﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PHPCTool
{
    public class TempCalibValue
    {
        public float Buffer1 { get; set; }
        public float Buffer2 { get; set; }
        public int read_count { get; set; }
        public float[] measure_vals { get; set; }

        public TempCalibValue()
        {
            Buffer1 = 1000f;
            Buffer2 = 1300f;
            measure_vals = new float[10];
            clear_data();
        }

        public void clear_data()
        {
            read_count = 0;
            for (int i = 0; i < 10; i++)
            {
                measure_vals[i] = 0;
            }
        }

        public bool CheckValid()
        {
            for (int i = 1; i < 10; i++)
            {
                if (measure_vals[i] - measure_vals[0] > 0.4f || measure_vals[i] - measure_vals[0] > 0.4f)
                    return false;
            }
            return true;
        }

    }
}
