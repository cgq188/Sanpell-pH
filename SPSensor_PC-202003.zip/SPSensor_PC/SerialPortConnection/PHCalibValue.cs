﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PHPCTool
{
    public class PHCalibValue
    {
        public float Buffer1 { get; set; }
        public float Buffer2 { get; set; }
        public float Buffer3 { get; set; }
        public float[] ph_voltage { get; set; }
        public float[] temperature { get; set; }
        public int read_count { get; set; }
        public DateTime StartTime { get; set; }

        public PHCalibValue()
        {
            Buffer1 = 4;
            Buffer2 = 7;
            Buffer3 = 10;
            ph_voltage = new float[10];
            temperature = new float[10];
            clear_data();
        }

        public void clear_data()
        {
            read_count = 0;
            for (int i = 0; i < 10; i++)
            {                
                ph_voltage[i] = 0;
                temperature[i] = 0;
            }
        }

        public float select_nist_tech_ph(float ph_mv)
        {
            float result = 1.68f;
            float[] tech_array = { 1.68f, 4.01f, 7.00f, 10.01f, 12.46f };
            float[] tech_mv_array = { 304f, 170.86f, 0.00f, -172f, -312f };
            float diff_min = 10000f;
            int i;

            for (i = 0; i < 5; i++)
            {
                if (diff_min * diff_min > (tech_mv_array[i] - ph_mv) * (tech_mv_array[i] - ph_mv))
                {
                    diff_min = tech_mv_array[i] - ph_mv;
                    result = tech_array[i];
                }
            }

            return result;
        }

        public float select_nist_standard_ph(float ph_mv)
        {
            float result = 1.68f;
            float[] std_array = { 1.68f, 4.01f, 6.87f, 9.18f, 12.45f };
            float[] std_mv_array = { 304f, 170.86f, 7.43f, -124.57f, -311.43f };
            float diff_min = 10000;
            int i;

            for (i = 0; i < 5; i++)
            {
                if (diff_min * diff_min > (std_mv_array[i] - ph_mv) * (std_mv_array[i] - ph_mv))
                {
                    diff_min = std_mv_array[i] - ph_mv;
                    result = std_array[i];
                }
            }
            return result;
        }

        public bool CheckValid()
        {
            for(int i = 1; i < 10; i++)
            {
                if (ph_voltage[i] - ph_voltage[0] > 0.4f || ph_voltage[i] - ph_voltage[0] > 0.4f)
                    return false;
                if (temperature[i] - temperature[0] > 0.4f || temperature[i] - temperature[0] > 0.4f)
                    return false;
            }
            return true;
        }

    }
}
