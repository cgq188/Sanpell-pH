/*********************************************************************************************************
*
* File                : usart.h
* Hardware Environment: 
* Build Environment   : RealView MDK-ARM  Version: 4.20
* Version             : V1.0
* By                  : 
*
*
*********************************************************************************************************/

#ifndef _USART_H
#define _USART_H

#include <stdio.h>
#include <stm32f10x.h>

#define MAIN_DEVICE_ADDRESS		0x02//0x16
#define BACKUP_DEVICE_ADDRESS	0x02//0x19

//data output type
#define OUTPUT_TYPE_SINGLE		0xA0
#define OUTPUT_TYPE_CONTINUE	0xA1
//data output format
#define OUTPUT_FORMAT_HEX		0xF1
#define OUTPUT_FORMAT_ASCII		0xF0


void USART_Configuration(uint32_t BaudRate);
void SendChar(uint8_t t);

#endif /*_USART_H*/
