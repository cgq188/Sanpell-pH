/****************************************************************************************
 * Device			  			: STM32F103RC
 * File                : main.c
 * Hardware Environment:
 * Build Environment   : RealView MDK-ARM  Version: 4.20
 * Version             : V1.0
 * By                  : KJH
 * Date				 				: 2018-01-10
 *****************************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"
#include "SysTick/systick.h" 
//#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdbool.h>

#include "ff.h"
#include "SPI_MSD_Driver.h"
#include "usart.h"
#include "timer.h"
#include "Flash.h"
#include "ACQ.h"
#include "RS485.h"

//#include "hmi_driver.h"
#include "cmd_queue.h"
#include "cmd_process.h"
#include "hw_config.h"	
#include "Info.h"
#include "PetitModbusPort.h"
#include "DataConvert.h"
#include "24cxx.h"


ErrorStatus HSEStartUpStatus;


#ifdef __GNUC__
/* With GCC/RAISONANCE, small printf (option LD Linker->Libraries->Small printf
     set to 'Yes') calls __io_putchar() */
#define PUTCHAR_PROTOTYPE int __io_putchar(int ch)
#else
#define PUTCHAR_PROTOTYPE int fputc(int ch, FILE *f)
#endif /* __GNUC__ */


#define MODBUS_DEV_ADDRESS 					0x39
#define MODBUS_BAUD_RATE_485 				0x3A
#define MODBUS_HW_VERSION 					0x3C
#define MODBUS_FW_VERSION 					0x1F //0x3F, at 20210806
#define MODBUS_SERIAL_NUMBER 				0x42
#define MODBUS_MF_NUMBER 						0x46
#define MODBUS_RPODUCT_NUMBER 			0x48
#define MODBUS_DATE_TIME 						0x4A



/* Private variables ---------------------------------------------------------*/
FATFS fs;         /* Work area (file system object) for logical drive */
FIL fsrc;         /* file objects */ 
FIL fsrc_r;
FRESULT res;
UINT br;

char path[512]="0:";
char subdir_year[7] = "3:/2021";
char subdir_month[10] = "3:/2021/07";
char subdir_day[13] = "3:/2021/07/15";
char save_filename[24] = "3:/2021/07/15/000011.TXT";
char read_filename[24] = "3:/2021/07/15/000011.TXT";

char fname[]="3:/00012915.TXT";				// SN=0002,Jan 29th 15o'clock
char fname_r[]="3:/00012915.TXT";			// Jan 29th 15o'clock
//uint8_t textFileBuffer[RECORD_MAX][36];	
uint8_t textFileBuffer[36];	
uint8_t read_buffer[36];			// file copy buffer

//uint8_t textRecord[35] = "2018-01-23 21:20:30, 7.00, 25.0 \r\n";

uint8_t cmd_buffer[CMD_MAX_SIZE];//ָ���
static uint16_t current_screen_id = 0;//��ǰ����ID
static uint16_t return_screen_id = 0;//��ǰ����ID

static int32_t test_value = 0;//����ֵ
//static uint8_t update_en = 0;//���±��

//////////////////////////////////////////
uint8	setting_pwd[6]; 
uint8	calib_pwd[6], factory_pwd[6]; 

//char* mode_icon[2] = {"pH","mV"};
//char* temper_icon[2] = {"ATC","MTC"};
char* signal_type[6] = {"pH","ORP","DO","SS","MLSS","Temper"};
char* signal_unit[6] = {"","mV","g/L","ppm","m3/h","mg/L"};
char* relay_types[2] = {"AIN1","AIN2"};
char* temper_mode[2] = {"ATC","MTC"};

uint8 mode_pH_ORP = 0;	//0:pH, 1:ORP, 2:DO, 3:SS, 4:MLSS
uint8 mode_ATC_MTC = MEASURE_MODE_ATC;	
uint8_t temper_1000_100 = TEMP_MODE_PT1000;

float pH_now_value = 7.00f; 
float pH_calc_value = 7.00f;
float pH_calib_offset = 0.0f;

float ORP_now_value = 0.0f; 
float ORP_calc_value = 0.0f; 
float ORP_auto = 0.0f; 
float ORP_avrg_value = 0.0f;

float temper_calib_manual[3];
float temper_calc_value = 25.0f;
float temper_auto = 25.0f;
float temper_manual = 25.0f;
float temper_now_res = 1000.0f;
float temper_calc_res = 1000.0f;

float Ain_now_value[2] = {0.0f,0.0f};
float Ain_calc_value[2] = {0.0f,0.0f};
float Ain_real_value[2] = {0.0f,0.0f};
float Ain_real_raw[2] = {0.0f,0.0f};
float calib_Ain_offset[2] = {0.0f,0.0f};

uint8 analog1_off_on = ANALOG1_STATE_OFF;
uint8 analog1_classify = ANALOG1_4_20;
uint8 analog1_type = 0;	//0:pH, 1:ORP, 2:DO, 3:SS, 4:MLSS, 5:Temper
uint8 analog2_off_on = ANALOG2_STATE_OFF;
uint8 analog2_classify = ANALOG2_4_20;
uint8 analog2_type = 0;
float analog1_point[2] = {0.0f,14.0f};
float analog2_point[2] = {0.0f,14.0f};	//[0]:0/4mA, [1]:20mA

//added by schn 2018-10-31
float analog1_point_ph[2] = {0.0f,14.0f};
float analog2_point_ph[2] = {0.0f,14.0f};	
float analog1_point_orp[2] = {-1000.0f,1000.0f};
float analog2_point_orp[2] = {-1000.0f,1000.0f};	
float analog1_point_temp[2] = {0.0f,100.0f};
float analog2_point_temp[2] = {0.0f,100.0f};

unsigned char type = 0;

float ACQ2analog_slope[2] = {1.0f,1.0f};	//0:analog1, 1:analog2
float ACQ2analog_offset[2] = {0.0f,0.0f};	//0:analog1, 1:analog2
//////////added at 2018/03/19 V1.1 ////////////////////////////////
uint8 analogIn_calib_ch = 0;	//0:AIN1, 1:AIN2
uint8 analogIn1_off_on = 0;		//0:OFF, 1:ON
uint8 analogIn1_classify = 1;	//0:0-20mA, 1:4-20mA
uint8 analogIn1_type = 0;		//0:pH, 1:ORP, 2:DO, 3:SS, 4:MLSS, 5:Temper
uint8 analogIn2_off_on = 0;		//0:OFF, 1:ON
uint8 analogIn2_classify = 1;	//0:0-20mA, 1:4-20mA
uint8 analogIn2_type = 5;		//0:pH, 1:ORP, 2:DO, 3:SS, 4:MLSS, 5:Temper
float analogIn1_point[2] = {0.0f,14.0f};
float analogIn2_point[2] = {0.0f,14.0f};	//[0]:0/4mA, [1]:20mA
float AIN2Val_slope[2] = {1.0f,1.0f};	//0:AIN1, 1:AIN2
float AIN2Val_offset[2] = {0.0f,0.0f};	//0:AIN1, 1:AIN2
///////////////////////////////////////////
uint8 relay1_off_on = RELAY1_STATE_OFF;
uint8 relay1_classify = RELAY1_LOW;
uint8 relay1_type = 0;	//0:AIN1, 1:AIN2
uint8 relay1_flag = 0;
uint8 relay2_off_on = RELAY2_STATE_OFF;
uint8 relay2_classify = RELAY2_LOW;
uint8 relay2_type = 0;
uint8 relay2_flag = 0;


float relay1_point[2];
float relay2_point[2];		//[0]:margin, [1]:warning

//added by schn 11/3/2018
float relay1_point_ph_low[2] = {0.0f,0.0f};
float relay2_point_ph_low[2] = {0.0f,0.0f};
float relay1_point_orp_low[2] = {0.0f,0.0f};
float relay2_point_orp_low[2] = {0.0f,0.0f};
float relay1_point_ph_hi[2] = {0.0f,0.0f};
float relay2_point_ph_hi[2] = {0.0f,0.0f};
float relay1_point_orp_hi[2] = {0.0f,0.0f};
float relay2_point_orp_hi[2] = {0.0f,0.0f};

//float relay1_point_ORP[2], relay2_point_ORP[2];		//[0]:margin, [1]:warning

float VALID_SLOPE = 0.36;

uint8 timer_off_on = TIMER_STATE_OFF;
uint8 timer_flag = 0;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   
float timer_point[2] = {600,10};		//[0]:pause, [1]:run period
static uint32 timer_count = 0;

uint16_t calib_pH_index = 0;
float calib_ORP_offset = 0.0f;
uint8 calib_pH_points, calib_pH_mode;
const float calib_pH_world_value[3] = {7.0f,4.01f,10.0f};
const float calib_pH_euro_value[3] = {6.86f,4.0f,9.18f};
float calib_pH_manual_value[3];
float calib_pH_value[3], calib_pH_measure[3];
float calib_pH_mV[3] = {0.0f,177.0f,-177.0f};
float calib_pH_slope[2] = {1.0f,1.0f};		//0:Positive, 1:Negative
float calib_pH_offset[2] = {0.0f,0.0f};	//0:Positive, 1:Negative
float calib_slope = 59.16f;
float calib_slope1 = 59.16f;
float mV2ph_coeff[3] = {59.16f, 59.16f, 59.16f};

uint8 calib_measure_flag = 0;
uint8 calib_measure_cnt = 0;
uint8 calib_stage_cnt = 0;
float calib_measure_ex[CALIB_SAMPLES];
float calib_measure_temp_ex[CALIB_SAMPLES];

float factory_ORP_ref[3] = {177.0f,0.0f,-177.0f};
float factory_ORP_measure[3] = {177.0f,0.0f,-177.0f};
float factory_ORP_slope[2] = {1.0f,1.0f};		//0:Positive, 1:Negative
float factory_ORP_offset[2] = {0.0f,0.0f};	//0:Positive, 1:Negative
float factory_temper_ref[2] = {1000.0f,1300.0f};
float factory_temper_measure[2] = {1000.0f,1300.0f};
float factory_temper_coeff[2] = {1.0f,0.0f};	//0:slope, 1:offset
uint8 progress_value = 0;
float factory_analog1_measure[2] = {4.0f,20.0f};
float factory_analog2_measure[2] = {4.0f,20.0f};
float factory_analog1_signal[2] = {4.0f,20.0f};
float factory_analog2_signal[2] = {4.0f,20.0f};
float factory_analog_slope[2] = {1.0f,1.0f};	//0:analog1, 1:analog2
float factory_analog_offset[2] = {0.0f,0.0f};	//0:analog1, 1:analog2
float factory_analogIn_slope[2] = {1.0f,1.0f};	//0:analog1, 1:analog2
float factory_analogIn_offset[2] = {0.0f,0.0f};	//0:analog1, 1:analog2
uint8_t analog_calib_flag = 0;
uint16_t calib_return_timeout = 0;	
//uint8_t bmesure_overflow[3] = {0};		//PH, ORP, temperature

uint8_t signal_src = SIGNAL_IN_SENSOR;
uint8_t RS485In_cmd_flag = 0;
uint32_t RS485_In_baud = 9600;		//115200;	
uint16_t factory_screen_id = 41; 

uint32_t RS485_baudrate = 9600;		//115200;		
uint8 light_in_flag = 0;	//Daytime
uint8_t now_year, now_month, now_day, now_hour, now_minute, now_sec;
uint8_t pre_day, pre_hour, pre_sec;

uint8_t ACQ_Enable = 1;
uint8_t Display_led, RS485_led; 
uint8_t ACQ_cycle;
uint16_t display_cnt = 0;
//uint16_t rs485_cnt_out = 0;
uint16_t HMI_init_cnt = 0;
uint8_t rx485_conn_flag = 0;

bool data_sample_10s_after_flag = false;
uint16_t data_sample_cnt = 0;
uint16_t data_record_i = 0;
uint32_t disp_data_time = 2822;
uint32_t disp_data_time_history = 2822;
uint32_t month_history;
uint8_t data_hist_ch = 0;	//0:AIN1, 1: AIN2
//char temp_record[] = "2018/01/23 21:20:30 -1000.0 -12.5 \r\n";

uint16_t main_count = 0;
unsigned char TF_CARD_STATE = 0;
unsigned char TF_CARD_DISP_STATE = 1;


//added by schn 2018/11/30
int16_t calib_count_down = 0;
char calib_count_down_buffer[10] = "05:00";

uint8 year_h, year_l, month, day, hour, minite, second;

extern PetitRegStructure  	PetitRegisters[];
extern unsigned char 				PETITMODBUS_SLAVE_ADDRESS;
extern unsigned int 				SettingUpdateFlag;

uint8_t custom_calib_state = 0;
float real_value1, real_value2;
uint32_t delay_count = 0, delay_max = 30;
uint8_t delay_flag = 0;

//schn add 2019/01/18
uint8_t calib_ph_mode = 0;		//0:nist	1:tech	2:manual
int16_t calib_count_up = 0;
float buffer1, buffer2, buffer3;
float temperature1, temperature2, temperature3;
float measured_ph[3] = {0.0f, 0.0f, 0.0f};
uint16_t orp_process_count = 0;

uint8_t calib_point_number = 0;
uint8_t calib_year, calib_month, calib_day, calib_hour, calib_minute, calib_sec;
uint8_t calib_mode = 0;
float calib_buffer1, calib_buffer2, calib_buffer3;
char* calib_mode_str[3] = {"NIST","TECH","MANUAL"};
char buffer_str[30];
float calib_temperature;
float calib_manual_temperature = 0.0f;
float calib_orp_buffer;

uint8_t calib_orp_year, calib_orp_month, calib_orp_day, calib_orp_hour, calib_orp_minute, calib_orp_sec;
float CALIB_ORP_THRES = 0.1f;

uint8_t	backlight_change = 0;

uint32_t orp_calib_point_num = 3;
uint32_t orp_calib_point_num_save = 3;
float orp_calib_ref_val[11] = {0,0,0,0,0,0,0,0,0,0,0};
float orp_calib_measure_val[11] = {0,0,0,0,0,0,0,0,0,0,0};
float orp_calib_ref_val_save[11] = {0,0,0,0,0,0,0,0,0,0,0};
float orp_calib_measure_val_save[11] = {0,0,0,0,0,0,0,0,0,0,0};
uint8_t orp_calib_process = 0;

uint32_t temp_calib_point_num = 3;
uint32_t temp_calib_point_num_save = 3;
float temp_calib_ref_val[11] = {0,0,0,0,0,0,0,0,0,0,0};
float temp_calib_measure_val[11] = {0,0,0,0,0,0,0,0,0,0,0};
float temp_calib_ref_val_save[11] = {0,0,0,0,0,0,0,0,0,0,0};
float temp_calib_measure_val_save[11] = {0,0,0,0,0,0,0,0,0,0,0};
uint8_t temp_calib_process = 0;

uint8 isCardMounted = 0x0;
extern unsigned char getStat(void);
uint8 read_rtc_flag = 0;

uint32_t current_timestamp = 0;
float zero_point = 7.0f;
float ph_second_point = 7.0f;

/* Private function prototypes -----------------------------------------------*/
//int SD_TotalSize(void);
//FRESULT scan_files (char* path);

/*******************************************************************************
 * Function Name  : Delay
 * Description    : Delay Time
 * Input          : - nCount: Delay Time
 * Output         : None
 * Return         : None
 * Attention		 : None
 *******************************************************************************/
void  Delay (uint32_t nCount)
{
	for(; nCount != 0; nCount--);
}

void IWDG_Init(uint8_t prer,uint16_t rlr) 
{	
	IWDG_WriteAccessCmd(IWDG_WriteAccess_Enable);  //enable writing to IWDG_PR, IWDG_RLR registers

	IWDG_SetPrescaler(prer);  //prescaler value= 4*2^prer, max 256 

	IWDG_SetReload(rlr);  //reload value for IWDG, 11bits

	IWDG_ReloadCounter();  //reload IWDG counter

	IWDG_Enable();  //enble IWDG
}

//Feed to IWDG
void IWDG_Feed(void)
{   
	IWDG_ReloadCounter();
}

void BindSettingValues()
{
	uint32_t baudrate_h, baudrate_l;
	// kjh repaired 20181104
	dev_address = PetitRegisters[MODBUS_DEV_ADDRESS].ActValue & 0x000000ff;		
	baudrate_h = PetitRegisters[MODBUS_BAUD_RATE_485].ActValue & 0x0000ffff;
	baudrate_l = PetitRegisters[MODBUS_BAUD_RATE_485 + 1].ActValue & 0x0000ffff;
	RS485_baudrate = (baudrate_h << 16) + baudrate_l;

	if(RS485_baudrate < 100 || RS485_baudrate > 230400)
		RS485_baudrate = 9600;
	if(dev_address < 1 || dev_address > 255)
		dev_address = 1;
	PETITMODBUS_SLAVE_ADDRESS = dev_address;

	//at 20210806
	HW_version[0] = PetitRegisters[MODBUS_HW_VERSION + 3].ActValue & 0xFF;
	HW_version[1] = (PetitRegisters[MODBUS_HW_VERSION + 3].ActValue >> 8) & 0xFF;
	HW_version[2] = PetitRegisters[MODBUS_HW_VERSION + 2].ActValue & 0xFF;
	HW_version[3] = (PetitRegisters[MODBUS_HW_VERSION + 2].ActValue >> 8) & 0xFF;
	HW_version[4] = PetitRegisters[MODBUS_HW_VERSION + 1].ActValue & 0xFF;
	HW_version[5] = (PetitRegisters[MODBUS_HW_VERSION + 1].ActValue >> 8) & 0xFF;
	HW_version[6] = PetitRegisters[MODBUS_HW_VERSION].ActValue & 0xFF;
	HW_version[7] = (PetitRegisters[MODBUS_HW_VERSION].ActValue >> 8) & 0xFF;

	//at 20210806
	FW_version[0] = PetitRegisters[MODBUS_FW_VERSION + 3].ActValue & 0xFF;
	FW_version[1] = (PetitRegisters[MODBUS_FW_VERSION + 3].ActValue >> 8) & 0xFF;
	FW_version[2] = PetitRegisters[MODBUS_FW_VERSION + 2].ActValue & 0xFF;
	FW_version[3] = (PetitRegisters[MODBUS_FW_VERSION + 2].ActValue >> 8) & 0xFF;
	FW_version[4] = PetitRegisters[MODBUS_FW_VERSION + 1].ActValue & 0xFF;
	FW_version[5] = (PetitRegisters[MODBUS_FW_VERSION + 1].ActValue >> 8) & 0xFF;
	FW_version[6] = PetitRegisters[MODBUS_FW_VERSION].ActValue & 0xFF;
	FW_version[7] = (PetitRegisters[MODBUS_FW_VERSION].ActValue >> 8) & 0xFF;	

	SN_num[0] = PetitRegisters[MODBUS_SERIAL_NUMBER + 3].ActValue & 0xFF;
	SN_num[1] = (PetitRegisters[MODBUS_SERIAL_NUMBER + 3].ActValue >> 8) & 0xFF;
	SN_num[2] = PetitRegisters[MODBUS_SERIAL_NUMBER + 2].ActValue & 0xFF;
	SN_num[3] = (PetitRegisters[MODBUS_SERIAL_NUMBER + 2].ActValue >> 8) & 0xFF;
	SN_num[4] = PetitRegisters[MODBUS_SERIAL_NUMBER + 1].ActValue & 0xFF;
	SN_num[5] = (PetitRegisters[MODBUS_SERIAL_NUMBER + 1].ActValue >> 8) & 0xFF;
	SN_num[6] = PetitRegisters[MODBUS_SERIAL_NUMBER + 0].ActValue & 0xFF;
	SN_num[7] = (PetitRegisters[MODBUS_SERIAL_NUMBER + 0].ActValue >> 8) & 0xFF;

	Factory_num[0] = PetitRegisters[MODBUS_MF_NUMBER + 1].ActValue & 0xFF;
	Factory_num[1] = (PetitRegisters[MODBUS_MF_NUMBER + 1].ActValue >> 8) & 0xFF;
	Factory_num[2] = PetitRegisters[MODBUS_MF_NUMBER + 0].ActValue & 0xFF;
	Factory_num[3] = (PetitRegisters[MODBUS_MF_NUMBER + 0].ActValue >> 8) & 0xFF;

	Product_num[0] = PetitRegisters[MODBUS_RPODUCT_NUMBER + 1].ActValue & 0xFF;
	Product_num[1] = (PetitRegisters[MODBUS_RPODUCT_NUMBER + 1].ActValue >> 8) & 0xFF;
	Product_num[2] = PetitRegisters[MODBUS_RPODUCT_NUMBER + 0].ActValue & 0xFF;
	Product_num[3] = (PetitRegisters[MODBUS_RPODUCT_NUMBER + 0].ActValue >> 8) & 0xFF;

	datetime[0] = PetitRegisters[MODBUS_DATE_TIME + 6].ActValue & 0xFF;
	datetime[1] = (PetitRegisters[MODBUS_DATE_TIME + 6].ActValue >> 8) & 0xFF;
	datetime[2] = PetitRegisters[MODBUS_DATE_TIME + 5].ActValue & 0xFF;
	datetime[3] = (PetitRegisters[MODBUS_DATE_TIME + 5].ActValue >> 8) & 0xFF;
	datetime[4] = PetitRegisters[MODBUS_DATE_TIME + 4].ActValue & 0xFF;
	datetime[5] = (PetitRegisters[MODBUS_DATE_TIME + 4].ActValue >> 8) & 0xFF;
	datetime[6] = PetitRegisters[MODBUS_DATE_TIME + 3].ActValue & 0xFF;
	datetime[7] = (PetitRegisters[MODBUS_DATE_TIME + 3].ActValue >> 8) & 0xFF;
	datetime[8] = PetitRegisters[MODBUS_DATE_TIME + 2].ActValue & 0xFF;
	datetime[9] = (PetitRegisters[MODBUS_DATE_TIME + 2].ActValue >> 8) & 0xFF;
	datetime[10] = PetitRegisters[MODBUS_DATE_TIME + 1].ActValue & 0xFF;
	datetime[11] = (PetitRegisters[MODBUS_DATE_TIME + 1].ActValue >> 8) & 0xFF;
	datetime[12] = PetitRegisters[MODBUS_DATE_TIME].ActValue & 0xFF;
	datetime[13] = (PetitRegisters[MODBUS_DATE_TIME].ActValue >> 8) & 0xFF;

	//now_year = (datetime[0] - 0x30) * 1000 + (datetime[1] - 0x30) * 100 + (datetime[2] - 0x30) * 10 + (datetime[3] - 0x30);
	//now_month = (datetime[4] - 0x30) * 10 + (datetime[5] - 0x30);
	//now_day = (datetime[6] - 0x30) * 10 + (datetime[7] - 0x30);
	//now_hour = (datetime[8] - 0x30) * 10 + (datetime[9] - 0x30);
	//now_minute = (datetime[10] - 0x30) * 10 + (datetime[11] - 0x30);
	//now_sec = (datetime[12] - 0x30) * 10 + (datetime[13] - 0x30);

	year_h = 	((datetime[0] - 0x30) << 4) + (datetime[1] - 0x30);
	year_l = 	((datetime[2] - 0x30) << 4) + (datetime[3] - 0x30);
	month = 	((datetime[4] - 0x30) << 4) + (datetime[5] - 0x30);
	day = 		((datetime[6] - 0x30) << 4) + (datetime[7] - 0x30);
	hour = 		((datetime[8] - 0x30) << 4) + (datetime[9] - 0x30);
	minite = 	((datetime[10] - 0x30) << 4) + (datetime[11] - 0x30);
	second = 	((datetime[12] - 0x30) << 4) + (datetime[13] - 0x30);

}

void Display_DeviceInfo()
{
	SetTextValue(62,2,HW_version);	delay_ms(1);
	SetTextValue(62,3,FW_version);	delay_ms(1);
	SetTextValue(62,4,SN_num);	delay_ms(1);
	SetTextValue(62,5,Factory_num);	delay_ms(1);
	SetTextValue(62,6,Product_num);	delay_ms(1);
}

/*******************************************************************************
 * Function Name  : main
 * Description    : Main program
 * Input          : None
 * Output         : None
 * Return         : None
 * Attention		 : None
 *******************************************************************************/
int main(void){

	qsize  size = 0;
	//	int idx = 0;
	///////////////////////////////
	now_year = 0x18;
	now_month = 0x01;
	now_day = 0x28;
	now_hour = 0x22;
	now_minute = 0x30;
	now_sec = 0x45;
	////////////////////////////////////

	RCC_Configuration();
	delay_init();

	//AT24CXX_Init();
	GetParams();
	BindSettingValues();	
	analogIn2_type = 5;	//temper
	//RS485_In_baud = 115200;	//test

	USART_Configuration(19200);	//115200
	//RS485_Configuration(RS485_baudrate);
	//RS485In_Config(RS485_In_baud);

	InitPetitModbus(dev_address, RS485_baudrate);

	AD7793_Configuration();
	ACQ_Init();
	GPIO_Configuration();
	TIM_Configuration();
	NVIC_Configuration();
	MSD_SPI_Configuration();	

	queue_reset();
	delay_ms(500);
	HMI_Init();

	AnimationPlayFrame(0,16,1);
	delay_ms(10);

	/*	if(_card_insert() != 0 )	//No card detected
		TF_CARD_STATE = 1; //SetScreen(76);	
	else
		TF_CARD_STATE = 0;
  f_mount(0,&fs);	*/
	isCardMounted = f_mount(&fs, "3:", 1); //at 20210721
	if(isCardMounted == FR_OK)
		TF_CARD_STATE = 0;
	else
		TF_CARD_STATE = 1; ////////

	display_cnt = 0;
	backlight_change = Env_Light_Sensor;

	while (1)
	{
		size = queue_find_cmd(cmd_buffer,CMD_MAX_SIZE);     
		if(size>0)
		{
			ProcessMessage((PCTRL_MSG)cmd_buffer, size);	//@jay   �������Ǵ�������������
		}		
		delay_ms(20); 

		if(SettingUpdateFlag != 0)	//@jay ���Modbus�����ݽ��������ã�modbus�Ĵ���������Ҫ����
		{
			SaveParams();
			GetParams();
			BindSettingValues();	
			if(MODBUS_DATE_TIME == SettingUpdateFlag)
				WriteRtc(year_h, year_l, month, day, hour, minite, second);
			if(MODBUS_BAUD_RATE_485 == SettingUpdateFlag)
				InitPetitModbus(dev_address, RS485_baudrate);
			Display_DeviceInfo();
			SettingUpdateFlag = 0;
		}

		ProcessPetitModbus();	//����modbusЭ��

		//----------------- LCD Backlight control -----------------------//
		if(backlight_change != Env_Light_Sensor)
		{
			backlight_change = Env_Light_Sensor;
			if(!Env_Light_Sensor) 
			{
				SetAutoBacklight(0,50,50,10);	//wanshang
			}
			else 
			{
				SetAutoBacklight(0,250,50,10);	//baitian
			}
		} 

		if(display_cnt>=TIME_1000MS)	//1000ms @jay ��TIM2���ж��������++����
		{
			display_cnt = 0;

			//--------------------- check TF card -----------------------//
			if(_card_insert()) //at 20210721
			{
				isCardMounted = 1;
				TF_CARD_STATE = 1;
			}
			else
			{
				if(isCardMounted == 1)
				{
					isCardMounted = f_mount(&fs, "3:", 1);
					if(isCardMounted == FR_OK)
						TF_CARD_STATE = 0;
				}
			}			///////

			if(TF_CARD_STATE == 0)
			{
				AnimationPlayFrame(0,16,1);
				delay_ms(10); //10
			}
			else
			{
				if(TF_CARD_DISP_STATE==1)
					TF_CARD_DISP_STATE = 0;
				else
					TF_CARD_DISP_STATE = 1;
				AnimationPlayFrame(0,16,TF_CARD_DISP_STATE);
				delay_ms(10); //10
			}

			if(HMI_init_cnt<3)	//wait until ACQ be stabled
				HMI_init_cnt ++;
			else if(HMI_init_cnt==3)
			{
				UpdateUI();
				SetScreen(0);
				HMI_init_cnt = 4;
				pre_day = now_day;
				pre_hour = now_hour;

				//			IWDG_Init(6,625);    //Tout=4s, //Tout=((4*2^prer)*rlr)/40 (ms)
				//	IWDG_Init(6,0xfff);
			}
			else
			{
				UpdateUI();		//at about every 1s
				ReadRtc(); //at 20210924
			}

			//------------ RUN LED ------------------//
			//	Display_led = ~Display_led;
			if( Display_led ) 
			{ 
				/*====LED-ON=======*/
				//GPIO_SetBits(GPIOC, GPIO_Pin_10);
				LED_RUN_OFF;
				Display_led = 0;				
			}
			else 
			{ 
				/*====LED-OFF=======*/ 
				//GPIO_ResetBits(GPIOC, GPIO_Pin_10);
				LED_RUN_ON;
				Display_led = 1;
			}


			if(data_sample_10s_after_flag)
			{
				//-------------------- Analog1, Analoag2 output -------------------//
				if(!analog_calib_flag)
				{
					ACQ_Enable = 0;
					AD7793_Disable;
					delay_ms(1);
					if(analog1_off_on)	//A channel
						C4To20mASet(0, ConvToAnalog1());
					else	//added at 20200601
						C4To20mASet(0, 0.0f);

					if(analog2_off_on)	//B channel
						C4To20mASet(1, ConvToAnalog2());
					else
						C4To20mASet(1, 0.0f);

					delay_ms(1);
					ACQ_Enable = 1;
				} //end of if(analog_calib_flag==0)
			}




			data_sample_cnt ++;
			//			if(data_sample_cnt==(DATA_INTERVAL-1))
			//				ReadRtc();
			if(data_sample_cnt>=DATA_INTERVAL)	//at about every 10s
			{
				data_sample_10s_after_flag = true;
				data_sample_cnt = 0;
				//	IWDG_Feed();			

				if(current_screen_id == 0) //at 20211026
					main_count = 0;	
				else
				{
					main_count++;
					if(main_count > TIME_RETURN)//180x10=1800s=30min
					{
						main_count = 0;
						current_screen_id = 0;
						SetScreen(current_screen_id);
					}
				}			
				/**
				 * @jay isCardMounted�ǹ��ڳɹ���־�� read_rtc_flag�ǽ��յ���������RTC�¼���־
				 * �������Ǳ�����ʱ�������Ч����ΪҪ�õ�RTC��ʱ����Ϊʱ���
				 */
				if(isCardMounted == FR_OK && read_rtc_flag == 1)
				{
					RecordToTFCard(current_timestamp); //at 20210721
				}
				//pre_day = now_day;
				//pre_hour = now_hour;							

				//////////////////////////////////////////
				//		if(current_screen_id==0)		//repaired at 20200408
//				{
//					//-------------------- Analog1, Analoag2 output -------------------//
//					if(!analog_calib_flag)
//					{
//						ACQ_Enable = 0;
//						AD7793_Disable;
//						delay_ms(1);
//						if(analog1_off_on)	//A channel
//							C4To20mASet(0, ConvToAnalog1());
//						else	//added at 20200601
//							C4To20mASet(0, 0.0f);
//
//						if(analog2_off_on)	//B channel
//							C4To20mASet(1, ConvToAnalog2());
//						else
//							C4To20mASet(1, 0.0f);
//
//						delay_ms(1);
//						ACQ_Enable = 1;
//					} //end of if(analog_calib_flag==0)
//				}

				//-------------------- History export -------------------------//
				/*	for(i=0; i<10; i++)
					{
						his_data[0][i] = i*116/10;
						his_data[1][i] = his_data[0][i]*5/10;
					}
					CurveDataToFoot(76,1,0,10,his_data[0]);
					CurveDataToFoot(76,1,1,10,his_data[1]); */

			} //end of if(data_sample_cnt>=DATA_INTERVAL)
		}		//end of if(TIME_OUT)	

	}
}

unsigned char RecordToTFCard(uint32_t time_stamp)
{
	FRESULT fr;
	FRESULT mk_res;
	FRESULT open_res;
	FILINFO fno;
	//	char temp_buf[8] = {0};
	uint16_t j;
	char buffer[8] = {0};

	timestamp_to_subdir_year(time_stamp, subdir_year);
	fr = f_stat(subdir_year, &fno);
	switch (fr)
	{
	case FR_OK:
		break;
	case FR_NO_FILE:
		mk_res = f_mkdir(subdir_year);
		if(mk_res != FR_OK)
		{
			return 0;
		}
		break;
	default:
		return 0;
		//			break;
	}

	timestamp_to_subdir_month(time_stamp, subdir_month);
	fr = f_stat(subdir_month, &fno);
	switch (fr)
	{
	case FR_OK:
		break;
	case FR_NO_FILE:
		mk_res = f_mkdir(subdir_month);
		if(mk_res != FR_OK)
		{
			return 0;
		}
		break;
	default:
		return 0;
		//			break;
	}

	timestamp_to_subdir_day(time_stamp, subdir_day);
	fr = f_stat(subdir_day, &fno);
	switch (fr)
	{
	case FR_OK:
		break;
	case FR_NO_FILE:
		mk_res = f_mkdir(subdir_day);
		if(mk_res != FR_OK)
		{
			return 0;
		}
		break;
	default:
		return 0;
		//			break;
	}	

	timestamp_to_filename(time_stamp, save_filename);
	fr = f_stat(save_filename, &fno);
	switch (fr)
	{
	case FR_OK:
		open_res = f_open(&fsrc, save_filename, FA_WRITE);
		if(open_res != FR_OK)
		{
			TF_CARD_STATE = 1;
			return 0;
		}
		f_lseek(&fsrc,f_size(&fsrc));

		textFileBuffer[0] = 2 + '0';
		textFileBuffer[1] = 0 + '0';
		textFileBuffer[2] = ((now_year >> 4) & 0x0F) + '0';
		textFileBuffer[3] = (now_year & 0x0F) + '0';
		textFileBuffer[4] = '/';
		textFileBuffer[5] = ((now_month >> 4) & 0x0F) + '0';
		textFileBuffer[6] = (now_month & 0x0F) + '0';
		textFileBuffer[7] = '/';
		textFileBuffer[8] = ((now_day>>4) & 0x0F) + '0';
		textFileBuffer[9] = (now_day & 0x0F) + '0';
		textFileBuffer[10] = ' ';

		textFileBuffer[11] = ((now_hour >> 4) & 0x0F) + '0';
		textFileBuffer[12] = (now_hour & 0x0F) + '0';
		textFileBuffer[13] = ':';
		textFileBuffer[14] = ((now_minute >> 4) & 0x0F) + '0';
		textFileBuffer[15] = (now_minute & 0x0F) + '0';
		textFileBuffer[16] = ':';
		textFileBuffer[17] = ((now_sec >> 4) & 0x0F) + '0';
		textFileBuffer[18] = (now_sec & 0x0F) + '0';
		textFileBuffer[19] = ' ';

		switch(analogIn1_type)
		{
		case 0:	//pH
			//case 2:	//DO
			sprintf(buffer,"%.2f",Ain_real_value[0]);
			break;
		case 1:	//ORP
			//case 3:	//SS
		case 5:	//Temper
			sprintf(buffer,"%.1f",Ain_real_value[0]);
			break;
		case 4:	//MLSS
			sprintf(buffer,"%u",(uint32_t)Ain_real_value[0]);
			break;
		default:
			break;
		}

		for(j = 0; j < 7; j++)
			textFileBuffer[20 + j] = buffer[j];		//[26]
		textFileBuffer[27] = ' ';

		switch(analogIn2_type)
		{
		case 0:	//pH
			//case 2:	//DO
			sprintf(buffer,"%.2f",Ain_real_value[1]);
			break;
		case 1:	//ORP
			//case 3:	//SS
		case 5:	//Temper
			sprintf(buffer,"%.1f",Ain_real_value[1]);
			break;
		case 4:	//MLSS
			sprintf(buffer,"%u",(uint32_t)Ain_real_value[1]);
			break;
		default:
			break;
		}
		for(j = 0; j < 5; j++)
			textFileBuffer[28+j] = buffer[j];	//[32]
		textFileBuffer[33] = ' ';
		textFileBuffer[34] = '\r';
		textFileBuffer[35] = '\n';

		res = f_write(&fsrc, textFileBuffer, sizeof(textFileBuffer), &br);
		f_close(&fsrc);
		if(res != 0)
			TF_CARD_STATE = 1;
		else
			TF_CARD_STATE = 0;
		break;
		case FR_NO_FILE:
			open_res = f_open(&fsrc, save_filename, FA_CREATE_NEW | FA_WRITE);
			if(open_res != FR_OK)
			{
				TF_CARD_STATE = 1;
				return 0;
			}
			for(j = 0; j < 36; j++)
				textFileBuffer[j] = ' ';	
			textFileBuffer[0] = 'D';
			textFileBuffer[1] = 'a';
			textFileBuffer[2] = 't';
			textFileBuffer[3] = 'e';

			textFileBuffer[11] = 'T';
			textFileBuffer[12] = 'i';
			textFileBuffer[13] = 'm';
			textFileBuffer[14] = 'e';

			for(j = 0; j < strlen(signal_type[analogIn1_type]); j++)
			{
				textFileBuffer[20+j] = signal_type[analogIn1_type][j];	
			}
			for(j=0; j<strlen(signal_type[analogIn2_type]); j++)
			{
				textFileBuffer[27+j] = signal_type[analogIn2_type][j];	
			}
			textFileBuffer[34] = '\r';
			textFileBuffer[35] = '\n';
			res = f_write(&fsrc, textFileBuffer, sizeof(textFileBuffer), &br);
			f_close(&fsrc);
			if(res == FR_OK)
			{
				TF_CARD_STATE = 0;
				return 1;
			}
			else
			{
				TF_CARD_STATE = 1;
				return 0;
			}
			//			break;
		default:
			return 0;
			//			break;
	}		
	return 1;
}

void ReadFromTFCard(uint32_t time_stamp)
{
	uint16_t i,j;
	//	char temp_buf[8] = {0};
	char time_buf[36] = {0};
	char data_buf[8] = {0};
	float temp_float;
	uint8_t history_data[RECORD_MAX] = {0};		

	timestamp_to_filename(time_stamp, read_filename);

	////////// Card reading ////////////////////
	res = f_open(&fsrc_r, read_filename, FA_OPEN_EXISTING | FA_READ);

	if(res != FR_OK)
	{
		char time_str[40];
		//		int i;
		timestamp_to_history_time_str(time_stamp, time_str);

		SetTextValue(current_screen_id, 11, "MAX: ----");
		SetTextValue(current_screen_id, 13, "MIN: ----");
		SetTextValue(current_screen_id, 15, "AVG: ----");
		SetTextValue(current_screen_id, 10, "MAX: ----");
		SetTextValue(current_screen_id, 12, "MIN: ----");
		SetTextValue(current_screen_id, 14, "AVG: ----");

		if(current_screen_id != 0)
			SetTextValue(current_screen_id, 7, time_str); //display date&time
		f_close(&fsrc_r); 
		return;
	}
	else
	{
		float sum, max, min;
		int sample_count = 0;
		char max_str[20], min_str[20], avg_str[20];

		sum = 0;
		max = 0;
		min = 10000;

		res = f_read(&fsrc_r, read_buffer, 36, &br);	//read 1st line (Indicator)

		for(i = 0; i < RECORD_MAX; i++)
		{
			res = f_read(&fsrc_r, read_buffer, 36, &br);
			if(res != 0)	//no data
				break;
			sample_count++;	
			if(i == 0)
			{
				for(j = 0; j < 16; j++)
					time_buf[j] = read_buffer[j];
			}

			//-------------------- History export -------------------------//

			if(data_hist_ch == 0)	//Main Value
			{
				for(j = 0; j < 7; j++)
					data_buf[j] = read_buffer[20 + j];		

				data_buf[7] = 0;
				sscanf(data_buf, "%f", &temp_float);	

				if(analogIn1_type == 0)
				{
					history_data[i] = (uint8_t)((temp_float + 2.0f) * 160.0f / 18.0f);
				}
				else
				{
					history_data[i] = (uint8_t)((temp_float + 2500.0f) * 160.0f / 5000.0f);
				}				
			}
			else if(data_hist_ch == 1)	//Temperature
			{
				for(j = 0; j < 5; j++)
					data_buf[j] = read_buffer[28 + j];
				data_buf[5] = 0;
				sscanf(data_buf, "%f", &temp_float);	

				history_data[i] = (uint8_t)((temp_float + 50.0f) * 160.0f / 200.0f);		

			}	//end of else if(data_hist_ch==1)

			sum += temp_float;
			if(max < temp_float)
				max = temp_float;
			if(min > temp_float)
				min = temp_float;
		}	//end of for(i=0; i<RECORD_MAX;i++)				

		sprintf(max_str, "MAX: %.2f", max);
		sprintf(min_str, "MIN: %.2f", min);
		sprintf(avg_str, "AVG: %.2f", sum / sample_count);

		if(current_screen_id != 0)
		{
			if(data_hist_ch == 0)
			{
				SetTextValue(current_screen_id, 11, max_str);
				SetTextValue(current_screen_id, 13, min_str);  
				SetTextValue(current_screen_id, 15, avg_str);  
			}
			else
			{
				SetTextValue(current_screen_id, 10, max_str);  
				SetTextValue(current_screen_id, 12, min_str);  
				SetTextValue(current_screen_id, 14, avg_str);  
			}
		}

		time_buf[16] = '-';
		for(j=0; j<16; j++)
			time_buf[17+j] = read_buffer[j];
		time_buf[33] = 0;

		if(current_screen_id != 0)
			SetTextValue(current_screen_id, 7, time_buf); //display date&time

		if(data_hist_ch == 0)
		{
			CurveDataToFoot(current_screen_id, 8, 0, RECORD_MAX, history_data);	
		}
		else
		{
			CurveDataToFoot(current_screen_id, 9, 0, RECORD_MAX, history_data);	
		}

		f_close(&fsrc_r); 
	}	//end of if(res!=FR_NO_FILE))
}

////////////////////////////////////////////////////////////////////////
/**************** Record a data *********************************
 ** textRecord[38] = "2018/01/23 21:20:30 -1000.0 -12.5 \r\n";
 *********************************************************************/

/************* 4To20mA complement ****************************/
float Comp4To20mA(uint8_t ch, float data)
{
	float result;

	result = data*ACQ2analog_slope[ch]+ACQ2analog_offset[ch];
	//result = result*factory_analog_slope[ch]+factory_analog_offset[ch];
	return result;
}

//------------- pH/ORP to mA -----------------------------------//
float ConvToAnalog1(void)
{
	float result;

	switch(analog1_type)
	{
	case 0:
	case 1:
		result = real_value1;
		break;
	case 5:
		result = real_value2;
		break;
	default:
		break;
	}
	//result = Ain_real_value[0];
	result = result*ACQ2analog_slope[0]+ACQ2analog_offset[0];			
	if((analog1_classify==ANALOG1_0_20) && (result<0.0f)) //at 20210730
		result = 0.0f;
	else if((analog1_classify==ANALOG1_4_20) && (result<4.0f))
		result = 4.0f;
	else if(result>20.0f)
		result = 20.0f;

	return result;
}

//------------- pH/ORP to mA -----------------------------------//
float ConvToAnalog2(void)
{
	float result;

	switch(analog2_type)
	{
	case 0:
	case 1:
		result = real_value1;
		break;
	case 5:
		result = real_value2;
	default:
		break;
	}
	//result = Ain_real_value[1];
	result = result*ACQ2analog_slope[1]+ACQ2analog_offset[1];		
	if((analog2_classify==ANALOG2_0_20) && (result<0.0f))//at 20210730
		result = 0.0f;
	else if((analog2_classify==ANALOG2_4_20) && (result<4.0f))
		result = 4.0f;
	else if(result>20.0f)
		result = 20.0f;

	return result;
}

//-------------- Save parameters to Flash -------------------------------------------------//
void SaveParams(void)
{
	uint16_t i, j;
	uint8_t u8arr[4];

	uint32_t flash_write_data[FLASH_DATA_SIZE]; //at 20210806
	uint32_t tempor_u32;
	// kjh repaired 20181104
	PETITMODBUS_SLAVE_ADDRESS = dev_address;
	PetitRegisters[MODBUS_DEV_ADDRESS].ActValue = (uint16_t)dev_address;
	tempor_u32 = RS485_baudrate;
	PetitRegisters[MODBUS_BAUD_RATE_485].ActValue = (uint16_t)(tempor_u32 >> 16);
	PetitRegisters[MODBUS_BAUD_RATE_485 + 1].ActValue = (uint16_t)tempor_u32;

	for(i=0; i<FLASH_DATA_SIZE; i++)
		flash_write_data[i] = 0;

	/*************** flash_write_data[0] *****************************************
13 						12 							11 							10							9 										8 							7 								6 
mode_pH_ORP		mode_ATC_MTC		temper_1000_100	analog1_off_on	analog1_classify			analog2_off_on	analog2_classify	timer_off_on
5							4								3					 			2				 				1				 							0 							
relay1_off_on	relay1_classify	relay2_off_on		relay2_classify analog1_type	analog2_type
	 ************************************************************************/
	//Setting state
	//flash_write_data[0] = flash_write_data[0] + mode_pH_ORP;	
	flash_write_data[0] = (flash_write_data[0]) + mode_ATC_MTC;
	flash_write_data[0] = (flash_write_data[0]<<1) + temper_1000_100;
	flash_write_data[0] = (flash_write_data[0]<<1) + analog1_off_on;
	flash_write_data[0] = (flash_write_data[0]<<1) + analog1_classify;
	flash_write_data[0] = (flash_write_data[0]<<1) + analog2_off_on;
	flash_write_data[0] = (flash_write_data[0]<<1) + analog2_classify;
	flash_write_data[0] = (flash_write_data[0]<<1) + timer_off_on;
	flash_write_data[0] = (flash_write_data[0]<<1) + relay1_off_on;
	flash_write_data[0] = (flash_write_data[0]<<1) + relay1_classify;
	flash_write_data[0] = (flash_write_data[0]<<1) + relay2_off_on;
	flash_write_data[0] = (flash_write_data[0]<<1) + relay2_classify;

	flash_write_data[0] = (flash_write_data[0]<<1) + analogIn1_off_on;
	flash_write_data[0] = (flash_write_data[0]<<1) + analogIn1_classify;
	flash_write_data[0] = (flash_write_data[0]<<1) + analogIn2_off_on;
	flash_write_data[0] = (flash_write_data[0]<<1) + analogIn2_classify;

	flash_write_data[1] = FloatToUInt32(calib_pH_slope[1]);
	flash_write_data[2] = FloatToUInt32(calib_pH_slope[0]);
	flash_write_data[3] = FloatToUInt32(calib_pH_offset[1]);
	flash_write_data[4] = FloatToUInt32(calib_pH_offset[0]); 

	flash_write_data[5] = FloatToUInt32(factory_ORP_slope[1]);
	flash_write_data[6] = FloatToUInt32(factory_ORP_slope[0]);
	flash_write_data[7] = FloatToUInt32(factory_ORP_offset[1]);
	flash_write_data[8] = FloatToUInt32(factory_ORP_offset[0]);
	flash_write_data[9] = FloatToUInt32(factory_temper_coeff[1]);
	flash_write_data[10] = FloatToUInt32(factory_temper_coeff[0]);

	////////////////////////////////////////////////////////
	flash_write_data[11] = FloatToUInt32(calib_Ain_offset[0]);
	flash_write_data[12] = FloatToUInt32(calib_Ain_offset[1]);

	//at 20210922
	flash_write_data[13] = FloatToUInt32(relay1_point_ph_low[1]);
	flash_write_data[14] = FloatToUInt32(relay1_point_ph_low[0]);
	flash_write_data[15] = FloatToUInt32(relay2_point_ph_low[1]);
	flash_write_data[16] = FloatToUInt32(relay2_point_ph_low[0]);
	flash_write_data[17] = FloatToUInt32(relay1_point_orp_low[1]);
	flash_write_data[18] = FloatToUInt32(relay1_point_orp_low[0]);
	flash_write_data[19] = FloatToUInt32(relay2_point_orp_low[1]);
	flash_write_data[20] = FloatToUInt32(relay2_point_orp_low[0]);

	flash_write_data[21] = FloatToUInt32(relay1_point_ph_hi[1]);
	flash_write_data[22] = FloatToUInt32(relay1_point_ph_hi[0]);
	flash_write_data[23] = FloatToUInt32(relay2_point_ph_hi[1]);
	flash_write_data[24] = FloatToUInt32(relay2_point_ph_hi[0]);
	flash_write_data[25] = FloatToUInt32(relay1_point_orp_hi[1]);
	flash_write_data[26] = FloatToUInt32(relay1_point_orp_hi[0]);
	flash_write_data[27] = FloatToUInt32(relay2_point_orp_hi[1]);
	flash_write_data[28] = FloatToUInt32(relay2_point_orp_hi[0]);

	flash_write_data[29] = FloatToUInt32(timer_point[1]);
	flash_write_data[30] = FloatToUInt32(timer_point[0]);

	flash_write_data[31] = FloatToUInt32(factory_analog_slope[1]);
	flash_write_data[32] = FloatToUInt32(factory_analog_slope[0]);
	flash_write_data[33] = FloatToUInt32(factory_analog_offset[1]);
	flash_write_data[34] = FloatToUInt32(factory_analog_offset[0]);

	//flash_write_data[30] = RS485_baudrate;
	flash_write_data[35] = FloatToUInt32(temper_manual);

	flash_write_data[36] = 0x000000ff & mode_pH_ORP;
	flash_write_data[36] = (flash_write_data[36]<<8) + signal_src;
	flash_write_data[36] = (flash_write_data[36]<<8) + dev_address;
	flash_write_data[36] = (flash_write_data[36]<<8) + sensor_addr;

	flash_write_data[37] = 0x000000ff & analog1_type;
	flash_write_data[37] = (flash_write_data[37]<<8) + analog2_type;
	flash_write_data[37] = (flash_write_data[37]<<8) + analogIn1_type;
	flash_write_data[37] = (flash_write_data[37]<<8) + analogIn2_type;

	flash_write_data[38] = 0x000000ff & relay1_type;
	flash_write_data[38] = (flash_write_data[38]<<8) + relay2_type;

	flash_write_data[41] = FloatToUInt32(factory_analogIn_slope[1]);
	flash_write_data[42] = FloatToUInt32(factory_analogIn_slope[0]);
	flash_write_data[43] = FloatToUInt32(factory_analogIn_offset[1]);
	flash_write_data[44] = FloatToUInt32(factory_analogIn_offset[0]);
	flash_write_data[45] = RS485_In_baud;

	///schn added 2018/08/12, kjh repaired 20181104
	j = 0;
	for(i = 0x39; i < 0x51; i+=2)  
	{
		j++;
		tempor_u32 = PetitRegisters[i].ActValue & 0x0000ffff;
		flash_write_data[45 + j] = (tempor_u32 << 16) + (PetitRegisters[i + 1].ActValue & 0x0000ffff);
	}	
	j = 0; //at 20210806
	for(i = MODBUS_FW_VERSION; i < MODBUS_FW_VERSION+4; i+=2)  
	{
		j++;
		tempor_u32 = PetitRegisters[i].ActValue & 0x0000ffff;
		flash_write_data[140 + j] = (tempor_u32 << 16) + (PetitRegisters[i + 1].ActValue & 0x0000ffff);
	}	
	////////////////////////////////////

	//at 20210922
	flash_write_data[70] = FloatToUInt32(analog1_point_ph[0]);
	flash_write_data[71] = FloatToUInt32(analog1_point_ph[1]);
	flash_write_data[72] = FloatToUInt32(analog2_point_ph[0]);
	flash_write_data[73] = FloatToUInt32(analog2_point_ph[1]);
	flash_write_data[74] = FloatToUInt32(analog1_point_orp[0]);
	flash_write_data[75] = FloatToUInt32(analog1_point_orp[1]);
	flash_write_data[76] = FloatToUInt32(analog2_point_orp[0]);
	flash_write_data[77] = FloatToUInt32(analog2_point_orp[1]);
	flash_write_data[78] = FloatToUInt32(analog1_point_temp[0]);
	flash_write_data[79] = FloatToUInt32(analog1_point_temp[1]);
	flash_write_data[80] = FloatToUInt32(analog2_point_temp[0]);
	flash_write_data[81] = FloatToUInt32(analog2_point_temp[1]);

	u8arr[0] = calib_year;
	u8arr[1] = calib_month;
	u8arr[2] = calib_day;
	u8arr[3] = calib_hour;	
	flash_write_data[82] = UInt8ArrToUInt32(u8arr, 0);

	u8arr[0] = calib_minute;
	u8arr[1] = calib_sec;
	u8arr[2] = calib_mode;
	u8arr[3] = calib_point_number;
	flash_write_data[83] = UInt8ArrToUInt32(u8arr, 0);

	flash_write_data[84] = FloatToUInt32(calib_buffer1);
	flash_write_data[85] = FloatToUInt32(calib_buffer2);
	flash_write_data[86] = FloatToUInt32(calib_buffer3);
	flash_write_data[87] = FloatToUInt32(calib_temperature);

	u8arr[0] = calib_orp_year;
	u8arr[1] = calib_orp_month;
	u8arr[2] = calib_orp_day;
	u8arr[3] = calib_orp_hour;
	flash_write_data[88] = UInt8ArrToUInt32(u8arr, 0);

	u8arr[0] = calib_orp_minute;
	u8arr[1] = calib_orp_sec;
	u8arr[2] = 0;
	u8arr[3] = 0;
	flash_write_data[89] = UInt8ArrToUInt32(u8arr, 0);

	flash_write_data[90] = FloatToUInt32(calib_orp_buffer);
	flash_write_data[91] = FloatToUInt32(pH_calib_offset);

	flash_write_data[92] = orp_calib_point_num_save;
	j = 0;
	for(i = 93; i < 93 + 22; i+=2)
	{
		flash_write_data[i] = FloatToUInt32(orp_calib_ref_val_save[j]); 
		flash_write_data[i+1] = FloatToUInt32(orp_calib_measure_val_save[j]);
		j++;
	}

	flash_write_data[116] = temp_calib_point_num_save;
	j = 0;
	for(i = 117; i < 117 + 22; i+=2)
	{
		flash_write_data[i] = FloatToUInt32(temp_calib_ref_val_save[j]); 
		flash_write_data[i+1] = FloatToUInt32(temp_calib_measure_val_save[j]);
		j++;
	}

	flash_write_data[143] = FloatToUInt32(mV2ph_coeff[0]);	//at 20211214
	flash_write_data[144] = FloatToUInt32(mV2ph_coeff[1]);
	flash_write_data[145] = FloatToUInt32(mV2ph_coeff[2]);

	WriteFlash_Data(FLASH_DATA_SIZE, BANK1_WRITE_START_ADDR, flash_write_data); 
	/*	for(i = 0; i < 140; i ++)
	{		
		UInt32ToUInt8Arr(flash_write_data[i], u8arr);
		AT24CXX_Write(i * 4, u8arr, 4);
	}  */

}

void GetParams(void)
{
	uint32_t flash_read_data[FLASH_DATA_SIZE];
	float point_0_4;
	int i, j;
	uint8_t u8arr[4];

	ReadFlash_Data(FLASH_DATA_SIZE, BANK1_WRITE_START_ADDR, flash_read_data);
	/*	for(i = 0; i < 140; i ++)
	{
		AT24CXX_Read(i * 4, u8arr, 4);
		flash_read_data[i] = UInt8ArrToUInt32(u8arr, 0);
	} */

	if((flash_read_data[1]!=0xffffffff) && (flash_read_data[1]!=0))
	{

		/*************** flash_write_data[0] *****************************************
13 						12 							11 							10							9 										8 							7 								6 
mode_pH_ORP		mode_ATC_MTC		temper_1000_100	analog1_off_on	analog1_classify			analog2_off_on	analog2_classify	timer_off_on
5							4								3					 			2				 				1				 							0 							
relay1_off_on	relay1_classify	relay2_off_on		relay2_classify analog1_type	analog2_type
		 ************************************************************************/
		//mode_pH_ORP = (uint8)((flash_read_data[0]>>13) & 0x01);
		mode_ATC_MTC = (uint8)((flash_read_data[0]>>14) & 0x01);
		if(mode_ATC_MTC > 1)
			mode_ATC_MTC = 0;
		temper_1000_100 = (uint8)((flash_read_data[0]>>13) & 0x01);
		temper_1000_100 = 0;
		analog1_off_on = (uint8)((flash_read_data[0]>>12) & 0x01);
		analog1_classify = (uint8)((flash_read_data[0]>>11) & 0x01);
		analog2_off_on = (uint8)((flash_read_data[0]>>10) & 0x01);
		analog2_classify = (uint8)((flash_read_data[0]>>9) & 0x01);
		timer_off_on = (uint8)((flash_read_data[0]>>8) & 0x01);
		relay1_off_on = (uint8)((flash_read_data[0]>>7) & 0x01);
		relay1_classify = (uint8)((flash_read_data[0]>>6) & 0x01);
		relay2_off_on = (uint8)((flash_read_data[0]>>5) & 0x01);
		relay2_classify = (uint8)((flash_read_data[0]>>4) & 0x01);

		analogIn1_off_on = (uint8)((flash_read_data[0]>>3) & 0x01);
		analogIn1_classify = (uint8)((flash_read_data[0]>>2) & 0x01);
		analogIn2_off_on = (uint8)((flash_read_data[0]>>1) & 0x01);
		analogIn2_classify = (uint8)(flash_read_data[0] & 0x01);

		calib_pH_slope[1] = UInt32ToFloat(flash_read_data[1]);
		calib_pH_slope[0] = UInt32ToFloat(flash_read_data[2]);
		calib_pH_offset[1] = UInt32ToFloat(flash_read_data[3]);
		calib_pH_offset[0] = UInt32ToFloat(flash_read_data[4]); 

		factory_ORP_slope[1] = UInt32ToFloat(flash_read_data[5]);
		factory_ORP_slope[0] = UInt32ToFloat(flash_read_data[6]);
		factory_ORP_offset[1] = UInt32ToFloat(flash_read_data[7]);
		factory_ORP_offset[0] = UInt32ToFloat(flash_read_data[8]);
		factory_temper_coeff[1] = UInt32ToFloat(flash_read_data[9]);
		factory_temper_coeff[0] = UInt32ToFloat(flash_read_data[10]);

		/////////////////////////////////////////////////////
		calib_Ain_offset[0] = UInt32ToFloat(flash_read_data[11]);
		calib_Ain_offset[1] = UInt32ToFloat(flash_read_data[12]);

		//at 20210922
		relay1_point_ph_low[1] = UInt32ToFloat(flash_read_data[13]);
		relay1_point_ph_low[0] = UInt32ToFloat(flash_read_data[14]);
		relay2_point_ph_low[1] = UInt32ToFloat(flash_read_data[15]);
		relay2_point_ph_low[0] = UInt32ToFloat(flash_read_data[16]);
		relay1_point_orp_low[1] = UInt32ToFloat(flash_read_data[17]);
		relay1_point_orp_low[0] = UInt32ToFloat(flash_read_data[18]);
		relay2_point_orp_low[1] = UInt32ToFloat(flash_read_data[19]);
		relay2_point_orp_low[0] = UInt32ToFloat(flash_read_data[20]);

		relay1_point_ph_hi[1] = UInt32ToFloat(flash_read_data[21]);
		relay1_point_ph_hi[0] = UInt32ToFloat(flash_read_data[22]);
		relay2_point_ph_hi[1] = UInt32ToFloat(flash_read_data[23]);
		relay2_point_ph_hi[0] = UInt32ToFloat(flash_read_data[24]);
		relay1_point_orp_hi[1] = UInt32ToFloat(flash_read_data[25]);
		relay1_point_orp_hi[0] = UInt32ToFloat(flash_read_data[26]);
		relay2_point_orp_hi[1] = UInt32ToFloat(flash_read_data[27]);
		relay2_point_orp_hi[0] = UInt32ToFloat(flash_read_data[28]);

		timer_point[1] = UInt32ToFloat(flash_read_data[29]);
		timer_point[0] = UInt32ToFloat(flash_read_data[30]);

		factory_analog_slope[1] = UInt32ToFloat(flash_read_data[31]);
		factory_analog_slope[0] = UInt32ToFloat(flash_read_data[32]);
		factory_analog_offset[1] = UInt32ToFloat(flash_read_data[33]);
		factory_analog_offset[0] = UInt32ToFloat(flash_read_data[34]);

		//RS485_baudrate = flash_read_data[30];
		temper_manual = UInt32ToFloat(flash_read_data[35]);

		mode_pH_ORP = (uint8_t)(flash_read_data[36]>>24) & 0xff;	//mode_pH_ORP
		signal_src = (uint8_t)(flash_read_data[36]>>16) & 0xff;
		dev_address = (uint32_t)((flash_read_data[36]>>8) & 0xff);		
		sensor_addr = (uint32_t)(flash_read_data[36] & 0xff);			

		analog1_type = (uint8_t)(flash_read_data[37]>>24) & 0xff;	
		analog2_type = (uint8_t)(flash_read_data[37]>>16) & 0xff;	
		analogIn1_type = (uint8_t)(flash_read_data[37]>>8) & 0xff;
		analogIn2_type = (uint8_t)(flash_read_data[37] & 0xff);	

		if(analog1_type > 5)
			analog1_type = 0;
		if(analog2_type > 5)
			analog2_type = 5;
		if(analogIn1_type > 5)
			analogIn1_type = 0;
		if(analogIn2_type > 5)
			analogIn2_type = 5;

		relay1_type = (uint8_t)(flash_read_data[38]>>8) & 0xff;
		relay2_type = (uint8_t)(flash_read_data[38] & 0xff);	

		if(relay1_classify==0)
		{
			if(analogIn1_type==0)
			{
				relay1_point[1] = relay1_point_ph_low[1];
				relay1_point[0] = relay1_point_ph_low[0];
			}
			else
			{
				relay1_point[1] = relay1_point_orp_low[1];
				relay1_point[0] = relay1_point_orp_low[0];
			}
		}
		else
		{
			if(analogIn1_type==0)
			{
				relay1_point[1] = relay1_point_ph_hi[1];
				relay1_point[0] = relay1_point_ph_hi[0];
			}
			else
			{
				relay1_point[1] = relay1_point_orp_hi[1];
				relay1_point[0] = relay1_point_orp_hi[0];
			}
		}

		if(relay2_classify==0)
		{
			if(analogIn1_type==0)
			{
				relay2_point[1] = relay2_point_ph_low[1];
				relay2_point[0] = relay2_point_ph_low[0];
			}
			else
			{
				relay2_point[1] = relay2_point_orp_low[1];
				relay2_point[0] = relay2_point_orp_low[0];
			}
		}
		else
		{
			if(analogIn1_type==0)	
			{
				relay2_point[1] = relay2_point_ph_hi[1];
				relay2_point[0] = relay2_point_ph_hi[0];
			}
			else
			{
				relay2_point[1] = relay2_point_orp_hi[1];
				relay2_point[0] = relay2_point_orp_hi[0];
			}
		}

		factory_analogIn_slope[1] = UInt32ToFloat(flash_read_data[41]);
		factory_analogIn_slope[0] = UInt32ToFloat(flash_read_data[42]);
		factory_analogIn_offset[1] = UInt32ToFloat(flash_read_data[43]);
		factory_analogIn_offset[0] = UInt32ToFloat(flash_read_data[44]);
		RS485_In_baud = flash_read_data[45];		

		///schn added 2018/08/12, kjh repaired 20181104
		j = 0;
		for(i = 0x39; i < 0x51; i+=2)
		{
			j++;
			PetitRegisters[i].ActValue = (uint16_t)(flash_read_data[45 + j] >> 16);	//&0xffff
			PetitRegisters[i + 1].ActValue = (uint16_t)flash_read_data[45 + j];
		}
		j = 0; //at 20210806
		for(i = MODBUS_FW_VERSION; i < MODBUS_FW_VERSION+4; i+=2)
		{
			j++;
			PetitRegisters[i].ActValue = (uint16_t)(flash_read_data[140 + j] >> 16);	//&0xffff
			PetitRegisters[i + 1].ActValue = (uint16_t)flash_read_data[140 + j];
		}

		//added by schn 2018-10-31
		analog1_point_ph[0] = UInt32ToFloat(flash_read_data[70]);
		analog1_point_ph[1] = UInt32ToFloat(flash_read_data[71]);
		analog2_point_ph[0] = UInt32ToFloat(flash_read_data[72]);
		analog2_point_ph[1] = UInt32ToFloat(flash_read_data[73]);

		analog1_point_orp[0] = UInt32ToFloat(flash_read_data[74]);
		analog1_point_orp[1] = UInt32ToFloat(flash_read_data[75]);
		analog2_point_orp[0] = UInt32ToFloat(flash_read_data[76]);
		analog2_point_orp[1] = UInt32ToFloat(flash_read_data[77]);

		analog1_point_temp[0] = UInt32ToFloat(flash_read_data[78]);
		analog1_point_temp[1] = UInt32ToFloat(flash_read_data[79]);
		analog2_point_temp[0] = UInt32ToFloat(flash_read_data[80]);
		analog2_point_temp[1] = UInt32ToFloat(flash_read_data[81]);

		if(analog1_type == 0)
		{
			analog1_point[0] = analog1_point_ph[0];
			analog1_point[1] = analog1_point_ph[1];
		}
		else if(analog1_type == 1)
		{
			analog1_point[0] = analog1_point_orp[0];
			analog1_point[1] = analog1_point_orp[1];
		}
		else if(analog1_type == 5)
		{
			analog1_point[0] = analog1_point_temp[0];
			analog1_point[1] = analog1_point_temp[1];
		}

		if(analog2_type == 0)
		{
			analog2_point[0] = analog2_point_ph[0];
			analog2_point[1] = analog2_point_ph[1];
		}
		else if(analog2_type == 1)
		{
			analog2_point[0] = analog2_point_orp[0];
			analog2_point[1] = analog2_point_orp[1];
		}
		else if(analog2_type == 5)
		{
			analog2_point[0] = analog2_point_temp[0];
			analog2_point[1] = analog2_point_temp[1];
		}

		//------------- Calulate the analog out coeffs -----------------------------//
		if(analog1_classify==ANALOG1_0_20)
			point_0_4 = 0.0f;
		else if(analog1_classify==ANALOG1_4_20)
			point_0_4 = 4.0f;
		ACQ2analog_slope[0] = (20.0f-point_0_4)/(analog1_point[1]-analog1_point[0]); 
		ACQ2analog_offset[0] = 20.0f - analog1_point[1]*ACQ2analog_slope[0];
		if(analog2_classify==ANALOG2_0_20)
			point_0_4 = 0.0f;
		else if(analog2_classify==ANALOG2_4_20)
			point_0_4 = 4.0f;
		ACQ2analog_slope[1] = (20.0f-point_0_4)/(analog2_point[1]-analog2_point[0]); 
		ACQ2analog_offset[1] = 20.0f - analog2_point[1]*ACQ2analog_slope[1];
		//------------- Calulate the analog Input coeffs -----------------------------//
		if(analogIn1_classify==0)
			point_0_4 = 0.0f;
		else if(analogIn1_classify==1)
			point_0_4 = 4.0f;
		AIN2Val_slope[0] = (analogIn1_point[1]-analogIn1_point[0])/(20.0f-point_0_4); 
		AIN2Val_offset[0] = analogIn1_point[1] - 20.0f*AIN2Val_slope[0];	
		if(analogIn2_classify==0)
			point_0_4 = 0.0f;
		else if(analogIn2_classify==1)
			point_0_4 = 4.0f;
		AIN2Val_slope[1] = (analogIn2_point[1]-analogIn2_point[0])/(20.0f-point_0_4); 
		AIN2Val_offset[1] = analogIn2_point[1] - 20.0f*AIN2Val_slope[1];	

		UInt32ToUInt8Arr(flash_read_data[82], u8arr);
		calib_year = u8arr[0];
		calib_month = u8arr[1];
		calib_day = u8arr[2];
		calib_hour = u8arr[3];

		UInt32ToUInt8Arr(flash_read_data[83], u8arr);
		calib_minute = u8arr[0];
		calib_sec = u8arr[1];
		calib_mode = u8arr[2];
		calib_point_number = u8arr[3];

		calib_buffer1 = UInt32ToFloat(flash_read_data[84]);
		calib_buffer2 = UInt32ToFloat(flash_read_data[85]);
		calib_buffer3 = UInt32ToFloat(flash_read_data[86]);
		calib_temperature = UInt32ToFloat(flash_read_data[87]);

		if(calib_point_number < 1 || calib_point_number > 3)
			calib_point_number = 1;
		if(calib_mode > 2)
			calib_mode = 0;

		UInt32ToUInt8Arr(flash_read_data[88], u8arr);
		calib_orp_year = u8arr[0];
		calib_orp_month = u8arr[1];
		calib_orp_day = u8arr[2];
		calib_orp_hour = u8arr[3];

		UInt32ToUInt8Arr(flash_read_data[89], u8arr);		
		calib_orp_minute = u8arr[0];
		calib_orp_sec = u8arr[1];

		calib_orp_buffer = UInt32ToFloat(flash_read_data[90]);
		pH_calib_offset = UInt32ToFloat(flash_read_data[91]);
	}

	orp_calib_point_num_save = flash_read_data[92];

	if(orp_calib_point_num_save < 2 || orp_calib_point_num_save > 11)
	{
		orp_calib_point_num_save = 3;
		orp_calib_ref_val_save[0] = 177;
		orp_calib_ref_val_save[1] = 0;
		orp_calib_ref_val_save[2] = -177;
		orp_calib_measure_val_save[0] = 177;
		orp_calib_measure_val_save[1] = 0;
		orp_calib_measure_val_save[2] = -177;
	}
	else
	{
		int isValid = 0;
		j = 0;
		for(i = 93; i < 93 + 22; i+=2)
		{
			orp_calib_ref_val_save[j] = UInt32ToFloat(flash_read_data[i]); 
			orp_calib_measure_val_save[j] = UInt32ToFloat(flash_read_data[i+1]);
			j++;
		}

		for(i = 0; i < orp_calib_point_num - 1; i++)
		{
			if(orp_calib_ref_val_save[i + 1] - orp_calib_ref_val_save[i] == 0)
			{
				isValid = 1;
				break;
			}	
		}

		if(isValid == 1)
		{
			orp_calib_point_num_save = 3;
			orp_calib_ref_val_save[0] = 177;
			orp_calib_ref_val_save[1] = 0;
			orp_calib_ref_val_save[2] = -177;
			orp_calib_measure_val_save[0] = 177;
			orp_calib_measure_val_save[1] = 0;
			orp_calib_measure_val_save[2] = -177;
		}
	}

	temp_calib_point_num_save = flash_read_data[116];

	if(temp_calib_point_num_save < 2 || temp_calib_point_num_save > 11)
	{
		temp_calib_point_num_save = 3;
		temp_calib_ref_val_save[0] = 177;
		temp_calib_ref_val_save[1] = 0;
		temp_calib_ref_val_save[2] = -177;
		temp_calib_measure_val_save[0] = 177;
		temp_calib_measure_val_save[1] = 0;
		temp_calib_measure_val_save[2] = -177;
	}
	else
	{
		int isValid = 0;
		j = 0;
		for(i = 117; i < 117 + 22; i+=2)
		{
			temp_calib_ref_val_save[j] = UInt32ToFloat(flash_read_data[i]); 
			temp_calib_measure_val_save[j] = UInt32ToFloat(flash_read_data[i+1]);
			j++;
		}

		for(i = 0; i < temp_calib_point_num - 1; i++)
		{
			if(temp_calib_ref_val_save[i + 1] - temp_calib_ref_val_save[i] == 0)
			{
				isValid = 1;
				break;
			}	
		}

		if(isValid == 1)
		{
			temp_calib_point_num_save = 3;
			temp_calib_ref_val_save[0] = 177;
			temp_calib_ref_val_save[1] = 0;
			temp_calib_ref_val_save[2] = -177;
			temp_calib_measure_val_save[0] = 177;
			temp_calib_measure_val_save[1] = 0;
			temp_calib_measure_val_save[2] = -177;
		}
	}

	mV2ph_coeff[0] = UInt32ToFloat(flash_read_data[143]); //at 20211214
	mV2ph_coeff[1] = UInt32ToFloat(flash_read_data[144]);
	mV2ph_coeff[2] = UInt32ToFloat(flash_read_data[145]);
}

/*! 
 *  \brief  ��Ϣ��������
 *  \param msg ��������Ϣ
 *  \param size ��Ϣ����
 */
void ProcessMessage( PCTRL_MSG msg, uint16 size )
{
	uint8 cmd_type = msg->cmd_type;//ָ������
	uint8 ctrl_msg = msg->ctrl_msg;   //��Ϣ������
	uint8 control_type = msg->control_type;//�ؼ�����
	uint16 screen_id = PTR2U16(&msg->screen_id);//����ID
	uint16 control_id = PTR2U16(&msg->control_id);//�ؼ�ID
	uint32 value = PTR2U32(msg->param);//��ֵ

	switch(cmd_type)
	{		
	case NOTIFY_LCD_RESET: //at 20210205
		//		NVIC_SystemReset();
		break;
	case NOTIFY_TOUCH_PRESS://����������
	case NOTIFY_TOUCH_RELEASE://�������ɿ�
		NotifyTouchXY(cmd_buffer[1],PTR2U16(cmd_buffer+2),PTR2U16(cmd_buffer+4));
		break;	
	case NOTIFY_WRITE_FLASH_OK://дFLASH�ɹ�
		NotifyWriteFlash(1);
		break;
	case NOTIFY_WRITE_FLASH_FAILD://дFLASHʧ��
		NotifyWriteFlash(0);
		break;
	case NOTIFY_READ_FLASH_OK://��ȡFLASH�ɹ�
		NotifyReadFlash(1,cmd_buffer+2,size-6);//ȥ��֡ͷ֡β
		break;
	case NOTIFY_READ_FLASH_FAILD://��ȡFLASHʧ��
		NotifyReadFlash(0,0,0);
		break;
	case NOTIFY_READ_RTC://��ȡRTCʱ��
		NotifyReadRTC(cmd_buffer[2],cmd_buffer[3],cmd_buffer[4],cmd_buffer[5],cmd_buffer[6],cmd_buffer[7],cmd_buffer[8]);
		break;
	case NOTIFY_CONTROL:
	{
		if(ctrl_msg==MSG_GET_CURRENT_SCREEN)//����ID�仯֪ͨ
		{
			NotifyScreen(screen_id);
		}
		else
		{
			switch(control_type)
			{
			case kCtrlButton: //��ť�ؼ�
				NotifyButton(screen_id,control_id,msg->param[1]);
				break;
			case kCtrlText://�ı��ؼ�
				NotifyText(screen_id,control_id,msg->param);
				break;
			case kCtrlProgress: //�������ؼ�
				NotifyProgress(screen_id,control_id,value);
				break;
			case kCtrlSlider: //�������ؼ�
				NotifySlider(screen_id,control_id,value);
				break;
			case kCtrlMeter: //�Ǳ��ؼ�
				NotifyMeter(screen_id,control_id,value);
				break;
			case kCtrlMenu://�˵��ؼ�
				NotifyMenu(screen_id,control_id,msg->param[0],msg->param[1]);
				break;
			case kCtrlSelector://ѡ��ؼ�
				NotifySelector(screen_id,control_id,msg->param[0]);
				break;
			case kCtrlRTC://����ʱ�ؼ�
				NotifyTimer(screen_id,control_id);
				break;
			default:
				break;
			}
		}
	}
	break;
	default:
		break;
	}
}

/*! 
 *  \brief  �����л�֪ͨ
 *  \details  ��ǰ����ı�ʱ(�����GetScreen)��ִ�д˺���
 *  \param screen_id ��ǰ����ID
 */
void NotifyScreen(uint16 screen_id)
{
	//TODO: �����û�����
	current_screen_id = screen_id;//�ڹ��������п��������л�֪ͨ����¼��ǰ����ID

	/*	if(current_screen_id==4)//�¶�����
	{
		uint16 i = 0;
		uint8 dat[100] = {0};

		//���ɷ���
		for (i=0;i<100;++i)
		{
			if((i%20)>=10)
				dat[i] = 200;
			else
				dat[i] = 20;
		}
		GraphChannelDataAdd(4,1,0,dat,100);//�������ݵ�ͨ��0

		//���ɾ�ݲ�
		for (i=0;i<100;++i)
		{
			dat[i] = 16*(i%15);
		}
		GraphChannelDataAdd(4,1,1,dat,100);//�������ݵ�ͨ��1
	}
	else if(current_screen_id==9)//��ά��
	{
		//��ά��ؼ���ʾ�����ַ�ʱ����Ҫת��ΪUTF8���룬
		//ͨ����ָ�����֡���ת�������ݴ��123�� ���õ��ַ�����������
		char dat[] = {0xE5,0xB9,0xBF,0xE5,0xB7,0x9E,0xE5,0xA4,0xA7,0xE5,0xBD,0xA9,0x31,0x32,0x33};
		SetTextValue(9,1,dat);
	} */
}

/*! 
 *  \brief  ���������¼���Ӧ
 *  \param press 1���´�������3�ɿ�������
 *  \param x x����
 *  \param y y����
 */
void NotifyTouchXY(uint8 press,uint16 x,uint16 y)
{
	//TODO: �����û�����
}

void SetTextValueInt32(uint16 screen_id, uint16 control_id,int32 value)
{
	char buffer[12] = {0};
	sprintf(buffer,"%ld",value); //������ת��Ϊ�ַ���
	SetTextValue(screen_id,control_id,buffer);
}

void SetTextValueFloat(uint16 screen_id, uint16 control_id,float value)
{
	char buffer[8] = {0};
	sprintf(buffer,"%.1f",value);//�Ѹ�����ת��Ϊ�ַ���(����һλС��)
	SetTextValue(screen_id,control_id,buffer);
}

void SetTextValueFloat2(uint16 screen_id, uint16 control_id,float value)
{
	char buffer[8] = {0};
	sprintf(buffer,"%.2f",value);//�Ѹ�����ת��Ϊ�ַ���(����һλС��)
	SetTextValue(screen_id,control_id,buffer);
}

///////////////////////////////////////////////
void HMI_Init(void)
{
	uint16_t i;

	/** SN_num[] = "17200002", fname[]="0:/00022915.TXT" **/
	for(i=0; i<2; i++)
	{
		fname[3+i] = SN_num[6+i];
		fname_r[3+i] = SN_num[6+i];
	}
	SetTextValue(0,5,signal_unit[analogIn1_type]);	delay_ms(1);	
	//AnimationPlayFrame(0,5,analogIn1_type);	delay_ms(1);	
	SetTextValue(0,14,signal_type[analogIn1_type]);	delay_ms(1);
	//AnimationPlayFrame(0,14,analogIn1_type);	delay_ms(1);
	SetTextValue(0,6,temper_mode[mode_ATC_MTC]);	delay_ms(1);	
	//AnimationPlayFrame(0,6,mode_ATC_MTC);	delay_ms(1);

	//0:Normal, 1:Alarm, 2: Inactive
	if(relay1_off_on==0)	//RELAY1
		AnimationPlayFrame(0,8,2);
	else if(relay1_off_on==1)
		AnimationPlayFrame(0,8,0);
	delay_ms(1);
	if(relay2_off_on==0)	//RELAY2
		AnimationPlayFrame(0,9,2);
	else if(relay2_off_on==1)
		AnimationPlayFrame(0,9,0);
	delay_ms(1);
	if(timer_off_on==0)		//WASH timer
		AnimationPlayFrame(0,10,2);
	else if(timer_off_on==1)
		AnimationPlayFrame(0,10,0);
	delay_ms(2);

	//Initialize pHORP & temper display
	/*	if(mode_pH_ORP == MEASURE_MODE_PH)
		SetTextValueFloat2(0,4,pH_calc_value);
	else if(mode_ATC_MTC == MEASURE_MODE_MTC)
		SetTextValueFloat(0,4,ORP_calc_value);
	delay_ms(10); 
	SetTextValueFloat(0,7,25.0f);	delay_ms(10);*/

	/********** Enter to WASH ************************/
	SetTextValueFloat(13,5,timer_point[1]);	delay_ms(1);	//running period
	SetTextValueFloat(13,6,timer_point[0]);	delay_ms(1);	//pause

	/********** Enter the device information **********************/
	SetTextValue(62,2,HW_version);	delay_ms(1);
	SetTextValue(62,3,FW_version);	delay_ms(1);
	SetTextValue(62,4,SN_num);	delay_ms(1);
	SetTextValue(62,5,Factory_num);	delay_ms(1);
	SetTextValue(62,6,Product_num);	delay_ms(1);

	/*********** Calibration Information *************/
	SetTextValueInt32(127,2,calib_point_number);
	SetTextValue(127,11,calib_mode_str[calib_mode]);
	if(calib_point_number == 1)
		sprintf(buffer_str, "%.2f", calib_buffer1);
	else if(calib_point_number == 2)
		sprintf(buffer_str, "%.2f, %.2f", calib_buffer1, calib_buffer2);
	else
		sprintf(buffer_str, "%.2f, %.2f, %.2f", calib_buffer1, calib_buffer2, calib_buffer3);
	SetTextValue(127,3,buffer_str);
	DispLastCalibTime(127,4);
	SetTextValueFloat2(127,5,7.0f * calib_pH_slope[0]+ calib_pH_offset[0]);

	SetTextValueFloat2(127,6, mV2ph_coeff[1]); //acid, at 20211214
	SetTextValueFloat(127,13, 100*mV2ph_coeff[1]/mV2ph_coeff[0]); 
	SetTextValueFloat2(127,8, mV2ph_coeff[2]); //alkari
	SetTextValueFloat(127,16, 100*mV2ph_coeff[2]/mV2ph_coeff[0]);

	SetTextValueFloat(127,18, calib_temperature);

	sprintf(buffer_str,"%.1f mV",calib_orp_buffer);
	SetTextValue(128,2,buffer_str);
	SetTextValueFloat(128,3,calib_Ain_offset[0]);
	DispLastCalibORPTime(128,4);

	SetScreen(73);
	SetAutoBacklight(1,250,50,10);
	ReadRtc();
	//SetBacklight(255);
}

void RelayControl(void)
{
	float temp_float;

	if(delay_flag || custom_calib_state)
	{
		//0:Normal, 1:Alarm, 2: Inactive
		AnimationPlayFrame(0,8,2); delay_ms(2); //RELAY1
		AnimationPlayFrame(0,9,2); delay_ms(2); //RELAY2
		AnimationPlayFrame(0,10,2);  //TIMER
		relay1_flag = 0;
		relay2_flag = 0;
		timer_flag = 0;
		Relay1_Disable;
		Relay2_Disable;
		WashTimer_Disable;
	}
	else
	{
		/*********** Relay1 Control ******************/
		if(relay1_off_on==RELAY1_STATE_ON)
		{
			temp_float = real_value1;//Ain_real_value[0];
			if(relay1_classify==RELAY1_LOW)
			{
				if((relay1_flag==0) && (temp_float <= relay1_point[1]))
				{
					AnimationPlayFrame(0,8,1);	//RELAY1 alarm
					relay1_flag = 1;
					Relay1_Enable;  //at 20210719
				}
				else if((relay1_flag==1) && (temp_float > (relay1_point[1]+relay1_point[0])))
				{
					AnimationPlayFrame(0,8,0);	//RELAY1 normal
					relay1_flag = 0;
					Relay1_Disable;  //at 20210719
				}
			}
			else if(relay1_classify==RELAY1_HIGH)
			{
				if((relay1_flag==0) && (temp_float >= relay1_point[1]))
				{
					AnimationPlayFrame(0,8,1);	//RELAY1 alarm
					relay1_flag = 1;
					Relay1_Enable;  //at 20210719
				}
				else if((relay1_flag==1) && (temp_float < (relay1_point[1]-relay1_point[0])))
				{
					AnimationPlayFrame(0,8,0);	//RELAY1 normal
					relay1_flag = 0;
					Relay1_Disable;  //at 20210719
				}
			}
		}	

		/*********** Relay2 Control ******************/
		if(relay2_off_on==RELAY2_STATE_ON)
		{

			temp_float = real_value1;//Ain_real_value[0];

			if(relay2_classify==RELAY2_LOW)
			{
				if((relay2_flag==0) && (temp_float <= relay2_point[1]))
				{
					AnimationPlayFrame(0,9,1);	//RELAY2 alarm
					relay2_flag = 1;
					Relay2_Enable;  //at 20210719
				}
				else if((relay2_flag==1) && (temp_float > (relay2_point[1]+relay2_point[0])))
				{
					AnimationPlayFrame(0,9,0);	//RELAY2 normal
					relay2_flag = 0;
					Relay2_Disable;  //at 20210719
				}
			}
			else if(relay2_classify==RELAY2_HIGH)
			{
				if((relay2_flag==0) && (temp_float >= relay2_point[1]))
				{
					AnimationPlayFrame(0,9,1);	//RELAY2 alarm
					relay2_flag = 1;
					Relay2_Enable;  //at 20210719
				}
				else if((relay2_flag==1) && (temp_float < (relay2_point[1]-relay2_point[0])))
				{
					AnimationPlayFrame(0,9,0);	//RELAY2 normal
					relay2_flag = 0;
					Relay2_Disable;  //at 20210719
				}
			}
		}	//end of if(relay2_off_on==RELAY2_STATE_ON)

		/*********** Wash timer Control ******************/
		if(timer_off_on==TIMER_STATE_ON)
		{
			if(timer_flag==0)
			{
				timer_count ++; 
				if(timer_count==(int)((timer_point[0]*60)))	//pause_period*60*1000/500
				{
					timer_count = 0;						
					AnimationPlayFrame(0,10,1);	 //at 20201016		
					timer_flag = 1;	
					WashTimer_Enable;  //at 20210719
				}				
			}	
			else if(timer_flag==1)
			{
				timer_count ++; 
				if(timer_count==(int)((timer_point[1]*60)))	//run_period*60*1000/500
				{
					timer_count = 0;					
					AnimationPlayFrame(0,10,0);	//at 20201016
					timer_flag = 0;		
					WashTimer_Disable;  //at 20210719
				}				
			}		
		}
	}

	//---------------- relay actions -------------------------//
	delay_ms(10); //(10) 
}

void UpdateTxPHBuf(float fvalue)
{
	unsigned short sbuf[2];
	FloatToShort(fvalue, sbuf);
	PetitRegisters[0x0035].ActValue = sbuf[0];
	PetitRegisters[0x0036].ActValue = sbuf[1];
}

void UpdateTxTemperatureBuf(float fvalue)
{
	unsigned short sbuf[2];
	FloatToShort(fvalue, sbuf);
	PetitRegisters[0x0037].ActValue = sbuf[0];
	PetitRegisters[0x0038].ActValue = sbuf[1];
}


float calc_real_temperature(float org_temp)
{
	int idx;
	float result;
	/*float calib_x[21] = {-55.5246f, -43.9488f, -32.5692f, -21.582f, -10.5948f, 0.0f, 10.5948f, 
	 	   			   	 20.9934f, 31.1958f, 41.3001f, 51.1101f, 60.9201f, 70.4358f, 79.8534f, 
						 89.1729f, 99.7f, 107.3214f, 116.1504f, 124.8813f, 133.5141f, 142.0488f};*/
	/*float calib_y[21] = {-50.0f, -40.0f, -30.0f, -20.0f, -10.0f, 0.0f, 10.0f, 20.0f, 30.0f, 40.0f, 
	 	   			   	 50.0f, 60.0f, 70.0f, 80.0f, 90.0f, 100.0f, 110.0f, 120.0f, 130.0f, 140.0f, 150.0f};*/
	float calib_x[21] = {-48.3f, -30.7f, -20.5f, -10.3f, 0.2f, 10.3f, 20.1f, 25.2f, 30.2f, 40.3f, 
			50.2f, 60.2f, 70.2f, 80.1f, 90.3f, 102.8f, 109.7f, 119.5f, 129.2f, 139.0f, 148.7f};
	float calib_y[21] = {-47.2f, -30.0f, -20.0f, -10.0f, 0.3f, 10.3f, 20.0f, 25.0f, 30.0f, 40.0f, 50.0f, 
			60.0f, 70.0f, 80.0f, 90.3f, 103.0f, 110.0f, 120.0f, 130.0f, 140.0f, 150.0f};
	if(org_temp < calib_x[0])
	{
		result = calib_y[0] + (calib_y[1] - calib_y[0]) * (org_temp - calib_x[0])/(calib_x[1] - calib_x[0]);
		return result;
	}
	if(org_temp > calib_x[20])
	{
		result = calib_y[19] + (calib_y[20] - calib_y[19]) * (org_temp - calib_x[19])/(calib_x[20] - calib_x[19]);
		return result;
	}
	for(idx = 0; idx < 20; idx++)
	{
		if(org_temp >= calib_x[idx] && org_temp < calib_x[idx + 1])
		{
			result = calib_y[idx] + (calib_y[idx + 1] - calib_y[idx]) * (org_temp - calib_x[idx]) / (calib_x[idx + 1] - calib_x[idx]);
			break;
		}
	}
	return result;
}

void UpdateUI()		//1000ms cycles
{
	float temp_float;
	uint16_t i;
	//	uint16_t error_cnt = 0;
	uint8_t measure_comp_flag = 0;
	uint8_t measure_comp_flag_temper = 0;

	if(current_screen_id==0)	//main window
	{
		if(analog_calib_flag)	//added by kjh at 20200226
		{
			calib_return_timeout ++;
			if(calib_return_timeout >= 60) //20  //at 20210209
			{
				calib_return_timeout = 0;
				analog_calib_flag = 0;
			}
		}
	}

	if(!analog_calib_flag)	//added at 20200408
	{		
		RelayControl();

		if(analogIn1_type==0)
		{
			Ain_real_value[0] = pH_calc_value;

			if(Ain_real_value[0] >= 20)	//16
			{
				Ain_real_value[0] = 20;
				//			bmesure_overflow[0] = 1;
			}
			else if(Ain_real_value[0] <= -10) //-2
			{
				Ain_real_value[0] = -10;
				//			bmesure_overflow[0] = 1;
			}

			if(!custom_calib_state)
			{
				if(!delay_flag) //&& !analog_calib_flag)
				{
					UpdateTxPHBuf(Ain_real_value[0]);
				}
				else
				{
					delay_count++;
					if(delay_count > delay_max)
					{
						delay_flag = 0;
						delay_count = 0;
					}
				}
			} //end of if(!custom_calib_state)

		}
		else if(analogIn1_type==1)
		{
			Ain_real_value[0] = ORP_calc_value + calib_Ain_offset[0];

			if(Ain_real_value[0] >= 2000)
			{
				Ain_real_value[0] = 2000;
				//			bmesure_overflow[1] = 1;
			}
			else if(Ain_real_value[0] <= -2000)
			{
				Ain_real_value[0] = -2000;
				//			bmesure_overflow[1] = 1;
			}

			if(!custom_calib_state)
			{
				if(!delay_flag) //&& !analog_calib_flag)
				{
					UpdateTxPHBuf(Ain_real_value[0]);
				}
				else
				{
					delay_count++;
					if(delay_count > delay_max)
					{
						delay_flag = 0;
						delay_count = 0;
					}
				}
			} //end of if(!custom_calib_state)
		}

		Ain_real_value[1] = temper_calc_value;
		/*		//--repaired by kjh at 20191021
			if(mode_ATC_MTC==MEASURE_MODE_MTC)
				Ain_real_value[1] = temper_manual;
			else
			{
				Ain_real_value[1] = temper_calc_value;  // û���¶�����
			}
			if(Ain_real_value[1] > 150)
				Ain_real_value[1] = 150;
			if(Ain_real_value[1] < -50)
				Ain_real_value[1] = -50;				*/

		if(!custom_calib_state)
		{
			if(!delay_flag) //&& !analog_calib_flag)
			{
				UpdateTxTemperatureBuf(Ain_real_value[1]);
			}
			else
			{
				delay_count++;
				if(delay_count > delay_max)
				{
					delay_flag = 0;
					delay_count = 0;
				}
			}
		}	//end of if(!custom_calib_state)

		////////////////////////////////////////////
		switch(analogIn1_type)
		{
		case 0:
		case 2:
			SetTextValueFloat2(0,4,Ain_real_value[0]);	break;

		case 1:
		case 3:
		case 5:
			SetTextValueFloat(0,4,Ain_real_value[0]);	break;
		case 4:
			SetTextValueInt32(0,4,(int32_t)Ain_real_value[0]);	break;
		default:
			break;
		}

		//Ain_real_value[1] = calc_real_temperature(temper_calc_value);  // �¶��������
		//		if(mode_ATC_MTC==MEASURE_MODE_MTC)  //repaird at 20200327
		//			SetTextValueFloat(0,7,temper_manual);
		//		else if(mode_ATC_MTC==MEASURE_MODE_ATC)
		switch(analogIn2_type)
		{
		case 0:
		case 2:
			SetTextValueFloat2(0,7,Ain_real_value[1]);	break;
		case 1:
		case 3:
		case 5:
			SetTextValueFloat(0,7,Ain_real_value[1]);	break;
		case 4:
			SetTextValueInt32(0,7,(int32_t)Ain_real_value[1]);	break;
		default:
			break;
		}

		if(!custom_calib_state)
		{
			if(!delay_flag)
			{
				real_value1 = Ain_real_value[0];
				real_value2 = Ain_real_value[1];
			}
			else
			{
				delay_count++;
				if(delay_count > delay_max)
				{
					delay_flag = 0;
					delay_count = 0;
				}
			}
		}		//end of if(!custom_calib_state)

	}

	if(current_screen_id==67)	//temper1 measure for calib
	{
		SetTextValueFloat(67,2,temper_calc_value);
		if(calib_measure_flag==1)
		{
			calib_measure_ex[calib_measure_cnt % CALIB_SAMPLES] = temper_calc_value;		//at 20210806 add % CALIB_SAMPLES
			calib_measure_cnt ++;
			if(calib_measure_cnt>=CALIB_SAMPLES)
			{
				//				calib_measure_cnt = 0; 	//at 20210806 commanted all
				//TODO error process
				temp_float = 0;
				for(i=0; i<CALIB_SAMPLES; i++)
					temp_float += calib_measure_ex[i];
				temp_float = (float)(temp_float/CALIB_SAMPLES);

				for(i=0; i<CALIB_SAMPLES; i++)
				{
					if((calib_measure_ex[i]-temp_float>0.5f) || (temp_float-calib_measure_ex[i]>0.5f))
					{
						measure_comp_flag = 0;
						break;
					}
					else
						measure_comp_flag = 1;
				}

				if(measure_comp_flag==0)
				{
					calib_stage_cnt ++;
					if(calib_stage_cnt>=CALIB_TIMEOUT)
					{
						calib_stage_cnt = 0;

						SetTextValue(64,4,"1");
						calib_pH_index = GetpHClass(calib_pH_value[0]);
						if((temp_float<0.0f) || (temp_float>95.0f))	//repaired at 20200707
						{
							calib_measure_flag = 0;
							current_screen_id = 64;
							SetScreen(current_screen_id);		//temper1 overlay error!
						}
						else
						{
							calib_measure_flag = 0;
							SetTextValue(74,4,"1");
							current_screen_id = 74;
							SetScreen(current_screen_id);		//temper1 unstable error!
						}								
						//					  else
						//						{
						//							if((calib_pH_index==1) || (calib_pH_index==4) || (calib_pH_index==5) || (calib_pH_index==7) || (calib_pH_index==8))
						//							{
						//								calib_measure_flag = 0;
						//								current_screen_id = 64;
						//								SetScreen(current_screen_id);		//temper1 overlay error!
						//							}
					}
				}
				else
				{
					calib_measure_flag = 1;
					SetTextFlash(29,1,50);		//500ms				  
					return_screen_id = 28;
					calib_count_down = 300;
					current_screen_id = 29;
					SetScreen(current_screen_id); 		//mV_1 measure window
				}
			}// end of if(calib_measure_cnt > CALIB_SAMPLES)
		}
	}

	else if(current_screen_id==61) //temper calib
	{
		SetTextValueFloat(61, 2, temper_calc_value); //at 20210922
	}
	else if(current_screen_id==119) //ORP calib process-1
	{
		SetTextValueFloat(119, 4, ORP_calc_value); //at 20210922
	}
	else if(current_screen_id==120) //ORP calib process-2
	{
		orp_process_count++;
		if(orp_process_count > 5)
		{
			orp_process_count = 0;
			SetTextValueFloat2(121, 2, calib_Ain_offset[0]);
			calib_orp_year = now_year;
			calib_orp_month = now_month;
			calib_orp_day = now_day;
			calib_orp_hour = now_hour;
			calib_orp_minute = now_minute;
			calib_orp_sec = now_sec;
			calib_orp_buffer = ORP_calc_value;

			sprintf(buffer_str,"%.1f mV",calib_orp_buffer);
			SetTextValue(128,2,buffer_str);
			SetTextValueFloat(128,3,calib_Ain_offset[0]);
			DispLastCalibORPTime(128,4);

			DispCalibTimeIdx(121, 3);
			current_screen_id = 121;
			SetScreen(current_screen_id);
		}
	}

	else if(current_screen_id==107)
	{
		calib_count_up++;
		SetTextValueFloat2(107, 3, ORP_calc_value);
		if(mode_ATC_MTC == 0)
			SetTextValueFloat2(107, 4, temper_calc_value);
		else
			SetTextValueFloat2(107, 4, calib_manual_temperature);
		SetTextValueInt32(107, 5, calib_count_up);
		calib_pH_mV[0] = ORP_calc_value;

		if(calib_count_up > 7)
		{
			if(calib_ph_mode == 0)
			{
				buffer1 = select_nist_standard_ph(ORP_calc_value);
				SetTextValueFloat2(107, 6, buffer1);
			}
			else if(calib_ph_mode == 1)
			{
				buffer1 = select_tech_standard_ph(ORP_calc_value);
				SetTextValueFloat2(107, 6, buffer1);
			}
		}		

		else if(calib_ph_mode == 2)
		{
			SetTextValueFloat2(107, 6, buffer1);
		}

		if(calib_measure_flag == 1)
		{
			float temp_avg = 0.0;

			calib_measure_ex[calib_measure_cnt % CALIB_SAMPLES] = ORP_calc_value;
			if(mode_ATC_MTC == 0)
				calib_measure_temp_ex[calib_measure_cnt % CALIB_SAMPLES] = temper_calc_value;
			else
				calib_measure_temp_ex[calib_measure_cnt % CALIB_SAMPLES] = calib_manual_temperature;

			calib_measure_cnt++;

			if(calib_measure_cnt >= CALIB_SAMPLES)
			{
				//				calib_measure_cnt = 0;
				temp_float = 0;

				for(i = 0; i < CALIB_SAMPLES; i++)
				{
					temp_float += calib_measure_ex[i];
					temp_avg += calib_measure_temp_ex[i];
				}

				temp_float = (float)(temp_float / CALIB_SAMPLES);
				temp_avg = 	(float)(temp_avg / CALIB_SAMPLES);

				for(i = 0; i < CALIB_SAMPLES; i++)
				{
					if((calib_measure_ex[i] - temp_float > CALIB_ORP_THRES) || (temp_float - calib_measure_ex[i] > CALIB_ORP_THRES))
					{
						measure_comp_flag = 0;
						break;
					}
					else
						measure_comp_flag = 1;
				}

				for(i = 0; i < CALIB_SAMPLES; i++)
				{
					if((calib_measure_temp_ex[i] - temp_avg > 0.2f) || (temp_avg - calib_measure_temp_ex[i] > 0.2f))
					{
						measure_comp_flag_temper = 2;
						break;
					}
					else
					{
						measure_comp_flag_temper = 1;
					}
				}

				if(measure_comp_flag==0)
				{
					calib_stage_cnt ++;
					if(calib_stage_cnt >= CALIB_TIMEOUT)
					{
						calib_stage_cnt = 0;	
						if(mode_ATC_MTC == 0)
							temp_float = calib_pH_mV[0] - pH2mV(buffer1, temper_calc_value);
						else
							temp_float = calib_pH_mV[0] - pH2mV(buffer1, calib_manual_temperature);						

						if(calib_ph_mode==0)
						{
							return_screen_id = 104;
						}
						else if(calib_ph_mode==1)
						{
							return_screen_id = 113;
						}
						else if(calib_ph_mode==2)
						{
							return_screen_id = 122;
						}

						if((temp_float>60.0f) || (temp_float<-60.0f))
						{
							SetTextValue(75,4,"1");
							current_screen_id = 75;
							SetScreen(current_screen_id);		//mV_1 overlay error!
						} 
						else
						{
							calib_measure_flag = 0;
							SetTextValue(65,4,"1");
							current_screen_id = 65;
							SetScreen(current_screen_id);			//mV_1 unstable error!
						}						
					}
				}
				else if(measure_comp_flag_temper==2)
				{
					calib_stage_cnt ++;
					if(calib_stage_cnt >= CALIB_TIMEOUT)
					{
						if(calib_ph_mode==0)
						{
							return_screen_id = 104;
						}
						else if(calib_ph_mode==1)
						{
							return_screen_id = 113;
						}
						else if(calib_ph_mode==2)
						{
							return_screen_id = 122;
						}
						SetTextValue(64,4,"1");
						current_screen_id = 64;
						SetScreen(current_screen_id);
					}
				}

				if(measure_comp_flag == 1 && measure_comp_flag_temper == 1)
				{
					if(mode_ATC_MTC == 0) 
						temperature1 = temper_calc_value;
					else
						temperature1 = calib_manual_temperature;
					SetTextValueFloat2(108, 4, ORP_calc_value);
					SetTextValueFloat2(108, 5, temperature1);
					SetTextValueInt32(108, 6, calib_count_up);
					SetTextValueFloat2(108, 7, buffer1);

					current_screen_id = 108;
					SetScreen(current_screen_id);											
				}
			}
		}
	}

	else if(current_screen_id==109)
	{
		calib_count_up++;
		SetTextValueFloat2(109, 4, ORP_calc_value);
		if(mode_ATC_MTC == 0)
			SetTextValueFloat2(109, 5, temper_calc_value);
		else
			SetTextValueFloat2(109, 5, calib_manual_temperature);
		SetTextValueInt32(109, 6, calib_count_up);
		calib_pH_mV[1] = ORP_calc_value;

		if(calib_count_up > 7)
		{
			if(calib_ph_mode == 0)
			{
				buffer2 = select_nist_standard_ph(ORP_calc_value);
				SetTextValueFloat2(109, 7, buffer2);
			}
			else if(calib_ph_mode == 1)
			{
				buffer2 = select_tech_standard_ph(ORP_calc_value);
				SetTextValueFloat2(109, 7, buffer2);
			}
		}

		if(calib_ph_mode == 2)
		{
			SetTextValueFloat2(109, 7, buffer2);
		}

		if(calib_measure_flag == 1)
		{
			float temp_avg;
			calib_measure_ex[calib_measure_cnt % CALIB_SAMPLES] = ORP_calc_value;
			if(mode_ATC_MTC == 0)
				calib_measure_temp_ex[calib_measure_cnt % CALIB_SAMPLES] = temper_calc_value;
			else
				calib_measure_temp_ex[calib_measure_cnt % CALIB_SAMPLES] = calib_manual_temperature;

			calib_measure_cnt++;

			if(calib_measure_cnt >= CALIB_SAMPLES)
			{
				//				calib_measure_cnt = 0;
				temp_float = 0;

				for(i = 0; i < CALIB_SAMPLES; i++)
				{
					temp_float += calib_measure_ex[i];
					temp_avg += calib_measure_temp_ex[i];
				}

				temp_float = (float)(temp_float / CALIB_SAMPLES);
				temp_avg = 	(float)(temp_avg / CALIB_SAMPLES);

				for(i = 0; i < CALIB_SAMPLES; i++)
				{
					if((calib_measure_ex[i] - temp_float > CALIB_ORP_THRES) || (temp_float - calib_measure_ex[i] > CALIB_ORP_THRES))
					{
						measure_comp_flag = 0;
						break;
					}
					else
						measure_comp_flag = 1;
				}

				for(i = 0; i < CALIB_SAMPLES; i++)
				{
					if((calib_measure_temp_ex[i] - temp_avg > 0.2f) || (temp_avg - calib_measure_temp_ex[i] > 0.2f))
					{
						measure_comp_flag_temper = 2;
						break;
					}
					else
					{
						measure_comp_flag_temper = 1;
					}
				}

				if(measure_comp_flag==0)
				{
					calib_stage_cnt ++;
					if(calib_stage_cnt >= CALIB_TIMEOUT)
					{
						calib_stage_cnt = 0;
						if(mode_ATC_MTC == 0)							
							temp_float = calib_pH_mV[1] - pH2mV(buffer2, temper_calc_value);
						else
							temp_float = calib_pH_mV[1] - pH2mV(buffer2, calib_manual_temperature);

						if(calib_ph_mode==0)
						{
							return_screen_id = 105;
						}
						else if(calib_ph_mode==1)
						{
							return_screen_id = 114;
						}
						else if(calib_ph_mode==1)
						{
							return_screen_id = 123;
						}

						if((temp_float>60.0f) || (temp_float<-60.0f))
						{
							SetTextValue(75,4,"2");
							current_screen_id = 75;
							SetScreen(current_screen_id);		//mV_1 overlay error!
						} 
						else
						{
							calib_measure_flag = 0;
							SetTextValue(65,4,"2");
							current_screen_id = 65;
							SetScreen(current_screen_id);			//mV_1 unstable error!
						}						
					}
				}
				else if(measure_comp_flag_temper==2)
				{
					calib_stage_cnt ++;
					if(calib_stage_cnt >= CALIB_TIMEOUT)
					{
						if(calib_ph_mode==0)
						{
							return_screen_id = 105;
						}
						else if(calib_ph_mode==1)
						{
							return_screen_id = 114;
						}
						else if(calib_ph_mode==2)
						{
							return_screen_id = 123;
						}
						SetTextValue(64,4,"2");
						current_screen_id = 64;
						SetScreen(current_screen_id);
					}
				}

				if(measure_comp_flag == 1 && measure_comp_flag_temper == 1)
				{
					/****temper complement for target ****/
					//calib_pH_value[1] = pHcompTemper(calib_pH_value[1], temper_calc_value);

					if(buffer1 != buffer2)
					{
						if(mode_ATC_MTC == 0)
							temperature2 = temper_calc_value;
						else
							temperature2 = calib_manual_temperature;					
						SetTextValueFloat2(110, 4, ORP_calc_value);
						SetTextValueFloat2(110, 5, temperature2);
						SetTextValueInt32(110, 6, calib_count_up);
						SetTextValueFloat2(110, 7, buffer2);

						current_screen_id = 110;
						SetScreen(current_screen_id);
					}
					else
					{
						current_screen_id = 129;
						SetTextValue(129, 3, "2");
						SetScreen(current_screen_id);
					}											
				}
			}
		}
	}

	else if(current_screen_id==111)
	{
		calib_count_up++;
		SetTextValueFloat2(111, 4, ORP_calc_value);
		if(mode_ATC_MTC == 0)
			SetTextValueFloat2(111, 5, temper_calc_value);
		else
			SetTextValueFloat2(111, 5, calib_manual_temperature);
		SetTextValueInt32(111, 6, calib_count_up);
		calib_pH_mV[2] = ORP_calc_value;

		if(calib_count_up > 7)
		{
			if(calib_ph_mode == 0)
			{
				buffer3 = select_nist_standard_ph(ORP_calc_value);	//nist
				SetTextValueFloat2(111, 7, buffer3);
			}
			else if(calib_ph_mode == 1)
			{
				buffer3 = select_tech_standard_ph(ORP_calc_value);	//tech
				SetTextValueFloat2(111, 7, buffer3);
			}
		}

		if(calib_ph_mode == 2)
		{
			SetTextValueFloat2(111, 7, buffer3);
		}

		if(calib_measure_flag == 1)
		{
			float temp_avg = 0;
			calib_measure_ex[calib_measure_cnt % CALIB_SAMPLES] = ORP_calc_value;
			if(mode_ATC_MTC == 0)
				calib_measure_temp_ex[calib_measure_cnt % CALIB_SAMPLES] = temper_calc_value;
			else
				calib_measure_temp_ex[calib_measure_cnt % CALIB_SAMPLES] = calib_manual_temperature;

			calib_measure_cnt++;

			if(calib_measure_cnt >= CALIB_SAMPLES)
			{
				//				calib_measure_cnt = 0;
				temp_float = 0;

				for(i = 0; i < CALIB_SAMPLES; i++)
				{
					temp_float += calib_measure_ex[i];
					temp_avg += calib_measure_temp_ex[i];
				}

				temp_float = (float)(temp_float / CALIB_SAMPLES);
				temp_avg = 	(float)(temp_avg / CALIB_SAMPLES);

				for(i = 0; i < CALIB_SAMPLES; i++)
				{
					if((calib_measure_ex[i] - temp_float > CALIB_ORP_THRES) || (temp_float - calib_measure_ex[i] > CALIB_ORP_THRES))
					{
						measure_comp_flag = 0;
						break;
					}
					else
						measure_comp_flag = 1;
				}

				for(i = 0; i < CALIB_SAMPLES; i++)
				{
					if((calib_measure_temp_ex[i] - temp_avg > 0.2f) || (temp_avg - calib_measure_temp_ex[i] > 0.2f))
					{
						measure_comp_flag_temper = 2;
						break;
					}
					else
					{
						measure_comp_flag_temper = 1;
					}
				}

				if(measure_comp_flag==0)
				{
					calib_stage_cnt ++;
					if(calib_stage_cnt >= CALIB_TIMEOUT)
					{
						calib_stage_cnt = 0;
						if(mode_ATC_MTC == 0)							
							temp_float = calib_pH_mV[2] - pH2mV(buffer3, temper_calc_value);
						else
							temp_float = calib_pH_mV[2] - pH2mV(buffer3, calib_manual_temperature);

						if(calib_ph_mode==0)
						{
							return_screen_id = 106;
						}
						else if(calib_ph_mode==1)
						{
							return_screen_id = 115;
						}
						else if(calib_ph_mode==1)
						{
							return_screen_id = 124;
						}

						if((temp_float>60.0f) || (temp_float<-60.0f))
						{
							SetTextValue(75,4,"3");
							current_screen_id = 75;
							SetScreen(current_screen_id);		//mV_1 overlay error!
						} 
						else
						{
							calib_measure_flag = 0;
							SetTextValue(65,4,"3");
							current_screen_id = 65;
							SetScreen(current_screen_id);			//mV_1 unstable error!
						}						
					}
				}
				else if(measure_comp_flag_temper==2)
				{
					calib_stage_cnt ++;
					if(calib_stage_cnt >= CALIB_TIMEOUT)
					{
						if(calib_ph_mode==0)
						{
							return_screen_id = 106;
						}
						else if(calib_ph_mode==1)
						{
							return_screen_id = 115;
						}
						else if(calib_ph_mode==2)
						{
							return_screen_id = 124;
						}
						SetTextValue(64,4,"3");
						current_screen_id = 64;
						SetScreen(current_screen_id);
					}
				}

				if(measure_comp_flag == 1 && measure_comp_flag_temper ==1)
				{
					/****temper complement for target ****/
					if(buffer3 != buffer2 && buffer3 != buffer1)
					{
						if(mode_ATC_MTC == 0)
							temperature3 = temper_calc_value;
						else
							temperature3 = calib_manual_temperature;
						calib_pH_value[2] = pHcompTemper(calib_pH_value[2], temper_calc_value); 
						SetTextValueFloat2(112, 4, ORP_calc_value);
						SetTextValueFloat2(112, 5, temperature3);
						SetTextValueInt32(112, 6, calib_count_up);
						SetTextValueFloat2(112, 7, buffer3);

						current_screen_id = 112;
						SetScreen(current_screen_id);
					}
					else
					{
						current_screen_id = 129;
						SetTextValue(129, 3, "3");
						SetScreen(current_screen_id);
					}											
				}
			}
		}
	}

	else if(current_screen_id==29)	//pH-1 calib point
	{
		SetTextValueFloat(29,1,ORP_calc_value);

		calib_count_down--;
		main_count = 0;
		if(calib_count_down > 0)
		{
			sprintf(calib_count_down_buffer, "%d%d:%d%d", calib_count_down / 600, (calib_count_down % 600) / 60, (calib_count_down % 60) / 10, calib_count_down % 10);
			SetTextValue(29, 5, calib_count_down_buffer);
		}
		else
		{
			SetTextValue(29, 5, "Calibrating...");
			calib_count_down = 0;
			calib_pH_mV[0] = ORP_calc_value;
			if(calib_measure_flag==1)
			{
				calib_measure_ex[calib_measure_cnt % CALIB_SAMPLES] = ORP_calc_value;
				calib_measure_cnt++;

				if(calib_measure_cnt>=CALIB_SAMPLES)
				{
					//					calib_measure_cnt = 0;
					//TODO error process
					temp_float = 0;
					for(i=0; i<CALIB_SAMPLES; i++)
						temp_float += calib_measure_ex[i];
					temp_float = (float)(temp_float/CALIB_SAMPLES);

					for(i=0; i<CALIB_SAMPLES; i++)
					{
						if((calib_measure_ex[i]-temp_float>CALIB_ORP_THRES) || (temp_float-calib_measure_ex[i]>CALIB_ORP_THRES))
						{
							measure_comp_flag = 0;
							break;
						}
						else
							measure_comp_flag = 1;
					}

					if(measure_comp_flag==0)
					{
						calib_stage_cnt ++;
						if(calib_stage_cnt>=CALIB_TIMEOUT)
						{
							calib_stage_cnt = 0;

							if(mode_ATC_MTC==MEASURE_MODE_ATC)
								temp_float = calib_pH_mV[0] - pH2mV(calib_pH_value[0],temper_calc_value); 
							else if(mode_ATC_MTC==MEASURE_MODE_MTC)
								temp_float = calib_pH_mV[0] - pH2mV(calib_pH_value[0],temper_calib_manual[0]); 
							if((temp_float>60.0f) || (temp_float<-60.0f))
							{
								SetTextValue(75,4,"1");
								current_screen_id = 75;
								SetScreen(current_screen_id);		//mV_1 overlay error!
							} 
							else
							{
								calib_measure_flag = 0;
								SetTextValue(65,4,"1");
								current_screen_id = 65;
								SetScreen(current_screen_id);			//mV_1 unstable error!
							}						
						}
					}
					else
					{
						/****temper complement for target ****/
						if(mode_ATC_MTC==MEASURE_MODE_ATC)
							calib_pH_value[0] = pHcompTemper(calib_pH_value[0],temper_calc_value); 
						else if(mode_ATC_MTC==MEASURE_MODE_MTC)
							calib_pH_value[0] = pHcompTemper(calib_pH_value[0],temper_calib_manual[0]); 

						SetTextValueFloat2(30,3,calib_pH_value[0]);
						current_screen_id = 30;
						SetScreen(current_screen_id);		//pH_1 direct
					}
				}// end of if(calib_measure_cnt > CALIB_SAMPLES)

			}
		}

	}

	else if(current_screen_id==69)	//temper2 measure for calib
	{
		SetTextValueFloat(69,2,temper_calc_value);
		if(calib_measure_flag==1)
		{
			calib_measure_ex[calib_measure_cnt % CALIB_SAMPLES] = temper_calc_value;
			calib_measure_cnt ++;
			if(calib_measure_cnt>=CALIB_SAMPLES)
			{
				//				calib_measure_cnt = 0;
				//TODO error process
				temp_float = 0;
				for(i=0; i<CALIB_SAMPLES; i++)
					temp_float += calib_measure_ex[i];
				temp_float = (float)(temp_float/CALIB_SAMPLES);

				for(i=0; i<CALIB_SAMPLES; i++)
				{
					if((calib_measure_ex[i]-temp_float>0.5f) || (temp_float-calib_measure_ex[i]>0.5f))
					{
						measure_comp_flag = 0;
						break;
					}
					else
						measure_comp_flag = 1;
				}

				if(measure_comp_flag==0)
				{
					calib_stage_cnt ++;
					if(calib_stage_cnt>=CALIB_TIMEOUT)
					{
						calib_stage_cnt = 0;

						SetTextValue(64,4,"2");
						calib_pH_index = GetpHClass(calib_pH_value[1]);
						if((temp_float<0) || (temp_float>95))
						{
							calib_measure_flag = 0;
							current_screen_id = 64;
							SetScreen(current_screen_id);		//temper2 overlay error!
						}
						else
						{
							calib_measure_flag = 0;
							SetTextValue(74,4,"2");
							current_screen_id = 74;
							SetScreen(current_screen_id);		//temper2 unstable error!
						}		
					}
				}
				else
				{
					calib_measure_flag = 1;
					SetTextFlash(32,1,50);		//500ms				 
					return_screen_id = 31;
					calib_count_down = 300; 
					current_screen_id = 32;
					SetScreen(current_screen_id); 		//mV_2 measure window
				}
			}// end of if(calib_measure_cnt > CALIB_SAMPLES)
		}
	}
	else if(current_screen_id==32)	//pH-2 calib point
	{
		SetTextValueFloat(32,1,ORP_calc_value);
		calib_count_down--;
		main_count = 0;
		if(calib_count_down > 0)
		{
			sprintf(calib_count_down_buffer, "%d%d:%d%d", calib_count_down / 600, (calib_count_down % 600) / 60, (calib_count_down % 60) / 10, calib_count_down % 10);
			SetTextValue(32, 5, calib_count_down_buffer);
		}
		else
		{
			SetTextValue(32, 5, "Calibrating...");
			calib_count_down = 0;
			calib_pH_mV[1] = ORP_calc_value;
			if(calib_measure_flag==1)
			{
				calib_measure_ex[calib_measure_cnt % CALIB_SAMPLES] = ORP_calc_value;
				calib_measure_cnt ++;
				if(calib_measure_cnt>=CALIB_SAMPLES)
				{
					//					calib_measure_cnt = 0;
					//TODO error process
					temp_float = 0;
					for(i=0; i<CALIB_SAMPLES; i++)
						temp_float += calib_measure_ex[i];
					temp_float = (float)(temp_float/CALIB_SAMPLES);

					for(i=0; i<CALIB_SAMPLES; i++)
					{
						if((calib_measure_ex[i]-temp_float>CALIB_ORP_THRES) || (temp_float-calib_measure_ex[i]>CALIB_ORP_THRES))
						{
							measure_comp_flag = 0;
							break;
						}
						else
							measure_comp_flag = 1;
					}

					if(measure_comp_flag==0)
					{
						calib_stage_cnt ++;
						if(calib_stage_cnt>=CALIB_TIMEOUT)
						{
							calib_stage_cnt = 0;

							if(mode_ATC_MTC==MEASURE_MODE_ATC)
								temp_float = calib_pH_mV[1] - pH2mV(calib_pH_value[1],temper_calc_value); 
							else if(mode_ATC_MTC==MEASURE_MODE_MTC)
								temp_float = calib_pH_mV[1] - pH2mV(calib_pH_value[1],temper_calib_manual[1]); 
							if((temp_float>60.0f) || (temp_float<-60.0f))
							{
								SetTextValue(75,4,"2");
								current_screen_id = 75;
								SetScreen(current_screen_id);		//mV_2 overlay error!
							} 
							else
							{
								calib_measure_flag = 0;
								SetTextValue(65,4,"2");
								current_screen_id = 65;
								SetScreen(current_screen_id);			//mV_2 unstable error!
							}						
						}
					}
					else
					{
						/****temper complement for target ****/
						if(mode_ATC_MTC==MEASURE_MODE_ATC)
							calib_pH_value[1] = pHcompTemper(calib_pH_value[1],temper_calc_value); 
						else if(mode_ATC_MTC==MEASURE_MODE_MTC)
							calib_pH_value[1] = pHcompTemper(calib_pH_value[1],temper_calib_manual[1]); 

						SetTextValueFloat2(33,3,calib_pH_value[1]);
						current_screen_id = 33;
						SetScreen(current_screen_id);		//pH_2 direct
					}
				}// end of if(calib_measure_cnt > CALIB_SAMPLES)

			}
		}
	}

	else if(current_screen_id==71)	//temper3 measure for calib
	{
		SetTextValueFloat(71,2,temper_calc_value);
		if(calib_measure_flag==1)
		{
			calib_measure_ex[calib_measure_cnt % CALIB_SAMPLES] = temper_calc_value;
			calib_measure_cnt ++;
			if(calib_measure_cnt>=CALIB_SAMPLES)
			{
				//				calib_measure_cnt = 0;
				//TODO error process
				temp_float = 0;
				for(i=0; i<CALIB_SAMPLES; i++)
					temp_float += calib_measure_ex[i];
				temp_float = (float)(temp_float/CALIB_SAMPLES);

				for(i=0; i<CALIB_SAMPLES; i++)
				{
					if((calib_measure_ex[i]-temp_float>0.5f) || (temp_float-calib_measure_ex[i]>0.5f))
					{
						measure_comp_flag = 0;
						break;
					}
					else
						measure_comp_flag = 1;
				}

				if(measure_comp_flag==0)
				{
					calib_stage_cnt ++;
					if(calib_stage_cnt>=CALIB_TIMEOUT)
					{
						calib_stage_cnt = 0;

						SetTextValue(64,4,"3");
						calib_pH_index = GetpHClass(calib_pH_value[2]);
						if((temp_float<0) || (temp_float>95))
						{
							calib_measure_flag = 0;
							current_screen_id = 64;
							SetScreen(current_screen_id);		//temper3 overlay error!
						}
						else
						{
							calib_measure_flag = 0;
							SetTextValue(74,4,"3");
							current_screen_id = 74;
							SetScreen(current_screen_id);		//temper3 unstable error!
						}			
					}
				}
				else
				{
					calib_measure_flag = 1;
					SetTextFlash(35,1,50);		//500ms				  
					return_screen_id = 34;
					calib_count_down = 300;
					current_screen_id = 35;
					SetScreen(current_screen_id); 		//mV_3 measure window
				}
			}// end of if(calib_measure_cnt > CALIB_SAMPLES)

		}
	}
	else if(current_screen_id==35)	//pH-3 calib point
	{
		//TODO measure now ORP
		SetTextValueFloat(35,1,ORP_calc_value);
		calib_count_down--;
		main_count = 0;
		if(calib_count_down > 0)
		{
			sprintf(calib_count_down_buffer, "%d%d:%d%d", calib_count_down / 600, (calib_count_down % 600) / 60, (calib_count_down % 60) / 10, calib_count_down % 10);
			SetTextValue(35, 5, calib_count_down_buffer);
		}
		else
		{
			SetTextValue(35, 5, "Calibrating...");
			calib_count_down = 0;
			calib_pH_mV[2] = ORP_calc_value;
			if(calib_measure_flag==1)
			{
				calib_measure_ex[calib_measure_cnt % CALIB_SAMPLES] = ORP_calc_value;
				calib_measure_cnt ++;

				if(calib_measure_cnt>=CALIB_SAMPLES)
				{
					//					calib_measure_cnt = 0;
					//TODO error process
					temp_float = 0;
					for(i=0; i<CALIB_SAMPLES; i++)
						temp_float += calib_measure_ex[i];
					temp_float = (float)(temp_float/CALIB_SAMPLES);

					for(i=0; i<CALIB_SAMPLES; i++)
					{
						if((calib_measure_ex[i]-temp_float>CALIB_ORP_THRES) || (temp_float-calib_measure_ex[i]>CALIB_ORP_THRES))
						{
							measure_comp_flag = 0;
							break;
						}
						else
							measure_comp_flag = 1;
					}

					if(measure_comp_flag==0)
					{
						calib_stage_cnt ++;
						if(calib_stage_cnt>=CALIB_TIMEOUT)
						{
							calib_stage_cnt = 0;

							if(mode_ATC_MTC==MEASURE_MODE_ATC)
								temp_float = calib_pH_mV[2] - pH2mV(calib_pH_value[2],temper_calc_value); 
							else if(mode_ATC_MTC==MEASURE_MODE_MTC)
								temp_float = calib_pH_mV[2] - pH2mV(calib_pH_value[2],temper_calib_manual[2]); 
							if((temp_float>60.0f) || (temp_float<-60.0f))
							{
								SetTextValue(75,4,"3");
								current_screen_id = 75;
								SetScreen(current_screen_id);		//mV_3 overlay error!
							} 
							else
							{
								calib_measure_flag = 0;
								SetTextValue(65,4,"3");
								current_screen_id = 65;
								SetScreen(current_screen_id);			//mV_3 unstable error!
							}						
						}
					}
					else
					{
						/****temper complement for target ****/
						if(mode_ATC_MTC==MEASURE_MODE_ATC)
							calib_pH_value[2] = pHcompTemper(calib_pH_value[2],temper_calc_value); 
						else if(mode_ATC_MTC==MEASURE_MODE_MTC)
							calib_pH_value[2] = pHcompTemper(calib_pH_value[2],temper_calib_manual[2]); 

						SetTextValueFloat2(36,3,calib_pH_value[2]);
						current_screen_id = 36;
						SetScreen(current_screen_id);		//pH_3 direct
					}
				}// end of if(calib_measure_cnt > CALIB_SAMPLES)

			}
		}
	}
	//-----------------AIN measuring for calibration ------------------------------//
	else if((current_screen_id==92)||(current_screen_id==95))	//DO, pH: 0.01
	{
		if(analogIn_calib_ch==0)
			SetTextValueFloat2(current_screen_id,2,Ain_real_raw[0]);
		else if(analogIn_calib_ch==1)
			SetTextValueFloat2(current_screen_id,2,Ain_real_raw[1]);
	}

	else if(current_screen_id==80)	//at 20211119
	{
		SetTextValueFloat2(current_screen_id, 2, pH_calc_value);
	}

	else if(current_screen_id==133)	
	{
		//TODO measure now ORP
		SetTextValueFloat(133,4,ORP_avrg_value);
		orp_calib_measure_val[orp_calib_process - 1] = ORP_avrg_value;
		if(calib_measure_flag==1)
		{
			calib_measure_ex[calib_measure_cnt % CALIB_SAMPLES] = ORP_avrg_value;
			calib_measure_cnt ++;
			if(calib_measure_cnt>=CALIB_SAMPLES)
			{
				//				calib_measure_cnt = 0;
				//TODO error process
				temp_float = 0;
				for(i=0; i<CALIB_SAMPLES; i++)
					temp_float += calib_measure_ex[i];
				temp_float = (float)(temp_float/CALIB_SAMPLES);

				for(i=0; i<CALIB_SAMPLES; i++)
				{
					if((calib_measure_ex[i]-temp_float>0.2f) || (temp_float-calib_measure_ex[i]>0.2f))
					{
						measure_comp_flag = 0;
						break;
					}
					else
						measure_comp_flag = 1;
				}

				if(measure_comp_flag==0)
				{
					calib_stage_cnt ++;
					if(calib_stage_cnt>=CALIB_TIMEOUT)
					{
						calib_stage_cnt = 0;

						calib_measure_flag = 0;
						SetTextValue(65,4,"3");
						current_screen_id = 65;
						SetScreen(current_screen_id);			//ORP_3 unstable error!
					}
				}
				else
				{
					if(orp_calib_process >= orp_calib_point_num)
					{
						SetTextFlash(133,4,0);		//flash off, complete
						AnimationPlayFrame(133,1,1);	//show "complete" button
					}
					else
					{
						orp_calib_process++;
						SetTextValueInt32(132,5,orp_calib_process);
						SetTextValueFloat2(132,3,orp_calib_ref_val[orp_calib_process - 1]);
						current_screen_id=132;
						SetScreen(current_screen_id);	
					}
				}
			}// end of if(calib_measure_cnt > CALIB_SAMPLES)

		}
	}

	else if(current_screen_id==136)
	{
		//TODO measure now ORP
		SetTextValueFloat(136,4,temper_now_res);
		temp_calib_measure_val[temp_calib_process - 1] = temper_now_res;

		if(calib_measure_flag==1)
		{
			calib_measure_ex[calib_measure_cnt % CALIB_SAMPLES] = temper_now_res;
			calib_measure_cnt ++;
			if(calib_measure_cnt>=CALIB_SAMPLES)
			{
				//				calib_measure_cnt = 0;
				//TODO error process
				temp_float = 0;
				for(i=0; i<CALIB_SAMPLES; i++)
					temp_float += calib_measure_ex[i];
				temp_float = (float)(temp_float/CALIB_SAMPLES);

				for(i=0; i<CALIB_SAMPLES; i++)
				{
					if((calib_measure_ex[i]-temp_float>0.1f) || (temp_float-calib_measure_ex[i]>0.1f))
					{
						measure_comp_flag = 0;
						break;
					}
					else
						measure_comp_flag = 1;
				}

				if(measure_comp_flag==0)
				{
					calib_stage_cnt ++;
					if(calib_stage_cnt>=CALIB_TIMEOUT)
					{
						calib_stage_cnt = 0;

						calib_measure_flag = 0;
						SetTextValue(59,4,"2");
						current_screen_id = 59;
						SetScreen(current_screen_id);			//temper_2 unstable error!
					}
				}
				else
				{
					if(temp_calib_process >= temp_calib_point_num)
					{
						SetTextFlash(136,4,0);		//flash off, complete
						AnimationPlayFrame(136,1,1);	//show "complete" button
					}
					else
					{
						temp_calib_process++;
						SetTextValueInt32(135,5,temp_calib_process);
						SetTextValueFloat2(135,3,temp_calib_ref_val[temp_calib_process - 1]);
						current_screen_id=135;
						SetScreen(current_screen_id);	
					}
				}
			}// end of if(calib_measure_cnt > CALIB_SAMPLES)

		}
	}
	/*	
	else if(current_screen_id==49)	//temper1 factory
	{
		//TODO measure now temper
		SetTextValueFloat(49,3,temper_now_res);
		factory_temper_measure[0] = temper_now_res;
		if(calib_measure_flag==1)
		{
			calib_measure_ex[calib_measure_cnt] = temper_now_res;
			calib_measure_cnt ++;
			if(calib_measure_cnt>=CALIB_SAMPLES)
			{
				calib_measure_cnt = 0;
				//TODO error process
				temp_float = 0;
				for(i=0; i<CALIB_SAMPLES; i++)
					temp_float += calib_measure_ex[i];
				temp_float = (float)(temp_float/CALIB_SAMPLES);

				for(i=0; i<CALIB_SAMPLES; i++)
				{
					if((calib_measure_ex[i]-temp_float>0.1f) || (temp_float-calib_measure_ex[i]>0.1f))
					{
						measure_comp_flag = 0;
						break;
					}
					else
						measure_comp_flag = 1;
				}

				if(measure_comp_flag==0)
				{
					calib_stage_cnt ++;
					if(calib_stage_cnt>=CALIB_TIMEOUT)
					{
						calib_stage_cnt = 0;

						calib_measure_flag = 0;
						SetTextValue(74,4,"1");
						SetScreen(74);			//temper_1 unstable error!
					}
				}
				else
				{
					current_screen_id = 50;
					SetScreen(50);		//temper_2 input
				}
			}// end of if(calib_measure_cnt > CALIB_SAMPLES)

		}
	}

	else if(current_screen_id==51)	//temper2 factory
	{
		//TODO measure now temper
		SetTextValueFloat(51,3,temper_now_res);
		factory_temper_measure[1] = temper_now_res;
		if(calib_measure_flag==1)
		{
			calib_measure_ex[calib_measure_cnt] = temper_now_res;
			calib_measure_cnt ++;
			if(calib_measure_cnt>=CALIB_SAMPLES)
			{
				calib_measure_cnt = 0;
				//TODO error process
				temp_float = 0;
				for(i=0; i<CALIB_SAMPLES; i++)
					temp_float += calib_measure_ex[i];
				temp_float = (float)(temp_float/CALIB_SAMPLES);

				for(i=0; i<CALIB_SAMPLES; i++)
				{
					if((calib_measure_ex[i]-temp_float>0.1f) || (temp_float-calib_measure_ex[i]>0.1f))
					{
						measure_comp_flag = 0;
						break;
					}
					else
						measure_comp_flag = 1;
				}

				if(measure_comp_flag==0)
				{
					calib_stage_cnt ++;
					if(calib_stage_cnt>=CALIB_TIMEOUT)
					{
						calib_stage_cnt = 0;

						calib_measure_flag = 0;
						SetTextValue(74,4,"2");
						SetScreen(74);			//temper_2 unstable error!
					}
				}
				else
				{
					SetTextFlash(51,3,0);		//flash off, complete
					AnimationPlayFrame(51,1,1);	//show "complete" button
				}
			}// end of if(calib_measure_cnt > CALIB_SAMPLES)

		}
	}*/

	/*
	else if(current_screen_id==5)//�������ͻ������
	{
		SetProgressValue(5,1,test_value%100);

		++test_value;
	}
	else if(current_screen_id==6)//�Ǳ��ؼ�
	{
		SetMeterValue(6,1,test_value%360);
		SetMeterValue(6,2,test_value%360);

		++test_value;
	} */
}

void DispCalibTime(uint16_t screen_id)
{
	char buf[32];
	buf[0] = 2 + '0';
	buf[1] = 0 + '0';
	buf[2] = ((now_year>>4)&0x0F) + '0';
	buf[3] = (now_year&0x0F) + '0';
	buf[4] = '/';
	buf[5] = ((now_month>>4)&0x0F) + '0';
	buf[6] = (now_month&0x0F) + '0';
	buf[7] = '/';
	buf[8] = ((now_day>>4)&0x0F) + '0';
	buf[9] = (now_day&0x0F) + '0';
	buf[10] = ' ';

	buf[11] = ((now_hour>>4)&0x0F) + '0';
	buf[12] = (now_hour&0x0F) + '0';
	buf[13] = ':';
	buf[14] = ((now_minute>>4)&0x0F) + '0';
	buf[15] = (now_minute&0x0F) + '0';
	buf[16] = ':';
	buf[17] = ((now_sec>>4)&0x0F) + '0';
	buf[18] = (now_sec&0x0F) + '0';
	buf[19] = 0;	

	SetTextValue(screen_id,11,buf);
}

void DispCalibTimeIdx(uint16_t screen_id, uint16_t control_id)
{
	char buf[32];
	buf[0] = 2 + '0';
	buf[1] = 0 + '0';
	buf[2] = ((now_year>>4)&0x0F) + '0';
	buf[3] = (now_year&0x0F) + '0';
	buf[4] = '/';
	buf[5] = ((now_month>>4)&0x0F) + '0';
	buf[6] = (now_month&0x0F) + '0';
	buf[7] = '/';
	buf[8] = ((now_day>>4)&0x0F) + '0';
	buf[9] = (now_day&0x0F) + '0';
	buf[10] = ' ';

	buf[11] = ((now_hour>>4)&0x0F) + '0';
	buf[12] = (now_hour&0x0F) + '0';
	buf[13] = ':';
	buf[14] = ((now_minute>>4)&0x0F) + '0';
	buf[15] = (now_minute&0x0F) + '0';
	buf[16] = ':';
	buf[17] = ((now_sec>>4)&0x0F) + '0';
	buf[18] = (now_sec&0x0F) + '0';
	buf[19] = 0;	

	SetTextValue(screen_id, control_id, buf);
}

void DispLastCalibTime(uint16_t screen_id, uint16_t control_id)
{
	char buf[32];
	buf[0] = 2 + '0';
	buf[1] = 0 + '0';
	buf[2] = ((calib_year>>4)&0x0F) + '0';
	buf[3] = (calib_year&0x0F) + '0';
	buf[4] = '/';
	buf[5] = ((calib_month>>4)&0x0F) + '0';
	buf[6] = (calib_month&0x0F) + '0';
	buf[7] = '/';
	buf[8] = ((calib_day>>4)&0x0F) + '0';
	buf[9] = (calib_day&0x0F) + '0';
	buf[10] = ' ';

	buf[11] = ((calib_hour>>4)&0x0F) + '0';
	buf[12] = (calib_hour&0x0F) + '0';
	buf[13] = ':';
	buf[14] = ((calib_minute>>4)&0x0F) + '0';
	buf[15] = (calib_minute&0x0F) + '0';
	buf[16] = ':';
	buf[17] = ((calib_sec>>4)&0x0F) + '0';
	buf[18] = (calib_sec&0x0F) + '0';
	buf[19] = 0;	

	SetTextValue(screen_id, control_id, buf);
}

void DispLastCalibORPTime(uint16_t screen_id, uint16_t control_id)
{
	char buf[32];
	buf[0] = 2 + '0';
	buf[1] = 0 + '0';
	buf[2] = ((calib_orp_year>>4)&0x0F) + '0';
	buf[3] = (calib_orp_year&0x0F) + '0';
	buf[4] = '/';
	buf[5] = ((calib_orp_month>>4)&0x0F) + '0';
	buf[6] = (calib_orp_month&0x0F) + '0';
	buf[7] = '/';
	buf[8] = ((calib_orp_day>>4)&0x0F) + '0';
	buf[9] = (calib_orp_day&0x0F) + '0';
	buf[10] = ' ';

	buf[11] = ((calib_orp_hour>>4)&0x0F) + '0';
	buf[12] = (calib_orp_hour&0x0F) + '0';
	buf[13] = ':';
	buf[14] = ((calib_orp_minute>>4)&0x0F) + '0';
	buf[15] = (calib_orp_minute&0x0F) + '0';
	buf[16] = ':';
	buf[17] = ((calib_orp_sec>>4)&0x0F) + '0';
	buf[18] = (calib_orp_sec&0x0F) + '0';
	buf[19] = 0;	

	SetTextValue(screen_id, control_id, buf);
}

/*! 
 *  \brief  ��ť�ؼ�֪ͨ
 *  \details  ����ť״̬�ı�(�����GetControlValue)ʱ��ִ�д˺���
 *  \param screen_id ����ID
 *  \param control_id �ؼ�ID
 *  \param state ��ť״̬��0����1����
 */
void NotifyButton(uint16 screen_id, uint16 control_id, uint8  state)
{
	uint16 i;
	uint8 cmp_flag = 0;

	main_count = 0;

	if(screen_id==0) 	//main window
	{
		if(control_id==1)	//Setting button
		{
			for(i=0; i<4; i++)
				setting_pwd[i] = '*';
			current_screen_id = 15;
			SetScreen(current_screen_id);
		}
		else if(control_id==2)	//Calib button
		{
			for(i=0; i<4; i++)
			{
				calib_pwd[i] = '*';
				factory_pwd[i] = '*';
			}

			current_screen_id = 17;
			SetScreen(current_screen_id);
		}
		else if(control_id==11)	//data history
		{
			if(analogIn1_type == 0)
				current_screen_id = 138;
			else
				current_screen_id = 137;

			CurveClear(current_screen_id, 9, 0);delay_ms(10);
			CurveClear(current_screen_id, 8, 0);delay_ms(10);
			//disp_data_time_history = ((now_month>>4)&0x0F)*100000+(now_month&0x0F)*10000+ ((now_day>>4)&0x0F)*1000+(now_day&0x0F)*100+((now_hour>>4)&0x0F)*10+(now_hour&0x0F) - 1;
			disp_data_time_history = current_timestamp - 3600; //at 20210721
			SetScreen(current_screen_id);
			data_hist_ch = 0;
			ReadFromTFCard(disp_data_time_history);
			data_hist_ch = 1;
			ReadFromTFCard(disp_data_time_history);
		}
		else if(control_id==12)
		{
			/********** Enter the device information **********************/
			SetTextValue(62,2,HW_version);	delay_ms(1);
			SetTextValue(62,3,FW_version);	delay_ms(1);
			SetTextValue(62,4,SN_num);	delay_ms(1);
			SetTextValue(62,5,Factory_num);	delay_ms(1);
			SetTextValue(62,6,Product_num);	delay_ms(1);

			current_screen_id = 62;
			SetScreen(current_screen_id);
		}
	}
	else if(screen_id==15) 	//enter to setting
	{
		if(control_id==1)	//������ť
		{
			for(i=0; i<4; i++)
			{
				if(setting_pwd[i] != setting_pwd_default[i])
					cmp_flag = 0;
				else
					cmp_flag = 1;
			}
			if(cmp_flag)
				current_screen_id = 1;
			else
				current_screen_id = 16;		//error message

			SetScreen(current_screen_id);
		}
		else if(control_id==2)	//return button
		{
			ACQ_Enable = 1;
			display_cnt = 0;
			current_screen_id = 0;
			SetScreen(current_screen_id);
		}
	}

	else if(screen_id==62)
	{
		if(control_id==1)
		{
			ACQ_Enable = 1;	//added by kjh at 20200327
			display_cnt = 0;
			current_screen_id = 0;
			SetScreen(current_screen_id);
		}
		else if(control_id==7)
		{
			if(analogIn1_type == 0)
				current_screen_id = 127;
			else
				current_screen_id = 128;
			SetScreen(current_screen_id);
		}
	}

	else if((screen_id==127) || (screen_id==128)) //at 20201130
	{
		if(control_id==1)
		{
			ACQ_Enable = 1;	//added by kjh at 20200327
			display_cnt = 0;
			current_screen_id = 0;
			SetScreen(current_screen_id);
		}
		else if(control_id==7)
		{
			current_screen_id = 62;
			SetScreen(current_screen_id);
		}
	}

	else if(screen_id==17) 	//enter to calibration
	{
		if(control_id==1)	//������ť
		{
			for(i=0; i<4; i++)
			{
				if(calib_pwd[i]==calib_pwd_default[i])
					cmp_flag = 1;
				else
				{
					cmp_flag = 0;
					break;
				}
			}
			if(cmp_flag==0)
			{
				for(i=0; i<4; i++)
				{
					if(calib_pwd[i]==factory_pwd_default[i])
						cmp_flag = 2;
					else
					{
						cmp_flag = 0;
						break;
					}
				}
			}

			if(cmp_flag==1)
			{
				Relay1_Disable;
				Relay2_Disable;
				WashTimer_Disable;

				analog_calib_flag = 1;	//added by kjh at 20200226
				//	ACQ_Enable = 0;				//added by kjh at 20200407

				AnimationPlayFrame(59,5,analogIn1_type);	delay_ms(1);
				AnimationPlayFrame(59,6,analogIn2_type);	delay_ms(1);
				AnimationPlayFrame(57,5,analogIn1_type);	delay_ms(1);
				AnimationPlayFrame(57,6,analogIn2_type);	delay_ms(1);
				if(mode_ATC_MTC==MEASURE_MODE_ATC)
				{
					custom_calib_state = 1;
					current_screen_id = 59;			//user calibration
				}
				else if(mode_ATC_MTC==MEASURE_MODE_MTC)
					current_screen_id = 57;			//
				SetScreen(current_screen_id);
			}
			else if(cmp_flag==2)
			{
				Relay1_Disable;
				Relay2_Disable;
				WashTimer_Disable;

				analog_calib_flag = 1;	//added by kjh at 20200226
				//	ACQ_Enable = 0;				//added by kjh at 20200407

				current_screen_id = 41;		//factory calib main for sensor
				SetScreen(current_screen_id);
			}
			else
				SetScreen(58);		//error message
		}
		else if(control_id==2)	//return button
		{
			ACQ_Enable = 1;
			display_cnt = 0;
			current_screen_id = 0;
			SetScreen(current_screen_id);
		}
	}

	else if(screen_id==1) 	//setting window
	{
		if(control_id==2)	//mode setting
		{
			//AnimationPlayFrame(2,5,mode_pH_ORP);	delay_ms(10);
			//AnimationPlayFrame(3,5,mode_pH_ORP);	delay_ms(10);
			SetTextValue(2,5,signal_type[analogIn1_type]);	delay_ms(1);
			SetTextValue(3,5,signal_type[analogIn1_type]);	delay_ms(1);
			SetTextValueFloat(3,4,temper_manual);	//added at 20200414

			if(mode_ATC_MTC == MEASURE_MODE_ATC)
				current_screen_id = 2;
			else if(mode_ATC_MTC == MEASURE_MODE_MTC)
				current_screen_id = 3;
			SetScreen(current_screen_id);
		}
		/*		else if(control_id==9)
		{
			SetTextValueInt32(52, 3, dev_address);
			current_screen_id = 52;
			SetScreen(current_screen_id);
		} */
		else if(control_id==3)	//analog1 setting
		{
			AnimationPlayFrame(4,7,analog1_classify);	delay_ms(1);
			AnimationPlayFrame(101,7,analog1_classify);	delay_ms(1);
			/*if(analog1_type==ANALOG1_TEMPER)
				AnimationPlayFrame(4,4,2);
			else if(analog1_type==ANALOG1_PHORP)
				AnimationPlayFrame(4,4,mode_pH_ORP);  */

			if(analog1_type > 1)
				type = 5;
			else
				type = analogIn1_type;
			SetTextValue(4,9,signal_type[type]);	delay_ms(1);
			SetTextValue(101,9,signal_type[type]);	delay_ms(1);

			if(analog1_type == 0)
			{
				analog1_point[0] = analog1_point_ph[0];
				analog1_point[1] = analog1_point_ph[1];
			}
			else if(analog1_type == 1)
			{
				analog1_point[0] = analog1_point_orp[0];
				analog1_point[1] = analog1_point_orp[1];
			}
			else if(analog1_type == 5)
			{
				analog1_point[0] = analog1_point_temp[0];
				analog1_point[1] = analog1_point_temp[1];
			}

			SetTextValueFloat2(4,5,analog1_point[0]);	delay_ms(1);
			SetTextValueFloat2(4,6,analog1_point[1]);	delay_ms(1);
			SetTextValueFloat2(101,5,analog1_point[0]);	delay_ms(1);
			SetTextValueFloat2(101,6,analog1_point[1]);	delay_ms(1);

			if(analog1_off_on==ANALOG1_STATE_ON)
			{
				if(analogIn1_type == 0)
					current_screen_id = 4;
				else
					current_screen_id = 101;
				SetScreen(current_screen_id);
			}
			else if(analog1_off_on==ANALOG1_STATE_OFF)
			{
				current_screen_id = 5;
				SetScreen(current_screen_id);
			}
		}
		else if(control_id==4)	//analog2 setting
		{
			AnimationPlayFrame(6,7,analog2_classify);	delay_ms(1);
			AnimationPlayFrame(102,7,analog2_classify);	delay_ms(1);

			//unsigned char type = 0;
			if(analog2_type > 1)
				type = 5;
			else
				type = analogIn1_type;

			SetTextValue(6,9,signal_type[type]); delay_ms(1);
			SetTextValue(102,9,signal_type[type]); delay_ms(1);

			if(analog2_type == 0)
			{
				analog2_point[0] = analog2_point_ph[0];
				analog2_point[1] = analog2_point_ph[1];
			}
			else if(analog2_type == 1)
			{
				analog2_point[0] = analog2_point_orp[0];
				analog2_point[1] = analog2_point_orp[1];
			}
			else if(analog2_type == 5)
			{
				analog2_point[0] = analog2_point_temp[0];
				analog2_point[1] = analog2_point_temp[1];
			}

			SetTextValueFloat2(6,5,analog2_point[0]);	delay_ms(1);
			SetTextValueFloat2(6,6,analog2_point[1]);	delay_ms(1);
			SetTextValueFloat2(102,5,analog2_point[0]);	delay_ms(1);
			SetTextValueFloat2(102,6,analog2_point[1]);	delay_ms(1);

			if(analog2_off_on == ANALOG2_STATE_ON)
			{
				if(analogIn1_type == 0)
					current_screen_id = 6;
				else
					current_screen_id = 102;
				SetScreen(current_screen_id);
			}
			else if(analog2_off_on == ANALOG2_STATE_OFF)
			{
				current_screen_id = 7;
				SetScreen(current_screen_id);
			}
		}
		else if(control_id==5)	//RS485 out setting
		{
			SetTextValueInt32(8,2,RS485_baudrate);
			SetTextValueInt32(8,5,dev_address);
			current_screen_id = 8;
			SetScreen(current_screen_id);
		}
		else if(control_id==12)	//analogIn1 setting
		{
			AnimationPlayFrame(88,7,analogIn1_classify);	delay_ms(1);
			SetTextValue(88,9,signal_type[analogIn1_type]);	delay_ms(1);

			SetTextValueFloat2(88,5,analogIn1_point[0]);	delay_ms(1);
			SetTextValueFloat2(88,6,analogIn1_point[1]);	delay_ms(1);

			if(analogIn1_off_on==1)
				current_screen_id = 88;
			else if(analogIn1_off_on==0)
				current_screen_id = 89;
			SetScreen(current_screen_id);
		}
		else if(control_id==13)	//analogIn2 setting
		{
			AnimationPlayFrame(90,7,analogIn2_classify);	delay_ms(1);
			SetTextValue(90,9,signal_type[analogIn2_type]);			delay_ms(1);

			SetTextValueFloat2(90,5,analogIn2_point[0]);	delay_ms(1);
			SetTextValueFloat2(90,6,analogIn2_point[1]);	delay_ms(1);

			if(analogIn2_off_on==1)
				current_screen_id = 90;
			else if(analogIn2_off_on==0)
				current_screen_id = 91;
			SetScreen(current_screen_id);
		}

		else if(control_id==6)	//relay1 setting
		{
			AnimationPlayFrame(9,4,analogIn1_type);	delay_ms(1);
			AnimationPlayFrame(9,7,relay1_classify);	delay_ms(1);
			//SetTextValue(9,9,relay_types[relay1_type]);	delay_ms(1);

			//	if(mode_pH_ORP==MEASURE_MODE_PH)
			{
				SetTextValueFloat2(9,5,relay1_point[1]);	delay_ms(1);	//warning point
				SetTextValueFloat2(9,6,relay1_point[0]);	delay_ms(1);	//margin
			}
			/*	else if(mode_pH_ORP==MEASURE_MODE_ORP)
			{
				SetTextValueFloat(9,5,relay1_point_ORP[1]);	delay_ms(1);	//warning point
				SetTextValueFloat(9,6,relay1_point_ORP[0]);	delay_ms(1);	//margin
			} */

			if(relay1_off_on==RELAY1_STATE_ON)
				current_screen_id = 9;
			else if(relay1_off_on==RELAY1_STATE_OFF)
				current_screen_id = 10;
			SetScreen(current_screen_id);
		}
		else if(control_id==7)	//relay2 setting
		{
			AnimationPlayFrame(11,4,analogIn1_type);	delay_ms(1);
			AnimationPlayFrame(11,7,relay2_classify);	delay_ms(1);
			//SetTextValue(11,9,relay_types[relay2_type]);	delay_ms(1);

			SetTextValueFloat2(11,5,relay2_point[1]);	delay_ms(1);
			SetTextValueFloat2(11,6,relay2_point[0]);	delay_ms(1);

			if(relay2_off_on==RELAY2_STATE_ON)
				current_screen_id = 11;
			else if(relay2_off_on==RELAY2_STATE_OFF)
				current_screen_id = 12;
			SetScreen(current_screen_id);
		}
		else if(control_id==8)	//timer setting
		{
			if(timer_off_on == TIMER_STATE_ON)
				current_screen_id = 13;
			else if(timer_off_on == TIMER_STATE_OFF)
				current_screen_id = 14;
			SetScreen(current_screen_id);
		}
		else if((control_id==1) || (control_id==10))	 //Save button
		{
			if(control_id==10)
			{
				SaveParams();
				GetParams();
				calib_return_timeout = 0;
			}
			ACQ_Enable = 1;
			display_cnt = 0;

			timer_count = 0; //at 20210728
			UpdateUI(); ///
			current_screen_id = 0;
			SetScreen(current_screen_id);
		}
		else if(control_id==11)			//Factory recovery
		{
			mode_pH_ORP = 0;
			mode_ATC_MTC = MEASURE_MODE_MTC;
			temper_manual = 25.0f;

			analog1_off_on = 1;			//ON
			analog1_classify = 1;		//4-20mA
			analog1_type = 0;	//pH
			analog1_point[0] = 0.0f; analog1_point[1] = 14.0f;
			analog2_off_on = 1;			//ON
			analog2_classify = 1;		//4-20mA
			analog2_type = 5;	//Temper
			analog2_point[0] = 0.0f; analog2_point[1] = 100.0f;

			analogIn1_off_on = 1;
			analogIn1_classify = 1;	//4-20mA
			analogIn1_type = 0;		//pH
			analogIn1_point[0] = 0.0f; analogIn1_point[1] = 14.0f;
			analogIn2_off_on = 1;
			analogIn2_classify = 1;	//4-20mA
			analogIn2_type = 5;		//pH
			analogIn2_point[0] = 0.0f; analogIn2_point[1] = 100.0f;

			relay1_off_on = RELAY1_STATE_OFF;
			relay2_off_on = RELAY2_STATE_OFF;
			timer_off_on = TIMER_STATE_OFF;
			AnimationPlayFrame(0,8,2);	delay_ms(2);
			AnimationPlayFrame(0,9,2);	delay_ms(2);
			AnimationPlayFrame(0,10,2);
			RS485_baudrate = 9600;

			calib_pH_measure[0] = mV2pH(0.0f,25.0f);	//7.00
			calib_pH_measure[1] = mV2pH(177.0f,25.0f);	//4.01
			calib_pH_measure[2] = mV2pH(-177.0f,25.0f);	//10.00

			calib_pH_slope[0] = (7.0f-4.01f)/(calib_pH_measure[0]-calib_pH_measure[1]);	//a1=(y0-y1)/(x0-x1)
			calib_pH_offset[0] = 7.0f - calib_pH_measure[0]*calib_pH_slope[0];	//b1=y0-x0*a1
			calib_pH_slope[1] = (10.0f-7.0f)/(calib_pH_measure[2]-calib_pH_measure[0]);	//a2=(y2-y0)/(x2-x0)
			calib_pH_offset[1] = 7.0f - calib_pH_measure[0]*calib_pH_slope[1];	//b2=y0-x0*a2

			ACQ_Enable = 1;
			display_cnt = 0;

			//added by schn 2018-10-31
			analog1_point_ph[0] = 0.0f;
			analog1_point_ph[1] = 14.0f;
			analog2_point_ph[0] = 0.0f;
			analog2_point_ph[1] = 14.0f;
			analog1_point_orp[0] = -1000.0f;
			analog1_point_orp[1] = 1000.0f;
			analog2_point_orp[0] = -1000.0f;
			analog2_point_orp[1] = 1000.0f;
			analog1_point_temp[0] = 0.0f;
			analog1_point_temp[1] = 100.0f;
			analog2_point_temp[0] = 0.0f;
			analog2_point_temp[1] = 100.0f;

			//added by schn 2018/08/20
			//initialize ID = 1, Baudrate = 9600
			PetitRegisters[MODBUS_DEV_ADDRESS].ActValue = 0x0001;
			PetitRegisters[MODBUS_BAUD_RATE_485].ActValue = 0x0000;
			PetitRegisters[MODBUS_BAUD_RATE_485 + 1].ActValue = 0x2580;
			SaveParams();
			GetParams();
			BindSettingValues();
			InitPetitModbus(dev_address, RS485_baudrate);
			calib_return_timeout = 0;
			current_screen_id = 0;
			SetScreen(current_screen_id);
		}
	}

	else if(screen_id==2) 	//mode setting; ATC
	{
		//	if(control_id==2)	//pH; ORP
		//		mode_pH_ORP = (~mode_pH_ORP)&0x01;
		if(control_id==3)	//ATC; MTC
		{
			mode_ATC_MTC = (~mode_ATC_MTC)&0x01;
			SetTextValue(3,5,signal_type[analogIn1_type]); delay_ms(1);
			current_screen_id = 3;		//added at 20200414
			SetScreen(current_screen_id);
		}
		//else if(control_id==4)	//PT1000; PT100
		//	temper_1000_100 = (~temper_1000_100)&0x01;
		else if(control_id==1)
		{
			SetTextValue(0,5,signal_unit[analogIn1_type]);	delay_ms(1);
			SetTextValue(0,14,signal_type[analogIn1_type]);	delay_ms(1);
			SetTextValue(0,6,temper_mode[mode_ATC_MTC]);	delay_ms(1);

			SaveParams(); //at 20210922
			GetParams();
			current_screen_id = 1;
			SetScreen(current_screen_id);
		}
		delay_ms(1);
	}
	else if(screen_id==3) 	//mode setting; MTC
	{
		//if(control_id==2)	//pH; ORP
		//	mode_pH_ORP = (~mode_pH_ORP)&0x01;
		if(control_id==3)	//ATC; MTC
		{
			mode_ATC_MTC = (~mode_ATC_MTC)&0x01;
			SetTextValue(2,5,signal_type[analogIn1_type]); delay_ms(1);
			current_screen_id = 2;		//added at 20200414
			SetScreen(current_screen_id);
		}
		else if(control_id==1)
		{
			SetTextValue(0,5,signal_unit[analogIn1_type]);	delay_ms(1);
			SetTextValue(0,14,signal_type[analogIn1_type]);	delay_ms(1);
			SetTextValue(0,6,temper_mode[mode_ATC_MTC]);	delay_ms(1);
			//analogIn2_type = 5;
			current_screen_id = 1;
			SetScreen(current_screen_id);
		}
		delay_ms(1);
	}

	//-------------Analog output setting -------------------------------//
	else if(screen_id==4 || screen_id==101) 	//analog1 setting; ON
	{
		/*	if(control_id==9)		//phORP / temper
		{
			analog1_type = (~analog1_type)&0x01;
			if(analog1_type==ANALOG1_PHORP)
				AnimationPlayFrame(4,4,mode_pH_ORP);
			else if(analog1_type==ANALOG1_TEMPER)
				AnimationPlayFrame(4,4,2);
		} */
		if(control_id==3)	//ON; OFF
		{
			analog1_off_on = (~analog1_off_on)&0x01;
			current_screen_id = 5;
			SetScreen(current_screen_id);
		}
		else if(control_id==2)	//0~20 / 4~20
		{
			analog1_classify = (~analog1_classify)&0x01;
			AnimationPlayFrame(4,7,analog1_classify);
			AnimationPlayFrame(101,7,analog1_classify);
		}
		else if(control_id==1)	//complete
		{
			SaveParams();
			GetParams();
			current_screen_id = 1;
			SetScreen(current_screen_id);
		}
		delay_ms(1);
	}

	else if(screen_id==5) 	//analog1 setting; OFF
	{
		if(control_id==3)	//ON; OFF
		{
			analog1_off_on = (~analog1_off_on)&0x01;
			if(!mode_pH_ORP)		//0:pH
				current_screen_id = 4;
			else
				current_screen_id = 101;
			SetScreen(current_screen_id);
		}
		else if(control_id==1)
		{
			current_screen_id = 1;
			SetScreen(current_screen_id);
		}
		delay_ms(1);
	}

	else if(screen_id==6 || screen_id==102)		//analog2 setting; ON
	{
		if(control_id==3)	//ON; OFF
		{
			analog2_off_on = (~analog2_off_on)&0x01;
			current_screen_id = 7;
			SetScreen(current_screen_id);
		}
		else if(control_id==2)	//0~20; 4~20
		{
			analog2_classify = (~analog2_classify)&0x01;
			AnimationPlayFrame(6,7,analog2_classify);
			AnimationPlayFrame(102,7,analog2_classify);
		}
		else if(control_id==1)	//complete
		{
			SaveParams();
			GetParams();
			current_screen_id = 1;
			SetScreen(current_screen_id);
		}
		delay_ms(1);
	}
	else if(screen_id==7) 	//analog2 setting; OFF
	{
		if(control_id==3)	//ON; OFF
		{
			analog2_off_on = (~analog2_off_on)&0x01;
			if(!mode_pH_ORP)		//0:pH
				current_screen_id = 6;
			else
				current_screen_id = 102;
			SetScreen(current_screen_id);
		}
		else if(control_id==1)
		{
			current_screen_id = 1;
			SetScreen(current_screen_id);
		}
	}

	//-------------Analog input setting -------------------------------//
	/*else if(screen_id==88) 	//analogIn1 setting; ON
	{
		if(control_id==3)	//ON; OFF
			analogIn1_off_on = (~analogIn1_off_on)&0x01;
		else if(control_id==2)	//0~20 / 4~20
		{
			analogIn1_classify = (~analogIn1_classify)&0x01;
			AnimationPlayFrame(88,7,analogIn1_classify);
		}
		else if(control_id==1)	//complete
		{
			AnimationPlayFrame(0,5,analogIn1_type);		delay_ms(1);
			AnimationPlayFrame(0,14,analogIn1_type);	delay_ms(1);
		}
	}
	else if(screen_id==89) 	//analogIn1 setting; OFF
	{
		if(control_id==3)	//ON; OFF
			analogIn1_off_on = (~analogIn1_off_on)&0x01;
	}*/

	/*else if(screen_id==90) 	//analogIn2 setting; ON
	{
		if(control_id==3)	//ON; OFF
			analogIn2_off_on = (~analogIn2_off_on)&0x01;
		else if(control_id==2)	//0~20; 4~20
		{
			analogIn2_classify = (~analogIn2_classify)&0x01;
			AnimationPlayFrame(90,7,analogIn2_classify);
		}
		else if(control_id==1)	//complete
		{
			AnimationPlayFrame(0,6,analogIn2_type);		delay_ms(1);
		}
		delay_ms(1);
	}
	else if(screen_id==91) 	//analogIn2 setting; OFF
	{
		if(control_id==3)	//ON; OFF
			analogIn2_off_on = (~analogIn2_off_on)&0x01;
		else if(control_id==1)	//confirm
			analogIn2_type = 5;
	}*/
	//-------------RS485 output setting ------------------------//
	else if(screen_id==8) 	//RS485 baudrate setting
	{
		if(control_id==4)	//confirm
		{
			//RS485_Configuration(RS485_baudrate);
			SaveParams();
			GetParams();
			InitPetitModbus(dev_address, RS485_baudrate);
			current_screen_id = 1;
			SetScreen(current_screen_id);
		}
		else if(control_id==6)	//return
		{
			current_screen_id = 1;
			SetScreen(current_screen_id);
		}
	}
	//-------------Relay1, Relay2, Washer setting ------------------//
	else if(screen_id==9) 	//relay1 setting; ON
	{
		if(control_id==1)
		{
			SaveParams();
			GetParams();

			AnimationPlayFrame(0,8,0);	//RELAY1 Normal, at 20210728
			relay1_flag = 0;
			Relay1_Disable;
			current_screen_id = 1;
			SetScreen(current_screen_id);
		}
		else if(control_id==3)	//ON; OFF
		{
			relay1_off_on = (~relay1_off_on)&0x01;
			current_screen_id = 10;
			SetScreen(current_screen_id);
		}
		else if(control_id==2)	//low / high
		{
			relay1_classify = (~relay1_classify)&0x01;
			AnimationPlayFrame(9,7,relay1_classify); delay_ms(1);

			//added by shcn 11/3/2018

			if(relay1_classify==0)
			{
				if(analogIn1_type==0)
				{
					SetTextValueFloat2(9,5,relay1_point_ph_low[1]);	delay_ms(1);	//warning point
					SetTextValueFloat2(9,6,relay1_point_ph_low[0]);	delay_ms(1);	//margin
				}
				else
				{
					SetTextValueFloat2(9,5,relay1_point_orp_low[1]);	delay_ms(1);	//warning point
					SetTextValueFloat2(9,6,relay1_point_orp_low[0]);	delay_ms(1);	//margin
				}
			}
			else
			{
				if(analogIn1_type==0)
				{
					SetTextValueFloat2(9,5,relay1_point_ph_hi[1]);	delay_ms(1);	//warning point
					SetTextValueFloat2(9,6,relay1_point_ph_hi[0]);	delay_ms(1);	//margin
				}
				else
				{
					SetTextValueFloat2(9,5,relay1_point_orp_hi[1]);	delay_ms(1);	//warning point
					SetTextValueFloat2(9,6,relay1_point_orp_hi[0]);	delay_ms(1);	//margin
				}
			}
		}
	}
	else if(screen_id==10) 	//relay1 setting; OFF
	{
		if(control_id==3)	//ON; OFF
		{
			relay1_off_on = (~relay1_off_on)&0x01;
			current_screen_id = 9;
			SetScreen(current_screen_id);
		}
		else if(control_id==1)	//confirm
		{
			SaveParams();
			GetParams();

			AnimationPlayFrame(0,8,2);	//RELAY1 Inactive ,at 20210728
			relay1_flag = 0;
			Relay1_Disable;
			current_screen_id = 1;
			SetScreen(current_screen_id);
		}
	}
	else if(screen_id==11) 	//relay2 setting; ON
	{
		if(control_id==1)
		{
			SaveParams();
			GetParams();

			AnimationPlayFrame(0,9,0);	//RELAY2 Normal, at 20210728
			relay2_flag = 0;
			Relay2_Disable;
			current_screen_id = 1;
			SetScreen(current_screen_id);
		}
		else if(control_id==3)	//ON; OFF
		{
			relay2_off_on = (~relay2_off_on)&0x01;
			current_screen_id = 12;
			SetScreen(current_screen_id);
		}
		else if(control_id==2)	//low / high
		{
			relay2_classify = (~relay2_classify)&0x01;
			AnimationPlayFrame(11,7,relay2_classify);
			delay_ms(1);
			//added by shcn 11/3/2018

			if(relay2_classify==0)
			{
				if(analogIn1_type==0)
				{
					SetTextValueFloat2(11,5,relay2_point_ph_low[1]);	delay_ms(1);	//warning point
					SetTextValueFloat2(11,6,relay2_point_ph_low[0]);	delay_ms(1);	//margin
				}
				else
				{
					SetTextValueFloat2(11,5,relay2_point_orp_low[1]);	delay_ms(1);	//warning point
					SetTextValueFloat2(11,6,relay2_point_orp_low[0]);	delay_ms(1);	//margin
				}
			}
			else
			{
				if(analogIn1_type==0)
				{
					SetTextValueFloat2(11,5,relay2_point_ph_hi[1]);	delay_ms(1);	//warning point
					SetTextValueFloat2(11,6,relay2_point_ph_hi[0]);	delay_ms(1);	//margin
				}
				else
				{
					SetTextValueFloat2(11,5,relay2_point_orp_hi[1]);	delay_ms(1);	//warning point
					SetTextValueFloat2(11,6,relay2_point_orp_hi[0]);	delay_ms(1);	//margin
				}
			}
		}
	}
	else if(screen_id==12) 	//relay2 setting; OFF
	{
		if(control_id==3)	//ON; OFF
		{
			relay2_off_on = (~relay2_off_on)&0x01;
			current_screen_id = 11;
			SetScreen(current_screen_id);
		}
		else if(control_id==1)	//confirm
		{
			SaveParams();
			GetParams();

			AnimationPlayFrame(0,9,2);	//RELAY2 Inactive ,at 20210728
			relay2_flag = 0;
			Relay2_Disable;
			current_screen_id = 1;
			SetScreen(current_screen_id);
		}
	}

	else if(screen_id==13) 	//timer setting; ON
	{
		if(control_id==3)	//ON; OFF
		{
			timer_off_on = (~timer_off_on)&0x01;
			current_screen_id = 14;
			SetScreen(current_screen_id);
		}

		if(control_id==1)
		{
			SaveParams();
			GetParams();

			AnimationPlayFrame(0,10,0);	//WASH Normal	,at 20210728
			timer_flag = 0;
			WashTimer_Disable;
			current_screen_id = 1;
			SetScreen(current_screen_id);
		}
	}
	else if(screen_id==14) 	//timer setting; OFF
	{
		if(control_id==3)	//ON; OFF
		{
			timer_off_on = (~timer_off_on)&0x01;
			SetTextValueFloat2(13, 5, timer_point[1]); //at 20210816
			SetTextValueFloat2(13, 6, timer_point[0]);
			current_screen_id = 13;
			SetScreen(current_screen_id);
		}
		else if(control_id==1)	//confirm
		{
			SaveParams();
			GetParams();

			AnimationPlayFrame(0,10,2);	//WASH Inactive,at 20210728
			timer_flag = 0;
			WashTimer_Disable;
			current_screen_id = 1;
			SetScreen(current_screen_id);
		}
	}

	else if((screen_id==57) || (screen_id==59))		//calibrating main
	{
		if(control_id==3)	//AIN1
		{
			ACQ_Enable = 1;
			display_cnt = 0;

			switch(analogIn1_type)
			{
			case 0:	//pH
				//SetTextValueFloat2(95,2,Ain_real_raw[0]);
				current_screen_id = 103;	break;	//pH user calibration
			case 1:	//ORP
				//SetTextValueFloat(60,2,Ain_real_raw[0]);
				SetTextFlash(119, 4, 50);
				SetTextValueFloat(119, 4, ORP_calc_value);
				SetTextValueFloat(119, 3, calib_Ain_offset[0]); //at 20211006
				current_screen_id = 119;	break;
			case 5:	//temper
				//SetTextValueFloat(61,2,Ain_real_raw[0]);
				SetTextFlash(61, 2, 50);
				SetTextValueFloat(61, 2, temper_calc_value); //at 20210922
				SetTextValueFloat(61, 3, calib_Ain_offset[1]); //at 20211006
				current_screen_id = 61;	break;
			default:
				break;
			}
			analogIn_calib_ch = 0;
			SetScreen(current_screen_id);
		}
		else if(control_id==2)	//AIN2
		{
			ACQ_Enable = 1;
			display_cnt = 0;

			switch(analogIn2_type)
			{
			case 0:	//pH
				//SetTextValueFloat2(95,2,Ain_real_raw[1]);
				current_screen_id = 95;	break;
			case 1:	//ORP
				SetTextFlash(60, 2, 50);
				SetTextValueFloat(60, 2, ORP_calc_value);
				SetTextValueFloat(60, 3, calib_Ain_offset[0]); //at 20211006
				current_screen_id = 60;	break;
			case 5:	//temper
				SetTextFlash(61, 2, 50);
				SetTextValueFloat(61, 2, temper_calc_value);
				SetTextValueFloat(61, 3, calib_Ain_offset[1]); //at 20211006
				current_screen_id = 61;	break;
			default:
				break;
			}
			analogIn_calib_ch = 1;
			SetScreen(current_screen_id);
		}
		else if((control_id==1) || (control_id==4))	//return button
		{
			custom_calib_state = 0;
			delay_flag = 1;
			delay_count = 0;
			ACQ_Enable = 1;
			display_cnt = 0;
			if(control_id==4)
			{
				//TODO save parameters
				SaveParams();
				calib_return_timeout = 0;
			}
			current_screen_id = 0;
			SetScreen(current_screen_id);
		}
	}

	else if((screen_id>=19) && (screen_id<=27) && (control_id==2))	 	//continue button at calibration
	{
		switch(screen_id)
		{
		case 19:
			calib_pH_points = 0;	// single point
			calib_pH_mode = 0;		//0:World, 1:European, 2:Manual
			break;
		case 20:
			calib_pH_points = 0;
			calib_pH_mode = 1;
			break;
		case 21:
			calib_pH_points = 0;
			calib_pH_mode = 2;
			break;
		case 22:
			calib_pH_points = 1;	// 2 points
			calib_pH_mode = 0;		//0:World, 1:European, 2:Manual
			break;
		case 23:
			calib_pH_points = 1;
			calib_pH_mode = 1;
			break;
		case 24:
			calib_pH_points = 1;
			calib_pH_mode = 2;
			break;
		case 25:
			calib_pH_points = 2;	// 3 points
			calib_pH_mode = 0;		//0:World, 1:European, 2:Manual
			break;
		case 26:
			calib_pH_points = 2;
			calib_pH_mode = 1;
			break;
		case 27:
			calib_pH_points = 2;
			calib_pH_mode = 2;
			break;
		}

		if(calib_pH_mode == 0)
			calib_pH_value[0] = calib_pH_world_value[0];
		else if(calib_pH_mode == 1)
			calib_pH_value[0] = calib_pH_euro_value[0];
		else if(calib_pH_mode == 2)
			calib_pH_value[0] = calib_pH_manual_value[0];

		SetTextValueFloat2(28,3,calib_pH_value[0]);
	}



	///schn zuode
	else if(screen_id==19 && control_id==1)	 	//cancel button at calibration
	{

		if(mode_ATC_MTC == MEASURE_MODE_MTC)
		{
			AnimationPlayFrame(57,5,analogIn1_type);	delay_ms(1);
			//AnimationPlayFrame(57,6,analogIn2_type);	delay_ms(1);
			current_screen_id = 57;
			SetScreen(current_screen_id);
		}
		else if(mode_ATC_MTC == MEASURE_MODE_ATC)
		{
			AnimationPlayFrame(59,5,analogIn1_type);	delay_ms(1);
			AnimationPlayFrame(59,6,analogIn2_type);	delay_ms(1);
			current_screen_id = 59;
			SetScreen(current_screen_id);
		}
	}

	else if(current_screen_id==121)
	{
		if(control_id==1)
		{
			SaveParams();
			GetParams();
			if(mode_ATC_MTC == MEASURE_MODE_MTC)
			{
				AnimationPlayFrame(57,5,analogIn1_type);	delay_ms(1);
				//AnimationPlayFrame(57,6,analogIn2_type);	delay_ms(1);
				current_screen_id = 57;
				SetScreen(current_screen_id);
			}
			else if(mode_ATC_MTC == MEASURE_MODE_ATC)
			{
				AnimationPlayFrame(59,5,analogIn1_type);	delay_ms(1);
				AnimationPlayFrame(59,6,analogIn2_type);	delay_ms(1);
				current_screen_id = 59;
				SetScreen(current_screen_id);
			}
		}
	}

	else if(screen_id==103) //select "auto calib mode"
	{
		if(control_id==1) //confirm
		{
			if(mode_ATC_MTC == MEASURE_MODE_MTC)
			{
				AnimationPlayFrame(57,5,analogIn1_type);	delay_ms(1);
				//AnimationPlayFrame(57,6,analogIn2_type);	delay_ms(1);
				current_screen_id = 57;
				SetScreen(current_screen_id);
			}
			else if(mode_ATC_MTC == MEASURE_MODE_ATC)
			{
				AnimationPlayFrame(59,5,analogIn1_type);	delay_ms(1);
				AnimationPlayFrame(59,6,analogIn2_type);	delay_ms(1);
				current_screen_id = 59;
				SetScreen(current_screen_id);
			}
		}
		else if(control_id==2)	//NIST
		{
			calib_ph_mode = 0;
			current_screen_id = 104;
			SetScreen(current_screen_id);
		}
		else if(control_id==3)	//TECH
		{
			calib_ph_mode = 1;
			current_screen_id = 113;
			SetScreen(current_screen_id);
		}
		else if(control_id==4) //INPUT
		{
			calib_ph_mode = 2;
			SetTextValueFloat2(122, 3, buffer1);
			SetTextValueFloat2(123, 3, buffer2);
			SetTextValueFloat2(124, 3, buffer3);

			delay_ms(100);
			current_screen_id = 122;
			SetScreen(current_screen_id);
		}

		else if(control_id==6) //ph calib offset, at 20211119
		{
			SetTextFlash(80, 2, 50);
			SetTextValueFloat2(80, 2, pH_calc_value);
			SetTextValueFloat2(80, 3, pH_calib_offset);
			delay_ms(100);
			current_screen_id = 80;
			SetScreen(current_screen_id);
		}
		else if(control_id==5) //return
		{
			current_screen_id = 125;
			SetScreen(current_screen_id);
		}
	}

	else if(screen_id==130)
	{
		if(control_id==1)
		{
			current_screen_id = return_screen_id;
			SetScreen(current_screen_id);
		}
		if(control_id==2)
		{
			if(return_screen_id==104)
			{
				SetTextValue(107, 3, " - ");
				SetTextValue(107, 4, " - ");
				SetTextValue(107, 5, " - ");
				SetTextValue(107, 6, " - ");
				calib_count_up = 0;
				calib_stage_cnt = 0;
				calib_measure_flag = 1;
				calib_measure_cnt = 0;
				current_screen_id = 107;
				SetScreen(current_screen_id);
			}
			if(return_screen_id==105)
			{
				SetTextValue(109, 4, " - ");
				SetTextValue(109, 5, " - ");
				SetTextValue(109, 6, " - ");
				SetTextValue(109, 7, " - ");
				calib_count_up = 0;
				calib_stage_cnt = 0;
				calib_measure_flag = 1;
				calib_measure_cnt = 0;
				current_screen_id = 109;
				SetScreen(current_screen_id);
			}
			if(return_screen_id==106)
			{
				SetTextValue(111, 4, " - ");
				SetTextValue(111, 5, " - ");
				SetTextValue(111, 6, " - ");
				SetTextValue(111, 7, " - ");
				calib_count_up = 0;
				calib_stage_cnt = 0;
				calib_measure_flag = 1;
				calib_measure_cnt = 0;
				current_screen_id = 111;
				SetScreen(current_screen_id);
			}
			if(return_screen_id==113)
			{
				SetTextValue(107, 3, " - ");
				SetTextValue(107, 4, " - ");
				SetTextValue(107, 5, " - ");
				SetTextValue(107, 6, " - ");
				calib_count_up = 0;
				calib_stage_cnt = 0;
				calib_measure_flag = 1;
				calib_measure_cnt = 0;
				current_screen_id = 107;
				SetScreen(current_screen_id);
			}
			if(return_screen_id==114)
			{
				SetTextValue(109, 4, " - ");
				SetTextValue(109, 5, " - ");
				SetTextValue(109, 6, " - ");
				SetTextValue(109, 7, " - ");
				calib_count_up = 0;
				calib_stage_cnt = 0;
				calib_measure_flag = 1;
				calib_measure_cnt = 0;
				current_screen_id = 109;
				SetScreen(current_screen_id);
			}
			if(return_screen_id==115)
			{
				SetTextValue(111, 4, " - ");
				SetTextValue(111, 5, " - ");
				SetTextValue(111, 6, " - ");
				SetTextValue(111, 7, " - ");
				calib_count_up = 0;
				calib_stage_cnt = 0;
				calib_measure_flag = 1;
				calib_measure_cnt = 0;
				current_screen_id = 111;
				SetScreen(current_screen_id);
			}
			if(return_screen_id==122)
			{
				SetTextValue(107, 3, " - ");
				SetTextValue(107, 4, " - ");
				SetTextValue(107, 5, " - ");
				SetTextValue(107, 6, " - ");
				calib_count_up = 0;
				calib_stage_cnt = 0;
				calib_measure_flag = 1;
				calib_measure_cnt = 0;
				current_screen_id = 107;
				SetScreen(current_screen_id);
			}
			if(return_screen_id==123)
			{
				SetTextValue(109, 4, " - ");
				SetTextValue(109, 5, " - ");
				SetTextValue(109, 6, " - ");
				SetTextValue(109, 7, " - ");
				calib_count_up = 0;
				calib_stage_cnt = 0;
				calib_measure_flag = 1;
				calib_measure_cnt = 0;
				current_screen_id = 109;
				SetScreen(current_screen_id);
			}
			if(return_screen_id==124)
			{
				SetTextValue(111, 4, " - ");
				SetTextValue(111, 5, " - ");
				SetTextValue(111, 6, " - ");
				SetTextValue(111, 7, " - ");
				calib_count_up = 0;
				calib_stage_cnt = 0;
				calib_measure_flag = 1;
				calib_measure_cnt = 0;
				current_screen_id = 111;
				SetScreen(current_screen_id);
			}
		}
	}

	else if(screen_id==104)
	{
		if(control_id==1)
		{
			current_screen_id = 103;
			SetScreen(current_screen_id);
		}
		if(control_id==2)
		{
			if(mode_ATC_MTC == 0)
			{
				SetTextValue(107, 3, " - ");
				SetTextValue(107, 4, " - ");
				SetTextValue(107, 5, " - ");
				SetTextValue(107, 6, " - ");
				calib_count_up = 0;
				calib_stage_cnt = 0;
				calib_measure_flag = 1;
				calib_measure_cnt = 0;
				current_screen_id = 107;
				SetScreen(current_screen_id);
			}
			else
			{
				calib_manual_temperature = temper_manual;
				SetTextValue(130,3,"1");
				SetTextValueFloat(130,4,calib_manual_temperature);
				current_screen_id = 130;
				return_screen_id = 104;
				SetScreen(current_screen_id);
			}
		}
	}

	else if(screen_id==105)
	{
		if(control_id==1)
		{
			current_screen_id = 104;
			SetScreen(current_screen_id);
		}
		if(control_id==2)
		{
			if(mode_ATC_MTC == 0)
			{
				SetTextValue(109, 4, " - ");
				SetTextValue(109, 5, " - ");
				SetTextValue(109, 6, " - ");
				SetTextValue(109, 7, " - ");
				calib_count_up = 0;
				calib_stage_cnt = 0;
				calib_measure_flag = 1;
				calib_measure_cnt = 0;
				current_screen_id = 109;
				SetScreen(current_screen_id);
			}
			else
			{
				SetTextValue(130,3,"2");
				SetTextValueFloat(130,4,calib_manual_temperature);
				current_screen_id = 130;
				return_screen_id = 105;
				SetScreen(current_screen_id);
			}
		}
	}

	else if(screen_id==106)
	{
		if(control_id==1)
		{
			current_screen_id = 105;
			SetScreen(current_screen_id);
		}
		if(control_id==2)
		{
			if(mode_ATC_MTC == 0)
			{
				SetTextValue(111, 4, " - ");
				SetTextValue(111, 5, " - ");
				SetTextValue(111, 6, " - ");
				SetTextValue(111, 7, " - ");
				calib_count_up = 0;
				calib_stage_cnt = 0;
				calib_measure_flag = 1;
				calib_measure_cnt = 0;
				current_screen_id = 111;
				SetScreen(current_screen_id);
			}
			else
			{
				SetTextValue(130,3,"3");
				SetTextValueFloat(130,4,calib_manual_temperature);
				current_screen_id = 130;
				return_screen_id = 106;
				SetScreen(current_screen_id);
			}
		}
	}

	else if(screen_id==113)
	{
		if(control_id==1)
		{
			current_screen_id = 103;
			SetScreen(current_screen_id);
		}
		if(control_id==2)
		{
			if(mode_ATC_MTC == 0)
			{
				SetTextValue(107, 3, " - ");
				SetTextValue(107, 4, " - ");
				SetTextValue(107, 5, " - ");
				SetTextValue(107, 6, " - ");
				calib_count_up = 0;
				calib_stage_cnt = 0;
				calib_measure_flag = 1;
				calib_measure_cnt = 0;
				current_screen_id = 107;
				SetScreen(current_screen_id);
			}
			else
			{
				calib_manual_temperature = temper_manual;
				SetTextValue(130,3,"1");
				SetTextValueFloat(130,4,calib_manual_temperature);
				current_screen_id = 130;
				return_screen_id = 113;
				SetScreen(current_screen_id);
			}
		}
	}

	else if(screen_id==114)
	{
		if(control_id==1)
		{
			current_screen_id = 113;
			SetScreen(current_screen_id);
		}
		if(control_id==2)
		{
			if(mode_ATC_MTC == 0)
			{
				SetTextValue(109, 4, " - ");
				SetTextValue(109, 5, " - ");
				SetTextValue(109, 6, " - ");
				SetTextValue(109, 7, " - ");
				calib_count_up = 0;
				calib_stage_cnt = 0;
				calib_measure_flag = 1;
				calib_measure_cnt = 0;
				current_screen_id = 109;
				SetScreen(current_screen_id);
			}
			else
			{
				SetTextValue(130,3,"2");
				SetTextValueFloat(130,4,calib_manual_temperature);
				current_screen_id = 130;
				return_screen_id = 114;
				SetScreen(current_screen_id);
			}
		}
	}

	else if(screen_id==115)
	{
		if(control_id==1)
		{
			current_screen_id = 114;
			SetScreen(current_screen_id);
		}
		if(control_id==2)
		{
			if(mode_ATC_MTC == 0)
			{
				SetTextValue(111, 4, " - ");
				SetTextValue(111, 5, " - ");
				SetTextValue(111, 6, " - ");
				SetTextValue(111, 7, " - ");
				calib_count_up = 0;
				calib_stage_cnt = 0;
				calib_measure_flag = 1;
				calib_measure_cnt = 0;
				current_screen_id = 111;
				SetScreen(current_screen_id);
			}
			else
			{
				SetTextValue(130,3,"3");
				SetTextValueFloat(130,4,calib_manual_temperature);
				current_screen_id = 130;
				return_screen_id = 115;
				SetScreen(current_screen_id);
			}
		}
	}

	else if(screen_id==122)
	{
		if(control_id==1)
		{
			current_screen_id = 103;
			SetScreen(current_screen_id);
		}
		if(control_id==2)
		{
			if(mode_ATC_MTC == 0)
			{
				SetTextValue(107, 3, " - ");
				SetTextValue(107, 4, " - ");
				SetTextValue(107, 5, " - ");
				SetTextValue(107, 6, " - ");
				calib_count_up = 0;
				calib_stage_cnt = 0;
				calib_measure_flag = 1;
				calib_measure_cnt = 0;
				current_screen_id = 107;
				SetScreen(current_screen_id);
			}
			else
			{
				calib_manual_temperature = temper_manual;
				SetTextValue(130,3,"1");
				SetTextValueFloat(130,4,calib_manual_temperature);
				current_screen_id = 130;
				return_screen_id = 122;
				SetScreen(current_screen_id);
			}
		}
	}

	else if(screen_id==123)
	{
		if(control_id==1)
		{
			current_screen_id = 113;
			SetScreen(current_screen_id);
		}
		if(control_id==2)
		{
			if(mode_ATC_MTC == 0)
			{
				SetTextValue(109, 4, " - ");
				SetTextValue(109, 5, " - ");
				SetTextValue(109, 6, " - ");
				SetTextValue(109, 7, " - ");
				calib_count_up = 0;
				calib_stage_cnt = 0;
				calib_measure_flag = 1;
				calib_measure_cnt = 0;
				current_screen_id = 109;
				SetScreen(current_screen_id);
			}
			else
			{
				SetTextValue(130,3,"2");
				SetTextValueFloat(130,4,calib_manual_temperature);
				current_screen_id = 130;
				return_screen_id = 123;
				SetScreen(current_screen_id);
			}
		}
	}

	else if(screen_id==124)
	{
		if(control_id==1)
		{
			current_screen_id = 114;
			SetScreen(current_screen_id);
		}
		if(control_id==2)
		{
			if(mode_ATC_MTC == 0)
			{
				SetTextValue(111, 4, " - ");
				SetTextValue(111, 5, " - ");
				SetTextValue(111, 6, " - ");
				SetTextValue(111, 7, " - ");
				calib_count_up = 0;
				calib_stage_cnt = 0;
				calib_measure_flag = 1;
				calib_measure_cnt = 0;
				current_screen_id = 111;
				SetScreen(current_screen_id);
			}
			else
			{
				SetTextValue(130,3,"3");
				SetTextValueFloat(130,4,calib_manual_temperature);
				current_screen_id = 130;
				return_screen_id = 124;
				SetScreen(current_screen_id);
			}
		}
	}

	else if(screen_id==125)
	{
		if(control_id==1)
		{
			current_screen_id = 103;
			SetScreen(current_screen_id);
		}
		if(control_id==2)
		{
			calib_pH_slope[0] = 1.0f;
			calib_pH_slope[1] = 1.0f;
			calib_pH_offset[0] = 0.0f;
			calib_pH_offset[1] = 0.0f;
			SaveParams();
			GetParams();
			current_screen_id = 103;
			SetScreen(current_screen_id);
		}
	}

	else if(screen_id==107) //1st point, at 20201130
	{
		if(control_id==1)
		{
			if(mode_ATC_MTC == 0)
				temperature1 = temper_calc_value;
			else
				temperature1 = calib_manual_temperature;
			SetTextValueFloat2(108, 4, ORP_calc_value);
			SetTextValueFloat2(108, 5, temperature1);
			SetTextValueInt32(108, 6, calib_count_up);
			SetTextValueFloat2(108, 7, buffer1);

			current_screen_id = 108;
			SetScreen(current_screen_id);
		}
	}

	else if(screen_id==108)
	{
		if(control_id==1)
		{
			if(calib_ph_mode == 0)
			{
				current_screen_id = 104;
				SetScreen(current_screen_id);
			}
			else if(calib_ph_mode == 1)
			{
				current_screen_id = 113;
				SetScreen(current_screen_id);
			}
			else if(calib_ph_mode == 2)
			{
				current_screen_id = 122;
				SetScreen(current_screen_id);
			}
		}
		if(control_id==2)
		{
			if(calib_ph_mode == 0)
			{
				current_screen_id = 105;
				SetScreen(current_screen_id);
			}
			else if(calib_ph_mode == 1)
			{
				current_screen_id = 114;
				SetScreen(current_screen_id);
			}
			else if(calib_ph_mode == 2)
			{
				current_screen_id = 123;
				SetScreen(current_screen_id);
			}
		}
		if(control_id==3)
		{
			uint8_t temper_error = 0;

			if(temperature1 < 0.0f || temperature1 > 95.0f)
			{
				temper_error = 1;
			}	//repaired at 20200707

			if(temper_error == 0)
			{
				SetTextValueFloat2(116, 3, buffer1);
				SetTextValueFloat2(116, 5, temperature1);
				SetTextValueFloat(116, 11, calib_pH_mV[0]);

				measured_ph[0] = mV2pH(calib_pH_mV[0], temperature1);
				SetTextValueFloat2(116, 6, measured_ph[0]);

				if(calib_ph_mode == 0)
				{
					calib_pH_slope[0] = 1.0f;
					calib_pH_slope[1] = 1.0f;
					calib_pH_offset[0] = select_real_ph_nist(buffer1, temperature1) - calib_pH_slope[0] * measured_ph[0];
					calib_pH_offset[1] = calib_pH_offset[0];
				}
				else if(calib_ph_mode == 1)
				{
					calib_pH_slope[0] = 1.0f;
					calib_pH_slope[1] = 1.0f;
					calib_pH_offset[0] = select_real_ph_tech(buffer1, temperature1) - calib_pH_slope[0] * measured_ph[0];
					calib_pH_offset[1] = calib_pH_offset[0];
				}
				else
				{
					calib_pH_slope[0] = 1.0f;
					calib_pH_slope[1] = 1.0f;
					//		calib_pH_offset[0] = pHcompTemper(buffer1, temperature1) - calib_pH_slope[0] * measured_ph[0];
					calib_pH_offset[0] = buffer1 - calib_pH_slope[0] * measured_ph[0];
					calib_pH_offset[1] = calib_pH_offset[0];
				}
				zero_point = (7.0f - calib_pH_offset[0])/calib_pH_slope[0];
				ph_second_point =  zero_point;		//added at 20200706
				SetTextValueFloat2(116, 8, zero_point);

				if((calib_pH_slope[0] - 1.0f) * (calib_pH_slope[0] - 1.0f) > VALID_SLOPE || (calib_pH_slope[1] - 1.0f) * (calib_pH_slope[1] - 1.0f) > VALID_SLOPE)
				{
					SetTextValue(66, 4, "1");
					current_screen_id = 66;
					SetScreen(current_screen_id);
				}
				else if((zero_point - 7.0) * (zero_point - 7.0) > 1 && (calib_ph_mode == 0 || calib_ph_mode == 1))
				{
					SetTextValue(126, 4, "1");
					current_screen_id = 126;
					SetScreen(current_screen_id);
				}
				else
				{
					mV2ph_coeff[0] = 0.1984f*(273.16f+temperature1);
					mV2ph_coeff[1] = mV2ph_coeff[0];
					SetTextValueFloat2(116, 9, mV2ph_coeff[1]); //at 20211214
					SetTextValueFloat2(116, 4, 100*mV2ph_coeff[1]/mV2ph_coeff[0]);
					//SetTextValueFloat2(116, 9, 59.16/calib_pH_slope[0]); //at 20210816
					//SetTextValueFloat2(116, 4, 100/calib_pH_slope[0]);
					DispCalibTimeIdx(116, 10);

					calib_year = now_year;
					calib_month = now_month;
					calib_day = now_day;
					calib_hour = now_hour;
					calib_minute = now_minute;
					calib_sec = now_sec;
					calib_mode = calib_ph_mode;
					calib_buffer1 = buffer1;
					calib_buffer2 = 0;
					calib_buffer3 = 0;
					calib_temperature = temperature1;
					calib_point_number = 1;

					current_screen_id = 116;
					SetScreen(current_screen_id);	//calib report for single point
				}
			}
			else
			{
				SetTextValue(64,4,"1");
				return_screen_id = 103;
				current_screen_id = 64;
				SetScreen(current_screen_id);
			}
		}
	}

	else if(screen_id==109) //2nd point, at 20201130
	{
		if(control_id==1)
		{
			if(buffer1 != buffer2)
			{
				if(mode_ATC_MTC == 0)
					temperature2 = temper_calc_value;
				else
					temperature2 = calib_manual_temperature;
				SetTextValueFloat2(110, 4, ORP_calc_value);
				SetTextValueFloat2(110, 5, temperature2);
				SetTextValueInt32(110, 6, calib_count_up);
				SetTextValueFloat2(110, 7, buffer2);

				current_screen_id = 110;
				SetScreen(current_screen_id);
			}
			else
			{
				current_screen_id = 129;
				SetTextValue(129, 3, "2");
				SetScreen(current_screen_id);
			}
		}
	}

	else if(screen_id==110)
	{
		if(control_id==1)
		{
			if(calib_ph_mode == 0)
			{
				current_screen_id = 105;
				SetScreen(current_screen_id);
			}
			else if(calib_ph_mode == 1)
			{
				current_screen_id = 114;
				SetScreen(current_screen_id);
			}
			else if(calib_ph_mode == 2)
			{
				current_screen_id = 123;
				SetScreen(current_screen_id);
			}
		}
		if(control_id==2)
		{
			if(calib_ph_mode == 0)
			{
				current_screen_id = 106;
				SetScreen(current_screen_id);
			}
			else if(calib_ph_mode == 1)
			{
				current_screen_id = 115;
				SetScreen(current_screen_id);
			}
			else if(calib_ph_mode == 2)
			{
				current_screen_id = 124;
				SetScreen(current_screen_id);
			}
		}
		if(control_id==3)
		{
			uint8_t temper_error = 0;

			if(temperature1 < 0.0f || temperature1 > 95.0f || temperature2 < 0.0f || temperature2 > 95.0f)
			{
				temper_error = 1;
			}	//repaired at 20200707

			if(temper_error == 0)
			{
				SetTextValueFloat2(117, 3, buffer1);
				SetTextValueFloat2(117, 4, buffer2);
				SetTextValueFloat2(117, 5, temperature1);
				SetTextValueFloat(117, 11, calib_pH_mV[0]);
				SetTextValueFloat(117, 12, calib_pH_mV[1]);

				if(calib_ph_mode == 0)
				{
					measured_ph[0] = select_real_ph_nist(buffer1,temperature1);
					measured_ph[1] = select_real_ph_nist(buffer2,temperature2);
				}
				else if(calib_ph_mode == 1)
				{
					measured_ph[0] = select_real_ph_tech(buffer1,temperature1);
					measured_ph[1] = select_real_ph_tech(buffer2,temperature2);
				}
				else
				{
					//		calib_pH_slope[0] = (pHcompTemper(buffer1,temperature1) - pHcompTemper(buffer2, temperature2)) / (measured_ph[0] - measured_ph[1]);	//a=(y0-y1)/(x0-x1)
					//		calib_pH_offset[0] = pHcompTemper(buffer1,temperature1) - measured_ph[0] * calib_pH_slope[0];	//b=y0-x0*a
					measured_ph[0] = buffer1;
					measured_ph[1] = buffer2;
				}
				calib_pH_slope[0] = (measured_ph[0] - measured_ph[1]) / (mV2pH(calib_pH_mV[0], temperature1) - mV2pH(calib_pH_mV[1], temperature2));	//a=(y0-y1)/(x0-x1)
				calib_pH_offset[0] = measured_ph[0] - mV2pH(calib_pH_mV[0], temperature1) * calib_pH_slope[0];	//b=y0-x0*a

				calib_pH_slope[1] = calib_pH_slope[0];		//Neg = Pos
				calib_pH_offset[1] = calib_pH_offset[0];	//Neg = Pos
				zero_point = (7.0f - calib_pH_offset[0])/calib_pH_slope[0];
				ph_second_point =  zero_point;		//added at 20200706
				SetTextValueFloat2(117, 8, zero_point);

				SetTextValueFloat2(117, 6, measured_ph[0]);
				SetTextValueFloat2(117, 7, measured_ph[1]);

				mV2ph_coeff[0] = 0.1984f*(273.16f+temperature1);
				mV2ph_coeff[1] = (calib_pH_mV[0]-calib_pH_mV[1])/(measured_ph[1]-measured_ph[0]);
				SetTextValueFloat2(117, 9, mV2ph_coeff[1]); //at 20211214
				SetTextValueFloat2(117, 13, 100*mV2ph_coeff[1]/mV2ph_coeff[0]); //100*S1/S0
				//SetTextValueFloat2(117, 9, 59.16/calib_pH_slope[0]); //at 20210816
				//SetTextValueFloat2(117, 13, 100.0f/calib_pH_slope[0]);

				DispCalibTimeIdx(117, 10);
				if((calib_pH_slope[0] - 1.0f) * (calib_pH_slope[0] - 1.0f) > VALID_SLOPE || (calib_pH_slope[1] - 1.0f) * (calib_pH_slope[1] - 1.0f) > VALID_SLOPE)
				{
					SetTextValue(66, 4, "2");
					current_screen_id = 66;
					SetScreen(current_screen_id);
				}
				else if((zero_point - 7.0) * (zero_point - 7.0) > 1 && (calib_ph_mode == 0 || calib_ph_mode == 1))
				{
					SetTextValue(126, 4, "2");
					current_screen_id = 126;
					SetScreen(current_screen_id);
				}
				else
				{
					calib_year = now_year;
					calib_month = now_month;
					calib_day = now_day;
					calib_hour = now_hour;
					calib_minute = now_minute;
					calib_sec = now_sec;
					calib_mode = calib_ph_mode;
					calib_buffer1 = buffer1;
					calib_buffer2 = buffer2;
					calib_buffer3 = 0;
					calib_temperature = temperature1;
					calib_point_number = 2;
					current_screen_id = 117;
					SetScreen(current_screen_id);
				}
			}
			else
			{
				SetTextValue(64,4,"2");
				return_screen_id = 103;
				current_screen_id = 64;
				SetScreen(current_screen_id);
			}
		}
	}

	else if(screen_id==111) //3th point, at 20201130
	{
		if(control_id==1)
		{
			if(buffer3 != buffer2 && buffer3 != buffer1)
			{
				if(mode_ATC_MTC == 0)
					temperature3 = temper_calc_value;
				else
					temperature3 = calib_manual_temperature;
				calib_pH_value[2] = pHcompTemper(calib_pH_value[2], temper_calc_value);
				SetTextValueFloat2(112, 4, ORP_calc_value);
				SetTextValueFloat2(112, 5, temperature3);
				SetTextValueInt32(112, 6, calib_count_up);
				SetTextValueFloat2(112, 7, buffer3);

				current_screen_id = 112;
				SetScreen(current_screen_id);
			}
			else
			{
				current_screen_id = 129;
				SetTextValue(129, 3, "3");
				SetScreen(current_screen_id);
			}
		}
	}

	else if(screen_id==112)
	{
		if(control_id==1)
		{
			if(calib_ph_mode == 0)
			{
				current_screen_id = 106;
				SetScreen(current_screen_id);
			}
			else
			{
				current_screen_id = 115;
				SetScreen(current_screen_id);
			}
		}
		if(control_id==2)
		{
			float calc_buffer[3];
			float calc_measured_ph[3];
			float calc_calib_pH_mV[3];
			//float zero_point = 0.0f;
			uint8_t i, j;
			uint8_t temper_error = 0;

			if(temperature1 < 0.0f || temperature1 > 95.0f || temperature2 < 0.0f || temperature2 > 95.0f || temperature3 < 0.0f || temperature3 > 95.0f)
			{
				temper_error = 1;
			}		//repaired at 20200707

			if(temper_error == 0)
			{
				SetTextValueFloat2(118, 3, buffer1);
				SetTextValueFloat2(118, 4, buffer2);
				SetTextValueFloat2(118, 13, buffer3);

				SetTextValueFloat2(118, 5, temperature1);
				SetTextValueFloat(118, 11, calib_pH_mV[0]);
				SetTextValueFloat(118, 12, calib_pH_mV[1]);
				SetTextValueFloat(118, 18, calib_pH_mV[2]);

				if(calib_ph_mode  == 0)
				{
					calc_buffer[0] = select_real_ph_nist(buffer1, temperature1);
					calc_buffer[1] = select_real_ph_nist(buffer2, temperature2);
					calc_buffer[2] = select_real_ph_nist(buffer3, temperature3);
				}
				else if(calib_ph_mode  == 1)
				{
					calc_buffer[0] = select_real_ph_tech(buffer1, temperature1);
					calc_buffer[1] = select_real_ph_tech(buffer2, temperature2);
					calc_buffer[2] = select_real_ph_tech(buffer3, temperature3);
				}
				else
				{
					/*		calc_buffer[0] = pHcompTemper(buffer1, temperature1);
					calc_buffer[1] = pHcompTemper(buffer2, temperature2);
					calc_buffer[2] = pHcompTemper(buffer3, temperature3); */
					calc_buffer[0] = buffer1;
					calc_buffer[1] = buffer2;
					calc_buffer[2] = buffer3;
				}

				measured_ph[0] = calc_buffer[0];
				measured_ph[1] = calc_buffer[1];
				measured_ph[2] = calc_buffer[2];
				SetTextValueFloat2(118, 6, measured_ph[0]);
				SetTextValueFloat2(118, 7, measured_ph[1]);
				SetTextValueFloat2(118, 8, measured_ph[2]);

				calc_measured_ph[0] = mV2pH(calib_pH_mV[0], temperature1);
				calc_measured_ph[1] = mV2pH(calib_pH_mV[1], temperature2);
				calc_measured_ph[2] = mV2pH(calib_pH_mV[2], temperature3);
				calc_calib_pH_mV[0] = calib_pH_mV[0];
				calc_calib_pH_mV[1] = calib_pH_mV[1];
				calc_calib_pH_mV[2] = calib_pH_mV[2];

				for(i = 0; i < 3; i++)
				{
					for(j = i + 1; j < 3; j++)
					{
						if(calc_buffer[i] > calc_buffer[j])
						{
							float temp;
							temp = calc_buffer[i];
							calc_buffer[i] = calc_buffer[j];
							calc_buffer[j] = temp;
							temp = calc_measured_ph[i];
							calc_measured_ph[i] = calc_measured_ph[j];
							calc_measured_ph[j] = temp;
							temp = calc_calib_pH_mV[i];
							calc_calib_pH_mV[i] = calc_calib_pH_mV[j];
							calc_calib_pH_mV[j] = temp;
						}
					}
				}

				calib_pH_slope[0] = (calc_buffer[0] - calc_buffer[1]) / (calc_measured_ph[0] - calc_measured_ph[1]);	//a=(y0-y1)/(x0-x1)
				calib_pH_offset[0] = calc_buffer[0] - calc_measured_ph[0] * calib_pH_slope[0];	//b=y0-x0*a
				calib_pH_slope[1] = (calc_buffer[1] - calc_buffer[2]) / (calc_measured_ph[1] - calc_measured_ph[2]);	//a=(y0-y1)/(x0-x1)
				calib_pH_offset[1] = calc_buffer[1] - calc_measured_ph[1] * calib_pH_slope[1];	//b=y0-x0*a

				zero_point = (7.0f - calib_pH_offset[0])/calib_pH_slope[0];		//repaired by kjh at 20200226
				ph_second_point =  zero_point;		//added at 20200706
				SetTextValueFloat2(118, 9, zero_point);

				mV2ph_coeff[0] = 0.1984f*(273.16f+temperature1);
				mV2ph_coeff[1] = (calc_calib_pH_mV[0]-calc_calib_pH_mV[1])/(calc_buffer[1]-calc_buffer[0]);
				SetTextValueFloat2(118, 14, mV2ph_coeff[1]); //acid, at 20211214
				SetTextValueFloat2(118, 16, 100*mV2ph_coeff[1]/mV2ph_coeff[0]); //100*S1/S0
				mV2ph_coeff[2] = (calc_calib_pH_mV[1]-calc_calib_pH_mV[2])/(calc_buffer[2]-calc_buffer[1]);
				SetTextValueFloat2(118, 15, mV2ph_coeff[2]); //alkari
				SetTextValueFloat2(118, 17, 100*mV2ph_coeff[2]/mV2ph_coeff[0]); //100*S1/S0
				//				SetTextValueFloat2(118, 14, 59.16/calib_pH_slope[0]); //at 20210816
				//				SetTextValueFloat2(118, 16, 100.0f/calib_pH_slope[0]);
				//				SetTextValueFloat2(118, 15, 59.16/calib_pH_slope[1]);
				//				SetTextValueFloat2(118, 17, 100.0f/calib_pH_slope[1]);

				DispCalibTimeIdx(118, 10);
				if((calib_pH_slope[0] - 1.0f) * (calib_pH_slope[0] - 1.0f) > VALID_SLOPE || (calib_pH_slope[1] - 1.0f) * (calib_pH_slope[1] - 1.0f) > VALID_SLOPE)
				{
					SetTextValue(66, 4, "3");
					current_screen_id = 66;
					SetScreen(current_screen_id);
				}
				else if((zero_point - 7.0) * (zero_point - 7.0) > 1 && (calib_ph_mode == 0 || calib_ph_mode == 1))
				{
					SetTextValue(126, 4, "2");
					current_screen_id = 126;
					SetScreen(current_screen_id);
				}
				else
				{
					calib_year = now_year;
					calib_month = now_month;
					calib_day = now_day;
					calib_hour = now_hour;
					calib_minute = now_minute;
					calib_sec = now_sec;
					calib_mode = calib_ph_mode;
					calib_buffer1 = buffer1;
					calib_buffer2 = buffer2;
					calib_buffer3 = buffer3;
					calib_temperature = temperature1;
					calib_point_number = 3;
					current_screen_id = 118;
					SetScreen(current_screen_id);
				}
			}
		}
		else
		{
			SetTextValue(64,4,"3");
			return_screen_id = 103;
			current_screen_id = 64;
			SetScreen(current_screen_id);
		}
	}

	else if(screen_id==116)
	{
		if(control_id==1)
		{
			GetParams();
			custom_calib_state = 0;
			delay_flag = 1;
			delay_count = 0;
			current_screen_id = 0;
			SetScreen(current_screen_id);
		}
		if(control_id==2)
		{
			SaveParams();
			GetParams();

			/*********** Calibration Information *************/
			SetTextValueInt32(127,2,calib_point_number);
			SetTextValue(127,11,calib_mode_str[calib_mode]);
			if(calib_point_number == 1)
				sprintf(buffer_str, "%.2f", calib_buffer1);
			else if(calib_point_number == 2)
				sprintf(buffer_str, "%.2f, %.2f", calib_buffer1, calib_buffer2);
			else
				sprintf(buffer_str, "%.2f, %.2f, %.2f", calib_buffer1, calib_buffer2, calib_buffer3);
			SetTextValue(127,3,buffer_str);
			DispLastCalibTime(127,4);
			SetTextValueFloat2(127,5,7.0f * calib_pH_slope[0]+ calib_pH_offset[0]);
			SetTextValueFloat(127,18, calib_temperature);

			SetTextValueFloat2(127,6, mV2ph_coeff[1]); //acid, at 20211214
			SetTextValueFloat(127,13, 100*mV2ph_coeff[1]/mV2ph_coeff[0]);
			SetTextValueFloat2(127,8, mV2ph_coeff[2]); //alkari
			SetTextValueFloat(127,16, 100*mV2ph_coeff[2]/mV2ph_coeff[0]);

			custom_calib_state = 0;
			delay_flag = 1;
			delay_count = 0;
			calib_return_timeout = 0;
			current_screen_id = 0;
			SetScreen(current_screen_id);
		}
	}

	else if(screen_id==117)
	{
		if(control_id==1)
		{
			GetParams();
			custom_calib_state = 0;
			delay_flag = 1;
			delay_count = 0;
			current_screen_id = 0;
			SetScreen(current_screen_id);
		}
		if(control_id==2)
		{
			SaveParams();
			GetParams();

			/*********** Calibration Information *************/
			SetTextValueInt32(127,2,calib_point_number);
			SetTextValue(127,11,calib_mode_str[calib_mode]);
			if(calib_point_number == 1)
				sprintf(buffer_str, "%.2f", calib_buffer1);
			else if(calib_point_number == 2)
				sprintf(buffer_str, "%.2f, %.2f", calib_buffer1, calib_buffer2);
			else
				sprintf(buffer_str, "%.2f, %.2f, %.2f", calib_buffer1, calib_buffer2, calib_buffer3);
			SetTextValue(127,3,buffer_str);
			DispLastCalibTime(127,4);
			SetTextValueFloat2(127,5,7.0f * calib_pH_slope[0]+ calib_pH_offset[0]);
			SetTextValueFloat(127,18,calib_temperature);

			SetTextValueFloat2(127,6, mV2ph_coeff[1]); //acid, at 20211214
			SetTextValueFloat(127,13, 100*mV2ph_coeff[1]/mV2ph_coeff[0]);
			SetTextValueFloat2(127,8, mV2ph_coeff[2]); //alkari
			SetTextValueFloat(127,16, 100*mV2ph_coeff[2]/mV2ph_coeff[0]);

			custom_calib_state = 0;
			delay_flag = 1;
			delay_count = 0;
			calib_return_timeout = 0;
			current_screen_id = 0;
			SetScreen(current_screen_id);
		}
	}

	else if(screen_id==118)
	{
		if(control_id==1)
		{
			GetParams();
			custom_calib_state = 0;
			delay_flag = 1;
			delay_count = 0;
			current_screen_id = 0;
			SetScreen(current_screen_id);
		}
		if(control_id==2)
		{
			SaveParams();
			GetParams();

			/*********** Calibration Information *************/
			SetTextValueInt32(127,2,calib_point_number);
			SetTextValue(127,11,calib_mode_str[calib_mode]);
			if(calib_point_number == 1)
				sprintf(buffer_str, "%.2f", calib_buffer1);
			else if(calib_point_number == 2)
				sprintf(buffer_str, "%.2f, %.2f", calib_buffer1, calib_buffer2);
			else
				sprintf(buffer_str, "%.2f, %.2f, %.2f", calib_buffer1, calib_buffer2, calib_buffer3);
			SetTextValue(127,3,buffer_str);
			DispLastCalibTime(127,4);
			SetTextValueFloat2(127,5,7.0f * calib_pH_slope[0]+ calib_pH_offset[0]);
			SetTextValueFloat(127,18,calib_temperature);

			SetTextValueFloat2(127,6, mV2ph_coeff[1]); //acid, at 20211214
			SetTextValueFloat(127,13, 100*mV2ph_coeff[1]/mV2ph_coeff[0]);
			SetTextValueFloat2(127,8, mV2ph_coeff[2]); //alkari
			SetTextValueFloat(127,16, 100*mV2ph_coeff[2]/mV2ph_coeff[0]);

			custom_calib_state = 0;
			delay_flag = 1;
			delay_count = 0;
			calib_return_timeout = 0;
			current_screen_id = 0;
			SetScreen(current_screen_id);
		}
	}

	else if(screen_id==60)
	{
		if(control_id==1)
		{
			if(mode_ATC_MTC == MEASURE_MODE_MTC)
			{
				AnimationPlayFrame(57,5,analogIn1_type);	delay_ms(1);
				//AnimationPlayFrame(57,6,analogIn2_type);	delay_ms(1);
				current_screen_id = 57;
				SetScreen(current_screen_id);
			}
			else if(mode_ATC_MTC == MEASURE_MODE_ATC)
			{
				AnimationPlayFrame(59,5,analogIn1_type);	delay_ms(1);
				AnimationPlayFrame(59,6,analogIn2_type);	delay_ms(1);
				current_screen_id = 59;
				SetScreen(current_screen_id);
			}
		}
	}

	else if(screen_id==119)
	{
		if(control_id==1)
		{
			AnimationPlayFrame(57,5,analogIn1_type);	delay_ms(1);
			//AnimationPlayFrame(57,6,analogIn2_type);	delay_ms(1);
			current_screen_id = 57;
			SetScreen(current_screen_id);
		}
		if(control_id==2)
		{
			orp_process_count = 0;
			current_screen_id = 120;
			SetScreen(current_screen_id);
		}
	}

	else if(screen_id==28) 	//1st point calibration prepare
	{
		if(control_id==2)	//continue button
		{
			if(mode_ATC_MTC==MEASURE_MODE_ATC)
			{
				SetTextFlash(67,2,50);		//500ms
				current_screen_id = 67;
				calib_measure_cnt = 0;
				calib_measure_flag = 1;
				SetScreen(67);
			}
			else if(mode_ATC_MTC==MEASURE_MODE_MTC)
			{
				SetScreen(68);
			}
		}
	}
	else if(screen_id==67)	//temper measure for calib
	{
		if(control_id==1)			//return
		{
			calib_measure_flag = 0;
			SetScreen(19);
		}
	}
	else if(screen_id==68)	//temper manual input for calib
	{
		if(control_id==1)			//return
		{
			calib_measure_flag = 0;
			SetScreen(19);
		}
		else if(control_id==3)	//continue
		{
			current_screen_id = 68;
			SetTextValue(64,4,"1");
			calib_pH_index = GetpHClass(calib_pH_value[0]);

			if((temper_calib_manual[0]<0.0f) || (temper_calib_manual[0]>95.0f))		//repaired at 20200707, 90
				SetScreen(64);
			//			else if((temper_calib_manual[0]>50) &&
			//				((calib_pH_index==1) || (calib_pH_index==4) || (calib_pH_index==5) || (calib_pH_index==7) || (calib_pH_index==8)))
			//			{
			//					SetScreen(64);
			//			}
			else
			{
				calib_measure_cnt = 0;
				calib_measure_flag = 1;

				SetTextFlash(29,1,50);		//500ms
				current_screen_id = 29;
				return_screen_id = 28;
				calib_count_down = 300;
				SetScreen(29);
			}
		}
	}

	else if(screen_id==64)	//calib temper overlay error
	{
		if(control_id==1)		//return
		{
			calib_measure_flag = 1;
			current_screen_id = return_screen_id;
			SetScreen(current_screen_id);
		}
	}
	else if(screen_id==65)	//calib mV unstable error
	{
		if(control_id==1)		//return
		{
			calib_measure_flag = 1;
			current_screen_id = return_screen_id;
			SetScreen(return_screen_id);
		}
	}
	else if(screen_id==66)	//calib pH slope overlay error
	{
		if(control_id==1)		//return
		{
			calib_measure_flag = 1;
			current_screen_id = 103;
			SetScreen(current_screen_id);
		}
	}
	else if(screen_id==126)
	{
		if(control_id==1)		//return
		{
			calib_measure_flag = 1;
			current_screen_id = 103;
			SetScreen(current_screen_id);
		}
	}
	else if(screen_id==74)	//calib temper unstable error
	{
		if(control_id==1)		//return
		{
			calib_measure_flag = 1;
			SetScreen(current_screen_id);
		}
	}
	else if(screen_id==75)	//calib mV overlay error
	{
		if(control_id==1)		//return
		{
			calib_measure_flag = 1;
			SetScreen(return_screen_id);
		}

	}

	else if(screen_id==29) 	//1st point measure
	{
		if(control_id==2)		//return
		{
			calib_measure_flag = 0;
			SetScreen(19);
		}
		if(control_id==6)	  //skip
		{
			calib_count_down = 0;
		}
	}

	else if(screen_id==30) 	//1st point complete
	{
		if(control_id==2)	//continue button
		{
			if(calib_pH_points == 0)
			{
				if(mode_ATC_MTC==MEASURE_MODE_ATC)
				{
					SetTextValueFloat(37,3,temper_calc_value);
					calib_slope = 0.1984f*(273.16f+temper_calc_value);
				}
				else if(mode_ATC_MTC==MEASURE_MODE_MTC)
				{
					SetTextValueFloat(37,3,temper_calib_manual[0]);
					calib_slope = 0.1984f*(273.16f+temper_calib_manual[0]);
				}
				calib_slope = calib_slope*100.0f/59.154f;
				SetTextValueFloat(37,4,calib_slope);	delay_ms(1);
				SetTextValueFloat2(37,5,calib_pH_value[0]);	delay_ms(1);
				SetTextValueFloat2(37,8,calib_pH_mV[0]);	delay_ms(1);
				DispCalibTime(37);	delay_ms(1);
				SetScreen(37);	//calib report for single point
			}
			else if(calib_pH_points > 0)
			{
				if(calib_pH_mode == 0)
					calib_pH_value[1] = calib_pH_world_value[1];
				else if(calib_pH_mode == 1)
					calib_pH_value[1] = calib_pH_euro_value[1];
				else if(calib_pH_mode == 2)
					calib_pH_value[1] = calib_pH_manual_value[1];
				SetTextValueFloat2(31,3,calib_pH_value[1]);
				delay_ms(10);
				SetScreen(31);	//2nd point calib
			}
		}
	}

	else if(screen_id==31) 	//2nd point calibration prepare
	{
		if(control_id==2)	//continue button
		{
			if(mode_ATC_MTC==MEASURE_MODE_ATC)
			{
				SetTextFlash(69,2,50);		//500ms
				current_screen_id = 69;
				calib_measure_cnt = 0;
				calib_measure_flag = 1;
				SetScreen(69);
			}
			else if(mode_ATC_MTC==MEASURE_MODE_MTC)
			{
				SetScreen(70);
			}
		}
	}
	else if(screen_id==69)	//temper measure for calib
	{
		if(control_id==1)			//return
		{
			calib_measure_flag = 0;
			SetScreen(19);
		}
	}
	else if(screen_id==70)	//temper manual input for calib
	{
		if(control_id==1)			//return
		{
			calib_measure_flag = 0;
			SetScreen(19);
		}
		else if(control_id==3)
		{
			current_screen_id = 70;
			SetTextValue(64,4,"2");
			calib_pH_index = GetpHClass(calib_pH_value[1]);

			if((temper_calib_manual[1]<0) || (temper_calib_manual[1]>95))
				SetScreen(64);
			//			else if((temper_calib_manual[1]>50) &&
			//				((calib_pH_index==1) || (calib_pH_index==4) || (calib_pH_index==5) || (calib_pH_index==7) || (calib_pH_index==8)))
			//			{
			//					SetScreen(64);
			//			}
			else
			{
				calib_measure_cnt = 0;
				calib_measure_flag = 1;

				SetTextFlash(32,1,50);		//500ms
				current_screen_id = 32;
				return_screen_id = 31;
				calib_count_down = 300;
				SetScreen(32);
			}
		}
	}
	else if(screen_id==32) 	//2nd point measure
	{
		if(control_id==2)		//return
		{
			calib_measure_flag = 0;
			SetScreen(19);
		}
		if(control_id==6)
		{
			calib_count_down = 0;
		}
	}
	else if(screen_id==33) 	//2nd point complete
	{
		if(control_id==2)	//continue button
		{
			if(calib_pH_points == 1)
			{
				if(mode_ATC_MTC==MEASURE_MODE_ATC)
				{
					SetTextValueFloat(38,3,temper_calc_value);
					//calib_slope = 0.1984f*(273.16f+temper_calc_value);
				}
				else if(mode_ATC_MTC==MEASURE_MODE_MTC)
				{
					SetTextValueFloat(38,3,temper_calib_manual[1]);
					//calib_slope = 0.1984f*(273.16f+temper_calib_manual[1]);
				}
				calib_slope = 100.0f - ((calib_pH_mV[1] - calib_pH_mV[0]) / (calib_pH_value[0] - calib_pH_value[1]) - 59.16) / 59.16 * 100.0f;
				//				calib_slope*100.0f/59.154f;
				SetTextValueFloat(38,4,calib_slope);	delay_ms(10);

				SetTextValueFloat2(38,5,calib_pH_value[0]);	delay_ms(1);
				SetTextValueFloat2(38,6,calib_pH_value[1]);	delay_ms(1);
				SetTextValueFloat2(38,8,calib_pH_mV[0]);	delay_ms(1);
				SetTextValueFloat2(38,9,calib_pH_mV[1]);	delay_ms(1);
				DispCalibTime(38);	delay_ms(1);
				SetScreen(38);		//calib report for two points
			}
			else if(calib_pH_points == 2)
			{
				if(calib_pH_mode == 0)
					calib_pH_value[2] = calib_pH_world_value[2];
				else if(calib_pH_mode == 1)
					calib_pH_value[2] = calib_pH_euro_value[2];
				else if(calib_pH_mode == 2)
					calib_pH_value[2] = calib_pH_manual_value[2];
				SetTextValueFloat2(34,3,calib_pH_value[2]);
				delay_ms(10);
				current_screen_id = 33;
				SetScreen(34);	//3th point calib
			}
		}
	}
	else if(screen_id==34) 	//3th point calibration prepare
	{
		if(control_id==2)	//continue button
		{
			if(mode_ATC_MTC==MEASURE_MODE_ATC)
			{
				SetTextFlash(71,2,50);		//500ms
				current_screen_id = 71;
				calib_measure_cnt = 0;
				calib_measure_flag = 1;
				SetScreen(71);
			}
			else if(mode_ATC_MTC==MEASURE_MODE_MTC)
			{
				SetScreen(72);
			}
		}
	}
	else if(screen_id==71)	//temper3 measure for calib
	{
		if(control_id==1)			//return
		{
			calib_measure_flag = 0;
			SetScreen(19);
		}
	}
	else if(screen_id==72)	//temper3 manual input for calib
	{
		if(control_id==1)			//return
		{
			calib_measure_flag = 0;
			SetScreen(19);
		}
		else if(control_id==3)
		{
			//TODO error process
			current_screen_id = 72;
			SetTextValue(64,4,"3");
			calib_pH_index = GetpHClass(calib_pH_value[2]);

			if((temper_calib_manual[2]<0) || (temper_calib_manual[2]>95))
				SetScreen(64);
			//			else if((temper_calib_manual[2]>50) &&
			//				((calib_pH_index==1) || (calib_pH_index==4) || (calib_pH_index==5) || (calib_pH_index==7) || (calib_pH_index==8)))
			//			{
			//				SetScreen(64);
			//			}
			else
			{
				calib_measure_cnt = 0;
				calib_measure_flag = 1;

				SetTextFlash(35,1,50);		//500ms
				current_screen_id = 35;
				return_screen_id = 34;
				calib_count_down = 300;
				SetScreen(35);
			}
		}
	}
	else if(screen_id==35) 	//3th point measure
	{
		if(control_id==2)		//return
		{
			calib_measure_flag = 0;
			SetScreen(19);
		}
		if(control_id==6)
		{
			calib_count_down = 0;
		}
	}

	else if(screen_id==36) 	//1st point complete
	{
		if(control_id==2)	//continue button
		{
			if(mode_ATC_MTC==MEASURE_MODE_ATC)
			{
				SetTextValueFloat(39,3,temper_calc_value);
				calib_slope = 0.1984f*(273.16f+temper_calc_value);
			}
			else if(mode_ATC_MTC==MEASURE_MODE_MTC)
			{
				SetTextValueFloat(39,3,temper_calib_manual[2]);
				calib_slope = 0.1984f*(273.16f+temper_calib_manual[2]);
			}
			calib_slope = calib_slope*100.0f/59.154f;

			calib_slope = 100.0f - ((calib_pH_mV[1] - calib_pH_mV[0]) / (calib_pH_value[0] - calib_pH_value[1]) - 59.16) / 59.16 * 100.0f;
			calib_slope1 = 100.0f - ((calib_pH_mV[2] - calib_pH_mV[1]) / (calib_pH_value[1] - calib_pH_value[2]) - 59.16) / 59.16 * 100.0f;

			SetTextValueFloat(39,4,calib_slope);	delay_ms(10);
			SetTextValueFloat(39,13,calib_slope1);	delay_ms(10);

			SetTextValueFloat2(39,5,calib_pH_value[0]);	delay_ms(1);
			SetTextValueFloat2(39,6,calib_pH_value[1]);	delay_ms(1);
			SetTextValueFloat2(39,7,calib_pH_value[2]);	delay_ms(1);
			SetTextValueFloat2(39,8,calib_pH_mV[0]);	delay_ms(1);
			SetTextValueFloat2(39,9,calib_pH_mV[1]);	delay_ms(1);
			SetTextValueFloat2(39,10,calib_pH_mV[2]);	delay_ms(1);

			DispCalibTime(39);	delay_ms(1);
			SetScreen(39);		//calib report for three points
		}
	}

	else if(screen_id==37)  	//one point calib report
	{
		if(control_id==2)	//confirm button
		{
			if(mode_ATC_MTC==MEASURE_MODE_ATC)
			{
				calib_pH_measure[0] = mV2pH(calib_pH_mV[0],temper_calc_value);
			}
			else if(mode_ATC_MTC==MEASURE_MODE_MTC)
			{
				calib_pH_measure[0] = mV2pH(calib_pH_mV[0],temper_calib_manual[0]);
			}

			calib_pH_slope[0] = 1.0f;
			calib_pH_offset[0] = calib_pH_value[0] - calib_pH_measure[0]*calib_pH_slope[0];	//b=y0-x0*a
			calib_pH_slope[1] = calib_pH_slope[0];		//Neg = Pos
			calib_pH_offset[1] = calib_pH_offset[0];	//Neg = Pos

			if(mode_ATC_MTC==MEASURE_MODE_ATC)
				SetScreen(59);			//calib main window
			else if(mode_ATC_MTC==MEASURE_MODE_MTC)
				SetScreen(57);
		}
	}
	else if(screen_id==38)  	//two points calib report
	{
		if(control_id==2)	//confirm button
		{
			if(mode_ATC_MTC==MEASURE_MODE_ATC)
			{
				calib_pH_measure[0] = mV2pH(calib_pH_mV[0],temper_calc_value);
				calib_pH_measure[1] = mV2pH(calib_pH_mV[1],temper_calc_value);
			}
			else if(mode_ATC_MTC==MEASURE_MODE_MTC)
			{
				calib_pH_measure[0] = mV2pH(calib_pH_mV[0],temper_calib_manual[0]);
				calib_pH_measure[1] = mV2pH(calib_pH_mV[1],temper_calib_manual[1]);
			}

			calib_pH_slope[0] = (calib_pH_value[0]-calib_pH_value[1])/(calib_pH_measure[0]-calib_pH_measure[1]);	//a=(y0-y1)/(x0-x1)
			calib_pH_offset[0] = calib_pH_value[0] - calib_pH_measure[0]*calib_pH_slope[0];	//b=y0-x0*a
			calib_pH_slope[1] = calib_pH_slope[0];		//Neg = Pos
			calib_pH_offset[1] = calib_pH_offset[0];	//Neg = Pos

			if(mode_ATC_MTC==MEASURE_MODE_ATC)
				SetScreen(59);			//calib main window
			else if(mode_ATC_MTC==MEASURE_MODE_MTC)
				SetScreen(57);
		}
	}
	else if(screen_id==39)  	//three points calib report
	{
		if(control_id==2)	//confirm button
		{

			// mV2pH(ORP_calc_value,temper_calc_value);
			if(mode_ATC_MTC==MEASURE_MODE_ATC)
			{
				calib_pH_measure[0] = mV2pH(calib_pH_mV[0],temper_calc_value);
				calib_pH_measure[1] = mV2pH(calib_pH_mV[1],temper_calc_value);
				calib_pH_measure[2] = mV2pH(calib_pH_mV[2],temper_calc_value);
			}
			else if(mode_ATC_MTC==MEASURE_MODE_MTC)
			{
				calib_pH_measure[0] = mV2pH(calib_pH_mV[0],temper_calib_manual[0]);
				calib_pH_measure[1] = mV2pH(calib_pH_mV[1],temper_calib_manual[1]);
				calib_pH_measure[2] = mV2pH(calib_pH_mV[2],temper_calib_manual[2]);
			}

			calib_pH_slope[0] = (calib_pH_value[0]-calib_pH_value[1])/(calib_pH_measure[0]-calib_pH_measure[1]);	//a1=(y0-y1)/(x0-x1)
			calib_pH_offset[0] = calib_pH_value[0] - calib_pH_measure[0]*calib_pH_slope[0];	//b1=y0-x0*a1
			calib_pH_slope[1] = (calib_pH_value[2]-calib_pH_value[0])/(calib_pH_measure[2]-calib_pH_measure[0]);	//a2=(y2-y0)/(x2-x0)
			calib_pH_offset[1] = calib_pH_value[0] - calib_pH_measure[0]*calib_pH_slope[1];	//b2=y0-x0*a2

			if(mode_ATC_MTC==MEASURE_MODE_ATC)
				SetScreen(59);			//calib main window
			else if(mode_ATC_MTC==MEASURE_MODE_MTC)
				SetScreen(57);
		}
	}

	else if(screen_id==80) //input PH offset, at 20211119
	{
		if(control_id==1) //return
		{
			current_screen_id = 103;
			SetScreen(current_screen_id);
		}
		else if(control_id==4)	//confirm
		{
			if(pH_calib_offset > 2.0f)
				pH_calib_offset = 2.0f;
			else if(pH_calib_offset < -2.0f)
				pH_calib_offset = -2.0f;

			SaveParams();
			current_screen_id = 103;
			SetScreen(current_screen_id);
		}
	}

	//else if((screen_id==41) || (screen_id==81) ||(screen_id==82)) 	//factory calib window
	else if(screen_id==41) 	//factory calib window
	{
		if(control_id==2)	//ORP factory
		{
			current_screen_id = 131;
			SetScreen(131);
		}
		else if(control_id==3)	//temper factory
		{
			current_screen_id = 134;
			SetScreen(134);
		}
		else if(control_id==4)
		{
			SetTextValueInt32(52, 3, dev_address);
		}
		else if(control_id==5)	//analog1 out factory
		{
			ACQ_Enable = 0;
			AD7793_Disable;
			analog_calib_flag = 1;
			delay_ms(10);
			if(analog1_classify==ANALOG1_0_20)
				C4To20mAFactory(0, 0.0f);
			else if(analog1_classify==ANALOG1_4_20)
				C4To20mAFactory(0, 4.0f);
			SetScreen(53);
		}
		else if(control_id==6)	//analog2 out factory
		{
			ACQ_Enable = 0;
			AD7793_Disable;
			analog_calib_flag = 1;
			delay_ms(10);
			if(analog2_classify==ANALOG2_0_20)
				C4To20mAFactory(1, 0.0f);
			else if(analog2_classify==ANALOG2_4_20)
				C4To20mAFactory(1, 4.0f);
			SetScreen(55);
		}
		else if((control_id==1) || (control_id==8))	//���水ť
		{
			if(control_id==8)
			{
				//TODO save parameters
				SaveParams();
				GetParams();
				calib_return_timeout = 0;
			}

			AD7793_Disable;  //---at 20210210
			delay_ms(1);
			if(analog1_off_on)	//A channel
				C4To20mASet(0, ConvToAnalog1());
			else	//added at 20200601
				C4To20mASet(0, 0.0f);
			if(analog2_off_on)	//B channel
				C4To20mASet(1, ConvToAnalog2());
			else
				C4To20mASet(1, 0.0f);	 //---

			current_screen_id = 0;
			ACQ_Enable = 1;
			display_cnt = 0;
			current_screen_id = 0;
			SetScreen(current_screen_id);
		}
		else if(control_id==7)	//RS485 in factory
		{
			SetTextValueInt32(83,2,RS485_In_baud);
			SetScreen(83);
		}

		else if(control_id==4)
		{
			current_screen_id = 52;
			SetScreen(52);
		}
	}

	else if(screen_id==52)
	{
		if(control_id==1)
		{
			current_screen_id = 1;
			SetScreen(current_screen_id);
		}
		else if(control_id==2)
		{
			SaveParams();

			current_screen_id = 1;
			SetScreen(current_screen_id);
		}
	}
	/*
	else if(screen_id==42)	//factory 1st ORP
	{
		if(control_id==2)		//start measure
		{
			ACQ_Enable = 1;
			calib_measure_flag = 1;

			SetTextFlash(43,3,50);		//500ms
			current_screen_id = 43;
			SetScreen(43);
		}
	}
	else if(screen_id==44)	//factory 2nd ORP
	{
		if(control_id==2)		//start measure
		{
			ACQ_Enable = 1;
			calib_measure_flag = 1;

			SetTextFlash(45,3,50);		//500ms
			current_screen_id = 45;
			SetScreen(45);
		}
	}
	else if(screen_id==46)	//factory 3th ORP
	{
		if(control_id==2)		//start measure
		{
			ACQ_Enable = 1;
			calib_measure_flag = 1;

			SetTextFlash(47,3,50);		//500ms
			current_screen_id = 47;
			SetScreen(47);
		}
	}
	//factory ORP 3th complete; Calulate calib coeffs
	else if(screen_id==47)
	{
		if(control_id==2)	//complete
		{
			factory_ORP_slope[0] = (factory_ORP_ref[0]-factory_ORP_ref[1])/(factory_ORP_measure[0]-factory_ORP_measure[1]);	//a1=(y0-y1)/(x0-x1)
			factory_ORP_offset[0] = factory_ORP_ref[1] - factory_ORP_measure[1]*factory_ORP_slope[0];	//b1=y1-x1*a1
			factory_ORP_slope[1] = (factory_ORP_ref[1]-factory_ORP_ref[2])/(factory_ORP_measure[1]-factory_ORP_measure[2]);	//a2=(y1-y2)/(x1-x2)
			factory_ORP_offset[1] = factory_ORP_ref[1] - factory_ORP_measure[1]*factory_ORP_slope[1];	//b2=y1-x1*a2
			ACQ_Enable = 0;
			AnimationPlayFrame(47,1,0);	delay_ms(1);
			SetScreen(factory_screen_id);
		}
	}*/

	else if(screen_id==131)
	{
		if(control_id==1)
		{
			current_screen_id = 41;
			SetScreen(41);
		}
		else if(control_id==2)
		{
			orp_calib_process = 1;
			SetTextValueInt32(132,5,orp_calib_process);
			SetTextValueFloat2(132,3,orp_calib_ref_val[0]);
			current_screen_id = 132;
			SetScreen(132);
		}
	}

	else if(screen_id==132)
	{
		if(control_id==1)
		{
			current_screen_id = 131;
			SetScreen(131);
		}
		else if(control_id==2)
		{
			ACQ_Enable = 1;
			calib_measure_flag = 1;
			SetTextValueInt32(133,5,orp_calib_process);
			SetTextFlash(133,4,50);
			current_screen_id = 133;
			SetScreen(133);
		}
	}

	else if(screen_id==133)
	{
		int i,j;
		float temp_fval;
		if(control_id==2)	//complete
		{
			for(i = 0; i < orp_calib_point_num; i++)
			{
				for(j = i + 1; j < orp_calib_point_num; j++)
				{
					if(orp_calib_ref_val[i] > orp_calib_ref_val[j])
					{
						temp_fval = orp_calib_ref_val[i];
						orp_calib_ref_val[i] = orp_calib_ref_val[j];
						orp_calib_ref_val[j] = temp_fval;

						temp_fval = orp_calib_measure_val[i];
						orp_calib_measure_val[i] = orp_calib_measure_val[j];
						orp_calib_measure_val[j] = temp_fval;
					}
				}
			}

			for(i = 0; i < orp_calib_point_num; i++)
			{
				orp_calib_ref_val_save[i] = orp_calib_ref_val[i];
				orp_calib_measure_val_save[i] = orp_calib_measure_val[i];
			}

			orp_calib_point_num_save = orp_calib_point_num;

			ACQ_Enable = 0;
			AnimationPlayFrame(133,1,0);	delay_ms(1);
			current_screen_id = 41;
			SetScreen(41);
		}
	}

	else if(screen_id==134)	//temperature calibrating.
	{
		if(control_id==1)
		{
			current_screen_id = 41;
			SetScreen(41);
		}
		else if(control_id==2)
		{
			temp_calib_process = 1;
			AnimationPlayFrame(136,1,0);	delay_ms(1);
			SetTextValueInt32(135,5,temp_calib_process);
			SetTextValueFloat2(135,3,temp_calib_ref_val[0]);
			current_screen_id = 135;
			SetScreen(135);
		}
	}

	else if(screen_id==135)
	{
		if(control_id==1)
		{
			current_screen_id = 134;
			SetScreen(134);
		}
		else if(control_id==2)
		{
			ACQ_Enable = 1;
			calib_measure_flag = 1;
			SetTextFlash(136,4,50);
			SetTextValueInt32(136,5,temp_calib_process);
			current_screen_id = 136;
			SetScreen(136);
		}
	}

	else if(screen_id==136)
	{
		int i,j;
		float temp_fval;
		if(control_id==2)	//complete
		{
			for(i = 0; i < temp_calib_point_num; i++)
			{
				for(j = i + 1; j < temp_calib_point_num; j++)
				{
					if(temp_calib_ref_val[i] > temp_calib_ref_val[j])
					{
						temp_fval = temp_calib_ref_val[i];
						temp_calib_ref_val[i] = temp_calib_ref_val[j];
						temp_calib_ref_val[j] = temp_fval;

						temp_fval = temp_calib_measure_val[i];
						temp_calib_measure_val[i] = temp_calib_measure_val[j];
						temp_calib_measure_val[j] = temp_fval;
					}
				}
			}

			for(i = 0; i < temp_calib_point_num; i++)
			{
				temp_calib_ref_val_save[i] = temp_calib_ref_val[i];
				temp_calib_measure_val_save[i] = temp_calib_measure_val[i];
			}
			temp_calib_point_num_save = temp_calib_point_num;

			ACQ_Enable = 0;
			AnimationPlayFrame(136,1,0);	delay_ms(1);
			current_screen_id = 41;
			SetScreen(41);
		}
	}

	/*
	//factory 2 points temper
	else if(screen_id==48)	//factory 1st temper
	{
		if(control_id==2)		//start measure
		{
			ACQ_Enable = 1;
			calib_measure_flag = 1;

			SetTextFlash(49,3,50);		//500ms
			current_screen_id = 49;
			SetScreen(49);
		}
	}
	else if(screen_id==50)	//factory 2nd temper
	{
		if(control_id==2)		//start measure
		{
			ACQ_Enable = 1;
			calib_measure_flag = 1;

			SetTextFlash(51,3,50);		//500ms
			current_screen_id = 51;
			SetScreen(51);
		}
	}
	//factory temper 2nd complete; Calulate calib coeffs
	else if(screen_id==51)
	{
		if(control_id==2)	//complete
		{
			factory_temper_coeff[0] = (factory_temper_ref[0]-factory_temper_ref[1])/(factory_temper_measure[0]-factory_temper_measure[1]);
			factory_temper_coeff[1] = factory_temper_ref[1] - factory_temper_measure[1]*factory_temper_coeff[0];
			SaveParams();
			GetParams();
			ACQ_Enable = 0;
			AnimationPlayFrame(51,1,0);	delay_ms(1);
			SetScreen(factory_screen_id);
 		}
	} */

	//---------------Factory Analog output calibrating ------------------------------//
	else if(screen_id==53)	//factory Analog1 output test
	{
		if(control_id==2)	//continue
		{
			C4To20mAFactory(0, 20.0f);
			SetScreen(54);
		}
		else if(control_id==4)	//giveup
		{
			SetScreen(41);
		}
	}
	else if(screen_id==54)	//factory Analog1 test complete
	{
		if(control_id==2)	//complete
		{
			if(analog1_classify==ANALOG1_0_20)
				factory_analog_slope[0] = (20.0f-0.0f)/(factory_analog1_measure[1]-factory_analog1_measure[0]);
			else if(analog1_classify==ANALOG1_4_20)
				factory_analog_slope[0] = (20.0f-4.0f)/(factory_analog1_measure[1]-factory_analog1_measure[0]);

			factory_analog_offset[0] = 20.0f - factory_analog1_measure[1]*factory_analog_slope[0];
			ACQ_Enable = 1;
			//analog_calib_flag = 0;
			SetScreen(factory_screen_id);
		}
		else if(control_id==4)	//giveup
		{
			SetScreen(53);
		}
	}
	else if(screen_id==55)	//factory Analog2 output test
	{
		if(control_id==2)	//continue
		{
			C4To20mAFactory(1, 20.0f);
			SetScreen(56);
		}
		else if(control_id==4)	//giveup
		{
			SetScreen(41);
		}
	}
	else if(screen_id==56)	// factory Analog2 test complete
	{
		if(control_id==2)	//complete
		{
			if(analog2_classify==ANALOG2_0_20)
				factory_analog_slope[1] = (20.0f-0.0f)/(factory_analog2_measure[1]-factory_analog2_measure[0]);
			else if(analog2_classify==ANALOG2_4_20)
				factory_analog_slope[1] = (20.0f-4.0f)/(factory_analog2_measure[1]-factory_analog2_measure[0]);

			factory_analog_offset[1] = 20.0f - factory_analog2_measure[1]*factory_analog_slope[1];
			ACQ_Enable = 1;
			//analog_calib_flag = 0;
			SetScreen(factory_screen_id);
		}
		else if(control_id==4)	//giveup
		{
			SetScreen(55);
		}
	}
	//---------------Factory Analog input calibrating ------------------------------//
	else if(screen_id==84)	//factory Analog1 input test
	{
		if(control_id==2)	//continue
		{
			factory_analog1_measure[0] = Ain_now_value[0];
			SetScreen(85);
		}
	}
	else if(screen_id==85)	//factory Analog1 test complete
	{
		if(control_id==2)	//complete
		{
			factory_analog1_measure[1] = Ain_now_value[0];

			factory_analogIn_slope[0] = (factory_analog1_signal[1]-factory_analog1_signal[0])/(factory_analog1_measure[1]-factory_analog1_measure[0]);
			factory_analogIn_offset[0] = factory_analog1_signal[1] - factory_analog1_measure[1]*factory_analogIn_slope[0];
			SetScreen(factory_screen_id);
		}
	}
	else if(screen_id==86)	//factory Analog2 input test
	{
		if(control_id==2)	//continue
		{
			factory_analog2_measure[0] = Ain_now_value[1];
			SetScreen(87);
		}
	}
	else if(screen_id==87)	// factory Analog2 test complete
	{
		if(control_id==2)	//complete
		{
			factory_analog2_measure[1] = Ain_now_value[1];

			factory_analogIn_slope[1] = (factory_analog2_signal[1]-factory_analog2_signal[0])/(factory_analog2_measure[1]-factory_analog2_measure[0]);
			factory_analogIn_offset[1] = factory_analog2_signal[1] - factory_analog2_measure[1]*factory_analogIn_slope[1];
			SetScreen(factory_screen_id);
		}
	}
	//----------------user data input error ------------------------//
	else if(screen_id==63)
	{
		if(control_id==2)	//return
		{
			SetScreen(current_screen_id);
		}
	}
	//----------------data history window -----------------------------//


	//	else if((screen_id==77)||(screen_id==78)||(screen_id==97)||(screen_id==98)||(screen_id==99)||(screen_id==100))
	else if((screen_id==137)||(screen_id==138))
	{
		if(control_id == 1)	//return
		{
			ACQ_Enable = 1;
			display_cnt = 0;
			queue_reset();
			delay_ms(500);

			current_screen_id = 0;
			SetScreen(current_screen_id);
		}
		else if(control_id == 2)		//to 24h ago data
		{
			//	if(disp_data_time_history > 10200)
			{
				disp_data_time_history -= (3600 * 24); //at 20210721
				CurveClear(current_screen_id, 9, 0);delay_ms(10);
				CurveClear(current_screen_id, 8, 0);delay_ms(10);
				data_hist_ch = 0;
				ReadFromTFCard(disp_data_time_history);
				data_hist_ch = 1;
				ReadFromTFCard(disp_data_time_history);
			}
		}
		else if(control_id == 3)		//to 1he ago data
		{
			//	if(disp_data_time_history > 10100)
			{
				disp_data_time_history -= 3600; //at 20210721
				CurveClear(current_screen_id, 9, 0);delay_ms(10);
				CurveClear(current_screen_id, 8, 0);delay_ms(10);
				data_hist_ch = 0;
				ReadFromTFCard(disp_data_time_history);
				data_hist_ch = 1;
				ReadFromTFCard(disp_data_time_history);
			}
		}
		else if(control_id == 4)		//to 1h after file
		{
			//if(disp_data_time_history < 123123)
			{
				disp_data_time_history += 3600;  //at 20210721
				CurveClear(current_screen_id, 9, 0);delay_ms(10);
				CurveClear(current_screen_id, 8, 0);delay_ms(10);
				data_hist_ch = 0;
				ReadFromTFCard(disp_data_time_history);
				data_hist_ch = 1;
				ReadFromTFCard(disp_data_time_history);
			}
		}
		else if(control_id == 5)		//to 24h after file
		{
			//	if(disp_data_time_history < 123023)
			{
				disp_data_time_history += (3600 * 24); //at 20210721
				CurveClear(current_screen_id, 9, 0);delay_ms(10);
				CurveClear(current_screen_id, 8, 0);delay_ms(10);
				data_hist_ch = 0;
				ReadFromTFCard(disp_data_time_history);
				data_hist_ch = 1;
				ReadFromTFCard(disp_data_time_history);
			}
		}
	}

	else if(screen_id==79)	//No file error!
	{
		if(control_id==2)		//return
		{
			SetScreen(current_screen_id);
		}
	}
	//-----------enter to data history --------------------------------------//
	else if(screen_id==96)
	{
		if(control_id==2)
		{
			data_hist_ch = 0;
			switch(analogIn1_type)
			{
			case 0:
				current_screen_id = 77; break;
			case 1:
				current_screen_id = 78; break;

			case 5:
				current_screen_id = 100; break;
			default:
				break;
			}
		}
		else if(control_id==3)
		{
			data_hist_ch = 1;
			switch(analogIn2_type)
			{
			case 0:
				current_screen_id = 77; break;
			case 1:
				current_screen_id = 78; break;

			case 5:
				current_screen_id = 100; break;
			default:
				break;
			}
		}
		///schn zuode
		else if(control_id==1)
		{
			current_screen_id = 0;
			SetScreen(current_screen_id);
		}

		CurveClear(current_screen_id,9,0);		delay_ms(1);
		//CurveClear(current_screen_id,9,1);		delay_ms(1);
		SetScreen(current_screen_id);
		//disp_data_time_history = ((now_month>>4)&0x0F)*100000+(now_month&0x0F)*10000+ ((now_day>>4)&0x0F)*1000+(now_day&0x0F)*100+((now_hour>>4)&0x0F)*10+(now_hour&0x0F) - 1;
		disp_data_time_history = current_timestamp - 3600; //at 20210721
		ReadFromTFCard(disp_data_time_history);
	}

	else if(screen_id==129)
	{
		if(control_id==1)
		{
			if(calib_ph_mode == 0)
			{
				if(buffer1==buffer2)
				{
					current_screen_id = 105;
					SetScreen(105);
				}
				else
				{
					current_screen_id = 106;
					SetScreen(106);
				}
			}
			else if(calib_ph_mode == 1)
			{
				if(buffer1==buffer2)
				{
					current_screen_id = 114;
					SetScreen(114);
				}
				else
				{
					current_screen_id = 115;
					SetScreen(115);
				}
			}
			else
			{
				if(buffer1==buffer2)
				{
					current_screen_id = 123;
					SetScreen(123);
				}
				else
				{
					current_screen_id = 124;
					SetScreen(124);
				}
			}

		}
	}


	/*	if(screen_id==3)//��ť��ͼ�ꡢ��������
	{
		if(control_id==3)//���а�ť
		{
			if(state==0)//ֹͣ����
			{
				AnimationPlayFrame(3,1,1);//��ʾֹͣͼ��
				AnimationStop(3,2);//����ֹͣ����
			}
			else//��ʼ����
			{
				SetControlVisiable(3,1,1);//��ʾͼ��
				SetControlVisiable(3,2,1);//��ʾ����

				AnimationPlayFrame(3,1,0);//��ʾ����ͼ��
				AnimationStart(3,2);//������ʼ����
			}
		}
		else if(control_id==4)//��λ��ť
		{
			SetControlVisiable(3,1,0);//����ͼ��
			SetControlVisiable(3,2,0);//���ض���
			SetButtonValue(3,3,0);//��ʾ��ʼ����
		}
	}*/
}

/*! 
 *  \brief  �ı��ؼ�֪ͨ
 *  \details  ���ı�ͨ�����̸���(�����GetControlValue)ʱ��ִ�д˺���
 *  \param screen_id ����ID
 *  \param control_id �ؼ�ID
 *  \param str �ı��ؼ�����
 */
void NotifyText(uint16 screen_id, uint16 control_id, uint8 *str)
{
	uint16 i;
	char str_temp[8];

	//	for(i=0; i<8; i++)
	//		str_temp[i] = 0;
	for(i=0; i<8; i++)
	{
		str_temp[i] = 0;
		str_temp[i] = str[i];
	}

	if(screen_id==15)			//��������
	{
		for(i=0; i<4; i++)
			setting_pwd[i] = str[i];
	}
	if(screen_id==17)			//��������
	{
		for(i=0; i<4; i++)
			calib_pwd[i] = str[i];
	}

	else if((screen_id==3)||(screen_id==91))			//enter manual temperature
	{
		if(control_id==4)
			sscanf(str_temp,"%f",&temper_manual);
	}
	//---------------Enter analog output points -------------------------//
	else if(screen_id==4 || screen_id==101)			//enter two analog1 points
	{
		if(control_id==5)				// 0/4mA value
		{	
			//	sscanf(str_temp,"%f",&analog1_point[0]);
			if(analog1_type == 0)
				sscanf(str_temp,"%f",&analog1_point_ph[0]);
			else if(analog1_type == 1)
				sscanf(str_temp,"%f",&analog1_point_orp[0]);
			else if(analog1_type == 5)
				sscanf(str_temp,"%f",&analog1_point_temp[0]);
		}
		else if(control_id==6)	// 20mA value
		{
			//	sscanf(str_temp,"%f",&analog1_point[1]);
			if(analog1_type == 0)
				sscanf(str_temp,"%f",&analog1_point_ph[1]);
			else if(analog1_type == 1)
				sscanf(str_temp,"%f",&analog1_point_orp[1]);
			else if(analog1_type == 5)
				sscanf(str_temp,"%f",&analog1_point_temp[1]);

			/*		if(analog1_point[1]<analog1_point[0])
			{
				SetScreen(63);
				current_screen_id = 4;
			} */
		}
	}
	else if(screen_id==6 || screen_id==102)			//enter two analog2 points
	{
		if(control_id==5)			// 0/4mA value		
		{
			//		sscanf(str_temp,"%f",&analog2_point[0]);
			if(analog2_type == 0)
				sscanf(str_temp,"%f",&analog2_point_ph[0]);
			else if(analog2_type == 1)
				sscanf(str_temp,"%f",&analog2_point_orp[0]);
			else if(analog2_type == 5)
				sscanf(str_temp,"%f",&analog2_point_temp[0]);
		}
		else if(control_id==6)	// 20mA value
		{
			//	sscanf(str_temp,"%f",&analog2_point[1]);
			if(analog2_type == 0)
				sscanf(str_temp,"%f",&analog2_point_ph[1]);
			else if(analog2_type == 1)
				sscanf(str_temp,"%f",&analog2_point_orp[1]);
			else if(analog2_type == 5)
				sscanf(str_temp,"%f",&analog2_point_temp[1]);
		}
	}
	//---------------Enter analog Input points -------------------------//
	/*else if(screen_id==88)			//enter two AIN1 points
	{
		if(control_id==5)			// 0/4mA value		
		{
			sscanf(str_temp,"%f",&analogIn1_point[0]);
		}
		else if(control_id==6)	// 20mA value
		{
			sscanf(str_temp,"%f",&analogIn1_point[1]);
		}
	}
	else if(screen_id==90)			//enter two AIN2 points
	{
		if(control_id==5)			// 0/4mA value		
		{
			sscanf(str_temp,"%f",&analogIn2_point[0]);
		}
		else if(control_id==6)	// 20mA value
		{
			sscanf(str_temp,"%f",&analogIn2_point[1]);
		}
	}*/

	else if(screen_id==9)			//enter two relay1 points
	{
		//added by schn 11/3/2018
		if(control_id==5)
		{
			//	if(mode_pH_ORP==MEASURE_MODE_PH)
			//sscanf(str_temp,"%f",&relay1_point[1]);	///
			if(relay1_classify==0)
			{
				if(analogIn1_type==0)
					sscanf(str_temp,"%f",&relay1_point_ph_low[1]);
				else
					sscanf(str_temp,"%f",&relay1_point_orp_low[1]);
			}
			else
			{
				if(analogIn1_type==0)
					sscanf(str_temp,"%f",&relay1_point_ph_hi[1]);
				else
					sscanf(str_temp,"%f",&relay1_point_orp_hi[1]);
			}
		}
		else if(control_id==6)
		{
			//	if(mode_pH_ORP==MEASURE_MODE_PH)
			//	sscanf(str_temp,"%f",&relay1_point[0]);	///
			if(relay1_classify==0)
			{
				if(analogIn1_type==0)
					sscanf(str_temp,"%f",&relay1_point_ph_low[0]);
				else
					sscanf(str_temp,"%f",&relay1_point_orp_low[0]);
			}
			else
			{
				if(analogIn1_type==0)
					sscanf(str_temp,"%f",&relay1_point_ph_hi[0]);
				else
					sscanf(str_temp,"%f",&relay1_point_orp_hi[0]);
			}
		}
	}
	else if(screen_id==11)			//enter two relay2 points
	{
		if(control_id==5)
		{		
			//	if(mode_pH_ORP==MEASURE_MODE_PH)
			//	sscanf(str_temp,"%f",&relay2_point[1]);	///
			if(relay2_classify==0)
			{
				if(analogIn1_type==0)
					sscanf(str_temp,"%f",&relay2_point_ph_low[1]);
				else
					sscanf(str_temp,"%f",&relay2_point_orp_low[1]);
			}
			else
			{
				if(analogIn1_type==0)
					sscanf(str_temp,"%f",&relay2_point_ph_hi[1]);
				else
					sscanf(str_temp,"%f",&relay2_point_orp_hi[1]);
			}
		}
		else if(control_id==6)
		{
			//	if(mode_pH_ORP==MEASURE_MODE_PH)
			//	sscanf(str_temp,"%f",&relay2_point[0]);	///
			if(relay2_classify==0)
			{
				if(analogIn1_type==0)
					sscanf(str_temp,"%f",&relay2_point_ph_low[0]);
				else
					sscanf(str_temp,"%f",&relay2_point_orp_low[0]);
			}
			else
			{
				if(analogIn1_type==0)
					sscanf(str_temp,"%f",&relay2_point_ph_hi[0]);
				else
					sscanf(str_temp,"%f",&relay2_point_orp_hi[0]);
			}
		}																				
	}

	else if(screen_id==13)			//enter timer on & off period
	{
		if(control_id==5)				
			sscanf(str_temp,"%f",&timer_point[1]);		//running period
		else if(control_id==6)
			sscanf(str_temp,"%f",&timer_point[0]);		//pause
	}

	else if(screen_id==130)
	{
		if(control_id==4)
			sscanf(str_temp,"%f",&calib_manual_temperature);
	}

	else if(screen_id==122)
	{
		if(control_id==3)				
			sscanf(str_temp,"%f",&buffer1);		
	}
	else if(screen_id==123)
	{
		if(control_id==3)				
			sscanf(str_temp,"%f",&buffer2);		
	}
	else if(screen_id==124)
	{
		if(control_id==3)				
			sscanf(str_temp,"%f",&buffer3);		
	}

	else if((screen_id==60)||(screen_id==61)||(screen_id==95||screen_id==119)) //92,93,94
	{
		if(control_id==3)				
		{
			if(analogIn_calib_ch==0)
				sscanf(str_temp,"%f",&calib_Ain_offset[0]);		
			else if(analogIn_calib_ch==1)
				sscanf(str_temp,"%f",&calib_Ain_offset[1]);		
		}		
	}

	else if(screen_id==80) //at 20211119
	{
		if(control_id==3)				
		{
			sscanf(str_temp,"%f",&pH_calib_offset);		
		}		
	}

	else if(screen_id==21)			//pH 1P manual calibrating
	{
		if(control_id==6)				
			sscanf(str_temp,"%f",&calib_pH_manual_value[0]);		
	}
	else if(screen_id==24)			//pH 2P manual calibrating
	{
		if(control_id==6)				
			sscanf(str_temp,"%f",&calib_pH_manual_value[0]);		
		else if(control_id==7)				
			sscanf(str_temp,"%f",&calib_pH_manual_value[1]);				
	}
	else if(screen_id==27)			//pH 3P manual calibrating
	{
		if(control_id==6)				
			sscanf(str_temp,"%f",&calib_pH_manual_value[0]);		
		else if(control_id==7)				
			sscanf(str_temp,"%f",&calib_pH_manual_value[1]);		
		else if(control_id==8)				
			sscanf(str_temp,"%f",&calib_pH_manual_value[2]);		
	}

	/*
	//////////----- Factory Calibration ---------//////////////////
	else if(screen_id==42) 	//1st ORP measure
	{
		if(control_id==3)			//input ref value
			sscanf(str_temp,"%f",&factory_ORP_ref[0]);
	}
	else if(screen_id==44) 	//2nd ORP measure
	{
		if(control_id==3)			//input ref value
			sscanf(str_temp,"%f",&factory_ORP_ref[1]);
	}
	else if(screen_id==46) 	//3th ORP measure
	{
		if(control_id==3)			//input ref value
			sscanf(str_temp,"%f",&factory_ORP_ref[2]);
	}*/

	else if(screen_id==131)
	{
		if(control_id==3)			
			sscanf(str_temp,"%u",&orp_calib_point_num);
	}

	else if(screen_id==132)
	{
		if(control_id==3)		
			sscanf(str_temp,"%f",&orp_calib_ref_val[orp_calib_process-1]);
	}

	else if(screen_id==134)
	{
		if(control_id==3)			
			sscanf(str_temp,"%u",&temp_calib_point_num);
	}

	else if(screen_id==135)
	{
		if(control_id==3)		
			sscanf(str_temp,"%f",&temp_calib_ref_val[temp_calib_process-1]);
	}

	/*
	else if(screen_id==48) 	//1st temper measure
	{
		if(control_id==3)			//input ref value
			sscanf(str_temp,"%f",&factory_temper_ref[0]);
	}
	else if(screen_id==50) 	//2nd temper measure
	{
		if(control_id==3)			//input ref value
			sscanf(str_temp,"%f",&factory_temper_ref[1]);
	} */

	else if(screen_id==8) 	//device address
	{
		if(control_id==5)			//input ref value
		{
			sscanf(str_temp,"%u",&dev_address);
			/*	PETITMODBUS_SLAVE_ADDRESS = dev_address;
			PetitRegisters[MODBUS_DEV_ADDRESS].ActValue = dev_address;
			SaveParams(); */
		}
	}
	//---------------Factory analog output calibrating ---------------------//
	else if(screen_id==53) 	//factory analog1 1st measure
	{
		if(control_id==3)			//input measured value
			sscanf(str_temp,"%f",&factory_analog1_measure[0]);
	}
	else if(screen_id==54) 	//factory analog1 2nd measure
	{
		if(control_id==3)			//input measured value
			sscanf(str_temp,"%f",&factory_analog1_measure[1]);
	}

	else if(screen_id==55) 	//factory analog2 1st measure
	{
		if(control_id==3)			//input measured value
			sscanf(str_temp,"%f",&factory_analog2_measure[0]);
	}
	else if(screen_id==56) 	//factory analog2 2nd measure
	{
		if(control_id==3)			//input measured value
			sscanf(str_temp,"%f",&factory_analog2_measure[1]);
	}
	//---------------Factory analog input calibrating ---------------------//
	else if(screen_id==84) 	//factory analog1 1st input
	{
		if(control_id==3)			//
			sscanf(str_temp,"%f",&factory_analog1_signal[0]);
	}
	else if(screen_id==85) 	//factory analog1 2nd input
	{
		if(control_id==3)			//
			sscanf(str_temp,"%f",&factory_analog1_signal[1]);
	}

	else if(screen_id==86) 	//factory analog2 1st input
	{
		if(control_id==3)			//
			sscanf(str_temp,"%f",&factory_analog2_signal[0]);
	}
	else if(screen_id==87) 	//factory analog2 2nd input
	{
		if(control_id==3)			//
			sscanf(str_temp,"%f",&factory_analog2_signal[1]);
	}

	else if(screen_id==68) 	//manual temper1 for calib
	{
		if(control_id==2)			//
			sscanf(str_temp,"%f",&temper_calib_manual[0]);
	}
	else if(screen_id==70) 	//manual temper2 for calib
	{
		if(control_id==2)			//
			sscanf(str_temp,"%f",&temper_calib_manual[1]);
	}
	else if(screen_id==72) 	//manual temper3 for calib
	{
		if(control_id==2)			//
			sscanf(str_temp,"%f",&temper_calib_manual[2]);
	}
	else if(screen_id==83) 	//manual temper3 for calib
	{
		if(control_id==5)			//
			sscanf(str_temp,"%u",&sensor_addr);
	}

	else if((screen_id==137)||(screen_id==138)) //time input for data history
	{
		if(control_id==6)			//
		{
			sscanf(str_temp,"%u",&disp_data_time_history);
			ReadFromTFCard(disp_data_time_history);	 //at 20210721
		}
	}

	delay_ms(10);
}

/*! 
 *  \brief  �������ؼ�֪ͨ
 *  \details  ����GetControlValueʱ��ִ�д˺���
 *  \param screen_id ����ID
 *  \param control_id �ؼ�ID
 *  \param value ֵ
 */
void NotifyProgress(uint16 screen_id, uint16 control_id, uint32 value)
{
	//TODO: �����û�����
}

/*! 
 *  \brief  �������ؼ�֪ͨ
 *  \details  ���������ı�(�����GetControlValue)ʱ��ִ�д˺���
 *  \param screen_id ����ID
 *  \param control_id �ؼ�ID
 *  \param value ֵ
 */
void NotifySlider(uint16 screen_id, uint16 control_id, uint32 value)
{
	//TODO: �����û�����
	if(screen_id==5&&control_id==2)//�������
	{
		test_value = value;

		SetProgressValue(5,1,test_value); //���½�������ֵ
	}
}

/*! 
 *  \brief  �Ǳ��ؼ�֪ͨ
 *  \details  ����GetControlValueʱ��ִ�д˺���
 *  \param screen_id ����ID
 *  \param control_id �ؼ�ID
 *  \param value ֵ
 */
void NotifyMeter(uint16 screen_id, uint16 control_id, uint32 value)
{
	//TODO: �����û�����
}

/*! 
 *  \brief  �˵��ؼ�֪ͨ
 *  \details  ���˵���»��ɿ�ʱ��ִ�д˺���
 *  \param screen_id ����ID
 *  \param control_id �ؼ�ID
 *  \param item �˵�������
 *  \param state ��ť״̬��0�ɿ���1����
 */
void NotifyMenu(uint16 screen_id, uint16 control_id, uint8  item, uint8  state)
{
	//TODO: �����û�����

	if((screen_id==2) || (screen_id==3))	//measure signal select
	{
		if(!state)
		{
			if(item<5)
				analogIn1_type = item;

			if(analog1_type != 5)			//added by kjh	at 20200305
				analog1_type = analogIn1_type;
			if(analog2_type != 5)
				analog2_type = analogIn1_type;
			//mode_pH_ORP = item;

			//			SetScreen(screen_id);
		}
	}
	else if(screen_id==4 || screen_id==101)	//Analog1 type setting
	{
		if(!state)
		{
			if(item<6)
			{
				if(item==1)
				{
					analog1_type = 5;
				}
				else
				{
					analog1_type = analogIn1_type;//analog1_type = 0;
				}

				if(analog1_type == 0)
				{
					SetTextValueFloat2(4,5,analog1_point_ph[0]);	delay_ms(1);	
					SetTextValueFloat2(4,6,analog1_point_ph[1]);	delay_ms(1);
					SetTextValueFloat2(101,5,analog1_point_ph[0]);	delay_ms(1);	
					SetTextValueFloat2(101,6,analog1_point_ph[1]);	delay_ms(1);
				}
				else if(analog1_type == 1)
				{
					SetTextValueFloat2(4,5,analog1_point_orp[0]);	delay_ms(1);	
					SetTextValueFloat2(4,6,analog1_point_orp[1]);	delay_ms(1);
					SetTextValueFloat2(101,5,analog1_point_orp[0]);	delay_ms(1);	
					SetTextValueFloat2(101,6,analog1_point_orp[1]);	delay_ms(1);
				}
				else if(analog1_type == 5)
				{
					SetTextValueFloat2(4,5,analog1_point_temp[0]);	delay_ms(1);	
					SetTextValueFloat2(4,6,analog1_point_temp[1]);	delay_ms(1);
					SetTextValueFloat2(101,5,analog1_point_temp[0]);	delay_ms(1);	
					SetTextValueFloat2(101,6,analog1_point_temp[1]);	delay_ms(1);
				}
			}
		}
	}
	else if(screen_id==6 || screen_id==102)	//Analog2 type setting
	{
		if(!state)
		{
			if(item<6)
			{
				if(item==1)
					analog2_type = 5;
				else
					analog2_type = analogIn1_type;//analog2_type = item;

				if(analog2_type == 0)
				{
					SetTextValueFloat2(6,5,analog2_point_ph[0]);	delay_ms(1);	
					SetTextValueFloat2(6,6,analog2_point_ph[1]);	delay_ms(1);
					SetTextValueFloat2(102,5,analog2_point_ph[0]);	delay_ms(1);	
					SetTextValueFloat2(102,6,analog2_point_ph[1]);	delay_ms(1);
				}
				else if(analog2_type == 1)
				{
					SetTextValueFloat2(6,5,analog2_point_orp[0]);	delay_ms(1);	
					SetTextValueFloat2(6,6,analog2_point_orp[1]);	delay_ms(1);
					SetTextValueFloat2(102,5,analog2_point_orp[0]);	delay_ms(1);	
					SetTextValueFloat2(102,6,analog2_point_orp[1]);	delay_ms(1);
				}
				else if(analog2_type == 5)
				{
					SetTextValueFloat2(6,5,analog2_point_temp[0]);	delay_ms(1);	
					SetTextValueFloat2(6,6,analog2_point_temp[1]);	delay_ms(1);
					SetTextValueFloat2(102,5,analog2_point_temp[0]);	delay_ms(1);	
					SetTextValueFloat2(102,6,analog2_point_temp[1]);	delay_ms(1);
				}
			}

		}
	}
	/*else if(screen_id==88)	//AIN1 type setting
	{
		if(!state)
		{
			if(item<6)
				analogIn1_type = item;
		}
	}
	else if(screen_id==90)	//AIN2 type setting
	{
		if(!state)
		{
			if(item<6)
				analogIn2_type = item;
		}
	}*/
	else if(screen_id==9)		//Relay1 type setting
	{
		if(!state)
		{
			if(item<6)
				relay1_type = item;
		}
	}
	else if(screen_id==11)	//Realy2 type setting
	{
		if(!state)
		{
			if(item<6)
				relay2_type = item;
		}
	}

	else if(screen_id==8)			//RS485 out user setting
	{
		if(!state)
		{
			switch(item)
			{
			case 0:
				RS485_baudrate = 4800;	break;
			case 1:
				RS485_baudrate = 9600;	break;
			case 2:
				RS485_baudrate = 19200;	break;
			case 3:
				RS485_baudrate = 115200;	break;
			case 4:
				RS485_baudrate = 230400;	break;
			default:
				break;
			}
		}
	}
	else if(screen_id==83)			//RS485 in user setting
	{
		if(!state)
		{
			switch(item)
			{
			case 0:
				RS485_In_baud = 4800;	break;
			case 1:
				RS485_In_baud = 9600;	break;
			case 2:
				RS485_In_baud = 19200;	break;
			case 3:
				RS485_In_baud = 115200;	break;
			case 4:
				RS485_In_baud = 230400;	break;
			default:
				break;
			}
		}
	}

}

/*! 
 *  \brief  ѡ��ؼ�֪ͨ
 *  \details  ��ѡ��ؼ��仯ʱ��ִ�д˺���
 *  \param screen_id ����ID
 *  \param control_id �ؼ�ID
 *  \param item ��ǰѡ��
 */
void NotifySelector(uint16 screen_id, uint16 control_id, uint8  item)
{
	//TODO: �����û�����
}

/*! 
 *  \brief  ��ʱ����ʱ֪ͨ����
 *  \param screen_id ����ID
 *  \param control_id �ؼ�ID
 */
void NotifyTimer(uint16 screen_id, uint16 control_id)
{
	//TODO: �����û�����
}

/*! 
 *  \brief  ��ȡ�û�FLASH״̬����
 *  \param status 0ʧ�ܣ�1�ɹ�
 *  \param _data ��������
 *  \param length ���ݳ���
 */
void NotifyReadFlash(uint8 status,uint8 *_data,uint16 length)
{
	//TODO: �����û�����
}

/*! 
 *  \brief  д�û�FLASH״̬����
 *  \param status 0ʧ�ܣ�1�ɹ�
 */
void NotifyWriteFlash(uint8 status)
{
	//TODO: �����û�����
}

int year_check(uint8 year1)
{
	uint8 pos1, pos2;
	pos1 = (year1 >> 4) & 0x0F;
	pos2 = year1 & 0x0F;
	if(pos1 > 9 || pos2 > 9)
		return -1;
	if(year1 == 0x00)
		return -1;
	return 1;
}

int month_check(uint8 month1)
{
	uint8 pos1, pos2;
	pos1 = (month1 >> 4) & 0x0F;
	pos2 = month1 & 0x0F;
	if(pos1 > 1 || pos2 > 9)
		return -1;
	if(month1 == 0x00)
		return -1;
	if(month1 > 0x12) //at 20201207, (month1 == 0x12)
		return -1;
	return 1;
}

int day_check(uint8 day1)
{
	uint8 pos1, pos2;
	pos1 = (day1 >> 4) & 0x0F;
	pos2 = day1 & 0x0F;
	if(pos1 > 3 || pos2 > 9)
		return -1;
	if(day1 == 0x00)
		return -1;
	if(day1 > 0x31) 
		return -1;
	return 1;
}

int hour_check(uint8 hour1)
{
	uint8 pos1, pos2;
	pos1 = (hour1 >> 4) & 0x0F;
	pos2 = hour1 & 0x0F;
	if(pos1 > 2 || pos2 > 9)
		return -1;
	if(hour1 > 0x24) 
		return -1;
	return 1;
}

int minute_check(uint8 minute1)
{
	uint8 pos1, pos2;
	pos1 = (minute1 >> 4) & 0x0F;
	pos2 = minute1 & 0x0F;
	if(pos1 > 6 || pos2 > 9)
		return -1;
	if(minute1 > 0x59) 
		return -1;
	return 1;
}

int second_check(uint8 second1)
{
	uint8 pos1, pos2;
	pos1 = (second1 >> 4) & 0x0F;
	pos2 = second1 & 0x0F;
	if(pos1 > 6 || pos2 > 9)
		return -1;
	if(second1 > 0x59) 
		return -1;
	return 1;
}

uint32_t bcd_decimal(uint8_t hex)
{
	uint32_t dec = ((hex & 0xF0) >> 4) * 10 + (hex & 0x0F);
	return dec;
}

/*! 
 *  \brief  ��ȡRTCʱ�䣬ע�ⷵ�ص���BCD��
 *  \param year �꣨BCD��
 *  \param month �£�BCD��
 *  \param week ���ڣ�BCD��
 *  \param day �գ�BCD��
 *  \param hour ʱ��BCD��
 *  \param minute �֣�BCD��
 *  \param second �루BCD��
 */
void NotifyReadRTC(uint8 year1,uint8 month1,uint8 week1,uint8 day1,uint8 hour1,uint8 minute1,uint8 second1) //at 20210721
{
	if(year_check(year1) == -1)
		return;
	if(month_check(month1) == -1)
		return;
	if(day_check(day1) == -1)
		return;
	if(hour_check(hour1) == -1)
		return;
	if(minute_check(minute1) == -1)
		return;
	if(second_check(second1) == -1)
		return;
	now_year = year1;
	now_month = month1;
	now_day = day1;

	now_hour = hour1;
	now_minute = minute1;
	now_sec = second1;

	current_timestamp = get_timestamp(
			bcd_decimal(now_year),
			bcd_decimal(now_month),
			bcd_decimal(now_day),
			bcd_decimal(now_hour),
			bcd_decimal(now_minute),
			bcd_decimal(now_sec));

	read_rtc_flag = 1;
}

/*******************************************************************************
 * Function Name  : GPIO_Configuration
 * Description    : Configures the different GPIO ports.
 * Input          : None
 * Output         : None
 * Return         : None
 * Attention		 : None
 *******************************************************************************/
void GPIO_Configuration(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOC | RCC_APB2Periph_AFIO ,ENABLE);

	// LED1(485) -> PA11, LED2(RUN) -> PA12	
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_11 | GPIO_Pin_12;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	LED_RUN_ON;
	LED_485_OFF;
	//GPIO_ResetBits(GPIOA, GPIO_Pin_11| GPIO_Pin_12);

	// LED2 -> PC10
	/*  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 
  GPIO_Init(GPIOC, &GPIO_InitStructure);
	GPIO_ResetBits(GPIOC, GPIO_Pin_10); */

	// TIMER -> PC7, RELAY2 -> PC8, RELAY1 -> PC9
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_7 | GPIO_Pin_8 | GPIO_Pin_9;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
	GPIO_ResetBits(GPIOC, GPIO_Pin_7 | GPIO_Pin_8 | GPIO_Pin_9);	//disable

	// Light_In -> PC0, No light:0	
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_0;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
}

/*******************************************************************************
 * Function Name  : NVIC_Configuration
 * Description    : Configures the nested vectored interrupt controller.
 * Input          : None
 * Output         : None
 * Return         : None
 * Attention		 : None
 *******************************************************************************/
void NVIC_Configuration(void)
{
	NVIC_InitTypeDef NVIC_InitStructure;

	/* Enable CAN1 RX0 interrupt IRQ channel */
	/*	NVIC_InitStructure.NVIC_IRQChannel = USB_LP_CAN1_RX0_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure); */

	NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn; //HMI
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);

	NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;	//RS485 out
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);

	NVIC_InitStructure.NVIC_IRQChannel = UART4_IRQn;	//RS485 in
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);

	//	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);
	NVIC_InitStructure.NVIC_IRQChannel=TIM2_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority=1;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
}

/*******************************************************************************
 * Function Name  : scan_files
 * Description    : �����ļ�Ŀ¼�������ļ�
 * Input          : - path: ��Ŀ¼
 * Output         : None
 * Return         : FRESULT
 * Attention		 : ��֧�ֳ��ļ���
 *******************************************************************************/
/*FRESULT scan_files (char* path)
{
    FILINFO fno;
    DIR dir;
    int i;
    char *fn;
#if _USE_LFN
    static char lfn[_MAX_LFN * (_DF1S ? 2 : 1) + 1];
    fno.lfname = lfn;
    fno.lfsize = sizeof(lfn);
#endif

    res = f_opendir(&dir, path);
    if (res == FR_OK) {
        i = strlen(path);
        for (;;) {
            res = f_readdir(&dir, &fno);
            if (res != FR_OK || fno.fname[0] == 0) break;
            if (fno.fname[0] == '.') continue;
#if _USE_LFN
            fn = *fno.lfname ? fno.lfname : fno.fname;
#else
            fn = fno.fname;
#endif
            if (fno.fattrib & AM_DIR) {
                sprintf(&path[i], "/%s", fn);
                res = scan_files(path);
                if (res != FR_OK) break;
                path[i] = 0;
            } else {
                printf("%s/%s \r\n", path, fn);
            }
        }
    }

    return res;
}*/



void RCC_Configuration(void)
{   
	/* RCC system reset(for debug purpose) */
	RCC_DeInit();

	/* Enable HSE */
	RCC_HSEConfig(RCC_HSE_ON);

	/* Wait till HSE is ready */
	HSEStartUpStatus = RCC_WaitForHSEStartUp();

	if(HSEStartUpStatus == SUCCESS)
	{
		/* HCLK = SYSCLK */
		RCC_HCLKConfig(RCC_SYSCLK_Div1);

		/* PCLK2 = HCLK */
		RCC_PCLK2Config(RCC_HCLK_Div1);

		/* PCLK1 = HCLK/2 */
		RCC_PCLK1Config(RCC_HCLK_Div2);

		/* PLLCLK = 8MHz * 9 = 72 MHz */
		RCC_PLLConfig(RCC_PLLSource_HSE_Div1, RCC_PLLMul_9);

		/* Enable PLL */
		RCC_PLLCmd(ENABLE);

		/* Wait till PLL is ready */
		while(RCC_GetFlagStatus(RCC_FLAG_PLLRDY) == RESET)
		{
		}

		/* Select PLL as system clock source */
		RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);

		/* Wait till PLL is used as system clock source */
		while(RCC_GetSYSCLKSource() != 0x08)
		{
		}
	}
}


#ifdef  USE_FULL_ASSERT

/**
 * @brief  Reports the name of the source file and the source line number
 *   where the assert_param error has occurred.
 * @param  file: pointer to the source file name
 * @param  line: assert_param error line source number
 * @retval None
 */
void assert_failed(uint8_t* file, uint32_t line)
{ 
	/* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

	/* Infinite loop */
	while (1)
	{
	}
}
#endif

/*********************************************************************************************************
      END FILE
 *********************************************************************************************************/

