/************************************************
* Name : Info.h
* Description : Information about the product
*************************************************/
uint32_t dev_address = 1;		//1~255
uint32_t sensor_addr = 3;

uint8_t	setting_pwd_default[4] = "1202"; 
uint8_t	calib_pwd_default[4] = "1606"; 
uint8_t	factory_pwd_default[4] = "1808"; 

char HW_version[] = "21070101";			//at 20210806
char FW_version[] = "21070101";			//at 20210806
char SN_num[] = "18230001";	//"17200002";			//���к�
char Factory_num[] = "1806";		//���ұ��
char Product_num[] = "2100";		//��Ʒ���

char datetime[] = "20180813090432";

