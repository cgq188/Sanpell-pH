#ifndef __DATACONVERTER__H
#define __DATACONVERTER__H

#include "stdint.h"

union FloatUInt8 {
	float float_val;
	uint8_t uint8_arr[4];
};

union UInt32UInt8 {
	uint32_t uint32_val;
	uint8_t uint8_arr[4];
};

union UInt16UInt8 {
	uint16_t uint16_val;
	uint8_t uint8_arr[2];
};

union F2C {
	float f; 
	char cbuf[4];
};

union F2S {
	float f; 
	unsigned short sbuf[2];
};

union Float2UInt32 {
	float f_val;
	uint32_t int_val;
};

union Short2UInt32 {
	uint32_t iVal;
	short sArr[2];
};


//void FloatToChar(float fVal, char* cbuf);
//float CharToFloat(char * in);

void FloatToShort(float fVal, unsigned short* sbuf);
float ShortToFloat(unsigned short * in);

uint32_t UInt8ArrToUInt32(uint8_t* buf, uint8_t start_idx);
float UInt8ArrToFloat(uint8_t* buf, uint8_t start_idx);
uint16_t UInt8ArrToUInt16(uint8_t* buf, uint8_t start_idx);
void FloatToUInt8Arr(float fval, uint8_t* buf);
void UInt32ToUInt8Arr(uint32_t uval, uint8_t* buf);
void TimestampToDatetime(uint32_t timestamp, char* datetime);
float CalcAverage(float* farr, uint8_t length);
float UInt32ToFloat(uint32_t i_val);
uint32_t FloatToUInt32(float f_val);
uint32_t ShortToUInt32(short* arr);
void UInt32ToShort(uint32_t ival, short* arr);

float select_nist_standard_ph(float ph_mv);
float select_tech_standard_ph(float ph_mv);
//float select_real_ph(float ph, float temp);

float select_real_ph_nist(float ph, float temp);
float select_real_ph_tech(float ph, float temp);

uint32_t get_timestamp(uint8_t year, uint8_t month, uint8_t day, uint8_t hour, uint8_t min, uint8_t sec);
void timestamp_to_filename(uint32_t timestamp, char* filename);
void timestamp_to_subdir_year(uint32_t timestamp, char* subdir);
void timestamp_to_subdir_month(uint32_t timestamp, char* subdir);
void timestamp_to_subdir_day(uint32_t timestamp, char* subdir);
void timestamp_to_time_rtc(uint32_t timestamp, char* timestr);
void timestamp_to_history_time_str(uint32_t timestamp, char* timestr);

#endif




