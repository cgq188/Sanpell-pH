/*  PetitModbus
 *  Author  schn:   
 *  Date    2018/08/01:   

 *  RS485   Implment Modbus RTU protocol only command 3, 6 ,16	
 */
 
 
#ifndef __PETITMODBUS__H
#define __PETITMODBUS__H

#define NUMBER_OF_OUTPUT_PETITREGISTERS									300
#define PETITMODBUS_RECEIVE_BUFFER_SIZE      						60 //at 220912
#define PETITMODBUS_TRANSMIT_BUFFER_SIZE             		200 //700
#define PETITMODBUS_RXTX_BUFFER_SIZE               			PETITMODBUS_TRANSMIT_BUFFER_SIZE


#define PETITMODBUS_TIMEOUTTIMER                        250
extern unsigned char PETITMODBUS_SLAVE_ADDRESS;

#define PETITMODBUS_READ_HOLDING_REGISTERS_ENABLED      ( 1 )
#define PETITMODBUSWRITE_SINGLE_REGISTER_ENABLED        ( 1 )
#define PETITMODBUS_WRITE_MULTIPLE_REGISTERS_ENABLED    ( 1 )


typedef struct {
						short			ActValue;
				}PetitRegStructure;

extern PetitRegStructure 				PetitRegisters[NUMBER_OF_OUTPUT_PETITREGISTERS];
extern unsigned int         		PetitModbusTimerValue;;

#ifndef TRUE
#define TRUE		1
#endif

#ifndef FALSE
#define FALSE		0
#endif

extern void 						InitPetitModbus(unsigned char PetitModbusSlaveAddress, int baudrate);
extern unsigned char		PetitSendMessage(void);
extern unsigned char		PetitRxDataAvailable(void);
extern void							ProcessPetitModbus(void);
extern void             HandlePetitModbusReadHoldingRegisters(void);            // ModBus 03
//extern void             HandlePetitModbusWriteSingleRegister(void);             // ModBus 06
extern void             HandleMPetitodbusWriteMultipleRegisters(void);          // ModBus 16
extern unsigned char    CheckPetitModbusBufferComplete(void);

#include "PetitModbusPort.h"

#endif


