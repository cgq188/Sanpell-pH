#include "DataConvert.h"
#include <stdio.h>
#include <math.h>
#include <time.h>

//extern float temper_comp_table[][9];
//extern float temper_list[];	
	
/*
void FloatToChar(float fVal, char* cbuf)
{
	union F2C pun;
	pun.f = fVal;
	cbuf[0] = pun.cbuf[0];
	cbuf[1] = pun.cbuf[1];
	cbuf[2] = pun.cbuf[2];
	cbuf[3] = pun.cbuf[3];
}


float CharToFloat(char * in)
{
	union F2C pun;
	pun.cbuf[0] = in[0];
	pun.cbuf[1] = in[1];
	pun.cbuf[2] = in[2];
	pun.cbuf[3] = in[3];
	return pun.f;
}*/

void FloatToShort(float fVal, unsigned short* sbuf)
{
	union F2S pun;
	pun.f = fVal;
	sbuf[0] = pun.sbuf[0];
	sbuf[1] = pun.sbuf[1];
}

float ShortToFloat(unsigned short * in)
{
	union F2S pun;
	pun.sbuf[0] = in[0];
	pun.sbuf[1] = in[1];
	if(pun.f > 50000.0f)
		return 0.0f;
	if(pun.f < -50000.0f)
		return 0.0f;
	return pun.f;
}

uint32_t UInt8ArrToUInt32(uint8_t* buf, uint8_t start_idx)
{
	union UInt32UInt8 temp;
	temp.uint8_arr[0] = buf[start_idx + 1];
	temp.uint8_arr[1] = buf[start_idx];
	temp.uint8_arr[2] = buf[start_idx + 3];
	temp.uint8_arr[3] = buf[start_idx + 2];
	return temp.uint32_val;
}

float UInt8ArrToFloat(uint8_t* buf, uint8_t start_idx)
{
	union FloatUInt8 temp;
	temp.uint8_arr[0] = buf[start_idx + 1];
	temp.uint8_arr[1] = buf[start_idx];
	temp.uint8_arr[2] = buf[start_idx + 3];
	temp.uint8_arr[3] = buf[start_idx + 2];
	if(isnan(temp.float_val))
		return 0.0001f;
	if(temp.float_val > 50000.0f)
		return 0.0f;
	if(temp.float_val < -50000.0f)
		return 0.0f;
	
	return temp.float_val;	
}

void FloatToUInt8Arr(float fval, uint8_t* buf)
{
	union FloatUInt8 temp;
	temp.float_val = fval;
	buf[0] = temp.uint8_arr[1];
	buf[1] = temp.uint8_arr[0];
	buf[2] = temp.uint8_arr[3];
	buf[3] = temp.uint8_arr[2];
}

void UInt32ToUInt8Arr(uint32_t uval, uint8_t* buf)
{
	union UInt32UInt8 temp;
	temp.uint32_val = uval;
	buf[0] = temp.uint8_arr[1];
	buf[1] = temp.uint8_arr[0];
	buf[2] = temp.uint8_arr[3];
	buf[3] = temp.uint8_arr[2];
}
uint16_t UInt8ArrToUInt16(uint8_t* buf, uint8_t start_idx)
{
	union UInt16UInt8 temp;
	temp.uint8_arr[0] = buf[start_idx + 1];
	temp.uint8_arr[1] = buf[start_idx];
	return temp.uint16_val;
}

float UInt32ToFloat(uint32_t i_val)
{
	union Float2UInt32 temp;
	temp.int_val = i_val;
	if(isnan(temp.f_val))
		return 0.0f; 
	if(temp.f_val > 50000.0f)
		return 0.0f;
	if(temp.f_val < -50000.0f)
		return 0.0f;
	return temp.f_val;
}

uint32_t FloatToUInt32(float f_val)
{
	union Float2UInt32 temp;
	temp.f_val = f_val;
	return temp.int_val;
}

uint32_t ShortToUInt32(short* arr)
{
	union Short2UInt32 temp;
	temp.sArr[0] = arr[0];
	temp.sArr[1] = arr[1];
	return temp.iVal;
}

void UInt32ToShort(uint32_t ival, short* arr)
{
	union Short2UInt32 temp;
	temp.iVal = ival;
	arr[0] = temp.sArr[0];
	arr[1] = temp.sArr[1];
}

float select_nist_standard_ph(float ph_mv)
{
	float result;
	float std_array[5] = {1.68f,	4.005f,	7.00f,	10.01f,	12.46f};
	float std_mv_array[5] = {304.0f, 170.86f, 0.0f, -172.0f, -312.0f}; //{304.0f, 170.86f, 7.43f, -124.57f, -311.43f};
	float diff_min = 10000.0f;
	int i;

	for(i = 0; i < 5; i++)
	{
		if(diff_min * diff_min > (std_mv_array[i] - ph_mv) * (std_mv_array[i] - ph_mv))
		{
			diff_min = std_mv_array[i] - ph_mv;
			result = std_array[i];
		}
	}
	return result;
}

float select_tech_standard_ph(float ph_mv)
{
	float result;
	float tech_array[5] = {1.68f,4.008f,	6.865f,	9.184f,	12.454f};
	float tech_mv_array[5] = {304.0f, 170.86f, 7.43f, -124.57f, -311.43f}; //{304.0f, 170.86f, 0.0f, -172.0f, -312.0f};
	float diff_min = 10000.0f;
	int i;

	for(i = 0; i < 5; i++)
	{
		if(diff_min * diff_min > (tech_mv_array[i] - ph_mv) * (tech_mv_array[i] - ph_mv))
		{
			diff_min = tech_mv_array[i] - ph_mv;
			result = tech_array[i];
		}
	}

	return result;
}

 /*
float select_real_ph(float ph, float temp)
{
	float calc_ph = 0.0f;

	
	float temp_std[] = {1.68f,	3.78f,	4.01f,	6.86f,	7.00f,	7.41f,	9.18f,	10.00f,	12.45f};
	
	int i, idx = 0, idy = 0;

	float min_diff = (temp_std[0] - ph) * (temp_std[0] - ph);

	for(i = 1; i < 9; i++)
	{
		if((temp_std[i] - ph) * (temp_std[i] - ph) < min_diff)
		{
			min_diff = (temp_std[i] - ph) * (temp_std[i] - ph);
			idx = i;
		}
	}
	
	for(i = 1; i < 12; i++)
	{
		if(temp >= temper_list[i - 1] && temp < temper_list[i])
		{
			idy = i - 1;
			break;
		}
	}	
	
	if(temp < 0)
	{
		return temper_comp_table[0][idx];
	}
	
	if(temp >= 90)
	{
		return temper_comp_table[11][idx];
	}
		
	calc_ph = temper_comp_table[idy][idx] + (temper_comp_table[idy + 1][idx] - temper_comp_table[idy][idx]) * (temp - temper_list[idy]) / (temper_list[idy + 1] - temper_list[idy]);
	return calc_ph;
}	 */

float select_real_ph_nist(float ph, float temp)
{
	float calc_ph = 0.0f;
	float temper_comp_table1[][5]=
	{
		{1.67f,	4.00f,	7.115f,	10.32f,	13.42f},//0
		{1.67f,	4.00f,	7.085f,	10.25f,	13.21f},//5
		{1.67f,	4.00f,	7.06f,	10.18f,	13.01f},//10
		{1.67f,	4.00f,	7.04f,	10.12f,	12.80f},//15
		{1.675f,4.00f,	7.015f,	10.06f,	12.64f},//20
		{1.68f,	4.005f,	7.00f,	10.01f,	12.46f},//25
		{1.68f,	4.015f,	6.985f,	9.97f,	12.30f},//30
		{1.69f,	4.025f,	6.98f,	9.93f,	12.13f},//35
		{1.69f,	4.03f,	6.975f,	9.89f,	11.99f},//40
		{1.70f,	4.045f,	6.975f,	9.86f,	11.84f},//45
		{1.705f,4.06f,	6.97f,	9.83f,	11.71f},//50
		{1.715f,4.075f,	6.97f,	9.83f,	11.57f},//55
		{1.72f,	4.085f, 6.97f, 	9.83f,	11.45f},//60
		{1.73f,	4.10f, 	6.98f, 	9.83f,	11.45f},//65
		{1.74f, 4.13f, 	6.99f,	9.83f,	11.45f},//70
		{1.75f, 4.14f, 	7.01f,	9.83f,	11.45f},//75
		{1.765f,4.16f, 	7.03f,	9.83f,	11.45f},//80
		{1.78f, 4.18f, 	7.05f,	9.83f,	11.45f},//85
		{1.79f,	4.21f, 	7.08f, 	9.83f,	11.45f},//90
		{1.805f,4.23f, 	7.11f, 	9.83f,	11.45f} //95
	};
		
	float temp_std[] = {1.68f,	4.005f,	7.00f,	10.01f,	12.46f};
	
	int i, idx = 0, idy = 0;

	float min_diff = (temp_std[0] - ph) * (temp_std[0] - ph);

	for(i = 1; i < 5; i++)
	{
		if((temp_std[i] - ph) * (temp_std[i] - ph) < min_diff)
		{
			min_diff = (temp_std[i] - ph) * (temp_std[i] - ph);
			idx = i;
		}
	}
	
	for(i = 5; i < 100; i+=5)
	{
		if(temp >= (float)(i - 5) && temp < (float)i)
		{
			idy = i / 5 - 1;
			break;
		}
	}	
	
	if(temp < 0.0f)
	{
		calc_ph = temper_comp_table1[0][idx];
	}
	else if(temp >= 95.0f)
	{
		calc_ph = temper_comp_table1[19][idx];
	}
	else
	{
		calc_ph = temper_comp_table1[idy][idx] + (temper_comp_table1[idy + 1][idx] - temper_comp_table1[idy][idx]) * (temp - idy * 5.0f) / 5.0f;		
	}
	
	return calc_ph;	
}

float select_real_ph_tech(float ph, float temp)
{
	float calc_ph = 0.0f;
	float temper_comp_table1[][5]=
	{
		{1.668f,4.00f,	6.98f,	9.46f,	13.423f},//0
		{1.668f,4.004f,	6.950f,	9.392f,	13.207f},//5
		{1.670f,4.001f,	6.922f,	9.331f,	13.003f},//10
		{1.672f,4.001f,	6.900f,	9.277f,	12.810f},//15
		{1.676f,4.003f,	6.880f,	9.228f,	12.627f},//20
		{1.680f,4.008f,	6.865f,	9.184f,	12.454f},//25
		{1.685f,4.015f,	6.853f,	9.144f,	12.289f},//30
		{1.694f,4.028f,	6.841f,	9.095f,	12.133f},//37
		{1.697f,4.036f,	6.837f,	9.076f,	11.984f},//40
		{1.704f,4.049f,	6.834f,	9.046f,	11.841f},//45
		{1.712f,4.064f,	6.833f,	9.018f,	11.705f},//50
		{1.715f,4.075f,	6.834f,	8.985f,	11.574f},//55
		{1.723f,4.091f, 6.836f, 8.962f,	11.449f},//60
		{1.73f,	4.11f,	6.84f,	8.94f,	11.330f},//65
		{1.743f,4.126f, 6.845f,	8.921f,	11.210f},//70
		{1.75f,	4.14f,	6.85f,	8.90f,	11.100f},//75
		{1.766f,4.164f,	6.859f,	8.885f,	10.990f},//80
		{1.78f,	4.19f,	6.87f,	8.87f,	10.890f},//85
		{1.792f,4.205f,	6.877f, 8.850f,	10.790f},//90
		{1.806f,4.227f,	6.886f, 8.833f,	10.690f}//95
	};
		
	float temp_std[] = {1.680f,4.008f,	6.865f,	9.184f,	12.454f};	
	int i, idx = 0, idy = 0;

	float min_diff = (temp_std[0] - ph) * (temp_std[0] - ph);

	for(i = 1; i < 5; i++)
	{
		if((temp_std[i] - ph) * (temp_std[i] - ph) < min_diff)
		{
			min_diff = (temp_std[i] - ph) * (temp_std[i] - ph);
			idx = i;
		}
	}
	
	for(i = 5; i < 100; i+=5)
	{
		if(temp >= (float)(i - 5) && temp < (float)i)
		{
			idy = i / 5 - 1;
			break;
		}
	}	
	
	if(temp < 0.0f)
	{
		calc_ph = temper_comp_table1[0][idx];
	}
	else if(temp >= 95.0f)		//repaired at 20200707
	{
		calc_ph = temper_comp_table1[19][idx];
	}
	else
	{
		calc_ph = temper_comp_table1[idy][idx] + (temper_comp_table1[idy + 1][idx] - temper_comp_table1[idy][idx]) * (temp - idy * 5.0f) / 5.0f;
	}	
	return calc_ph;
}

uint32_t get_timestamp(uint8_t year, uint8_t month, uint8_t day, uint8_t hour, uint8_t min, uint8_t sec)
{
	struct tm stm, t_org;
	uint32_t timestamp;
	
	t_org.tm_year = 100;	
	t_org.tm_mon	= 0;
	t_org.tm_mday	= 1;
	t_org.tm_hour	= 0;	
	t_org.tm_min	= 0;   
	t_org.tm_sec	= 0;	
	
	stm.tm_year = year + 100;	
	stm.tm_mon	= month - 1;
	stm.tm_mday	= day;
	stm.tm_hour	= hour;	
	stm.tm_min	= min;   
	stm.tm_sec	= sec;	
	timestamp = mktime(&stm) - mktime(&t_org);
	return timestamp;
}

void timestamp_to_history_time_str(uint32_t timestamp, char* timestr)
{
	int year, month, day, hour; //, min, sec;
	struct tm t_org;
	struct tm *stm;

	t_org.tm_year = 100;	
	t_org.tm_mon	= 0;
	t_org.tm_mday	= 1;
	t_org.tm_hour	= 0;	
	t_org.tm_min	= 0;   
	t_org.tm_sec	= 0;
	
	timestamp += mktime(&t_org);
	stm = localtime(&timestamp);
	year = stm -> tm_year + 1900;
	month = stm->tm_mon + 1;
	day = stm->tm_mday;
	hour = stm->tm_hour;
//	min = stm->tm_min;
//	sec = stm->tm_sec;
	sprintf(timestr, "%04d/%02d/%02d %02d:00-%04d/%02d/%02d %02d:00", year, month, day, hour, year, month, day, hour);	
}

void timestamp_to_filename(uint32_t timestamp, char* filename)
{
	int year, month, day, hour; //, min, sec;
	struct tm t_org;
	struct tm *stm;

	t_org.tm_year = 100;	
	t_org.tm_mon	= 0;
	t_org.tm_mday	= 1;
	t_org.tm_hour	= 0;	
	t_org.tm_min	= 0;   
	t_org.tm_sec	= 0;
	
	timestamp += mktime(&t_org);
	stm = localtime(&timestamp);
	year = stm -> tm_year + 1900;
	month = stm->tm_mon + 1;
	day = stm->tm_mday;
	hour = stm->tm_hour;
//	min = stm->tm_min;
//	sec = stm->tm_sec;
	sprintf(filename, "3:/%04d/%02d/%02d/0000%02d.TXT", year, month, day, hour);
}

void timestamp_to_subdir_year(uint32_t timestamp, char* subdir)
{
	int year; //, month, day, hour, min, sec;
	struct tm t_org;
	struct tm *stm;

	t_org.tm_year = 100;	
	t_org.tm_mon	= 0;
	t_org.tm_mday	= 1;
	t_org.tm_hour	= 0;	
	t_org.tm_min	= 0;   
	t_org.tm_sec	= 0;
	
	timestamp += mktime(&t_org);
	stm = localtime(&timestamp);
	year = stm -> tm_year + 1900;
//	month = stm->tm_mon + 1;
//	day = stm->tm_mday;
//	hour = stm->tm_hour;
//	min = stm->tm_min;
//	sec = stm->tm_sec;
	sprintf(subdir, "3:/%04d", year);
}

void timestamp_to_subdir_month(uint32_t timestamp, char* subdir)
{
	int year, month; //, day, hour, min, sec;
	struct tm t_org;
	struct tm *stm;

	t_org.tm_year = 100;	
	t_org.tm_mon	= 0;
	t_org.tm_mday	= 1;
	t_org.tm_hour	= 0;	
	t_org.tm_min	= 0;   
	t_org.tm_sec	= 0;
	
	timestamp += mktime(&t_org);
	stm = localtime(&timestamp);
	year = stm -> tm_year + 1900;
	month = stm->tm_mon + 1;
//	day = stm->tm_mday;
//	hour = stm->tm_hour;
//	min = stm->tm_min;
//	sec = stm->tm_sec;
	sprintf(subdir, "3:/%04d/%02d", year, month);
}

void timestamp_to_subdir_day(uint32_t timestamp, char* subdir)
{
	int year, month, day; //, hour, min, sec;
	struct tm t_org;
	struct tm *stm;

	t_org.tm_year = 100;	
	t_org.tm_mon	= 0;
	t_org.tm_mday	= 1;
	t_org.tm_hour	= 0;	
	t_org.tm_min	= 0;   
	t_org.tm_sec	= 0;
	
	timestamp += mktime(&t_org);
	stm = localtime(&timestamp);
	year = stm -> tm_year + 1900;
	month = stm->tm_mon + 1;
	day = stm->tm_mday;
//	hour = stm->tm_hour;
//	min = stm->tm_min;
//	sec = stm->tm_sec;
	sprintf(subdir, "3:/%04d/%02d/%02d", year, month, day);
}

void timestamp_to_time_rtc(uint32_t timestamp, char* timestr)
{
	int year, month, day, hour, min, sec;
	struct tm t_org;
	struct tm *stm;

	t_org.tm_year = 100;	
	t_org.tm_mon	= 0;
	t_org.tm_mday	= 1;
	t_org.tm_hour	= 0;	
	t_org.tm_min	= 0;   
	t_org.tm_sec	= 0;
	
	timestamp += mktime(&t_org);
	stm = localtime(&timestamp);
	year = stm -> tm_year + 1900;
	month = stm->tm_mon + 1;
	day = stm->tm_mday;
	hour = stm->tm_hour;
	min = stm->tm_min;
	sec = stm->tm_sec;
	sprintf(timestr, "%04d-%02d-%02d %02d:%02d:%02d", year, month, day, hour, min, sec);	
}
