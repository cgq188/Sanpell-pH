#include "hw_config.h"
#include "PetitModbus.h"
#include "PetitModbusPort.h"
#include "SysTick/systick.h"
//#include "info.h"

#define RS485_TX	GPIO_SetBits(GPIOA,GPIO_Pin_1)
#define RS485_RX	GPIO_ResetBits(GPIOA,GPIO_Pin_1)

unsigned char   PetitReceiveBuffer[PETITMODBUS_RECEIVE_BUFFER_SIZE];
unsigned char   PetitReceiveCounter=0;
unsigned char   Rx_Pk_Flag = 0;

unsigned char   U3TxDmaBuf[PETITMODBUS_TRANSMIT_BUFFER_SIZE];
extern uint32_t dev_address;	

void PetitModBus_UART_Initialise(int baudrate)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;
	//  NVIC_InitTypeDef NVIC_InitStructure;

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_AFIO, ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE); 	////

	//485_D/R# -> PA1
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	GPIO_ResetBits(GPIOA,GPIO_Pin_1);

	//USART2_TX -> PA2 , USART2_RX ->	PA3
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	USART_InitStructure.USART_BaudRate = baudrate;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;

	USART_Init(USART2, &USART_InitStructure);
	USART_ClearFlag(USART2,USART_FLAG_TC);
	USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);
	//  USART_ITConfig(USART2, USART_IT_TXE, ENABLE);
	USART_Cmd(USART2, ENABLE);
}

void PetitModBus_TIMER_Initialise(void)
{
	TIM_TimeBaseInitTypeDef TIM_InitStructure;
	NVIC_InitTypeDef 				NVIC_InitStructure;

	RCC_APB1PeriphClockCmd(RCC_APB1ENR_TIM3EN, ENABLE);

	TIM_InitStructure.TIM_Period						=36000;
	TIM_InitStructure.TIM_Prescaler					=1;
	TIM_InitStructure.TIM_ClockDivision			=TIM_CKD_DIV1;
	TIM_InitStructure.TIM_RepetitionCounter	=0;
	TIM_InitStructure.TIM_CounterMode 			=TIM_CounterMode_Up;
	NVIC_InitStructure.NVIC_IRQChannel 		  =TIM3_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelCmd	  =ENABLE;

	TIM_TimeBaseInit(TIM3,&TIM_InitStructure);
	TIM_ITConfig(TIM3,TIM_IT_Update,ENABLE);
	NVIC_Init(&NVIC_InitStructure);
	TIM_Cmd(TIM3,ENABLE);
}



void PetitModBus_UART_Putch(unsigned char c)
{

	//Wait for the uart to finish sending the byte.
	while(USART_GetFlagStatus(USART2, USART_FLAG_TXE) == RESET);

	USART_SendData(USART2,c);

}

void uart_putc1(const char data, char port) 
{ 
	if(port == 1)
	{
		__NOP();
		USART_SendData(USART1,data);
		while(USART_GetFlagStatus(USART1,USART_FLAG_TXE)==RESET);
		while((USART_GetFlagStatus(USART1, USART_FLAG_TC)==RESET));
		__NOP();
	}
	else if(port == 2)
	{
		USART_SendData(USART2,data);
		while(USART_GetFlagStatus(USART2,USART_FLAG_TXE)==RESET);
		while((USART_GetFlagStatus(USART2, USART_FLAG_TC)==RESET));
	}
	else if(port == 4)
	{
		USART_SendData(UART4,data);
		while(USART_GetFlagStatus(UART4,USART_FLAG_TXE)==RESET);
		while((USART_GetFlagStatus(UART4, USART_FLAG_TC)==RESET));
	}
}

unsigned char PetitModBus_UART_String(unsigned char *s, unsigned int Length)
{

	RS485_TX;
	delay_ms(20); //(100), 20210309
	LED_485_ON;

	while(Length)
	{
		uart_putc1(*s++, 2);
		Length--;
	}

	LED_485_OFF;
	RS485_RX;
	//		delay_ms(10); //(100), 20210309
	return TRUE;
}

/***************************Interrupt For Slave********************************/

void USART2_IRQHandler(void)
{
	uint8_t rx_temp; //at 20201104
	if(USART_GetITStatus(USART2,USART_IT_RXNE)==SET)
	{
		//		LED_485_ON;
		rx_temp = USART_ReceiveData(USART2);
		if((rx_temp==(uint8_t)dev_address || rx_temp==0x0) && (PetitReceiveCounter==0)) //at 20210816
		{
			PetitReceiveBuffer[PetitReceiveCounter] = rx_temp;
			PetitReceiveCounter ++;
		}
		else if(PetitReceiveCounter==1)
		{
			if((rx_temp==0x03) || (rx_temp==0x10))
			{
				PetitReceiveBuffer[PetitReceiveCounter] = rx_temp;
				PetitReceiveCounter ++;
				Rx_Pk_Flag = 1;
			}
			else
				PetitReceiveCounter = 0;
		}
		else if((Rx_Pk_Flag==1) && (PetitReceiveCounter>1))
		{
			PetitReceiveBuffer[PetitReceiveCounter] = rx_temp;
			PetitReceiveCounter ++;
		}

		//	PetitReceiveBuffer[PetitReceiveCounter] = USART_ReceiveData(USART1);
		//  PetitReceiveCounter++;
		if(PetitReceiveCounter>=PETITMODBUS_RECEIVE_BUFFER_SIZE)
		{
			PetitReceiveCounter=0;
			Rx_Pk_Flag = 0;
		}

		PetitModbusTimerValue=0;
		//		LED_485_OFF;

		USART_ClearFlag(USART2, USART_IT_RXNE);
	}
}


/******************************************************************************/
void PetitModBus_TimerValues(void)
{
	PetitModbusTimerValue++;
}

void TIM3_IRQHandler(void)
{
	if(TIM_GetITStatus(TIM3,TIM_IT_Update)==SET)
	{
		TIM_ClearITPendingBit(TIM3, TIM_IT_Update);

		PetitModBus_TimerValues();
	}
}

