/*****************************************
* Name : hw_config.h
* Description : 
******************************************/
#include <stm32f10x.h>

#define 	TIME_1000MS			100  //10ms unit
#define 	TIME_RETURN			180

#define		FLASH_DATA_SIZE		150

#define   SIGNAL_IN_SENSOR	0
#define   SIGNAL_IN_RS485		1
#define   SIGNAL_IN_AIN			2

#define 	MEASURE_MODE_PH		0
#define 	MEASURE_MODE_ORP	1
//#define 	MEASURE_MODE_DO		2
//#define 	MEASURE_MODE_SS		3
//#define 	MEASURE_MODE_MLSS	4

#define 	MEASURE_MODE_ATC	0
#define 	MEASURE_MODE_MTC	1
#define 	TEMP_MODE_PT1000	0
#define 	TEMP_MODE_PT100		1

//-----------Analog1 out -----------------------------//
#define 	ANALOG1_STATE_OFF	0
#define 	ANALOG1_STATE_ON	1
#define 	ANALOG1_0_20			0
#define 	ANALOG1_4_20			1
#define 	ANALOG1_PHORP			0
#define 	ANALOG1_TEMPER		1
//-----------Analog2 out-----------------------------//
#define 	ANALOG2_STATE_OFF	0
#define 	ANALOG2_STATE_ON	1
#define 	ANALOG2_0_20			0
#define 	ANALOG2_4_20			1
#define 	ANALOG2_PHORP			0
#define 	ANALOG2_TEMPER		1

#define 	RELAY1_STATE_OFF	0
#define 	RELAY1_STATE_ON		1
#define 	RELAY1_LOW			0	//acid
#define 	RELAY1_HIGH			1	//alkali

#define 	RELAY2_STATE_OFF	0
#define 	RELAY2_STATE_ON		1
#define 	RELAY2_LOW			0
#define 	RELAY2_HIGH			1

#define 	TIMER_STATE_OFF		0
#define 	TIMER_STATE_ON		1

#define		CALIB_SAMPLES		20	
#define		CALIB_TIMEOUT		400	

#define		DATA_INTERVAL		10		//every 10s, save data once
#define 	RECORD_MAX			360		//one hour; 3600/10=360
#define 	READ_MAX				120		
#define 	FILE_MAX				744		//one month; 31*24=744


/*********************************************
*
**********************************************/


//////////////////////////////////////
#ifndef _HW_CONFIG_H
#define _HW_CONFIG_H

#define LED_RUN_ON		GPIO_ResetBits(GPIOA, GPIO_Pin_12)
#define LED_RUN_OFF		GPIO_SetBits(GPIOA, GPIO_Pin_12)
#define LED_485_ON		GPIO_ResetBits(GPIOA, GPIO_Pin_11)
#define LED_485_OFF		GPIO_SetBits(GPIOA, GPIO_Pin_11)

#define Relay1_Enable 	GPIO_SetBits(GPIOC,GPIO_Pin_9)
#define Relay1_Disable 	GPIO_ResetBits(GPIOC,GPIO_Pin_9)
#define Relay2_Enable 	GPIO_SetBits(GPIOC,GPIO_Pin_8)
#define Relay2_Disable 	GPIO_ResetBits(GPIOC,GPIO_Pin_8)
#define WashTimer_Enable	 	GPIO_SetBits(GPIOC,GPIO_Pin_7)
#define WashTimer_Disable 	GPIO_ResetBits(GPIOC,GPIO_Pin_7)

#define Env_Light_Sensor		GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_0)

/////////////////////////////////////////////////
void RCC_Configuration(void);
void GPIO_Configuration(void);
void NVIC_Configuration(void);

void HMI_Init(void);
void UpdateUI(void);
void RelayControl(void);
void SaveParams(void);
void GetParams(void);
void DispCalibTime(uint16_t screen_id);
void DispCalibTimeIdx(uint16_t screen_id, uint16_t control_id);
void DispLastCalibTime(uint16_t screen_id, uint16_t control_id);
void DispLastCalibORPTime(uint16_t screen_id, uint16_t control_id);

float Comp4To20mA(uint8_t ch, float data);
float ConvToAnalog1(void);
float ConvToAnalog2(void);
unsigned char RecordToTFCard(uint32_t time_stamp);
void ReadFromTFCard(uint32_t time_stamp);

void IWDG_Init(uint8_t prer, uint16_t rlr);
void IWDG_Feed(void);

#endif
