/************************************************
* Name : Info.h
* Description : Information about the product
*************************************************/

const char HW_Version[] = "1.0";
const char FW_version[] = "1.0";
const char SN_num[] = "1720002";
const char Factory_num[] = "1806";
const char Product_num[] = "1000";
