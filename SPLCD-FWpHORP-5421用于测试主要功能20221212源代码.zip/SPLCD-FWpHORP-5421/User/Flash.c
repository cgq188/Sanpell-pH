/*****************************************************************************************************
*
* File                : Flash.c
*
******************************************************************************************************/
#include "Flash.h"
#include "stdio.h"

/* Uncomment this line to Enable Write Protection */
//#define WRITE_PROTECTION_ENABLE
/* Uncomment this line to Disable Write Protection */
#define WRITE_PROTECTION_DISABLE


uint32_t *ptr1 =(uint32_t *)BANK1_WRITE_START_ADDR; 
uint32_t EraseCounter = 0x00, Address = 0x00;
uint32_t Data[LENGTH_SERIALNUM] = {'A','B','C','D'};
uint32_t Data_2[LENGTH_SERIALNUM];
	
	__IO uint32_t NbrOfPage = 0x00;
volatile FLASH_Status FLASHStatus = FLASH_COMPLETE;
volatile TestStatus MemoryProgramStatus = PASSED;
__IO uint32_t WRPR_Value = 0xFFFFFFFF, ProtectedPages = 0x0;


void WriteFlash_Data(uint16_t len, uint32_t add, uint32_t * data)
{
//	WWDG_DeInit();
	FLASH_SetLatency(FLASH_Latency_2);
	
	FLASHStatus = FLASH_COMPLETE;
	MemoryProgramStatus = PASSED;  
	EraseCounter = 0x0;

	FLASH_Unlock();

	/* Define the number of page to be erased */
	NbrOfPage = (BANK1_WRITE_END_ADDR - BANK1_WRITE_START_ADDR + 1) / FLASH_PAGE_SIZE;
  
	/* Clear All pending flags */
	FLASH_ClearFlag(FLASH_FLAG_EOP | FLASH_FLAG_PGERR | FLASH_FLAG_WRPRTERR);	
	
	/* Get pages write protection status */
	WRPR_Value = FLASH_GetWriteProtectionOptionByte();
	ProtectedPages = WRPR_Value & 0x000000C0;
	
#ifdef WRITE_PROTECTION_DISABLE
	if (ProtectedPages == 0x00)
	{
		/* Pages are write protected */

		/* Disable the write protection */
		FLASHStatus = FLASH_EraseOptionBytes();

		/* Generate System Reset to load the new option byte values */
		NVIC_SystemReset();
	}
	
#elif defined WRITE_PROTECTION_ENABLE
  
	if (ProtectedPages != 0x00)
	{ 
		/* Pages not write protected */

		/* Enable the pages write protection */
   #if defined (STM32F10X_HD) || defined (STM32F10X_CL) || defined (STM32F10X_XL)
		FLASHStatus = FLASH_EnableWriteProtection(FLASH_WRProt_Pages12to13 |FLASH_WRProt_Pages14to15);
   #else
		FLASHStatus = FLASH_EnableWriteProtection(FLASH_WRProt_Pages24to27 |FLASH_WRProt_Pages28to31); 
   #endif   
		/* Generate System Reset to load the new option byte values */
		NVIC_SystemReset();
	}
#endif
	/* If Pages are not write protected, perform erase and program operations
     Else nothing */
	
	if(ProtectedPages != 0x00)
	{
		/* Clear All pending flags */
		FLASH_ClearFlag(FLASH_FLAG_BSY | FLASH_FLAG_EOP|FLASH_FLAG_PGERR |FLASH_FLAG_WRPRTERR);	
		
		/* erase the FLASH pages */
		for(EraseCounter = 0; (EraseCounter < NbrOfPage) && (FLASHStatus == FLASH_COMPLETE); EraseCounter++)
		{
		  FLASHStatus = FLASH_ErasePage(BANK1_WRITE_START_ADDR + (FLASH_PAGE_SIZE * EraseCounter));
		}
  

		/* Program Flash Bank1 */
		Address = add;
			
		while((Address < BANK1_WRITE_END_ADDR) && (FLASHStatus == FLASH_COMPLETE))
		{

			int i;
			for(i=0;i<len;i++)
			{
				FLASHStatus = FLASH_ProgramWord(Address, data[i]);
				Address = Address + 4;
			}
		}
  
		//  FLASH_LockBank1();
		FLASH_Lock();
		
		/* Check the corectness of written data */
		Address = BANK1_WRITE_START_ADDR;

		while((Address < (BANK1_WRITE_START_ADDR + LENGTH_SERIALNUM*4)) && (MemoryProgramStatus != FAILED))
		{
			if((*(__IO uint32_t*) Address) != Data[0])
			{
				MemoryProgramStatus = FAILED;
			}
			Address += 4;
		}
	}
//	WWDG_NVIC_Configuration();
//	WD_Configuration();
	
}

void ReadFlash_Data(uint16_t len, uint32_t add, uint32_t * data)
{
	uint16_t i;
	uint32_t ReadAddr;
	ReadAddr = add;

	for(i=0;i<len;i++)
	{
		data[i] = *(uint32_t*)(ReadAddr);
		ReadAddr += 4;
	}
}

void WWDG_NVIC_Configuration(void)
{
	NVIC_InitTypeDef NVIC_InitStructure;
  
	/* 1 bits for pre-emption priority and 3 bits for subpriority */

	/* Set Button EXTI Interrupt priority to 0 (highest) */
	NVIC_SetPriority(EXTI9_5_IRQn, NVIC_EncodePriority(NVIC_GetPriorityGrouping(),0,0));

	/* Set WWDG interrupt vector Preemption Priority to 1 */
	NVIC_InitStructure.NVIC_IRQChannel = WWDG_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
}

void WD_Configuration(void)
{
	/* Add your application code here*/
	/* Check if the system has resumed from WWDG reset */
	if (RCC_GetFlagStatus(RCC_FLAG_WWDGRST) != RESET)
	{ 
		/* WWDGRST flag set */
   
//		printf(" System wd Rebooting!!! ");
		//wd_flag = 0;
		/* Clear reset flags */
		RCC_ClearFlag();
	}
	else
	{
		/* WWDGRST flag is not set */
		//wd_flag = 1;
	}

	/* NVIC configuration */
	WWDG_NVIC_Configuration();

	/* WWDG configuration */
	/* Enable WWDG clock */
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_WWDG, ENABLE);

	/* On Value line devices, WWDG clock counter = (PCLK1 (24MHz)/4096)/8 = 732 Hz (~1366 �s)  */
	/* On other devices, WWDG clock counter = (PCLK1(36MHz)/4096)/8 = 1099 Hz (~910 �s)  */
	WWDG_SetPrescaler(WWDG_Prescaler_8);

	/* Set Window value to 65 */
	WWDG_SetWindowValue(127);

	/* On Value line devices, Enable WWDG and set counter value to 127, WWDG timeout = ~1366 �s * 64 = 87.42 ms */
	/* On other devices, Enable WWDG and set counter value to 127, WWDG timeout = ~910 �s * 64 = 58.25 ms */
	WWDG_Enable(127);

	/* Clear EWI flag */
	WWDG_ClearFlag();

	/* Enable EW interrupt */
	WWDG_EnableIT();
}

