/****************************************************************************************
 * File                : ACQ.c
 * Discriptions				: Acqure the samples
 * Version             : V1.0
 * By                  : KJH
 * Date				 				: 2018-01-10
 *****************************************************************************************/
#include "ACQ.h"
#include "hw_config.h"
#include "hmi_driver.h"
#include "HAL/AD5421.h"

#define AD5421_FSR_MODE			0		//ѡ�������Χģʽ�� 0: 4-20mA ; 1: 3.8-21mA ; 2: 3.2-24mA
#define AD5421_DEFAULT_CURRENT	4		//����AD5421�ϵ�ʱ��ʼ�ĵ�������λmA�������÷�Χ4-20mA

float ADC_REF_VOLT = 4.096f; //

float temper_comp_table[][9]=
{
		{1.67f,	3.86f,	4.00f,	6.98f,	7.12f,	7.53f,	9.46f,	10.32f,	13.42f},//0
		{1.67f,	3.84f,	4.00f,	6.95f,	7.09f,	7.50f,	9.40f,	10.25f,	13.21f},//5
		{1.67f,	3.82f,	4.00f,	6.92f,	7.06f,	7.47f,	9.33f,	10.18f,	13.00f},//10
		{1.67f,	3.79f,	4.00f,	6.88f,	7.02f,	7.43f,	9.23f,	10.06f,	12.63f},//20
		{1.68f,	3.78f,	4.01f,	6.86f,	7.00f,	7.41f,	9.18f,	10.01f,	12.45f},//25
		{1.68f,	3.77f,	4.01f,	6.85f,	6.99f,	7.40f,	9.14f,	9.97f,	12.29f},//30
		{1.69f,	3.75f,	4.03f,	6.84f,	6.97f,	7.38f,	9.07f,	9.89f,	11.98f},//40
		{1.71f,	3.75f,	4.05f,	6.83f,	6.96f,	7.37f,	9.01f,	9.83f,	11.71f},//50
		{1.72f, 0.0f,		4.08f, 	6.84f,  0.0f, 	0.0f,		8.96f,	0.0f,		0.0f},  //60
		{1.74f, 0.0f,   4.12f, 	6.85f,	0.0f,		0.0f,		8.82f,	0.0f,		0.0f},	 //70
		{1.77f, 0.0f,	  4.16f, 	6.86f,	0.0f,		0.0f,		8.88f,	0.0f,		0.0f},  //80
		{1.79f,	0.0f,   4.21f, 	6.88f,  0.0f,   0.0f,		8.85f,	0.0f,		0.0f}  //90
};
float temper_list[]={0.0f,5.0f,10.0f,20.0f,25.0f,30.0f,40.0f,50.0f,60.0f,70.0f,80.0f,90.0f};

float PT1000_M49_P99[][10] = {
		{ 803.063, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
		{ 807.033, 806.604, 806.239, 805.842, 805.445, 805.048, 804.651, 804.254, 803.857, 803.460 },
		{ 811.003, 810.606, 810.209, 809.812, 809.415, 809.018, 808.621, 808.224, 807.827, 807.430 },
		{ 814.970, 814.573, 814.177, 813.780, 813.383, 812.987, 812.590, 812.193, 811.796, 811.400 },
		{ 818.937, 818.540, 818.144, 817.747, 817.350, 816.954, 816.557, 816.160, 815.763, 815.367 },
		{ 822.902, 822.506, 822.109, 821.713, 821.316, 820.920, 820.523, 820.127, 819.730, 819.334 },
		{ 826.865, 826.469, 826.072, 825.676, 825.280, 824.884, 824.487, 824.091, 823.695, 823.298 },
		{ 830.828, 830.432, 830.035, 829.639, 829.243, 828.847, 828.450, 828.054, 827.658, 827.261 },
		{ 834.789, 834.393, 833.997, 833.601, 833.205, 832.809, 832.412, 832.016, 831.620, 831.224 },
		{ 838.748, 838.352, 837.956, 837.560, 837.164, 836.769, 836.373, 835.977, 835.581, 835.185 },
		{ 842.707, 842.311, 841.915, 841.519, 841.123, 840.728, 840.332, 839.936, 839.540, 839.144 },
		{ 846.664, 846.268, 845.873, 845.477, 845.081, 844.686, 844.290, 843.894, 843.498, 843.103 },
		{ 850.619, 850.224, 849.828, 849.433, 849.037, 848.642, 848.246, 847.851, 847.455, 847.060 },
		{ 854.573, 854.179, 853.783, 853.388, 852.992, 852.597, 852.201, 851.806, 851.410, 851.015 },
		{ 858.526, 858.131, 857.735, 857.340, 856.945, 856.550, 856.154, 855.759, 855.364, 854.968 },
		{ 862.478, 862.082, 861.688, 861.292, 860.897, 860.502, 860.107, 859.712, 859.316, 858.921 },
		{ 866.428, 866.033, 865.638, 865.243, 864.848, 864.453, 864.058, 863.663, 863.268, 862.873 },
		{ 870.377, 869.982, 869.587, 869.192, 868.797, 868.403, 868.008, 867.613, 867.218, 866.823 },
		{ 874.325, 873.930, 873.535, 873.141, 872.746, 872.351, 871.956, 871.561, 871.166, 870.772 },
		{ 878.272, 877.877, 877.483, 877.088, 876.693, 876.299, 875.904, 875.509, 875.114, 874.720 },
		{ 882.217, 881.823, 881.428, 881.034, 880.639, 880.245, 879.850, 879.456, 879.061, 878.667 },
		{ 886.161, 885.766, 885.372, 884.978, 884.583, 884.189, 883.795, 883.400, 883.006, 882.611 },
		{ 890.103, 889.709, 889.315, 888.920, 888.526, 888.132, 887.738, 887.344, 886.949, 886.555 },
		{ 894.044, 893.650, 893.256, 892.862, 892.468, 892.074, 891.679, 891.285, 890.891, 890.497 },
		{ 897.985, 897.591, 897.197, 896.803, 896.409, 896.015, 895.620, 895.226, 894.832, 894.438 },
		{ 901.923, 901.529, 901.135, 900.742, 900.348, 899.954, 899.560, 899.166, 898.773, 898.379 },
		{ 905.861, 905.467, 905.073, 904.680, 904.286, 903.892, 903.498, 903.104, 902.711, 902.317 },
		{ 909.798, 909.404, 909.011, 908.617, 908.223, 907.830, 907.436, 907.042, 906.648, 906.255 },
		{ 913.733, 913.340, 912.946, 912.553, 912.159, 911.766, 911.372, 910.979, 910.585, 910.192 },
		{ 917.666, 917.273, 916.879, 916.486, 916.093, 915.700, 915.306, 914.913, 914.520, 914.126 },
		{ 921.599, 921.206, 920.812, 920.419, 920.026, 919.633, 919.239, 918.846, 918.453, 918.059 },
		{ 925.531, 925.138, 924.745, 924.351, 923.958, 923.565, 923.172, 922.779, 922.385, 921.992 },
		{ 929.460, 929.067, 928.674, 928.281, 927.888, 927.496, 927.103, 926.710, 926.317, 925.924 },
		{ 933.390, 932.997, 932.604, 932.211, 931.818, 931.425, 931.032, 930.639, 930.246, 929.853 },
		{ 937.317, 936.924, 936.532, 936.139, 935.746, 935.354, 934.961, 934.568, 934.175, 933.783 },
		{ 941.244, 940.851, 940.459, 940.066, 939.673, 939.281, 938.888, 938.495, 938.102, 937.710 },
		{ 945.170, 944.777, 944.385, 943.992, 943.600, 943.207, 942.814, 942.422, 942.029, 941.637 },
		{ 949.094, 948.702, 948.309, 947.917, 947.524, 947.132, 946.740, 946.347, 945.955, 945.562 },
		{ 953.016, 952.624, 952.232, 951.839, 951.447, 951.055, 950.663, 950.271, 949.878, 949.486 },
		{ 956.938, 956.546, 956.154, 955.761, 955.369, 954.977, 954.585, 954.193, 953.800, 953.408 },
		{ 960.859, 960.467, 960.075, 959.683, 959.291, 958.899, 958.506, 958.114, 957.722, 957.330 },
		{ 964.779, 964.387, 963.995, 963.603, 963.211, 962.819, 962.427, 962.035, 961.643, 961.251 },
		{ 968.697, 968.305, 967.913, 967.522, 967.130, 966.738, 966.346, 965.954, 965.563, 965.171 },
		{ 972.614, 972.222, 971.831, 971.439, 971.047, 970.656, 970.264, 969.872, 969.480, 969.089 },
		{ 976.529, 976.138, 975.746, 975.355, 974.963, 974.572, 974.180, 973.789, 973.397, 973.006 },
		{ 980.444, 980.053, 979.662, 979.270, 978.879, 978.487, 978.096, 977.704, 977.313, 976.921 },
		{ 984.358, 983.967, 983.575, 983.184, 982.793, 982.401, 982.010, 981.618, 981.227, 980.835 },
		{ 988.270, 987.879, 987.488, 987.096, 986.705, 986.314, 985.923, 985.532, 985.140, 984.749 },
		{ 992.181, 991.790, 991.399, 991.008, 990.617, 990.226, 989.834, 989.443, 989.052, 988.661 },
		{ 996.091, 995.700, 995.309, 994.918, 994.527, 994.136, 993.745, 993.354, 992.963, 992.572 },
		{ 1000.000, 1000.391, 1000.782, 1001.172, 1001.563, 1001.954, 1002.345, 1002.736, 1003.126, 1003.517 },
		{ 1003.908, 1004.298, 1004.689, 1005.080, 1005.470, 1005.861, 1006.252, 1006.642, 1007.033, 1007.424 },
		{ 1007.814, 1008.205, 1008.595, 1008.986, 1009.377, 1009.767, 1010.158, 1010.548, 1010.939, 1011.329 },
		{ 1011.720, 1012.110, 1012.501, 1012.891, 1013.282, 1013.672, 1014.062, 1014.453, 1014.843, 1015.234 },
		{ 1015.624, 1016.014, 1016.405, 1016.795, 1017.185, 1017.576, 1017.966, 1018.356, 1018.747, 1019.137 },
		{ 1019.527, 1019.917, 1020.308, 1020.698, 1021.088, 1021.478, 1021.868, 1022.259, 1022.649, 1023.039 },
		{ 1023.429, 1023.819, 1024.209, 1024.599, 1024.989, 1025.380, 1025.770, 1026.160, 1026.550, 1026.940 },
		{ 1027.330, 1027.720, 1028.110, 1028.500, 1028.890, 1029.280, 1029.670, 1030.060, 1030.450, 1030.840 },
		{ 1031.229, 1031.619, 1032.009, 1032.399, 1032.789, 1033.179, 1033.569, 1033.958, 1034.348, 1034.738 },
		{ 1035.128, 1035.518, 1035.907, 1036.297, 1036.687, 1037.077, 1037.466, 1037.856, 1038.246, 1038.636 },
		{ 1039.025, 1039.415, 1039.805, 1040.194, 1040.584, 1040.973, 1041.363, 1041.753, 1042.142, 1042.532 },
		{ 1042.921, 1043.311, 1043.701, 1044.090, 1044.480, 1044.869, 1045.259, 1045.648, 1046.038, 1046.427 },
		{ 1046.816, 1047.206, 1047.595, 1047.985, 1048.374, 1048.764, 1049.153, 1049.542, 1049.932, 1050.321 },
		{ 1050.710, 1051.099, 1051.489, 1051.878, 1052.268, 1052.657, 1053.046, 1053.435, 1053.825, 1054.214 },
		{ 1054.603, 1054.992, 1055.381, 1055.771, 1056.160, 1056.549, 1056.938, 1057.327, 1057.716, 1058.105 },
		{ 1058.495, 1058.884, 1059.273, 1059.662, 1060.051, 1060.440, 1060.829, 1061.218, 1061.607, 1061.996 },
		{ 1062.385, 1062.774, 1063.163, 1063.552, 1063.941, 1064.330, 1064.719, 1065.108, 1065.496, 1065.885 },
		{ 1066.274, 1066.663, 1067.052, 1067.441, 1067.830, 1068.218, 1068.607, 1068.996, 1069.385, 1069.774 },
		{ 1070.162, 1070.551, 1070.940, 1071.328, 1071.717, 1072.106, 1072.495, 1072.883, 1073.272, 1073.661 },
		{ 1074.049, 1074.438, 1074.826, 1075.215, 1075.604, 1075.992, 1076.381, 1076.769, 1077.158, 1077.546 },
		{ 1077.935, 1078.324, 1078.712, 1079.101, 1079.489, 1079.877, 1080.266, 1080.654, 1081.043, 1081.431 },
		{ 1081.820, 1082.208, 1082.596, 1082.985, 1083.373, 1083.762, 1084.150, 1084.538, 1084.926, 1085.315 },
		{ 1085.703, 1086.091, 1086.480, 1086.868, 1087.256, 1087.644, 1088.033, 1088.421, 1088.809, 1089.197 },
		{ 1089.585, 1089.974, 1090.362, 1090.750, 1091.138, 1091.526, 1091.914, 1092.302, 1092.690, 1093.078 },
		{ 1093.467, 1093.855, 1094.243, 1094.631, 1095.019, 1095.407, 1095.795, 1096.183, 1096.571, 1096.959 },
		{ 1097.347, 1097.734, 1098.122, 1098.510, 1098.898, 1099.286, 1099.674, 1100.062, 1100.450, 1100.838 },
		{ 1101.225, 1101.613, 1102.001, 1102.389, 1102.777, 1103.164, 1103.552, 1103.940, 1104.328, 1104.715 },
		{ 1105.103, 1105.491, 1105.879, 1106.266, 1106.654, 1107.042, 1107.429, 1107.817, 1108.204, 1108.592 },
		{ 1108.980, 1109.367, 1109.755, 1110.142, 1110.530, 1110.917, 1111.305, 1111.693, 1112.080, 1112.468 },
		{ 1112.855, 1113.242, 1113.630, 1114.017, 1114.405, 1114.792, 1115.180, 1115.567, 1115.954, 1116.342 },
		{ 1116.729, 1117.117, 1117.504, 1117.891, 1118.279, 1118.666, 1119.053, 1119.441, 1119.828, 1120.215 },
		{ 1120.602, 1120.990, 1121.377, 1121.764, 1122.151, 1122.538, 1122.926, 1123.313, 1123.700, 1124.087 },
		{ 1124.474, 1124.861, 1125.248, 1125.636, 1126.023, 1126.410, 1126.797, 1127.184, 1127.571, 1127.958 },
		{ 1128.345, 1128.732, 1129.119, 1130.127, 1129.893, 1130.280, 1130.667, 1131.054, 1131.441, 1131.828 },
		{ 1132.215, 1132.602, 1132.988, 1133.375, 1133.762, 1134.149, 1134.536, 1134.923, 1135.309, 1135.696 },
		{ 1136.083, 1136.470, 1136.857, 1137.243, 1137.630, 1138.017, 1138.404, 1138.790, 1139.177, 1139.564 },
		{ 1139.950, 1140.337, 1140.724, 1141.110, 1141.497, 1141.884, 1142.270, 1142.657, 1143.043, 1143.430 },
		{ 1143.817, 1144.203, 1144.590, 1144.976, 1145.363, 1145.749, 1146.136, 1146.522, 1146.909, 1147.295 },
		{ 1147.681, 1148.068, 1148.454, 1148.841, 1149.227, 1149.614, 1150.000, 1150.386, 1150.773, 1151.159 },
		{ 1151.545, 1151.932, 1152.318, 1152.704, 1153.091, 1153.477, 1153.863, 1154.249, 1154.636, 1155.022 },
		{ 1155.408, 1155.794, 1156.180, 1156.567, 1156.953, 1157.339, 1157.725, 1158.111, 1158.497, 1158.883 },
		{ 1159.270, 1159.656, 1160.042, 1160.428, 1160.814, 1161.200, 1161.586, 1161.972, 1162.358, 1162.744 },
		{ 1163.130, 1163.516, 1163.902, 1164.288, 1164.674, 1165.060, 1165.446, 1165.831, 1166.217, 1166.603 },
		{ 1166.989, 1167.375, 1167.761, 1168.147, 1168.532, 1168.918, 1169.304, 1169.690, 1170.076, 1170.461 },
		{ 1170.847, 1171.233, 1171.619, 1172.004, 1172.390, 1172.776, 1173.161, 1173.547, 1173.933, 1174.318 },
		{ 1174.704, 1175.090, 1175.475, 1175.861, 1176.247, 1176.632, 1177.018, 1177.403, 1177.789, 1178.174 },
		{ 1178.560, 1178.945, 1179.331, 1179.716, 1180.102, 1180.487, 1180.873, 1181.258, 1181.644, 1182.029 },
		{ 1182.414, 1182.800, 1183.185, 1183.571, 1183.956, 1184.341, 1184.727, 1185.112, 1185.597, 1185.883 },
		{ 1186.268, 1186.653, 1187.038, 1187.424, 1187.809, 1188.194, 1188.579, 1188.965, 1189.350, 1189.735 },
		{ 1190.120, 1190.505, 1190.890, 1191.276, 1191.661, 1192.046, 1192.431, 1192.816, 1193.201, 1193.586 },
		{ 1193.971, 1194.356, 1194.741, 1195.126, 1195.511, 1195.896, 1196.281, 1196.666, 1197.051, 1197.436 },
		{ 1197.821, 1198.206, 1198.591, 1198.976, 1199.361, 1199.746, 1200.131, 1200.516, 1200.900, 1201.285 },
		{ 1201.670, 1202.055, 1202.440, 1202.824, 1203.209, 1203.594, 1203.979, 1204.364, 1204.748, 1205.133 },
		{ 1205.518, 1205.902, 1206.287, 1206.672, 1207.056, 1207.441, 1207.826, 1208.210, 1208.595, 1208.980 },
		{ 1209.364, 1209.749, 1210.133, 1210.518, 1210.902, 1211.287, 1211.672, 1212.056, 1212.441, 1212.825 },
		{ 1213.210, 1213.594, 1213.978, 1214.363, 1214.747, 1215.120, 1215.516, 1215.901, 1216.285, 1216.669 },
		{ 1217.054, 1217.438, 1217.822, 1218.207, 1218.591, 1218.975, 1219.360, 1219.744, 1220.128, 1220.513 },
		{ 1220.897, 1221.281, 1221.665, 1222.049, 1222.434, 1222.818, 1223.202, 1223.586, 1223.970, 1224.355 },
		{ 1224.739, 1225.123, 1225.507, 1225.891, 1226.275, 1226.659, 1227.043, 1227.427, 1227.811, 1228.195 },
		{ 1228.579, 1228.963, 1229.347, 1229.731, 1230.115, 1230.499, 1230.883, 1231.267, 1231.651, 1232.035 },
		{ 1232.419, 1232.803, 1233.187, 1233.571, 1233.955, 1234.338, 1234.722, 1235.106, 1235.490, 1235.874 },
		{ 1236.257, 1236.641, 1237.025, 1237.409, 1237.792, 1238.176, 1238.560, 1238.944, 1239.327, 1239.711 },
		{ 1240.095, 1240.478, 1240.862, 1241.246, 1241.629, 1242.030, 1242.396, 1242.780, 1243.164, 1243.547 },
		{ 1243.931, 1244.314, 1244.698, 1245.081, 1245.465, 1245.848, 1246.232, 1246.615, 1246.999, 1247.382 },
		{ 1247.766, 1248.149, 1248.533, 1248.916, 1249.299, 1249.683, 1250.066, 1250.450, 1250.833, 1251.216 },
		{ 1251.600, 1251.983, 1252.366, 1252.749, 1253.133, 1253.516, 1253.899, 1254.283, 1254.666, 1255.049 },
		{ 1255.432, 1255.815, 1256.199, 1256.582, 1256.965, 1257.348, 1257.731, 1258.114, 1258.497, 1258.881 },
		{ 1259.264, 1259.647, 1260.030, 1260.413, 1260.796, 1261.179, 1261.562, 1261.945, 1262.328, 1262.711 },
		{ 1263.094, 1263.477, 1263.860, 1264.243, 1264.626, 1265.009, 1265.392, 1265.775, 1266.157, 1266.540 },
		{ 1266.923, 1267.306, 1267.689, 1268.072, 1268.455, 1268.837, 1269.220, 1269.603, 1269.986, 1270.368 },
		{ 1270.751, 1271.134, 1271.517, 1271.899, 1272.282, 1272.665, 1273.048, 1273.430, 1273.813, 1274.195 },
		{ 1274.578, 1274.691, 1274.803, 1274.916, 1275.029, 1275.141, 1275.254, 1275.366, 1275.479, 1275.591 },
		{ 1278.404, 1278.786, 1279.169, 1279.551, 1279.934, 1280.316, 1280.699, 1281.081, 1281.464, 1281.846 },
		{ 1282.228, 1282.611, 1282.993, 1283.376, 1283.758, 1284.140, 1284.523, 1284.905, 1285.287, 1285.670 },
		{ 1286.052, 1286.434, 1286.816, 1287.199, 1287.581, 1287.963, 1288.345, 1288.728, 1289.110, 1289.492 },
		{ 1289.874, 1290.256, 1290.638, 1291.021, 1291.403, 1291.785, 1292.167, 1292.549, 1292.931, 1293.313 },
		{ 1293.695, 1294.077, 1294.459, 1294.841, 1295.223, 1295.605, 1295.987, 1296.369, 1296.751, 1297.133 },
		{ 1297.515, 1297.897, 1298.279, 1298.661, 1299.043, 1299.425, 1299.807, 1300.188, 1300.570, 1300.952 },
		{ 1301.334, 1301.716, 1302.098, 1302.479, 1302.861, 1303.243, 1303.625, 1304.006, 1304.388, 1304.770 },
		{ 1305.152, 1305.533, 1305.915, 1306.297, 1306.678, 1307.060, 1307.442, 1307.823, 1308.205, 1308.586 },
		{ 1308.968, 1309.350, 1309.731, 1310.113, 1310.494, 1310.876, 1311.270, 1311.639, 1312.020, 1312.402 },
		{ 1312.783, 1313.165, 1313.546, 1313.928, 1314.309, 1314.691, 1315.072, 1315.453, 1315.835, 1316.216 },
		{ 1316.597, 1316.979, 1317.360, 1317.742, 1318.123, 1318.504, 1318.885, 1319.267, 1319.648, 1320.029 },
		{ 1320.411, 1320.792, 1321.173, 1321.554, 1321.935, 1322.316, 1322.697, 1323.079, 1323.460, 1323.841 },
		{ 1324.222, 1324.603, 1324.985, 1325.366, 1325.747, 1326.128, 1326.509, 1326.890, 1327.271, 1327.652 },
		{ 1328.033, 1328.414, 1328.795, 1329.176, 1329.557, 1329.938, 1330.319, 1330.700, 1331.081, 1331.462 },
		{ 1331.843, 1332.224, 1332.604, 1332.985, 1333.366, 1333.747, 1334.128, 1334.509, 1334.889, 1335.270 },
		{ 1335.651, 1336.032, 1336.413, 1336.793, 1337.174, 1337.555, 1337.935, 1338.316, 1338.697, 1339.078 },
		{ 1339.458, 1335.839, 1332.220, 1328.600, 1324.981, 1321.361, 1317.742, 1314.123, 1310.503, 1306.884 },
		{ 1343.264, 1343.645, 1344.025, 1344.406, 1344.786, 1345.167, 1345.570, 1345.928, 1346.308, 1346.689 },
		{ 1347.069, 1347.450, 1347.830, 1348.211, 1348.591, 1348.971, 1349.352, 1349.732, 1350.112, 1350.493 },
		{ 1350.873, 1351.253, 1351.634, 1352.014, 1352.394, 1352.774, 1353.155, 1353.535, 1353.915, 1354.295 },
		{ 1354.676, 1355.056, 1355.436, 1355.816, 1356.196, 1356.577, 1356.957, 1357.337, 1357.717, 1358.097 },
		{ 1358.477, 1358.857, 1359.237, 1359.617, 1359.997, 1360.377, 1360.757, 1361.137, 1361.517, 1361.897 },
		{ 1362.277, 1362.657, 1363.037, 1363.417, 1363.797, 1364.177, 1364.557, 1364.937, 1365.317, 1365.697 },
		{ 1366.077, 1366.456, 1366.836, 1367.216, 1367.596, 1367.976, 1368.355, 1368.735, 1369.115, 1369.495 },
		{ 1369.875, 1370.254, 1370.634, 1371.014, 1371.393, 1371.773, 1372.153, 1372.532, 1372.912, 1373.292 },
		{ 1373.671, 1374.051, 1374.431, 1374.810, 1375.190, 1375.569, 1375.949, 1376.329, 1376.708, 1377.088 },
		{ 1377.467, 1377.847, 1378.226, 1378.606, 1378.985, 1379.365, 1379.744, 1380.123, 1380.503, 1380.882 },
		{ 1381.262, 1381.641, 1382.020, 1382.400, 1382.779, 1383.158, 1383.538, 1383.917, 1384.296, 1384.676 },
		{ 1385.055, 0, 0, 0, 0, 0, 0, 0, 0, 0 }
};


float PT1000_P100_P150[][10] = {
		{ 1385.055, 1388.847, 1392.638, 1396.428, 1400.217, 1404.005, 1407.791, 1411.576, 1415.360, 1419.143 },
		{ 1422.925, 1426.706, 1430.485, 1434.264, 1438.041, 1441.817, 1445.592, 1449.366, 1453.138, 1456.910 },
		{ 1460.680, 1464.449, 1468.217, 1471.984, 1475.750, 1479.514, 1483.277, 1487.040, 1490.801, 1494.561 },
		{ 1498.319, 1502.077, 1505.833, 1509.589, 1513.343, 1517.096, 1520.847, 1524.598, 1528.381, 1532.139 },
		{ 1535.843, 1539.589, 1543.334, 1547.078, 1550.820, 1554.562, 1558.302, 1562.041, 1565.779, 1569.516 },
		{ 1573.251, 0, 0, 0, 0, 0, 0, 0, 0, 0 }
};

uint8_t adc_flag = 0;	//0:none,1:ORP, 2:temper 
uint8_t adcval_index = 0;
uint32_t adcval_temp[MAX_TEMP_PH];
uint32_t adcval_result = 0.0f;
float adc_mV_pre = 0.0f;
float ORP_temp[20];	//MAX_TEMP_PH
uint8_t ORP_temp_cnt = 0;

extern uint8_t signal_src;
extern uint8_t mode_temper_flag;

extern float pH_now_value;
extern float pH_calc_value;
extern float ORP_now_value;
extern float ORP_calc_value; 
extern float ORP_auto;
extern float ORP_avrg_value;

extern float Ain_now_value[2];
extern float Ain_calc_value[2];
extern float factory_analogIn_slope[2];
extern float factory_analogIn_offset[2];
extern float calib_Ain_offset[2];

extern float calib_pH_slope[2];			//0:Positive, 1:Negative
extern float calib_pH_offset[2];		//0:Positive, 1:Negative
extern float calib_slope;
extern float calib_ORP_offset;

extern float factory_ORP_slope[2];		//0:Positive, 1:Negative
extern float factory_ORP_offset[2];		//0:Positive, 1:Negative
extern float factory_temper_coeff[2];	//0:slope, 1:offset
extern float factory_analog_slope[2];	//0:analog1, 1:analog2
extern float factory_analog_offset[2];	//0:analog1, 1:analog2

extern float temper_now_res;
extern float temper_calc_res;
extern float temper_calc_value;
extern float temper_auto;
extern float temper_manual;
extern uint8_t temper_1000_100;
extern uint8_t mode_ATC_MTC;

uint16_t  timer_tick_count = 0; //

extern char* temper_mode[2];

extern uint32_t orp_calib_point_num_save;
extern float orp_calib_ref_val_save[11];
extern float orp_calib_measure_val_save[11];

extern uint32_t temp_calib_point_num_save;
extern float temp_calib_ref_val_save[11];
extern float temp_calib_measure_val_save[11];

uint32_t adc_val;
uint32_t orp_adc_val;
float orp_temp_store[ORP_SAMPLE_NUM];
float orp_temp_order[ORP_SAMPLE_NUM];
int orp_temp_index = 0;

uint16_t AD7793_err_count = 0;
extern uint16_t HMI_init_cnt;
extern float pH_calib_offset;

////////////////////////////////////////////////////////
static void AD7793_WriteReg(uint8_t addr,uint16_t dat)
{
	unsigned char buf[3];
	buf[0] = 0x00|((addr&0x07)<<3);
	buf[1] = 0xFF&(dat>>8);
	buf[2] = (uint8_t)(0x00FF&dat);

	AD7793_Enable;
	SPI1_SendRec(buf,buf,3);	
	AD7793_Disable;	
}

static uint8_t AD7793_ReadReg(uint8_t addr)
{
	unsigned char buf[2];
	buf[0]=0x40|((addr&0x07)<<3);

	AD7793_Enable;
	SPI1_SendRec(buf,buf,2);	
	AD7793_Disable;
	return buf[1];			
}

/////////////////////////////////////////////////////
//__inline int _ACQ_read_write(uint8_t data)
uint16_t _ACQ_read_write(uint8_t data)
{
	/* Loop while DR register in not emplty */
	while (SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_TXE) == RESET);

	/* Send byte through the SPI1 peripheral */
	SPI_I2S_SendData(SPI1, data);

	/* Wait to receive a byte */
	while (SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_RXNE) == RESET);

	/* Return the byte read from the SPI1 bus */
	return SPI_I2S_ReceiveData(SPI1);
}




/////////////////////////////////////////////////////
void SPI1_SendRec(uint8_t sendbuf[],uint8_t recbuf[],uint16_t bytes)
{
	uint16_t n;

	for(n=0;n<bytes;n++)
	{
		recbuf[n] = _ACQ_read_write(sendbuf[n]);
	}		
}



void AD7793_Configuration(void)
{		
	GPIO_InitTypeDef GPIO_InitStructure;
	SPI_InitTypeDef SPI_InitStructure;

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOC | RCC_APB2Periph_AFIO, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_SPI1, ENABLE);

	/* SPI1 Remap enable */
	//GPIO_PinRemapConfig(GPIO_Remap_SPI1, ENABLE);

	// SPI1_SCK -> PA5 , SPI1_MISO -> PA6 , SPI1_MOSI ->	PA7
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	// ACQ_CS -> PA4 
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	AD7793_Disable;

	// LT2602_DAC_CS -> PC5 
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
	LT2602_Disable;

	SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_128;	//select speed _32
	SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex;
	SPI_InitStructure.SPI_Mode = SPI_Mode_Master;
	SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;
	SPI_InitStructure.SPI_CPOL = SPI_CPOL_High;
	SPI_InitStructure.SPI_CPHA = SPI_CPHA_2Edge;
	SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;
	SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB;
	SPI_InitStructure.SPI_CRCPolynomial = 7;
	SPI_Init(SPI1, &SPI_InitStructure);

	SPI_Cmd(SPI1, ENABLE);

	C4To20mAFactory(  0, AD5421_DEFAULT_CURRENT);
}

void AD7793_Reset(void)
{
	uint16_t n;
	uint8_t sendbuf[1],recbuf[1];

	sendbuf[0]=0xff;
	AD7793_Enable;
	for(n=0; n<10; n++)
	{
		SPI1_SendRec(sendbuf,recbuf,1);	
	} 
	AD7793_Disable;	

}

void AD7793_StartSample(void)
{
	//16.7Hz��������ģʽ
	//	AD7788_WriteReg(0x01,0x200A);	//mode: Single conversion,Internal 64kHz, f(ADC)=16.7Hz
	AD7793_WriteReg(0x01,0x000A);	//mode: continuous conversion,Internal 64kHz, f(ADC)=16.7Hz
}

uint8_t AD7793_IsDataReady(void)
{
	if(AD7793_ReadReg(0x00)&0x80)
	{
		return 0;
	}		
	return 1;
}

uint8_t AD7793_IsErr(void)
{
	return (AD7793_ReadReg(0x00)&0x40);
}

uint32_t AD7793_GetADCVal(void)
{
	uint8_t buf[4];
	uint32_t result;
	buf[0] = 0x58;		//0x38, Data register

	AD7793_Enable;
	SPI1_SendRec(buf,buf,4);	
	AD7793_Disable;

	result = buf[1];
	result = (result<<8) | buf[2];
	result = (result<<8) | buf[3];
	return result;	
}

void AD7793_SetToPHChannal(void)
{
	//д���ƼĴ������л���ͨ��0 ����1 ��ʹ��buf
	AD7793_WriteReg(0x02,0x0010);	//config: bipolar, buffered mode, gain=1
}

void AD7793_SetToTempChannal(void)
{
	//	AD7793_WriteReg(0x02,0x0011);	 //config; bipolar, gain=1
	AD7793_WriteReg(0x02,0x0001);		//д���ƼĴ������л���ͨ��1 ����1 ��ʹ��amp�����뷶Χ2.5V
}

void AD7793_ExcitCurrent(void)
{
	uint8_t buf[2];
	buf[0] = 0x28;		//IO register
	buf[1] = 0x02;		//0x02, OUT2=210uA

	AD7793_Enable;
	SPI1_SendRec(buf,buf,2);	
	AD7793_Disable;
}

void AD7793_ExcitCurDisable(void)
{
	uint8_t buf[2];
	buf[0] = 0x28;		//IO register
	buf[1] = 0x00;		//

	AD7793_Enable;
	SPI1_SendRec(buf,buf,2);	
	AD7793_Disable;
}

//////////////////////////////////////////////////////
void ACQ_Init(void)
{
	uint16_t i = 0;
	//	AD7793_Configuration();
	AD7793_Reset();	
	AD7793_SetToTempChannal();	
	//	if(mode_ATC_MTC == MEASURE_MODE_ATC) //at 20210928
	AD7793_ExcitCurrent();

	for(i = 0; i < MAX_TEMP_PH; i++) //at 20210721
	{
		adcval_temp[i] = 0;
	}	
}

void SAMP_adcval(void)
{
	uint16_t i = 0;
	uint32_t maxPH = adcval_temp[0];
	uint32_t minPH = adcval_temp[0];
	uint32_t sum = adcval_temp[0];

	for(i = 1; i < MAX_TEMP_PH; i++)
	{
		if(adcval_temp[i] >= maxPH)
			maxPH = adcval_temp[i];
		if(adcval_temp[i] <= minPH)
			minPH = adcval_temp[i];
		sum += adcval_temp[i];
	}
	adcval_result = (sum-minPH-maxPH)/(MAX_TEMP_PH - 2);

	//	if(adc_flag==4)		//mV measure
	{
		//		adcval_result = adc_mV_pre*0.5f + adcval_result*0.5f;
		//		adc_mV_pre = adcval_result;
	} 

}

void SAMP_mV(void)
{
	uint16_t i = 0;
	float maxPH = ORP_temp[0];
	float minPH = ORP_temp[0];
	float sum = ORP_temp[0];

	/*	for(i=0; i<10; i++)
		temp_float += ORP_temp[i];
	ORP_avrg_value = temp_float/10; */

	for(i = 1; i < MAX_mV_SAMP; i++)
	{
		if(ORP_temp[i] >= maxPH)
			maxPH = ORP_temp[i];
		if(adcval_temp[i] <= minPH)
			minPH = ORP_temp[i];
		sum += ORP_temp[i];
	}
	ORP_avrg_value = (sum-minPH-maxPH)/(MAX_mV_SAMP - 2);

}

//#define mV2pH(v,s) (7.00f-v/s)
//#define pH2mV(ph,s) (s*(7.0f-ph))

float calc_real_orp(float measure_orp)
{
	float result = 0.0f;
	int i;
	if(measure_orp < orp_calib_measure_val_save[0])
	{
		result = orp_calib_ref_val_save[0] + (measure_orp - orp_calib_measure_val_save[0]) * (orp_calib_ref_val_save[1] - orp_calib_ref_val_save[0]) / (orp_calib_measure_val_save[1] - orp_calib_measure_val_save[0]);
	}
	else if(measure_orp >= orp_calib_measure_val_save[orp_calib_point_num_save - 1]) //at 20210816
	{
		result = orp_calib_ref_val_save[orp_calib_point_num_save - 1] + (measure_orp - orp_calib_measure_val_save[orp_calib_point_num_save - 1]) * (orp_calib_ref_val_save[orp_calib_point_num_save - 1] - orp_calib_ref_val_save[orp_calib_point_num_save - 2]) / (orp_calib_measure_val_save[orp_calib_point_num_save - 1] - orp_calib_measure_val_save[orp_calib_point_num_save - 2]);
	}
	else
	{
		for(i = 0; i < orp_calib_point_num_save - 1; i++)
		{
			if(measure_orp >= orp_calib_measure_val_save[i] && measure_orp < orp_calib_measure_val_save[i + 1])
			{
				result = orp_calib_ref_val_save[i] + (measure_orp - orp_calib_measure_val_save[i]) * (orp_calib_ref_val_save[i + 1] - orp_calib_ref_val_save[i]) / (orp_calib_measure_val_save[i + 1] - orp_calib_measure_val_save[i]);	
			}	
		}
	}
	return result;
}

float calc_real_temp(float measure_temp)
{
	float result = 0.0f;
	int i;
	if(measure_temp < temp_calib_measure_val_save[0])
	{
		result = temp_calib_ref_val_save[0] + (measure_temp - temp_calib_measure_val_save[0]) * (temp_calib_ref_val_save[1] - temp_calib_ref_val_save[0]) / (temp_calib_measure_val_save[1] - temp_calib_measure_val_save[0]);
	}
	else if(measure_temp > temp_calib_measure_val_save[temp_calib_point_num_save - 1])
	{
		result = temp_calib_ref_val_save[temp_calib_point_num_save - 1] + (measure_temp - temp_calib_measure_val_save[temp_calib_point_num_save - 1]) * (temp_calib_ref_val_save[temp_calib_point_num_save - 1] - temp_calib_ref_val_save[temp_calib_point_num_save - 2]) / (temp_calib_measure_val_save[temp_calib_point_num_save - 1] - temp_calib_measure_val_save[temp_calib_point_num_save - 2]);
	}
	else
	{
		for(i = 0; i < temp_calib_point_num_save - 1; i++)
		{
			if(measure_temp >= temp_calib_measure_val_save[i] && measure_temp < temp_calib_measure_val_save[i + 1])
			{
				result = temp_calib_ref_val_save[i] + (measure_temp - temp_calib_measure_val_save[i]) * (temp_calib_ref_val_save[i + 1] - temp_calib_ref_val_save[i]) / (temp_calib_measure_val_save[i + 1] - temp_calib_measure_val_save[i]);	
			}	
		}
	}
	return result;
} 

//1000*(1+0.00385*(t-25))
float select_temp_from_res(float res)
{
	float result = 0.0f;
	if (res <= 803.063f) 
	{
		result = -50.0f;
	}
	else if (res >= 1573.251f) 
	{
		result = 150.0f;
	}
	else if (res>=1385.055f && res<1573.251f) //at 20210922
	{
		int i, j;
		for (i = 0; i < 5; i++)
		{
			if (PT1000_P100_P150[i][0] <= res && PT1000_P100_P150[i + 1][0] > res)
			{
				int isSel = 0;
				for (j = 0; j < 9; j++)
				{
					if (PT1000_P100_P150[i][j] <= res && PT1000_P100_P150[i][j + 1] > res)
					{
						result = 100.0f + i * 10 + j + (res - PT1000_P100_P150[i][j]) / (PT1000_P100_P150[i][j + 1] - PT1000_P100_P150[i][j]);
						isSel = 1;
						break;
					}
				}
				if (isSel == 0)
					result = 100.0f + i * 10 + 9.0f + (res - PT1000_P100_P150[i][9]) / (PT1000_P100_P150[i + 1][0] - PT1000_P100_P150[i][9]);
				break;
			}
		}
	}
	else if (res>803.063f && res<1385.055f)
	{
		int i, j;
		if (res >= 1000.f)
		{
			for (i = 50; i < 150; i++)
			{
				if (PT1000_M49_P99[i][0] <= res && PT1000_M49_P99[i + 1][0] > res)
				{
					int isSel = 0;
					for (j = 0; j < 9; j++)
					{
						if (PT1000_M49_P99[i][j] <= res && PT1000_M49_P99[i][j + 1] > res)
						{
							result = -49.0f + i - 1.0f + j * 0.1 + (res - PT1000_M49_P99[i][j]) / (PT1000_M49_P99[i][j + 1] - PT1000_M49_P99[i][j]) * 0.1f;
							isSel = 1;
							break;
						}
					}
					if (isSel == 0)
						result = -49.0f + i - 1.0f + 0.9 + (res - PT1000_M49_P99[i][9]) / (PT1000_M49_P99[i + 1][0] - PT1000_M49_P99[i][9]) * 0.1f;
					break;
				}
			}
		}
		else //(803.063f, 1000.0f), 
		{
			if (res > 996.091f)
			{
				result = -1.0f + (res - 996.091f) / (1000.f - 996.091f);
			}				
			else //(-50, -1], at 220929
			{
				//	result = (res/1000.0f-1.0f)/0.00385f;
				for (i = 0; i < 50; i++)
				{
					if (PT1000_M49_P99[i][0] < res && PT1000_M49_P99[i + 1][0] >= res)
					{
						int isSel = 0;
						for (j = 0; j < 9; j++)
						{
							if (PT1000_M49_P99[i + 1][j] >= res && PT1000_M49_P99[i + 1][j + 1] < res)
							{
								result = -49.0f + i - j * 0.1 - (res - PT1000_M49_P99[i + 1][j]) / (PT1000_M49_P99[i + 1][j + 1] - PT1000_M49_P99[i + 1][j]) * 0.1f;
								isSel = 1;
								break;
							}
						}
						if (isSel == 0)
							result = -49.0f + i - 0.9 - (res - PT1000_M49_P99[i + 1][9]) / (PT1000_M49_P99[i][0] - PT1000_M49_P99[i + 1][9]) * 0.1f;
						break;
					}
				} 
			}			
		}
	}

	return result;
}

/*****************************************************************
 ** Every 20ms
 ** Sample cycle: 200ms ORP, 200ms wait, 200ms temper, 200ms wait
 ******************************************************************/
void ACQ_Sample(void)
{
	float temper_calc_res, orp_sample;

	if(AD7793_IsErr())//ERR state, at 20211109
	{
		AD7793_err_count++;
		if(AD7793_err_count > 10)
		{
			AD7793_err_count = 0;
			ACQ_Init();
			return;
		}
	}

	if(AD7793_IsDataReady())
	{
		adcval_temp[adcval_index] = AD7793_GetADCVal();
		adcval_index ++;
		if(adcval_index == MAX_TEMP_PH)
		{
			adcval_index = 0;
			adc_flag ++;
			SAMP_adcval();

			if(adc_flag == 1)
			{
				temper_now_res = 1000000.0f*(ADC_REF_VOLT*(adcval_result-8388608.0f)/8388608.0f)/210.0f;		//RTD resistor, VREF=4.096
				//temper_now_res = 10.0f*(2.5f*(adcval_result-8388608.0f)/8388608.0f);		//1000*V/R [mA]
				/*		if(temper_now_res>=1580.0f)		//no temper signal
					{
						mode_ATC_MTC = MEASURE_MODE_MTC;
						SetTextValue(0,6,temper_mode[mode_ATC_MTC]);
						//AnimationPlayFrame(0,6,mode_ATC_MTC);				
						mode_temper_flag = 1;
					}
					else if(temper_now_res<1580.0f)	
					{
						mode_ATC_MTC = MEASURE_MODE_ATC;
						SetTextValue(0,6,temper_mode[mode_ATC_MTC]);
						//AnimationPlayFrame(0,6,mode_ATC_MTC);
						mode_temper_flag = 0;
					}			*/		

				temper_calc_res = calc_real_temp(temper_now_res);// temper_now_res*factory_temper_coeff[0] + factory_temper_coeff[1];
				temper_auto = select_temp_from_res(temper_calc_res);// (temper_calc_res/temp_float-1.0f)/0.00385f;
				if(mode_ATC_MTC == MEASURE_MODE_ATC)
					temper_calc_value = temper_auto + calib_Ain_offset[1]; 	//at 20200512
				else if(mode_ATC_MTC == MEASURE_MODE_MTC)
					temper_calc_value = temper_manual;

				AD7793_SetToPHChannal();
			}

			else if(adc_flag > 1)
			{
				orp_sample = 1000.f*(ADC_REF_VOLT*(adcval_result-8388608.0f)/8388608.0f);	//mV, VREF=4.096
				ORP_temp[ORP_temp_cnt] = orp_sample;
				ORP_temp_cnt ++;
				if(ORP_temp_cnt == MAX_mV_SAMP)
				{
					ORP_temp_cnt = 0;
					SAMP_mV();

					/*if(ORP_now_value>0)
							ORP_auto = ORP_avrg_value*factory_ORP_slope[0] + factory_ORP_offset[0];	//Pos 
						else
							ORP_auto = ORP_avrg_value*factory_ORP_slope[1] + factory_ORP_offset[1];	//Neg*/
					ORP_auto = calc_real_orp(ORP_avrg_value);
					ORP_calc_value = ORP_auto;// + calib_ORP_offset;	//by 20180121

					pH_now_value = mV2pH(ORP_calc_value,temper_calc_value);
					if(pH_now_value<7.0f)
						pH_calc_value = pH_now_value*calib_pH_slope[0] + calib_pH_offset[0];		//Pos
					else
						pH_calc_value = pH_now_value*calib_pH_slope[1] + calib_pH_offset[1];		//Neg
					pH_calc_value += pH_calib_offset; //at 20211119

					AD7793_SetToTempChannal();
					adc_flag = 0;
				}
			}
		} //end of if(adcval_index == MAX_TEMP_PH)
	}  //end of if(AD7793_IsDataReady())

}


//#define mV2pH(v,s) (7.00f-v/s)
float mV2pH(float mV,float tempter)
{
	float s_temp;
	s_temp = 0.1984f*(273.16f+tempter);	
	return (7.0f - mV/s_temp);
}

//#define pH2mV(ph,s) (s*(7.0f-ph))
float pH2mV(float pH,float tempter)
{
	float s_temp;
	s_temp = 0.1984f*(273.16f+tempter);	
	return (s_temp*(7.0f - pH));
}

/********** get a class about standard pH ***************************/
uint16_t GetpHClass(float pH)
{
	uint16_t pH_index;

	if(pH<=temper_comp_table[11][0])	//(--,1.79]
		pH_index = 0;
	else if((pH>temper_comp_table[11][0]) && (pH<=temper_comp_table[0][1]))	//(1.79,3.86]
		pH_index = 1;
	else if((pH>temper_comp_table[0][1]) && (pH<=temper_comp_table[11][2]))	//(3.86,4.21]
		pH_index = 2;
	else if((pH>temper_comp_table[11][2]) && (pH<=temper_comp_table[0][3]))	//(4.21,6.98]
		pH_index = 3;
	else if((pH>temper_comp_table[0][3]) && (pH<=temper_comp_table[0][4]))	//(6.98,7.12]
		pH_index = 4;
	else if((pH>temper_comp_table[0][4]) && (pH<=temper_comp_table[0][5]))	//(7.21,7.53]
		pH_index = 5;
	else if((pH>temper_comp_table[0][5]) && (pH<=temper_comp_table[0][6]))	//(7.53,9.46]
		pH_index = 6;
	else if((pH>temper_comp_table[0][6]) && (pH<=temper_comp_table[0][7]))	//(9.46,10.32]
		pH_index = 7;
	else if((pH>temper_comp_table[0][7]) && (pH<=temper_comp_table[0][8]))	//(10.32,--)
		pH_index = 8;

	return pH_index;
}

/********** temperature complement about standard pH ************************/
float pHcompTemper(float pH, float temper)
{
	float comp_slope, comp_offset;
	uint16_t pH_index, i;

	pH_index = GetpHClass(pH);

	if((temper>=temper_list[0]) && (temper<=temper_list[7]))	//[0, 50]
	{
		for(i=0; i<8; i++)
		{
			if((temper>=temper_list[i]) && (temper<temper_list[i+1]))
			{		//y=ax+b, y:pH, x:temper
				comp_slope = (temper_comp_table[i][pH_index]-temper_comp_table[i+1][pH_index])/(temper_list[i]-temper_list[i+1]);
				comp_offset = temper_comp_table[i][pH_index] - comp_slope*temper_list[i];
				break;			
			}
		}
	}
	else if((temper>temper_list[7]) && (temper<=temper_list[11]))	//(50, 90]
	{
		if((pH_index==0) || (pH_index==2) || (pH_index==3) || (pH_index==6))
		{
			for(i=8; i<12; i++)
			{
				if((temper>=temper_list[i]) && (temper<temper_list[i+1]))
				{		//y=ax+b, y:pH, x:temper
					comp_slope = (temper_comp_table[i][pH_index]-temper_comp_table[i+1][pH_index])/(temper_list[i]-temper_list[i+1]);
					comp_offset = temper_comp_table[i][pH_index] - comp_slope*temper_list[i];
					break;			
				}
			}
		}
		else
		{
			comp_slope = 0.0f;
			comp_offset = 0.0f;
		}
	}
	else
	{
		comp_slope = 0.0f;
		comp_offset = 0.0f;
	}

	return (temper*comp_slope+comp_offset);
}

///******************************************************
// ** LT2602_DAC, use SPI1
// *******************************************************/
//static void LT2602_UpdateDAC(uint8_t ch, uint16_t val)
//{
//	uint32_t tmp;//,recdat;
//	uint8_t sendbuf[3];

//	tmp=((0x30|(ch&0x01))<<16)|val;	//0x30: cmd=write to and update
//	sendbuf[0]=tmp>>16;
//	sendbuf[1]=(tmp>>8)&0xff;
//	sendbuf[2]=(uint8_t)(tmp&0xff);

//	LT2602_Enable;
//	SPI1_SendRec(sendbuf,sendbuf,3);	
//	LT2602_Disable;	
//}











void C4To20mASet(uint8_t ch,float mA)
{
	//	float result;
	//
	//	result = mA*factory_analog_slope[ch]+factory_analog_offset[ch];
	//	/*****Vout=mA*100ohm/1000[V]=mA*0.1, k=Vout*65536/Vref****/
	//	result = result*0.1f*65536.0f/2.5f;
	//	LT2602_UpdateDAC(ch,(uint16_t)(result));

	float result;
	
	if(ch != 0 )
	{
		return ;
	}

	result = mA*factory_analog_slope[ch]+factory_analog_offset[ch];

#if (AD5421_FSR_MODE==0)
	if(result < 4.0) {
		result = 0;
	} else if(result > 20.0) {
		result = 65535;
	} else {
		result =  (result - 4) / 16 * 65536 ;
	}
#elif (AD5421_FSR_MODE==1)
	if(result < 3.8) {
		result = 0;
	} else if(result > 21.0) {
		result = 65535;
	} else {
		result =  (result - 3.8) / 17.2 * 65536 ;
	}
#elif (AD5421_FSR_MODE==2)
	if(result < 3.2) {
		result = 0;
	} else if(result > 24.0) {
		result = 65535;
	} else {
		result =  (result - 3.2) / 20.8 * 65536 ;
	}
#endif


	if((result + 0.5)   > 65535)
	{
		AD5421_UpdateDAC( 65535 );
	}
	else if(result < 0)
	{
		AD5421_UpdateDAC( 0 );
	}
	else
	{
		AD5421_UpdateDAC( (uint16_t) (result + 0.5) );
	}
}

void C4To20mAFactory(uint8_t ch,float mA)
{
	float result;
	
	if(ch != 0 )
	{
		return ;
	}
	//	float result;
	//	/*****Vout=mA*100ohm/1000[V]=mA*0.1, k=Vout*65536/Vref****/
	//	result = mA*0.1f*65536.0f/2.5f;
	//	LT2602_UpdateDAC(ch,(uint16_t)(result));



#if (AD5421_FSR_MODE==0)
	if(mA < 4.0) {
		result = 0;
	} else if(mA > 20.0) {
		result = 65535;
	} else {
		result =  (mA - 4) / 16 * 65536 ;
	}
#elif (AD5421_FSR_MODE==1)
	if(mA < 3.8) {
		result = 0;
	} else if(mA > 21.0) {
		result = 65535;
	} else {
		result =  (mA - 3.8) / 17.2 * 65536 ;
	}
#elif (AD5421_FSR_MODE==2)
	if(mA < 3.2) {
		result = 0;
	} else if(mA > 24.0) {
		result = 65535;
	} else {
		result =  (mA - 3.2) / 20.8 * 65536 ;
	}
#endif


	if((result + 0.5)   > 65535)
	{
		AD5421_UpdateDAC( 65535 );
	}
	else if(result < 0)
	{
		AD5421_UpdateDAC( 0 );
	}
	else
	{
		AD5421_UpdateDAC( (uint16_t) (result + 0.5) );
	}

}

