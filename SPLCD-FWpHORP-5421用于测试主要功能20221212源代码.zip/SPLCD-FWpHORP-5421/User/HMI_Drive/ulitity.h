#ifndef _ULITITY_H
#define _ULITITY_H

#include "hmi_user_uart.h"

void systicket_init(void);

void delay_ms(uint32 delay);

#endif
