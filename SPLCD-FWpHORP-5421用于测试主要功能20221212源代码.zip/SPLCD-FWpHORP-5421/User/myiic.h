#ifndef __MYIIC_H
#define __MYIIC_H
#include "stm32f10x.h"
#include "sys.h"

#define BIT_ADDR(addr, bitnum)   MEM_ADDR(BITBAND(addr, bitnum)) 

#define IIC_SCL    PBout(10) //SCL
#define IIC_SDA    PBout(11) 
#define READ_SDA   PBin(11)  

#define DELAY_IIC 	16

void SDA_IN(void);
void SDA_OUT(void);
void IIC_Init(void); 
void IIC_Start(void);	
void IIC_Stop(void);	 
void IIC_Send_Byte(u8 txd);	
u8 IIC_Read_Byte(unsigned char ack);
u8 IIC_Wait_Ack(void);
void IIC_Ack(void);	
void IIC_NAck(void);			

void IIC_Write_One_Byte(u8 daddr,u8 addr,u8 data);
u8 IIC_Read_One_Byte(u8 daddr,u8 addr);	  
#endif
















