/************************************************************************************
* File                	: ACQ.h
* Date				 	: 2018-01-10
************************************************************************************/
#ifndef __ACQ_H
#define __ACQ_H

#include <stm32f10x.h>

#define MAX_TEMP_PH	6
#define MAX_mV_SAMP	6
#define ORP_SAMPLE_NUM	20

/* Physical level marcos */
#define AD7793_Enable	 	GPIO_ResetBits(GPIOA,GPIO_Pin_4)
#define AD7793_Disable 	GPIO_SetBits(GPIOA,GPIO_Pin_4)
#define LT2602_Enable	 	GPIO_ResetBits(GPIOC,GPIO_Pin_5)
#define LT2602_Disable 	GPIO_SetBits(GPIOC,GPIO_Pin_5)










//void AD7793_WriteReg(uint8_t addr, uint16_t dat);
void SPI1_SendRec(uint8_t sendbuf[],uint8_t recbuf[],uint16_t bytes);
void AD7793_Configuration(void);
void AD7793_Reset(void);
void AD7793_SetToPHChannal(void);
void AD7793_SetToTempChannal(void);
void AD7793_ExcitCurrent(void);
void AD7793_ExcitCurDisable(void);
uint8_t AD7793_IsDataReady(void);
uint8_t AD7793_IsErr(void);
void AD7793_StartSample(void);
uint32_t AD7788_GetADCVal(void);

void ACQ_Init(void);
void ACQ_Sample(void);
void SAMP_mV(void);

float mV2pH(float mV,float tempter);
float pH2mV(float pH,float tempter);
float pHcompTemper(float pH, float temper);
uint16_t GetpHClass(float pH);

////////////////////////////////////////
void C4To20mAFactory(uint8_t ch,float mA);
void C4To20mASet(uint8_t ch,float mA);
void LT2602_UpdateDAC(uint8_t ch, uint16_t val);
void AD5421_UpdateDAC( uint16_t val);

#endif
