#ifndef __FLASH_H
#define __FLASH_H

#include "stm32f10x.h"

typedef enum {FAILED = 0, PASSED = !FAILED} TestStatus;

#define FLASH_PAGE_SIZE    ((uint16_t)0x800)
#define BANK1_WRITE_START_ADDR  ((uint32_t)0x08032000)// ((uint32_t)0x0806f800)
#define BANK1_WRITE_END_ADDR   ((uint32_t)0x080327ff) // ((uint32_t)0x0806ffff)

#define LENGTH_SERIALNUM		64
extern uint32_t *ptr1 ; 
extern uint32_t EraseCounter, Address ;
extern uint32_t Data[LENGTH_SERIALNUM] ;
extern uint32_t Data_2[LENGTH_SERIALNUM];
extern __IO uint32_t NbrOfPage;
extern volatile FLASH_Status FLASHStatus ;
extern volatile TestStatus MemoryProgramStatus ;

void WWDG_NVIC_Configuration(void);
void WD_Configuration(void);
void ReadFlash_Data(uint16_t len,uint32_t add, uint32_t * data);
void WriteFlash_Data(uint16_t len,uint32_t add, uint32_t * data);
#endif
