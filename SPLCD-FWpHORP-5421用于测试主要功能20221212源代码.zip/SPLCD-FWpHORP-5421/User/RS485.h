/************************************************************************************
* File         	: RS485.h
* Date				 	: 2018-01-10
************************************************************************************/
#ifndef __RS485_H
#define __RS485_H

#include <stm32f10x.h>

#define RS485In_REG_PH			0x10
#define RS485In_REG_TEMPER	0x12
#define RS485In_REG_ORP			0x14

#define RS485_TX	GPIO_SetBits(GPIOA,GPIO_Pin_1)
#define RS485_RX	GPIO_ResetBits(GPIOA,GPIO_Pin_1)
#define RS485In_TX	GPIO_SetBits(GPIOC,GPIO_Pin_1)
#define RS485In_RX	GPIO_ResetBits(GPIOC,GPIO_Pin_1)

///////////////////////////////////
//void RS485_Configuration(uint32_t BaudRate);
//void RS485RxProcess(uint8_t data);

/*void RS485TxBuf(uint8_t buf[], uint16_t length, uint8_t port);
void Rs485TxFloat(float value);
void RS485TxData(void);*/
//void RS485TxError(void);

void uart_putc(const char data, char port);
void uart_puts(const char *s, char port);

//void RS485In_Config(uint32_t BaudRate);
//void RS485InCmd(uint8_t addr,uint16_t reg);
//void RS485InProcess(uint8_t data);

#endif
