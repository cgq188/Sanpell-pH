/*********************************************************************************************************
 *
 * File                : timer.c
 * Hardware Environment:
 * Build Environment   : RealView MDK-ARM  Version: 4.20
 * Version             : V1.0
 * By                  : KJH
 * Date				  : 2017-11-20
 *
 *********************************************************************************************************/
#include "stm32f10x.h"
#include "timer.h"
#include "ACQ.h"
#include "hw_config.h"

//#include "SysTick/systick.h" 

extern uint16_t display_cnt;

extern uint16_t timer_tick_count;
extern uint8_t ACQ_Enable;
extern float ORP_calc_value;

float ORP_calc_value_prev = 0.0f; 

/**************************************************
 ** Tout=(arr+1)*(psc+1)/72M
 ****************************************************/
void TIM_Configuration(void)
{
	TIM_TimeBaseInitTypeDef  timerInitStructure;

	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);

	/* TIM2 configuration */
	timerInitStructure.TIM_Prescaler = 7199;
	timerInitStructure.TIM_CounterMode = TIM_CounterMode_Up;
	timerInitStructure.TIM_Period = 99;	 	//10ms:99. 20ms:199
	timerInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
	timerInitStructure.TIM_RepetitionCounter = 0;
	TIM_TimeBaseInit(TIM2, &timerInitStructure);

	/* TIM2 enable counter */
	TIM_Cmd(TIM2, ENABLE);

	/* Enable TIM2 Update interrupt */
	TIM_ITConfig(TIM2, TIM_IT_Update, ENABLE);
}

/**
 * @brief  This function handles TIM2 Handler.
 * @param  None
 * @retval None
 */
void TIM2_IRQHandler(void)
{
	if(TIM_GetITStatus(TIM2, TIM_IT_Update) != RESET)
	{
		/* Clear TIM2 update interrupt */
		TIM_ClearITPendingBit(TIM2, TIM_IT_Update);

		display_cnt ++;
		//	timer_tick_count ++;	//for ACQ test
		if(ACQ_Enable)
		{
			ACQ_Sample();
		}

	}
}

