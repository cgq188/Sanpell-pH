/********************************************************************************
 Author             : CAST (China Applications Support Team) 

 Date               : 6-21-2011

 File name          : AD5421.C

 Description        : Using ADuC7026 to CONTROL AD5421 in software SPI form through GPIO.

 Hardware plateform : ADuC7026 + AD5421	
 ********************************************************************************/
#include <stm32f10x.h>
#include "hw_config.h"
#include "hmi_driver.h"
#include "HAL/AD5421.h"



#define AD5421_Enable	 	GPIO_ResetBits(GPIOC,GPIO_Pin_5)
#define AD5421_Disable 		GPIO_SetBits(GPIOC,GPIO_Pin_5)



#define AD5421_SCK_SET	 	GPIO_SetBits(GPIOA,GPIO_Pin_5)
#define AD5421_SCK_CLR 		GPIO_ResetBits(GPIOA,GPIO_Pin_5)

#define AD5421_MOSI_SET	 	GPIO_SetBits(GPIOA,GPIO_Pin_7)
#define AD5421_MOSI_CLR 	GPIO_ResetBits(GPIOA,GPIO_Pin_7)




#define AD5421_MISO_GET()	GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_6)


static void Delay(unsigned long int DelayTime)			  //delay function,Delay(1)=10us
{
	unsigned char i;

	while(DelayTime>0)
	{
		for(i=0;i<32*6;i++) {}
		DelayTime--;
	}
}

static uint16_t spi_access(uint8_t data)
{
	/* Loop while DR register in not emplty */
	while (SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_TXE) == RESET);

	/* Send byte through the SPI1 peripheral */
	SPI_I2S_SendData(SPI1, data);

	/* Wait to receive a byte */
	while (SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_RXNE) == RESET);

	/* Return the byte read from the SPI1 bus */
	return SPI_I2S_ReceiveData(SPI1);
}

static void WriteToAD5421ViaSpi(long int *RegisterData)
{
	SPI_InitTypeDef SPI_InitStructure;

	long int TempData = 0;
	TempData = *RegisterData;


	SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_128;	//select speed _32
	SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex;
	SPI_InitStructure.SPI_Mode = SPI_Mode_Master;
	SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;
	SPI_InitStructure.SPI_CPOL = SPI_CPOL_Low;
	SPI_InitStructure.SPI_CPHA = SPI_CPHA_2Edge;
	SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;
	SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB;
	SPI_InitStructure.SPI_CRCPolynomial = 7;
	SPI_Init(SPI1, &SPI_InitStructure);

	AD5421_Enable;

	spi_access(TempData>>16  );
	spi_access(TempData>>8  );
	spi_access(TempData>>0  );


	AD5421_Disable;

	SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_128;	//select speed _32
	SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex;
	SPI_InitStructure.SPI_Mode = SPI_Mode_Master;
	SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;
	SPI_InitStructure.SPI_CPOL = SPI_CPOL_High;
	SPI_InitStructure.SPI_CPHA = SPI_CPHA_2Edge;
	SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;
	SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB;
	SPI_InitStructure.SPI_CRCPolynomial = 7;
	SPI_Init(SPI1, &SPI_InitStructure);

	// Load DAC register only this way can work
	//	AD5421_spiOutputBit(AD5421_LDAC,0);
	Delay(10);
	//	AD5421_spiOutputBit(AD5421_LDAC,1);
	Delay(5);

}


//static void ReadFromAD5421ViaSpi(long int *RegisterData,long int RegAddress)
//{
//	long int cstr,putdata=0;
//	long int tempdata = AD5421_NOP;
//	unsigned char i;
//
//	cstr = RD | RegAddress;
//	WriteToAD5421ViaSpi(&cstr);
//
//	AD5421_Enable;
//	for(i=0; i<24; i++)
//	{
//		AD5421_SCK_SET	 	 ;
//		if(0x800000 == (tempdata & 0x800000))
//		{
//			AD5421_MOSI_SET;	  //Send one to DIN pin
//		}
//		else
//		{
//			AD5421_MOSI_CLR;	  //Send zero to DIN pin
//		}
//
//		AD5421_SCK_CLR	 ;
//		tempdata<<= 1;	//Rotate data
//		putdata<<=1;
//
//		if(AD5421_MISO_GET() != Bit_RESET)
//		{
//			putdata |= 1 ;
//		}
//	}
//	*RegisterData=putdata;
//
//	AD5421_Disable;
//	Delay(10);
//
//}



void AD5421_Init()
{
	long int cstr = 0;
 
 
	/*
	 * To read back a register, Bit D11 of the control register must be set
	 * to Logic 1 to disable the automatic readback of the fault register.
	 * In the meantime, you must disable the spi watchdog
	 */
	cstr = WR | CONTROL_REGISTER  | 0x7800;
	WriteToAD5421ViaSpi(&cstr);


	/*
	 *  The output range is 4mA to 20mA, in this range it satisfied the function equation in datasheet(page 29),
	 *  and if you set the output, according to the function, lower than 4mA, it will stay at 4mA, or if you set
	 *  the output higher than 20mA, it will stay at 20mA.
	 */

	cstr = WR | DAC_REGISTER | 0x4000; 	//output current = 12mA
	WriteToAD5421ViaSpi(&cstr);


	cstr = WR | OFFSET_ADJUST_REGISTER | 0x8000; 	//default value of the offset register
	WriteToAD5421ViaSpi(&cstr);

	cstr = WR | GAIN_ADJUST_REGISTER | 0xFFFF; 		//default value of the gain register
	WriteToAD5421ViaSpi(&cstr);




}	
/******************************************************
 ** AD5421, use SPI1
 *******************************************************/
void AD5421_UpdateDAC(uint16_t val)
{
	long int cstr = 0;

	/*
	 * To read back a register, Bit D11 of the control register must be set
	 * to Logic 1 to disable the automatic readback of the fault register.
	 * In the meantime, you must disable the spi watchdog
	 */
	cstr = WR | CONTROL_REGISTER  | 0x7800;
	WriteToAD5421ViaSpi(&cstr);

	cstr = WR | DAC_REGISTER | val; 	//output current = 12mA
	WriteToAD5421ViaSpi(&cstr);
}




