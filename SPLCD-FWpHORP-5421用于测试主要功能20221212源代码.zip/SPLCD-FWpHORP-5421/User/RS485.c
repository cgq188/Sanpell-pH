/****************************************************************************************
* File                : RS485.c
* Discriptions		  	: RS485 communication
* Version             : V1.0
* By                  : KJH
* Date				  			: 2018-01-10
*****************************************************************************************/
#include "hw_config.h"
#include "RS485.h"
#include "SysTick/systick.h" 
#include <stdio.h>
#include <string.h>

///////////////////////////////////////
/*
extern uint8_t sensor_addr;
extern uint8_t signal_src;
extern uint8_t RS485In_cmd_flag;

extern uint32_t dev_address;
extern uint8_t mode_pH_ORP;
extern uint8_t mode_ATC_MTC;
extern float pH_calc_value;
extern float ORP_calc_value; 
extern float temper_calc_value;
extern float temper_manual;

extern uint8_t	analogIn1_type;
extern uint8_t	analogIn2_type;
extern float Ain_real_raw[2];
extern float Ain_real_value[2];
extern float calib_Ain_offset[2];

extern char SN_num[]; 
extern uint8_t now_year, now_month, now_day, now_hour, now_minute, now_sec;
extern uint32_t RS485_baudrate;	
extern uint8_t rx485_conn_flag;
extern uint16_t rs485_cnt_out;

uint8_t	Rx_Pk_Flag = 0;
//uint8_t	Rx_Buf[32];
//uint8_t Tx_Buf[32];

uint8_t	 Rx_Error_State = 2;
uint16_t Rx_Index = 0;
uint16_t Rx_Index_SN = 0;

uint8_t  Rx_Data_Len = 0;
uint8_t	 Tx_Data_Len = 0;	
uint16_t	usart_delay_cnt = 0;
////////////////////////////////////////////////
uint8_t	Rx_Pk_Flag2 = 0;
//uint8_t	Rx_Buf2[32];
//uint8_t Tx_Buf2[32];

//uint16_t Rx_Index2 = 0;
//uint8_t  Rx_Data_Len2 = 0;
//uint8_t	 Tx_Data_Len2 = 0;	
//uint16_t	usart_delay_cnt2 = 0;*/

////////////////////////////////////////////////////////
/*
void RS485_Configuration(uint32_t BaudRate)
{ 
  GPIO_InitTypeDef GPIO_InitStructure;
  USART_InitTypeDef USART_InitStructure; 
//  NVIC_InitTypeDef NVIC_InitStructure;

  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_AFIO, ENABLE);	 
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE); 	////
	
	//485_D/R# -> PA1
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;	         
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; 
  GPIO_Init(GPIOA, &GPIO_InitStructure);
	RS485_RX;	 
	
  //USART2_TX -> PA2 , USART2_RX ->	PA3
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;	         
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP; 
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; 
  GPIO_Init(GPIOA, &GPIO_InitStructure);		   

  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;	        
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;  
  GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	USART_InitStructure.USART_BaudRate = BaudRate;
  USART_InitStructure.USART_WordLength = USART_WordLength_8b;
  USART_InitStructure.USART_StopBits = USART_StopBits_1;	//USART_StopBits_1
  USART_InitStructure.USART_Parity = USART_Parity_No;
  USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
  USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;

  USART_Init(USART2, &USART_InitStructure); 
  USART_ClearFlag(USART2,USART_FLAG_TC);
  USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);
//  USART_ITConfig(USART2, USART_IT_TXE, ENABLE);
  USART_Cmd(USART2, ENABLE);

}*/

/************************************************************************* 
 *				transmit one byte to USART 
 **************************************************************************/ 
void uart_putc(const char data, char port) 
{ 
	if(port == 1)
	{
		__NOP();
		USART_SendData(USART1,data);
		while(USART_GetFlagStatus(USART1,USART_FLAG_TXE)==RESET);
		while((USART_GetFlagStatus(USART1, USART_FLAG_TC)==RESET));
		__NOP();
	}
	else if(port == 2)
	{
		USART_SendData(USART2,data);
		while(USART_GetFlagStatus(USART2,USART_FLAG_TXE)==RESET);
		while((USART_GetFlagStatus(USART2, USART_FLAG_TC)==RESET));
	}
	else if(port == 4)
	{
		USART_SendData(UART4,data);
		while(USART_GetFlagStatus(UART4,USART_FLAG_TXE)==RESET);
		while((USART_GetFlagStatus(UART4, USART_FLAG_TC)==RESET));
	}
}

/*******************************************************************
*				Send full message
*******************************************************************/
/*
void RS485TxBuf(uint8_t buf[], uint16_t length, uint8_t port)
{
	uint16_t i;

	for ( i	= 0; i < length; i++ )
	{
		uart_putc(buf[i], port);
	}
}*/

/************************************************************************* 
 *			transmit null-terminated string to USART 
 **************************************************************************/ 
void uart_puts(const char *str, char port) 
{ 
	while (*str) 
	{ 
		uart_putc(*str++, port); 
	} 
}


/*******************************************************************
*			process received packet and return result code.
*     packet : AA len <data> crc
* 		rx_data: $xxLV
*  		tx_data: $xxLV type(P/O) <pH/ORP(7)> T <temper(5)>
*******************************************************************/ 		
/*
void RS485RxProcess(uint8_t data)
{
	uint8_t CRC_temp;
	uint16_t i, temp_MLSS;
	int16_t temp_int16;
	uint32_t temp_uint32;
	
	//CRC_rx = data;
//	Rx_Error_State	= 0;
	
	//---------------- command table ---------------------//
	if(Rx_Buf[3]==0x01)		//ask the measure value
	{
		RS485_TX;
		delay_ms(1);		//10ms
		Tx_Buf[0] = 0xAA;	Tx_Buf[1] = 0x0B;
		Tx_Buf[2] = Rx_Buf[2];	Tx_Buf[3] = Rx_Buf[3];
		Tx_Buf[4] = analogIn1_type;
		Tx_Buf[4] = (Tx_Buf[4]<<4) | analogIn2_type; 
		
		switch(analogIn1_type)
		{
			case 0:
			case 2:
				temp_int16 = (int16_t)(Ain_real_value[0]*100.0f);	break;
			case 1:
			case 3:
			case 5:			
				temp_int16 = (int16_t)(Ain_real_value[0]*10.0f);	break;
		//	case 4:	//MLSS
		//		temp_int16 = (int32_t)(Ain_real_value[0]);	break; 
			default:
				break;
		}
		if(analogIn1_type==4)	//MLSSS
		{
			temp_MLSS = (uint16_t)Ain_real_value[0]; 
			Tx_Buf[5] = (temp_MLSS>>8) & 0x00ff;
			Tx_Buf[6] = (temp_MLSS) & 0x00ff;	
		}
		else
		{
			Tx_Buf[5] = (temp_int16>>8) & 0x00ff;
			Tx_Buf[6] = (temp_int16) & 0x00ff;	
		}		
				
		//temper_calc_value = -10.5f;	//for test
		switch(analogIn2_type)
		{
			case 0:
			case 2:
				temp_int16 = (int16_t)(Ain_real_value[1]*100.0f);	break;
			case 1:
			case 3:
			case 5:			
				temp_int16 = (int16_t)(Ain_real_value[1]*10.0f);	break;
			//case 4:	//MLSS
			//	temp_int32 = (int32_t)(Ain_real_value[1]);	break; 
			default:
				break;
		}
		if(analogIn2_type==4)	//MLSSS
		{
			temp_MLSS = (uint16_t)Ain_real_value[1]; 
			Tx_Buf[7] = (temp_MLSS>>8) & 0x000ff;
			Tx_Buf[8] = (temp_MLSS) & 0x00ff;	
		}
		else
		{
			Tx_Buf[7] = (temp_int16>>8) & 0x00ff;
			Tx_Buf[8] = (temp_int16) & 0x00ff;	
		}		

		CRC_temp = Tx_Buf[0];
		for(i=1; i<9; i++)
			CRC_temp = CRC_temp ^ Tx_Buf[i];
		Tx_Buf[9] = CRC_temp;
		
		RS485TxBuf(Tx_Buf, 10, 2);
		RS485_RX;	 
	}

	else if(Rx_Buf[3]==0x02)		//ask serial number
	{
		RS485_TX;
		delay_ms(1);		//10ms
		Tx_Buf[0] = 0xAA;	Tx_Buf[1] = 0x0C;
		Tx_Buf[2] = Rx_Buf[2];	Tx_Buf[3] = Rx_Buf[3];
		for(i=0; i<8; i++)
			Tx_Buf[4+i] = SN_num[i];
		
		CRC_temp = Tx_Buf[0];
		for(i=1; i<12; i++)
			CRC_temp = CRC_temp ^ Tx_Buf[i];
		Tx_Buf[12] = CRC_temp;
		
		RS485TxBuf(Tx_Buf, 13, 2);
		RS485_RX;	 
	}
	else if(Rx_Buf[3]==0x03)		//ask date&time
	{
		RS485_TX;
		delay_ms(1);		//10ms
		Tx_Buf[0] = 0xAA;	Tx_Buf[1] = 0x0A;
		Tx_Buf[2] = Rx_Buf[2];	Tx_Buf[3] = Rx_Buf[3];
		Tx_Buf[4] = now_year;
		Tx_Buf[5] = now_month;
		Tx_Buf[6] = now_day;
		Tx_Buf[7] = now_hour;
		Tx_Buf[8] = now_minute;
		Tx_Buf[9] = now_sec;
				
		CRC_temp = Tx_Buf[0];
		for(i=1; i<10; i++)
			CRC_temp = CRC_temp ^ Tx_Buf[i];
		Tx_Buf[10] = CRC_temp;
		
		RS485TxBuf(Tx_Buf, 11, 2);
		RS485_RX;	 
	}
	else if(Rx_Buf[3]==0x04)		//ask RS485 baudrate
	{
		RS485_TX;
		delay_ms(1);		//10ms
		Tx_Buf[0] = 0xAA;	Tx_Buf[1] = 0x08;
		Tx_Buf[2] = Rx_Buf[2];	Tx_Buf[3] = Rx_Buf[3];
		
		temp_uint32 = RS485_baudrate;
		Tx_Buf[4] = (temp_uint32>>24) & 0xff;		
		Tx_Buf[5] = (temp_uint32>>16) & 0xff;	
		Tx_Buf[6] = (temp_uint32>>8) & 0xff;
		Tx_Buf[7] = (temp_uint32) & 0xff;
				
		CRC_temp = Tx_Buf[0];
		for(i=1; i<8; i++)
			CRC_temp = CRC_temp ^ Tx_Buf[i];
		Tx_Buf[8] = CRC_temp;
		
		RS485TxBuf(Tx_Buf, 9, 2);
		RS485_RX;	 
	}
			
}*/

/******* RX CRC error *******************/
/*
void RS485TxError(void)
{
	uint16_t i;
	uint8_t CRC_temp;
	
	RS485_TX;
	delay_ms(1);		//10ms
	Tx_Buf[0] = 0xAA;	Tx_Buf[1] = 0x04;
	Tx_Buf[2] = Rx_Buf[2];	//address
	Tx_Buf[3] = 0xEE;				//error code
				
		CRC_temp = Tx_Buf[0];
		for(i=1; i<4; i++)
			CRC_temp = CRC_temp ^ Tx_Buf[i];
		Tx_Buf[4] = CRC_temp;
		
		RS485TxBuf(Tx_Buf, 5, 2);
		RS485_RX;	 
}*/



/*
//--------------------------------------//
void USART2_IRQHandler(void)
{
	uint8_t data, CRC_temp;
	uint16_t i;

	if((USART_GetITStatus(USART2, USART_IT_RXNE)) != RESET)
  {
		data = USART_ReceiveData(USART2);
		
		//------Setting Serial Number ----------------------//
		if((data=='S') && (Rx_Index_SN==0))
			Rx_Index_SN ++;
		else if((data=='N') && (Rx_Index_SN==1))
			Rx_Index_SN ++;
		else if(Rx_Index_SN>1)
		{
			SN_num[Rx_Index_SN-2] = data;
			Rx_Index_SN ++;
			if(Rx_Index_SN>=10)
			{
				Rx_Index_SN = 0;
				SaveParams();
				
				RS485_TX;
				delay_ms(1);		
				Tx_Buf[0] = 'O';	Tx_Buf[1] = 'K';
				//Tx_Buf[2] = '\r';	Tx_Buf[3] = '\n';
				RS485TxBuf(Tx_Buf, 2, 2);
				RS485_RX;	 
			}
		}			
			
		if((data==0xAA) && (Rx_Index==0))	//0xAA
		{
			Rx_Pk_Flag = 1;
			Rx_Buf[Rx_Index] = data;
			Rx_Index ++;
			usart_delay_cnt = 0;
		}
		else if((Rx_Pk_Flag==1) && (Rx_Index>0))
		{
			if(Rx_Index==1)
				Rx_Data_Len = data;
			
			Rx_Buf[Rx_Index] = data;
			Rx_Index ++;
			if(Rx_Index>=(Rx_Data_Len+1))		//include header
			{
				rx485_conn_flag = 1;
				rs485_cnt_out = 0;
				Rx_Index = 0;
				Rx_Pk_Flag = 0;
				
				CRC_temp = Rx_Buf[0];
				for(i=1; i<Rx_Data_Len; i++)
					CRC_temp = CRC_temp ^ Rx_Buf[i];
				
				if(Rx_Buf[2]==dev_address)
				{
					if(CRC_temp==data)
						RS485RxProcess(data);
					else
						RS485TxError();
				}				
			}
		}
		//USART_ClearITPendingBit(USART2, USART_IT_RXNE);
	}
}
*/
/*************************************************
** RS485_IN, UART4
**************************************************/
////////////////////////////////////////////////////////
/*
void RS485In_Config(uint32_t BaudRate)
{ 
  GPIO_InitTypeDef GPIO_InitStructure;
  USART_InitTypeDef USART_InitStructure; 
//  NVIC_InitTypeDef NVIC_InitStructure;

  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC | RCC_APB2Periph_AFIO, ENABLE);	 
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART4, ENABLE); 	////
	//GPIO_PinRemapConfig(GPIO_Remap_SPI1, ENABLE);
	
	//485In_D/R# -> PC1
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;	         
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; 
  GPIO_Init(GPIOC, &GPIO_InitStructure);
	RS485In_RX;
	
  //UART4_TX -> PC10 , UART4_RX ->	PC11
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;	         
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP; 
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; 
  GPIO_Init(GPIOC, &GPIO_InitStructure);		   

  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;	        
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;  
  GPIO_Init(GPIOC, &GPIO_InitStructure);
	
	USART_InitStructure.USART_BaudRate = BaudRate;
  USART_InitStructure.USART_WordLength = USART_WordLength_8b;
  USART_InitStructure.USART_StopBits = USART_StopBits_1;	//USART_StopBits_1
  USART_InitStructure.USART_Parity = USART_Parity_No;
  USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
  USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;

  USART_Init(UART4, &USART_InitStructure); 
  USART_ClearFlag(UART4,USART_FLAG_TC);
  USART_ITConfig(UART4, USART_IT_RXNE, ENABLE);
//  USART_ITConfig(USART2, USART_IT_TXE, ENABLE);
  USART_Cmd(UART4, ENABLE);

}

uint16_t crc16(uint8_t *data,int num, uint16_t crc)  
{  
	uint16_t i;
	for(;num > 0;num--)  
	{  
			crc = crc^(*data++);  
			for(i=0; i<8; i++)  
			{  
					if(crc & 0x0001)  
							crc = (crc>>1)^0xA001;  
					else  
							crc >>= 1;  
			}  
	}  
	return(crc);  
}  

void RS485InCmd(uint8_t addr,uint16_t reg)
{
//	uint16_t i;
	uint16_t CRC_temp;
	
	RS485In_TX; delay_ms(1);		//10ms
	
	Tx_Buf2[0] = 0xAA;	
	Tx_Buf2[1] = 0x04;
	Tx_Buf2[2] = addr;
	Tx_Buf2[3] = cmd;				
	
	CRC_temp = Tx_Buf2[0];
	for(i=1; i<4; i++)
		CRC_temp = CRC_temp ^ Tx_Buf2[i];
	Tx_Buf2[4] = CRC_temp;
	RS485TxBuf(Tx_Buf2, 5, 4); */
	/*
	//pH: 		01 03 00 10 00 02 CE C5
	//tempr:  01 03 00 12 00 02 0E 64
	Tx_Buf2[0] = addr;	
	Tx_Buf2[1] = 0x03;	//cmd
	Tx_Buf2[2] = (reg>>8) & 0xff;
	Tx_Buf2[3] = reg & 0xff;
	Tx_Buf2[4] = 0;
	Tx_Buf2[5] = 0x02;
		
	CRC_temp = crc16(Tx_Buf2, 6, 0xffff);
	Tx_Buf2[6] = (CRC_temp>>8) & 0xff;
	Tx_Buf2[7] = CRC_temp & 0xff;
	RS485TxBuf(Tx_Buf2, 8, 4);
	
	RS485In_RX;	 	
}*/
/*
void RS485InProcess(uint8_t data)
{
	//int32_t temp_int32;
	uint8_t buf[4];
	
	//---------------- command table ---------------------//
	if(Rx_Buf2[3]==0x01)		//measure value
	{
		temp_int32 = (Rx_Buf2[5]<<8) | Rx_Buf2[6];
		temp_int32 = (temp_int32<<8) | Rx_Buf2[7];
		temp_int32 = (temp_int32<<8) | Rx_Buf2[8];
		
		if(temp_int32&0x80000000)	//negative number
			temp_int32 = temp_int32-0x100000000;
		if(Rx_Buf2[4]==0)	//pH
			pH_calc_value = (float)temp_int32/100;
		else if(Rx_Buf2[4]==0x01)	//ORP
			ORP_calc_value = (float)temp_int32/10;
		
		temp_int32 = Rx_Buf2[9] & 0x000000ff;
		temp_int32 = (temp_int32<<8) | Rx_Buf2[10];
		if(temp_int32&0x8000)	//negative number
			temp_int32 = temp_int32-0x10000;
		temper_calc_value = (float)temp_int32/10;
	} */
	/*
	buf[0] = Rx_Buf2[4]; buf[1] = Rx_Buf2[3];
	buf[2] = Rx_Buf2[6]; buf[3] = Rx_Buf2[5];
	
	if(RS485In_cmd_flag==0)
	{
		//pH_calc_value = *(float*)buf;	
		Ain_real_raw[0] = *(float*)buf;
		Ain_real_value[0] = Ain_real_raw[0] + calib_Ain_offset[0];
		RS485In_cmd_flag = 1;
	}
	else if(RS485In_cmd_flag==1)
	{
		//temper_calc_value = *(float*)buf;	
		Ain_real_raw[1] = *(float*)buf;
		if(mode_ATC_MTC==MEASURE_MODE_ATC)
			Ain_real_value[1] = Ain_real_raw[1] + calib_Ain_offset[1];
		if(mode_ATC_MTC==MEASURE_MODE_MTC)
			Ain_real_value[1] = temper_manual;
		RS485In_cmd_flag = 0;
	}
	
}*/
/*
//--------------------------------------//
void UART4_IRQHandler(void)
{
	uint8_t data;
	uint16_t CRC_temp;
//	uint16_t i;

	if((USART_GetITStatus(UART4, USART_IT_RXNE)) != RESET)
  {
		data = USART_ReceiveData(UART4);
		Rx_Buf2[Rx_Index2] = data;
		Rx_Index2 ++;
		if(Rx_Index2==9)
		{
			Rx_Index2 = 0;
			RS485InProcess(data);
		} */
	/*	
		if((data==sensor_addr) && (Rx_Index2==0))	//0xAA
		{
			Rx_Pk_Flag2 = 1;
			Rx_Buf2[Rx_Index2] = data;
			Rx_Index2 ++;
			usart_delay_cnt2 = 0;
		}
		else if((Rx_Pk_Flag2==1) && (Rx_Index2>0))
		{
			Rx_Buf2[Rx_Index2] = data;
			Rx_Index2 ++;
			if(Rx_Index2>=9)		//cmd=8bytes
			{
				Rx_Index2 = 0;
				Rx_Pk_Flag2 = 0;
				CRC_temp = crc16(Rx_Buf2, 7, 0xffff);
				
				if((Rx_Buf2[7]==((CRC_temp>>8)&0xff)) && (Rx_Buf2[8]==(CRC_temp&0xff)))
					RS485InProcess(data);
			
			}
		} 
					
		//USART_ClearITPendingBit(UART4, USART_IT_RXNE);
	}
}*/
