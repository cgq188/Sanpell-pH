/*
File 			:timer.h
Description		:define variables and functions for Timer
*/
#include "stm32f10x.h"


void TIM_Configuration(void);

