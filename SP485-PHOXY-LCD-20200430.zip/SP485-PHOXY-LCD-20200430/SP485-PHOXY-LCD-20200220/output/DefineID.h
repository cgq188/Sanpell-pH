//��������MainScreen����������ID
#define  _SCREEN_MAINSCREEN                                                    0

//��������MainSetting����������ID
#define  _SCREEN_MAINSETTING                                                   1

//��������SettingPassWord����������ID
#define  _SCREEN_SETTINGPASSWORD                                               2

//��������SplashScreen����������ID
#define  _SCREEN_SPLASHSCREEN                                                  3

//��������OXYModeSelect����������ID
#define  _SCREEN_OXYMODESELECT                                                 4

//��������Output_A_OXY_LDO_Setting����������ID
#define  _SCREEN_OUTPUT_A_OXY_LDO_SETTING                                      5

//��������Output_A_OXY_SATURATION_Setting����������ID
#define  _SCREEN_OUTPUT_A_OXY_SATURATION_SETTING                               6

//��������Output_B_OXY_LDO_Setting����������ID
#define  _SCREEN_OUTPUT_B_OXY_LDO_SETTING                                      7

//��������Output_B_OXY_SATURATION_Setting����������ID
#define  _SCREEN_OUTPUT_B_OXY_SATURATION_SETTING                               8

//��������Output_A_Start����������ID
#define  _SCREEN_OUTPUT_A_START                                                9

//��������Output_B_Start����������ID
#define  _SCREEN_OUTPUT_B_START                                               10

//��������RS485InputSetting����������ID
#define  _SCREEN_RS485INPUTSETTING                                            11

//��������RS485OutputSetting����������ID
#define  _SCREEN_RS485OUTPUTSETTING                                           12

//��������SettingPasswordError����������ID
#define  _SCREEN_SETTINGPASSWORDERROR                                         13

//��������Realay1Setting����������ID
#define  _SCREEN_REALAY1SETTING                                               14

//��������Relay1Start����������ID
#define  _SCREEN_RELAY1START                                                  15

//��������Relay2Setting����������ID
#define  _SCREEN_RELAY2SETTING                                                16

//��������Relay2Start����������ID
#define  _SCREEN_RELAY2START                                                  17

//��������WashSetting����������ID
#define  _SCREEN_WASHSETTING                                                  18

//��������WashStart����������ID
#define  _SCREEN_WASHSTART                                                    19

//��������CalibrationPassWord����������ID
#define  _SCREEN_CALIBRATIONPASSWORD                                          20

//��������CalibrationPasswordError����������ID
#define  _SCREEN_CALIBRATIONPASSWORDERROR                                     21

//��������FactoryCalibrationMain����������ID
#define  _SCREEN_FACTORYCALIBRATIONMAIN                                       22

//��������OutputAStep1����������ID
#define  _SCREEN_OUTPUTASTEP1                                                 23

//��������OutputAStep2����������ID
#define  _SCREEN_OUTPUTASTEP2                                                 24

//��������OutputBStep1����������ID
#define  _SCREEN_OUTPUTBSTEP1                                                 25

//��������OutputBStep2����������ID
#define  _SCREEN_OUTPUTBSTEP2                                                 26

//��������CalibrationMain����������ID
#define  _SCREEN_CALIBRATIONMAIN                                              27

//��������CalibrationASICap#����������ID
#define  _SCREEN_CALIBRATIONASICAP#                                           28

//��������CalibrationASIyandu����������ID
#define  _SCREEN_CALIBRATIONASIYANDU                                          29

//��������CalibrationASIPoint100����������ID
#define  _SCREEN_CALIBRATIONASIPOINT100                                       30

//��������CalibrationASITemperature����������ID
#define  _SCREEN_CALIBRATIONASITEMPERATURE                                    31

//��������CalibrationPoint0����������ID
#define  _SCREEN_CALIBRATIONPOINT0                                            32

//��������CalibrationProcess����������ID
#define  _SCREEN_CALIBRATIONPROCESS                                           33

//��������CalibrationProcessLDO����������ID
#define  _SCREEN_CALIBRATIONPROCESSLDO                                        34

//��������ASI_History����������ID
#define  _SCREEN_ASI_HISTORY                                                  35

//��������DeviceInfo����������ID
#define  _SCREEN_DEVICEINFO                                                   36

//��������SensorInfo����������ID
#define  _SCREEN_SENSORINFO                                                   37

//��������ReadSensorProcess����������ID
#define  _SCREEN_READSENSORPROCESS                                            38

//��������Factory_Reset����������ID
#define  _SCREEN_FACTORY_RESET                                                39

//��������pH_Mode_Sel_ATC����������ID
#define  _SCREEN_PH_MODE_SEL_ATC                                              40

//��������pH_Mode_Sel_MTC����������ID
#define  _SCREEN_PH_MODE_SEL_MTC                                              41

//��������Output_A_pH_Setting����������ID
#define  _SCREEN_OUTPUT_A_PH_SETTING                                          42

//��������Output_A_ORP_Setting����������ID
#define  _SCREEN_OUTPUT_A_ORP_SETTING                                         43

//��������Output_B_pH_Setting����������ID
#define  _SCREEN_OUTPUT_B_PH_SETTING                                          44

//��������Output_B_ORP_Setting����������ID
#define  _SCREEN_OUTPUT_B_ORP_SETTING                                         45

//��������PH_Calib_Main����������ID
#define  _SCREEN_PH_CALIB_MAIN                                                46

//��������Ph_Calib_MANU_P1_Start����������ID
#define  _SCREEN_PH_CALIB_MANU_P1_START                                       47

//��������Ph_Calib_MANU_P2_Start����������ID
#define  _SCREEN_PH_CALIB_MANU_P2_START                                       48

//��������Ph_Calib_MANU_P3_Start����������ID
#define  _SCREEN_PH_CALIB_MANU_P3_START                                       49

//��������Ph_Calib_Menu_ATC����������ID
#define  _SCREEN_PH_CALIB_MENU_ATC                                            50

//��������Ph_Calib_Menu_MTC����������ID
#define  _SCREEN_PH_CALIB_MENU_MTC                                            51

//��������Ph_Calib_NIST_P1_Start����������ID
#define  _SCREEN_PH_CALIB_NIST_P1_START                                       52

//��������Ph_Calib_NIST_P2_Start����������ID
#define  _SCREEN_PH_CALIB_NIST_P2_START                                       53

//��������Ph_Calib_NIST_P3_Start����������ID
#define  _SCREEN_PH_CALIB_NIST_P3_START                                       54

//��������Ph_Calib_P1_End����������ID
#define  _SCREEN_PH_CALIB_P1_END                                              55

//��������Ph_Calib_P1_Process����������ID
#define  _SCREEN_PH_CALIB_P1_PROCESS                                          56

//��������Ph_Calib_P2_End����������ID
#define  _SCREEN_PH_CALIB_P2_END                                              57

//��������Ph_Calib_P2_Process����������ID
#define  _SCREEN_PH_CALIB_P2_PROCESS                                          58

//��������Ph_Calib_P3_End����������ID
#define  _SCREEN_PH_CALIB_P3_END                                              59

//��������Ph_Calib_P3_Process����������ID
#define  _SCREEN_PH_CALIB_P3_PROCESS                                          60

//��������Ph_Calib_Result_P1����������ID
#define  _SCREEN_PH_CALIB_RESULT_P1                                           61

//��������Ph_Calib_Result_P2����������ID
#define  _SCREEN_PH_CALIB_RESULT_P2                                           62

//��������Ph_Calib_Result_P3����������ID
#define  _SCREEN_PH_CALIB_RESULT_P3                                           63

//��������Ph_Calib_TECH_P1_Start����������ID
#define  _SCREEN_PH_CALIB_TECH_P1_START                                       64

//��������Ph_Calib_TECH_P2_Start����������ID
#define  _SCREEN_PH_CALIB_TECH_P2_START                                       65

//��������Ph_Calib_TECH_P3_Start����������ID
#define  _SCREEN_PH_CALIB_TECH_P3_START                                       66

//��������ORP_Calib_Start����������ID
#define  _SCREEN_ORP_CALIB_START                                              67

//��������ORP_Calib_Process����������ID
#define  _SCREEN_ORP_CALIB_PROCESS                                            68

//��������Temp_Calib_Diff����������ID
#define  _SCREEN_TEMP_CALIB_DIFF                                              69

//��������PHORP_Factory_Calib_Main����������ID
#define  _SCREEN_PHORP_FACTORY_CALIB_MAIN                                     70

//��������ORP_Factory_Calib_P1_Start����������ID
#define  _SCREEN_ORP_FACTORY_CALIB_P1_START                                   71

//��������ORP_Factory_Calib_P1_Process����������ID
#define  _SCREEN_ORP_FACTORY_CALIB_P1_PROCESS                                 72

//��������ORP_Factory_Calib_P2_Start����������ID
#define  _SCREEN_ORP_FACTORY_CALIB_P2_START                                   73

//��������ORP_Factory_Calib_P2_Process����������ID
#define  _SCREEN_ORP_FACTORY_CALIB_P2_PROCESS                                 74

//��������ORP_Factory_Calib_P3_Start����������ID
#define  _SCREEN_ORP_FACTORY_CALIB_P3_START                                   75

//��������ORP_Factory_Calib_P3_Process����������ID
#define  _SCREEN_ORP_FACTORY_CALIB_P3_PROCESS                                 76

//��������ORP_Factory_Calib_Result����������ID
#define  _SCREEN_ORP_FACTORY_CALIB_RESULT                                     77

//��������Temp_Calib_P1_Start����������ID
#define  _SCREEN_TEMP_CALIB_P1_START                                          78

//��������Temp_Calib_P1_Process����������ID
#define  _SCREEN_TEMP_CALIB_P1_PROCESS                                        79

//��������Temp_Calib_P2_Start����������ID
#define  _SCREEN_TEMP_CALIB_P2_START                                          80

//��������Temp_Calib_P2_Process����������ID
#define  _SCREEN_TEMP_CALIB_P2_PROCESS                                        81

//��������Temp_Calib_Result����������ID
#define  _SCREEN_TEMP_CALIB_RESULT                                            82

//��������Factory_Calib_Question����������ID
#define  _SCREEN_FACTORY_CALIB_QUESTION                                       83

//��������Factory_Setting_Question����������ID
#define  _SCREEN_FACTORY_SETTING_QUESTION                                     84

//��������PH_History����������ID
#define  _SCREEN_PH_HISTORY                                                   85

//��������ORP_History����������ID
#define  _SCREEN_ORP_HISTORY                                                  86

//��������PHORP_SensorInfo����������ID
#define  _SCREEN_PHORP_SENSORINFO                                             87

//��������SettingWait����������ID
#define  _SCREEN_SETTINGWAIT                                                  88

//��������SensorDisconnect����������ID
#define  _SCREEN_SENSORDISCONNECT                                             89

//��������CalibrationError����������ID
#define  _SCREEN_CALIBRATIONERROR                                             90

//��������PHORP_Calib_Temp����������ID
#define  _SCREEN_PHORP_CALIB_TEMP                                             91

//����MainScreen�ı���ͼƬ
#define  _IMG_MAINSCREEN                                                       0

#define  _RTC_MAINSCREEN_RTC1                                                  3

#define  _TXT_DIS__MAINSCREEN_TEXT_DISPLAY1                                    4

//����MainScreen���ı���ʾText_Display1�ı���ͼƬ
#define  _IMG_MAINSCREEN_TEXT_DISPLAY1                                         1

#define  _TXT_DIS__MAINSCREEN_TEXT_DISPLAY4                                    7

//����MainScreen���ı���ʾText_Display4�ı���ͼƬ
#define  _IMG_MAINSCREEN_TEXT_DISPLAY4                                         2

#define  _TXT_DIS__MAINSCREEN_TEXT_DISPLAY2                                   13

#define  _TXT_DIS__MAINSCREEN_TEXT_DISPLAY3                                    6

#define  _TXT_DIS__MAINSCREEN_TEXT_DISPLAY5                                    5

#define  _BTN_MAINSCREEN_BUTTON1                                               1

#define  _BTN_MAINSCREEN_BUTTON2                                               2

#define  _BTN_MAINSCREEN_BUTTON3                                              11

#define  _BTN_MAINSCREEN_BUTTON4                                              12

//����MainScreen�ж����ؼ�Icon5ʹ�õ�ͼƬ
#define  _IMG_MAINSCREEN_ICON5                                                 3

#define  _ANIMATION_MAINSCREEN_ICON5                                           8

//����MainScreen�ж����ؼ�Icon4ʹ�õ�ͼƬ
#define  _IMG_MAINSCREEN_ICON4                                                 4

#define  _ANIMATION_MAINSCREEN_ICON4                                           9

//����MainScreen�ж����ؼ�Icon1ʹ�õ�ͼƬ
#define  _IMG_MAINSCREEN_ICON1                                                 5

#define  _ANIMATION_MAINSCREEN_ICON1                                          10

//����MainScreen�ж����ؼ�Icon7ʹ�õ�ͼƬ
#define  _IMG_MAINSCREEN_ICON7                                                 6

#define  _ANIMATION_MAINSCREEN_ICON7                                          16

//����MainSetting�ı���ͼƬ
#define  _IMG_MAINSETTING                                                      7

#define  _BTN_MAINSETTING_BUTTON2                                              3

#define  _BTN_MAINSETTING_BUTTON4                                              4

#define  _BTN_MAINSETTING_BUTTON5                                              5

#define  _BTN_MAINSETTING_BUTTON6                                              6

#define  _BTN_MAINSETTING_BUTTON7                                              7

#define  _BTN_MAINSETTING_BUTTON8                                              8

#define  _BTN_MAINSETTING_BUTTON10                                            10

#define  _BTN_MAINSETTING_BUTTON1                                             11

#define  _BTN_MAINSETTING_BUTTON9                                              1

#define  _BTN_MAINSETTING_BUTTON3                                              2

#define  _BTN_MAINSETTING_BUTTON11                                             9

//����SettingPassWord�ı���ͼƬ
#define  _IMG_SETTINGPASSWORD                                                  8

#define  _BTN_SETTINGPASSWORD_BUTTON1                                          1

#define  _BTN_SETTINGPASSWORD_BUTTON2                                          2

#define  _TXT_DIS__SETTINGPASSWORD_TEXT_DISPLAY1                               3

//����SplashScreen�ı���ͼƬ
#define  _IMG_SPLASHSCREEN                                                     9

//����OXYModeSelect�ı���ͼƬ
#define  _IMG_OXYMODESELECT                                                   10

#define  _BTN_OXYMODESELECT_BUTTON1                                            1

#define  _TXT_DIS__OXYMODESELECT_TEXT_DISPLAY4                                 9

#define  _BTN_OXYMODESELECT_BUTTON4                                           10

#define  _MENU_OXYMODESELECT_MENU1                                             4

//����Output_A_OXY_LDO_Setting�ı���ͼƬ
#define  _IMG_OUTPUT_A_OXY_LDO_SETTING                                        11

#define  _BTN_OUTPUT_A_OXY_LDO_SETTING_BUTTON1                                 1

#define  _BTN_OUTPUT_A_OXY_LDO_SETTING_BUTTON3                                 3

#define  _TXT_DIS__OUTPUT_A_OXY_LDO_SETTING_TEXT_DISPLAY1                      5

#define  _TXT_DIS__OUTPUT_A_OXY_LDO_SETTING_TEXT_DISPLAY2                      6

#define  _TXT_DIS__OUTPUT_A_OXY_LDO_SETTING_TEXT_DISPLAY3                      8

#define  _TXT_DIS__OUTPUT_A_OXY_LDO_SETTING_TEXT_DISPLAY4                      9

#define  _BTN_OUTPUT_A_OXY_LDO_SETTING_BUTTON4                                10

#define  _MENU_OUTPUT_A_OXY_LDO_SETTING_MENU1                                  4

//����Output_A_OXY_SATURATION_Setting�ı���ͼƬ
#define  _IMG_OUTPUT_A_OXY_SATURATION_SETTING                                 11

#define  _BTN_OUTPUT_A_OXY_SATURATION_SETTING_BUTTON1                          1

#define  _BTN_OUTPUT_A_OXY_SATURATION_SETTING_BUTTON3                          3

#define  _TXT_DIS__OUTPUT_A_OXY_SATURATION_SETTING_TEXT_DISPLAY1               5

#define  _TXT_DIS__OUTPUT_A_OXY_SATURATION_SETTING_TEXT_DISPLAY2               6

#define  _TXT_DIS__OUTPUT_A_OXY_SATURATION_SETTING_TEXT_DISPLAY3               8

#define  _TXT_DIS__OUTPUT_A_OXY_SATURATION_SETTING_TEXT_DISPLAY4               9

#define  _BTN_OUTPUT_A_OXY_SATURATION_SETTING_BUTTON4                         10

#define  _MENU_OUTPUT_A_OXY_SATURATION_SETTING_MENU1                           4

//����Output_B_OXY_LDO_Setting�ı���ͼƬ
#define  _IMG_OUTPUT_B_OXY_LDO_SETTING                                        11

#define  _TXT_DIS__OUTPUT_B_OXY_LDO_SETTING_TEXT_DISPLAY3                      8

#define  _BTN_OUTPUT_B_OXY_LDO_SETTING_BUTTON1                                 1

#define  _BTN_OUTPUT_B_OXY_LDO_SETTING_BUTTON3                                 3

#define  _TXT_DIS__OUTPUT_B_OXY_LDO_SETTING_TEXT_DISPLAY1                      5

#define  _TXT_DIS__OUTPUT_B_OXY_LDO_SETTING_TEXT_DISPLAY2                      6

#define  _TXT_DIS__OUTPUT_B_OXY_LDO_SETTING_TEXT_DISPLAY4                      9

#define  _BTN_OUTPUT_B_OXY_LDO_SETTING_BUTTON4                                10

#define  _MENU_OUTPUT_B_OXY_LDO_SETTING_MENU1                                  4

//����Output_B_OXY_SATURATION_Setting�ı���ͼƬ
#define  _IMG_OUTPUT_B_OXY_SATURATION_SETTING                                 11

#define  _TXT_DIS__OUTPUT_B_OXY_SATURATION_SETTING_TEXT_DISPLAY3               8

#define  _BTN_OUTPUT_B_OXY_SATURATION_SETTING_BUTTON1                          1

#define  _BTN_OUTPUT_B_OXY_SATURATION_SETTING_BUTTON3                          3

#define  _TXT_DIS__OUTPUT_B_OXY_SATURATION_SETTING_TEXT_DISPLAY1               5

#define  _TXT_DIS__OUTPUT_B_OXY_SATURATION_SETTING_TEXT_DISPLAY2               6

#define  _TXT_DIS__OUTPUT_B_OXY_SATURATION_SETTING_TEXT_DISPLAY4               9

#define  _BTN_OUTPUT_B_OXY_SATURATION_SETTING_BUTTON4                         10

#define  _MENU_OUTPUT_B_OXY_SATURATION_SETTING_MENU1                           4

//����Output_A_Start�ı���ͼƬ
#define  _IMG_OUTPUT_A_START                                                  12

#define  _BTN_OUTPUT_A_START_BUTTON1                                           2

#define  _BTN_OUTPUT_A_START_BUTTON2                                           1

#define  _TXT_DIS__OUTPUT_A_START_TEXT_DISPLAY3                                8

//����Output_B_Start�ı���ͼƬ
#define  _IMG_OUTPUT_B_START                                                  12

#define  _TXT_DIS__OUTPUT_B_START_TEXT_DISPLAY3                                8

#define  _BTN_OUTPUT_B_START_BUTTON1                                           2

#define  _BTN_OUTPUT_B_START_BUTTON2                                           1

//����RS485InputSetting�ı���ͼƬ
#define  _IMG_RS485INPUTSETTING                                               13

#define  _TXT_DIS__RS485INPUTSETTING_TEXT_DISPLAY4                             4

#define  _BTN_RS485INPUTSETTING_BUTTON4                                        5

#define  _MENU_RS485INPUTSETTING_MENU1                                         3

#define  _BTN_RS485INPUTSETTING_BUTTON2                                        1

#define  _TXT_DIS__RS485INPUTSETTING_TEXT_DISPLAY2                             2

#define  _TXT_DIS__RS485INPUTSETTING_TEXT_DISPLAY1                             6

#define  _BTN_RS485INPUTSETTING_BUTTON1                                        7

#define  _MENU_RS485INPUTSETTING_MENU2                                         8

#define  _TXT_DIS__RS485INPUTSETTING_TEXT_DISPLAY3                             9

#define  _BTN_RS485INPUTSETTING_BUTTON3                                       10

#define  _MENU_RS485INPUTSETTING_MENU3                                        11

#define  _TXT_DIS__RS485INPUTSETTING_TEXT_DISPLAY5                            12

#define  _BTN_RS485INPUTSETTING_BUTTON5                                       13

#define  _MENU_RS485INPUTSETTING_MENU4                                        14

#define  _TXT_DIS__RS485INPUTSETTING_TEXT_DISPLAY6                            15

#define  _BTN_RS485INPUTSETTING_BUTTON6                                       16

#define  _MENU_RS485INPUTSETTING_MENU5                                        17

//����RS485OutputSetting�ı���ͼƬ
#define  _IMG_RS485OUTPUTSETTING                                              14

#define  _TXT_DIS__RS485OUTPUTSETTING_TEXT_DISPLAY4                            4

#define  _BTN_RS485OUTPUTSETTING_BUTTON4                                       5

#define  _MENU_RS485OUTPUTSETTING_MENU1                                        3

#define  _BTN_RS485OUTPUTSETTING_BUTTON2                                       1

#define  _TXT_DIS__RS485OUTPUTSETTING_TEXT_DISPLAY2                            2

#define  _TXT_DIS__RS485OUTPUTSETTING_TEXT_DISPLAY1                            6

#define  _BTN_RS485OUTPUTSETTING_BUTTON1                                       7

#define  _MENU_RS485OUTPUTSETTING_MENU2                                        8

#define  _TXT_DIS__RS485OUTPUTSETTING_TEXT_DISPLAY3                            9

#define  _BTN_RS485OUTPUTSETTING_BUTTON3                                      10

#define  _MENU_RS485OUTPUTSETTING_MENU3                                       11

#define  _TXT_DIS__RS485OUTPUTSETTING_TEXT_DISPLAY5                           12

#define  _BTN_RS485OUTPUTSETTING_BUTTON5                                      13

#define  _MENU_RS485OUTPUTSETTING_MENU4                                       14

#define  _TXT_DIS__RS485OUTPUTSETTING_TEXT_DISPLAY6                           15

#define  _BTN_RS485OUTPUTSETTING_BUTTON6                                      16

#define  _MENU_RS485OUTPUTSETTING_MENU5                                       17

//����SettingPasswordError��ͼƬImage1ʹ�õ�ͼƬ
#define  _IMG_SETTINGPASSWORDERROR_IMAGE1                                     15

#define  _BTN_SETTINGPASSWORDERROR_BUTTON1                                     2

//����Realay1Setting�ı���ͼƬ
#define  _IMG_REALAY1SETTING                                                  16

#define  _BTN_REALAY1SETTING_BUTTON1                                           1

#define  _BTN_REALAY1SETTING_BUTTON3                                           3

#define  _TXT_DIS__REALAY1SETTING_TEXT_DISPLAY1                                5

#define  _TXT_DIS__REALAY1SETTING_TEXT_DISPLAY2                                6

//����Realay1Setting�ж����ؼ�Icon2ʹ�õ�ͼƬ
#define  _IMG_REALAY1SETTING_ICON2                                            17

#define  _ANIMATION_REALAY1SETTING_ICON2                                       7

#define  _BTN_REALAY1SETTING_BUTTON2                                           2

#define  _TXT_DIS__REALAY1SETTING_TEXT_DISPLAY3                                4

#define  _TXT_DIS__REALAY1SETTING_TEXT_DISPLAY4                                8

//����Relay1Start�ı���ͼƬ
#define  _IMG_RELAY1START                                                     18

#define  _BTN_RELAY1START_BUTTON2                                              1

#define  _BTN_RELAY1START_BUTTON1                                              3

#define  _TXT_DIS__RELAY1START_TEXT_DISPLAY3                                   8

//����Relay2Setting�ı���ͼƬ
#define  _IMG_RELAY2SETTING                                                   16

#define  _TXT_DIS__RELAY2SETTING_TEXT_DISPLAY4                                 8

#define  _BTN_RELAY2SETTING_BUTTON1                                            1

#define  _BTN_RELAY2SETTING_BUTTON3                                            3

#define  _TXT_DIS__RELAY2SETTING_TEXT_DISPLAY1                                 5

#define  _TXT_DIS__RELAY2SETTING_TEXT_DISPLAY2                                 6

//����Relay2Setting�ж����ؼ�Icon2ʹ�õ�ͼƬ
#define  _IMG_RELAY2SETTING_ICON2                                             17

#define  _ANIMATION_RELAY2SETTING_ICON2                                        7

#define  _BTN_RELAY2SETTING_BUTTON2                                            2

#define  _TXT_DIS__RELAY2SETTING_TEXT_DISPLAY3                                 4

//����Relay2Start�ı���ͼƬ
#define  _IMG_RELAY2START                                                     18

#define  _BTN_RELAY2START_BUTTON2                                              1

#define  _BTN_RELAY2START_BUTTON1                                              3

#define  _TXT_DIS__RELAY2START_TEXT_DISPLAY3                                   8

//����WashSetting�ı���ͼƬ
#define  _IMG_WASHSETTING                                                     19

#define  _BTN_WASHSETTING_BUTTON1                                              1

#define  _BTN_WASHSETTING_BUTTON3                                              3

#define  _TXT_DIS__WASHSETTING_TEXT_DISPLAY1                                   5

#define  _TXT_DIS__WASHSETTING_TEXT_DISPLAY2                                   6

//����WashStart�ı���ͼƬ
#define  _IMG_WASHSTART                                                       20

#define  _BTN_WASHSTART_BUTTON1                                                3

#define  _BTN_WASHSTART_BUTTON2                                                1

//����CalibrationPassWord�ı���ͼƬ
#define  _IMG_CALIBRATIONPASSWORD                                             21

#define  _BTN_CALIBRATIONPASSWORD_BUTTON1                                      1

#define  _BTN_CALIBRATIONPASSWORD_BUTTON2                                      2

#define  _TXT_DIS__CALIBRATIONPASSWORD_TEXT_DISPLAY1                           3

//����CalibrationPasswordError��ͼƬImage1ʹ�õ�ͼƬ
#define  _IMG_CALIBRATIONPASSWORDERROR_IMAGE1                                 15

#define  _BTN_CALIBRATIONPASSWORDERROR_BUTTON1                                 2

//����FactoryCalibrationMain�ı���ͼƬ
#define  _IMG_FACTORYCALIBRATIONMAIN                                          22

#define  _BTN_FACTORYCALIBRATIONMAIN_BUTTON1                                   1

#define  _BTN_FACTORYCALIBRATIONMAIN_BUTTON2                                   2

#define  _BTN_FACTORYCALIBRATIONMAIN_BUTTON3                                   3

#define  _BTN_FACTORYCALIBRATIONMAIN_BUTTON4                                   4

//����OutputAStep1�ı���ͼƬ
#define  _IMG_OUTPUTASTEP1                                                    23

#define  _TXT_DIS__OUTPUTASTEP1_TEXT_DISPLAY1                                  3

#define  _BTN_OUTPUTASTEP1_BUTTON2                                             2

#define  _BTN_OUTPUTASTEP1_BUTTON1                                             4

#define  _TXT_DIS__OUTPUTASTEP1_TEXT_DISPLAY3                                  8

//����OutputAStep2�ı���ͼƬ
#define  _IMG_OUTPUTASTEP2                                                    24

#define  _TXT_DIS__OUTPUTASTEP2_TEXT_DISPLAY1                                  3

#define  _BTN_OUTPUTASTEP2_BUTTON2                                             2

#define  _BTN_OUTPUTASTEP2_BUTTON1                                             4

#define  _TXT_DIS__OUTPUTASTEP2_TEXT_DISPLAY3                                  8

//����OutputBStep1�ı���ͼƬ
#define  _IMG_OUTPUTBSTEP1                                                    23

#define  _TXT_DIS__OUTPUTBSTEP1_TEXT_DISPLAY1                                  3

#define  _BTN_OUTPUTBSTEP1_BUTTON2                                             2

#define  _BTN_OUTPUTBSTEP1_BUTTON1                                             4

#define  _TXT_DIS__OUTPUTBSTEP1_TEXT_DISPLAY3                                  8

//����OutputBStep2�ı���ͼƬ
#define  _IMG_OUTPUTBSTEP2                                                    24

#define  _TXT_DIS__OUTPUTBSTEP2_TEXT_DISPLAY1                                  3

#define  _BTN_OUTPUTBSTEP2_BUTTON2                                             2

#define  _BTN_OUTPUTBSTEP2_BUTTON1                                             4

#define  _TXT_DIS__OUTPUTBSTEP2_TEXT_DISPLAY3                                  8

//����CalibrationMain�ı���ͼƬ
#define  _IMG_CALIBRATIONMAIN                                                 25

#define  _BTN_CALIBRATIONMAIN_BUTTON2                                          1

#define  _BTN_CALIBRATIONMAIN_BUTTON1                                          2

#define  _BTN_CALIBRATIONMAIN_BUTTON3                                          3

#define  _BTN_CALIBRATIONMAIN_BUTTON4                                          4

#define  _BTN_CALIBRATIONMAIN_BUTTON5                                          5

#define  _BTN_CALIBRATIONMAIN_BUTTON6                                          6

#define  _BTN_CALIBRATIONMAIN_BUTTON7                                          7

#define  _BTN_CALIBRATIONMAIN_BUTTON8                                          8

//����CalibrationASICap#�ı���ͼƬ
#define  _IMG_CALIBRATIONASICAP#                                              26

#define  _TXT_DIS__CALIBRATIONASICAP#_TEXT_DISPLAY1                            3

#define  _BTN_CALIBRATIONASICAP#_BUTTON2                                       1

#define  _BTN_CALIBRATIONASICAP#_BUTTON1                                       2

//����CalibrationASIyandu�ı���ͼƬ
#define  _IMG_CALIBRATIONASIYANDU                                             27

#define  _TXT_DIS__CALIBRATIONASIYANDU_TEXT_DISPLAY1                           3

#define  _BTN_CALIBRATIONASIYANDU_BUTTON2                                      1

#define  _BTN_CALIBRATIONASIYANDU_BUTTON1                                      2

//����CalibrationASIPoint100�ı���ͼƬ
#define  _IMG_CALIBRATIONASIPOINT100                                          28

#define  _BTN_CALIBRATIONASIPOINT100_BUTTON2                                   1

#define  _BTN_CALIBRATIONASIPOINT100_BUTTON1                                   2

//����CalibrationASITemperature�ı���ͼƬ
#define  _IMG_CALIBRATIONASITEMPERATURE                                       29

#define  _TXT_DIS__CALIBRATIONASITEMPERATURE_TEXT_DISPLAY1                     3

#define  _BTN_CALIBRATIONASITEMPERATURE_BUTTON2                                1

#define  _BTN_CALIBRATIONASITEMPERATURE_BUTTON1                                2

#define  _TXT_DIS__CALIBRATIONASITEMPERATURE_TEXT_DISPLAY2                     4

//����CalibrationPoint0�ı���ͼƬ
#define  _IMG_CALIBRATIONPOINT0                                               30

#define  _BTN_CALIBRATIONPOINT0_BUTTON2                                        1

#define  _BTN_CALIBRATIONPOINT0_BUTTON1                                        2

//����CalibrationProcess�ı���ͼƬ
#define  _IMG_CALIBRATIONPROCESS                                              31

//����CalibrationProcess�ж����ؼ�Animation1ʹ�õ�ͼƬ
#define  _IMG_CALIBRATIONPROCESS_ANIMATION1                                   32

#define  _ANIMATION_CALIBRATIONPROCESS_ANIMATION1                              5

//����CalibrationProcessLDO�ı���ͼƬ
#define  _IMG_CALIBRATIONPROCESSLDO                                           31

#define  _TXT_DIS__CALIBRATIONPROCESSLDO_TEXT_DISPLAY1                         3

#define  _TXT_DIS__CALIBRATIONPROCESSLDO_TEXT_DISPLAY2                         4

//����CalibrationProcessLDO�ж����ؼ�Animation1ʹ�õ�ͼƬ
#define  _IMG_CALIBRATIONPROCESSLDO_ANIMATION1                                33

#define  _ANIMATION_CALIBRATIONPROCESSLDO_ANIMATION1                           5

#define  _TXT_DIS__CALIBRATIONPROCESSLDO_TEXT_DISPLAY3                         8

#define  _TXT_DIS__CALIBRATIONPROCESSLDO_TEXT_DISPLAY4                         9

#define  _TXT_DIS__CALIBRATIONPROCESSLDO_TEXT_DISPLAY5                        11

//����ASI_History�ı���ͼƬ
#define  _IMG_ASI_HISTORY                                                     34

#define  _BTN_ASI_HISTORY_BUTTON1                                              1

#define  _BTN_ASI_HISTORY_BUTTON2                                              2

#define  _BTN_ASI_HISTORY_BUTTON3                                              3

#define  _BTN_ASI_HISTORY_BUTTON4                                              4

#define  _BTN_ASI_HISTORY_BUTTON5                                              5

#define  _TXT_DIS__ASI_HISTORY_TEXT_DISPLAY1                                   6

#define  _TXT_DIS__ASI_HISTORY_TEXT_DISPLAY2                                   7

#define  _GRAPH_ASI_HISTORY_GRAPH1                                             9

#define  _GRAPH_ASI_HISTORY_GRAPH2                                             8

#define  _TXT_DIS__ASI_HISTORY_TEXT_DISPLAY4                                  10

#define  _TXT_DIS__ASI_HISTORY_TEXT_DISPLAY6                                  12

#define  _TXT_DIS__ASI_HISTORY_TEXT_DISPLAY8                                  14

#define  _TXT_DIS__ASI_HISTORY_TEXT_DISPLAY3                                  11

#define  _TXT_DIS__ASI_HISTORY_TEXT_DISPLAY5                                  13

#define  _TXT_DIS__ASI_HISTORY_TEXT_DISPLAY7                                  15

//����DeviceInfo�ı���ͼƬ
#define  _IMG_DEVICEINFO                                                      35

#define  _BTN_DEVICEINFO_BUTTON1                                               1

#define  _TXT_DIS__DEVICEINFO_TEXT_DISPLAY1                                    2

#define  _TXT_DIS__DEVICEINFO_TEXT_DISPLAY2                                    3

#define  _TXT_DIS__DEVICEINFO_TEXT_DISPLAY3                                    4

#define  _TXT_DIS__DEVICEINFO_TEXT_DISPLAY4                                    5

#define  _TXT_DIS__DEVICEINFO_TEXT_DISPLAY5                                    6

#define  _BTN_DEVICEINFO_BUTTON2                                               7

//����SensorInfo�ı���ͼƬ
#define  _IMG_SENSORINFO                                                      36

#define  _BTN_SENSORINFO_BUTTON1                                               1

#define  _TXT_DIS__SENSORINFO_TEXT_DISPLAY1                                    2

#define  _TXT_DIS__SENSORINFO_TEXT_DISPLAY2                                    3

#define  _TXT_DIS__SENSORINFO_TEXT_DISPLAY3                                    4

#define  _BTN_SENSORINFO_BUTTON2                                               7

#define  _TXT_DIS__SENSORINFO_TEXT_DISPLAY4                                    5

//����ReadSensorProcess�ı���ͼƬ
#define  _IMG_READSENSORPROCESS                                               37

//����ReadSensorProcess�ж����ؼ�Animation1ʹ�õ�ͼƬ
#define  _IMG_READSENSORPROCESS_ANIMATION1                                    32

#define  _ANIMATION_READSENSORPROCESS_ANIMATION1                               5

//����Factory_Reset�ı���ͼƬ
#define  _IMG_FACTORY_RESET                                                   38

#define  _BTN_FACTORY_RESET_BUTTON1                                            1

#define  _BTN_FACTORY_RESET_BUTTON2                                            2

//����pH_Mode_Sel_ATC�ı���ͼƬ
#define  _IMG_PH_MODE_SEL_ATC                                                 39

#define  _BTN_PH_MODE_SEL_ATC_BUTTON1                                          3

#define  _BTN_PH_MODE_SEL_ATC_BUTTON2                                          1

#define  _TXT_DIS__PH_MODE_SEL_ATC_TEXT_DISPLAY2                               5

#define  _BTN_PH_MODE_SEL_ATC_BUTTON3                                          6

#define  _MENU_PH_MODE_SEL_ATC_MENU1                                           2

//����pH_Mode_Sel_MTC�ı���ͼƬ
#define  _IMG_PH_MODE_SEL_MTC                                                 40

#define  _BTN_PH_MODE_SEL_MTC_BUTTON1                                          3

#define  _TXT_DIS__PH_MODE_SEL_MTC_TEXT_DISPLAY1                               4

#define  _BTN_PH_MODE_SEL_MTC_BUTTON2                                          1

#define  _TXT_DIS__PH_MODE_SEL_MTC_TEXT_DISPLAY2                               5

#define  _BTN_PH_MODE_SEL_MTC_BUTTON3                                          6

#define  _MENU_PH_MODE_SEL_MTC_MENU1                                           2

//����Output_A_pH_Setting�ı���ͼƬ
#define  _IMG_OUTPUT_A_PH_SETTING                                             11

#define  _BTN_OUTPUT_A_PH_SETTING_BUTTON1                                      1

#define  _BTN_OUTPUT_A_PH_SETTING_BUTTON3                                      3

#define  _TXT_DIS__OUTPUT_A_PH_SETTING_TEXT_DISPLAY1                           5

#define  _TXT_DIS__OUTPUT_A_PH_SETTING_TEXT_DISPLAY2                           6

#define  _TXT_DIS__OUTPUT_A_PH_SETTING_TEXT_DISPLAY3                           8

#define  _TXT_DIS__OUTPUT_A_PH_SETTING_TEXT_DISPLAY4                           9

#define  _BTN_OUTPUT_A_PH_SETTING_BUTTON4                                     10

#define  _MENU_OUTPUT_A_PH_SETTING_MENU1                                       4

//����Output_A_ORP_Setting�ı���ͼƬ
#define  _IMG_OUTPUT_A_ORP_SETTING                                            11

#define  _BTN_OUTPUT_A_ORP_SETTING_BUTTON1                                     1

#define  _BTN_OUTPUT_A_ORP_SETTING_BUTTON3                                     3

#define  _TXT_DIS__OUTPUT_A_ORP_SETTING_TEXT_DISPLAY1                          5

#define  _TXT_DIS__OUTPUT_A_ORP_SETTING_TEXT_DISPLAY2                          6

#define  _TXT_DIS__OUTPUT_A_ORP_SETTING_TEXT_DISPLAY3                          8

#define  _TXT_DIS__OUTPUT_A_ORP_SETTING_TEXT_DISPLAY4                          9

#define  _BTN_OUTPUT_A_ORP_SETTING_BUTTON4                                    10

#define  _MENU_OUTPUT_A_ORP_SETTING_MENU1                                      4

//����Output_B_pH_Setting�ı���ͼƬ
#define  _IMG_OUTPUT_B_PH_SETTING                                             11

#define  _TXT_DIS__OUTPUT_B_PH_SETTING_TEXT_DISPLAY3                           8

#define  _BTN_OUTPUT_B_PH_SETTING_BUTTON1                                      1

#define  _BTN_OUTPUT_B_PH_SETTING_BUTTON3                                      3

#define  _TXT_DIS__OUTPUT_B_PH_SETTING_TEXT_DISPLAY1                           5

#define  _TXT_DIS__OUTPUT_B_PH_SETTING_TEXT_DISPLAY2                           6

#define  _TXT_DIS__OUTPUT_B_PH_SETTING_TEXT_DISPLAY4                           9

#define  _BTN_OUTPUT_B_PH_SETTING_BUTTON4                                     10

#define  _MENU_OUTPUT_B_PH_SETTING_MENU1                                       4

//����Output_B_ORP_Setting�ı���ͼƬ
#define  _IMG_OUTPUT_B_ORP_SETTING                                            11

#define  _TXT_DIS__OUTPUT_B_ORP_SETTING_TEXT_DISPLAY3                          8

#define  _BTN_OUTPUT_B_ORP_SETTING_BUTTON1                                     1

#define  _BTN_OUTPUT_B_ORP_SETTING_BUTTON3                                     3

#define  _TXT_DIS__OUTPUT_B_ORP_SETTING_TEXT_DISPLAY1                          5

#define  _TXT_DIS__OUTPUT_B_ORP_SETTING_TEXT_DISPLAY2                          6

#define  _TXT_DIS__OUTPUT_B_ORP_SETTING_TEXT_DISPLAY4                          9

#define  _BTN_OUTPUT_B_ORP_SETTING_BUTTON4                                    10

#define  _MENU_OUTPUT_B_ORP_SETTING_MENU1                                      4

//����PH_Calib_Main�ı���ͼƬ
#define  _IMG_PH_CALIB_MAIN                                                   41

#define  _BTN_PH_CALIB_MAIN_BUTTON1                                            1

#define  _BTN_PH_CALIB_MAIN_BUTTON2                                            2

#define  _BTN_PH_CALIB_MAIN_BUTTON3                                            3

#define  _BTN_PH_CALIB_MAIN_BUTTON4                                            4

#define  _BTN_PH_CALIB_MAIN_BUTTON5                                            5

//����Ph_Calib_MANU_P1_Start�ı���ͼƬ
#define  _IMG_PH_CALIB_MANU_P1_START                                          42

#define  _BTN_PH_CALIB_MANU_P1_START_BUTTON2                                   2

#define  _BTN_PH_CALIB_MANU_P1_START_BUTTON1                                   1

#define  _TXT_DIS__PH_CALIB_MANU_P1_START_TEXT_DISPLAY2                        3

//����Ph_Calib_MANU_P2_Start�ı���ͼƬ
#define  _IMG_PH_CALIB_MANU_P2_START                                          43

#define  _BTN_PH_CALIB_MANU_P2_START_BUTTON2                                   2

#define  _BTN_PH_CALIB_MANU_P2_START_BUTTON1                                   1

#define  _TXT_DIS__PH_CALIB_MANU_P2_START_TEXT_DISPLAY2                        3

//����Ph_Calib_MANU_P3_Start�ı���ͼƬ
#define  _IMG_PH_CALIB_MANU_P3_START                                          44

#define  _BTN_PH_CALIB_MANU_P3_START_BUTTON2                                   2

#define  _BTN_PH_CALIB_MANU_P3_START_BUTTON1                                   1

#define  _TXT_DIS__PH_CALIB_MANU_P3_START_TEXT_DISPLAY2                        3

//����Ph_Calib_Menu_ATC�ı���ͼƬ
#define  _IMG_PH_CALIB_MENU_ATC                                               45

#define  _BTN_PH_CALIB_MENU_ATC_BUTTON1                                        1

#define  _BTN_PH_CALIB_MENU_ATC_BUTTON2                                        2

#define  _TXT_DIS__PH_CALIB_MENU_ATC_TEXT_DISPLAY4                             9

#define  _BTN_PH_CALIB_MENU_ATC_BUTTON3                                        3

#define  _BTN_PH_CALIB_MENU_ATC_BUTTON4                                        4

//����Ph_Calib_Menu_MTC�ı���ͼƬ
#define  _IMG_PH_CALIB_MENU_MTC                                               46

#define  _BTN_PH_CALIB_MENU_MTC_BUTTON4                                        4

#define  _BTN_PH_CALIB_MENU_MTC_BUTTON1                                        1

#define  _TXT_DIS__PH_CALIB_MENU_MTC_TEXT_DISPLAY4                             9

#define  _BTN_PH_CALIB_MENU_MTC_BUTTON3                                        3

//����Ph_Calib_NIST_P1_Start�ı���ͼƬ
#define  _IMG_PH_CALIB_NIST_P1_START                                          47

#define  _BTN_PH_CALIB_NIST_P1_START_BUTTON1                                   1

#define  _BTN_PH_CALIB_NIST_P1_START_BUTTON2                                   2

//����Ph_Calib_NIST_P2_Start�ı���ͼƬ
#define  _IMG_PH_CALIB_NIST_P2_START                                          48

#define  _BTN_PH_CALIB_NIST_P2_START_BUTTON2                                   2

#define  _BTN_PH_CALIB_NIST_P2_START_BUTTON1                                   1

//����Ph_Calib_NIST_P3_Start�ı���ͼƬ
#define  _IMG_PH_CALIB_NIST_P3_START                                          49

#define  _BTN_PH_CALIB_NIST_P3_START_BUTTON2                                   2

#define  _BTN_PH_CALIB_NIST_P3_START_BUTTON1                                   1

//����Ph_Calib_P1_End�ı���ͼƬ
#define  _IMG_PH_CALIB_P1_END                                                 50

#define  _BTN_PH_CALIB_P1_END_BUTTON2                                          2

#define  _BTN_PH_CALIB_P1_END_BUTTON1                                          1

#define  _BTN_PH_CALIB_P1_END_BUTTON3                                          3

#define  _TXT_DIS__PH_CALIB_P1_END_TEXT_DISPLAY1                               4

#define  _TXT_DIS__PH_CALIB_P1_END_TEXT_DISPLAY2                               5

#define  _TXT_DIS__PH_CALIB_P1_END_TEXT_DISPLAY3                               6

#define  _TXT_DIS__PH_CALIB_P1_END_TEXT_DISPLAY4                               7

//����Ph_Calib_P1_Process�ı���ͼƬ
#define  _IMG_PH_CALIB_P1_PROCESS                                             51

#define  _TXT_DIS__PH_CALIB_P1_PROCESS_TEXT_DISPLAY1                           4

#define  _TXT_DIS__PH_CALIB_P1_PROCESS_TEXT_DISPLAY2                           5

#define  _TXT_DIS__PH_CALIB_P1_PROCESS_TEXT_DISPLAY3                           6

#define  _TXT_DIS__PH_CALIB_P1_PROCESS_TEXT_DISPLAY4                           7

//����Ph_Calib_P2_End�ı���ͼƬ
#define  _IMG_PH_CALIB_P2_END                                                 52

#define  _BTN_PH_CALIB_P2_END_BUTTON2                                          2

#define  _BTN_PH_CALIB_P2_END_BUTTON1                                          1

#define  _BTN_PH_CALIB_P2_END_BUTTON3                                          3

#define  _TXT_DIS__PH_CALIB_P2_END_TEXT_DISPLAY1                               4

#define  _TXT_DIS__PH_CALIB_P2_END_TEXT_DISPLAY2                               5

#define  _TXT_DIS__PH_CALIB_P2_END_TEXT_DISPLAY3                               6

#define  _TXT_DIS__PH_CALIB_P2_END_TEXT_DISPLAY4                               7

//����Ph_Calib_P2_Process�ı���ͼƬ
#define  _IMG_PH_CALIB_P2_PROCESS                                             53

#define  _TXT_DIS__PH_CALIB_P2_PROCESS_TEXT_DISPLAY1                           4

#define  _TXT_DIS__PH_CALIB_P2_PROCESS_TEXT_DISPLAY2                           5

#define  _TXT_DIS__PH_CALIB_P2_PROCESS_TEXT_DISPLAY3                           6

#define  _TXT_DIS__PH_CALIB_P2_PROCESS_TEXT_DISPLAY4                           7

//����Ph_Calib_P3_End�ı���ͼƬ
#define  _IMG_PH_CALIB_P3_END                                                 54

#define  _BTN_PH_CALIB_P3_END_BUTTON2                                          2

#define  _BTN_PH_CALIB_P3_END_BUTTON1                                          1

#define  _TXT_DIS__PH_CALIB_P3_END_TEXT_DISPLAY1                               4

#define  _TXT_DIS__PH_CALIB_P3_END_TEXT_DISPLAY2                               5

#define  _TXT_DIS__PH_CALIB_P3_END_TEXT_DISPLAY3                               6

#define  _TXT_DIS__PH_CALIB_P3_END_TEXT_DISPLAY4                               7

//����Ph_Calib_P3_Process�ı���ͼƬ
#define  _IMG_PH_CALIB_P3_PROCESS                                             55

#define  _TXT_DIS__PH_CALIB_P3_PROCESS_TEXT_DISPLAY1                           4

#define  _TXT_DIS__PH_CALIB_P3_PROCESS_TEXT_DISPLAY2                           5

#define  _TXT_DIS__PH_CALIB_P3_PROCESS_TEXT_DISPLAY3                           6

#define  _TXT_DIS__PH_CALIB_P3_PROCESS_TEXT_DISPLAY4                           7

//����Ph_Calib_Result_P1�ı���ͼƬ
#define  _IMG_PH_CALIB_RESULT_P1                                              56

#define  _BTN_PH_CALIB_RESULT_P1_BUTTON1                                       1

#define  _TXT_DIS__PH_CALIB_RESULT_P1_TEXT_DISPLAY8                           10

#define  _TXT_DIS__PH_CALIB_RESULT_P1_TEXT_DISPLAY2                            4

#define  _TXT_DIS__PH_CALIB_RESULT_P1_TEXT_DISPLAY1                            2

#define  _TXT_DIS__PH_CALIB_RESULT_P1_TEXT_DISPLAY3                            3

#define  _TXT_DIS__PH_CALIB_RESULT_P1_TEXT_DISPLAY4                            5

#define  _TXT_DIS__PH_CALIB_RESULT_P1_TEXT_DISPLAY5                            6

#define  _TXT_DIS__PH_CALIB_RESULT_P1_TEXT_DISPLAY6                            7

//����Ph_Calib_Result_P2�ı���ͼƬ
#define  _IMG_PH_CALIB_RESULT_P2                                              57

#define  _BTN_PH_CALIB_RESULT_P2_BUTTON1                                       1

#define  _TXT_DIS__PH_CALIB_RESULT_P2_TEXT_DISPLAY1                            3

#define  _TXT_DIS__PH_CALIB_RESULT_P2_TEXT_DISPLAY2                            4

#define  _TXT_DIS__PH_CALIB_RESULT_P2_TEXT_DISPLAY3                            5

#define  _TXT_DIS__PH_CALIB_RESULT_P2_TEXT_DISPLAY4                            6

#define  _TXT_DIS__PH_CALIB_RESULT_P2_TEXT_DISPLAY5                            7

#define  _TXT_DIS__PH_CALIB_RESULT_P2_TEXT_DISPLAY6                            8

#define  _TXT_DIS__PH_CALIB_RESULT_P2_TEXT_DISPLAY7                            9

#define  _TXT_DIS__PH_CALIB_RESULT_P2_TEXT_DISPLAY8                           10

#define  _TXT_DIS__PH_CALIB_RESULT_P2_TEXT_DISPLAY9                           11

#define  _TXT_DIS__PH_CALIB_RESULT_P2_TEXT_DISPLAY10                          12

#define  _TXT_DIS__PH_CALIB_RESULT_P2_TEXT_DISPLAY11                          13

//����Ph_Calib_Result_P3�ı���ͼƬ
#define  _IMG_PH_CALIB_RESULT_P3                                              58

#define  _BTN_PH_CALIB_RESULT_P3_BUTTON1                                       1

#define  _TXT_DIS__PH_CALIB_RESULT_P3_TEXT_DISPLAY1                            3

#define  _TXT_DIS__PH_CALIB_RESULT_P3_TEXT_DISPLAY2                            4

#define  _TXT_DIS__PH_CALIB_RESULT_P3_TEXT_DISPLAY3                            5

#define  _TXT_DIS__PH_CALIB_RESULT_P3_TEXT_DISPLAY4                            6

#define  _TXT_DIS__PH_CALIB_RESULT_P3_TEXT_DISPLAY5                            7

#define  _TXT_DIS__PH_CALIB_RESULT_P3_TEXT_DISPLAY6                            8

#define  _TXT_DIS__PH_CALIB_RESULT_P3_TEXT_DISPLAY7                            9

#define  _TXT_DIS__PH_CALIB_RESULT_P3_TEXT_DISPLAY8                           10

#define  _TXT_DIS__PH_CALIB_RESULT_P3_TEXT_DISPLAY9                           11

#define  _TXT_DIS__PH_CALIB_RESULT_P3_TEXT_DISPLAY10                          12

#define  _TXT_DIS__PH_CALIB_RESULT_P3_TEXT_DISPLAY11                          13

#define  _TXT_DIS__PH_CALIB_RESULT_P3_TEXT_DISPLAY12                          14

#define  _TXT_DIS__PH_CALIB_RESULT_P3_TEXT_DISPLAY13                          15

#define  _TXT_DIS__PH_CALIB_RESULT_P3_TEXT_DISPLAY14                          16

#define  _TXT_DIS__PH_CALIB_RESULT_P3_TEXT_DISPLAY15                          17

#define  _TXT_DIS__PH_CALIB_RESULT_P3_TEXT_DISPLAY16                          18

//����Ph_Calib_TECH_P1_Start�ı���ͼƬ
#define  _IMG_PH_CALIB_TECH_P1_START                                          59

#define  _BTN_PH_CALIB_TECH_P1_START_BUTTON2                                   2

#define  _BTN_PH_CALIB_TECH_P1_START_BUTTON1                                   1

//����Ph_Calib_TECH_P2_Start�ı���ͼƬ
#define  _IMG_PH_CALIB_TECH_P2_START                                          60

#define  _BTN_PH_CALIB_TECH_P2_START_BUTTON2                                   2

#define  _BTN_PH_CALIB_TECH_P2_START_BUTTON1                                   1

//����Ph_Calib_TECH_P3_Start�ı���ͼƬ
#define  _IMG_PH_CALIB_TECH_P3_START                                          61

#define  _BTN_PH_CALIB_TECH_P3_START_BUTTON2                                   2

#define  _BTN_PH_CALIB_TECH_P3_START_BUTTON1                                   1

//����ORP_Calib_Start�ı���ͼƬ
#define  _IMG_ORP_CALIB_START                                                 62

#define  _BTN_ORP_CALIB_START_BUTTON2                                          2

#define  _BTN_ORP_CALIB_START_BUTTON1                                          1

#define  _TXT_DIS__ORP_CALIB_START_TEXT_DISPLAY1                               4

#define  _TXT_DIS__ORP_CALIB_START_TEXT_DISPLAY2                               3

//����ORP_Calib_Process�ı���ͼƬ
#define  _IMG_ORP_CALIB_PROCESS                                               63

//����ORP_Calib_Process�ж����ؼ�Animation1ʹ�õ�ͼƬ
#define  _IMG_ORP_CALIB_PROCESS_ANIMATION1                                    32

#define  _ANIMATION_ORP_CALIB_PROCESS_ANIMATION1                               5

//����Temp_Calib_Diff�ı���ͼƬ
#define  _IMG_TEMP_CALIB_DIFF                                                 64

#define  _BTN_TEMP_CALIB_DIFF_BUTTON2                                          2

#define  _BTN_TEMP_CALIB_DIFF_BUTTON1                                          1

#define  _TXT_DIS__TEMP_CALIB_DIFF_TEXT_DISPLAY1                               4

#define  _TXT_DIS__TEMP_CALIB_DIFF_TEXT_DISPLAY2                               3

//����PHORP_Factory_Calib_Main�ı���ͼƬ
#define  _IMG_PHORP_FACTORY_CALIB_MAIN                                        65

#define  _BTN_PHORP_FACTORY_CALIB_MAIN_BUTTON2                                 2

#define  _BTN_PHORP_FACTORY_CALIB_MAIN_BUTTON1                                 1

#define  _BTN_PHORP_FACTORY_CALIB_MAIN_BUTTON3                                 3

#define  _BTN_PHORP_FACTORY_CALIB_MAIN_BUTTON4                                 4

#define  _BTN_PHORP_FACTORY_CALIB_MAIN_BUTTON5                                 5

#define  _BTN_PHORP_FACTORY_CALIB_MAIN_BUTTON6                                 6

//����ORP_Factory_Calib_P1_Start�ı���ͼƬ
#define  _IMG_ORP_FACTORY_CALIB_P1_START                                      66

#define  _BTN_ORP_FACTORY_CALIB_P1_START_BUTTON2                               2

#define  _BTN_ORP_FACTORY_CALIB_P1_START_BUTTON1                               1

#define  _TXT_DIS__ORP_FACTORY_CALIB_P1_START_TEXT_DISPLAY2                    3

//����ORP_Factory_Calib_P1_Process�ı���ͼƬ
#define  _IMG_ORP_FACTORY_CALIB_P1_PROCESS                                    67

#define  _TXT_DIS__ORP_FACTORY_CALIB_P1_PROCESS_TEXT_DISPLAY1                  4

//����ORP_Factory_Calib_P2_Start�ı���ͼƬ
#define  _IMG_ORP_FACTORY_CALIB_P2_START                                      68

#define  _BTN_ORP_FACTORY_CALIB_P2_START_BUTTON2                               2

#define  _BTN_ORP_FACTORY_CALIB_P2_START_BUTTON1                               1

#define  _TXT_DIS__ORP_FACTORY_CALIB_P2_START_TEXT_DISPLAY2                    3

//����ORP_Factory_Calib_P2_Process�ı���ͼƬ
#define  _IMG_ORP_FACTORY_CALIB_P2_PROCESS                                    69

#define  _TXT_DIS__ORP_FACTORY_CALIB_P2_PROCESS_TEXT_DISPLAY1                  4

//����ORP_Factory_Calib_P3_Start�ı���ͼƬ
#define  _IMG_ORP_FACTORY_CALIB_P3_START                                      70

#define  _BTN_ORP_FACTORY_CALIB_P3_START_BUTTON2                               2

#define  _BTN_ORP_FACTORY_CALIB_P3_START_BUTTON1                               1

#define  _TXT_DIS__ORP_FACTORY_CALIB_P3_START_TEXT_DISPLAY2                    3

//����ORP_Factory_Calib_P3_Process�ı���ͼƬ
#define  _IMG_ORP_FACTORY_CALIB_P3_PROCESS                                    71

#define  _TXT_DIS__ORP_FACTORY_CALIB_P3_PROCESS_TEXT_DISPLAY1                  4

//����ORP_Factory_Calib_Result�ı���ͼƬ
#define  _IMG_ORP_FACTORY_CALIB_RESULT                                        72

#define  _BTN_ORP_FACTORY_CALIB_RESULT_BUTTON1                                 1

#define  _TXT_DIS__ORP_FACTORY_CALIB_RESULT_TEXT_DISPLAY1                      4

#define  _TXT_DIS__ORP_FACTORY_CALIB_RESULT_TEXT_DISPLAY2                      2

#define  _TXT_DIS__ORP_FACTORY_CALIB_RESULT_TEXT_DISPLAY3                      3

#define  _TXT_DIS__ORP_FACTORY_CALIB_RESULT_TEXT_DISPLAY4                      5

#define  _TXT_DIS__ORP_FACTORY_CALIB_RESULT_TEXT_DISPLAY5                      6

//����Temp_Calib_P1_Start�ı���ͼƬ
#define  _IMG_TEMP_CALIB_P1_START                                             73

#define  _BTN_TEMP_CALIB_P1_START_BUTTON2                                      2

#define  _BTN_TEMP_CALIB_P1_START_BUTTON1                                      1

#define  _TXT_DIS__TEMP_CALIB_P1_START_TEXT_DISPLAY2                           3

//����Temp_Calib_P1_Process�ı���ͼƬ
#define  _IMG_TEMP_CALIB_P1_PROCESS                                           74

#define  _TXT_DIS__TEMP_CALIB_P1_PROCESS_TEXT_DISPLAY1                         4

//����Temp_Calib_P2_Start�ı���ͼƬ
#define  _IMG_TEMP_CALIB_P2_START                                             75

#define  _BTN_TEMP_CALIB_P2_START_BUTTON2                                      2

#define  _BTN_TEMP_CALIB_P2_START_BUTTON1                                      1

#define  _TXT_DIS__TEMP_CALIB_P2_START_TEXT_DISPLAY2                           3

//����Temp_Calib_P2_Process�ı���ͼƬ
#define  _IMG_TEMP_CALIB_P2_PROCESS                                           76

#define  _TXT_DIS__TEMP_CALIB_P2_PROCESS_TEXT_DISPLAY1                         4

//����Temp_Calib_Result�ı���ͼƬ
#define  _IMG_TEMP_CALIB_RESULT                                               77

#define  _BTN_TEMP_CALIB_RESULT_BUTTON1                                        1

#define  _TXT_DIS__TEMP_CALIB_RESULT_TEXT_DISPLAY1                             4

#define  _TXT_DIS__TEMP_CALIB_RESULT_TEXT_DISPLAY2                             2

#define  _TXT_DIS__TEMP_CALIB_RESULT_TEXT_DISPLAY4                             5

//����Factory_Calib_Question�ı���ͼƬ
#define  _IMG_FACTORY_CALIB_QUESTION                                          78

#define  _BTN_FACTORY_CALIB_QUESTION_BUTTON2                                   2

#define  _BTN_FACTORY_CALIB_QUESTION_BUTTON1                                   1

//����Factory_Setting_Question�ı���ͼƬ
#define  _IMG_FACTORY_SETTING_QUESTION                                        79

#define  _BTN_FACTORY_SETTING_QUESTION_BUTTON2                                 2

#define  _BTN_FACTORY_SETTING_QUESTION_BUTTON1                                 1

//����PH_History�ı���ͼƬ
#define  _IMG_PH_HISTORY                                                      80

#define  _BTN_PH_HISTORY_BUTTON1                                               1

#define  _BTN_PH_HISTORY_BUTTON2                                               2

#define  _BTN_PH_HISTORY_BUTTON3                                               3

#define  _BTN_PH_HISTORY_BUTTON4                                               4

#define  _BTN_PH_HISTORY_BUTTON5                                               5

#define  _TXT_DIS__PH_HISTORY_TEXT_DISPLAY1                                    6

#define  _TXT_DIS__PH_HISTORY_TEXT_DISPLAY2                                    7

#define  _GRAPH_PH_HISTORY_GRAPH1                                              9

#define  _GRAPH_PH_HISTORY_GRAPH2                                              8

#define  _TXT_DIS__PH_HISTORY_TEXT_DISPLAY4                                   10

#define  _TXT_DIS__PH_HISTORY_TEXT_DISPLAY6                                   12

#define  _TXT_DIS__PH_HISTORY_TEXT_DISPLAY8                                   14

#define  _TXT_DIS__PH_HISTORY_TEXT_DISPLAY3                                   11

#define  _TXT_DIS__PH_HISTORY_TEXT_DISPLAY5                                   13

#define  _TXT_DIS__PH_HISTORY_TEXT_DISPLAY7                                   15

//����ORP_History�ı���ͼƬ
#define  _IMG_ORP_HISTORY                                                     81

#define  _BTN_ORP_HISTORY_BUTTON1                                              1

#define  _BTN_ORP_HISTORY_BUTTON2                                              2

#define  _BTN_ORP_HISTORY_BUTTON3                                              3

#define  _BTN_ORP_HISTORY_BUTTON4                                              4

#define  _BTN_ORP_HISTORY_BUTTON5                                              5

#define  _TXT_DIS__ORP_HISTORY_TEXT_DISPLAY1                                   6

#define  _TXT_DIS__ORP_HISTORY_TEXT_DISPLAY2                                   7

#define  _GRAPH_ORP_HISTORY_GRAPH1                                             9

#define  _GRAPH_ORP_HISTORY_GRAPH2                                             8

#define  _TXT_DIS__ORP_HISTORY_TEXT_DISPLAY4                                  10

#define  _TXT_DIS__ORP_HISTORY_TEXT_DISPLAY6                                  12

#define  _TXT_DIS__ORP_HISTORY_TEXT_DISPLAY8                                  14

#define  _TXT_DIS__ORP_HISTORY_TEXT_DISPLAY3                                  11

#define  _TXT_DIS__ORP_HISTORY_TEXT_DISPLAY5                                  13

#define  _TXT_DIS__ORP_HISTORY_TEXT_DISPLAY7                                  15

//����PHORP_SensorInfo�ı���ͼƬ
#define  _IMG_PHORP_SENSORINFO                                                82

#define  _BTN_PHORP_SENSORINFO_BUTTON1                                         1

#define  _TXT_DIS__PHORP_SENSORINFO_TEXT_DISPLAY1                              2

#define  _TXT_DIS__PHORP_SENSORINFO_TEXT_DISPLAY2                              3

#define  _TXT_DIS__PHORP_SENSORINFO_TEXT_DISPLAY3                              4

#define  _BTN_PHORP_SENSORINFO_BUTTON2                                         7

#define  _TXT_DIS__PHORP_SENSORINFO_TEXT_DISPLAY4                              5

#define  _TXT_DIS__PHORP_SENSORINFO_TEXT_DISPLAY5                              6

//����SettingWait�ı���ͼƬ
#define  _IMG_SETTINGWAIT                                                     83

//����SettingWait�ж����ؼ�Animation1ʹ�õ�ͼƬ
#define  _IMG_SETTINGWAIT_ANIMATION1                                          32

#define  _ANIMATION_SETTINGWAIT_ANIMATION1                                     5

//����SensorDisconnect�ı���ͼƬ
#define  _IMG_SENSORDISCONNECT                                                84

#define  _BTN_SENSORDISCONNECT_BUTTON1                                         1

//����CalibrationError�ı���ͼƬ
#define  _IMG_CALIBRATIONERROR                                                85

#define  _BTN_CALIBRATIONERROR_BUTTON1                                         1

#define  _TXT_DIS__CALIBRATIONERROR_TEXT_DISPLAY1                              4

//����PHORP_Calib_Temp�ı���ͼƬ
#define  _IMG_PHORP_CALIB_TEMP                                                86

#define  _TXT_DIS__PHORP_CALIB_TEMP_TEXT_DISPLAY1                              4

#define  _BTN_PHORP_CALIB_TEMP_BUTTON2                                         1

#define  _TXT_DIS__PHORP_CALIB_TEMP_TEXT_DISPLAY2                              3

#define  _BTN_PHORP_CALIB_TEMP_BUTTON1                                         2

