Analog Devices Inc.
Design Support Package
CN-0388
09/16/2016
Rev. 0

This file is designed to provide you with a brief overview of what is contained within the circuit note design support package.

**********************
*******Overview*******
**********************

CN-0388 Design Support Package contains: 
	
	Link to Circuit Note
	Link to Product Datasheets
	Link to Product Evaluation Boards and User Guides
	PADs Schematics
	Bill of Materials
	PADs Layout Files
	Gerber Layout Files	
	Link to Technical Support
	Link to Other Resources


**********************
***File Explanation**
**********************


Circuit Note - Copy of the circuit note this design support package was made for.  This file is provided as a PDF:

	CN0388: http://www.analog.com/CN0388

Product Datasheets - Links to all ADI component datasheets used in the circuit.  These files are provided as a PDF:


	ADN4651		http://www.analog.com/ADN4651
	AD7960		http://www.analog.com/AD7960
	ADUM4400	http://www.analog.com/ADUM4400
	ADUM2251	http://www.analog.com/ADUM2251
			

********************************************************
CN0388 	Evaluation Board:
	 
	http://www.analog.com/EVAL-CN0388-FMCZ


Schematic (PADS) for EVAL-CN0388-FMCZ:

	EVAL-CN0388-FMCZ-PADSSchematic-RevB.sch
	EVAL-CN0388-FMCZ-PADSSchematic-RevB.pdf

	
Layout files (PADS) for EVAL-CN0388-FMCZ: 

	EVAL-CN0388-FMCZ-PADSLayout-RevB.pcb
	EVAL-CN0388-FMCZ-PADSLayout-RevB.pdf


Gerber files for EVAL-CN0388-FMCZ:

	EVAL-CN0388-FMCZ-GRB-RevB.zip


Bill of Materials for EVAL-CN0388-FMCZ:

	EVAL-CN0388-FMCZ-BOM-RevB1.xls


AD7960 Evaluation Board: EVAL-AD7960-FMCZ

	http://www.analog.com/EVAL-AD7960-FMCZ
	
	http://www.analog.com/UG-409   (User Guide)


SDP-H1 System Demonstration Platform: EVAL-SDP-CH1Z

	http://www.analog.com/EVAL-SDP-CH1Z
	
	http://www.analog.com/UG-502   (User Guide)
	




Symbols and Footprints:

ADN4651:
http://www.analog.com/en/design-center/packaging-quality-symbols-footprints/symbols-and-footprints/ADN4651.html

AD7960:
http://www.analog.com/en/design-center/packaging-quality-symbols-footprints/symbols-and-footprints/AD7960.html

ADUM4400:
http://www.analog.com/en/design-center/packaging-quality-symbols-footprints/symbols-and-footprints/ADUM4400.html

ADUM2251:
http://www.analog.com/en/design-center/packaging-quality-symbols-footprints/symbols-and-footprints/ADUM2251.html


			
********************************************************


Technical Support -  If you require further technical assistance please contact us by phone, email, or our EngineerZone community.  http://www.analog.com/en/content/technical_support_page/fca.html


**********************
***Other Resources****
**********************

Resources that are not provided by Analog Devices, but could be helpful.

Gerber Viewer:  http://www.graphicode.com, http://www.viewplot.com, http://www.pentalogix.com/

PADs Viewer: http://www.mentor.com/products/pcb-system-design/design-flows/pads/pads-pcb-viewer

