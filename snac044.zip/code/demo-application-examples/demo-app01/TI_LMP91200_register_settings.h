//----------------------------------------------------------------------------
//  Description:  This file contains the initialization values for the 
//  LMP91200 registers.
//
//  MSP430/LMP91200 Interface Code Library v1.0
//
//   Vishy Natarajan
//   Texas Instruments Inc.
//   March 2012
//   Built with CCE Version: 4.2 and IAR Embedded Workbench Version:  5.3x
//------------------------------------------------------------------------------
// Change Log:
//------------------------------------------------------------------------------
// Version:  1.00
// Comments: Initial Release Version
//------------------------------------------------------------------------------
#ifndef HEADER_FILE_TI_LMP91200_REGISTER_SETTINGS_H

#define HEADER_FILE_TI_LMP91200_REGISTER_SETTINGS_H

/************************************************************
* TI LMP91200 REGISTER SET INITIALIZATION VALUES
************************************************************/

#define TI_LMP91200_CONFIG_REG_VALUE                  (0xB080)                 /* Temp Measurement, RTD, 2mA, PGA=5, VOCM=GND */                          
#define TI_LMP91200_CONFIG_REG_NEW_VALUE              (0xA080)                 /* Temp Measurement, RTD, 1mA, PGA=5, VOCM=GND */

#endif                                                                         // HEADER_FILE_TI_LMP91200_REGISTER_SETTINGS_H