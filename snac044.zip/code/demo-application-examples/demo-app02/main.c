//******************************************************************************
//  Demo Application02 for MSP430/LMP91200 Interface Code Library
//  1-step temperature measurement
//
//                MSP430F5528
//             -----------------
//         /|\|              XIN|-
//          | |                 |  
//          --|RST          XOUT|-
//            |                 |
//            |    P3.3/UCA0SIMO|--> SDI 
//            |    P3.4/UCA0SOMI|<-- SDO 
//            |     P2.7/UCA0CLK|--> CLK 
//            |             P2.5|--> CSB 
//            |                 | 
//            |                 | 
//
//   Vishy Natarajan
//   Texas Instruments Inc.
//   March 2012
//   Built with CCE Version: 4.2 and IAR Embedded Workbench Version:  5.3x
//******************************************************************************
// Change Log:
//******************************************************************************
// Version:  1.00
// Comments: Initial Release Version
//******************************************************************************
/*  Copyright 2011-2012 Texas Instruments Incorporated. All rights reserved.

  IMPORTANT: Your use of this Software is limited to those specific rights
  granted under the terms of a software license agreement between the user who
  downloaded the software, his/her employer (which must be your employer) and
  Texas Instruments Incorporated (the "License"). You may not use this Software
  unless you agree to abide by the terms of the License. The License limits your
  use, and you acknowledge, that the Software may not be modified, copied or
  distributed unless embedded on a Texas Instruments microcontroller which is 
  integrated into your product. Other than for the foregoing purpose, you may 
  not use, reproduce, copy, prepare derivative works of, modify, distribute, 
  perform, display or sell this Software and/or its documentation for any 
  purpose.

  YOU FURTHER ACKNOWLEDGE AND AGREE THAT THE SOFTWARE AND DOCUMENTATION ARE
  PROVIDED �AS IS� WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED,
  INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF MERCHANTABILITY, TITLE,
  NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT SHALL TEXAS
  INSTRUMENTS OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER CONTRACT,
  NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR OTHER LEGAL
  EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES INCLUDING BUT NOT
  LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR CONSEQUENTIAL
  DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF SUBSTITUTE GOODS,
  TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES (INCLUDING BUT NOT
  LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.

  Should you have any questions regarding your right to use this Software,
  contact Texas Instruments Incorporated at www.TI.com.
*******************************************************************************/

#include <stdint.h>
#include "TI_LMP91200.h"
#include "TI_LMP91200_register_settings.h"
#include "TI_MSP430.h"
#include "TI_MSP430_hardware_board.h"
#include "TI_MSP430_spi.h"

void timerA0_init(void);                                                       // initialize timerA0 to generate interrupt every sec
                                                                               // for temperature measurement
#define NUM_OF_RESULTS      8                                                  // Number of temp sensor samples to take
#define SCALE_FACTOR        3                                                  // For averaging converted samples
#define PT_RES_NOMINAL      100                                                // 100ohms at 0degC
#define ADC14_RATIO         0.15259                                            // 2500/16384(2500mV ref & 14bit converter w/ 2's comp o/p)
#define PT_TC               0.3850                                             // PT_TC is ohms/degC
#define PGA_GAIN            10                                                 // Gain of 10
#define I_VALUE             1                                                  // 1mA
#define INTERVAL_1S         16666                                              // 1sec timer interval
//******************************************************************************
void main(void)
{
  uint16_t reg_write_data, reg_read_data;
    
  WDTCTL = WDTPW+WDTHOLD;                                                      // Stop WDT
  
  TI_LMP91200_LED_PxOUT |= TI_LMP91200_LED_PIN;                                // Set LED ON
  TI_LMP91200_LED_PxDIR |= TI_LMP91200_LED_PIN;                                // Set pin direction is output
  
  TI_LMP91200_SPISetup();                                                      // Initilaize MSP430 SPI Block
  
  reg_write_data = TI_LMP91200_CONFIG_REG_RTD_VALUE;                           // Setup to measure RTD for 1mA & PGA 10 
  reg_read_data = TI_LMP91200_SPIWriteReg(reg_write_data);                     // Write again to read config register  
  reg_read_data = TI_LMP91200_SPIWriteReg(reg_write_data);                     // Write again to read config register
  // test if write/read values match
  if (reg_write_data != reg_read_data)
  {
   while (1)                                                                   // error: blink LED continuously
   {
     __delay_cycles(250000);
     TI_LMP91200_LED_PxOUT ^= TI_LMP91200_LED_PIN;        
   }      
  }
  TI_ADC14S626_SPISetup();                                                     // setup onboard ADS14S626 SPI interface
  timerA0_init();                                                              // initialize timerA0 for interrupt every 1sec                  
  __bis_SR_register(LPM0_bits + GIE);                                          // Enter LPM0, enable interrupts
  __no_operation();                                                            // For debugger 

} 
//------------------------------------------------------------------------------
//  void timerA0_init(void)
//
//  DESCRIPTION:
//  Initialize timer_A0 to generat 1sec interrupt.   
//  Note: This function is for MSP430F5528 & might need modifications for other MSP430s
//------------------------------------------------------------------------------
void timerA0_init(void)
{
        
  TA0CCTL0 = CCIE;                                                             // TA2CCR0 interrupt enabled
  TA0CCR0 = INTERVAL_1S;                                                       // Initialize for 1sec interval
  TA0EX0 = TAIDEX_7;                                                           // Divide clock (selected below) further by 8	
  TA0CTL = TASSEL_2 + MC_1 + TACLR + ID_3;                                     // SMCLK, upmode, clear TAR, divide by 8
    
}
//------------------------------------------------------------------------------
// Timer A0 interrupt service routine
// Note: This ISR is for MSP430F5528 & might need modifications for other MSP430s
//------------------------------------------------------------------------------
#pragma vector=TIMER0_A0_VECTOR
__interrupt void TIMER0_A0_ISR (void)
{
  uint8_t i;
  static uint16_t results[NUM_OF_RESULTS];                                     // To store ADC14 output
  static uint32_t sum_adc_data = 0;                                            // accumulate and avg adc results
  static float vout, pt_res_calc;                                              // voltage out and calculated resistance (PT100)
  volatile static float measured_temp;                                         // 1step measured temperature 
  
  for(i=0; i<8;i++)
  {
    results[i] = TI_ADC14S626_SPIReadReg();                                    // read and store ADC14 output
    sum_adc_data += results[i];                                                // accumulate result
    __delay_cycles(4);                                                         // acquisition time                             
  }
  sum_adc_data >>= SCALE_FACTOR;                                               // Average the accumulated sum
  vout = ADC14_RATIO * sum_adc_data;                                           // convert to voltage
  pt_res_calc = vout/(I_VALUE * PGA_GAIN);                                     // calcuated resistance: Eqn 2 Page 19 of LMP91200 DS
  measured_temp = (pt_res_calc - PT_RES_NOMINAL) / PT_TC;                      // LMP91200 DS pg 18 equation 1
  sum_adc_data = 0;                                                            // Set Breakpoint here & see measured temperature      
  
}  
//------------------------------------------------------------------------------
