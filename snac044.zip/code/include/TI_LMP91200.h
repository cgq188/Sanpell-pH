//----------------------------------------------------------------------------
//  Description:  This file contains definitions specific to the LMP91200.
//  All the LMP91200 registers are defined as well as some common masks
//  for these registers.
//
//  MSP430/LMP91200 Interface Code Library v1.0
//
//   Vishy Natarajan
//   Texas Instruments Inc.
//   March 2012
//   Built with CCE Version: 4.2 and IAR Embedded Workbench Version:  5.3x
//------------------------------------------------------------------------------
// Change Log:
//------------------------------------------------------------------------------
// Version:  1.00
// Comments: Initial Release Version
//------------------------------------------------------------------------------
#ifndef HEADER_FILE_TI_LMP91200_H

#define HEADER_FILE_TI_LMP91200_H

/************************************************************
* TI LMP91200 REGISTER SET ADDRESSES
************************************************************/

// Useful definitions
#define MEASURE_MODE_BIT                               (0x8000)
#define I_MUX_CAL_BIT                                  (0x4000)
#define PGA_BIT                                        (0x0800)
#define VOCM_BIT                                       (0x0080)
#define DIAG_EN_BIT                                    (0x0040)




#endif                                                                         // HEADER_FILE_TI_LMP91200_H

