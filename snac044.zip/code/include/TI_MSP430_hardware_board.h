//----------------------------------------------------------------------------
//  Description:  This file contains definitions specific to the hardware board.
//  Specifically, the definitions include hardware connections with the
//  ADS141S626 pins, chip select, and LED pins.
//
//  MSP430/LMP91200 Interface Code Library v1.0
//
//   Vishy Natarajan
//   Texas Instruments Inc.
//   March 2012
//   Built with CCE Version: 4.2 and IAR Embedded Workbench Version:  5.3x
//------------------------------------------------------------------------------
// Change Log:
//------------------------------------------------------------------------------
// Version:  1.00
// Comments: Initial Release Version
//------------------------------------------------------------------------------
#ifndef HEADER_FILE_TI_MSP430_HARDWARE_BOARD_H

#define HEADER_FILE_TI_MSP430_HARDWARE_BOARD_H

void TI_ADC14S626_SPISetup(void);
uint16_t TI_ADC14S626_SPIReadReg(void);

// LED Pin 
#define TI_LMP91200_LED_PxOUT                         P1OUT
#define TI_LMP91200_LED_PxDIR                         P1DIR
#define TI_LMP91200_LED_PIN                           BIT0

// Chip Select Pin 
#define TI_LMP91200_CSn_PxOUT                         P2OUT
#define TI_LMP91200_CSn_PxDIR                         P2DIR
#define TI_LMP91200_CSn_PIN                           BIT5

// F552x USCIB1 for ADC14S626 SPI Connection
#define TI_ADC14S626_SPI_USCIB1_SIMO_PxSEL            P4SEL
#define TI_ADC14S626_SPI_USCIB1_SOMI_PxSEL            P4SEL
#define TI_ADC14S626_SPI_USCIB1_UCLK_PxSEL            P4SEL
#define TI_ADC14S626_SPI_USCIB1_SIMO_PxDIR            P4DIR
#define TI_ADC14S626_SPI_USCIB1_UCLK_PxDIR            P4DIR
#define TI_ADC14S626_SPI_USCIB1_PxIN                  P4IN
#define TI_ADC14S626_SPI_USCIB1_SIMO                  BIT1
#define TI_ADC14S626_SPI_USCIB1_SOMI                  BIT2
#define TI_ADC14S626_SPI_USCIB1_UCLK                  BIT3

// GPIO Bit Bang (pins same as USCIB1) for ADC14S626 SPI Connection
#define TI_ADC14S626_SPI_BITBANG_SIMO_PxSEL           P4SEL
#define TI_ADC14S626_SPI_BITBANG_SOMI_PxSEL           P4SEL
#define TI_ADC14S626_SPI_BITBANG_UCLK_PxSEL           P4SEL

#define TI_ADC14S626_SPI_BITBANG_PxDIR                P4DIR
#define TI_ADC14S626_SPI_BITBANG_PxOUT                P4OUT
#define TI_ADC14S626_SPI_BITBANG_PxIN                 P4IN
#define TI_ADC14S626_SPI_BITBANG_SIMO                 BIT1
#define TI_ADC14S626_SPI_BITBANG_SOMI                 BIT2
#define TI_ADC14S626_SPI_BITBANG_UCLK                 BIT3

#define TI_ADC14S626_CSn_PxOUT                        P2OUT
#define TI_ADC14S626_CSn_PxDIR                        P2DIR
#define TI_ADC14S626_CSn_PIN                          BIT4

//----------------------------------------------------------------------------
// Select which port will be used for interface to LMP91200
//----------------------------------------------------------------------------
#define TI_LMP91200_SER_INTF            TI_LMP91200_SER_INTF_USCIA0_5xx      // 5xx, 6xx family USCIA0 SPI Interface to LMP91200
//#define TI_LMP91200_SER_INTF            TI_LMP91200_SER_INTF_USCIA1_5xx      // 5xx, 6xx family USCIA1 SPI Interface to LMP91200
//#define TI_LMP91200_SER_INTF            TI_LMP91200_SER_INTF_USCIA2_5xx      // 5xx, 6xx family USCIA2 SPI Interface to LMP91200
//#define TI_LMP91200_SER_INTF            TI_LMP91200_SER_INTF_USCIA3_5xx      // 5xx, 6xx family USCIA3 SPI Interface to LMP91200
//#define TI_LMP91200_SER_INTF            TI_LMP91200_SER_INTF_USCIB0_5xx      // 5xx, 6xx family USCIB0 SPI Interface to LMP91200
//#define TI_LMP91200_SER_INTF            TI_LMP91200_SER_INTF_USCIB1_5xx      // 5xx, 6xx family USCIB1 SPI Interface to LMP91200
//#define TI_LMP91200_SER_INTF            TI_LMP91200_SER_INTF_USCIB2_5xx      // 5xx, 6xx family USCIB2 SPI Interface to LMP91200
//#define TI_LMP91200_SER_INTF            TI_LMP91200_SER_INTF_USCIB3_5xx      // 5xx, 6xx family USCIB3 SPI Interface to LMP91200
//#define TI_LMP91200_SER_INTF            TI_LMP91200_SER_INTF_USART0          // USART0 SPI Interface to LMP91200
//#define TI_LMP91200_SER_INTF            TI_LMP91200_SER_INTF_USART1          // USART1 SPI Interface to LMP91200
//#define TI_LMP91200_SER_INTF            TI_LMP91200_SER_INTF_USCIA0          // 2xx, 4xx family USCIA0 SPI Interface to LMP91200
//#define TI_LMP91200_SER_INTF            TI_LMP91200_SER_INTF_USCIA1          // 2xx, 4xx family USCIA1 SPI Interface to LMP91200
//#define TI_LMP91200_SER_INTF            TI_LMP91200_SER_INTF_USCIB0          // 2xx, 4xx family USCIB0 SPI Interface to LMP91200
//#define TI_LMP91200_SER_INTF            TI_LMP91200_SER_INTF_USCIB1          // 2xx, 4xx family USCIB1 SPI Interface to LMP91200
//#define TI_LMP91200_SER_INTF            TI_LMP91200_SER_INTF_USI             // G2xx value seris SPI Interface to LMP91200
//#define TI_LMP91200_SER_INTF            TI_LMP91200_SER_INTF_BITBANG         // BITBANG SPI Interface to LMP91200

#endif                                                                         // HEADER_FILE_TI_MSP430_HARDWARE_BOARD_H