//------------------------------------------------------------------------------
//  Description:  Header file for TI_MSP430_spi_*.c
//
//  MSP430/LMP91200 Interface Code Library v1.1
//
//   Vishy Natarajan
//   Texas Instruments Inc.
//   March 2012
//   Built with CCE Version: 4.2 and IAR Embedded Workbench Version:  5.3x
//------------------------------------------------------------------------------
// Change Log:
//------------------------------------------------------------------------------
// Version:  1.00
// Comments: Initial Release Version
//------------------------------------------------------------------------------

#ifndef HEADER_FILE_TI_MSP430_SPI_H
#define HEADER_FILE_TI_MSP430_SPI_H

void TI_LMP91200_SPISetup(void);
uint16_t TI_LMP91200_SPIWriteReg(uint16_t);

#endif                                                                         // HEADER_FILE_TI_MSP430_SPI_H