Analog Devices Inc.
Design Support Package
CN-0359
03/05/2015
Rev. 0

This file is designed to provide you with a brief overview of what is contained within the circuit note design support package.

**********************
*******Overview*******
**********************

CN-0359 Design Support Package contains: 
	
	Link to Circuit Note
	Link to Product Datasheets
	Link to Product Evaluation Boards and User Guides
	PADs Schematics
	Bill of Materials
	PADs Layout Files
	Gerber Layout Files	
	Link to Technical Support
	Link to Other Resources


**********************
***File Explanation**
**********************


Circuit Note - Copy of the circuit note this design support package was made for.  This file is provided as a PDF:

	CN0359: http://www.analog.com/CN0359

Product Datasheets - Links to all ADI component datasheets used in the circuit.  These files are provided as a PDF:

	AD8253		http://www.analog.com/AD8253
	ADA4627-1	http://www.analog.com/ADA4627-1
	ADA4000-1	http://www.analog.com/ADA4000-1
	ADA4638-1	http://www.analog.com/ADA4638-1
	ADA4528-2	http://www.analog.com/ADA4528-2
	ADA4077-2	http://www.analog.com/ADA4077-2
	AD8592		http://www.analog.com/AD8592
	ADuCM360	http://www.analog.com/ADuCM350
	AD8542		http://www.analog.com/AD8542
	ADP2300		http://www.analog.com/ADP2300
	ADP1613		http://www.analog.com/ADP1613
	ADG1211		http://www.analog.com/ADG1211
	ADG1419		http://www.analog.com/ADG1419
	ADM3483		http://www.analog.com/ADM3483		

	

********************************************************
CN0359 	Evaluation Board:
	 
	http://www.analog.com/EVAL-CN0359-EB1Z


Schematic (PADS) for EVAL-CN0359-EB1Z:

	EVAL-CN0359-EB1Z-PADSSchematic-RevA.sch
	EVAL-CN0359-EB1Z-PADSSchematic-RevA.pdf


Assembly Drawing (PDF) for EVAL-CN0359-EB1Z:

	EVAL-CN0359-EB1Z-Assembly-RevA.pdf

	
Layout files (PADS) for EVAL-CN0359-EB1Z: 

	EVAL-CN0359-EB1Z-PADSLayout-RevA.pcb

Gerber files for EVAL-CN0359-EB1Z:

	EVAL-CN0359-EB1Z-GBR-RevA.zip


Bill of Materials for EVAL-CN0359-EB1Z:

	EVAL-CN0359-EB1Z-BOM-RevA.xls
	

Source Code for CN0359:

	CN0359-SourceCode-RevA.tar.xz   (open with 7-Zip)



Symbols and Footprints:

AD8253:
http://www.analog.com/en/design-center/packaging-quality-symbols-footprints/symbols-and-footprints/AD8253.html
		
ADA4627-1:
http://www.analog.com/en/design-center/packaging-quality-symbols-footprints/symbols-and-footprints/ADA4627-1.html
	
ADA4000-1:
http://www.analog.com/en/design-center/packaging-quality-symbols-footprints/symbols-and-footprints/ADA4000-1.html
	
ADA4638-1:
http://www.analog.com/en/design-center/packaging-quality-symbols-footprints/symbols-and-footprints/ADA4638-1.html
	
ADA4528-2:
http://www.analog.com/en/design-center/packaging-quality-symbols-footprints/symbols-and-footprints/ADA4528-2.html
	
ADA4077-2:
http://www.analog.com/en/design-center/packaging-quality-symbols-footprints/symbols-and-footprints/ADA4077-2.html
	
AD8592:
http://www.analog.com/en/design-center/packaging-quality-symbols-footprints/symbols-and-footprints/AD8592.html
		
ADuCM360:
http://www.analog.com/en/design-center/packaging-quality-symbols-footprints/symbols-and-footprints/ADUCM360.html
	
AD8542:
http://www.analog.com/en/design-center/packaging-quality-symbols-footprints/symbols-and-footprints/AD8542.html
	
ADP2300:
http://www.analog.com/en/design-center/packaging-quality-symbols-footprints/symbols-and-footprints/ADP2300.html

ADP1613:
http://www.analog.com/en/design-center/packaging-quality-symbols-footprints/symbols-and-footprints/ADP1613.html
	
ADG1211:
http://www.analog.com/en/design-center/packaging-quality-symbols-footprints/symbols-and-footprints/ADG1211.html
		
ADG1419:
http://www.analog.com/en/design-center/packaging-quality-symbols-footprints/symbols-and-footprints/ADG1419.html

		
ADM3483:
http://www.analog.com/en/design-center/packaging-quality-symbols-footprints/symbols-and-footprints/ADM3483.html

	
********************************************************


Technical Support -  If you require further technical assistance please contact us by phone, email, or our EngineerZone community.  http://www.analog.com/en/content/technical_support_page/fca.html


**********************
***Other Resources****
**********************

Resources that are not provided by Analog Devices, but could be helpful.

Gerber Viewer:  http://www.graphicode.com, http://www.viewplot.com, http://www.pentalogix.com/

PADs Viewer: http://www.mentor.com/products/pcb-system-design/design-flows/pads/pads-pcb-viewer

Keil Embedded Development Tools: http://www.keil.com/
