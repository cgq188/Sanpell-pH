/********************************************************************************
 Author             : CAST (China Applications Support Team) 

 Date               : 6-21-2011

 File name          : AD5421.h

 Description        : Using ADuC7026 to CONTROL AD5421 in software SPI form through GPIO.

 Hardware plateform : ADuC7026 + AD5421	
********************************************************************************/

#ifndef AD5421_H
#define AD5421_H
void WriteToAD5421ViaSpi(long int *RegisterData);
void ReadFromAD5421ViaSpi(unsigned short *RegisterData,long int RegAddress);
void AD5421_Initiate(void);
#define WR                        0x00
#define RD                       (0x01<<23)

#define DAC_REGISTER             (0x01<<16)
#define CONTROL_REGISTER         (0x01<<17)
#define OFFSET_ADJUST_REGISTER  ((0x01<<16) | (0x01<<17))
#define GAIN_ADJUST_REGISTER     (0x01<<18)
#define LOAD_DAC                ((0x01<<16) | (0x01<<18))
#define FORCE_ALARM_CURRENT     ((0x01<<17) | (0x01<<18))
#define RESET                   ((0x01<<16) | (0x01<<17) | (0x01<<18))
#define INI_VLOOP_TEMP_MEAS      (0x01<<19)
#define NOP                     ((0x01<<16) | (0x01<<19))
#define FAULT_REGISTER          ((0x01<<16) | (0x01<<18))

#define SPI_WATCHDOG_DISABLE     (0x01<<12)
#define FAULT_REG_OUT_DISABLE    (0x01<<11)
#define ALARM_SPI_FAULT          (0x01<<10)
#define SET_MINI_LOOP_CURRENT    (0x01<<9)
#define ADC_MEASURE_TEMPERATURE  (0x01<<8)
#define EN_ADC                   (0x01<<7)
#define POWER_DOWN_INTERNAL_REF  (0x01<<6)
#define VLOOOP_FAULT_ALERT_SET   (0x01<<5)


#endif 

