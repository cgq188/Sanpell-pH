/********************************************************************************
 Author              : CAST (China Applications Support Team) 

 Date                : 6-21-2011

 File name           : ADuC7026Driver.h

 Description         : Using ADuC7026 to control AD5421 in software SPI form through GPIO

 Hardware plateform  : ADuC7026 	+ AD5421
********************************************************************************/
#ifndef ADUC7026_DRIVER_H
#define ADUC7026_DRIVER_H
//-------------------------------------------------------------
//This file contains the common macro and function declarations
//-------------------------------------------------------------


//----------------------
//AD5421 pins configuration
//----------------------
#define AD5421_SDOUT		0x44	// P4.4->SDOUT
#define AD5421_SYNC  		0x46	// P4.6->CS
#define AD5421_SDIN 		0x43	// P4.3->SDIN
#define	AD5421_SCLK			0x23	// P2.3->SCLK
#define	AD5421_LDAC			0x47	// P4.1->LDAC



//----------------------
//External Function declarations
//----------------------
unsigned char ADuC7026_InputBit(unsigned char GPIONum);
void ADuC7026_OutputBit(unsigned char GPIONum, unsigned char Data);
void ADuC7026_Initiate(void);
void Delay(unsigned long int DelayTime);
void putchar(unsigned char);

#endif



