/********************************************************************************
 Author             : CAST (China Applications Support Team) 

 Date               : 6-21-2011

 File name          : AD5421.C

 Description        : Using ADuC7026 to CONTROL AD5421 in software SPI form through GPIO.

 Hardware plateform : ADuC7026 + AD5421	
********************************************************************************/
#include <ADuC7026.h>
#include "ADuC7026Driver.h"
#include "AD5421.h"


/********************************************************************************
Function that writes to the AD5421 via the SPI port.
********************************************************************************/

void AD5421_Initiate(void)
{
	ADuC7026_OutputBit(AD5421_SYNC,1);	//SYNC should be stay high for at lest 
	ADuC7026_OutputBit(AD5421_LDAC,1);
	Delay(5);
}	
void WriteToAD5421ViaSpi(long int *RegisterData)
{
	unsigned char i;
	long int TempData = 0;
	TempData = *RegisterData;
	
	ADuC7026_OutputBit(AD5421_SYNC, 0);
	for(i=0; i<24; i++)
	{	
		ADuC7026_OutputBit(AD5421_SCLK,1);
		
		if(0x800000 == (TempData & 0x800000))
		{
			ADuC7026_OutputBit(AD5421_SDIN,1);	  //Send one to DIN pin
		}
		else
		{
			ADuC7026_OutputBit(AD5421_SDIN,0);	  //Send zero to DIN pin
		}
		
		ADuC7026_OutputBit(AD5421_SCLK,0);
		
		TempData <<= 1;	//Rotate data
	}
	ADuC7026_OutputBit(AD5421_SYNC,1);	
	// Load DAC register only this way can work 
	ADuC7026_OutputBit(AD5421_LDAC,0);
	Delay(10);
	ADuC7026_OutputBit(AD5421_LDAC,1);
	Delay(5);

}

/********************************************************************************
Function that read from the AD5421 via the SPI port.
********************************************************************************/


void ReadFromAD5421ViaSpi(unsigned short *RegisterData,long int RegAddress)
{	
	long int cstr,putdata=0;
	long int tempdata = NOP;
	unsigned char i;

	cstr = RD | RegAddress;
	WriteToAD5421ViaSpi(&cstr);

	ADuC7026_OutputBit(AD5421_SYNC, 0);

	for(i=0; i<24; i++)
	{	
		
		ADuC7026_OutputBit(AD5421_SCLK,1);
		if(0x800000 == (tempdata & 0x800000))
		{
			ADuC7026_OutputBit(AD5421_SDIN,1);	  //Send one to DIN pin
		}
		else
		{
			ADuC7026_OutputBit(AD5421_SDIN,0);	  //Send zero to DIN pin
		}
		
		ADuC7026_OutputBit(AD5421_SCLK,0);
		tempdata<<= 1;	//Rotate data	
		putdata<<=1;
		
			 
		putdata |= ADuC7026_InputBit(AD5421_SDOUT);	
	}	   
	*RegisterData=putdata;

	ADuC7026_OutputBit(AD5421_SYNC, 1);	 
	Delay(10);

}
		



