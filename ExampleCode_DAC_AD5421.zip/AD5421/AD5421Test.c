/********************************************************************************
 Author             : CAST (China Applications Support Team) 

 Date               : 6-21-2011

 File name          : AD5421Test.C

 Description        : Using ADuC7026 to CONTROL AD5421 in software SPI form through GPIO.

 Hardware plateform : ADuC7026 + AD5421	
********************************************************************************/
#include <ADuC7026.h>
#include "ADuC7026Driver.h"
#include "AD5421.h"

/*------------------------------------------
 *	 CAUTION:
 *   You must power on the MCU before the AD5421.
 *   The internal SPI Watchdog of AD5421 is enable as in default, if
 *	 the AD5421 power on before the MCU, a spi-fault maybe occurs,
 *   the spi will be locked then. You can't change the locking state
 *   unless you power down the AD5421 for a while and power on it again, before that,
 *   the MCU must be running previously. In the following code,
 *   the spi-watchdog-bit of the control register is disabled.
 */

int main()
{
	
	long int cstr = 0;
	unsigned short RegisterData = 0;
	long int RegAddress;
	unsigned char rdata[2]={0,0};


	ADuC7026_Initiate();
	AD5421_Initiate();	  

 
	while(1)
	{ 	/*
    	 * To read back a register, Bit D11 of the control register must be set 
    	 * to Logic 1 to disable the automatic readback of the fault register. 
		 * In the meantime, you must disable the spi watchdog
		 */
 		cstr = WR | CONTROL_REGISTER  | 0x7800;	
		WriteToAD5421ViaSpi(&cstr);


    	/*
		 *  The output range is 4mA to 20mA, in this range it satisfied the function equation in datasheet(page 29),
		 *  and if you set the output, according to the function, lower than 4mA, it will stay at 4mA, or if you set
		 *  the output higher than 20mA, it will stay at 20mA. 
		 */
		
		cstr = WR | DAC_REGISTER | 0x8000; 	//output current = 12mA 	   
		WriteToAD5421ViaSpi(&cstr);	
   

		cstr = WR | OFFSET_ADJUST_REGISTER | 0x8000; 	//default value of the offset register
		WriteToAD5421ViaSpi(&cstr);	
	
		cstr = WR | GAIN_ADJUST_REGISTER | 0xFFFF; 		//default value of the gain register
		WriteToAD5421ViaSpi(&cstr);	  

		//readback the selected registers

		RegAddress =  CONTROL_REGISTER;
		ReadFromAD5421ViaSpi(&RegisterData,RegAddress);

		rdata[0]=(unsigned char)(RegisterData & 0x00FF);
		rdata[1]=(unsigned char)((RegisterData & 0xFF00)>>8);
		putchar(rdata[1]);
		putchar(rdata[0]);
		
		RegAddress =  DAC_REGISTER;
		ReadFromAD5421ViaSpi(&RegisterData,RegAddress);

		rdata[0]=(unsigned char)(RegisterData & 0x00FF);
		rdata[1]=(unsigned char)((RegisterData & 0xFF00)>>8);
		putchar(rdata[1]);
		putchar(rdata[0]);		

 		  
	}
	return 0;
}
