CN0349.GKO -- Board Outline
CN0349.GBL -- Bottom Copper 
CN0349.GBO -- Bottom Overlay 
CN0349.GBP -- Bottom Solderpaste 
CN0349.GBS -- Bottom Soldermask 
CN0349.GTL -- Top Copper 
CN0349.GTO -- Top Overlay 
CN0349.GTP -- Top Solderpaste 
CN0349.GTS -- Top Soldermask 

CN0349.TXT -- NC Drill File (2.4 Format)
CN0349.DRR -- Drill Report

CN0349_Drills.cam -- Exported Drills 
CN0349_Layers.cam -- Exported Layers