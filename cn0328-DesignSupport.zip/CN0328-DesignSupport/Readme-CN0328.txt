Analog Devices Inc.
Design Support Package
CN-0328
7/21/2014
Rev. 0


This file is designed to provide you with a brief overview of what is contained within the circuit note design support package.


**********************
*******Overview*******
**********************


CN-0328 Design Support Package contains: 
	
	Link to Circuit Note
	Link to Product Datasheets
	Link to Product Evaluation Boards and User Guides
	Cadence Schematics
	Bill of Materials
	Assembly Drawings
	Cadence Layout Files
	Gerber Layout Files	
	Link to Symbols and Footprints
	Link to Technical Support
	Link to Other Resources



**********************
***File Explanation**
**********************


Circuit Note - Copy of the circuit note this design support package was made for.  This file is provided as a PDF:

	CN0328: http://www.analog.com/CN0328


Product Datasheets - Links to all ADI component datasheets used in the circuit.  These files are provided as a PDF:

	AD5755-1: 	http://www.analog.com/AD5755-1
	AD5700-1: 	http://www.analog.com/AD5700-1
	ADG759:		http://www.analog.com/ADG759
	ADP1621:	http://www.analog.com/ADP1621
	ADuM3481:	http://www.analog.com/ADuM3481
	ADuM3482:	http://www.analog.com/ADuM3482
	ADum3210:	http://www.analog.com/ADuM3210
	ADR02:		http://www.analog.com/ADR02
	ADCMP356:	http://www.analog.com/ADCMP356


CN0328 	Evaluation Board:
	 
	EVAL-CN0328-SDPZ: http://www.analog.com/EVAL-CN0328-SDPZ



Bill of Materials for EVAL-CN0328-SDPZ:
	
	EVAL-CN0328-SDPZ-BOM-RevB.xls
	


Schematic Drawings (PADS) for EVAL-CN0328-SDPZ:


	EVAL-CN0328-SDPZ-PADSSchematic-RevB.pdf
	EVAL-CN0328-SDPZ-PADSSchematic-RevB.sch


Layout Drawings (PADS) for EVAL-CN0328-SDPZ:


	EVAL-CN0328-SDPZ-PADSLayout-RevB.pcb
	
		
Gerber Layout Files for EVAL-CN0328-SDPZ:


	EVAL-CN0328-EB1Z-GRB-RevB.zip



System Demonstration Platform (EVAL-SDP-CB1Z):

	http://www.analog.com/EVAL-SDP-CB1Z





Symbols and Footprints for ADI parts:

AD5755-1:
http://www.analog.com/en/digital-to-analog-converters/da-converters/ad5755-1/products/symbols-footprints.html


AD5700-1:
http://www.analog.com/en/interface-isolation/hart-modem/ad5700-1/products/symbols-footprints.html


ADG759:	
http://www.analog.com/en/switchesmultiplexers/multiplexers-muxes/adg759/products/symbols-footprints.html?location=Symbols

	
ADP1621:
http://www.analog.com/en/power-management/switching-controllers-external-switches/adp1621/products/symbols-footprints.html?location=Symbols

	
ADuM3481:
http://www.analog.com/en/interface-isolation/digital-isolators/adum3481/products/symbols-footprints.html?location=Symbols

	
ADuM3482:
http://www.analog.com/en/interface-isolation/digital-isolators/adum3482/products/symbols-footprints.html?location=Symbols

	
ADum3210:
http://www.analog.com/en/interface-isolation/digital-isolators/adum3210/products/symbols-footprints.html?location=Symbols

	
ADR02:	
http://www.analog.com/en/special-linear-functions/voltage-references/adr02/products/symbols-footprints.html?location=Symbols

	
ADCMP356:
http://www.analog.com/en/special-linear-functions/comparators/adcmp356/products/symbols-footprints.html?location=Symbols
	



http://www.analog.com/en/digital-to-analog-converters/da-converters/ad5420/products/symbols-footprints.html

AD5700:
http://www.analog.com/en/digital-to-analog-converters/da-converters/ad5700/products/symbols-footprints.html?location=Symbols

AD5700-1:
http://www.analog.com/en/interface-isolation/hart-modem/ad5700-1/products/symbols-footprints.html
	

Technical Support -  If you require further technical assistance please contact us by phone, email, or our EngineerZone community.  http://www.analog.com/en/content/technical_support_page/fca.html



**********************
***Other Resources****
**********************


Resources that are not provided by Analog Devices, but could be helpful.


Gerber Viewer:  http://www.graphicode.com

Cadence Viewer: http://www.mentor.com/products/pcb-system-design/design-flows/Cadence/Cadence-pcb-viewer

Allegro Physical Viewer: http://www.cadence.com/products/pcb/Pages/downloads.aspx


