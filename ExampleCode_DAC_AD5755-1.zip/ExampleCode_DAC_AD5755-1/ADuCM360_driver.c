
//***************************************************************************
//***************************************************************************
#include <ADuCM360.h>
#include	"ClkLib.h"
#include	"WdtLib.h"
#include  "UrtLib.h"

#include  "ADuCM360_driver.h"
//***************************************************************************
//declaration
//***************************************************************************
void	ADuCM360_Initialize(void);

void wdt_TurnOffWatchDogTimer(void);
void clk_TurnOffAllOptionClock(void);
void clk_SelectInternalOSC16M(void);
void clk_SelectInternalOSC32K(void);
void clk_SystemClockInit(void);
void clk_EnableSPI0Clock(void);
void clk_EnableSPI1Clock(void);
void clk_EnableI2CClock(void);
void clk_EnableUartClock(void);
void clk_EnablePWMClock(void);
void clk_EnableTimer0Clock(void);
void clk_EnableTimer1Clock(void);
void clk_EnableDACClock(void);
void clk_EnableDMAClock(void);
void clk_EnableADCClock(void);

void io_LedInit(void) ; 
void io_LedOn(void)  ;
void io_LedOff(void) ;
void io_OntimerLedBlink(void);

void uart_Init(void);
unsigned short UART_NumberToRead(void);
unsigned char UART_WRITEUART(unsigned char *pBuf, unsigned short len, unsigned short *pWriteLen);
unsigned char UART_READUART(unsigned char *pBuf, unsigned short len, unsigned short *pReadLen);

//***************************************************************************
void	ADuCM360_Initialize(void)
{
	clk_SystemClockInit();	
	uart_Init();		
	io_LedInit();		
}
//***************************************************************************
//CLK
//***************************************************************************
//---------------------------------------------------------------------------
// Turn off Watchdog timer
//---------------------------------------------------------------------------
void wdt_TurnOffWatchDogTimer(void)
{
	WdtCfg(T3CON_PRE_DIV1,T3CON_IRQ_EN,T3CON_PD_DIS);							
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
void clk_TurnOffAllOptionClock(void)
{
	pADI_CLKCTL->CLKDIS = 0x03ff;
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
void clk_SelectInternalOSC16M(void)
{
	ClkCfg(0, CLK_HF, 0 , 0);
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
void clk_SelectInternalOSC32K(void)
{
	ClkCfg(0, CLK_LF, 0 , 0);
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
void clk_SystemClockInit(void)
{
	wdt_TurnOffWatchDogTimer();
	clk_SelectInternalOSC16M();
	//pADI_CLKCTL->CLKCON1 = 0x0000;
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
void clk_EnableSPI0Clock(void)
{	
	pADI_CLKCTL->CLKDIS &=~ 0x0001;
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
void clk_EnableSPI1Clock(void)
{	
	pADI_CLKCTL->CLKDIS &=~ 0x0002;
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
void clk_EnableI2CClock(void)
{	
	pADI_CLKCTL->CLKDIS &=~ 0x0004;
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
void clk_EnableUartClock(void)
{	
	pADI_CLKCTL->CLKDIS &=~ 0x0008;
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
void clk_EnablePWMClock(void)
{	
	pADI_CLKCTL->CLKDIS &=~ 0x0010;
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
void clk_EnableTimer0Clock(void)
{	
	pADI_CLKCTL->CLKDIS &=~ 0x0020;
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
void clk_EnableTimer1Clock(void)
{	
	pADI_CLKCTL->CLKDIS &=~ 0x0040;
}
void clk_EnableDACClock(void)
{	
	pADI_CLKCTL->CLKDIS &=~ 0x0080;
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
void clk_EnableDMAClock(void)
{	
	pADI_CLKCTL->CLKDIS &=~ 0x0100;
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
void clk_EnableADCClock(void)
{	
	pADI_CLKCTL->CLKDIS &=~ 0x0200;
}
//***************************************************************************
//BSP LED
//***************************************************************************
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
void io_LedInit(void)  //led  p04  p05 p13
{
	//con
	pADI_GP0->GPCON |=  0x0000  << (4*2) ;
	pADI_GP0->GPCON |=  0x0000  << (5*2) ;
	
	pADI_GP1->GPCON |=  0x0000  << (3*2) ;
	//
	pADI_GP0->GPOEN |=  0x10;
	pADI_GP0->GPOEN |=  0x20;
	
	pADI_GP1->GPOEN |=  0x08;
	
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
void io_LedOn(void)  //led  p04  p05 p13
{	
	pADI_GP0->GPOUT |=  0x10;
	pADI_GP0->GPOUT |=  0x20;
	
	pADI_GP1->GPOUT |=  0x08;
	
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
void io_LedOff(void)  //led  p04  p05 p13
{
	pADI_GP0->GPOUT &=~  0x10;
	pADI_GP0->GPOUT &=~  0x20;
	
	pADI_GP1->GPOUT &=~  0x08;
	
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
void io_OntimerLedBlink(void)
{
	
	static unsigned char i=0;
	i++;
	if(i==0)
	{
		io_LedOn();
	}
	else if(i==20)
	{io_LedOff();
	}
	else if(i==40)
	{io_LedOn();}
	else if(i==60)
	{
		io_LedOff();
	}
}

//***************************************************************************
//UART At P1.1 P1.2
//***************************************************************************
#define BUF_LEN (128)

unsigned char Tx_buf[BUF_LEN]={0};
unsigned short Tx_wt=0;
unsigned short Tx_rd=0;
 
unsigned char Rx_buf[BUF_LEN]={0};
unsigned short Rx_wt=0;
unsigned short Rx_rd=0; 
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
void uart_Init(void)
{
	//clock
	clk_EnableUartClock();
	//
	pADI_CLKCTL->CLKCON1 &=~ (0x0e00) ; //??????????????
	//io function select
	pADI_GP0->GPCON |=  0x3c;	
	//
	UrtCfg(pADI_UART, B115200, COMLCR_WLS_8BITS,0);	
	//--------------------------------
	/*
	pADI_UART->COMCON = 0; 
	pADI_UART->COMLCR = COMLCR_WLS_8BITS + COMLCR_STOP;  // 8-data bits + 1 Stop bit. 
	pADI_UART->COMDIV = 0x11;  
	pADI_UART->COMFBR = COMFBR_ENABLE_EN + 0x1883;   // DIVM = 3, DIVN = 131. 
	*/
	//--------------------------------
	/*	
	*COMIEN_ERBFI to enable UART RX IRQ.
	*COMIEN_ETBEI to enable UART TX IRQ.
	*COMIEN_ELSI to enable UART Status IRQ.
	*COMIEN_EDSSI to enable UART Modem status IRQ.
	*COMIEN_EDMAT to enable UART DMA Tx IRQ.
	*COMIEN_EDMAR to enable UART DMA Rx IRQ.
	*/
	UrtIntCfg(pADI_UART , COMIEN_ERBFI|COMIEN_ETBEI |COMIEN_ELSI ); //0x07
	NVIC_EnableIRQ(UART_IRQn); 
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
unsigned short IndexInc(unsigned short raw, unsigned short delta)
{
	unsigned short temp=0;
	temp = raw+ delta; 
	if ( temp > (BUF_LEN -1)  ){temp= temp% BUF_LEN;}

	return temp;
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
unsigned short UART_NumberToRead(void)
{
	return (Rx_wt>= Rx_rd)? (Rx_wt- Rx_rd): (BUF_LEN+ Rx_wt- Rx_rd);
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
unsigned char UART_WRITEUART(unsigned char *pBuf, unsigned short len, unsigned short *pWriteLen)
{
	unsigned short i=0;
	if(len< BUF_LEN)
	{
		for(i=0;i<len;i++)
		{
			Tx_buf[Tx_wt]= *(pBuf+i);
			
			Tx_wt= IndexInc(Tx_wt ,1);	
			
		}	
	}
	//--------------------------------------------------
	pADI_UART->COMTX= Tx_buf[Tx_rd];
	Tx_rd= IndexInc(Tx_rd ,1);		
	//----------------------------------------------------
	return 1;
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
unsigned char UART_READUART(unsigned char *pBuf, unsigned short len, unsigned short *pReadLen)
{
	unsigned short i=0;
	unsigned short numberToRead= UART_NumberToRead();
	if(numberToRead!=0)
	{			
				if(len > 	numberToRead ) {len =	numberToRead;}
				for(i=0;i<len;i++)
				{
					 *(pBuf+i)= Rx_buf[Rx_rd];
						Rx_rd= IndexInc(Rx_rd ,1);				
				}				
	}			
	return 1;
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
void UART_Int_Handler (void)
{
	unsigned char comiir=0;
	comiir=  ( pADI_UART->COMIIR) & 0x07;
	//start of switch
	switch(comiir)
	{
		case 0x00: //modem status  READ COMMSR
			break;
		case 0x02: //tx empty			
			if(! (Tx_wt== Tx_rd) )
			{
				pADI_UART->COMTX= Tx_buf[Tx_rd];
				Tx_rd= IndexInc(Tx_rd ,1);		
			}			
			break;
		case 0x04:  //rx empty		READ COMRX			
			Rx_buf[Rx_wt]= pADI_UART->COMRX ;		
			Rx_wt= IndexInc(Rx_wt ,1);			
			break;
		
		case 0x06:   //line status  READ COMLSR
			break;
		default :break;
	}
	//end of switch
	
}

//***************************************************************************
//***************************************************************************
//***************************************************************************
//***************************************************************************
