
#define REG_DAC_DATA    (0)
#define REG_GAIN        (2)
#define REG_GAIN_ALL    (3)
#define REG_OFFSET      (4)
#define REG_OFFSET_ALL  (5)
#define REG_CLEAR_CODE  (6)
#define REG_CONTROL     (7)

#define DACA      (0)
#define DACB      (1)
#define DACC      (2)
#define DACD      (3)

#define REG_SLOWRATE_CONTROL    (0<<13)
#define REG_MAIN_CONTROL        (1<<13)
#define REG_DAC_CONTROL         (2<<13)
#define REG_DCDC_CONTROL        (3<<13)
#define REG_SOFTWARE            (4<<13)


#define POC                (1<<12)
#define STARTREAD          (1<<11)
#define ENABLE_WATCHDOG    (1<<10)
#define WATCHDOG_5MS        (0<<8)
#define WATCHDOG_10MS       (1<<8)
#define WATCHDOG_100MS      (2<<8)
#define WATCHDOG_200MS      (3<<8)
#define SHORT_CIRCIUT_16MA   (0<<6)
#define SHORT_CIRCIUT_8MA    (1<<6)
#define OUTEN_ALL           (1<<5)
#define DCDC_ALL            (1<<4)

#define INT_ENABLE                (1<<8)
#define CLR_EN                    (1<<7)
#define OUT_EN                    (1<<6)
#define RSET                      (1<<5)
#define DCDC                      (1<<4)
#define OVERRANGE                 (1<<3)

#define RANGE_5V                     (0)
#define RANGE_10V                    (1)
#define RANGE_DOUBLE5V               (2)
#define RANGE_DOUBLE10V              (3)
#define RANGE_4_20MA                 (4)
#define RANGE_0_20MA                 (5)
#define RANGE_0_24MA                 (6)

#define RESET_CODE                   (0x555)
#define SPI_WATCHDOG_CODE            (0x195)

#define DC_DC_COMP                   (1<<6)

#define DC_DC_PHASE                  (1<<4)

#define DC_DC_250K                  (0<<2)
#define DC_DC_410K                  (1<<2)
#define DC_DC_650K                  (2<<2)

#define DC_DC_23V                     (0)
#define DC_DC_24V5                    (1)
#define DC_DC_27V                     (2)
#define DC_DC_29V5                    (3)

#define READ_STATUS_COMMAND             (0x980000)
#define NO_OP_COMMAND                   (0x1CE000)


#define READ_DACA_DATA				(0)
#define READ_DACB_DATA				(1)
#define READ_DACC_DATA				(2)
#define READ_DACD_DATA				(3)

#define READ_DACA_CONTROL					(4)
#define READ_DACB_CONTROL					(5)
#define READ_DACC_CONTROL					(6)
#define READ_DACD_CONTROL					(7)

#define READ_DACA_GAIN			(8)
#define READ_DACB_GAIN			(9)
#define READ_DACC_GAIN			(10)
#define READ_DACD_GAIN			(11)

#define READ_DACA_OFFSET			(12)
#define READ_DACB_OFFSET			(13)
#define READ_DACC_OFFSET			(14)
#define READ_DACD_OFFSET			(15)

#define READ_DACA_CODE			(16)
#define READ_DACB_CODE			(17)
#define READ_DACC_CODE			(18)
#define READ_DACD_CODE			(19)

#define READ_DACA_SLEWRATE			(20)
#define READ_DACB_SLEWRATE			(21)
#define READ_DACC_SLEWRATE			(22)
#define READ_DACD_SLEWRATE			(23)

#define READ_STATUS							(24)
#define READ_MAIN_CONTROL				(25)
#define READ_DCDC								(26)

typedef struct st_AD5755_1_sendPackage
{
    unsigned char deviceAddr;
    unsigned char RegAddr;
    unsigned char dacNum;
    unsigned short data;
}AD5755_1_sendPackage;

typedef struct st_AD5755_1_ReadBackPackage
{
	unsigned char deviceAddr;
  unsigned char RegAddr;  
}AD5755_1_ReadBackPackage;


void AD5755_1_IO_Initialize(void);
AD5755_1_sendPackage MakeAPkg( unsigned char deviceAddr,
    unsigned char RegAddr,
    unsigned char dacNum,
    unsigned short data);
unsigned int SPI_Tx_24bit(unsigned int sendData);
void AD5755_1_SendCommand(AD5755_1_sendPackage pkg);
unsigned int  AD5755_1_RecieveCommand(unsigned char deviceAddr,unsigned short RegAddr);
