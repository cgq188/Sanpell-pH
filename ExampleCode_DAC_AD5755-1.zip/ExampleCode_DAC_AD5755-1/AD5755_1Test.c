
#include <ADuCM360.h>
#include "ADuCM360_driver.h"
#include "AD5755_1.h"
//***************************************************************************
//declaration
unsigned short res16=0x0000;
unsigned short* pWrite=0;
unsigned char runFlag=0;

//***************************************************************************
//sysTimer interrupt
//***************************************************************************
void SysTick_Handler (void)
{
	static unsigned long cnt=0;	
	io_OntimerLedBlink();	
	if(cnt==2)
  {
		cnt=0;
		runFlag=1;	
	}
	else
	{	cnt++;}	
}
//***************************************************************************
//main
//***************************************************************************
int main()
{	
	ADuCM360_Initialize();
	AD5755_1_IO_Initialize();	
	
	AD5755_1_SendCommand(MakeAPkg(0,REG_CONTROL,0,0|REG_SOFTWARE|0x555));
	
	AD5755_1_SendCommand(MakeAPkg(0,REG_CONTROL,0,0|REG_DCDC_CONTROL|0x4));
	//select range form
	//RANGE_5V                    
	//RANGE_10V                    
	//RANGE_DOUBLE5V               
	//RANGE_DOUBLE10V              
	//RANGE_4_20MA                 
	//RANGE_0_20MA                 
	//RANGE_0_24MA                 
	AD5755_1_SendCommand(MakeAPkg(0,REG_CONTROL,DACA,0|REG_DAC_CONTROL|INT_ENABLE|DCDC|RANGE_DOUBLE5V));
	AD5755_1_SendCommand(MakeAPkg(0,REG_CONTROL,DACB,0|REG_DAC_CONTROL|INT_ENABLE|DCDC|RANGE_DOUBLE5V));
	AD5755_1_SendCommand(MakeAPkg(0,REG_CONTROL,DACC,0|REG_DAC_CONTROL|INT_ENABLE|DCDC|RANGE_DOUBLE5V));
	AD5755_1_SendCommand(MakeAPkg(0,REG_CONTROL,DACD,0|REG_DAC_CONTROL|INT_ENABLE|DCDC|RANGE_DOUBLE5V));
		
	AD5755_1_SendCommand(MakeAPkg(0,REG_GAIN_ALL,0,0xFFFF));	//gain 2^16-1
	AD5755_1_SendCommand(MakeAPkg(0,REG_OFFSET_ALL,0,0x8000));//offset 2^15
	
	AD5755_1_SendCommand(MakeAPkg(0,REG_DAC_DATA,DACA,0xFFFF));
	AD5755_1_SendCommand(MakeAPkg(0,REG_DAC_DATA,DACB,0xFFFF>>1));
	AD5755_1_SendCommand(MakeAPkg(0,REG_DAC_DATA,DACC,0xFFFF>>2));
	AD5755_1_SendCommand(MakeAPkg(0,REG_DAC_DATA,DACD,0xFFFF>>3));
	
	AD5755_1_SendCommand(MakeAPkg(0,REG_CONTROL,DACA,0|REG_DAC_CONTROL|INT_ENABLE|DCDC|OUT_EN|RANGE_DOUBLE5V));
	AD5755_1_SendCommand(MakeAPkg(0,REG_CONTROL,DACB,0|REG_DAC_CONTROL|INT_ENABLE|DCDC|OUT_EN|RANGE_DOUBLE5V));
	AD5755_1_SendCommand(MakeAPkg(0,REG_CONTROL,DACC,0|REG_DAC_CONTROL|INT_ENABLE|DCDC|OUT_EN|RANGE_DOUBLE5V));
	AD5755_1_SendCommand(MakeAPkg(0,REG_CONTROL,DACD,0|REG_DAC_CONTROL|INT_ENABLE|DCDC|OUT_EN|RANGE_DOUBLE5V));
	
	//start sysTimer  
	//200Hz
	SysTick_Config(16000000/ 200);
	
	while(1)
	{
		if(runFlag==1)
		{
			  runFlag=0;			
				
				
	  }
	}
	
}
