#include <ADuCM360.h>
#include "AD5755_1.h"
//***************************************************************************
//define
//***************************************************************************
#define SYNC_HIGH			pADI_GP1->GPOUT |= 0x80 ;
#define SYNC_LOW			pADI_GP1->GPOUT &=~ 0x80 ;

#define SCLK_HIGH			pADI_GP1->GPOUT |= 0x20 ;
#define SCLK_LOW			pADI_GP1->GPOUT &=~ 0x20 ;

#define SDIN_HIGH			pADI_GP1->GPOUT |= 0x40;
#define SDIN_LOW			pADI_GP1->GPOUT &=~ 0x40;

#define LDAC_HIGH			pADI_GP0->GPOUT |= 0x80;
#define LDAC_LOW			pADI_GP0->GPOUT &= ~0x80;

#define SDO     				((pADI_GP1->GPIN &0x10 ) ==0x10) ? 1 :0;
#define NOP_NUMBER			(50)
//***************************************************************************
//declaration
//***************************************************************************
void AD5755_1_IO_Initialize(void);
AD5755_1_sendPackage MakeAPkg( unsigned char deviceAddr,
    unsigned char RegAddr,
    unsigned char dacNum,
    unsigned short data);
unsigned int SPI_Tx_24bit(unsigned int sendData);
void AD5755_1_SendCommand(AD5755_1_sendPackage pkg);
unsigned int  AD5755_1_RecieveCommand(unsigned char deviceAddr,unsigned short RegAddr);

void SPI_nop(unsigned long cnt);
//***************************************************************************
//***************************************************************************
void AD5755_1_IO_Initialize(void)
{
	pADI_GP1->GPOEN |=  0xE0;
	
	pADI_GP0->GPCON |= 0x4000; //p0.7??POR ???GPIO	
	pADI_GP0->GPOEN |= 0x80;	
	
	SYNC_LOW;	
	SCLK_LOW;
	SDIN_LOW;
	LDAC_LOW;
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
AD5755_1_sendPackage MakeAPkg( unsigned char deviceAddr,
    unsigned char RegAddr,
    unsigned char dacNum,
    unsigned short data)
{
		AD5755_1_sendPackage sendPkg;
	
		sendPkg.deviceAddr=deviceAddr;
    sendPkg.RegAddr=RegAddr;
    sendPkg.dacNum=dacNum;
    sendPkg.data=data ;
	
		/*sendPkg.deviceAddr=0;
    sendPkg.RegAddr=REG_CONTROL;
    sendPkg.dacNum=0;
    sendPkg.data=0|REG_DAC_CONTROL|INT_ENABLE|DCDC ;

    sendPkg.deviceAddr=0;
    sendPkg.RegAddr=REG_DAC_DATA;
    sendPkg.dacNum=0;
    sendPkg.data=0|0x0000 ;

    sendPkg.deviceAddr=0;
    sendPkg.RegAddr=REG_CONTROL;
    sendPkg.dacNum=0;
    sendPkg.data=0|REG_DAC_CONTROL|INT_ENABLE|DCDC|OUT_EN ;*/
	
		return sendPkg;
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
void SPI_nop(unsigned long cnt)
{
    unsigned long i=0;
    for(i=0;i<cnt;i++)
    {
        __NOP();
    }
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
unsigned int SPI_Tx_24bit(unsigned int sendData)
{
     unsigned char i=0;
     unsigned char temp= 0x0000;
     unsigned int res= 0x0;

     SPI_nop(NOP_NUMBER);
     SYNC_LOW;
     SCLK_HIGH;
     SPI_nop(NOP_NUMBER);

     for(i=0;i<24;i++)
     {
       SCLK_HIGH;
       if( (sendData & (1<< (23-i))) == (1<< (23-i)))
       {SDIN_HIGH;}
       else	 {SDIN_LOW;}
       SPI_nop(NOP_NUMBER);

       SCLK_LOW;

       temp=SDO;
       res |= (temp <<(23-i) );

       SPI_nop(NOP_NUMBER);
     }

     SPI_nop(NOP_NUMBER);
     SYNC_HIGH;

     return res;
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
void AD5755_1_SendCommand(AD5755_1_sendPackage pkg)
{
    SPI_Tx_24bit((pkg.deviceAddr<<21) |
            (pkg.RegAddr<<18)  |
            (pkg.dacNum<<16)   |
            (pkg.data));
}

//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
unsigned int  AD5755_1_RecieveCommand(unsigned char deviceAddr,unsigned short RegAddr)
{
    unsigned int res=0;
		SPI_Tx_24bit(0x800000|(deviceAddr<<21)|(RegAddr<<16) );
    res= SPI_Tx_24bit(NO_OP_COMMAND);
    return res;
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------

