void	ADuCM360_Initialize(void);
unsigned char UART_WRITEUART(unsigned char *pBuf, unsigned short len, unsigned short *pWriteLen);
unsigned char UART_READUART(unsigned char *pBuf, unsigned short len, unsigned short *pReadLen);
void io_OntimerLedBlink(void);
