/**
 *****************************************************************************
   @addtogroup EC sensor
   @{
   @file     M355_CN0428.h
   @brief    CN0428 Water Quality Main Program.
   @version  V0.1
   @author   ADI
   @date     June 2018
   @par Revision History:
   - V0.1, June 2018: initial version.


All files provided by ADI, including this file, are
provided  as is without warranty of any kind, either expressed or implied.
The user assumes any and all risk from the use of this code.
It is the responsibility of the person integrating this code into an application
to ensure that the resulting application performs as required and is safe.

**/

#ifndef M355_CN0428_H_
#define M355_CN0428_H_

#ifdef __cplusplus
extern "C" {
#endif

//#include "ADuCM355_Peri.h"
#include <stdio.h>

/*  Other misc constants  */
#define Faraday 96485 /*Faraday constant*/
#define Ideal_gas_const_R 8.314 /*Ideal gas constant*/

#define _CR			13	/* <ENTER> */
#define _LF			10	/* <New line> */
#define _SPC			32	/* <Space> */
#define _BS			8	/* <Backspace> */

/*=========================== Function declarations ====================*/
void GPIOInit(void);
void ClockInit(void);
void UartInit(void);
void SPISlaveSetup(void);
void I2CInit(uint8_t address);
void AfeAdc_Int_Handler();
void GPIO_A_Int_Handler();

#ifdef __cplusplus
}
#endif

#endif // #define M355_CN0428_H_
