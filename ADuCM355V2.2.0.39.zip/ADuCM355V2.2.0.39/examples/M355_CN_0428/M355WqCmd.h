/**
 *****************************************************************************
   @addtogroup EC sensor
   @{
   @file     M355WqCmd.h
   @brief    Command Line Interface for Water Quality Demo
   @par Revision History:
   @version  V0.1
   @author   ADI
   @date     June 2018
   @par Revision History:
   - V0.1, June 2018: initial version
   Decription:
     Command line interpreter for CN0428. Based largely on CN0326 pH demo.

All files for ADuCM355 provided by ADI, including this file, are
provided  as is without warranty of any kind, either expressed or implied.
The user assumes any and all risk from the use of this code.
It is the responsibility of the person integrating this code into an application
to ensure that the resulting application performs as required and is safe.

**/

#ifndef M355WQCMD_H_
#define M355WQCMD_H_


#ifdef __cplusplus
extern "C" {
#endif

#include "ADuCM355_Peri.h"
#include "stdio.h"


/****************************** Internal types ********************************/

typedef  void (*cmdFunc)(uint8_t *);

/*************************** Functions prototypes *****************************/

void Wq_Init(void);
void Wq_Interrupt(void);
float Wq_CalculateTemp(void);
float Wq_CalculatePH(float temp);
void Wq_CmdHelp(uint8_t *args);
void Wq_CmdTemp(uint8_t *args);
void Wq_CmdPH(uint8_t *args);
void DoNothing(uint8_t *args);
void Wq_CmdCalibration(uint8_t *args);
void Wq_CmdReset(uint8_t *args);
cmdFunc Wq_FindCommand(char *cmd);
void Wq_CmdProcess(void);
void Wq_CmdPrompt(void);
uint8_t *Wq_FindArgv(uint8_t *args);
void Wq_GetArgv(char *dst, uint8_t *args);
void ChangeSnsType(uint8_t *args); /*type ph, conductivity*/
void ChangeDevType(uint8_t dev_type);
void MeasureParameter(uint8_t *args); /*pH, conductivity, temperature*/
void MeasureEIS(uint8_t *args);
void PrintSnsHealth(uint8_t *args);
void PrintTemp(uint8_t *args);
void PrintConfig(uint8_t *args);
void EnableTemp(uint8_t *args);
void EnableHiZMode(uint8_t *args);
void HiZModeSet(uint8_t hiz_en);
void SetMinEISFreq(uint8_t *args);
void SetMaxEISFreq(uint8_t *args);
void RenameSns(uint8_t *args);
void PrintSerialNum(uint8_t *args);
void EnableBoard(uint8_t *args);
void SetI2CAddr(uint8_t newaddr);

float Wq_TempGet();
float Wq_TempResGet();
float Wq_CondGet();
float Wq_PHGet();
float Wq_PHVoltGet();
float Wq_ORPGet();
float Wq_ORPVoltGet();
float Wq_Resistivity();

/****************************** Internal defines ******************************/

#define UID_BASE 0x40070	/* 16 bytes @ 0x40770 - 0x4077F Unique ID */
#define BOARD_ID_PTR 	((unsigned int *) UID_BASE)	// Pointer to UID_BASE in 4 byte chunks, not volatile bc it's read only

/*! Default I2C address  (may be overriden if agreed with master) */
#define ADI_CFG_I2C_DEFAULT_ADDR (0x4Cu)
#define ADI_CFG_I2C_DEFAULT_ADDR_SHIFTED (ADI_CFG_I2C_DEFAULT_ADDR << 1)

///* Other constants for communication functions */
//#define I2C_SLAVE_TX_BYTES_MAX		3
//#define I2C_MASTER_RX_BYTES_MAX		3
//
//// SPI
//#define SPI_SLAVE_TX_BYTES_MAX		3
//#define SPI_MASTER_RX_BYTES_MAX		3

// I2C commands
#define	GET_STATUS			0x02
#define BYTES_TO_READ			0x61
#define SET_I2C_ADDRESS			0x80

#define BUF_SIZE			4096u

typedef enum {
	NOT_READY	= 0x00,
	READY		= 0x03,
	BUSY		= 0x04
} SLAVE_STATUS;

#define YES	1
#define NO	2

/* [Ω/Ω/˚C] - defined by the standard => check the documentation */
#define TEMP_COEFF		0.00385
/* [Coulombs/mol] -  Faraday constant */
#define FARADAY_CONST		96485
/* Constant value used in Nernst formula for pH calculation */
#define PH_CONST		2.303
/* With [mV-Coulombs/˚K] - Ideal Gas Constant R */
#define IDEAL_GAS_CONST_R	8.314
/* [˚K] - Kelvin degrees for 0˚C */
#define K_DEGREES		273.15


#define _CR			13	/* <ENTER> */
#define _LF			10	/* <New line> */
#define _SPC			32	/* <Space> */
#define _BS			8	/* <Backspace> */

/******************** Variables for use in other functions ********************/
extern unsigned char ucPacketReceived; //needed in main
extern unsigned char szTemp[];
extern volatile unsigned char* pTxWrite;
extern volatile unsigned char* pTxSend;

#ifdef __cplusplus
}
#endif

#endif /* M355WQCMD_H_ */
