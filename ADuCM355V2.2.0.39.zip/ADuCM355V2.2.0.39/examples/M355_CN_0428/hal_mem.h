/*
 * 文件名:hal_mem.h
 *
 * 创建日期:2016年1月11日
 * 作者:Jay Lau
 * 描述:
 */

#ifndef SRC_APP_HAL_MEM_H_
#define SRC_APP_HAL_MEM_H_

#include "stdbool.h"
#include "assert.h"
#include "stdint.h"

#define CFGINFO_START_ADDR		(124*1024)
#define CFGINFO_END_ADDR		(128*1024-1)
#define FLA_PAGE_SIZE			(2048)


#define DEV_TYPE_COND 		2
#define DEV_TYPE_ORP		1
#define DEV_TYPE_PH			0



#define TEMP_SENSOR_TYPE_PT1000 		0
#define TEMP_SENSOR_TYPE_NTC30K			1
#define TEMP_SENSOR_TYPE_MANUAL  		2
#define TEMP_SENSOR_TYPE_PT100    		3



typedef struct{

	float conductivity ;
	float resistivity ;
	float temperature ;
	float tempSensorRes   ;

	float condSetupTime ;
	float condHoldTime ;
	float condTempCoef ;
	float condCellConstant ;
	float condExcitVolt ;
	float condExcitFreq ;

	float condResOffset ;

	uint32_t baudRate ;
	uint32_t rs485Addr ;
	uint32_t fwVersion ;
	uint16_t tempSensorType ;
	uint16_t dummy_12;


	float tempReviseCoef ;
	float tempManualVal  ;
	float tempOffset;




	float orpOffset;



	uint16_t phCalMode ;
	uint16_t phNistMode ;

	float ph_val1    ;
	float ph_volt1   ;
	float ph_temp1   ;

	float ph_val2    ;
	float ph_volt2   ;
	float ph_temp2   ;

	float ph_val3    ;
	float ph_volt3   ;
	float ph_temp3   ;

	float phOffset   ;



	float compGain40K ;
	float compGain80K ;
	float compGain160K ;
	float compGain1M ;

	float compOffset40K ;
	float compOffset80K ;
	float compOffset160K ;
	float compOffset1M ;


	//address is 50（0x32）
	uint16_t devType  ;
	uint16_t hizMode   ;
	uint32_t devSN ;

	uint8_t  cs;
	uint8_t  cs_dummy[3];
}cfgInfo_t;

typedef struct
{
	cfgInfo_t				cfgActive;
	uint8_t dummy1[FLA_PAGE_SIZE-sizeof(cfgInfo_t)%FLA_PAGE_SIZE];

	cfgInfo_t				cfgCopy;
	uint8_t dummy2[FLA_PAGE_SIZE-sizeof(cfgInfo_t)%FLA_PAGE_SIZE];
}FLAMem_t;


void HAL_MEM_Init();
bool HAL_MEM_WriteEEP(uint32_t addr,uint8_t* data,uint16_t length);



bool cfgInfo_reset();
bool cfgInfo_init();
bool getValidIdx(cfgInfo_t **idx);
bool cfgInfo_write(cfgInfo_t * idx);
bool cfgInfo_get(cfgInfo_t  *idx);


uint8_t calculate_sum(uint8_t* data,uint16_t length);








#endif /* SRC_APP_HAL_MEM_H_ */



















