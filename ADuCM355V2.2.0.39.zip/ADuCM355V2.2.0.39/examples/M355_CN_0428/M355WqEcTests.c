/**
 *****************************************************************************
   @addtogroup EC sensor
   @{
   @file     M355WqEcTests.c
   @brief    Set of Electrochemical sensor functions.
   @par Revision History:
   @version  V0.1
   @author   ADI
   @date     June 2018
   @par Revision History:
   - V0.1, June 2018: initial version.

   Contains EIS and DC measurements for Water Quality (CN0428)
All files for ADuCM355 provided by ADI, including this file, are
provided  as is without warranty of any kind, either expressed or implied.
The user assumes any and all risk from the use of this code.
It is the responsibility of the person integrating this code into an application
to ensure that the resulting application performs as required and is safe.

**/
#include "M355WqConfig.h"
#include "M355WqEcTests.h"

#include "hal_mem.h"

volatile uint8_t dftRdy = 0;
volatile uint8_t adcRdy = 0;
volatile uint8_t sinc2Rdy = 0;
volatile uint8_t adcSat = 0;
volatile uint32_t ucButtonPress = 0;
uint8_t uiHpRtiaSeIndex; /* Refers to values in hprtiase_ohm, *szValHpRtiaSe, and uiHpRtiaSe */
uint8_t uiGnPgaIndex; /* Refers to values in uiValGnPga_x2, *szValGnPga, and uiGnPga */
uint8_t uiRcalIndex = 0; /* Refers to uiValRcal, *szVa;Rca; */
uint8_t flagHiZMode = HI_Z_MODE;
uint8_t disableTiaAutorange = 0; /* Set in SnsAcInit() to prevent HiZMode autoranging. Other uses possible. */
uint8_t disablePgaAutorange = 0; /* Set in SnsAcInit(). Currently used to prevent HiZMode. */
/* Maximum allowed TIA gain. Set to 8 at the beginning of measureimpedance, decrease if ADCMAX/ADCMIN interrupt */
volatile uint8_t uiMaxGainRangeIndex;
/* Maximum allowed PGA gain. Set to 4 at the beginning of measureimpedance, decrease if ADCMAX/ADCMIN interrupt */
volatile uint8_t uiMaxPgaGainIndex;
/* HP Rtia Values available */
const char *szValHpRtiaSe[] = { "200", "1k", "5k", "10k", "20k", "40k", "80k", "160k", "1Meg"};
const HPTIASE_RTIA_Type uiHpRtiaSe[] = {HPTIASE_RTIA_200,HPTIASE_RTIA_1K,HPTIASE_RTIA_5K,HPTIASE_RTIA_10K,HPTIASE_RTIA_20K, \
                     HPTIASE_RTIA_40K,HPTIASE_RTIA_80K,HPTIASE_RTIA_160K,HPTIASE_RTIA_OPEN};//register values for HSRTIACON:RTIACON
/* Rcal Values Available */
const uint32_t uiValRcal[] = { 200, 2000, 25500, 200000, 1000000 };
const char *szValRcal[] = { "200", "2k", "25.5k", "200k", "1Meg" };
const char *szSnsStatus[] = { "Normal", "Broken/short", "Dry/Clogged", "Dirty", "Unknown" };
const char *szSnsType[] = { "pH", "Conductivity", "ORP", "ISE", "DO" };
const char *szTempSnsType[] = { "None", "NTC Thermistor", "RTD" };
SNS_CFG_Type * pSnsCfg0;
SNS_CFG_Type * pSnsCfg1;
/* To extend ULPTIA_SWMODE_TypeDef options as needed in this file */
	/* Same as SWMODE_NORM, but with SW10 to short CE and RE */
const uint16_t SWMODE_NORM_CE_RE_SHORT = 0x342C;
	/* pH sensors indicating electrode should be floating b/w measurements */
const uint16_t SWMODE_OPEN_RE = 0x3120;


SNS_CFG_Type SnsCfg[2] = {
	/*Sensor Channel 0*/
	{
		SENSOR_CHANNEL_ENABLE,
		CHAN0,
		1100u,
		1100u,
		LPTIA_RLOAD_0,
		LPTIA_RGAIN_1K,
		LPTIA_RFILTER_1M,
		DEFAULT_SENSOR,
		Unknown,
		8,
		0,
		MIN_FREQ_DEFAULT,
		MAX_FREQ_DEFAULT,
		"Sensor 1"
	},
	/*Sensor Channel 1, used as a dedicated temperature channel*/
	{
		TEMP_SENSOR_INCLUDED,
		CHAN1,
		1100u,
		1100u,		/* actual vbias-vzero is determined by offset of channel 0 */
		LPTIA_RLOAD_0,		/* unused */
		LPTIA_RGAIN_1K,		/* unused */
		LPTIA_RFILTER_1M,	/* unused */
		(SnsType)TEMPSENSORTYPE,
		Normal,
		7,
		0,
		MIN_FREQ_DEFAULT,
		MAX_FREQ_DEFAULT,
		"Temp Sensor 1"
	}
};

ImpResult_t TempResult[] = {
	{1005,{0,0,0,0},0,0},
};

size_t TempResultArrSize = sizeof(TempResult)/sizeof(ImpResult_t);

ImpResult_t CondResult[] = {
	{100,{0,0,0,0},0,0},
};

size_t CondResultArrSize = sizeof(CondResult)/sizeof(ImpResult_t);

ImpResult_t SingleFrequencyZResult[] = {
	{1050,{0,0,0,0},0,0},
};

size_t SingleFrequencyZResultArrSize = sizeof(SingleFrequencyZResult)/sizeof(
		ImpResult_t);

#ifndef PH_CAL_POINTS
#define PH_CAL_POINTS 0
#endif /* PH_CAL_POINTS */

/* Set probe defaults based on values in config file */
pH_probe_t myPhProbe = {
	PH_ISO, 			/* pH_iso */
	ATC,				/* ATC */
	PH_CAL_POINTS,			/* cal_points */
	PH_CAL_V1,			/* cal_V1 */
	PH_CAL_PH1,			/* cal_pH1 - note: subsequently changed if USE_BUFFER_LOOKUP*/
	PH_CAL_T1,			/* cal_T1 */
	PH_CAL_V2,			/* cal_V2 */
	PH_CAL_PH2,			/* cal_pH2 - note: subsequently changed if USE_BUFFER_LOOKUP*/
	PH_CAL_T2,			/* cal_T2 */
};

/* Set probe defaults based on values in config file */
Conductivity_probe_t myEcProbe = {
	COND_CELL_CONST, 		/* cell_constant */
	COND_CAL_MEAS,			/* cal_cond_measured */
	COND_CAL_ACT,			/* cal_cond_actual */
	COND_DEFAULT_FREQ,		/* cond_meas_freq */
};

/* Set probe defaults based on values in config file */
Temp_sensor_t myTempSensor = {
	TEMPSENSORTYPE,			/* temp_sensor_type - defined in config file */
	R_POINT1,			/* R1 (NTC - Nominal resistance, RTD - resistance point 1) */
	T_POINT1,			/* T1 (NTC - Nominal temperature, RTD - temperature point 1) */
	R_POINT2,			/* R2 (only used for RTD) */
	T_POINT2,			/* T2 (only used for RTD) */
#ifdef NTC_B_DEFAULT
	NTC_B_DEFAULT,			/* B_value (only used for NTC) */
#else
	0,
#endif
#if NTC_COMP_TYPE==STEINHARTHART
	NTC_A_STEINHART,		/* A_steinhart */
	NCT_B_STEINHART,		/* B_steinhart */
	NTC_C_STEINHART			/* C_steinhart */
#else
	0,
	0,
	0
#endif
};



SNS_CFG_Type * getSnsCfg(uint32_t channel)
{
	return (SNS_CFG_Type *)(&(SnsCfg[channel]));
}

void SensorInit()
{
	if((SnsCfg[0].Enable == SENSOR_CHANNEL_ENABLE)) {
#if DEBUG
		printf("%s Sensor Initializing\r\n", SnsCfg[0].SensorName);
#endif /*DEBUG*/
		SnsInit(SnsCfg);
		for(uint32_t i=0; i<5000; i++)delay_10us(100);
	}
	if((SnsCfg[1].Enable == SENSOR_CHANNEL_ENABLE)) {
#if DEBUG
		printf("%s Sensor Initializing\r\n", SnsCfg[1].SensorName);
#endif /*DEBUG*/
		SnsInit(&(SnsCfg[1]));
		for(uint32_t i=0; i<5000; i++)delay_10us(100);
	}
}

/**
 * @brief uint8_t SnsInit(SNS_CFG_Type *pSnsCfg)
 *	======== Mux setup, bias sensor, load sensor parameters.
 * @param pSnsCfg :{}
 *	- pointer to sensor configuration parameters
 * @return 1.
 */
uint8_t SnsInit(SNS_CFG_Type *pSnsCfg)
{
	uint16_t Cbias,Czero;
	int32_t Vdiff = 0;
	uint32_t channel = pSnsCfg->channel;

	if(channel == 0) {
		/* set up default sensor at init */
#if USE_BUFFER_LOOKUP
		uint8_t i;
		if(myPhProbe.cal_T1 < 0) {
			myPhProbe.cal_pH1 = ph_temp_lut_1[0];
		} else {
			for(i = 1; i < NUMBER_OF_TEMPERATURE_ENTRIES; i++) {
				if(myPhProbe.cal_T1 > ph_temperatures[i - 1]
				    && myPhProbe.cal_T1 <= ph_temperatures[i]) {
					/* Copied CN0398, but may change to linear interpolation */
					myPhProbe.cal_pH1 = ph_temp_lut_1[i];
				}
			}
		}
		if(myPhProbe.cal_points == 2) {
			if(myPhProbe.cal_T2 < 0) {
				myPhProbe.cal_pH2 = ph_temp_lut_2[0];
			} else {
				for(i = 1; i < NUMBER_OF_TEMPERATURE_ENTRIES; i++) {
					if(myPhProbe.cal_T2 > ph_temperatures[i - 1]
					    && myPhProbe.cal_T2 <= ph_temperatures[i]) {
						/* Copied CN0398, but may change to linear interpolation */
						myPhProbe.cal_pH2 = ph_temp_lut_2[i];
					}
				}
			}
		}
#endif /* USE_BUFFER_LOOKUP */
	}
	/*********ULP DAC setup************/

	LPDacPwrCtrl(channel,PWR_UP); /*power up DAC*/

	Vdiff = (int32_t)(pSnsCfg->Vbias - pSnsCfg->Vzero);
	/* 6 bit DAC code for Vzero */
	Czero = (uint32_t)((pSnsCfg->Vzero - 200)*63.0/2166 +0.5);
	if(Vdiff == 0) { /* zero bias  across sensor */
		Cbias = (uint32_t)((pSnsCfg->Vbias - 200)*4095.0/2200+0.5);      /*12 bit*/
		/*short Vzero to Vbias*/
		LPDacCfg(channel, LPDACSWNOR, VBIAS12BIT_VZERO12BIT_SHORT, LPDACREF2P5);
	} else {
		/*adjust Vbias according to Vzero to make sure Vdiff is accurate*/
		Cbias = (uint16_t)(Czero*64 + (int16_t)(Vdiff*4095.0/2200+0.5));
		//dac设置为normal工作模式，vbais 12bit模式，vzero 6bit模式，ref 2.5v
		LPDacCfg(channel,LPDACSWNOR,VBIAS12BIT_VZERO6BIT,LPDACREF2P5);
	}
	LPDacWr(channel,Czero,Cbias);

	for(uint32_t i=0; i<50000; i++); /* delay for cap on bias(zero) pin */

	/***********ULP TIA/PA setup*************/
	AfeLpTiaPwrDown(channel,0); /* power up PA and TIA. */
	/*short TIA feedback with diode for Sensor setup*/
	AfeLpTiaSwitchCfg(channel, SWMODE_SHORT);
	//设置Rload电阻 、反馈增益电阻、滤波电阻
	AfeLpTiaCon(channel,(LPTIA_RLOAD_Type)(pSnsCfg->Rload),
		    (LPTIA_RGAIN_Type)(pSnsCfg->Rtia), (LPTIA_RF_Type)(pSnsCfg->Rfilter));

	for(uint32_t i=0; i<50000; i++); /* delay for sensor setup */

	/* set up based on sensortype */
	/* pH sensor should not be held at 0V */
	if(pSnsCfg->Sensor_Type == pH) {
		AfeLpTiaSwitchCfg(channel,SWMODE_OPEN_RE);
		if(flagHiZMode) { /* Set default EIS freq range */
			pSnsCfg->minFreq = MIN_PH_HZ_FREQ;
			pSnsCfg->maxFreq = MAX_PH_HZ_FREQ;
		} else {
			pSnsCfg->minFreq = MIN_PH_INT_FREQ;
			pSnsCfg->maxFreq = MAX_PH_INT_FREQ;
		}
	} else if(pSnsCfg->Sensor_Type == ORP) {
		AfeLpTiaSwitchCfg(channel,SWMODE_OPEN_RE);
	} else {
	/*TIA switch to normal mode for measurement*/
		AfeLpTiaSwitchCfg(channel, SWMODE_NORM_CE_RE_SHORT);
		if(pSnsCfg->Sensor_Type == Conductivity && channel == 0) {
			if(flagHiZMode) { /* Set default EIS freq range */
				pSnsCfg->minFreq = MIN_COND_HZ_FREQ;
				pSnsCfg->maxFreq = MAX_COND_HZ_FREQ;
			} else {
				pSnsCfg->minFreq = MIN_COND_INT_FREQ;
				pSnsCfg->maxFreq = MAX_COND_INT_FREQ;
			}
		}
	}

	return 1;
}

/**
 * @brief uint8_t SnsACInit(uint8_t channel)
 *	Initialization for AC test, setup wave generation and switches.
 * @param channel :{CHAN0,CHAN1}
 *	 - 0 or CHAN0, Sensor channel 0
 *	- 1 or CHAN1, Sensor channel 1
 * @return 1.
 */
uint8_t SnsACInit(uint8_t channel)
{
	uint32_t ctia;
	uint8_t small_signal; /*small signal 15mVp, large signal 600mVp*/
	if(channel > 0) {
		disableTiaAutorange = 0;
		disablePgaAutorange = 0;
		uiHpRtiaSeIndex = pSnsCfg1->StartingHpRtiaSeIndex;
		uiGnPgaIndex = pSnsCfg1->StartingGnPgaIndex;
		/* note: switch resistance limits current in case of small resistance */
		small_signal = 0;
	} else {
		disableTiaAutorange = flagHiZMode; /* HiZMode can't autorange TIA */
		disablePgaAutorange = flagHiZMode; /* HiZMode could autorange PGA if desired */
		uiHpRtiaSeIndex = pSnsCfg0->StartingHpRtiaSeIndex;
		uiGnPgaIndex = pSnsCfg0->StartingGnPgaIndex;
		if(pSnsCfg0->Sensor_Type == pH || pSnsCfg0->Sensor_Type == ORP)
			small_signal = 1;
		else
			small_signal = 0;
	}

	/*DFT and SINC2 interrupt enable*/
	AfeAdcIntCfg(BITM_AFE_ADCINTIEN_DFTRDYIEN|BITM_AFE_ADCINTIEN_SINC2RDYIEN);
	NVIC_EnableIRQ(AFE_ADC_IRQn);

	/******setup exitation loop and TIA********/
	AfeHpTiaPwrUp(true);
	/*Normal power mode, VZero0 biased HP TIA*/
	AfeHpTiaCon(HPTIABIAS_VZERO0);
	AfeSwitchFullCfg(SWITCH_GROUP_T,SWID_T9);
	ctia = BITM_HPTIA_CTIA_16PF|BITM_HPTIA_CTIA_8PF|BITM_HPTIA_CTIA_4PF|
	       BITM_HPTIA_CTIA_2PF|BITM_HPTIA_CTIA_1PF;

	AfeHpTiaSeCfg(uiHpRtiaSe[uiHpRtiaSeIndex],ctia,0); /*set RTIA based on index*/
#if DEBUG
	if(channel == 0 && flagHiZMode) {
		printf("RTia (Hi-Z): 10Meg"EOL);
	} else if(uiHpRtiaSeIndex == 8) {
		printf("RTia: 1Meg"EOL);
	} else {
		printf("RTia: %s"EOL, szValHpRtiaSe[uiHpRtiaSeIndex]);
	}
#endif /*DEBUG*/

	AfeHpTiaDeCfg(CHAN0,HPTIADE_RLOAD_OPEN,HPTIADE_RTIA_OPEN);
	AfeHpTiaDeCfg(CHAN1,HPTIADE_RLOAD_OPEN,HPTIADE_RTIA_OPEN);
	/*switch to RCAL, loop exitation before power up*/
	AfeSwitchDPNT(SWID_DR0_RCAL0,SWID_PR0_RCAL0,SWID_NR1_RCAL1,
		      SWID_TR1_RCAL1|SWID_T9);

	/*********Initialize ADC and DFT********/
	/*ADC initialization*/
	AfeAdcFiltCfg(SINC3OSR_4,SINC2OSR_178,LFPBYPEN_NOBYP,
		      ADCSAMPLERATE_800K); /* 1120Hz as default */
	AfeSysCfg(ENUM_AFE_PMBW_LP,ENUM_AFE_PMBW_BW50);
	AfeAdcPgaCfg(uiGnPga[uiGnPgaIndex],0);
#if DEBUG
	printf("PGA Gain: %s"EOL, szValGnPga[uiGnPgaIndex]);
#endif /*DEBUG*/
	if(channel == 0 && flagHiZMode) {
		AfeAdcChan(MUXSELP_AIN5,MUXSELN_VZERO0);
	} else {
		AfeAdcChan(MUXSELP_HPTIA_P,MUXSELN_HPTIA_N);
	}
	/* Enable ADC input buffer chop for LP mode (up to 80kHz) */
	AfeAdcChopEn(1);

	/********sinewave generation**********/
	AfeHPDacPwrUp(true);
	/*DAC attenuator = 1/5, Excitaion Amplifier Gain=1/4,DAC update rate = 320KHz,bandwidth=50KHz*/
	if(small_signal)

		AfeHPDacCfg(HPDAC_ATTEN_DIV5,HPDAC_RATE_REG,HPDAC_INAMPGAIN_DIV4);
	else
		AfeHPDacCfg(HPDAC_ATTEN_DIV1,HPDAC_RATE_REG,HPDAC_INAMPGAIN_2);

	AfeHPDacSineCfg(SINE_FREQ_REG,0,SINE_OFFSET_REG,SINE_AMPLITUDE_REG);
	AfeHPDacWgType(HPDAC_WGTYPE_SINE);
	return 1;
}

/**
 * @brief uint8_t SnsACSigChainCfg(uint32_t freq)
 *	======== configuration of AC signal chain depends on required excitation
 *		 frequency.
 * @param freq :{}
 *	- excitation AC signal frequency
 * @return 1.
 * @note settings including DAC update rate, ADC update rate and DFT samples can
 *	 be adjusted for different excitation frequencies to get better
 *	 performance. As general guidelines,
 *	- DAC update rate: make sure at least 4 points per sinewave period.
 *	  Higher rate comsumes more power.
 *	- ADC update rate:  at least follow Nyquist sampling rule.
 *	- DFT samples should cover more than 1 sine wave period. more DFT sample
 *	  reduce variation but take longer time.
 *	the configuration can be optimised depending on user's applicationn
 */
uint8_t SnsACSigChainCfg(float *infreq)
{
	/* In order to get 2 periods for DFT and at least 10 samples per period (better than nyquist):
	 *	10*freq <= update rate < 0.5 * freq * DFTsamples
	 * or equivalently
	 *	2*update rate/DFTsamples < freq < update rate/10
	 */
	uint16_t DacCon;
	uint16_t LfSinc2;
	uint16_t LfDftNum;
	uint32_t WgFreqReg;
	float freq;
	uint32_t ctia;
	LfDftNum = DFTNUM_4096;
	LfSinc2 = SINC2OSR_44;

	freq = *infreq;
	DacCon = pADI_AFE->HSDACCON;
	DacCon &= (~BITM_AFE_HSDACCON_RATE); /* clear rate bits for later setting */
	DacCon |= (HPDAC_ATTEN_DIV5|HPDAC_INAMPGAIN_DIV4); /* Ensure attenuation is set */
	/*Frequency register resolution was increased after early samples*/
	if (ATE_REV >= 0x14) {
		WgFreqReg = (uint32_t)(freq*67.108864+0.5);
		/* Control corner cases */
		if (WgFreqReg > 13421772)
			WgFreqReg = 13421772;/* 200kHz, ATE version 0x14 */
		else if(WgFreqReg < 1)
			WgFreqReg = 1;
		freq = (float) WgFreqReg / 67.108864;
	} else {
		WgFreqReg = (uint32_t)(freq*4.194304+0.5);
		/* Control corner cases */
		if (WgFreqReg > 838860)
			WgFreqReg = 838860; /* 200kHz, ATE version <0x03 */
		else if(WgFreqReg < 1)
			WgFreqReg = 1;
		freq = (float) WgFreqReg / 4.194304; //ATE version less than 0x03
	}

	*infreq = freq;
	/*frequency from min to 4.439Hz  ***IMPORTANT TO OPTIMIZE FOR RUNTIME****/
	if(freq<4.439) {
		ClkDivCfg(1,1);			/* digital die to 26MHz */
		AfeHFOsc32M(0);			/* AFE oscillator change to 16MHz */
		AfeSysClkDiv(AFE_SYSCLKDIV_1);	/* AFE system clock remain in 16MHz */

		if (freq < 0.037) {
		/* 109second DFT (150Hz effective sample rate). Minimum freq for 2 periods is 0.018Hz */
			LfSinc2 = SINC2OSR_1333;
			LfDftNum = DFTNUM_16384;
		} else if (freq < 0.073) {		/* 54s DFT (150Hz ESR) */
			LfSinc2 = SINC2OSR_1333;
			LfDftNum = DFTNUM_8192;
		} else if (freq < 0.092) {
			LfSinc2 = SINC2OSR_1333;	//27s DFT (150Hz ESR)
		} else if (freq < 0.110) {
			LfSinc2 = SINC2OSR_1067;	//22s DFT (187Hz ESR)
		} else if (freq < 0.122) {
			LfSinc2 = SINC2OSR_889;		//18s DFT (225Hz ESR)
		} else if (freq < 0.146) {
			LfSinc2 = SINC2OSR_667;		//14s DFT (300Hz ESR)
		} else if (freq < 0.366) {
			LfSinc2 = SINC2OSR_533;		//11s DFT (375Hz ESR)
		} else if (freq < 0.549) {
			LfSinc2 = SINC2OSR_267;		//5.5s DFT (750Hz ESR)
		} else if (freq < 1.097) {
			LfSinc2 = SINC2OSR_178;		//3.6s DFT (1100Hz ESR)
		} else if (freq < 2.219) {
			LfSinc2 = SINC2OSR_89;		//1.8s DFT (2250Hz ESR)
		}
		/* else by default: SINC2OSR_44, 0.9s DFT (4545Hz ESR) */

		/* set High speed DAC and ADC in Low Power mode, filter cut-off at 50kHz */
		AfeSysCfg(ENUM_AFE_PMBW_LP, ENUM_AFE_PMBW_BW50);
		/*set low DAC update rate,16MHz/255=~62.7KHz update rate, skew the DAC and ADC clocks with respect to each other*/
		DacCon |= (255u<<BITP_AFE_HSDACCON_RATE);
		/*ADC update rate to DFT engine*/
		pADI_AFE->AFECON |= BITM_AFE_AFECON_SINC2EN;
		AfeAdcFiltCfg(SINC3OSR_4,LfSinc2,LFPBYPEN_NOBYP,ADCSAMPLERATE_800K);
		AfeAdcDFTCfg(BITM_AFE_DFTCON_HANNINGEN,LfDftNum,DFTIN_SINC2);
	} else if(freq<100) { /*4.439 Hz < freq < 100 Hz*/
		ClkDivCfg(1,1);			/* digital die to 26MHz */
		AfeHFOsc32M(0);			/* AFE oscillator change to 16MHz */
		AfeSysClkDiv(AFE_SYSCLKDIV_1);	/* AFE system clock remain in 16MHz */
		/* set High speed DAC and ADC in Low Power mode, filter cut-off at 50kHz */
		AfeSysCfg(ENUM_AFE_PMBW_LP,ENUM_AFE_PMBW_BW50);
		/*set low DAC update rate,16MHz/255=~62.7KHz update rate, skew the DAC and ADC clocks with respect to each other*/
		DacCon |= (255u<<BITP_AFE_HSDACCON_RATE);
		/*ADC 9090sps update rate to DFT engine*/
		pADI_AFE->AFECON |= BITM_AFE_AFECON_SINC2EN;
		AfeAdcFiltCfg(SINC3OSR_4,SINC2OSR_22,LFPBYPEN_NOBYP,
			      ADCSAMPLERATE_800K); /* 9090Hz */
		/* 0.45s DFT (~4.5 Hz minimum for 2 periods) */
		AfeAdcDFTCfg(BITM_AFE_DFTCON_HANNINGEN,DFTNUM_4096,DFTIN_SINC2);
	/* Could add averaging filters to reduce noise in the 100s of Hz. */
	} else if(freq<20000) { /*100Hz < frequency < 20KHz*/
		ClkDivCfg(1,1);			/* digital die to 26MHz */
		AfeHFOsc32M(0);			/* AFE oscillator change to 16MHz */
		AfeSysClkDiv(AFE_SYSCLKDIV_1);	/* AFE system clock remain in 16MHz */
		/*set middle DAC update rate,16MHz/18=~888KHz update rate,skew the DAC and ADC clocks with respect to each other*/
		/* set High speed DAC and ADC in Low Power mode, filter cut-off at 100kHz */
		AfeSysCfg(ENUM_AFE_PMBW_LP,ENUM_AFE_PMBW_BW100);
		DacCon |= (18u<<BITP_AFE_HSDACCON_RATE);
		/*ADC 200Ksps update rate to DFT engine*/
		pADI_AFE->AFECON &= (~BITM_AFE_AFECON_SINC2EN);
		AfeAdcFiltCfg(SINC3OSR_4,SINC2OSR_178,LFPBYPEN_BYP,
			      ADCSAMPLERATE_800K); /* bypass LPF, 200KHz ADC update rate */
		/* DFT source: Sinc3 result --> 40ms DFT (~50Hz min) */
		AfeAdcDFTCfg(BITM_AFE_DFTCON_HANNINGEN,DFTNUM_8192,DFTIN_SINC3);
	} else if(freq<200000) { /*20KHz < frequency < 200KHz*/
		/***Check if RTia | Ctia is too high***/
		/* Ctia = 31pF, 31pF|160k = 30kHz. */
		if(uiHpRtiaSeIndex > 3) { /* 10k ohms */
			/*reduce CTIA to extend BW*/
			ctia = BITM_HPTIA_CTIA_4PF; /* 4pF||160k = 250kHz */
			AfeHpTiaSeCfg(uiHpRtiaSe[uiHpRtiaSeIndex],ctia,0);
		}
		/*****boost ADC sample rate to 1.6MHz****/
		AfeAdcChopEn(0); /* Disable ADC input buffer chop for HP mode (>80kHz) */
		/* set High speed DAC and ADC in high power mode */
		AfeSysCfg(ENUM_AFE_PMBW_HP,ENUM_AFE_PMBW_BW250);
		ClkDivCfg(2,2);
		AfeSysClkDiv(AFE_SYSCLKDIV_2); /* AFE system clock 8MHz */
		AfeHFOsc32M(BITM_AFE_HPOSCCON_CLK32MHZEN); /* AFE osc 32MHz */
		ClkDivCfg(1,1);
		/*set High DAC update rate,16MHz/9=~1.6MHz update rate,skew the DAC and ADC clocks with respect to each other*/
		DacCon |= (9u<<BITP_AFE_HSDACCON_RATE);
		/*ADC 400Ksps update rate to DFT engine*/
		pADI_AFE->AFECON &= (~BITM_AFE_AFECON_SINC2EN); /* disable supply LPF */
		AfeAdcFiltCfg(SINC3OSR_4,SINC2OSR_178,LFPBYPEN_BYP,
			      ADCSAMPLERATE_1600K); /* bypass LPF, 400KHz ADC update rate */
		/* DFT source: Sinc3 result  --> 20ms DFT */
		AfeAdcDFTCfg(BITM_AFE_DFTCON_HANNINGEN,DFTNUM_8192,DFTIN_SINC3);
	} else { /*frequency higher than 200KHz,exceeded specification*/
		return 0;
	}
	pADI_AFE->HSDACCON = DacCon;
	/* set new frequency */
	AfeHPDacSineCfg(WgFreqReg,0,SINE_OFFSET_REG,SINE_AMPLITUDE_REG);
	return 1;
}

/**
 * @brief uint8_t SnsACTest(uint8_t channel, ImpResult_t *ImpResult,
 *			    size_t ImpResultArrSize)
 *	Start AC impedance measurement test
 * @param channel :{CHAN0,CHAN1}
 *	- 0 or CHAN0, Sensor channel 0
 *	- 1 or CHAN1, Sensor channel 1
 * @param *ImpResult :{}
 *	- pointer to impedance result array populated with measurement
 *	  frequencies
 * @param ImpResultArrSize :{}
 *	- size of the impedance result array
 * @return 1.
 */
uint8_t SnsACTest(uint8_t channel, ImpResult_t *ImpResult,
		  size_t ImpResultArrSize)
{
	uint32_t freqNum = ImpResultArrSize;
	for(int32_t i = freqNum - 1; i >= 0; i--) {
		/* Skip measurements outside the defined EIS frequency range */
		if(NICE_EIS_FREQ_RANGE) {
			if(channel > 0) {
				if(ImpResult[i].freq < pSnsCfg1->minFreq || ImpResult[i].freq > pSnsCfg1->maxFreq) {
					ImpResult[i].result_valid = false;
					continue;
				}
			} else {
				if(ImpResult[i].freq < pSnsCfg0->minFreq || ImpResult[i].freq > pSnsCfg0->maxFreq) {
					ImpResult[i].result_valid = false;
					continue;
				}
			}
		}
		/* Start off assuming max TIA gain could be 1Meg. Reduce on interrupt. */
		uiMaxGainRangeIndex = 8;
		/* Start off assuming max PGA gain could be 9. Reduce on interrupt. */
		uiMaxPgaGainIndex = 4;
		MeasureImpedance(RSnsLoad, i, channel, ImpResult);
		/* Cannot connect calibration resistor for Hi-Z Mode */
		if (channel == 0 && flagHiZMode) {
			ImpResult[i].Cal_result = false;
			ImpResult[i].Load_result = false;
		} else if (uiHpRtiaSeIndex == 8) {
		/* hprtiase_ohm[8] is 0xFFFFFFFF, not 1Meg */
			MeasureImpedance(RCal, i, channel, ImpResult);
			ImpResult[i].Cal_result = true;
			ImpResult[i].Load_result = false;
		} else if(((hprtiase_ohm[uiHpRtiaSeIndex])*(uiValGnPga_x2[uiGnPgaIndex]))<=
			  10000) {
			/* Can only measure Rsns of 200 ohms up to RTia of 5k. 15mV/100*5000 = 750mV. */
			/* Note: Assumes Rload = 100 ohms as in SE input. */
			MeasureImpedance(RLoad, i, channel, ImpResult);
			MeasureImpedance(RCal, i, channel, ImpResult);
			ImpResult[i].Cal_result = true;
			ImpResult[i].Load_result = true;
		} else { /* RTIA is too big for Rload, but Rcal is okay */
			MeasureImpedance(RCal, i, channel, ImpResult);
			ImpResult[i].Cal_result = true;
			ImpResult[i].Load_result = false;
		}
	}
	return 1;
}

/**
 * @brief uint32_t WaterDigComp(uint16_t uiMinVal, uint16_t uiMinHysteresis,
 *				uint16_t uiMaxVal, uint16_t uiMaxHysteresis)
 *	Configure digital comparators for autoranging
 * @param uiMinVal :{}
 *	- Minimum trip point for ADCMINERR interrupt source
 * @param uiMinHysteresis :{}
 *	- Hysteresis value for ADCMINERR interrupt source
 * @param uiMaxVal :{}
 *	- Maximum trip point for ADCMAXERR interrupt source
 * @param uiMaxHysteresis :{}
 *	- Hysteresis value for ADCMAXERR interrupt source
 * @return 1.
 */
uint32_t WaterDigComp(uint16_t uiMinVal, uint16_t uiMinHysteresis,
		      uint16_t uiMaxVal, uint16_t uiMaxHysteresis)
{
	/* Setup Minimum trip point for ADCMINERR interrupt source */
	pADI_AFE->ADCMIN = uiMinVal;
	/* Setup hysteresis value for ADCMINERR interrupt source */
	pADI_AFE->ADCMINSM = uiMinHysteresis;
	/* Setup Maximum trip point for ADCMAXERR interrupt source */
	pADI_AFE->ADCMAX = uiMaxVal;
	/* Setup hysteresis value for ADCMAXERR interrupt source */
	pADI_AFE->ADCMAXSMEN = uiMaxHysteresis;
	return 1;
}

uint32_t RtiaGet()
{
	uint32_t szValHpRtiaSe[] = {  200 , 1000, 5000,  10000,  20000,  40000,  80000,  160000, 1000000};

	return szValHpRtiaSe[uiHpRtiaSeIndex];
}
float mMagRaw = 0;
float MagRawGet()
{
	return mMagRaw ;
}

/**
 * @brief uint8_t MeasureImpedance(RMeasType MType, uint8_t i, uint8_t channel)
 *	Measure DFT of sensor and store in ImpResult[i].DFT_result[1..2].
 * @param i : {}
 *	- Index for ImpResult[]
 * @param MType :{}
 *	- Whether to measure Rsensor+Rload (0 or RSnsLoad), Rload (1 or RLoad),
 *	  or Rcal (2 or RCal)
 * @param channel :{}
 *	- Indicates which channel to connect
 * @param *ImpResult :{}
 *	- pointer to impedance result array populated with measurement
 *	  frequencies
 * @return 1.
 */
uint8_t MeasureImpedance(RMeasType MType, uint8_t i, uint8_t channel,
			 ImpResult_t *ImpResult)
{
	float dcfreq;
	float DFT_mag, Var1, Var2;
	uint32_t ctia;
	uint8_t MeasComplete = 0;
	dcfreq = 10.0;
	ctia = BITM_HPTIA_CTIA_16PF|BITM_HPTIA_CTIA_8PF|BITM_HPTIA_CTIA_4PF|
	       BITM_HPTIA_CTIA_2PF|BITM_HPTIA_CTIA_1PF;	//采用最大 16+8+4+2+1=31pF

	while(!MeasComplete) {
		if(MType > 0 && ImpResult[i].freq < 10)
		/* No need to measure Rcal or Rload below 10Hz to save time for low frequency measurements */
			SnsACSigChainCfg(&dcfreq);
		else
			SnsACSigChainCfg(&ImpResult[i].freq);

		/****** Config sw matrix ********/
		ConnectSensor(MType, i, channel, ImpResult);
		AfeWaveGenGo(true);
		/* Set interrupt at 20% and 80% of ADC range for autoranging. */
		WaterDigComp(0x3333,0x50,0xCCCC,0x50);

		pADI_AFE->ADCINTSTA =
			BITM_AFE_ADCINTIEN_DFTRDYIEN|BITM_AFE_ADCINTIEN_ADCMINFAILIEN|BITM_AFE_ADCINTIEN_ADCMAXFAILIEN;
		delay_10us(100);

		AfeAdcIntCfg(
			BITM_AFE_ADCINTIEN_DFTRDYIEN|BITM_AFE_ADCINTIEN_ADCMINFAILIEN|BITM_AFE_ADCINTIEN_ADCMAXFAILIEN);

		/* Reset SINC Filters */
		/* Clear AFECON[8] (SINC3) and AFECON[16] (SINC2) */
		pADI_AFE->AFECON &= (~
				     (BITM_AFE_AFECON_SINC2EN|BITM_AFE_AFECON_ADCCONVEN));
		delay_10us(20); /* 200us */
		/* Set AFECON[16]. Bit 8 will be set when ADC is started. */
		pADI_AFE->AFECON |= BITM_AFE_AFECON_SINC2EN;
		pADI_AFE->AFECON |= BITM_AFE_AFECON_ADCEN;
		delay_10us(1000); /* 10ms for switch settling */
		/*start ADC conversion and DFT */
		pADI_AFE->AFECON |= BITM_AFE_AFECON_DFTEN|BITM_AFE_AFECON_ADCCONVEN;
		adcSat = 0;
		while(!dftRdy) {		/* wait for DFT result */
			if(adcSat) {
				pADI_AFE->AFECON &= (~(BITM_AFE_AFECON_DFTEN|
						       BITM_AFE_AFECON_ADCCONVEN|
						       BITM_AFE_AFECON_ADCEN));  /* stop conversion */
				break;
			}
		}
		if(dftRdy) {
			dftRdy = 0;
			delay_10us(20); /* 200us */
			Var1 = (float) convertDftToInt(pADI_AFE->DFTREAL);
			Var2 = (float) convertDftToInt(pADI_AFE->DFTIMAG);
			DFT_mag = sqrt((Var1*Var1)+(Var2*Var2));
		}

		if (MType != RSnsLoad) { /* Disable autorange */
		/* Don't autorange for RCal or RLoad measurements
		(these should be done in the same range as sensor) */
			MeasComplete = 1;
		/* Note: can't autorange TIA for Hi-Z Mode. Could autorange PGA with time penalty. */
		} else if (adcSat) {
			/* Digital comparator interrupt has triggered, indicating
			saturation of ADC. Reduce range. */
			if(uiGnPgaIndex > 0 && !disablePgaAutorange) { /* first reduce PGA gain */
				uiGnPgaIndex--;
				AfeAdcPgaCfg(uiGnPga[uiGnPgaIndex],0);
#if DEBUG
				printf("PGA Gain changed to: %s"EOL, szValGnPga[uiGnPgaIndex]);
#endif /*DEBUG*/
			} else if(uiHpRtiaSeIndex > 0 && !disableTiaAutorange) { /* reduce RTIA */
				uiHpRtiaSeIndex--;
				AfeHpTiaSeCfg(uiHpRtiaSe[uiHpRtiaSeIndex],ctia,
					      BITM_AFE_HSRTIACON_TIASW6CON);
				/*set RTIA based on index, set diode until switches are configured*/
#if DEBUG
				printf("RTia changed to: %s"EOL, szValHpRtiaSe[uiHpRtiaSeIndex]);
#endif /*DEBUG*/
			} else {
				MeasComplete = 1; /* min gain */
				ImpResult[i].result_valid = false; //Invalid because ADC saturated
			}
		} else if((int) DFT_mag < 6554) {
		/* 5% of max magnitude. Very low signal due to low gain or high impedance */
			if(uiHpRtiaSeIndex < uiMaxGainRangeIndex && !disableTiaAutorange) { /* First increase RTIA */
				uiHpRtiaSeIndex++;
				AfeHpTiaSeCfg(uiHpRtiaSe[uiHpRtiaSeIndex],ctia,
					      BITM_AFE_HSRTIACON_TIASW6CON);
				/*set RTIA based on index, set diode until switches are configured*/
				if(uiHpRtiaSeIndex == 8) { /* Make sure there is a TIA resistor connected */
					/* Connect AIN2 to input */
					pADI_AFE->TSWFULLCON |= SWID_T3_AIN2;
					/* Connect DE1 to output (RLOAD is 0, RTIA is 50) */
					pADI_AFE->DE1RESCON &= ~(0xFF);
					/* Ensure internal RTIA is disconnected and set capacitance to 4pF */
					AfeHpTiaSeCfg(HPTIASE_RTIA_OPEN,BITM_HPTIA_CTIA_4PF,
						      BITM_AFE_HSRTIACON_TIASW6CON);
				}
#if DEBUG
				printf("RTia changed to: %s"EOL, szValHpRtiaSe[uiHpRtiaSeIndex]);
#endif /*DEBUG*/
			} else if(uiGnPgaIndex < uiMaxPgaGainIndex && !disablePgaAutorange) {
			/* increase PGA gain if RTIA is at max */
				uiGnPgaIndex++;
				AfeAdcPgaCfg(uiGnPga[uiGnPgaIndex],0);
#if DEBUG
				printf("PGA Gain changed to: %s"EOL, szValGnPga[uiGnPgaIndex]);
#endif /*DEBUG*/
			} else {
			/* small magnitude, but max gain. */
				MeasComplete=1;
				ImpResult[i].result_valid = ((int) DFT_mag != 0); /* 0 would give infinite Z */
			}
		} else {
		/* Measurement is between 5% and 80% */
			MeasComplete=1;
			ImpResult[i].result_valid = true;
		}
	} /* Loop until MeasComplete */
	/* Set Rtia and PGA gain index for range calibration */
	ImpResult[i].iRtia = uiHpRtiaSeIndex;
	ImpResult[i].iGpga = uiGnPgaIndex;
	/* Impedance = V/I = [15mV<0 / ((Vadc / Gpga) / RTia)] -> Calculate that denominator for use in later calc */
	ImpResult[i].DFT_result[MType*2] = DFTtoCurrent(pADI_AFE->DFTREAL, channel);
	ImpResult[i].DFT_result[MType*2+1] = DFTtoCurrent(pADI_AFE->DFTIMAG, channel);

	/********** recover LP TIA connection to maintain sensor*********/
	AfeWaveGenGo(false);
	/* Disconnect mux */
	AfeSwitchDPNT(SWID_ALLOPEN,SWID_ALLOPEN,SWID_ALLOPEN,SWID_ALLOPEN);
	/*TIA switch to normal mode plus SW10 to short CE and RE*/
	AfeLpTiaSwitchCfg(channel,SWMODE_NORM_CE_RE_SHORT);
	if(channel>0) {
		/* connect RTIA */
		AfeLpTiaCon(CHAN1,pSnsCfg1->Rload,pSnsCfg1->Rtia,
			    pSnsCfg1->Rfilter);
		/* Set LPDac mode back to normal */
		pADI_AFE->LPDACCON1 &= ~LPDACSWDIAG;
	} else {
		/* connect RTIA */
		AfeLpTiaCon(CHAN0,pSnsCfg0->Rload,pSnsCfg0->Rtia,
			    pSnsCfg0->Rfilter);
		/* Set LPDac mode back to normal */
		pADI_AFE->LPDACCON0 &= ~LPDACSWDIAG;
	}
	return 1;
}

/**
 * @brief uint8_t SnsMagPhaseCal()
 *	Calculate magnitude and phase of sensor.
 * @param *ImpResult :{}
 *	- pointer to impedance result array populated with measurement
 *	  frequencies
 * @param ImpResultArrSize :{}
 *	- size of the impedance result array
 * @return 1.
 */
uint8_t SnsMagPhaseCal(ImpResult_t *ImpResult, size_t ImpResultArrSize)
{
	float Src[8];
	float Var1,Var2;

	cfgInfo_t cfgInfo;
	cfgInfo_get(&cfgInfo);


	uint32_t testNum = ImpResultArrSize;
	for(uint32_t i=0; i<testNum; i++) {
		if(!ImpResult[i].Cal_result && !ImpResult[i].Load_result) {
		/* Take care of case where we couldn't measure Rcal or Rload for this range */
			ImpResult[i].Mag = 0.015 / sqrt(
						   ImpResult[i].DFT_result[0]*ImpResult[i].DFT_result[0] +
						   ImpResult[i].DFT_result[1]*ImpResult[i].DFT_result[1]);
			ImpResult[i].Phase = - atan2(ImpResult[i].DFT_result[1],
						     ImpResult[i].DFT_result[0]);
			ImpResult[i].DFT_Mag[2] = 0; /* show Rcal was not measured */
			/* Compensate phase error in Hi-Z Mode */
			if(flagHiZMode) {
				ImpResult[i].Phase += COMPPHASEHIZ;
				if(ImpResult[i].Phase > PI)
					ImpResult[i].Phase -= (2*PI);
				else if(ImpResult[i].Phase < -PI)
					ImpResult[i].Phase += (2*PI);
			}

			/* Convert real: DFT_Result[0] and imaginary: DFT_Result[1] to impedance for printing */
			ImpResult[i].DFT_result[0] = ImpResult[i].Mag * cos(ImpResult[i].Phase); /* Real */
			ImpResult[i].DFT_result[1] = ImpResult[i].Mag * sin(ImpResult[i].Phase); /* Imag */
			
			ImpResult[i].Phase = ImpResult[i].Phase*180/PI;
		} else if (ImpResult[i].Cal_result && !ImpResult[i].Load_result) {
			/* Measured Cal resistor but not load resistor
			 Assume 100 ohm constant Rload (HPTIASE)
			 ZSns = (ICal*ZCal - 100*ISnsPlusLoad) / ISnsPlusLoad */

			/* For now DFT_result holds current so we can calculate mag/phase
				DFT_result[0] - real part of Rload+Sensor
				DFT_result[1] - img part of Rload+Sensor
				DFT_result[4] - real part of Rcal
				DFT_result[5] - img part of Rcal
			Copy these into Src array for calculation */
			Src[0] = ImpResult[i].DFT_result[0];
			Src[1] = ImpResult[i].DFT_result[1];
			Src[4] = ImpResult[i].DFT_result[4];
			Src[5] = ImpResult[i].DFT_result[5];

			/* Calculate Ical*Zcal - 100*ISnsPlusLoad */
			Var1 = uiValRcal[(ImpResult[i].iRcal)]*Src[4];
			Var2 = 100*Src[0];
			Src[2] = Var1 - Var2;
			Var1 = uiValRcal[(ImpResult[i].iRcal)]*Src[5];
			Var2 = 100*Src[1];
			Src[3] = Var1 - Var2;

			/* For phasor division, Impedance = (15mV<0) / (Imag<Iphase) */
			for (uint8_t ix=0; ix<3; ix++) {
				Var1 = sqrt(Src[ix*2]*Src[ix*2]+Src[ix*2+1]*Src[ix*2+1]); /* Current magnitude */
				Var2 = atan2(Src[ix*2+1], Src[ix*2]); /* Current phase */
				Src[ix*2] = Var1; /* Current magnitude */
				Src[ix*2+1] = Var2; /* Current phase (Radians) */
			}

			/*SRC[x] needs to be magnitude & phase for later calculations
				Src[0] - Mag of I(Rload+Sensor)
				Src[1] - Phase of I(Rload+Sensor)
				Src[2] - Mag of ICal*ZCal - 100*I(Rload+Sensor)
				Src[3] - Phase of ICal*ZCal - 100*I(Rload+Sensor)
				Src[4] - Mag of I(Rcal)
				Src[5] - Phase of I(Rcal))
				*/

			/* Calculate Magnitude of Rcal and RSnsLoad
				DFT_Mag[0]: Rload+Sensor
				DFT_Mag[2]: Rcal
			*/
			/* Compensate for voltage mag = Rcal * I(Rcal) */
			ImpResult[i].DFT_Mag[0] = Src[4]*uiValRcal[(ImpResult[i].iRcal)] /
						  Src[0];
			/* Have to assume amplitude for Rcal mag */
			ImpResult[i].DFT_Mag[2] = 0.015 / Src[4];

			/* Calculate real and imaginary impedacne of Rcal and Rload+Sensor */
			/* 	Convert polar to rectangular */
			/* Real Rcal Impedance */
			ImpResult[i].DFT_result[4] = ImpResult[i].DFT_Mag[2] * cos(-
						     (Src[5]));
			/* Imaginary Rcal Impedance */
			ImpResult[i].DFT_result[5] = ImpResult[i].DFT_Mag[2] * sin(-
						     (Src[5]));

			/* Calculate Compensated Magnitude and phase */
			ImpResult[i].Mag = Src[2] / Src[0];

			mMagRaw = ImpResult[0].Mag;


			Var1 = Src[3] - Src[1];

			Var2 = Var1*180/PI;
			/* degrees */
			/*shift phase back to range (-180,180]*/
			if(Var2 > 180) {
				do {
					Var2 -= 360;
				} while(Var2 > 180);
			} else if(Var2 < -180) {
				do {
					Var2 += 360;
				} while(Var2 < -180);
			}
			ImpResult[i].Phase = Var2;
#if COMPRANGES
/* RANGE COMPENSATION:
 * Measure known resistor values connected to BNC connector. It is suggested to
 * use DEBUG mode, set sensortype to conductivity, and run measuresensor. Record
 * magnitude values and Rtia gain range. This requires at least two measurements
 * per range. For each range, plot the measured values against the known
 * resistor value (as measured with a precision DMM or similar).
 * Calculate a best-fit line and record gain and offset in M355WqConfig.h */

//			if(ImpResult[i].iRtia  == 5) {
//			/* Based on known values (~22 ohms - 100 ohms) */
//				ImpResult[i].Mag = (ImpResult[i].Mag -
//						    COMPOFFSET40K)/COMPGAIN40K;
//			}
//			if(ImpResult[i].iRtia  == 6) {
//			/* Based on known values (~220 ohms - 1k ohms) */
//				ImpResult[i].Mag = (ImpResult[i].Mag -
//						    COMPOFFSET80K)/COMPGAIN80K;
//			}
//			if(ImpResult[i].iRtia  == 7) {
//			/* Based on known values (~1.5k ohms - 3.3k ohms) */
//				ImpResult[i].Mag = (ImpResult[i].Mag -
//						    COMPOFFSET160K)/COMPGAIN160K;
//			}
//			if(ImpResult[i].iRtia  == 8) {
//			/* Based on known values (~4.7k ohms - 10Meg ohms) */
//				ImpResult[i].Mag = (ImpResult[i].Mag -
//						    COMPOFFSET1MEG)/COMPGAIN1MEG;
//			}

//			if(ImpResult[i].iRtia  == 5) {
//			/* Based on known values (~22 ohms - 100 ohms) */
//				ImpResult[i].Mag = (ImpResult[i].Mag * COMPGAIN40K + COMPOFFSET40K);
//			}
//			if(ImpResult[i].iRtia  == 6) {
//			/* Based on known values (~220 ohms - 1k ohms) */
//				ImpResult[i].Mag = (ImpResult[i].Mag * COMPGAIN80K + COMPOFFSET80K);
//			}
//			if(ImpResult[i].iRtia  == 7) {
//			/* Based on known values (~1.5k ohms - 3.3k ohms) */
//				ImpResult[i].Mag = (ImpResult[i].Mag * COMPGAIN160K + COMPOFFSET160K);
//			}
//			if(ImpResult[i].iRtia  == 8) {
//			/* Based on known values (~4.7k ohms - 10Meg ohms) */
//				ImpResult[i].Mag = (ImpResult[i].Mag * COMPGAIN1MEG + COMPOFFSET1MEG);
//			}

			if(ImpResult[i].iRtia  == 5) {
			/* Based on known values (~22 ohms - 100 ohms) */
				ImpResult[i].Mag = (ImpResult[i].Mag * cfgInfo.compGain40K + cfgInfo.compOffset40K);
			}
			if(ImpResult[i].iRtia  == 6) {
			/* Based on known values (~220 ohms - 1k ohms) */
				ImpResult[i].Mag = (ImpResult[i].Mag * cfgInfo.compGain80K + cfgInfo.compOffset80K);
			}
			if(ImpResult[i].iRtia  == 7) {
			/* Based on known values (~1.5k ohms - 3.3k ohms) */
				ImpResult[i].Mag = (ImpResult[i].Mag * cfgInfo.compGain160K + cfgInfo.compOffset160K);
			}
			if(ImpResult[i].iRtia  == 8) {
			/* Based on known values (~4.7k ohms - 10Meg ohms) */
				ImpResult[i].Mag = (ImpResult[i].Mag * cfgInfo.compGain1M + cfgInfo.compOffset1M);
			}



#endif /*COMPRANGES*/
			/* Calculate compensated Real and Imaginary */
			/* Real RSnsLoad Impedance */
			ImpResult[i].DFT_result[0] = ImpResult[i].Mag * cos(
							     Var1);
			/* Imaginary Impedance */
			ImpResult[i].DFT_result[1] = ImpResult[i].Mag * sin(Var1);
		} else {
		/* Case where both Load and Cal resistor were measured (matches User Guide example) */
			for (uint8_t ix=0; ix<3; ix++) {
				/*For now DFT_result holds current so we can calculate mag/phase
				DFT_result[0] - real part of Rload+Sensor (converted from current to impedance in this loop)
				DFT_result[1] - img part of Rload+Sensor
				DFT_result[2] - real part of Rload
				DFT_result[3] - img part of Rload
				DFT_result[4] - real part of Rcal
				DFT_result[5] - img part of Rcal
				*/
				Src[ix*2] = ImpResult[i].DFT_result[ix*2];
				Src[ix*2+1] = ImpResult[i].DFT_result[ix*2+1];

				/* For phasor division, Impedance = (15mV<0) / (Imag<Iphase) */
				/* Current magnitude */
				Var1 = sqrt(Src[ix*2]*Src[ix*2]+Src[ix*2+1]*Src[ix*2+1]);
				/* Current phase */
				Var2 = atan2(Src[ix*2+1], Src[ix*2]);

				/*SRC[x] needs to be magnitude & phase for later calculations
				Src[0] - Mag of I(Rload+Sensor)
				Src[1] - Phase of I(Rload+Sensor)
				Src[2] - Mag of I(Rload)
				Src[3] - Phase of I(Rload)
				Src[4] - Mag of I(Rcal)
				Src[5] - Phase of I(Rcal)
				Src[6] - |I(Rload) - I(Rload+Sensor)|
				Src[7] - Phase of (I(Rload) - I(Rload+Sensor))
				*/
				Src[ix*2] = Var1; /* Current magnitude */
				Src[ix*2+1] = Var2; /* Current phase (Radians) */

				/* Impedance magnitude = 15mV / Current magnitude */
				Var1 = 0.015 / Var1;
				/* Impedance phase = 0 degrees - Current phase */
				Var2 = -Var2;

				/* Polar to rectangular */
				/* Real Impedance */
				ImpResult[i].DFT_result[ix*2] = Var1 * cos(Var2);
				/* Imaginary Impedance */
				ImpResult[i].DFT_result[ix*2+1] = Var1 * sin(Var2);
			}
			/* Calculate I(Rload) - I(Rload+Sensor), subtracting in rectangular then converting to polar */
			Var1 = Src[2]*cos(Src[3]) - Src[0]*cos(Src[1]); /*Real(ILoad-ISnsPlusLoad)*/
			Var2 = Src[2]*sin(Src[3]) - Src[0]*sin(Src[1]); /*Img(ILoad-ISnsPlusLoad)*/
			Src[6] = sqrt((Var1 * Var1) + (Var2 * Var2)); /* Magnitude */
			Src[7] = atan2(Var2, Var1); /* Phase */

			for (uint8_t ix=0; ix<4; ix++) {
				/* DFT_Mag enumeration is as follows
				ix=0: Rload+Sensor
				ix=1: Rload
				ix=2: Rcal
				ix=3: RLoad - Rload+Sensor (for use in calculation)
				*/
				ImpResult[i].DFT_Mag[ix] = 0.015 / Src[ix*2]; //Z_mag = 15mV / I_mag
			}
			/*
			Var1 = Actual cal resistor value * |I(Rcal)| * |I(Rload) - I(Rload+Rsensor)|
			Var2 = |I(Rload+Rsensor)| * |I(Rload)|
			ImpResult Mag = Var1/Var2
			*/
			Var1 = uiValRcal[(ImpResult[i].iRcal)] * Src[4] * Src[6];
			Var2 = Src[0] * Src[2];
			ImpResult[i].Mag = Var1/Var2;

			mMagRaw = ImpResult[i].Mag;

			Var1 = Src[5] + Src[7] - Src[1] - Src[3]; /* radians */
			Var2 = Var1*180/PI; /* degrees */
			/*shift phase back to range (-180,180]*/
			if(Var2 > 180) {
				do {
					Var2 -= 360;
				} while(Var1 > 180);
			} else if(Var2 < -180) {
				do {
					Var2 += 360;
				} while(Var2 < -180);
			}
			ImpResult[i].Phase = Var2;
#if COMPRANGES
/* RANGE COMPENSATION - See above explanation */
//			if(ImpResult[i].iRtia  == 5) {
//				ImpResult[i].Mag = (ImpResult[i].Mag -
//						    COMPOFFSET40K)/COMPGAIN40K; //Based on known values (22 ohms - 100 ohms)
//			}
//			if(ImpResult[i].iRtia == 6) {
//				ImpResult[i].Mag = (ImpResult[i].Mag -
//						    COMPOFFSET80K)/COMPGAIN80K; //Based on known values (220 ohms - 1k ohms)
//			}
//			if(ImpResult[i].iRtia == 7) {
//				ImpResult[i].Mag = (ImpResult[i].Mag -
//						    COMPOFFSET160K)/COMPGAIN160K; //Based on known values (1.5k ohms - 3.3k ohms)
//			}
//			if(ImpResult[i].iRtia  == 8) {
//				ImpResult[i].Mag = (ImpResult[i].Mag -
//						    COMPOFFSET1MEG)/COMPGAIN1MEG; //Based on known values (4.7k ohms - 10Meg ohms)
//			}

//			if(ImpResult[i].iRtia  == 5) {
//			/* Based on known values (~22 ohms - 100 ohms) */
//				ImpResult[i].Mag = (ImpResult[i].Mag * COMPGAIN40K + COMPOFFSET40K);
//			}
//			if(ImpResult[i].iRtia  == 6) {
//			/* Based on known values (~220 ohms - 1k ohms) */
//				ImpResult[i].Mag = (ImpResult[i].Mag * COMPGAIN80K + COMPOFFSET80K);
//			}
//			if(ImpResult[i].iRtia  == 7) {
//			/* Based on known values (~1.5k ohms - 3.3k ohms) */
//				ImpResult[i].Mag = (ImpResult[i].Mag * COMPGAIN160K + COMPOFFSET160K);
//			}
//			if(ImpResult[i].iRtia  == 8) {
//			/* Based on known values (~4.7k ohms - 10Meg ohms) */
//				ImpResult[i].Mag = (ImpResult[i].Mag * COMPGAIN1MEG + COMPOFFSET1MEG);
//			}

			if(ImpResult[i].iRtia  == 5) {
			/* Based on known values (~22 ohms - 100 ohms) */
				ImpResult[i].Mag = (ImpResult[i].Mag * cfgInfo.compGain40K + cfgInfo.compOffset40K);
			}
			if(ImpResult[i].iRtia  == 6) {
			/* Based on known values (~220 ohms - 1k ohms) */
				ImpResult[i].Mag = (ImpResult[i].Mag * cfgInfo.compGain80K + cfgInfo.compOffset80K);
			}
			if(ImpResult[i].iRtia  == 7) {
			/* Based on known values (~1.5k ohms - 3.3k ohms) */
				ImpResult[i].Mag = (ImpResult[i].Mag * cfgInfo.compGain160K + cfgInfo.compOffset160K);
			}
			if(ImpResult[i].iRtia  == 8) {
			/* Based on known values (~4.7k ohms - 10Meg ohms) */
				ImpResult[i].Mag = (ImpResult[i].Mag * cfgInfo.compGain1M + cfgInfo.compOffset1M);
			}
#endif /*COMPRANGES*/
			/* Calculate compensated Real and Imaginary */
			/* Real RSnsLoad Impedance */
			ImpResult[i].DFT_result[0] = ImpResult[i].Mag * cos(
							     Var1);
			/* Imaginary RSnsLoad Impedance */
			ImpResult[i].DFT_result[1] = ImpResult[i].Mag * sin(
							     Var1);
		}
	}
	return 1;
}

/**
 * @brief float DFTtoCurrent(int32_t DFTres, uint8_t channel)
 *	======== Take results from DFT registers and convert to current.
 * @param DFTres :{}
 *	-DFT register value
 * @param channel :{0,1}
 *	-channel
 * @return DFTtoCurrent
 *	-float value of calculated current in amps
 */
float DFTtoCurrent (int32_t DFTres, uint8_t channel)
{
	float result;
	float PGAgain;
	float Rtia;

	//Enumerated in AfeAdcLib.c
	PGAgain = ((float) uiValGnPga_x2[uiGnPgaIndex])/2;

	//Enumerated in AfeTiaLib.c
	if(channel == 0 && flagHiZMode)
		Rtia = 10000000.0;
	else if(uiHpRtiaSeIndex == 8)
		Rtia = 1000000.0;
	else
		Rtia = (float) hprtiase_ohm[uiHpRtiaSeIndex];

	//Code to volts
	result = (float) convertDftToInt(DFTres);
	if (ATE_REV >= 0x4)
		result = 1.835*result;
	else if (ATE_REV >= 0x2)
		result = 1.82*result;
	else
		result = 1.8*result;

	result = result/131072; /* 2^17 because DFT is 18b result */
	/* divide by PGA gain, divide by RTia (inverting) */
	result = -(result / PGAgain) / Rtia;

	return result;
}

/**
 * @brief uint8_t ConnectSensor(RMeasType MType, uint8_t i, uint8_t channel
 *				ImpResult_t *ImpResult)
 *	Set switching matrix and gain switches for measurement.
 * @param i : {}
 *	- Index for ImpResult[]
 * @param MType :{}
 *	- Whether to measure Rsensor+Rload (0 or RSnsLoad), Rload (1 or RLoad),
 *	  or Rcal (2 or RCal)
 * @param channel :{}
 *	- Indicates which channel to connect
 * @param *ImpResult :{}
 *	- pointer to impedance result array populated with measurement
 *	  frequencies
 * @return 1.
 **/
uint8_t ConnectSensor(RMeasType MType, uint8_t i, uint8_t channel,
		      ImpResult_t *ImpResult)
{
	/***Switch matrix configurations for measurements***/
	uint32_t ctia = BITM_HPTIA_CTIA_16PF|BITM_HPTIA_CTIA_8PF|BITM_HPTIA_CTIA_4PF|
			BITM_HPTIA_CTIA_2PF|BITM_HPTIA_CTIA_1PF;

	/*By default, break LP TIA connection*/
	pADI_AFE->SWCON &= ~BITM_AFE_SWCON_SWSOURCESEL; /* clear SWCON[16] */
		/*set diode until switches are configured*/
	pADI_AFE->HSRTIACON |= BITM_AFE_HSRTIACON_TIASW6CON;
	/* add bias voltage to excitation sinewave */
	/* enable DC buffer for excitation loop */
	pADI_AFE->AFECON |= BITM_AFE_AFECON_DACBUFEN;
	if(channel>0) {
		/* set DC offset using LP DAC1 */
		pADI_AFE->DACDCBUFCON = ENUM_AFE_DACDCBUFCON_CHAN1;
		/* diagnostic mode, connects VZERO to HPTIA */
		pADI_AFE->LPDACCON1 |= LPDACSWDIAG;
		/*disconnect RTIA to avoid RC filter discharge*/
		AfeLpTiaCon(CHAN1,pSnsCfg1->Rload,LPTIA_RGAIN_DISCONNECT,pSnsCfg1->Rfilter);
	} else {
	/* set DC offset using LP DAC0 */
		pADI_AFE->DACDCBUFCON = ENUM_AFE_DACDCBUFCON_CHAN0;
		pADI_AFE->LPDACCON0 |= LPDACSWDIAG; /* diagnostic mode */
		/*disconnect RTIA to avoid RC filter discharge*/
		AfeLpTiaCon(CHAN0,pSnsCfg0->Rload,LPTIA_RGAIN_DISCONNECT,pSnsCfg0->Rfilter);
	}
	AfeLpTiaSwitchCfg(channel,SWMODE_AC); /*LP TIA disconnect sensor for AC test*/
	/*RSnsLoad*/
	if(MType == RSnsLoad) {
		/*********Sensor+Rload AC measurement*************/
		/*switch to sensor+rload*/
		if(channel>0) {
			/*AuxTemp (Resistive Temp Sensors) */
			AfeSwitchDPNT(SWID_ALLOPEN,SWID_P6_RE1|SWID_PL,SWID_N7_SE1RLOAD,
				      SWID_T7_SE1RLOAD|SWID_T9);/*2-terminal between RE1 and SE1*/
		} else {
			/* CHECK HI-Z Mode */
			if(flagHiZMode) { /* Connect external TIA */
				AfeSwitchDPNT(SWID_ALLOPEN,SWID_P5_RE0|SWID_PL,SWID_NL,
					      SWID_T9); /* Do not connect TIA switches */
				/* Set N amplifier input to VZERO0 */
				AfeHpTiaSeCfg(HPTIASE_RTIA_200,ctia,
					      BITM_AFE_HSRTIACON_TIASW6CON);
			} else {
				/* 3-terminal sensor: SWID_D5_CE0,SWID_P5_RE0,SWID_N5_SE0RLOAD,SWID_T5_SE0RLOAD|SWID_T9*/
				AfeSwitchDPNT(SWID_ALLOPEN,SWID_P5_RE0|SWID_PL,SWID_N5_SE0RLOAD,
					      SWID_T5_SE0RLOAD|SWID_T9);/*2 terminal b/w RE0 and SE0*/
			}
		}
	}

	/*RLoad*/
	else if(MType == RLoad) {
		/***************Rload AC measurement*************/
		/* This measurement only works for RTIA <=5k ohms (for 100 ohm Rload), otherwise it saturates. Taken care of in call function. */
		if(channel>0) {
			/*this stage measured Rload exclude PCB wires from SE to innner Rload*/
			AfeSwitchDPNT(SWID_D6_CE1,SWID_P9_WE1,SWID_N7_SE1RLOAD,
				      SWID_T7_SE1RLOAD|SWID_T9);
		} else {
			/*this stage measured Rload exclude PCB wires from SE to innner Rload*/
			AfeSwitchDPNT(SWID_D7_WE0,SWID_P7_WE0,SWID_N5_SE0RLOAD,
				      SWID_T5_SE0RLOAD|SWID_T9);
		}
		/*switch to rload*/
		/* Disable DC buffer for excitation loop */
		pADI_AFE->AFECON &= ~BITM_AFE_AFECON_DACBUFEN;
	}

	/*RCal*/
	else if(MType == RCal) {
		/************RCAL AC measurement***************/
		/*switch to RCAL, loop exitation before power up*/
/* General (200 ohms) - Use for <10k RTIA */
		if (uiHpRtiaSeIndex < 3) {
			AfeSwitchDPNT(SWID_DR0_RCAL0,SWID_PR0_RCAL0,SWID_NR1_RCAL1,
				      SWID_TR1_RCAL1|SWID_T9);
			ImpResult[i].iRcal = 0; /* Set RCal index */
		}
/* Aux1Cal (2k ohms) - Use for <100k RTIA. PGA gain is 1 at this point. */
		else if (uiHpRtiaSeIndex < 7) {
			AfeSwitchDPNT(SWID_D4_AIN3,SWID_P4_AIN3,SWID_NL,SWID_T6_DE0|SWID_T9);
			ImpResult[i].iRcal = 1; /* Set RCal index */
		}
/* Not used: Aux4Cal (1Meg ohms) - Good for <50Meg RTIA. Could use if external TIA is >10Meg or PGA is >1 and <9 */
		/* Switch code: AfeSwitchDPNT(SWID_ALLOPEN,SWID_P10_DE1|SWID_PL,SWID_N3_AIN2,SWID_T3_AIN2|SWID_T9)*/
		else {
/* Aux3Cal (200k ohms) - Good for <10Meg RTIA or 1Meg and Gain = 9 */
			if(uiGnPgaIndex > 0) {
				/* internal 1Meg and PGA > 1, use 200k Rcal */
				AfeSwitchDPNT(SWID_ALLOPEN,SWID_P8_DE0|SWID_PL,SWID_N3_AIN2,
					      SWID_T3_AIN2|SWID_T9);/*2-terminal between RE1 and SE1*/
				ImpResult[i].iRcal = 3; /* Set RCal index */
			}
//Aux2Cal (25.5k ohms) - Use for <1.275Meg RTIA or 160k and GPGA <=4
			else { /* 160k RTIA or 1Meg RTIA and G=1 PGA. Use 25k5 Rcal */
				AfeSwitchDPNT(SWID_D2_AIN1,SWID_P2_AIN1,SWID_N1_AIN0,SWID_T1_AIN0|SWID_T9);
				ImpResult[i].iRcal = 2; /* Set RCal index */
			}
		}
		/*TIA switch to normal mode plus SW10 to short CE and RE*/
		AfeLpTiaSwitchCfg(channel,SWMODE_NORM_CE_RE_SHORT);
		if(channel>0) {
			AfeLpTiaCon(CHAN1,pSnsCfg1->Rload,pSnsCfg1->Rtia,
				    pSnsCfg1->Rfilter); /* connect RTIA */
		} else {
			AfeLpTiaCon(CHAN0,pSnsCfg0->Rload,pSnsCfg0->Rtia,
				    pSnsCfg0->Rfilter); /* connect RTIA */
		}
	}

	/* Regardless of MType, if uiHpRtiaSeIndex = 8, connect external TIA resistor */
	/* Set DE1RESCON, HSRTIACON, DE0RESCON */
	AfeHpTiaDeCfg(0, HPTIADE_RLOAD_OPEN, HPTIADE_RTIA_OPEN);
	AfeHpTiaDeCfg(1, HPTIADE_RLOAD_OPEN, HPTIADE_RTIA_OPEN);
	if(uiHpRtiaSeIndex == 8) { /* Connect 1Meg */
		pADI_AFE->TSWFULLCON |= SWID_T3_AIN2; /* Connect AIN2 to input */
		/* Connect DE1 to output */
		AfeHpTiaDeCfg(1, HPTIADE_RLOAD_0, HPTIADE_RTIA_50);
		if(ImpResult[i].freq > 20000) /* 1pF */
			AfeHpTiaSeCfg(HPTIASE_RTIA_OPEN, BITM_HPTIA_CTIA_1PF,
				      BITM_AFE_HSRTIACON_TIASW6CON);
		else if(ImpResult[i].freq > 2000) /* 4pF */
			AfeHpTiaSeCfg(HPTIASE_RTIA_OPEN, BITM_HPTIA_CTIA_4PF,
				      BITM_AFE_HSRTIACON_TIASW6CON);
		else /* 31pF */
			AfeHpTiaSeCfg(HPTIASE_RTIA_OPEN,ctia,
				      BITM_AFE_HSRTIACON_TIASW6CON);
	}
	pADI_AFE->HSRTIACON &= ~BITM_AFE_HSRTIACON_TIASW6CON; /*disconnect diode*/
	pADI_AFE->SWCON = BITM_AFE_SWCON_SWSOURCESEL; /* update switch, */
	delay_10us(10000);
	return 1;
}

/**
 * @brief uint8_t SnsMeasure(uint8_t channel, uint32_t *pResult,
 *			     uint16_t iNumber)
 *	======== start DC measurement
 * @param channel :{0,1}
 *	- 0 Sensor channel 0
 *	- 1 Sensor channel 1
 * @param pResult: {}
 *	pointer to uint32_t which stores the sum of iNumber repeated
 *	measurements. Cast as float and divide by iNumber to get a true average.
 * @param iNumber: {0-65535}
 *	-  Data number will be measured
 * @return 1.
 */
uint8_t SnsMeasure(uint8_t channel, uint32_t *pResult, uint16_t iNumber)
{
	*pResult = 0;
	/*Sinc2 interrupt enable*/
	AfeAdcIntCfg(BITM_AFE_ADCINTIEN_SINC2RDYIEN);
	NVIC_EnableIRQ(AFE_ADC_IRQn);
	if(channel>0)
		AfeAdcChan(MUXSELP_LPTIA1_LPF,MUXSELN_VSET1P1);
	else
		AfeAdcChan(MUXSELP_AIN6,MUXSELN_VZERO0); /*connect buffer amp */
	AfeSysCfg(ENUM_AFE_PMBW_LP,ENUM_AFE_PMBW_BW50);
	AfeAdcPgaCfg(GNPGA_1,0);
	AfeAdcChopEn(1);
	AfeAdcPwrUp(BITM_AFE_AFECON_ADCEN);	//ADC Power Enable
	AfeAdcFiltCfg(SINC3OSR_4,SINC2OSR_1333,LFPBYPEN_NOBYP,ADCSAMPLERATE_800K);
	pADI_AFE->ADCINTSTA |= BITM_AFE_ADCINTSTA_SINC2RDY;
	sinc2Rdy = 0;
	AfeAdcSinc2Go(BITM_AFE_AFECON_ADCCONVEN);
	/* For low noise call with iNumber = 15 to average ADC data 15x.
	This gives 10Hz update rate to get extra 50 & 60Hz rejection */
	for(uint16_t ix=0; ix<iNumber; ix++) {
		while(!sinc2Rdy);
		sinc2Rdy = 0;
		*pResult = *pResult + pADI_AFE->SINC2DAT;
	}
	/* power down ADC */
	AfeAdcSinc2Go(ADCIDLE);
	AfeAdcPwrUp(0);
	return 1;
}

/**
 * @brief uint8_t CalibrateAdc()
 *	======== perform initial ADC calibration.
 * @return 1.
 */
uint8_t CalibrateAdc()
{
	int32_t iOffsetCal = 0;
	uint32_t iVGainCal = 0;
	uint32_t prevGain;
	float fVGainCal = 0;

	/*Sinc2 interrupt enable*/
	AfeAdcPwrUp(BITM_AFE_AFECON_ADCEN);
	AfeAdcIntCfg(BITM_AFE_ADCINTIEN_SINC2RDYIEN);
	NVIC_EnableIRQ(AFE_ADC_IRQn);
	prevGain = pADI_AFE->ADCGAINGN1;

	/* Reset previous calibrations */
	AfeCalRegWrite(AfeCalReg_ADCOFFSETGN1,0x0);
	AfeCalRegWrite(AfeCalReg_ADCGAINGN1,0x4000) ;

	/* Calibrate zero first */
	/* Both are ADCVBIAS_CAP (1.11V) */
	AfeAdcChan(MUXSELP_BIAS1,MUXSELN_VSET1P1);
	delay_10us(2000); /* 20mS */
	AfeSysCfg(ENUM_AFE_PMBW_LP,ENUM_AFE_PMBW_BW50);
	AfeAdcPgaCfg(GNPGA_1,0);
	AfeAdcChopEn(1);
	AfeAdcFiltCfg(SINC3OSR_4,SINC2OSR_1333,LFPBYPEN_NOBYP,ADCSAMPLERATE_800K);
	/* Clear SINC2 Filter bit to reset it */
	pADI_AFE->AFECON &= (~BITM_AFE_AFECON_SINC2EN);
	/* Clear conversion bit to restart SINC3 filter */
	pADI_AFE->AFECON &= (~BITM_AFE_AFECON_ADCCONVEN);
	pADI_AFE->ADCINTSTA = BITM_AFE_ADCINTSTA_SINC2RDY;
	sinc2Rdy = 0;
	delay_10us(2000);
	/* Re-enable SINC2 filter */
	pADI_AFE->AFECON |= BITM_AFE_AFECON_SINC2EN;
	AfeAdcSinc2Go(BITM_AFE_AFECON_ADCCONVEN);

	/* Read ADC data */
	while(!sinc2Rdy);
	sinc2Rdy = 0;
	iOffsetCal = pADI_AFE->SINC2DAT;
	/* power down ADC */
	AfeAdcSinc2Go(ADCIDLE);
	iOffsetCal = iOffsetCal - 32768; /* iOffsetCal = b */

	/* Calibrate gain second */
	AfeHPDacPwrUp(1); /* Power up HP reference */
	delay_10us(20);
	/* 1.82 - 1.11 = 0.71V differential */
	AfeAdcChan(MUXSELP_VREF1P8DAC,MUXSELN_VSET1P1);
	delay_10us(2000); /* 20mS */
	AfeSysCfg(ENUM_AFE_PMBW_LP,ENUM_AFE_PMBW_BW50);
	AfeAdcPgaCfg(GNPGA_1,0);
	AfeAdcChopEn(1);
	AfeAdcFiltCfg(SINC3OSR_4,SINC2OSR_1333,LFPBYPEN_NOBYP,ADCSAMPLERATE_800K);
	/* Clear SINC2 Filter bit to reset it */
	pADI_AFE->AFECON &= (~BITM_AFE_AFECON_SINC2EN);
	/* Clear conversion bit to restart SINC3 filter */
	pADI_AFE->AFECON &= (~BITM_AFE_AFECON_ADCCONVEN);
	pADI_AFE->ADCINTSTA = BITM_AFE_ADCINTSTA_SINC2RDY;
	sinc2Rdy = 0;
	delay_10us(2000);
	/* Re-enable SINC2 filter */
	pADI_AFE->AFECON |= BITM_AFE_AFECON_SINC2EN;
	AfeAdcSinc2Go(BITM_AFE_AFECON_ADCCONVEN);

	/* Read ADC data */
	while(!sinc2Rdy);
	sinc2Rdy = 0;
	iVGainCal = pADI_AFE->SINC2DAT;
	/* power down ADC */
	AfeAdcSinc2Go(ADCIDLE);
	AfeAdcPwrUp(0);
	AfeHPDacPwrUp(0);

	/***Calibration Procedure
	 *Given points (C1, V1), (C2, V2), slope = (C1 - C2)/(V1 - V2)
	 *slope is ideally 2^15/1.835. measuredslope * adjustment = 2^15/1.835
	 *code = adjustment * 0x7FFF/2 (because adjustment range goes from 0-2
	 *for codes 0x0 to 0x7FFF)
	 */
	/* calculate actual slope */
	fVGainCal = ((float)(iOffsetCal + 32768) - (float)iVGainCal)/(0 - 0.71);
	/* calculate adjustment multiplier (should be between 0 and 2)
	   17857.2 = 2^15/1.835 */
	fVGainCal = 17857.2/fVGainCal;
	if(fVGainCal < 2 && fVGainCal > 0)
		fVGainCal = fVGainCal * 32767 / 2; /* calculate code */
	else
		fVGainCal = (float) prevGain; /* Failed. Set to previous. */
	iVGainCal = (uint16_t) fVGainCal & 0x7FFF;

	/* offset is twos complement. Take advantage of signed int. */
	iOffsetCal = ((0 - iOffsetCal) << 2)&0x7FFF;
	/* Write to offset cal register */
	AfeCalRegWrite(AfeCalReg_ADCOFFSETGN1,iOffsetCal);
	/* Write to gain cal register */
	if(iVGainCal > 0x0) { /* Avoid illegal value */
		AfeCalRegWrite(AfeCalReg_ADCGAINGN1,iVGainCal) ;
	}
	return 1;
}

/**@}*/
