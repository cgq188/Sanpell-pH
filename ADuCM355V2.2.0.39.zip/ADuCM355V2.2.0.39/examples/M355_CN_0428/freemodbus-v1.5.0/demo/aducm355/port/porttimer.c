

/* ----------------------- Platform includes --------------------------------*/
#include "mb.h"
#include "mbport.h"
#include "port.h"
#include <ADuCM355.h>
#include "stdbool.h"
#include "ClkLib.h"
#include "GptLib.h"


/* ----------------------- Defines ------------------------------------------*/
/* Timer ticks are counted in multiples of 50us. Therefore 20000 ticks are
 * one second.
 */
#define MB_TIMER_TICKS          ( 20000L )

/* ----------------------- Static variables ---------------------------------*/
static USHORT   usTimerOCRADelta;
static USHORT   usTimerOCRBDelta;

/* ----------------------- Start implementation -----------------------------*/
BOOL xMBPortTimersInit( USHORT usTim1Timeout50us )
{
	BOOL            bInitialized = TRUE;

//	ClkGateSet(  CLK_GATE_GPT0,   false);

	//Timer 0 setup to re-start every 64mS
	//设置定时器0，使用26mhz时钟源，周期 = 16mhz/256分频/(0x1000/6)= 64/6ms周期,重载模式，向上计数
	GptLd(pADI_TMR0,0x1000/((float)6*26/16));		  // Time-out period of 256 clock pulese

	GptCfg(pADI_TMR0,TCTL_CLK_HFOSC,TCTL_PRE_DIV256,BITM_TMR_CTL_MODE|BITM_TMR_CTL_RLD);  // T0 config, Uclk/256,


	return bInitialized;
}

void vMBPortTimersEnable( void )
{
	NVIC_DisableIRQ(TMR0_EVT_IRQn);

	GptCfg(pADI_TMR0,TCTL_CLK_HFOSC,TCTL_PRE_DIV256,BITM_TMR_CTL_MODE|BITM_TMR_CTL_RLD);  // T0 config, Uclk/256,


    GptLd(pADI_TMR0,0x1000/((float)6*26/16));		  // Time-out period of 256 clock pulese
	GptCfg(pADI_TMR0,TCTL_CLK_HFOSC,TCTL_PRE_DIV256,BITM_TMR_CTL_MODE|BITM_TMR_CTL_RLD|BITM_TMR_CTL_EN);  // T0 config, Uclk/256,

	NVIC_EnableIRQ(TMR0_EVT_IRQn);                          // Enable Timer0 IRQ
}

void vMBPortTimersDisable( void )
{
	GptCfg(pADI_TMR0,TCTL_CLK_HFOSC,TCTL_PRE_DIV256,BITM_TMR_CTL_MODE|BITM_TMR_CTL_RLD);  // T0 config, Uclk/256,

	NVIC_DisableIRQ(TMR0_EVT_IRQn);                          // Disable Timer0 IRQ
}


#define portNVIC_INT_CTRL_REG		( * ( ( volatile uint32_t * ) 0xe000ed04 ) )
#define portNVIC_PENDSVSET_BIT		( 1UL << 28UL )

void GP_Tmr0_Int_Handler(void)
{
	GptClrInt(pADI_TMR0,BITM_TMR_CLRINT_TIMEOUT);
	( void )pxMBPortCBTimerExpired(  );

	//trigger penscv
	( * ( ( volatile uint32_t * ) 0xe000ed04 ) ) = ( 1UL << 28UL );
	__DSB();
	__ISB();
}


