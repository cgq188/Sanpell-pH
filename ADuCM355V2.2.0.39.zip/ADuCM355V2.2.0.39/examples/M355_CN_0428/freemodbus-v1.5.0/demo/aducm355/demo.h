/*
 * demo.h
 *
 *  Created on: 2022年3月7日
 *      Author: jason
 */

#ifndef FREEMODBUS_V1_5_0_DEMO_ADUCM360_DEMO_H_
#define FREEMODBUS_V1_5_0_DEMO_ADUCM360_DEMO_H_

#include "port.h"

#ifdef __cplusplus
PR_BEGIN_EXTERN_C
#endif

void rtu_con_set(float val);
void rtu_temperature_set(float val);

#ifdef __cplusplus
PR_END_EXTERN_C
#endif

#endif /* FREEMODBUS_V1_5_0_DEMO_ADUCM360_DEMO_H_ */
