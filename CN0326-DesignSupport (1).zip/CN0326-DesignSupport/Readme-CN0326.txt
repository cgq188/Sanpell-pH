Analog Devices Inc.
Design Support Package
CN-0326
09/12/2013
Rev. A


This file is designed to provide you with a brief overview of what is contained within the circuit note design support package.


**********************
*******Overview*******
**********************


CN-0326 Design Support Package contains: 
	
	Link to Circuit Note
	Link to Product Datasheets
	Link to Product Evaluation Boards and User Guides
	Cadence Schematics
	Bill of Materials
	Assembly Drawings
	Cadence Layout Files
	Gerber Layout Files	
	Link to Symbols and Footprints
	Link to Technical Support
	Link to Other Resources
	Calibration Text Format
	NIST Buffer Solution Table Format



**********************
***File Explanation**
**********************


Circuit Note - Copy of the circuit note this design support package was made for.  This file is provided as a PDF:

	CN0326: http://www.analog.com/CN0326


Product Datasheets - Links to all ADI component datasheets used in the circuit.  These files are provided as a PDF:
	
	AD7793	 :http://www.analog.com/ad7793
	ADUM5401 :http://www.analog.com/adum5401
	AD8603   :http://www.analog.com/ad8603

CN0326 	Evaluation Board:
	 
	EVAL-CN0326-SDPZ: http://www.analog.com/EVAL-CN0326-PMDZ


Software for CN0326 Evaluation Board:

	ftp://ftp.analog.com/pub/cftl/CN0326

System Demonstration Platform:

	EVAL-SDP-CB1Z: http://www.analog.com/EVAL-SDP-CB1Z
	EVAL-SDP-CS1Z: http://www.analog.com/EVAL-SDP-CS1Z
	

Bill of Materials for EVAL-CN0326-PMDZ:

	
	EVAL-CN0326-PMDZ-BOM-RevA.xls
	EVAL-CN0326-PMDZ-BOM-RevA.pdf


Assembly Drawing


	EVAL-CN0326-PMDZ-AssemblyDrawing-RevA.pdf


Schematic Drawings (CADENCE) for EVAL-CN0326-PMDZ:


	EVAL-CN0326-PMDZ-CadenceSchematic-RevA.pdf
	EVAL-CN0326-PMDZ-CadenceSchematic-RevA


Layout Drawings (CADENCE) for EVAL-CN0326-PMDZ:


	EVAL-CN0326-PMDZ-CadenceLayout-RevA.brd
	EVAL-CN0326-PMDZ-CadenceLayout-RevA.pdf
	
	
Gerber Layout Files:


	EVAL-CN0326-PMDZ-GBR-RevA


Calibration Text Format

	Sample of a text format for calibration setup

NIST Buffer Solution Table Format

	Contains the file that can be used as a format to input a custom buffer solution temperature coefficient.
	
	

Technical Support -  If you require further technical assistance please contact us by phone, email, or our EngineerZone community.  http://www.analog.com/en/content/technical_support_page/fca.html



**********************
***Other Resources****
**********************


Resources that are not provided by Analog Devices, but could be helpful.


Gerber Viewer:  http://www.graphicode.com

PADs Viewer: http://www.mentor.com/products/pcb-system-design/design-flows/pads/pads-pcb-viewer

Allegro Physical Viewer: http://www.cadence.com/products/pcb/Pages/downloads.aspx


