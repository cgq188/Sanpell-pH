//SHW080926

#include "stdafx.h"
#include "OEM.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////////
BYTE	g_ImageBufferReal[98 * 1024 + 8];
#define g_ImageBuffer (&g_ImageBufferReal[4])

BYTE	gbyImg8bit[IMG8BIT_SIZE];
BYTE	gbyImgRaw[320 * 240];
BYTE	gbyImgRawOrg[320 * 240];
BYTE	gbyTemplate[FP_TEMPLATE_SIZE];

BYTE	timages[5][96 * 112];

WORD gwDevID = 1;
WORD gwLastAck = 0;
int  gwLastAckParam = 0;
int  gnPassedTime = 0;

devinfo gDevInfo;

//////////////////////////////////////////////////////////////////////////
int oem_CommandRun(WORD wCmd, int nCmdParam)
{
	if( oemp_SendCmdOrAck( gwDevID, wCmd, nCmdParam ) < 0 )
		return OEM_COMM_ERR;
	gnPassedTime = GetTickCount();
	if( oemp_ReceiveCmdOrAck( gwDevID, &gwLastAck, &gwLastAckParam ) < 0 )
		return OEM_COMM_ERR;
	gnPassedTime = GetTickCount() - gnPassedTime;
	return 0;
}

int oem_open( void )
{
	if (oem_CommandRun( CMD_OPEN, 1 ) < 0 )
		return OEM_COMM_ERR;

	if (oemp_ReceiveData(gwDevID, g_ImageBuffer, sizeof(devinfo)) < 0)
		return OEM_COMM_ERR;
	memcpy(&gDevInfo, g_ImageBuffer, sizeof(devinfo));
	return 0;
}

int oem_close( void )
{
	return oem_CommandRun( CMD_CLOSE, 0);
}

extern DWORD gCommTimeOut;
int oem_usb_internal_check( void ){
	
	DWORD prevCommTimeOut = gCommTimeOut;
	gCommTimeOut = 5000;
	
	int ret = oem_CommandRun( CMD_USB_INTERNAL_CHECK, gwDevID );
	
	gCommTimeOut = prevCommTimeOut;
	return ret;
}

int oem_change_baudrate( int nBaudrate )
{
	return oem_CommandRun( CMD_CHANGE_BAUDRATE, nBaudrate );
}

int oem_enroll_count( void )
{
	return oem_CommandRun( CMD_ENROLL_COUNT, 0 );
}

int oem_check_enrolled( int nPos )
{
	return oem_CommandRun( CMD_CHECK_ENROLLED, nPos );
}

int oem_enroll_start( int nPos )
{
	return oem_CommandRun( CMD_ENROLL_START, nPos );
}

int oem_enroll_nth()
{
	return oem_CommandRun( CMD_ENROLL_START + 1, 0 );
}

int oem_enroll_finish()
{
	return oem_CommandRun(CMD_ENROLL_FINISH, 0);
}

int oem_is_press_finger( void )
{
	return oem_CommandRun( CMD_IS_PRESS_FINGER, 0 );
}

int oem_delete( int nPos )
{
	return oem_CommandRun( CMD_DELETE, nPos );
}

int oem_delete_all( void )
{
	return oem_CommandRun( CMD_DELETE_ALL, 0 );
}

int oem_verify( int nPos )
{
	return oem_CommandRun( CMD_VERIFY, nPos );
}

int oem_identify( void )
{
	return oem_CommandRun( CMD_IDENTIFY, 0 );
}

int oem_verify_template( int nPos )
{
	if( oem_CommandRun( CMD_VERIFY_TEMPLATE, nPos ) < 0 )
		return OEM_COMM_ERR;
	
	if(gwLastAck == ACK_OK)
	{
		memcpy(g_ImageBuffer, &gbyTemplate[0], FP_TEMPLATE_SIZE);
		if (oemp_SendData(gwDevID, g_ImageBuffer, FP_TEMPLATE_SIZE) < 0)
			return OEM_COMM_ERR;
		
		gnPassedTime = GetTickCount();
		if( oemp_ReceiveCmdOrAck( gwDevID, &gwLastAck, &gwLastAckParam ) < 0 )
			return OEM_COMM_ERR;
		gnPassedTime = GetTickCount() - gnPassedTime;
	}
	
	return 0;
}

int oem_identify_template( void )
{
	if( oem_CommandRun( CMD_IDENTIFY_TEMPLATE, 0 ) < 0 )
		return OEM_COMM_ERR;
	
	if(gwLastAck == ACK_OK)
	{
		memcpy(g_ImageBuffer, &gbyTemplate[0], FP_TEMPLATE_SIZE);
		if (oemp_SendData(gwDevID, g_ImageBuffer, FP_TEMPLATE_SIZE) < 0)
			return OEM_COMM_ERR;
		
		gnPassedTime = GetTickCount();
		if( oemp_ReceiveCmdOrAck( gwDevID, &gwLastAck, &gwLastAckParam ) < 0 )
			return OEM_COMM_ERR;
		gnPassedTime = GetTickCount() - gnPassedTime;
	}
	
	return 0;
}

int oem_capture(int Time_Limit)
{
	// check command
	if (oem_CommandRun(CMD_CAPTURE, Time_Limit) < 0)
		return OEM_COMM_ERR;
	if (gwLastAck != ACK_OK)
		return 0;

	// check wait touch
	if (oemp_ReceiveCmdOrAck(gwDevID, &gwLastAck, &gwLastAckParam) < 0)
		return OEM_COMM_ERR;
	if (gwLastAck != ACK_OK)
		return 0;

	// check result
	if (oemp_ReceiveCmdOrAck(gwDevID, &gwLastAck, &gwLastAckParam) < 0)
		return OEM_COMM_ERR;
	if (gwLastAck != ACK_OK)
		return 0;

	// receive image
	if (oemp_ReceiveData(gwDevID, g_ImageBuffer, RAWIMG_CX * RAWIMG_CY + 100) < 0)
		return OEM_COMM_ERR;
	memcpy(gbyImgRawOrg, g_ImageBuffer, RAWIMG_CX * RAWIMG_CY);
	{
		int i, j;
		UINT8* pdst = gbyImgRaw;
		for (i = 0; i < RAWIMG_CY; i++)
		{
			UINT8* psrc = gbyImgRawOrg + (RAWIMG_CY - 1 - i);
			for (j = 0; j < RAWIMG_CX; j++)
			{
				*pdst++ = *psrc;
				psrc += RAWIMG_CY;
			}
		}
	}
	return 0;
}

int oem_get_image( int param )
{
	// check command
	if (oem_CommandRun(CMD_GET_IMAGE, (int)param) < 0)
		return OEM_COMM_ERR;
	if (gwLastAck != ACK_OK)
		return 0;

	// check wait touch
	if (oemp_ReceiveCmdOrAck(gwDevID, &gwLastAck, &gwLastAckParam) < 0)
		return OEM_COMM_ERR;
	if (gwLastAck != ACK_OK)
		return gwLastAckParam;

	// receive raw images
	if (param) {
		for (int tt = 0; tt < 3; tt++) {
			if (oemp_ReceiveData(gwDevID, g_ImageBuffer, RAWIMG_CX * RAWIMG_CY+100) < 0)
				return OEM_COMM_ERR;

			memcpy(gbyImgRawOrg, g_ImageBuffer, RAWIMG_CX * RAWIMG_CY);

			int i, j;
			UINT8* pdst = timages[tt];
			for (i = 0; i < RAWIMG_CY; i++)
			{
				UINT8* psrc = gbyImgRawOrg + (RAWIMG_CY - 1 - i);
				for (j = 0; j < RAWIMG_CX; j++)
				{
					*(pdst++) = 255 - *psrc;
					psrc += RAWIMG_CY;
				}
			}
		}
	}

	// check result
	if (oemp_ReceiveCmdOrAck(gwDevID, &gwLastAck, &gwLastAckParam) < 0)
		return OEM_COMM_ERR;
	if (gwLastAck != ACK_OK)
		return gwLastAckParam;

	/// Receive Final Image
	if (oemp_ReceiveData(gwDevID, g_ImageBuffer, RAWIMG_CX * RAWIMG_CY+100) < 0)
		return OEM_COMM_ERR;

	memcpy(gbyImgRawOrg, g_ImageBuffer, RAWIMG_CX * RAWIMG_CY);

	int i, j;
	UINT8* pdst = gbyImgRaw;
	for (i = 0; i < RAWIMG_CY; i++)
	{
		UINT8* psrc = gbyImgRawOrg + (RAWIMG_CY - 1 - i);
		for (j = 0; j < RAWIMG_CX; j++)
		{
			*(pdst++) = *psrc;
			psrc += RAWIMG_CY;
		}
	}

	if (param){
		memcpy(timages[3], gbyImgRaw, RAWIMG_CX*RAWIMG_CY);
	}

	return 0;
}

int oem_get_rawimage(unsigned char dacp_val, unsigned char reg31_val, unsigned char reg32_val)
{
	DWORD param = (((DWORD)dacp_val) << 0) + (((DWORD)reg31_val) << 8) + (((DWORD)reg32_val) << 16);
	if( oem_CommandRun( CMD_GET_RAWIMAGE, (int)param) < 0 )
		return OEM_COMM_ERR;
	if (gwLastAck != ACK_OK)
		return 0;
	if( oemp_ReceiveData( gwDevID, g_ImageBuffer, RAWIMG_CX * RAWIMG_CY + 100) < 0 )
		return OEM_COMM_ERR;
	memcpy(gbyImgRawOrg, g_ImageBuffer, RAWIMG_CX * RAWIMG_CY);
	{
		int i, j;
		UINT8* pdst = gbyImgRaw;
		for (i = 0; i < RAWIMG_CY; i++)
		{
			UINT8* psrc = gbyImgRawOrg + (RAWIMG_CY - 1 - i);
			for (j = 0; j < RAWIMG_CX; j++)
			{
#if defined(BS510_8MM)
				*pdst++ = *psrc;
#else
				*pdst++ = 255 - *psrc;
#endif
				psrc += RAWIMG_CY;
			}
		}
	}
	return 0;
}

int oem_download_image(unsigned char* img){
	if (oem_CommandRun(CMD_DOWNLOAD_IMAGE, 0) < 0)
		return OEM_COMM_ERR;
	if (gwLastAck == ACK_OK){
		memcpy(g_ImageBuffer, img, RAWIMG_CX*RAWIMG_CY);

		int i, j;
		UINT8* pdst = g_ImageBuffer;
		for (i = 0; i < RAWIMG_CX; i++)
		{
			UINT8* psrc = img + RAWIMG_CX*(RAWIMG_CY-1) + i;
			for (j = 0; j < RAWIMG_CY; j++)
			{
				*(pdst++) = *psrc;
				psrc -= RAWIMG_CX;
			}
		}

		oemp_SendData(gwDevID, g_ImageBuffer, RAWIMG_CX*RAWIMG_CY + 100);
	}
	return 0;
}

int oem_get_template( int nPos )
{
	if( oem_CommandRun( CMD_GET_TEMPLATE, nPos ) < 0 )
		return OEM_COMM_ERR;

	if(gwLastAck == ACK_OK)
	{
		if( oemp_ReceiveData( gwDevID, g_ImageBuffer, FP_TEMPLATE_SIZE ) < 0 )
			return OEM_COMM_ERR;
		memcpy(&gbyTemplate[0], g_ImageBuffer, FP_TEMPLATE_SIZE);
	}
	
	return 0;
}

int oem_add_template( int nPos )
{
	if( oem_CommandRun( CMD_ADD_TEMPLATE, nPos ) < 0 )
		return OEM_COMM_ERR;
	
	if(gwLastAck == ACK_OK)
	{
		memcpy(g_ImageBuffer, &gbyTemplate[0], FP_TEMPLATE_SIZE);
		if (oemp_SendData(gwDevID, g_ImageBuffer, FP_TEMPLATE_SIZE) < 0)
			return OEM_COMM_ERR;
		
		if( oemp_ReceiveCmdOrAck( gwDevID, &gwLastAck, &gwLastAckParam ) < 0 )
			return OEM_COMM_ERR;
	}
	
	return 0;
}

int oem_fw_upgrade(BOOL bRestartOnly)
{
	return oem_CommandRun(CMD_FW_UPDATE, bRestartOnly);
}

int oem_read_uid(byte* uid_data){
	if (oem_CommandRun(CMD_READ_IMEI_INFO, 0) < 0) return -1;
	if (oemp_ReceiveData(gwDevID, uid_data, 16) < 0)
		return OEM_COMM_ERR;

	if (oemp_ReceiveCmdOrAck(gwDevID, &gwLastAck, &gwLastAckParam) < 0)
		return OEM_COMM_ERR;

	return 0;
}

byte tbuf[1000];

int star_SendData(byte* send_data, int send_size, int send_step){
	byte* sbuf = tbuf + 4;

	int cou = send_size / send_step;
	int pos = 0;
	for (int i = 0; i < cou; i++){
		memcpy(sbuf, send_data + pos, send_step);
		if (oemp_SendData(gwDevID, sbuf, send_step) < 0) return OEM_COMM_ERR;
		pos += send_step;
	}
	int rem = send_size - send_step * cou;
	if (rem > 0){
		memcpy(sbuf, send_data + pos, rem);
		if (oemp_SendData(gwDevID, sbuf, rem) < 0) return OEM_COMM_ERR;
	}
	return 0;
}

int oem_write_license(byte* license_data)
{
	if (oem_CommandRun(CMD_WRITE_LICENSE, 0) < 0) return -1;

	oemp_SendData(gwDevID, license_data, 2056);

	if (oemp_ReceiveCmdOrAck(gwDevID, &gwLastAck, &gwLastAckParam) < 0)
		return OEM_COMM_ERR;
	return gwLastAckParam;
}

#define BLK_SIZE	8
bool oem_check_is_press_fp(int percent)
{
	int i, j, cnt = 0;
	int tcnt = RAWIMG_CY / BLK_SIZE * RAWIMG_CX / BLK_SIZE;

	for (i=0; i < RAWIMG_CY / BLK_SIZE; i++)
	{
		for (j = 0; j < RAWIMG_CX / BLK_SIZE; j++)
		{
			int k,l,b = 0;
			for (k = 0; k < BLK_SIZE; k++)
			{
				BYTE* p = &gbyImgRaw[(i * BLK_SIZE + k) * RAWIMG_CX + (j * BLK_SIZE)];
				for (l = 0; l < BLK_SIZE; l++)
				{
					b += *p++;
				}
			}

			if (b / BLK_SIZE / BLK_SIZE < 240)
			{
				cnt++;
			}
		}
	}

	return (cnt * 100 / tcnt) > percent;
}
