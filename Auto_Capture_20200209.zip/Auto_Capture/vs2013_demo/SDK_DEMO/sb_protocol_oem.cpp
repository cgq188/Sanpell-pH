///////////     Insert the code     ///////////
#include "stdafx.h"
#include "OEM.h"

///////////////////////////////////////////////
#define COMM_DEF_TIMEOUT 15000
DWORD gCommTimeOut = COMM_DEF_TIMEOUT;

WORD oemp_CalcChkSumOfCmdAckPkt( SB_OEM_PKT* pPkt )
{
	WORD wChkSum = 0;
	BYTE* pBuf = (BYTE*)pPkt;
	int i;
	
	for(i=0;i<(sizeof(SB_OEM_PKT)-SB_OEM_CHK_SUM_SIZE);i++)
		wChkSum += pBuf[i];
	return wChkSum;
}

WORD oemp_CalcChkSumOfDataPkt( BYTE* pDataPkt, int nSize )
{
	int i;
	WORD wChkSum = 0;
	BYTE* pBuf = (BYTE*)pDataPkt;
	
	for(i=0;i<nSize;i++)
		wChkSum += pBuf[i];
	return wChkSum;
}

int oemp_CheckCmdAckPkt( WORD wDevID, SB_OEM_PKT* pPkt )
{
	if( ( pPkt->Head1 != STX1 ) || 
		( pPkt->Head2 != STX2 ) )
	{
		return PKT_HDR_ERR;
	}
	
	if( pPkt->wDevId != wDevID ) 
		return PKT_DEV_ID_ERR;
	
	if( pPkt->wChkSum != oemp_CalcChkSumOfCmdAckPkt( pPkt ) ) 
		return PKT_CHK_SUM_ERR;

	return 0;
}

int oemp_SendCmdOrAck( WORD wDevID, WORD wCmdOrAck, int nParam )
{
	Sleep(5);

	SB_OEM_PKT pkt;
	int nSentBytes;

	pkt.Head1 = (BYTE)STX1;
	pkt.Head2 = (BYTE)STX2;
	pkt.wDevId = wDevID;
	pkt.wCmd = wCmdOrAck;
	pkt.nParam = nParam;
	pkt.wChkSum = oemp_CalcChkSumOfCmdAckPkt( &pkt );

	nSentBytes = comm_send( (BYTE*)&pkt, SB_OEM_PKT_SIZE, gCommTimeOut );
	if( nSentBytes != SB_OEM_PKT_SIZE )
		return PKT_COMM_ERR;

	return 0;
}

int oemp_ReceiveCmdOrAck( WORD wDevID, WORD* pwCmdOrAck, int* pnParam )
{
	Sleep(5);

	SB_OEM_PKT pkt;
	int nReceivedBytes;
		
	if( ( pwCmdOrAck == NULL ) || 
		( pnParam == NULL ) )
	{
		return PKT_PARAM_ERR;
	}

	nReceivedBytes = comm_recv( (BYTE*)&pkt, SB_OEM_PKT_SIZE, gCommTimeOut );
	if( nReceivedBytes != SB_OEM_PKT_SIZE )
		return PKT_COMM_ERR;
	
	if( ( pkt.Head1 != STX1 ) || 
		( pkt.Head2 != STX2 ) )
	{
		return PKT_HDR_ERR;
	}

	if( pkt.wDevId != wDevID ) 
		return PKT_DEV_ID_ERR;

	if( pkt.wChkSum != oemp_CalcChkSumOfCmdAckPkt( &pkt ) ) 
		return PKT_CHK_SUM_ERR;
	
	*pwCmdOrAck = pkt.wCmd;
	*pnParam = pkt.nParam;
	
	return 0;
}

int oemp_SendData( WORD wDevID, BYTE* pBuf, int nSize )
{
	Sleep(5);

	WORD wChkSum = 0;
	BYTE* Buf = pBuf - 4;
	int nSentBytes;
	
	if( pBuf == NULL )
		return PKT_PARAM_ERR;
	
	Buf[0] = (BYTE)STX3;
	Buf[1] = (BYTE)STX4;
	*((WORD*)(&Buf[SB_OEM_HEADER_SIZE])) = wDevID;
	
	wChkSum = oemp_CalcChkSumOfDataPkt( Buf, SB_OEM_HEADER_SIZE+SB_OEM_DEV_ID_SIZE  );
	wChkSum += oemp_CalcChkSumOfDataPkt( pBuf, nSize );
	
	pBuf[nSize] = LOBYTE(wChkSum);
	pBuf[nSize + 1] = HIBYTE(wChkSum);

	nSentBytes = comm_send( pBuf - 4, nSize + 6, gCommTimeOut );
	if( nSentBytes != nSize + 6 )
		return PKT_COMM_ERR;
	
	return 0;
}

int oemp_ReceiveData( WORD wDevID, BYTE* pBuf, int nSize )
{
	Sleep(5);

	WORD wReceivedChkSum, wChkSum;
	BYTE* Buf = pBuf - 4;
	int nReceivedBytes;
	
	if( pBuf == NULL )
		return PKT_PARAM_ERR;
	
	nReceivedBytes = comm_recv( pBuf - 4, nSize + 6, gCommTimeOut );
	if( nReceivedBytes != nSize + 6 )
		return PKT_COMM_ERR;

	wReceivedChkSum = MAKEWORD(pBuf[nSize], pBuf[nSize + 1]);

	if( ( Buf[0] != STX3 ) || 
		( Buf[1] != STX4 ) )
	{
		return PKT_HDR_ERR;
	}
	
	if( *((WORD*)(&Buf[SB_OEM_HEADER_SIZE])) != wDevID ) 
		return PKT_DEV_ID_ERR;
	
	wChkSum = oemp_CalcChkSumOfDataPkt( Buf, SB_OEM_HEADER_SIZE+SB_OEM_DEV_ID_SIZE  );
	wChkSum += oemp_CalcChkSumOfDataPkt( pBuf, nSize );
	
	if( wChkSum != wReceivedChkSum ) 
		return PKT_CHK_SUM_ERR;
	
	return 0;
}
