﻿
// SDK_DEMODlg.cpp : implementation file
//

#include "stdafx.h"
#include "SDK_DEMO.h"
#include "SDK_DEMODlg.h"
#include "OEM.h"
#include <fstream>
#include <string>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

/************************************************************************/
/*                                                                      */
/************************************************************************/
#pragma pack(1)
struct FP_BITMAP
{
	BITMAPFILEHEADER bmfHdr;
	BITMAPINFO bmInfo;
	RGBQUAD bmiColors[255];
	
	FP_BITMAP(int cx, int cy)
	{
		bmfHdr.bfType = ((WORD) ('M' << 8) | 'B');  // "BM"
		bmfHdr.bfSize = sizeof(FP_BITMAP) + cx*cy;
		bmfHdr.bfReserved1 = 0;
		bmfHdr.bfReserved2 = 0;
		bmfHdr.bfOffBits = sizeof(FP_BITMAP);
		
		bmInfo.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
		bmInfo.bmiHeader.biWidth = cx;
		bmInfo.bmiHeader.biHeight	= -cy;
		bmInfo.bmiHeader.biPlanes	= 1;
		bmInfo.bmiHeader.biBitCount = 8;
		bmInfo.bmiHeader.biCompression = 0;
		bmInfo.bmiHeader.biSizeImage = cx*cy;
		bmInfo.bmiHeader.biXPelsPerMeter = 0;
		bmInfo.bmiHeader.biYPelsPerMeter = 0;
		bmInfo.bmiHeader.biClrUsed = 0;
		bmInfo.bmiHeader.biClrImportant = 0;
		
		RGBQUAD *pals = bmInfo.bmiColors;
		for (int i = 0; i < 256; i++) {
			pals[i].rgbBlue = i;
			pals[i].rgbGreen = i;
			pals[i].rgbRed = i;
			pals[i].rgbReserved = 0;
		}
	}
};
#pragma pack()

FP_BITMAP fp_bmp256(CONVIMG_CX, CONVIMG_CY);
FP_BITMAP fp_bmpraw(RAWIMG_CX, RAWIMG_CY);


int g_Identify_Tot_Count = 0;
int g_Identify_Pass_Count = 0;
int g_Identify_Fail_Count = 0;

void fp_bmp_draw(HDC hdc, const FP_BITMAP* fp_bmp, void* p, int x, int y, int cx, int cy)
{
	SetStretchBltMode(hdc, COLORONCOLOR);
	
	StretchDIBits(hdc, x, y, cx, cy,
		0, 0, fp_bmp->bmInfo.bmiHeader.biWidth, abs(fp_bmp->bmInfo.bmiHeader.biHeight),
		p, &fp_bmp->bmInfo,
		DIB_RGB_COLORS, SRCCOPY);
}

BOOL fp_bmp_save(LPCTSTR szFilePath, FP_BITMAP* fp_bmp, void* p)
{
	CFile f;
	if(!f.Open(szFilePath, CFile::typeBinary | CFile::modeCreate | CFile::modeWrite))
		return FALSE;
	
	int w = fp_bmp->bmInfo.bmiHeader.biWidth;
	int h_org = fp_bmp->bmInfo.bmiHeader.biHeight;
	int h = abs(h_org);
	
	fp_bmp->bmInfo.bmiHeader.biHeight = h;
	f.Write(fp_bmp, sizeof(FP_BITMAP));
	fp_bmp->bmInfo.bmiHeader.biHeight = h_org;
	
	int i;
	for (i=h-1; i>=0; i--)
		f.Write((BYTE*)p + i*w, w);
	
	f.Close();
	
	return TRUE;
}

BOOL fp_bmp_read(LPCTSTR szFilePath, FP_BITMAP* fp_bmp, void* p)
{
	CFile f;
	if (!f.Open(szFilePath, CFile::typeBinary | CFile::modeRead))
		return FALSE;

	int w, h;

	f.Read(p, sizeof(FP_BITMAP));
	FP_BITMAP* tbmp = (FP_BITMAP*)p;
	w = tbmp->bmInfo.bmiHeader.biWidth;
	h = tbmp->bmInfo.bmiHeader.biHeight;
	if (h < 0) h = -h;

	if (w != fp_bmp->bmInfo.bmiHeader.biWidth) return FALSE;
	if (h != abs(fp_bmp->bmInfo.bmiHeader.biHeight)) return FALSE;

	int i;
	for (i = h - 1; i >= 0; i--)
		f.Read((BYTE*)p + i*w, w);

	f.Close();

	return TRUE;
}

enum
{
	fp_bmp_none,
	fp_bmp_256,	
	fp_bmp_raw,	
};

int gImageType = fp_bmp_none;

#if defined(BS510_8MM)
#  define MAGRAW	1
#else
#  define MAGRAW	2
#endif
#define TOP		10
#define TOPRAW	(TOP + (256-(RAWIMG_CY*MAGRAW))/2)
#define TOP256	(TOP + (256-CONVIMG_CY)/2)
#define LEFT	10
#define LEFTRAW	(LEFT + (256-(RAWIMG_CX*MAGRAW))/2)
#define LEFT256	(LEFT + (256-CONVIMG_CX)/2)

/************************************************************************/
/*                                                                      */
/************************************************************************/
//////////////////////////////////////////////////////////////////////////
BYTE gbyTemplateDB[FP_TEMPLATE_SIZE * FP_MAX_USERS+FP_MAX_USERS];

enum
{
	FILE_NAME_GET_TEMPLATE,
	FILE_NAME_GET_FPDB,
	FILE_NAME_GET_BMP,
	FILE_NAME_FIRMWARE,
};

CString file_name_get(int nType, BOOL bOpenSave)
{
	TCHAR* defexts[] = {_T("dat"), _T("db"), _T("bmp"), _T("bin")};
	TCHAR* deffilenames[] = {_T("00.dat"), _T("database.db"), _T("image.bmp"), _T("fingerKeyFw.BIN")};
	TCHAR* filters[] = {_T("Templ File (*.dat)|*.dat|All (*.*)|*.*||"),
		_T("Db File (*.db)|*.db|All (*.*)|*.*||"),
		_T("Image (*.bmp)|*.bmp|All (*.*)|*.*||"),
		_T("Firmware (*.bin)|*.bin|All (*.*)|*.*||")};

	CFileDialog dlg(bOpenSave, defexts[nType], deffilenames[nType], OFN_OVERWRITEPROMPT, filters[nType]);
	
	if(dlg.DoModal() == IDOK) 
	{
		return dlg.GetPathName();
	}
	
	return _T("");
}

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CSDK_DEMODlg dialog



CSDK_DEMODlg::CSDK_DEMODlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CSDK_DEMODlg::IDD, pParent)
	, m_bCheckTcp(FALSE)
	, m_nImageNumber(0)
	, bDEBUG(FALSE)
	, str_Identify_Result(_T(""))
{
	m_nPortNumber = 0;
	m_nBaudrate = 4;
	m_strResult = _T("");

	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	m_bImageShow = TRUE;
	m_bContinue = FALSE;
	m_ing = FALSE;
}

void CSDK_DEMODlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_CBIndex(pDX, IDC_COMBO_COM, m_nPortNumber);
	DDX_CBIndex(pDX, IDC_COMBO_BAUDRATE, m_nBaudrate);
	DDX_Control(pDX, IDC_SPIN_ID, m_spinID);
	DDX_Control(pDX, IDC_PROGRESS1, m_prog);
	DDX_Text(pDX, IDC_STATIC_RESULT, m_strResult);
	DDX_Check(pDX, IDC_CHECK_TCP, m_bCheckTcp);
	DDX_Control(pDX, IDC_IPADDRESS1, m_Ip);
	DDX_Text(pDX, IDC_EDIT_IMAGE_NUMBER, m_nImageNumber);
	DDX_Check(pDX, IDC_CHECK_DEBUG, bDEBUG);
	DDX_Text(pDX, IDC_EDIT_IDENT_RESULT, str_Identify_Result);
	DDX_Control(pDX, IDC_COMBO1, Enroll_Count_CB_BOX);
}

BEGIN_MESSAGE_MAP(CSDK_DEMODlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_CLOSE()
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BUTT_OPEN, OnButtOpen)
	ON_BN_CLICKED(IDC_BUTT_CLOSE, OnButtClose)
	ON_BN_CLICKED(IDC_BUTT_ENROLL, OnButtEnroll)
	ON_BN_CLICKED(IDC_BUTT_VERIFY, OnButtVerify)
	ON_BN_CLICKED(IDC_BUTT_IDENTIFY, OnButtIdentify)
	ON_BN_CLICKED(IDC_BUTT_VERIFY_TEMPLATE, OnButtVerifyTemplate)
	ON_BN_CLICKED(IDC_BUTT_IDENTIFY_TEMPLATE, OnButtIdentifyTemplate)
	ON_BN_CLICKED(IDC_BUTT_ISPRESSFP, OnButtIspressfp)
	ON_BN_CLICKED(IDC_BUTT_GET_IMAGE, OnButtGetImage)
	ON_BN_CLICKED(IDC_BUTT_GET_RAWIMAGE, OnButtGetRawimage)
	ON_BN_CLICKED(IDC_BUTT_GET_USER_COUNT, OnButtGetUserCount)
	ON_BN_CLICKED(IDC_BUTT_DELETE, OnButtDelete)
	ON_BN_CLICKED(IDC_BUTT_DELETE_ALL, OnButtDeleteAll)
	ON_BN_CLICKED(IDC_BUTT_GET_TEMPLATE, OnButtGetTemplate)
	ON_BN_CLICKED(IDC_BUTT_SET_TEMPLATE, OnButtSetTemplate)
	ON_BN_CLICKED(IDC_BUTT_GET_DATABASE, OnButtGetDatabase)
	ON_BN_CLICKED(IDC_BUTT_SET_DATABASE, OnButtSetDatabase)
	ON_BN_CLICKED(IDC_BUTT_FW_UPGRADE, OnButtFwUpgrade)
	ON_BN_CLICKED(IDC_BUTT_SAVE_IMAGE, OnButtSaveImage)
	ON_BN_CLICKED(IDC_BUTT_CANCEL, OnButtCancel)
	ON_BN_CLICKED(IDC_BUTT_GET_MASS_RAWIMAGE, &CSDK_DEMODlg::OnBnClickedButtGetMassRawImage)
	ON_BN_CLICKED(IDC_BUTT_RESTART, &CSDK_DEMODlg::OnBnClickedButtRestart)
	ON_BN_CLICKED(IDC_WRITE_LICENSE, &CSDK_DEMODlg::OnBnClickedWriteLicense)
	ON_BN_CLICKED(IDC_READ_LICENSE, &CSDK_DEMODlg::OnBnClickedReadLicense)
	ON_BN_CLICKED(IDC_BUTT_GET_MASS_IMAGE, &CSDK_DEMODlg::OnBnClickedButtGetMassImage)
	ON_BN_CLICKED(IDC_BUTTON_CLEAR_HISTORY, &CSDK_DEMODlg::OnBnClickedButtonClearHistory)
END_MESSAGE_MAP()


// CSDK_DEMODlg message handlers

BOOL CSDK_DEMODlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here

	EnableBtn(FALSE);
	GetDlgItem(IDC_BUTT_CANCEL)->EnableWindow(FALSE);

	//m_spinID.SetBuddy(GetDlgItem(IDC_EDIT_ID));
	m_spinID.SetRange32(0, 255/*FP_MAX_USERS-1*/);
	m_spinID.SetPos32(0);

	m_prog.SetRange32(0, 10000);
	m_Ip.SetAddress(192, 168, 1, 192);

	LOGFONT lf;
	memset(&lf, 0, sizeof(LOGFONT));
	lf.lfHeight = 28;
	lf.lfWeight = 700;
	_tcsncpy_s(lf.lfFaceName, LF_FACESIZE, _T("Arial"), 7);

	m_font.CreateFontIndirect(&lf);
	lf.lfHeight = 24;
	m_font2.CreateFontIndirect(&lf);

	GetDlgItem(IDC_BUTT_OPEN)->SetFont(&m_font);
	GetDlgItem(IDC_BUTT_CLOSE)->SetFont(&m_font);
	GetDlgItem(IDC_STATIC_ID_LABEL)->SetFont(&m_font2);
	GetDlgItem(IDC_EDIT_ID)->SetFont(&m_font);
	GetDlgItem(IDC_BUTT_ENROLL)->SetFont(&m_font);
	GetDlgItem(IDC_BUTT_GET_USER_COUNT)->SetFont(&m_font);
	GetDlgItem(IDC_BUTT_IDENTIFY)->SetFont(&m_font);
	GetDlgItem(IDC_BUTT_DELETE)->SetFont(&m_font);
	GetDlgItem(IDC_BUTT_CANCEL)->SetFont(&m_font);
	GetDlgItem(IDC_BUTT_DELETE_ALL)->SetFont(&m_font);
	GetDlgItem(IDC_STATIC_RESULT)->SetFont(&m_font2);
	GetDlgItem(IDC_BUTT_SAVE_IMAGE)->SetFont(&m_font2);
	GetDlgItem(IDC_BUTT_GET_IMAGE)->SetFont(&m_font2);
	GetDlgItem(IDC_BUTT_GET_MASS_IMAGE)->SetFont(&m_font2);
	GetDlgItem(IDC_BUTT_GET_RAWIMAGE)->SetFont(&m_font2);
	GetDlgItem(IDC_BUTT_GET_MASS_RAWIMAGE)->SetFont(&m_font2);

	BOOL bDevEdition = FALSE;
	if (!theApp.GetInt(_T("developer_edition")))
	{
		theApp.WriteInt(_T("developer_edition"), 0);
	}
	else
	{
		theApp.WriteInt(_T("developer_edition"), 1);
		bDevEdition = TRUE;
	}

	bDevEdition = TRUE;
	if (!bDevEdition)
	{
		GetDlgItem(IDC_BUTT_VERIFY)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BUTT_VERIFY_TEMPLATE)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BUTT_IDENTIFY_TEMPLATE)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BUTT_GET_TEMPLATE)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BUTT_SET_TEMPLATE)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BUTT_GET_DATABASE)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BUTT_SET_DATABASE)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BUTT_FW_UPGRADE)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BUTT_ISPRESSFP)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BUTT_GET_IMAGE)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BUTT_GET_RAWIMAGE)->ShowWindow(SW_HIDE);

		CRect rtWin;
		GetWindowRect(&rtWin);
		rtWin.right -= 350;
		MoveWindow(&rtWin, TRUE);
	}

#if defined(BS510_8MM)
	CString strTitle;
	GetWindowText(strTitle);
	strTitle += _T(" BS510_8MM");
	SetWindowText(strTitle);
#endif

	CString ec_item;
	Enroll_Count_CB_BOX.ResetContent();
	Enroll_Count_CB_BOX.AddString(_T("Auto"));
	for (int i = 5; i <= 20; i++){
		ec_item.Format(_T("%d"), i);
		Enroll_Count_CB_BOX.AddString(ec_item);
	}
	Enroll_Count_CB_BOX.SetCurSel(0);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CSDK_DEMODlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CSDK_DEMODlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
// 		CDialogEx::OnPaint();
		
		CPaintDC dc(this); // device context for painting
		
		static int gImageType_prev = fp_bmp_raw;
		if (gImageType_prev != gImageType)
		{
			dc.FillRect(CRect(CPoint(LEFT,TOP), CSize(256,256)), &(CBrush(RGB(255,255,255))));
			gImageType_prev = gImageType;
		}

		if(gImageType == fp_bmp_256)
		{
			fp_bmp_draw(dc.GetSafeHdc(), &fp_bmp256, gbyImg8bit, LEFT256, TOP256, CONVIMG_CX, CONVIMG_CY);
		}
		if(gImageType == fp_bmp_raw)
		{
			fp_bmp_draw(dc.GetSafeHdc(), &fp_bmpraw, gbyImgRaw, LEFTRAW, TOPRAW, RAWIMG_CX*MAGRAW, RAWIMG_CY*MAGRAW);
		}
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CSDK_DEMODlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CSDK_DEMODlg::OnClose() 
{
	// TODO: Add your message handler code here and/or call default
	
	if (m_ing)
		return;

	CDialog::OnClose();
}

void CSDK_DEMODlg::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	
	if (nIDEvent == 1)
	{
		m_prog.SetPos((int)(comm_percent * 100.0));
	}

	CDialog::OnTimer(nIDEvent);
}

BOOL CSDK_DEMODlg::PreTranslateMessage(MSG* pMsg) 
{
	// TODO: Add your specialized code here and/or call the base class
	
	if ((pMsg->message == WM_KEYDOWN || pMsg->message == WM_KEYUP) &&
		pMsg->wParam == VK_ESCAPE)
	{
		return TRUE;
	}

	return CDialog::PreTranslateMessage(pMsg);
}

BOOL CSDK_DEMODlg::OnCommand(WPARAM wParam, LPARAM lParam) 
{
	// TODO: Add your specialized code here and/or call the base class
	
	if (wParam == IDOK)
		return FALSE;

	return CDialog::OnCommand(wParam, lParam);
}

//////////////////////////////////////////////////////////////////////////
class CSDK_DEMODlgWrap
{
	CSDK_DEMODlg* m_pDlg;
	UINT m_nLastID;
public:
	
	CSDK_DEMODlgWrap(CSDK_DEMODlg* pDlg, UINT nLastID)
	{
		m_pDlg = pDlg;
		m_nLastID = nLastID;
		m_pDlg->m_strResult = _T(" ");
		m_pDlg->EnableBtn(FALSE, TRUE);
		m_pDlg->UpdateData();
		m_pDlg->m_prog.SetPos(0);
		//m_pDlg->m_prog.ShowWindow(SW_SHOW);

		m_pDlg->m_ing = TRUE;
	}
	
	~CSDK_DEMODlgWrap()
	{
		m_pDlg->m_ing = FALSE;

		m_pDlg->m_prog.ShowWindow(SW_HIDE);
		m_pDlg->UpdateData(FALSE);
		m_pDlg->EnableBtn(TRUE);
		m_pDlg->GetDlgItem(m_nLastID)->SetFocus();
	}
};

class CSDK_DEMODlgWrap_cancel
{
	CSDK_DEMODlg* m_pDlg;
public:
	
	CSDK_DEMODlgWrap_cancel(CSDK_DEMODlg* pDlg)
	{
		m_pDlg = pDlg;
		m_pDlg->m_bContinue = TRUE;
		m_pDlg->GetDlgItem(IDC_BUTT_CANCEL)->EnableWindow(TRUE);
	}
	
	~CSDK_DEMODlgWrap_cancel()
	{
		m_pDlg->GetDlgItem(IDC_BUTT_CANCEL)->EnableWindow(FALSE);
		m_pDlg->m_bContinue = FALSE;
	}
};

void CSDK_DEMODlg::EnableBtn(BOOL bEnable, BOOL bDisableAll)
{
	GetDlgItem(IDC_BUTT_OPEN)->EnableWindow(!bEnable && !bDisableAll);
    
	for (UINT id=IDC_BUTT_CLOSE; id<IDC_BUTT_CANCEL; id++)
	{
		try
		{
			auto pWnd = GetDlgItem(id);
			if (pWnd)
				pWnd->EnableWindow(bEnable && !bDisableAll);
		}
		catch (...)
		{
		}
	}
}

int CSDK_DEMODlg::Capturing(BOOL bBest/* = FALSE*/)
{
	if(oem_capture(5000) < 0)
	{
		m_strResult = _T("Comm Error");
		return -1;
	}
	else if(gwLastAck == ACK_OK)
	{
		return 0;
	}
	ui_polling();

	//m_strResult = _T("Capture Timeout");
	//return -1;
	return 0;
}

extern BYTE	timages[5][96 * 112];

int CSDK_DEMODlg::LoadingImageCont()
{
	CString strDirName, strFileName;
	strDirName.Format(_T("D:\\Capture_Failed"));
	CreateDirectory(strDirName, NULL);
	strDirName.Format(_T("D:\\small_fpdb"));
	CreateDirectory(strDirName, NULL);
	strDirName.Format(_T("D:\\small_fpdb\\%03d"), m_spinID.GetPos32());
	CreateDirectory(strDirName, NULL);

	UpdateData(TRUE);
	int gnImageNumber = m_nImageNumber;
	while (m_bContinue && gnImageNumber < 100)
	{
		m_strResult.Format(_T("%04d Press Finger..."), m_nImageNumber);
		UpdateData(FALSE);
		ui_polling();

		int ret = 0;

		while (m_bContinue)
		{
			if (oem_get_image(1) < 0) return 0;
			if (gwLastAck != ACK_OK)
			{
				DisplayErr(gwLastAckParam, 0); UpdateData(FALSE);
				if (gwLastAckParam == NACK_FINGER_IS_NOT_PRESSED){
					return 0;
				}

				static int bad_finger_count = 0;
				for (int i = 0; i < 3; i++){
					strFileName.Format(_T("%04d_%d.bmp"), bad_finger_count, i);
					fp_bmp_save(_T("D:\\Capture_Failed\\") + strFileName, &fp_bmpraw, timages[i]);
				}
				bad_finger_count++;

				//Sleep(100);
				continue;
			}

			SetBmp(TRUE);
			ui_polling();

			ret = 1;
			break;

// 			if (oem_check_is_press_fp(95))
// 			{
// 				ret++;
// 				if (ret > 0)
// 					break;
// 			}
// 			else
// 			{
// 				ret = 0;
// 			}
		}
		if (ret >= 0)
		{
			m_nImageNumber = gnImageNumber;

			for (int i = 0; i < 4; i++){
				strFileName.Format(_T("%04d_%d.bmp"), gnImageNumber, i);
				fp_bmp_save(strDirName + _T("\\") + strFileName, &fp_bmpraw, timages[i]);
			}
			gnImageNumber++;
//			fp_bmp_save(strDirName + _T("\\") + strFileName, &fp_bmpraw, gbyImgRaw);

			m_strResult.Format(_T("%04d OK, Take Off..."), m_nImageNumber);
			UpdateData(FALSE);
			ui_polling();

			while (m_bContinue) {
				if (oem_is_press_finger() < 0 ||
					gwLastAck == NACK_INFO)
				{
					break;
				}
				ui_polling();
				Sleep(100);
			}
		}
	}

	return 0;
}

int CSDK_DEMODlg::LoadingImageRawCont()
{
	CString strDirName;
	strDirName.Format(_T("D:\\small_raw_fpdb"));
	CreateDirectory(strDirName, NULL);
	strDirName.Format(_T("D:\\small_raw_fpdb\\%03d"), m_spinID.GetPos32());
	CreateDirectory(strDirName, NULL);

	UpdateData(TRUE);
	int gnImageNumber = m_nImageNumber;
	while (m_bContinue && gnImageNumber < 100)
	{
		m_strResult.Format(_T("Press Finger..."), m_nImageNumber);
		UpdateData(FALSE);
		ui_polling();

		unsigned char dacp_val = 96;// 0x8d;
		unsigned char reg31_val = 0x25;// 0x5e;
		unsigned char reg32_val = 0xc8;

// 		int rate = 100;
		int ret = 0;

		while (m_bContinue)
		{
			if (oem_get_rawimage(dacp_val, reg31_val, reg32_val) < 0 ||
				gwLastAck == NACK_INFO)
			{
// 				ret = -1;
// 				rate = 100;
				ui_polling();
				continue;
			}

			SetBmp(TRUE);
			ui_polling();

// 			ret = Recur_Param(gbyImgRaw, RAWIMG_CY, RAWIMG_CX,
// 				dacp_val, reg31_val,
// 				&dacp_val, &reg31_val, rate);
// 			if (ret < 0) {
// 				rate = 100;
// 				ui_polling();
// 				continue;
// 			}
// 			rate -= 10;
// 			if (rate < 10)
// 				break;
			if (oem_check_is_press_fp(95))
			{
				ret++;
				if (ret > 0)
					break;
			}
			else
			{
				ret = 0;
			}
		}
		if (ret >= 0)
		{
			m_nImageNumber = gnImageNumber;

			CString strFileName;
			strFileName.Format(_T("%04d.bmp"), gnImageNumber++);
			fp_bmp_save(strDirName + _T("\\") + strFileName, &fp_bmpraw, gbyImgRaw);

			m_strResult.Format(_T("%04d OK, Take Off..."), m_nImageNumber);
			UpdateData(FALSE);
			ui_polling();

			while (m_bContinue) {
				if (oem_get_rawimage(dacp_val, reg31_val, reg32_val) < 0 ||
					gwLastAck == NACK_INFO ||
					!oem_check_is_press_fp(50))

// 				if (oem_is_press_finger() < 0 ||
// 					gwLastAck == NACK_INFO)
				{
					break;
				}
				Sleep(100);
				ui_polling();
			}
		}
	}

	return 0;
}

extern byte timages[5][96 * 112];
int CSDK_DEMODlg::LoadingImage(int param)
{
	int nRet = 0;
	
	m_prog.ShowWindow(SW_SHOW);
	m_prog.SetPos(0);
	SetTimer(1, 100, NULL);
	m_strResult = _T("Downloading Image...");
	UpdateData(FALSE);
	if(oem_get_image(param) < 0)
	{
		m_strResult = _T("Comm Error");
		nRet = -1;
	}
	else if(gwLastAck == NACK_INFO)
	{
		DisplayErr(gwLastAckParam, 0);
		nRet = -1;
	}
	else if(param)
	{
		static int gnImageNumber = 0;
		CreateDirectory(_T("D:\\Capture_Temp"), NULL);
		CString strFileName;
		for (int i = 0; i < 4; i++){
			strFileName.Format(_T("C:\\_\\ImageRaw%03d.bmp"), gnImageNumber++);
			fp_bmp_save(strFileName, &fp_bmpraw, timages[i]);
		}
		gnImageNumber = (gnImageNumber/10 + 1) * 10;
	}
	KillTimer(1);
	m_prog.ShowWindow(SW_HIDE);
	m_strResult = _T("");
	UpdateData(FALSE);
	return nRet;
}

int CSDK_DEMODlg::LoadingImageRaw(unsigned char dacp_val, unsigned char reg31_val, unsigned char reg32_val)
{
	int nRet = 0;
	
	m_prog.ShowWindow(SW_SHOW);
	m_prog.SetPos(0);
	SetTimer(1, 100, NULL);
	m_strResult = _T("Downloading Image...");
	UpdateData(FALSE);
	if(oem_get_rawimage(dacp_val, reg31_val, reg32_val) < 0)
	{
		m_strResult = _T("Comm Error");
		nRet = -1;
	}
	else if(gwLastAck == NACK_INFO)
	{
		DisplayErr(gwLastAckParam, 0);
		nRet = -1;
	}
	else if(0)
	{
		static int gnImageNumber = 1;
		CreateDirectory(_T("C:\\_"), NULL);
		CString strFileName;
		strFileName.Format(_T("C:\\_\\ImageRaw%03d.bmp"), gnImageNumber++);
		
		fp_bmp_save(strFileName, &fp_bmpraw, gbyImgRaw);
	}
	KillTimer(1);
	m_prog.ShowWindow(SW_HIDE);
	m_strResult = _T("");
	UpdateData(FALSE);
	return nRet;
}

void CSDK_DEMODlg::DisplayErr(int nNackInfo, int nPos)
{
	if( nNackInfo > NACK_NONE)
	{
		switch(nNackInfo)
		{
		case NACK_TIMEOUT:
			m_strResult = _T("Timeout");
			break;
		case NACK_INVALID_BAUDRATE:
			m_strResult = _T("Invalid Baud Rate");
			break;
		case NACK_INVALID_POS:
			m_strResult = _T("Invalid Fp No.");
			break;
		case NACK_IS_NOT_USED:
			m_strResult.Format(_T("Fp No. = %d: Not Enrolled"), nPos);
			break;
		case NACK_IS_ALREADY_USED:
			m_strResult.Format(_T("Fp No. = %d: Already Enrolled"), nPos);
			break;
		case NACK_COMM_ERR:
			m_strResult = _T("Comm Error");
			break;
		case NACK_VERIFY_FAILED:
			m_strResult.Format(_T("Fp No. = %d: Verify Fail"), nPos);
			break;
		case NACK_IDENTIFY_FAILED:
			m_strResult.Format(_T("Identify Fail"));
			break;
		case NACK_DB_IS_FULL:
			m_strResult = _T("Db Overflow");
			break;
		case NACK_DB_IS_EMPTY:
			m_strResult = _T("No Data");
			break;
		case NACK_TURN_ERR:
			m_strResult = _T("Enroll Fail");
			break;
		case NACK_BAD_FINGER:
			m_strResult = _T("Press Again");
			break;
		case NACK_ENROLL_FAILED:
			m_strResult = _T("Enroll Fail");
			break;
		case NACK_IS_NOT_SUPPORTED:
			m_strResult = _T("Not Supported");
			break;
		case NACK_DEV_ERR:
			m_strResult = _T("Device Error");
			break;
		case NACK_CAPTURE_CANCELED:
			m_strResult = _T("Canceled");
			break;
		case NACK_INVALID_PARAM:
			m_strResult = _T("Invalid Param");
			break;
		case NACK_FINGER_IS_NOT_PRESSED:
			m_strResult = _T("No Finger Pressed");
			break;
		case NACK_FINGER_IS_PUSHED:
			m_strResult = _T("Finger is Pushed");
			break;
		default:
			m_strResult = _T("Unknown Error");
			break;
		}
	}
	else if (nNackInfo<FP_MAX_USERS)
	{
		m_strResult.Format(_T("Fp No. = %d: Fp Duplicated"), nNackInfo);
	}
}

void CSDK_DEMODlg::SetBmp(BOOL bIsRaw/* = FALSE*/)
{
	gImageType = bIsRaw ? fp_bmp_raw : fp_bmp_256;
	Invalidate(FALSE);

	ui_polling();
}

void CSDK_DEMODlg::OnButtOpen() 
{
	UpdateData();

	if (m_bCheckTcp)
	{
		DWORD server_name;
		m_Ip.GetAddress(server_name);

		if (!comm_open_tcp(server_name, 5005)){
			m_strResult = _T("TCP Error");
			return;
		}
	}
	else
	{
		if (m_nPortNumber == 0)
		{
			if (!comm_open_usb()){
				m_strResult = _T("Please Check USB");
				AfxMessageBox(m_strResult);
				return;
			}
		}
		else
		{
			if (!comm_open_serial(m_nPortNumber, 115200)){
				m_strResult = _T("Please Check UART");
				return;
			}
		}
	}
	
	if(oem_open() < 0)
	{
		m_strResult = _T("Open Error");
		return;
	}
	if(gwLastAck == NACK_INFO)
	{
		m_strResult = _T("Open Error");
		return;
	}

	m_strResult.Format(_T("Ver: %08X\r\nSN: "), gDevInfo.FirmwareVersion);

	BYTE* p = gDevInfo.DeviceSerialNumber;
	CString str;
	str.Format(_T("%02X%02X%02X%02X%02X%02X%02X%02X-%02X%02X%02X%02X%02X%02X%02X%02X"),
		p[0],p[1],p[2],p[3],p[4],p[5],p[6],p[7],
		p[8], p[9], p[10], p[11], p[12], p[13], p[14], p[15]);
	m_strResult += str;
	
	UpdateData(FALSE);
	EnableBtn(TRUE);
	GetDlgItem(IDC_BUTT_ENROLL)->SetFocus();
}

void CSDK_DEMODlg::OnButtClose() 
{

	// TODO: Add your control notification handler code here
	UpdateData();
	m_strResult = _T("");
	UpdateData(FALSE);
	oem_close();
	comm_close();
	EnableBtn(FALSE);
	GetDlgItem(IDC_BUTT_CANCEL)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTT_OPEN)->SetFocus();
}

void Transitionn(BYTE* src, BYTE* dst){
	int i, j;
	BYTE* spsrc = src + RAWIMG_CX * (RAWIMG_CY-1);
	BYTE* pdst = dst;
	BYTE* psrc;
	for (i = 0; i < RAWIMG_CX; i++){
		spsrc++; psrc = spsrc;
		for (j = 0; j < RAWIMG_CY; j++){
			*pdst = *psrc;
			pdst++;
			psrc -= RAWIMG_CX;
		}
	}
}

void CSDK_DEMODlg::OnButtEnroll() 
{
	CSDK_DEMODlgWrap _wrap_(this, IDC_BUTT_ENROLL);
	
	int nID = m_spinID.GetPos32();
	if (nID < 0)
		nID = 0;
	if (nID > FP_MAX_USERS-1)
		nID = FP_MAX_USERS-1;
	m_spinID.SetPos32(nID);

	UpdateData(TRUE);
	int en_cou;
	if (Enroll_Count_CB_BOX.GetCurSel() == 0){ /// Auto
		en_cou = 0;
	}
	else{
		en_cou = Enroll_Count_CB_BOX.GetCurSel() + 4;
	}

	if(oem_enroll_start(nID) < 0)
	{
		m_strResult = _T("Comm Error");
		return;
	}
	if(gwLastAck == NACK_INFO)
	{
		DisplayErr(gwLastAckParam, nID);
		return;
	}

	CSDK_DEMODlgWrap_cancel _wrap_cancel_(this);

	int Enrolled_percent = 0, Enrolled_Cou = 0;

	if (bDEBUG){
		CFolderPickerDialog folderdlg;
		if (folderdlg.DoModal() != IDOK) return;

		CFileFind finder;
		bool bwork;
		bwork = finder.FindFile(folderdlg.GetFolderPath() + _T("\\*.bmp"));
		while (bwork && m_bContinue){
			bwork = finder.FindNextFileW();
			if (!fp_bmp_read(finder.GetFilePath(), &fp_bmpraw, gbyImgRaw)) continue;

			m_strResult.Format(_T("%d%% Enroll %s"), Enrolled_percent, finder.GetFileName());
			UpdateData(FALSE);

			SetBmp(TRUE);

 			oem_download_image(gbyImgRaw);

			Sleep(100);

			if (oem_enroll_nth() < 0)
			{
				m_strResult = _T("Comm Error");
				return;
			}
			if (gwLastAck == NACK_INFO)
			{
				DisplayErr(gwLastAckParam, 0);
				continue;
			}

			Enrolled_Cou++;
			Enrolled_percent = gwLastAckParam;

			UpdateData(TRUE);
			if (Enroll_Count_CB_BOX.GetCurSel() > 0){
				Enrolled_percent = 100 * Enrolled_Cou / (Enroll_Count_CB_BOX.GetCurSel() + 4);
			}

			ui_polling();

			if (Enrolled_percent == 100) break;

		}

		if (Enrolled_percent == 100) oem_enroll_finish();

	}
	else{

		CString strDirName;

		strDirName.Format(_T("D:\\device_db"));
		CreateDirectory(strDirName, NULL);
		strDirName.Format(_T("D:\\device_db\\Enroll"));
		CreateDirectory(strDirName, NULL);
		strDirName.Format(_T("D:\\device_db\\Enroll\\%03d"), nID);
		CreateDirectory(strDirName, NULL);

		int tcou = 0;
		CString strFilePath;

		while (Enrolled_percent < 100)
		{
			m_strResult.Format(_T("Press Finger...   %d%% Completed"), Enrolled_percent);
			UpdateData(FALSE);
			if (Capturing(TRUE) < 0){
				return;
			}

			if (gwLastAck != ACK_OK){
				if (gwLastAckParam == NACK_FINGER_IS_NOT_PRESSED){
					DisplayErr(gwLastAckParam, 0);
					return;
				}
				DisplayErr(gwLastAckParam, 0);
				continue;
			}

			SetBmp(TRUE);

			strFilePath.Format(_T("D:\\device_db\\Enroll\\%03d\\%03d.bmp"), nID, tcou++);
			fp_bmp_save(strFilePath, &fp_bmpraw, gbyImgRaw);


			if (oem_enroll_nth() < 0)
			{
				m_strResult = _T("Comm Error");
				return;
			}
			if (gwLastAck == NACK_INFO)
			{
				DisplayErr(gwLastAckParam, 0);
				continue;
			}

			Enrolled_Cou++;
			Enrolled_percent = gwLastAckParam;

			UpdateData(TRUE);
			if (Enroll_Count_CB_BOX.GetCurSel() > 0){
				Enrolled_percent = 100 * Enrolled_Cou / (Enroll_Count_CB_BOX.GetCurSel() + 4);
			}

			m_strResult.Format(_T("Take Off...   %d%% Completed"), Enrolled_percent);
			UpdateData(FALSE);

		}

		if (Enrolled_percent==100) oem_enroll_finish();
	}

	m_spinID.SetPos32(nID+1);
	m_strResult.Format(_T("Enroll Success (Fp No. = %d)"), nID);
}

void CSDK_DEMODlg::OnButtVerify() 
{
	// TODO: Add your control notification handler code here
	CSDK_DEMODlgWrap _wrap_(this, IDC_BUTT_VERIFY);
	
	int nID = m_spinID.GetPos32();

	if (nID < 0 || nID >= FP_MAX_USERS)
	{
		if (nID < 0) nID = 0;
		if (nID >= FP_MAX_USERS) nID = FP_MAX_USERS - 1;
		m_spinID.SetPos32(nID);
	}
	
	if( oem_check_enrolled(nID) < 0)
	{
		m_strResult = _T("Comm Error");
		return;
	}
	if(gwLastAck == NACK_INFO)
	{
		DisplayErr(gwLastAckParam, nID);
		return;
	}
	
	CSDK_DEMODlgWrap_cancel _wrap_cancel_(this);



	if (bDEBUG){
		CFolderPickerDialog folderdlg;
		if (folderdlg.DoModal() != IDOK) return;

		CFileFind finder;
		bool bwork;
		bwork = finder.FindFile(folderdlg.GetFolderPath() + _T("\\*.bmp"));
		while (bwork && m_bContinue){
			bwork = finder.FindNextFileW();
			if (!fp_bmp_read(finder.GetFilePath(), &fp_bmpraw, gbyImgRaw)) continue;

			SetBmp(TRUE);

			oem_download_image(gbyImgRaw);

			Sleep(100);

			if (oem_verify(nID) < 0)
			{
				m_strResult = _T("Comm Error");
				return;
			}
			if (gwLastAck == NACK_INFO)
			{
				DisplayErr(gwLastAckParam, 0);
				UpdateData(FALSE);

				g_Identify_Fail_Count++;
				Update_Identify_Result();

				continue;
			}

			m_strResult.Format(_T("Fp No. = %d : %d ms"), gwLastAckParam, gnPassedTime);
			UpdateData(FALSE);

			g_Identify_Pass_Count++;
			Update_Identify_Result();

			Sleep(1000);

			ui_polling();
		}

		return;

	}
	else{

		CString strDirName, strFileName;

		m_strResult = _T("");
		while (m_bContinue)
		{
			m_strResult += _T("  Press Finger");
			UpdateData(FALSE);

			if (Capturing() < 0)
				return;

			if (gwLastAck != ACK_OK){
				if (gwLastAckParam == NACK_FINGER_IS_NOT_PRESSED){
					DisplayErr(gwLastAckParam, 0);
					return;
				}
				DisplayErr(gwLastAckParam, 0);
				continue;
			}

			SetBmp(TRUE);

			m_strResult = _T("Processing...");
			UpdateData(FALSE);

			if (oem_verify(nID) < 0)
			{
				m_strResult = _T("Comm Error");
				return;
			}
			if (gwLastAck == NACK_INFO)
			{
				DisplayErr(gwLastAckParam, nID);
				UpdateData(FALSE);

				g_Identify_Fail_Count++;
				Update_Identify_Result();

				if (m_bImageShow && gn_comm_type != COMM_MODE_SERIAL)
				{
					if (!bDEBUG){
						strDirName.Format(_T("D:\\device_db"));
						CreateDirectory(strDirName, NULL);
						strDirName.Format(_T("D:\\device_db\\Verify"));
						CreateDirectory(strDirName, NULL);
						strDirName.Format(_T("D:\\device_db\\Verify\\%03d"), nID);
						CreateDirectory(strDirName, NULL);
						strDirName.Format(_T("D:\\device_db\\Verify\\%03d\\Fail"), nID);
						CreateDirectory(strDirName, NULL);

						static int fgnImageNumber = 1;
						strFileName.Format(_T("D:\\device_db\\Verify\\%03d\\Fail\\%03d.bmp"), nID, fgnImageNumber++);

						fp_bmp_save(strFileName, &fp_bmpraw, gbyImgRaw);
					}
				}


				continue;
			}

			m_strResult.Format(_T("Fp No. = %d : %d ms"), nID, gnPassedTime);
			UpdateData(FALSE);

			g_Identify_Pass_Count++;
			Update_Identify_Result();

			if (m_bImageShow && gn_comm_type != COMM_MODE_SERIAL)
			{
				if (!bDEBUG){
					strDirName.Format(_T("D:\\device_db"));
					CreateDirectory(strDirName, NULL);
					strDirName.Format(_T("D:\\device_db\\Verify"));
					CreateDirectory(strDirName, NULL);
					strDirName.Format(_T("D:\\device_db\\Verify\\%03d"), nID);
					CreateDirectory(strDirName, NULL);
					strDirName.Format(_T("D:\\device_db\\Verify\\%03d\\Success"), nID);
					CreateDirectory(strDirName, NULL);

					static int fgnImageNumber = 1;
					strFileName.Format(_T("D:\\device_db\\Verify\\%03d\\Success\\%03d.bmp"), nID, fgnImageNumber++);

					fp_bmp_save(strFileName, &fp_bmpraw, gbyImgRaw);
				}
			}

			Sleep(1000);

		}
	}
}

void CSDK_DEMODlg::OnButtIdentify() 
{
	// TODO: Add your control notification handler code here
	CSDK_DEMODlgWrap _wrap_(this, IDC_BUTT_IDENTIFY);
	
	if(oem_enroll_count() < 0)
	{
		m_strResult = _T("Comm Error");
		return;
	}
	if(gwLastAck == NACK_INFO)
	{
		DisplayErr(gwLastAckParam, 0);
		return;
	}
	
	if (gwLastAckParam == 0)
	{
		m_strResult = _T("No Data");
		return;
	}
	
	CSDK_DEMODlgWrap_cancel _wrap_cancel_(this);




	if (bDEBUG){
		CFolderPickerDialog folderdlg;
		if (folderdlg.DoModal() != IDOK) return;

		CFileFind finder;
		bool bwork;
		bwork = finder.FindFile(folderdlg.GetFolderPath() + _T("\\*.bmp"));
		while (bwork && m_bContinue){
			bwork = finder.FindNextFileW();
			if (!fp_bmp_read(finder.GetFilePath(), &fp_bmpraw, gbyImgRaw)) continue;

			SetBmp(TRUE);

			oem_download_image(gbyImgRaw);

			Sleep(100);

			if (oem_identify() < 0)
			{
				m_strResult = _T("Comm Error");
				return;
			}
			if (gwLastAck == NACK_INFO)
			{
				DisplayErr(gwLastAckParam, 0);
				UpdateData(FALSE);

				g_Identify_Fail_Count++;
				Update_Identify_Result();

				continue;
			}

			m_strResult.Format(_T("Fp No. = %d : %d ms"), gwLastAckParam, gnPassedTime);
			UpdateData(FALSE);

			g_Identify_Pass_Count++;
			Update_Identify_Result();

			Sleep(1000);

			ui_polling();
		}

		return;

	}
	else{

		CString strDirName, strFileName;

		m_strResult = _T("");
		while (m_bContinue)
		{
			m_strResult += _T("  Press Finger");
			UpdateData(FALSE);

			if (Capturing() < 0)
				return;

			if (gwLastAck != ACK_OK){
				if (gwLastAckParam == NACK_FINGER_IS_NOT_PRESSED){
					DisplayErr(gwLastAckParam, 0);
					return;
				}
				DisplayErr(gwLastAckParam, 0);
				continue;
			}

			SetBmp(TRUE);

			m_strResult = _T("Processing...");
			UpdateData(FALSE);

			if (oem_identify() < 0)
			{
				m_strResult = _T("Comm Error");
				return;
			}
			if (gwLastAck == NACK_INFO)
			{
				DisplayErr(gwLastAckParam, 0);
				UpdateData(FALSE);

				g_Identify_Fail_Count++;
				Update_Identify_Result();

				if (m_bImageShow && gn_comm_type != COMM_MODE_SERIAL)
				{
					if (!bDEBUG){
						strDirName.Format(_T("D:\\device_db"));
						CreateDirectory(strDirName, NULL);
						strDirName.Format(_T("D:\\device_db\\Identify"));
						CreateDirectory(strDirName, NULL);
						strDirName.Format(_T("D:\\device_db\\Identify\\Fail"));
						CreateDirectory(strDirName, NULL);

						static int fgnImageNumber = 1;
						strFileName.Format(_T("D:\\device_db\\Identify\\Fail\\%03d.bmp"), fgnImageNumber++);

						fp_bmp_save(strFileName, &fp_bmpraw, gbyImgRaw);
					}
				}

				continue;
			}

			m_strResult.Format(_T("Fp No. = %d : %d ms"), gwLastAckParam, gnPassedTime);
			UpdateData(FALSE);

			g_Identify_Pass_Count++;
			Update_Identify_Result();

			if (m_bImageShow && gn_comm_type != COMM_MODE_SERIAL)
			{
				if (!bDEBUG){
					strDirName.Format(_T("D:\\device_db"));
					CreateDirectory(strDirName, NULL);
					strDirName.Format(_T("D:\\device_db\\Identify"));
					CreateDirectory(strDirName, NULL);
					strDirName.Format(_T("D:\\device_db\\Identify\\%03d"), gwLastAckParam);
					CreateDirectory(strDirName, NULL);

					static int pgnImageNumber = 1;
					strFileName.Format(_T("D:\\device_db\\Identify\\%03d\\%03d.bmp"), gwLastAckParam, pgnImageNumber++);

					fp_bmp_save(strFileName, &fp_bmpraw, gbyImgRaw);
				}
			}

			Sleep(1000);

		}
	}

}

void CSDK_DEMODlg::OnButtVerifyTemplate() 
{
	// TODO: Add your control notification handler code here
	
	//////////////////////////////////////////////////////////////////////////
	CSDK_DEMODlgWrap _wrap_(this, IDC_BUTT_VERIFY_TEMPLATE);

	int nID = m_spinID.GetPos32();
	if (nID < 0 || nID >= FP_MAX_USERS)
	{
		nID = 0;
		m_spinID.SetPos32(nID);
	}
	
	if( oem_check_enrolled(nID) < 0)
	{
		m_strResult = _T("Comm Error");
		return;
	}
	if(gwLastAck == NACK_INFO)
	{
		DisplayErr(gwLastAckParam, nID);
		return;
	}

	CString m_strFilePath = file_name_get(FILE_NAME_GET_TEMPLATE, TRUE);
	if(m_strFilePath == _T(""))
		return;
	
	CFile m_File;
	if( !m_File.Open( m_strFilePath,CFile::modeRead | CFile::typeBinary) )
	{
		AfxMessageBox(_T("Read Error"));
		return;
	}
	
	int nLength = (int)m_File.GetLength();
	if( nLength != FP_TEMPLATE_SIZE )
	{
		AfxMessageBox(_T("Invalid File Size"));
		return;
	}
	m_File.Read( gbyTemplate, nLength);
	m_File.Close();
	
	//////////////////////////////////////////////////////////////////////////
	
	
	if(oem_verify_template(nID) < 0)
	{
		m_strResult = _T("Comm Error");
		return;
	}
	if( gwLastAck==NACK_INFO )
	{
		DisplayErr(gwLastAckParam, nID);
		return;
	}
	
	m_strResult.Format(_T("Fp No. = %d : %d ms"), nID, gnPassedTime);
	UpdateData(FALSE);
}

void CSDK_DEMODlg::OnButtIdentifyTemplate() 
{
	// TODO: Add your control notification handler code here
	//////////////////////////////////////////////////////////////////////////
	CSDK_DEMODlgWrap _wrap_(this, IDC_BUTT_IDENTIFY_TEMPLATE);

	if(oem_enroll_count() < 0)
	{
		m_strResult = _T("Comm Error");
		return;
	}
	if(gwLastAck == NACK_INFO)
	{
		DisplayErr(gwLastAckParam, 0);
		return;
	}
	
	if (gwLastAckParam == 0)
	{
		m_strResult = _T("No Data");
		return;
	}
	
	CString m_strFilePath = file_name_get(FILE_NAME_GET_TEMPLATE, TRUE);
	if(m_strFilePath == _T(""))
		return;
	
	CFile m_File;
	if( !m_File.Open( m_strFilePath,CFile::modeRead | CFile::typeBinary) )
	{
		AfxMessageBox(_T("Read Error"));
		return;
	}
	
	int nLength = (int)m_File.GetLength();
	if( nLength != FP_TEMPLATE_SIZE )
	{
		AfxMessageBox(_T("Invalid File Size"));
		return;
	}
	m_File.Read( gbyTemplate, nLength);
	m_File.Close();
	
	//////////////////////////////////////////////////////////////////////////

	
	if(oem_identify_template() < 0)
	{
		m_strResult = _T("Comm Error");
		return;
	}
	if(gwLastAck == NACK_INFO)
	{
		DisplayErr(gwLastAckParam, 0);
		return;
	}
	
	m_strResult.Format(_T("Fp No. = %d : %d ms"), gwLastAckParam, gnPassedTime);
	UpdateData(FALSE);

}

void CSDK_DEMODlg::OnButtIspressfp() 
{
	// TODO: Add your control notification handler code here

	CSDK_DEMODlgWrap _wrap_(this, IDC_BUTT_ISPRESSFP);
	
	if(  oem_is_press_finger() < 0 ){
		m_strResult = _T("Comm Error");
		UpdateData(FALSE);
		return;
	}
	if( gwLastAck == NACK_INFO ){
		DisplayErr( gwLastAckParam, 0 );
		UpdateData(FALSE);
		return;
	}
	if( gwLastAckParam != 0 )
	{
		m_strResult = _T("No Finger Pressed");
		UpdateData(FALSE);
		return;
	}
	
	m_strResult = _T("Finger Pressed");
	UpdateData(FALSE);
}

void CSDK_DEMODlg::OnButtGetImage() 
{
	// TODO: Add your control notification handler code here
	CSDK_DEMODlgWrap _wrap_(this, IDC_BUTT_GET_IMAGE);
	
	m_strResult = _T("Press Finger");
	UpdateData(FALSE);
	
	CSDK_DEMODlgWrap_cancel _wrap_cancel_(this);
	if(LoadingImage(1) < 0)
		return;

	SetBmp(TRUE);
	
	m_strResult = _T("Get Image Success");
}

void CSDK_DEMODlg::OnButtGetRawimage() 
{
	// TODO: Add your control notification handler code here
	
	CSDK_DEMODlgWrap _wrap_(this, IDC_BUTT_GET_RAWIMAGE);
	
	CSDK_DEMODlgWrap_cancel _wrap_cancel_(this);

// 	UpdateData(TRUE);
// 	m_nImageNumber++;
// 	UpdateData(FALSE);
// 	CString strDirName;
// 	strDirName.Format(_T("D:\\small_fpdb\\two_params_%02d\\"), m_nImageNumber);
// 	CreateDirectory(strDirName, NULL);

	unsigned int dacp_val = 96, reg31_val, reg32_val;
	//unsigned int gain2 = 6, gain3 = 3, cur1 = 2, cur2 = 0, cur3 = 4;
	unsigned int gain2 = 5, gain3 = 0, cur1 = 1, cur2 = 0, cur3 = 4;
	//unsigned int gain2 = 4, gain3 = 0, cur1 = 1, cur2 = 4, cur3 = 7;

	//for (cur3 = 0; cur3 < 8; cur3++)
		//for (cur2 = 0; cur2 < 8; cur2++)
			//for (cur1 = 0; cur1 < 8; cur1++)
				//for (gain3 = 0; gain3 < 4; gain3++)
					//for (gain2 = 0; gain2 < 8; gain2++)
						//for (dacp_val = 8; dacp_val < 255; dacp_val += 16)
	for (int i=0; i<1; i++)
					{
						reg31_val = (cur1 << 5) + (gain3 << 3) + (gain2 << 0);
						reg32_val = 0x80 + (cur3 << 4) + 0x08 + (cur2 << 0);
						while (LoadingImageRaw((unsigned char)dacp_val, (unsigned char)reg31_val, (unsigned char)reg32_val) < 0 &&
							m_bContinue)
						{
							ui_polling();
						}
						SetBmp(TRUE);
						ui_polling();

// 						CString strFileName;
// 						//strFileName.Format(_T("%d%d%d%d%d.bmp"), cur3, cur2, cur1, gain3, gain2);
// 						strFileName.Format(_T("%03d.bmp"), i);
// 						fp_bmp_save(strDirName + strFileName, &fp_bmpraw, gbyImgRaw);

						if (!m_bContinue)
						{
							return;
						}
					}

/*
	unsigned char dacp_val = 164;// 0x8d;
	unsigned char reg31_val = 0x24, reg31_val_nouse;// 0x5e;
	unsigned char reg32_val = 0xff;

	int st = ::GetTickCount();
	int rate = 100;

	while (GetTickCount() - st < 5000)
	{
		if (LoadingImageRaw(dacp_val, reg31_val, reg32_val) < 0)
		{
			rate = 100;
			continue;
		}

		SetBmp(TRUE);
		ui_polling();

		int ret = Recur_Param(gbyImgRawOrg, RAWIMG_CY, RAWIMG_CX,
			dacp_val, reg31_val,
			&dacp_val, &reg31_val_nouse, rate);
		if (ret < 0) {
			rate = 100;
			continue;
		}
		rate -= 10;
		if (rate < 10)
		{
			m_strResult = _T("Get Raw Image Success");
			return;
		}
	}
*/

	m_strResult = _T("Get Raw Image Success");
}

void CSDK_DEMODlg::OnButtGetUserCount() 
{
	// TODO: Add your control notification handler code here
	
	CSDK_DEMODlgWrap _wrap_(this, IDC_BUTT_GET_USER_COUNT);
	
	if(oem_enroll_count() < 0)
	{
		m_strResult = _T("Comm Error");
		return;
	}
	if(gwLastAck == NACK_INFO)
	{
		DisplayErr(gwLastAckParam, 0);
		return;
	}
	
	m_strResult.Format(_T("Enrolled Count = %d"), gwLastAckParam);
}

void CSDK_DEMODlg::OnButtDelete() 
{
	// TODO: Add your control notification handler code here
	
	CSDK_DEMODlgWrap _wrap_(this,IDC_BUTT_DELETE);
	
	int nID = m_spinID.GetPos32();
	if (nID < 0 || nID >= FP_MAX_USERS)
	{
		nID = 0;
		m_spinID.SetPos32(nID);
	}
	
	CString str;
	str.Format(_T("%d"), m_spinID.GetPos32());
	GetDlgItem(IDC_EDIT_ID)->SetWindowText(str);
	
	if(AfxMessageBox(_T("Are you sure to delete (Fp No. : ") + str + _T(") ?"), MB_YESNO) == IDNO)
	{
		m_strResult = _T("Canceled");
		return;
	}
	
	if(oem_delete(nID) < 0)
	{
		m_strResult = _T("Comm Error");
		return;
	}
	if(gwLastAck == NACK_INFO)
	{
		DisplayErr(gwLastAckParam, nID);
		return;
	}

	m_strResult = _T("Delete Success");
}

void CSDK_DEMODlg::OnButtDeleteAll() 
{
	// TODO: Add your control notification handler code here
	
	CSDK_DEMODlgWrap _wrap_(this, IDC_BUTT_DELETE_ALL);
	
	if(AfxMessageBox(_T("Are you sure to delete all?"), MB_YESNO) == IDNO)
	{
		m_strResult = _T("Canceled");
		return;
	}
	
	if(oem_delete_all() < 0)
	{
		m_strResult = _T("Comm Error");
		return;
	}
	if(gwLastAck == NACK_INFO)
	{
		DisplayErr(gwLastAckParam, 0);
		return;
	}

	m_strResult = _T("Delete All Success");
}

void CSDK_DEMODlg::OnButtGetTemplate() 
{
	// TODO: Add your control notification handler code here
	
	CSDK_DEMODlgWrap _wrap_(this, IDC_BUTT_GET_TEMPLATE);
	
	int nIndexBufPos = FP_TEMPLATE_SIZE * FP_MAX_USERS;
	
	int nID = m_spinID.GetPos32();
	if (nID < 0 || nID >= FP_MAX_USERS)
	{
		nID = 0;
		m_spinID.SetPos32(nID);
	}
	
	m_strResult.Format(_T("Getting Templ %d th..."), nID);
	UpdateData(FALSE);
		
	if(oem_get_template(nID) < 0)
	{
		m_strResult = _T("Comm Error");
		return;
	}
	if( gwLastAck==NACK_INFO )
	{
		DisplayErr(gwLastAckParam, nID);
		return;
	}

	
	//////////////////////////////////////////////////////////////////////////
	CString m_strFilePath = file_name_get(FILE_NAME_GET_TEMPLATE, FALSE);
	if(m_strFilePath == _T(""))
	{
		m_strResult = _T("Canceled");
		return;
	}

	CFile m_File;
	if( !m_File.Open( m_strFilePath,CFile::modeCreate | CFile::modeWrite | CFile::typeBinary) )
	{
		AfxMessageBox(_T("Write Error"));
		m_strResult = _T("Write Error");
		return;
	}
	
	m_File.Write( gbyTemplate, FP_TEMPLATE_SIZE);
	m_File.Close();
	//////////////////////////////////////////////////////////////////////////
	
	m_strResult.Format(_T("Get Templ Success (Fp No. = %d)"), nID);
}

void CSDK_DEMODlg::OnButtSetTemplate() 
{
	// TODO: Add your control notification handler code here
	//////////////////////////////////////////////////////////////////////////
	CSDK_DEMODlgWrap _wrap_(this, IDC_BUTT_SET_TEMPLATE);

	int nID = m_spinID.GetPos32();
	if (nID < 0 || nID >= FP_MAX_USERS)
	{
		nID = 0;
		m_spinID.SetPos32(nID);
	}

	CString m_strFilePath = file_name_get(FILE_NAME_GET_TEMPLATE, TRUE);
	if(m_strFilePath == _T(""))
		return;
	
	CFile m_File;
	if( !m_File.Open( m_strFilePath,CFile::modeRead | CFile::typeBinary) )
	{
		AfxMessageBox(_T("Read Error"));
		return;
	}
	
	int nLength = (int)m_File.GetLength();
	if( nLength != FP_TEMPLATE_SIZE )
	{
		AfxMessageBox(_T("Invalid File Size"));
		return;
	}
	m_File.Read( gbyTemplate, nLength);
	m_File.Close();

	//////////////////////////////////////////////////////////////////////////
	
	
	m_strResult.Format(_T("Setting Templ %d th..."), nID);
	UpdateData(FALSE);
		
	if(oem_add_template(nID) < 0)
	{
		m_strResult = _T("Comm Error");
		return;
	}
	if( gwLastAck==NACK_INFO )
	{
		DisplayErr(gwLastAckParam, nID);
		return;
	}
	
	m_strResult.Format(_T("Set Templ Success (Fp No. = %d)"), nID);
}

void CSDK_DEMODlg::OnButtGetDatabase() 
{
	// TODO: Add your control notification handler code here
	
	CSDK_DEMODlgWrap _wrap_(this, IDC_BUTT_GET_DATABASE);

	int nIndexBufPos = FP_TEMPLATE_SIZE * FP_MAX_USERS;

	if(oem_enroll_count() < 0)
	{
		m_strResult = _T("Comm Error");
		return;
	}
	if(gwLastAck == NACK_INFO)
	{
		DisplayErr(gwLastAckParam, 0);
		return;
	}

	if (gwLastAckParam == 0)
	{
		m_strResult = _T("No Data");
		return;
	}

	int nEnrollCount = 0;
	for (int i=0; i<FP_MAX_USERS; i++)
	{
		m_strResult.Format(_T("Getting Templ %d th..."), i);
		UpdateData(FALSE);

		if(oem_get_template(i) < 0)
		{
			 m_strResult = _T("Comm Error");
			 return;
		}
		if( gwLastAck==NACK_INFO && gwLastAckParam!=NACK_IS_NOT_USED )
		{
			DisplayErr(gwLastAckParam, i);
			return;
		}
		
		if( gwLastAck==NACK_INFO &&  gwLastAckParam==NACK_IS_NOT_USED )
		{
			memset(&gbyTemplateDB[i * FP_TEMPLATE_SIZE], 0xFF, FP_TEMPLATE_SIZE);
			gbyTemplateDB[nIndexBufPos+i] = 0;
		}
		else
		{
			memcpy(&gbyTemplateDB[i * FP_TEMPLATE_SIZE], gbyTemplate, FP_TEMPLATE_SIZE);
			gbyTemplateDB[nIndexBufPos+i] = 1;
			nEnrollCount++;
		}
	}

	//////////////////////////////////////////////////////////////////////////
	CString m_strFilePath = file_name_get(FILE_NAME_GET_FPDB, FALSE);
	if(m_strFilePath == _T(""))
		return;
	
	CFile m_File;
	if( !m_File.Open( m_strFilePath,CFile::modeCreate | CFile::modeWrite | CFile::typeBinary) )
	{
		AfxMessageBox(_T("Write Error"));
		return;
	}

/* 
	KCN : then, database file would be the same size every time and it's not related to enroll count.
		and also database file should be contain count of templates.
		read database process should do correspond something.
*/	

	m_File.Write( &gbyTemplateDB[0], FP_MAX_USERS * FP_TEMPLATE_SIZE + FP_MAX_USERS);
	m_File.Close();
	//////////////////////////////////////////////////////////////////////////
	
	m_strResult.Format(_T("Get Db Success (Count = %d)"), nEnrollCount);
}

void CSDK_DEMODlg::OnButtSetDatabase() 
{
	// TODO: Add your control notification handler code here
	
	//////////////////////////////////////////////////////////////////////////
	CString m_strFilePath = file_name_get(FILE_NAME_GET_FPDB, TRUE);
	if(m_strFilePath == _T(""))
		return;
	
	CFile m_File;
	if( !m_File.Open( m_strFilePath,CFile::modeRead | CFile::typeBinary) )
	{
		AfxMessageBox(_T("Read Error"));
		return;
	}
	
	int nLength = (int)m_File.GetLength();
	if( nLength != (FP_TEMPLATE_SIZE * FP_MAX_USERS + FP_MAX_USERS) )
	{
		AfxMessageBox(_T("Invalid File Size"));
		return;
	}
	m_File.Read( &gbyTemplateDB[0], nLength);
	m_File.Close();
	
	int j, nIndexBufPos = FP_TEMPLATE_SIZE * FP_MAX_USERS;

	for(j=0;j<FP_MAX_USERS;j++)
	{
		if(gbyTemplateDB[nIndexBufPos+j])
			break;
	}

	if( j==FP_MAX_USERS )
	{
		m_strResult = _T("No Data");
		UpdateData(FALSE);
		return;
	}
	//////////////////////////////////////////////////////////////////////////
	
	CSDK_DEMODlgWrap _wrap_(this, IDC_BUTT_SET_DATABASE);
	
	if(oem_delete_all() < 0)
	{
		m_strResult = _T("Comm Error");
		return;
	}
// 	if(gwLastAck == NACK_INFO)
// 	{
// 		DisplayErr(gwLastAckParam, 0);
// 		return;
// 	}

	int nAddCount = 0;
	for (int i=0; i<FP_MAX_USERS; i++)
	{
		
		if(gbyTemplateDB[nIndexBufPos+i] == 0)
			continue;

		m_strResult.Format(_T("Setting Templ %d th..."), i);
		UpdateData(FALSE);
		
		memcpy(gbyTemplate, &gbyTemplateDB[i * FP_TEMPLATE_SIZE], FP_TEMPLATE_SIZE);
		
		if(oem_add_template(i) < 0)
		{
			m_strResult = _T("Comm Error");
			return;
		}
		if( gwLastAck==NACK_INFO )
		{
			DisplayErr(gwLastAckParam, i);
			return;
		}
		nAddCount++;
	}
	
	m_strResult.Format(_T("Set Db Success (Count = %d)"), nAddCount);
}

void CSDK_DEMODlg::OnFwUpgrade(BOOL bRestartOnly)
{
// 	CSDK_DEMODlgWrap _wrap_(this, IDC_BUTT_FW_UPGRADE);
	
	EnableBtn( FALSE );
	GetDlgItem(IDC_BUTT_OPEN)->EnableWindow( FALSE );

	if(oem_fw_upgrade(bRestartOnly) < 0)
	{
		m_strResult = _T("Comm Error");
		if( gwLastAck==NACK_INFO )
		{
			DisplayErr( gwLastAckParam, 0 );
		}
		AfxMessageBox(bRestartOnly ? _T("Restart Fail") : _T("Erase Program Fail"));
	}
	else{
		m_strResult = bRestartOnly ? _T("Restart Success") : _T("Erase Program Success");
		AfxMessageBox(bRestartOnly ? _T("Restart Success") : _T("Erase Program Success"));
	}

	UpdateData( FALSE );
	comm_close();
	GetDlgItem(IDC_BUTT_OPEN)->EnableWindow( TRUE );
	GetDlgItem(IDC_BUTT_CANCEL)->EnableWindow(FALSE);
}
void CSDK_DEMODlg::OnButtFwUpgrade()
{
	OnFwUpgrade(FALSE);
}

void CSDK_DEMODlg::OnButtSaveImage() 
{
	// TODO: Add your control notification handler code here
	CSDK_DEMODlgWrap _wrap_(this, IDC_BUTT_SAVE_IMAGE);
	
	if(!UpdateData(TRUE))
		return;
	
	if (gImageType == fp_bmp_none)
	{
		m_strResult = _T("No Image");
		UpdateData(FALSE);
		return;
	}
	
	//////////////////////////////////////////////////////////////////////////
	CString m_strFilePath = file_name_get(FILE_NAME_GET_BMP, FALSE);
	if(m_strFilePath == _T(""))
		return;
	
	if(gImageType == fp_bmp_256)
		fp_bmp_save(m_strFilePath, &fp_bmp256, gbyImg8bit);
	if(gImageType == fp_bmp_raw)
		fp_bmp_save(m_strFilePath, &fp_bmpraw, gbyImgRaw);
	//////////////////////////////////////////////////////////////////////////
	
	m_strResult = _T("Save Image Success");
	UpdateData(FALSE);
}

void CSDK_DEMODlg::OnButtCancel() 
{
	// TODO: Add your control notification handler code here
	m_bContinue = FALSE;
	m_strResult = _T("");
	
}


void CSDK_DEMODlg::OnBnClickedButtGetMassRawImage()
{
	// TODO: Add your control notification handler code here

	CSDK_DEMODlgWrap _wrap_(this, IDC_BUTT_GET_MASS_RAWIMAGE);

	CSDK_DEMODlgWrap_cancel _wrap_cancel_(this);

	LoadingImageRawCont();

	if (m_nImageNumber == 99)
	{
		int nID = m_spinID.GetPos32();
		m_spinID.SetPos32(nID + 1);
		m_nImageNumber = 0;
	}
	UpdateData(FALSE);
}

void CSDK_DEMODlg::OnBnClickedButtRestart()
{
	// TODO: Add your control notification handler code here
	OnFwUpgrade(TRUE);
}

unsigned char t_license_data[2 * 1024 + 20];

void CSDK_DEMODlg::OnBnClickedWriteLicense()
{
	CFileDialog cdlg(TRUE);
	if (cdlg.DoModal() != IDOK) return;
	CString fn = cdlg.GetPathName();

	CFile m_File;
	if (!m_File.Open(fn, CFile::modeRead | CFile::typeBinary))
	{
		AfxMessageBox(_T("Read Error"));
		return;
	}

	int nLength = (int)m_File.GetLength();
	if (nLength != (2*1024))
	{
		AfxMessageBox(_T("Invalid File Size"));
		return;
	}

	byte* license_data = t_license_data + 4;

	m_File.Read(license_data, nLength);
	m_File.Close();

	int ret = oem_write_license(license_data);

	if (ret == 0){
		AfxMessageBox(_T("Writing License is Successed."));
	}
	else{
		AfxMessageBox(_T("Writing License is Failed."));
	}
}


unsigned char uid_buf[50];
void CSDK_DEMODlg::OnBnClickedReadLicense()
{
	unsigned char* uid_data = uid_buf + 10;
	oem_read_uid(uid_data);
	AfxMessageBox(_T("Read uid From Device is Successed."));

	CFileDialog cdlg(false);
	if (cdlg.DoModal() != IDOK) return;
	CString fn = cdlg.GetPathName();

	CFile m_File;
	if (!m_File.Open(fn, CFile::modeCreate | CFile::modeWrite | CFile::typeBinary))
	{
		AfxMessageBox(_T("Write Error"));
		return;
	}

	m_File.Write(uid_data, 12);

	m_File.Close();


	if (gwLastAckParam == 0){
		AfxMessageBox(_T("Reading License is Successed."));
	}
	else{
		AfxMessageBox(_T("Reading License is Failed."));
	}
}


void CSDK_DEMODlg::OnBnClickedButtGetMassImage()
{
	// TODO: Add your control notification handler code here

	CSDK_DEMODlgWrap _wrap_(this, IDC_BUTT_GET_MASS_IMAGE);

	CSDK_DEMODlgWrap_cancel _wrap_cancel_(this);

	LoadingImageCont();

	if (m_nImageNumber == 99)
	{
		int nID = m_spinID.GetPos32();
		m_spinID.SetPos32(nID + 1);
		m_nImageNumber = 0;
	}
	UpdateData(FALSE);
}


void CSDK_DEMODlg::Update_Identify_Result(){
	g_Identify_Tot_Count = g_Identify_Pass_Count + g_Identify_Fail_Count;
	str_Identify_Result.Format(_T("Total : %04d    Pass : %04d     Fail : %04d"), g_Identify_Tot_Count, g_Identify_Pass_Count, g_Identify_Fail_Count);
	UpdateData(FALSE);
}

void CSDK_DEMODlg::OnBnClickedButtonClearHistory()
{
	g_Identify_Pass_Count = 0;
	g_Identify_Fail_Count = 0;

	Update_Identify_Result();
}
