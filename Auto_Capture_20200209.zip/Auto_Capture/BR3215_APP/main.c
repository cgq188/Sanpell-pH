#include "main.h"
#include "Need_For_Lib\global_for_lib.h"

/************************************************************************/
/*                                                                      */
/************************************************************************/
#define APP_POLL 0

int boot_time;
extern UINT8* FlashWriteBuf;

int main(void) {

	AlgBuf = &g_abyImageBuf[4];
	FlashWriteBuf = AlgBuf + ((TOTAL_USE_RAM - 4)*1024 - 4);

	////////////////////////////////////////////////// init
	dev_init();
#if APP_POLL
	monitor_power(TRUE, TRUE);
#endif
	boot_time = GetMainTickCount();

	g_StudyFlag = 0;

	while (1)
	{
		engine_poll();
		USBDoWithPackage();
		CommandProcMain();
#if APP_POLL
		monitor_power(FALSE, FALSE);

		if (!gusbhandle->host_ctrl_started)
		{
			if(app_poll())
				monitor_power(FALSE, TRUE);
		}
		else if(0) //gusbhandle->last_scsi_cmd_time && GetMainTickCount() - gusbhandle->last_scsi_cmd_time > 2000)
		{
			gusbhandle->host_ctrl_started = 0;
			gusbhandle->last_scsi_cmd_time = 0;
		}
#endif
	}
	return 0;
}

