/*
    ChibiOS - Copyright (C) 2006..2015 Giovanni Di Sirio

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    templates/halconf.h
 * @brief   HAL configuration header.
 * @details HAL configuration file, this file allows to enable or disable the
 *          various device drivers from your application. You may also use
 *          this file in order to override the device drivers default settings.
 *
 * @addtogroup HAL_CONF
 * @{
 */

#ifndef _MAIN_H_
#define _MAIN_H_

#include "global.h"
#include "FingerPro.h"
#include "usbd.h"
#include "br32xx.h"
#include "dbgtrace.h"
#include <bs201/bs201_api.h>
#include <bs201/sensor/bs201_bep_fun.h>
#include "BS510.h"
#include <stdio.h>
#include <stdarg.h>
#include <string.h>

#include "main_driver.h"
#include "main_db.h"

BOOL app_is_idle(void);
void app_power_off(void);
BOOL app_poll(void);

#endif /* _MAIN_H_ */

/** @} */
