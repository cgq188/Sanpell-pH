#include "main.h"
#include "iso.h"

/************************************************************************/
/*                                                                      */
/************************************************************************/
//////////////////////////////////////////////////////////////////////////
void SAVE_LONG(void* buf, long l)
{
	BYTE* pby = (BYTE*)buf;

	pby[0] = (l & 0xFF);
	pby[1] = (l & 0xFF00) >> 8;
	pby[2] = (l & 0xFF0000) >> 16;
	pby[3] = (l & 0xFF000000) >> 24;
}

long GET_LONG(void* buf)
{
	BYTE* pby = (BYTE*)buf;
	return (pby[0] | (pby[1] << 8) | (pby[2] << 16) | (pby[3] << 24));
}

void SCSI_UpdateInfo(void)
{
	int i;
	PVDPtr p = (PVDPtr)&gbyIsoDataArea[(HSTERMSTART - HSVOLSTART) * CDBLKSIZE];
	DirRcdPtr dirLong = (DirRcdPtr)&gbyIsoDataArea[g_dwDirEntryPosLong];
	DirRcd tmpDir;
	char buf[768];

	const char* pch = "iLockUSB        ";
	for (i = 0; i < (int)strlen(pch); i++)
	{
		buf[i * 2] = 0;
		buf[i * 2 + 1] = pch[i];
	}
	Flash_WriteInfo(buf, (uint32_t)p->volumeIdentifier, sizeof(p->volumeIdentifier));

	memset(buf, 0, sizeof buf);
	strcpy(buf, "iLock Module");
	sprintf(&buf[strlen(buf)], "\r\n(Service Tag: %08x)\r\n", FW_VERSION);

	memcpy(&tmpDir, dirLong, sizeof(tmpDir));
	SAVE_LONG(&tmpDir.lsbDataLength, strlen(buf));
	SAVE_LONG(&tmpDir.msbDataLength, BE_DWORD(strlen(buf)));
	Flash_WriteInfo(&tmpDir, (uint32_t)dirLong, sizeof(tmpDir));
	Flash_WriteInfo(buf, (uint32_t)&gbyIsoDataArea[(GET_LONG(&dirLong->lsbStart) - HSVOLSTART) * CDBLKSIZE], strlen(buf));
}

DWORD DbSetupCsum(void* pSetup, int nSize)
{
	DWORD* pdw = (DWORD*)pSetup;
	DWORD dwCheckSum = FLASH_CHECKSUM_SIGN;
	int i;

	for (i = 0; i < nSize / 4; i++)
	{
		dwCheckSum += *pdw;
		pdw++;
	}

	return ~dwCheckSum;
}

void DbLicenseWrite(DBLICENSE* pdbLicense)
{
	pdbLicense->dwCheckSum = 0;
	pdbLicense->dwCheckSum = DbSetupCsum(pdbLicense, sizeof(DBLICENSE));

	Flash_WriteInfo(pdbLicense, (uint32_t)&dbLicenseR, sizeof(DBLICENSE));
}

void DbLicenseRead(void)
{
	/*DBLICENSE dbLicense;
	memcpy(&dbLicense, &dbLicenseR, sizeof(DBLICENSE));

	if (DbSetupCsum(&dbLicense, sizeof(DBLICENSE)) != 0)
	{//to default
		memset(&dbLicense, 0, sizeof(DBLICENSE));
		dbLicense.nPrevLockOpened = 0;
		DbLicenseWrite(&dbLicense);
		sb_delete_all();
	}*/
	SCSI_UpdateInfo();
}

void DbLicenseSetPrevLockOpened(int v)
{
	DBLICENSE dbLicense;
	memcpy(&dbLicense, &dbLicenseR, sizeof(DBLICENSE));
	dbLicense.nPrevLockOpened = v;
	DbLicenseWrite(&dbLicense);
}

void sb_add(int pos)
{
	char pTemp[FP_MAX_USERS];
	memcpy(pTemp, gFpIndex, FP_MAX_USERS);
	pTemp[pos] = 1;
	Flash_WriteInfo(pTemp, (uint32_t)gFpIndex, FP_MAX_USERS);
}

void sb_delete(int pos)
{
	char pTemp[FP_MAX_USERS];
	memcpy(pTemp, gFpIndex, FP_MAX_USERS);
	pTemp[pos] = 0;
	Flash_WriteInfo(pTemp, (uint32_t)gFpIndex, FP_MAX_USERS);
}

void sb_delete_all(void)
{
	char pTemp[FP_MAX_USERS];
	memset(pTemp, 0, FP_MAX_USERS);
	Flash_WriteInfo(pTemp, (uint32_t)gFpIndex, FP_MAX_USERS);
}

int sb_enroll_count(void)
{
	int n = 0, i;

	for (i = 0; i < FP_MAX_USERS; i++)
	{
		if (gFpIndex[i])
			n++;
	}

	return n;
}

int sb_next_enroll_pos(void)
{
	int i;

	for (i = 0; i < FP_MAX_USERS; i++)
	{
		if (!gFpIndex[i])
			break;
	}

	return i;
}

BOOL sb_check_pos(int pos)
{
	return (BOOL)gFpIndex[pos];
}
