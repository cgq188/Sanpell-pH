/*
    ChibiOS/HAL - Copyright (C) 2016 Uladzimir Pylinsky aka barthess

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    wdg_lld.h
 * @brief   WDG Driver subsystem low level driver header template.
 *
 * @addtogroup WDG
 * @{
 */
#ifndef MY_SCSI_H_
#define MY_SCSI_H_

#include "hal_usb_msd.h"

#ifdef __cplusplus
extern "C" {
#endif
 extern bool MyScsiCmd (USBMassStorageDriver* msdp, SCSITarget *scsip, msd_cbw_t * pcbw);
 extern void UsbSendEnable(void);
 typedef void (*MyScsiCmd_Finish_Hook_One_Time_Function_type) (void);
 extern void MyScsiCmd_Finish_Hook_One_Time_Function_Config ( MyScsiCmd_Finish_Hook_One_Time_Function_type func );
 extern void MyScsiCmd_Finish_Hook ( void );
#ifdef __cplusplus
}
#endif

#endif /* MY_SCSI_H_ */

/** @} */
