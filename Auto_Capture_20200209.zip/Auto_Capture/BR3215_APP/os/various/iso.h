#ifndef __ISO_H__
#define __ISO_H__

/************************************************************************/
/*                                                                      */
/************************************************************************/
#define	CDBLKSIZE	2048
#define	HSVOLSTART	16		/* where we expect a Primary Volume Descriptor */
#define HSTERMSTART	17		/* where we expect the Volume Descriptor Terminator */
#define	LSBPATH		18		/* location of the lsb path table */
#define	MSBPATH		19		/* location of the msb path table */
#define	DIRECTORY	20		/* location of directory table */
#define DATASTART	21		/* where the first data file starts */

/* round up to the next CDBLKSIZE boundary */
#define ROUND_UP(x)	((x) + CDBLKSIZE -1) & ~(CDBLKSIZE-1)

/* 
 * Primary Volume Descriptor (PVD)
 */
typedef UINT8 byte;
typedef struct
{
	byte	VDType;					/* Must be 1 for PVD */
	char	VSStdId[5];				/* Must be "CD001" */
	byte	VSStdVersion;			/* Must be 1 */
	byte	Reserved1;				/* Must be 0's */
	char	systemIdentifier[32];
	char	volumeIdentifier[32];
	char	Reserved2[8];			/* Must be 0's */
	long	lsbVolumeSpaceSize;
	long	msbVolumeSpaceSize;
	char	Reserved3[32];			/* Must be 0's */
	short	lsbVolumeSetSize;
	short	msbVolumeSetSize;
	short	lsbVolumeSetSequenceNumber;
	short	msbVolumeSetSequenceNumber;
	short	lsbLogicalBlockSize;
	short	msbLogicalBlockSize;
	long	lsbPathTableSize;
	long	msbPathTableSize;
	long	lsbPathTable1;			/* mandatory occurrence */
	long	lsbPathTable2;			/* optional occurrence */
	long	msbPathTable1;			/* mandatory occurrence */
	long	msbPathTable2;			/* optional occurrence */
	char	rootDirectoryRecord[34];
	char	volumeSetIdentifier[128];
	char	publisherIdentifier[128];
	char	dataPreparerIdentifier[128];
	char	applicationIdentifier[128];
	char	copyrightFileIdentifier[37];
	char	abstractFileIdentifier[37];
	char	bibliographicFileIdentifier[37];
	char	volumeCreation[17];
	char	volumeModification[17];
	char	volumeExpiration[17];
	char	volumeEffective[17];
	char	FileStructureStandardVersion;
	char	Reserved4;				/* Must be 0's */
	char	ApplicationUse[512];
	char	FutureStandardization[653];
} PVD, *PVDPtr;

/*
 * Path Table
 */

typedef char	dirIDArray[8];

typedef struct
{
	byte	len_di;			/* length of directory identifier */
	byte	XARlength;	/* Extended Attribute Record Length */
	long	dirLocation;	/* 1st logical block where directory is stored */
	short	parentDN;		/* parent directory number */
	dirIDArray	dirID;		/* directory identifier: actual length is
							 *	9 - [8+Len_di]; there is an extra blank
							 *	byte if Len_di is odd.
							 */
} PathTableRecord, *PathTableRecordPtr;

/*
 * Directory Record
 *	There exists one of these for each file in the directory.
 *	
 */
typedef struct
{
	char	macFlag[2];		/* $42 $41 - 'BA' famous value */
	byte	systemUseID;	/* 06 = HFS */
	byte	fileType[4];	/* such as 'TEXT' or 'STAK' */
	byte	fileCreator[4];	/* such as 'hscd' or 'WILD' */
	byte	finderFlags[2];
} OldAppleExtension;


typedef struct
{
	char	signature[2];		/* $41 $41 - 'AA' famous value */
	byte	extensionLength;	/* $0E for this ID */
	byte	systemUseID;	/* 02 = HFS */
	byte	fileType[4];	/* such as 'TEXT' or 'STAK' */
	byte	fileCreator[4];	/* such as 'hscd' or 'WILD' */
	byte	finderFlags[2];
} AppleExtension;


typedef struct
{
	byte	len_dr;				/* directory record length */
	byte	XARlength;			/* Extended Attribute Record Length */
	long	lsbStart;
	long	msbStart;			/* 1st logical block where file starts */
	long	lsbDataLength;
	long	msbDataLength;
	byte	year;				/* since 1900 */
	byte	month;
	byte	day;
	byte	hour;
	byte	minute;
	byte	second;
	byte	gmtOffset;
	byte	fileFlags;
	byte	interleaveSize;
	byte	interleaveSkip;
	short	lsbVolSetSeqNum;
	short	msbVolSetSeqNum;	/* which volume in volume set contains this file. */
	byte	len_fi;				/* length of file identifier which follows */
	char	fi[37];				/* file identifier: actual is 37-[36+Len_fi].
									contains extra blank byte if Len_fi odd */
	AppleExtension	apple;		/* this actually fits immediately after the fi[] */
								/* field, or after its padding byte. */
} DirRcd, *DirRcdPtr;

extern const UINT32 g_dwDirEntryPosShort;
extern const UINT32 g_dwDirEntryPosLong;
extern const UINT8 gbyIsoDataArea[20480];
extern const int glDiskCap;

#endif /*__ISO_H__*/
