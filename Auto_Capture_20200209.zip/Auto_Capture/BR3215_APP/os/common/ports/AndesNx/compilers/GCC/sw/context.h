#ifndef __CPU_CONTEXT_H__
#define __CPU_CONTEXT_H__

void cpu_enter_sleep(int xclk_on);

#endif

