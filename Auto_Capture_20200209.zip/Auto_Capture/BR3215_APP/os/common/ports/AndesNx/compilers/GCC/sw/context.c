#include <nds32_intrinsic.h>
#include "nds32_regs.h"
#include "context.h"
#include "hal.h"

#define __KEEP_POWER  1


#if __KEEP_POWER
#define __PD_SIGNAL__     ((1U<<1) | (1U<<5) | (0xf << 7) | (3 << 12) | (1 << 16) | (0xD << 21));
#else
#define __PD_SIGNAL__     ((1U<<1) | (1U<<2) | (0xf << 7));
#endif

void system_enter_sleep(void)
{
#if (defined(BR3215) || defined(BR3215c))
  //__nds32__setgie_dis();
  cpm_switch_to_xtal();
  //cpm_stop_pll();
  //HS_SYS->SYS_TICK = 0x7d00 * 5;
  HS_SYS->SYS_TICK &= ~(1u << 24);
  //HS_SF->INTR_MASK = 0;
  //HS_PSO->BTPHY_CFG |= (CPM_BUS_GATE | (1 << 12) | (1 << 10) | (1 << 8));
  cpmDisableGPIO();
  cpmDisableI2C0();
  cpmDisableUSB();
  cpmDisableSPI0();
  cpmDisableSPI1();
  cpmDisableTIM0();
  cpmDisableTIM1();
  cpmDisableTIM2();
  cpmDisableUART0();
  //cpmDisableUART1();
#if defined(BR3215c)
  cpmDisableUART2();
#endif
  cpmDisableRTC();


  HS_ANA->PD_CFG[0] |= ((1u<<12) | (1u<<15) | (3u<<20));
  #if 0
  HS_ANA->PD_CFG[1] |= ((1u<<4) | (1u<<12) | (1u<<28));
  #else
  HS_ANA->PD_CFG[1] &= ~(1u<<28);
  HS_ANA->PD_CFG[1] |= ((1u<<4) | (1u<<12));
  #endif

  //HS_PSO->CPU_CFG = 0x1f1f049e;
  //__WFD();
  //HS_PSO->CPU_CFG = 0x1f1f1f9e;
  //__WFD();

  //HS_PSO->REG_UPD = 0x01;

  HS_PSO->CPM_ANA_CFG |= 2;  
  HS_PSO->REG_UPD = 0x01; 

  //HS_PMU->EXT &= ~(1u<<4);
  HS_PMU->EXT |= 0x7 << 5;
  HS_PMU->ANA_CON |= __PD_SIGNAL__; 
  HS_PMU->BASIC  |= (1u<<30); 
  
  __WFI();
  
  //cpm_start_pll();
  cpm_switch_to_pll();

  //HS_PMU->EXT |= (1u<<4);
  HS_PMU->EXT &= ~(0x7 << 5);
  HS_PMU->ANA_CON &= ~__PD_SIGNAL__;  
  HS_PMU->BASIC  |= (1u<<30);  

  HS_PSO->CPM_ANA_CFG &= ~2u;

  HS_ANA->PD_CFG[0] &= ~((1u<<12) | (1u<<15) | (3u<<20));
  HS_ANA->PD_CFG[1] &= ~((1u<<4) | (1u<<12) | (1u<<28));

  //HS_PSO->CPU_CFG = 0x49e;
  //__WFD();
  //HS_PSO->CPU_CFG = 0x9e;
  //__WFD();

  HS_PSO->REG_UPD = 0x01;
  
  cpmEnableGPIO();
  HS_SYS->SYS_TICK |= (1u << 24);
  //__nds32__setgie_en();
#endif /* defined(BR3215c) */
}
