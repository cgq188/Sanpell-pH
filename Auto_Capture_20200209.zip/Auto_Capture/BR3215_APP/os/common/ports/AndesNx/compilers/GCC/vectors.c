/*
    ChibiOS - Copyright (C) 2006..2015 Giovanni Di Sirio.

    This file is part of ChibiOS.

    ChibiOS is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    ChibiOS is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/**
 * @file    AndesNx/compilers/GCC/vectors.c
 * @brief   Interrupt vectors for N10xx devices.
 *
 * @defgroup AndesNx_VECTORS N10xx Interrupt Vectors
 * @{
 */

#include <stdbool.h>
#include <stdint.h>

#include "anparams.h"

#if (ANDES_NUM_VECTORS > 32)
#error "the constant ANDES_NUM_VECTORS must be less than 32"
#endif

/**
 * @brief   Unhandled exceptions handler.
 * @details Any undefined exception vector points to this function by default.
 *          This function simply stops the system into an infinite loop.
 *
 * @notapi
 */
/*lint -save -e9075 [8.4] All symbols are invoked from asm context.*/
void _unhandled_exception(void) {
/*lint -restore*/

  while (true) {
  }
}

void Vector00(void) __attribute__((weak, alias("_unhandled_exception")));
void Vector01(void) __attribute__((weak, alias("_unhandled_exception")));
void Vector02(void) __attribute__((weak, alias("_unhandled_exception")));
void Vector03(void) __attribute__((weak, alias("_unhandled_exception")));
void Vector04(void) __attribute__((weak, alias("_unhandled_exception")));
void Vector05(void) __attribute__((weak, alias("_unhandled_exception")));
void Vector06(void) __attribute__((weak, alias("_unhandled_exception")));
void Vector07(void) __attribute__((weak, alias("_unhandled_exception")));
void Vector08(void) __attribute__((weak, alias("_unhandled_exception")));
void Vector09(void) __attribute__((weak, alias("_unhandled_exception")));
void Vector10(void) __attribute__((weak, alias("_unhandled_exception")));
void Vector11(void) __attribute__((weak, alias("_unhandled_exception")));
void Vector12(void) __attribute__((weak, alias("_unhandled_exception")));
void Vector13(void) __attribute__((weak, alias("_unhandled_exception")));
void Vector14(void) __attribute__((weak, alias("_unhandled_exception")));
void Vector15(void) __attribute__((weak, alias("_unhandled_exception")));
void Vector16(void) __attribute__((weak, alias("_unhandled_exception")));
void Vector17(void) __attribute__((weak, alias("_unhandled_exception")));
void Vector18(void) __attribute__((weak, alias("_unhandled_exception")));
void Vector19(void) __attribute__((weak, alias("_unhandled_exception")));
void Vector20(void) __attribute__((weak, alias("_unhandled_exception")));
void Vector21(void) __attribute__((weak, alias("_unhandled_exception")));
void Vector22(void) __attribute__((weak, alias("_unhandled_exception")));
void Vector23(void) __attribute__((weak, alias("_unhandled_exception")));
void Vector24(void) __attribute__((weak, alias("_unhandled_exception")));
void Vector25(void) __attribute__((weak, alias("_unhandled_exception")));
void Vector26(void) __attribute__((weak, alias("_unhandled_exception")));
void Vector27(void) __attribute__((weak, alias("_unhandled_exception")));
void Vector28(void) __attribute__((weak, alias("_unhandled_exception")));
void Vector29(void) __attribute__((weak, alias("_unhandled_exception")));
void Vector30(void) __attribute__((weak, alias("_unhandled_exception")));
void Vector31(void) __attribute__((weak, alias("_unhandled_exception")));

/*******************************************************************************
 *       Interrupt vector Table
 ******************************************************************************/

typedef void (*interrupt_vector_table_entry_t)(void);
interrupt_vector_table_entry_t Interrupt_Vector_Table[ANDES_NUM_VECTORS] = {
  Vector00,
  Vector01,
  Vector02,
  Vector03,
  Vector04,
  Vector05,
  Vector06,
  Vector07,
  Vector08,
  Vector09,
  Vector10,
  Vector11,
  Vector12,
  Vector13,
  Vector14,
  Vector15,
  Vector16,
  Vector17,
  Vector18,
  Vector19,
  Vector20,
  Vector21,
  Vector22,
  Vector23,
  Vector24,
  Vector25,
  Vector26,
  Vector27,
  Vector28,
  Vector29,
  Vector30,
  Vector31,
};

/** @} */
