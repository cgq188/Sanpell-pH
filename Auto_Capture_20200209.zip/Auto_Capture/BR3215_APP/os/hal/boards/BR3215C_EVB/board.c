/*
    ChibiOS - Copyright (C) 2006..2015 Giovanni Di Sirio

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

#include "hal.h"

#if HAL_USE_PAL || defined(__DOXYGEN__)
/**
 * @brief   PAL setup.
 * @details Digital I/O ports static configuration as defined in @p board.h.
 *          This variable is used by the HAL when initializing the PAL driver.
 */
const PALConfig pal_default_config = {
  {0, 0, 0, 0, 0, 0},
  {0, 0, 0, 0, 0, 0},
};
#endif

/**
 * @brief   Early initialization code.
 * @details This initialization must be performed just after stack setup
 *          and before any other initialization.
 */
void __early_init(void) {
  cpm_init_clock();
}

#if HAL_USE_MMC_SPI || defined(__DOXYGEN__)
/**
 * @brief   MMC_SPI card detection.
 */
bool mmc_lld_is_card_inserted(MMCDriver *mmcp) {

  (void)mmcp;
  /* TODO: Fill the implementation.*/
  return true;
}

/**
 * @brief   MMC_SPI card write protection detection.
 */
bool mmc_lld_is_write_protected(MMCDriver *mmcp) {

  (void)mmcp;
  /* TODO: Fill the implementation.*/
  return false;
}
#endif

/**
 * @brief   Board-specific initialization code.
 * @todo    Add your board-specific code, if any.
 */
#if !defined(__DOXYGEN__)
__attribute__((weak))
#endif
void boardInit(void) {
  /* USB: D+, D-, CID. */
#if defined(BR3215)
  palSetPadMode(GPIOA, 14, PAL_MODE_INPUT        | PAL_MODE_ALTERNATE(PAD_FUNC_SD_USB) | PAL_MODE_DRIVE_CAP(3));
  palSetPadMode(GPIOB,  0, PAL_MODE_INPUT        | PAL_MODE_ALTERNATE(PAD_FUNC_SD_USB) | PAL_MODE_DRIVE_CAP(3));
  palSetPadMode(GPIOB,  1, PAL_MODE_INPUT_PULLUP | PAL_MODE_ALTERNATE(PAD_FUNC_SD_USB) | PAL_MODE_DRIVE_CAP(3));
#endif
#if defined(BR3215e)
  palSetPadMode(GPIOA, 14, PAL_MODE_INPUT        | PAL_MODE_ALTERNATE(PAD_FUNC_SD_USB) | PAL_MODE_DRIVE_CAP(3));
  palSetPadMode(GPIOA, 15, PAL_MODE_INPUT        | PAL_MODE_ALTERNATE(PAD_FUNC_SD_USB) | PAL_MODE_DRIVE_CAP(3));
  palSetPadMode(GPIOB,  0, PAL_MODE_INPUT_PULLUP | PAL_MODE_ALTERNATE(PAD_FUNC_SD_USB) | PAL_MODE_DRIVE_CAP(3));
#endif
}
