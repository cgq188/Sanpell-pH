Needed header files from ChibiOS:
(Maybe they should be copied here.)

\os\rt\include\chsys.h
\os\rt\ports\AndesNx\compilers\GCC\chtypes.h
\os\rt\ports\AndesNx\chcore_n10.h
\os\rt\ports\AndesNx\chcore.h

peripheral_lib/lib/
