/*
    ChibiOS - Copyright (C) 2006..2016 Giovanni Di Sirio

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    osal.c
 * @brief   OSAL module code.
 *
 * @addtogroup OSAL
 * @{
 */

//#include <errno.h>
#include "hal.h"
#include <sys/types.h>
#include "osal.h"
#include "osal_vt.h"

/*===========================================================================*/
/* Module local definitions.                                                 */
/*===========================================================================*/

/*===========================================================================*/
/* Module exported variables.                                                */
/*===========================================================================*/

/**
 * @brief   Pointer to a halt error message.
 * @note    The message is meant to be retrieved by the debugger after the
 *          system halt caused by an unexpected error.
 */
const char *osal_halt_msg;

/*===========================================================================*/
/* Module local types.                                                       */
/*===========================================================================*/

/*===========================================================================*/
/* Module local variables.                                                   */
/*===========================================================================*/

/*===========================================================================*/
/* Module local functions.                                                   */
/*===========================================================================*/

static void callback_timeout(void *p) {
  osalSysLockFromISR();
  osalThreadResumeI((thread_reference_t *)p, MSG_TIMEOUT);
  osalSysUnlockFromISR();
}

/*===========================================================================*/
/* Module exported functions.                                                */
/*===========================================================================*/

/**
 * @brief   OSAL module initialization.
 *
 * @api
 */
void osalInit(void) {

  vtInit();

  OSAL_INIT_HOOK();
}

/**
 * @brief   System halt with error message.
 *
 * @param[in] reason    the halt message pointer
 *
 * @api
 */
#if !defined(__DOXYGEN__)
__attribute__((weak, noreturn))
#endif
void osalSysHalt(const char *reason) {

  osalSysDisable();
  osal_halt_msg = reason;
  while (true) {
  }
}

#if (PORT_SUPPORTS_RT == TRUE) || defined(__DOXYGEN__)
/**
 * @brief   Returns the current value of the realtime counter.
 *
 * @return              The realtime counter value.
 */
static inline rtcnt_t port_rt_get_counter_value(void) {

  return __nds32__mfsr(NDS32_SR_PFMC1);
}

/**
 * @brief   Realtime window test.
 * @details This function verifies if the current realtime counter value
 *          lies within the specified range or not. The test takes care
 *          of the realtime counter wrapping to zero on overflow.
 * @note    When start==end then the function returns always true because the
 *          whole time range is specified.
 * @note    This function is only available if the port layer supports the
 *          option @p PORT_SUPPORTS_RT.
 *
 * @param[in] cnt       the counter value to be tested
 * @param[in] start     the start of the time window (inclusive)
 * @param[in] end       the end of the time window (non inclusive)
 * @retval true         current time within the specified time window.
 * @retval false        current time not within the specified time window.
 *
 * @xclass
 */
bool osalSysIsCounterWithinX(rtcnt_t cnt, rtcnt_t start, rtcnt_t end) {

  return (bool)((cnt - start) < (end - start));
}

/**
 * @brief   Polled delay.
 * @note    The real delay is always few cycles in excess of the specified
 *          value.
 *
 * @param[in] cycles    number of cycles
 *
 * @xclass
 */
void osalSysPolledDelayX(rtcnt_t cycles) {

  rtcnt_t start = osalSysGetRealtimeCounterX();
  rtcnt_t end  = start + cycles;

  while (osalSysIsCounterWithinX(osalSysGetRealtimeCounterX(), start, end)) {
  }
}
#endif /* PORT_SUPPORTS_RT == TRUE */

/**
 * @brief   System timer handler.
 * @details The handler is used for scheduling and Virtual Timers management.
 *
 * @iclass
 */
void osalOsTimerHandlerI(void) {

  osalDbgCheckClassI();

  vtDoTickI();
}

/**
 * @brief   Checks if a reschedule is required and performs it.
 * @note    I-Class functions invoked from thread context must not reschedule
 *          by themselves, an explicit reschedule using this function is
 *          required in this scenario.
 * @note    Not implemented in this simplified OSAL.
 *
 * @sclass
 */
void osalOsRescheduleS(void) {

}

/**
 * @brief   Current system time.
 * @details Returns the number of system ticks since the @p osalInit()
 *          invocation.
 * @note    The counter can reach its maximum and then restart from zero.
 * @note    This function can be called from any context but its atomicity
 *          is not guaranteed on architectures whose word size is less than
 *          @p systime_t size.
 *
 * @return              The system time in ticks.
 *
 * @xclass
 */
systime_t osalOsGetSystemTimeX(void) {
  return vtlist.vt_systime;
}

/**
 * @brief   Suspends the invoking thread for the specified time.
 *
 * @param[in] time      the delay in system ticks, the special values are
 *                      handled as follow:
 *                      - @a TIME_INFINITE is allowed but interpreted as a
 *                        normal time specification.
 *                      - @a TIME_IMMEDIATE this value is not allowed.
 *                      .
 *
 * @sclass
 */
void osalThreadSleepS(systime_t time) {
  virtual_timer_t vt;
  thread_reference_t tr;

  tr = NULL;
  vtSetI(&vt, time, callback_timeout, (void *)&tr);
  osalThreadSuspendS(&tr);
}

/**
 * @brief   Suspends the invoking thread for the specified time.
 *
 * @param[in] time      the delay in system ticks, the special values are
 *                      handled as follow:
 *                      - @a TIME_INFINITE is allowed but interpreted as a
 *                        normal time specification.
 *                      - @a TIME_IMMEDIATE this value is not allowed.
 *                      .
 *
 * @api
 */
void osalThreadSleep(systime_t time) {

  osalSysLock();
  osalThreadSleepS(time);
  osalSysUnlock();
}

/**
 * @brief   Sends the current thread sleeping and sets a reference variable.
 * @note    This function must reschedule, it can only be called from thread
 *          context.
 *
 * @param[in] trp       a pointer to a thread reference object
 * @return              The wake up message.
 *
 * @sclass
 */
msg_t osalThreadSuspendS(thread_reference_t *trp) {
  thread_t self = {MSG_WAIT};

  osalDbgCheck(trp != NULL);

  *trp = &self;
  while (self.message == MSG_WAIT) {
    osalSysUnlock();
    /* A state-changing interrupt could occur here and cause the loop to
       terminate, an hook macro is executed while waiting.*/
    OSAL_IDLE_HOOK();

    osalSysLock();
  }

  return self.message;
}

static __IO thread_t ThreadSuspendthread;
static char suspendStarted = 0;
msg_t osalThreadSuspendStart(thread_reference_t *trp) {
  ThreadSuspendthread.message = MSG_WAIT;

  osalDbgCheck(trp != NULL);

  (*trp) = (thread_reference_t)&ThreadSuspendthread;

  suspendStarted = 1;

  return MSG_OK;
}

msg_t osalThreadSuspendCheck(thread_reference_t *trp) {

	(void)trp;
  if(suspendStarted == 0)
	  return MSG_RESET; // ?1??��D?a��?��?usb��y?Y�㨹
  else
  {
	  if(ThreadSuspendthread.message == MSG_WAIT) // ?y?��s��?usb��y?Y�㨹
		  return MSG_WAIT;
	  else
		  return MSG_OK;
  }
}
msg_t osalThreadSuspendKill(thread_reference_t *trp) {

	(void)trp;
  osalDbgCheck(trp != NULL);
  suspendStarted = 0;
  return ThreadSuspendthread.message;
}

/**
 * @brief   Sends the current thread sleeping and sets a reference variable.
 * @note    This function must reschedule, it can only be called from thread
 *          context.
 *
 * @param[in] trp       a pointer to a thread reference object
 * @param[in] timeout   the timeout in system ticks, the special values are
 *                      handled as follow:
 *                      - @a TIME_INFINITE the thread enters an infinite sleep
 *                        state.
 *                      - @a TIME_IMMEDIATE the thread is not enqueued and
 *                        the function returns @p MSG_TIMEOUT as if a timeout
 *                        occurred.
 *                      .
 * @return              The wake up message.
 * @retval MSG_TIMEOUT  if the operation timed out.
 *
 * @sclass
 */
msg_t osalThreadSuspendTimeoutS(thread_reference_t *trp, systime_t timeout) {
  msg_t msg;
  virtual_timer_t vt;

  osalDbgCheck(trp != NULL);

  if (TIME_INFINITE == timeout)
   return osalThreadSuspendS(trp);

  vtSetI(&vt, timeout, callback_timeout, (void *)trp);
  msg = osalThreadSuspendS(trp);
  if (vtIsArmedI(&vt))
    vtResetI(&vt);

  return msg;
}

/**
 * @brief   Wakes up a thread waiting on a thread reference object.
 * @note    This function must not reschedule because it can be called from
 *          ISR context.
 *
 * @param[in] trp       a pointer to a thread reference object
 * @param[in] msg       the message code
 *
 * @iclass
 */
void osalThreadResumeI(thread_reference_t *trp, msg_t msg) {

  osalDbgCheck(trp != NULL);

  if (*trp != NULL) {
    (*trp)->message = msg;
    *trp = NULL;
  }
}

/**
 * @brief   Wakes up a thread waiting on a thread reference object.
 * @note    This function must reschedule, it can only be called from thread
 *          context.
 *
 * @param[in] trp       a pointer to a thread reference object
 * @param[in] msg       the message code
 *
 * @iclass
 */
void osalThreadResumeS(thread_reference_t *trp, msg_t msg) {

  osalDbgCheck(trp != NULL);

  if (*trp != NULL) {
    (*trp)->message = msg;
    *trp = NULL;
  }
}

/**
 * @brief   Enqueues the caller thread.
 * @details The caller thread is enqueued and put to sleep until it is
 *          dequeued or the specified timeouts expires.
 *
 * @param[in] tqp       pointer to the threads queue object
 * @param[in] timeout   the timeout in system ticks, the special values are
 *                      handled as follow:
 *                      - @a TIME_INFINITE the thread enters an infinite sleep
 *                        state.
 *                      - @a TIME_IMMEDIATE the thread is not enqueued and
 *                        the function returns @p MSG_TIMEOUT as if a timeout
 *                        occurred.
 *                      .
 * @return              The message from @p osalQueueWakeupOneI() or
 *                      @p osalQueueWakeupAllI() functions.
 * @retval MSG_TIMEOUT  if the thread has not been dequeued within the
 *                      specified timeout or if the function has been
 *                      invoked with @p TIME_IMMEDIATE as timeout
 *                      specification.
 *
 * @sclass
 */
msg_t osalThreadEnqueueTimeoutS(threads_queue_t *tqp, systime_t timeout) {
  msg_t msg;
  virtual_timer_t vt;

  osalDbgCheck(tqp != NULL);

  if (TIME_IMMEDIATE == timeout)
    return MSG_TIMEOUT;

  tqp->tr = NULL;

  if (TIME_INFINITE == timeout)
   return osalThreadSuspendS(&tqp->tr);

  vtSetI(&vt, timeout, callback_timeout, (void *)&tqp->tr);
  msg = osalThreadSuspendS(&tqp->tr);
  if (vtIsArmedI(&vt))
    vtResetI(&vt);

  return msg;
}

/**
 * @brief   Dequeues and wakes up one thread from the queue, if any.
 *
 * @param[in] tqp       pointer to the threads queue object
 * @param[in] msg       the message code
 *
 * @iclass
 */
void osalThreadDequeueNextI(threads_queue_t *tqp, msg_t msg) {

  osalDbgCheck(tqp != NULL);

  osalThreadResumeI(&tqp->tr, msg);
}

/**
 * @brief   Dequeues and wakes up all threads from the queue.
 *
 * @param[in] tqp       pointer to the threads queue object
 * @param[in] msg       the message code
 *
 * @iclass
 */
void osalThreadDequeueAllI(threads_queue_t *tqp, msg_t msg) {

  osalDbgCheck(tqp != NULL);

  osalThreadResumeI(&tqp->tr, msg);
}

/**
 * @brief   Add flags to an event source object.
 *
 * @param[in] esp       pointer to the event flags object
 * @param[in] flags     flags to be ORed to the flags mask
 *
 * @iclass
 */
void osalEventBroadcastFlagsI(event_source_t *esp, eventflags_t flags) {

  osalDbgCheck(esp != NULL);

  esp->flags |= flags;
  if (esp->cb != NULL) {
    esp->cb(esp);
  }
}

/**
 * @brief   Add flags to an event source object.
 *
 * @param[in] esp       pointer to the event flags object
 * @param[in] flags     flags to be ORed to the flags mask
 *
 * @iclass
 */
void osalEventBroadcastFlags(event_source_t *esp, eventflags_t flags) {

  osalDbgCheck(esp != NULL);

  osalSysLock();
  osalEventBroadcastFlagsI(esp, flags);
  osalSysUnlock();
}

/**
 * @brief   Event callback setup.
 * @note    The callback is invoked from ISR context and can
 *          only invoke I-Class functions. The callback is meant
 *          to wakeup the task that will handle the event by
 *          calling @p osalEventGetAndClearFlagsI().
 * @note    This function is not part of the OSAL API and is provided
 *          exclusively as an example and for convenience.
 *
 * @param[in] esp       pointer to the event flags object
 * @param[in] cb        pointer to the callback function
 * @param[in] param     parameter to be passed to the callback function
 *
 * @api
 */
void osalEventSetCallback(event_source_t *esp,
                          eventcallback_t cb,
                          void *param) {

  osalDbgCheck(esp != NULL);

  esp->cb    = cb;
  esp->param = param;
}

/**
 * @brief   Locks the specified mutex.
 * @post    The mutex is locked and inserted in the per-thread stack of owned
 *          mutexes.
 *
 * @param[in,out] mp    pointer to the @p mutex_t object
 *
 * @api
 */
void osalMutexLock(mutex_t *mp) {

  osalDbgCheck(mp != NULL);

  *mp = 1;
}

/**
 * @brief   Unlocks the specified mutex.
 * @note    The HAL guarantees to release mutex in reverse lock order. The
 *          mutex being unlocked is guaranteed to be the last locked mutex
 *          by the invoking thread.
 *          The implementation can rely on this behavior and eventually
 *          ignore the @p mp parameter which is supplied in order to support
 *          those OSes not supporting a stack of the owned mutexes.
 *
 * @param[in,out] mp    pointer to the @p mutex_t object
 *
 * @api
 */
void osalMutexUnlock(mutex_t *mp) {

  osalDbgCheck(mp != NULL);

  *mp = 0;
}

/**
 * @brief   Wait operation on the binary semaphore.
 *
 * @param[in] bsp       pointer to a @p binary_semaphore_t structure
 * @param[in] time      the number of ticks before the operation timeouts,
 *                      the following special values are allowed:
 *                      - @a TIME_IMMEDIATE immediate timeout.
 *                      - @a TIME_INFINITE no timeout.
 *                      .
 * @return              A message specifying how the invoking thread has been
 *                      released from the semaphore.
 * @retval MSG_OK       if the binary semaphore has been successfully taken.
 * @retval MSG_RESET    if the binary semaphore has been reset using
 *                      @p bsemReset().
 * @retval MSG_TIMEOUT  if the binary semaphore has not been signaled or reset
 *                      within the specified timeout.
 *
 * @sclass
 */
msg_t osalBSemWaitTimeoutS(binary_semaphore_t *bsp, systime_t time) {

  osalDbgCheckClassS();
  osalDbgCheck(bsp != NULL);

  if (time == TIME_IMMEDIATE) {
  }
  else if (time == TIME_INFINITE) {
    while (bsp->bs_sem == true)
      ;
  }
  else {
    virtual_timer_t vt;
    thread_t self = {MSG_WAIT};
    thread_reference_t tr;

    tr = &self;
    vtSetI(&vt, time, callback_timeout, (void *)&tr);

    while (self.message == MSG_WAIT) {
      osalSysUnlock();
      /* A state-changing interrupt could occur here and cause the loop to
         terminate, an hook macro is executed while waiting.*/
      OSAL_IDLE_HOOK();
      if (bsp->bs_sem != true) {
        self.message = MSG_OK;
      }
      osalSysLock();
    }

    if (vtIsArmedI(&vt))
      vtResetI(&vt);
  }

  if (bsp->bs_sem != true) {
    bsp->bs_sem = true;
    return MSG_OK;
  }
  else
    return MSG_TIMEOUT;
}

/**
 * Wait and check for pf() to be true until timeout.
 *
 * @param pf         Pointer to a BoolFunction object which returns true when succeed.
 * @param args       Array of void pointers to be transferred to pf().
 * @param timeout    timeout in milliseconds.
 * @return           true if pf() return true, false if timeout.
 */
bool osalWaitTimeoutX(BoolFunction pf, void *args[], systime_t timeout) {

	systime_t start, end;
	bool infinite = false;

	if (timeout == TIME_IMMEDIATE) {
		return false;
  }
  else if (timeout == TIME_INFINITE) {
    infinite = true;
  }

  start = osalOsGetSystemTimeX();
  end = start + OSAL_MS2ST(timeout);

  while (true) {
  	if (pf && pf(args))
  		return true;
  	if (infinite)
  		continue;
  	if (!osalOsIsTimeWithinX(osalOsGetSystemTimeX(), start, end))
  		return false;
  }
}

#if OSAL_CFG_USE_HEAP == TRUE

extern uint8_t __heap_base__[];
extern uint8_t __heap_end__[];
extern uint8_t _end[];

/**
 * @brief   Override C library's default _sbrk_r() called by the malloc().
 * @note    Copied from and edited based on syscalls.c.
 */
caddr_t _sbrk_r(struct _reent *r, int incr)
{
  (void)r;

  static uint8_t *heap_end = NULL;
	uint8_t *prev_heap_end;

	if (heap_end == NULL)
		heap_end = __heap_base__;
	prev_heap_end = heap_end;

	if (heap_end + incr > __heap_end__) {
		// __errno_r(r) = ENOMEM;
		return (caddr_t)-1;
	}

	heap_end += incr;
	return (caddr_t)prev_heap_end;
}

/**
 * @brief    Allocate maximum free RAM to heap used by malloc().
 */
static void _heap_init(void) {

  char *p = malloc(__heap_end__ - __heap_base__ - 8);
  if (p)
  	free(p);
}
#endif /* #if OSAL_CFG_USE_HEAP == TRUE */

/**
 * @brief   System initialization.
 * @details After executing this function the current instructions stream
 *          becomes the main thread.
 * @pre     Interrupts must disabled before invoking this function.
 * @post    The main thread is created with priority @p NORMALPRIO and
 *          interrupts are enabled.
 *
 * @special
 */
void osalSysInit(void) {

//   port_init();
//  _vt_init();

//#if OSAL_CFG_USE_TM == TRUE
//  _tm_init();
//#endif

//#if OSAL_CFG_USE_MEMCORE == TRUE
//  _core_init();
//#endif

#if OSAL_CFG_USE_HEAP == TRUE
  _heap_init();
#endif

  osalSysEnable();
}

/** @} */
