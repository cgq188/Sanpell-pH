/*
  ChibiOS/HAL - Copyright (C) 2019 BRMICRO Technologies
  pengjiang, 20140714
  wupingping, 20160614
  luwei, 20180710

  Licensed under the Apache License, Version 2.0 (the "License");
  you may not use this file except in compliance with the License.
  You may obtain a copy of the License at

  http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
*/
#include <string.h>
#include "ch.h"
#include "hal.h"

#if ((HAL_USE_USB_AUDIO == TRUE) && defined(hscAudiophile)) || defined(__DOXYGEN__)

#define IF_NUM_ASI_OUT                  0x02
#define IF_NUM_ASI_IN                   0x03

/*===========================================================================*/
/* Driver local definitions.                                                 */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local variables and types.                                         */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local functions.                                                   */
/*===========================================================================*/

static void set_mute(USBDriver *usbp)
{
  USBAudioDriver *usbaudp = (USBAudioDriver *)usbp->out_params[0];
  uint8_t unitId = usbp->setup[5];
  uint8_t idx;

  chDbgAssert(usbp&&usbaudp, "null pointer");

  idx = (unitId == UNITID_DAC) ? IDX_PLY : IDX_REC;

  if (NULL != usbaudp->config->audio_ctl) {
    uint32_t cmd = idx == IDX_PLY ? UA_SIGNAL_PLY_SET_MUTE : UA_SIGNAL_REC_SET_MUTE;
    usbaudp->config->audio_ctl(cmd, &usbaudp->vol_ctl[idx].bmute);
  }
}

static void set_vol(USBDriver *usbp)
{
  USBAudioDriver *usbaudp = (USBAudioDriver *)usbp->out_params[0];
  uint8_t unitId = usbp->setup[5];
  uint8_t idx;

  chDbgAssert(usbp&&usbaudp, "null pointer");

  idx = (unitId == UNITID_DAC) ? IDX_PLY : IDX_REC;

  if (NULL != usbaudp->config->audio_ctl) {
    uint32_t cmd = idx == IDX_PLY ? UA_SIGNAL_PLY_SET_VOL : UA_SIGNAL_REC_SET_VOL;
    usbaudp->config->audio_ctl(cmd, &usbaudp->vol_ctl[idx].wvol[0]);
  }
}

static bool_t usbaud_class_req_handler_if(USBDriver *usbp)
{
  uint8_t request = usbp->setup[1];
  uint8_t controlselector = usbp->setup[3];
  uint8_t unitId = usbp->setup[5];
  uint8_t ch = usbp->setup[2];
  uint16_t xferlen = 0xffff;
  USBAudioDriver *usbaudp = (USBAudioDriver *)usbp->out_params[0];
  usbcallback_t cb = NULL;
  uint8_t *buf = NULL;
  uint8_t idx;

  chDbgAssert(usbp&&usbaudp, "null pointer");

  if (unitId != UNITID_DAC &&
      unitId != UNITID_ADC) {
    return false;
  }

  xferlen = (usbp->setup[7] << 8) | usbp->setup[6];
  if (xferlen == 0xffff) {
    return false;
  }

  idx = (unitId == UNITID_DAC)? IDX_PLY : IDX_REC;
  if (0 == ch) {
    /* both channel */
  }
  else if (ch <= 2) {
    /* specific channel 1 or channel 2 */
    ch--;
  }

  if ((usbp->setup[0] & USB_RTYPE_DIR_MASK) == USB_RTYPE_DIR_HOST2DEV) {
    //set commands
    if (controlselector == MUTE_CONTROL) {
      xferlen = min(1, xferlen);
      cb = set_mute;
      buf = &usbaudp->vol_ctl[idx].bmute;
    }
    else if (controlselector == VOLUME_CONTROL) {
      xferlen = min(2, xferlen);
      cb = set_vol;
      buf = (uint8_t *)&usbaudp->vol_ctl[idx].wvol[ch];
    }
  }
  else {
    //get commands
    if (request == GET_CUR) {
      if (controlselector == MUTE_CONTROL) {
        xferlen = min(1, xferlen);
        buf = &usbaudp->vol_ctl[idx].bmute;
      }
      else if (controlselector == VOLUME_CONTROL) {
        xferlen = min(2, xferlen);
        buf = (uint8_t *)&usbaudp->vol_ctl[idx].wvol[ch];
      }
    }
    else if ((request == GET_MIN) && (controlselector == VOLUME_CONTROL)) {
      xferlen = min(2, xferlen);
      buf = (uint8_t *)&usbaudp->config->vol_range[idx].min;
    }
    else if ((request == GET_MAX) && (controlselector == VOLUME_CONTROL)) {
      xferlen = min(2, xferlen);
      buf = (uint8_t *)&usbaudp->config->vol_range[idx].max;
    }
    else if ((request == GET_RES) && (controlselector == VOLUME_CONTROL)) {
      xferlen = min(2, xferlen);
      buf = (uint8_t *)&usbaudp->config->vol_range[idx].res;
    }
  }

  usbSetupTransfer(usbp, buf, xferlen, cb);
  return true;
}

static bool usbaud_class_req_handler_ep(USBDriver *usbp)
{
  chDbgAssert(usbp, "null pointer");

  if ((usbp->setup[3] == SAMPLING_FREQ_CONTROL) &&
      (usbp->setup[1] == SET_CUR)) {
    /* support the fixed sample rate only */
    #if 0
    uint8_t idx = (EP_NUM_ASI_OUT == usbp->setup[4]) ? IDX_PLY : IDX_REC;
    uint16_t xferlen = min(3, (usbp->setup[7] << 8) | usbp->setup[6]);
    usbSetupTransfer(usbp, &g_Sr[0], xferlen, set_sr);
    return true;
    #endif
  }
  return false;
}

static bool usbaud_std_req_handler_set_interface(USBDriver *usbp)
{
  USBAudioDriver *usbaudp = (USBAudioDriver *)usbp->out_params[0];
  uint8_t altset = usbp->setup[2];
  uint8_t idx;
  audio_control_ops_t audio_ctl = usbaudp->config->audio_ctl;

  usbSetupTransfer(usbp, NULL, 0, NULL);

  if (NULL == audio_ctl) {
    return true;
  }

  idx = (IF_NUM_ASI_OUT == usbp->setup[4]) ? IDX_PLY : IDX_REC;

  if (altset == 0) {
    if (idx == IDX_PLY) {
      audio_ctl(UA_SIGNAL_PLY_STOP, NULL);
    }
    else {
      audio_ctl(UA_SIGNAL_REC_STOP, NULL);
    }
  }
  else {
    if (idx == IDX_PLY) {
      audio_ctl(UA_SIGNAL_PLY_START, NULL);
    }
    else {
      audio_ctl(UA_SIGNAL_REC_START, NULL);
    }
  }

  return true;
}

/*===========================================================================*/
/* Driver exported functions.                                                */
/*===========================================================================*/

bool usbaudRequestsHook(USBDriver *usbp)
{
  USBAudioDriver *usbaudp = (USBAudioDriver *)usbp->out_params[0];

  /* host starts to enumerate but device function driver is not started */
  if ((NULL == usbaudp) || (usbaudp->state != USB_AUDIO_STATE_START)) {
    return false;
  }

  if (((usbp->setup[0] & USB_RTYPE_TYPE_MASK) == USB_RTYPE_TYPE_STD) &&
      ((usbp->setup[0] & USB_RTYPE_RECIPIENT_MASK) == USB_RTYPE_RECIPIENT_INTERFACE)) {
    /* start/stop */
    return usbaud_std_req_handler_set_interface(usbp);
  }

  if ((usbp->setup[0] & USB_RTYPE_TYPE_MASK) != USB_RTYPE_TYPE_CLASS) {
    return false;
  }

  if ((usbp->setup[0] & USB_RTYPE_RECIPIENT_MASK) == USB_RTYPE_RECIPIENT_ENDPOINT) {
    if ((EP_NUM_ASI_OUT == usbp->setup[4]) ||
        (EP_NUM_ASI_IN  == usbp->setup[4])) {
      /* sample rate */
      return usbaud_class_req_handler_ep(usbp);
    }
  }

  if ((usbp->setup[0] & USB_RTYPE_RECIPIENT_MASK) == USB_RTYPE_RECIPIENT_INTERFACE) {
    /* volume, mute etc */
    return usbaud_class_req_handler_if(usbp);
  }
  return false;
}

/**
 * @brief   Default data received callback.
 * @details The application must use this function as callback for the OUT
 *          data endpoint.
 *
 * @param[in] usbp      pointer to the @p USBDriver object
 * @param[in] ep        OUT endpoint number
 */
void usbaudDataReceived(USBDriver *usbp, usbep_t ep)
{
  uint8_t *buf;
  USBAudioDriver *usbaudp = (USBAudioDriver *)usbp->out_params[0];
  const USBEndpointConfig *epcp = usbp->epc[ep];
  USBOutEndpointState *osp = epcp->out_state;

  if (usbaudp == NULL) {
    return;
  }

  if (NULL != usbaudp->config->ply_stream) {
    size_t ret = usbaudp->config->ply_stream(osp->rxbuf, osp->rxcnt);
    if (0 == ret) {
      /* audio playing is stopped */
      return;
    }
  }

  osalSysLockFromISR();
  usbaudp->ply_idx = (usbaudp->ply_idx + 1) % USB_PLY_BUF_NUM;
  buf = usbaudp->ply_buf + USB_PLY_BUF_SIZ * usbaudp->ply_idx;
  usbStartReceiveI(usbp, ep, buf, USB_PLY_BUF_SIZ);
  osalSysUnlockFromISR();
}

void usbaudObjectInit(USBAudioDriver *usbaudp)
{
  memset(usbaudp, 0x00, sizeof(USBAudioDriver));
  usbaudp->state = USB_AUDIO_STATE_STOP;
}

void usbaudStart(USBAudioDriver *usbaudp, USBDriver *usbp,
                 const USBAudioConfig *config,
                 uint8_t *ply_buf, uint8_t *rec_buf)
{
  int ddb_left, ddb_right;

  chDbgAssert(usbp&&usbaudp, "null pointer");

  if(usbaudp->state == USB_AUDIO_STATE_START)
    return ;

  usbaudp->usbp = usbp;
  usbaudp->config = config;
  usbaudp->ply_buf = ply_buf;
  usbaudp->rec_buf = rec_buf;
  usbp->out_params[0] = usbaudp;

  usbaudp->vol_ctl[IDX_PLY].bmute = false;
  audioPlayGetVolume(&ddb_left, &ddb_right);
  usbaudp->vol_ctl[IDX_PLY].wvol[0] = ddb_left * 25;
  usbaudp->vol_ctl[IDX_PLY].wvol[1] = ddb_right * 25;

  usbaudp->vol_ctl[IDX_REC].bmute = false;
  audioRecordGetVolume(&ddb_left, &ddb_right);
  usbaudp->vol_ctl[IDX_REC].wvol[0] = ddb_left * 25;
  usbaudp->vol_ctl[IDX_REC].wvol[1] = ddb_right * 25;

  usbaudp->state = USB_AUDIO_STATE_START;
}

void usbaudStop(USBAudioDriver *usbaudp)
{
  usbaudp->state = USB_AUDIO_STATE_STOP;
}

#endif
