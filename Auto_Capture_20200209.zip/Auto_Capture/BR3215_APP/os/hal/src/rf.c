/*
    ChibiOS/RT - Copyright (C) 2006,2007,2008,2009,2010,
                 2011,2012,2013 Giovanni Di Sirio.
		 Copyright (C) 2019 BRMICRO Technologies
                 shangzhou.hu@BRMicro.com.cn
    This file is part of ChibiOS/RT.

    ChibiOS/RT is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    ChibiOS/RT is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

                                      ---

    A special exception to the GPL can be applied should you wish to distribute
    a combined work that includes ChibiOS/RT, without being obliged to provide
    the source code for any proprietary components. See the file exception.txt
    for full details of how and when the exception can be applied.
*/

#include <string.h>
#include "hal.h"
#include "chprintf.h"

#if HAL_USE_RF || defined(__DOXYGEN__)

/*
 * Interface implementation, the following functions just invoke the equivalent
 * queue-level function or macro.
 */

static size_t write(void *op, const uint8_t *bp, size_t n) {

	uint8_t status = 0;
	uint8_t i;
	uint8_t buf[32];
	size_t len = oqWriteTimeout(&((Rf24gDriver *)op)->oqueue, bp,
                         n, TIME_INFINITE);

rf_write_tx_payload:
	rf_lld_Rd_Reg(MAC6200_BANK0_STATUS, &status, 1);
	if(!(status & MAC6200_TX_FIFO_FULL))
	{
		if (!oqIsEmptyI(&((Rf24gDriver *)op)->oqueue)) {

		i = 0;
		buf[0] = 0x5a;
		do {
			msg_t b;

			osalSysLockFromISR();
			b = oqGetI(&((Rf24gDriver *)op)->oqueue);
			osalSysUnlockFromISR();
			if (b < Q_OK) {
			  break;
			}

			buf[++i] = b;
			if(i==31)
			{
				buf[0] = 0xa5;
				break;
			}


		   } while (1);

		   rf_lld_Write_Ack_Payload(0, buf, i+1);
		   if(i==31)
			   goto rf_write_tx_payload;
		}

	}

	return len;

}

static size_t read(void *ip, uint8_t *bp, size_t n) {

  return iqReadTimeout(&((Rf24gDriver *)ip)->iqueue, bp,
                       n, TIME_INFINITE);
}

static msg_t put(void *ip, uint8_t b) {

  ip = ip;
  b = b;
  return MSG_OK;

}

static msg_t get(void *ip) {

  return iqGetTimeout(&((Rf24gDriver *)ip)->iqueue, TIME_INFINITE);
}

static msg_t putt(void *ip, uint8_t b, systime_t timeout) {

  return oqPutTimeout(&((Rf24gDriver *)ip)->oqueue, b, timeout);
}

static msg_t gett(void *ip, systime_t timeout) {

  return iqGetTimeout(&((Rf24gDriver *)ip)->iqueue, timeout);
}

static size_t writet(void *ip, const uint8_t *bp, size_t n, systime_t timeout) {

  return oqWriteTimeout(&((Rf24gDriver *)ip)->oqueue, bp, n, timeout);
}

static size_t readt(void *ip, uint8_t *bp, size_t n, systime_t timeout) {

  return iqReadTimeout(&((Rf24gDriver *)ip)->iqueue, bp, n, timeout);
}

static const struct Rf24gDriverVMT vmt = {
  write, read, put, get,
  putt, gett, writet, readt
};

/*===========================================================================*/
/* Driver exported functions.                                                */
/*===========================================================================*/

/**
 * @brief   Serial Driver initialization.
 * @note    This function is implicitly invoked by @p halInit(), there is
 *          no need to explicitly initialize the driver.
 *
 * @init
 */
void rf24gInit(void) {

  rf24g_lld_init();
}

/**
 * @brief   Initializes a generic full duplex driver object.
 * @details The HW dependent part of the initialization has to be performed
 *          outside, usually in the hardware initialization code.
 *
 * @param[out] rdp      pointer to a @p Rf24gDriver structure
 * @param[in] inotify   pointer to a callback function that is invoked when
 *                      some data is read from the Queue. The value can be
 *                      @p NULL.
 * @param[in] onotify   pointer to a callback function that is invoked when
 *                      some data is written in the Queue. The value can be
 *                      @p NULL.
 *
 * @init
 */
void rf24gObjectInit(Rf24gDriver *rdp, qnotify_t inotify, qnotify_t onotify) {

  rdp->vmt = &vmt;
  osalEventObjectInit(&rdp->event);
  rdp->state = RF24G_STOP;
  iqObjectInit(&rdp->iqueue, rdp->ib, RF24G_BUFFERS_SIZE, inotify, rdp);
  oqObjectInit(&rdp->oqueue, rdp->ob, RF24G_BUFFERS_SIZE, onotify, rdp);
}

/**
 * @brief   Configures and starts the driver.
 *
 * @param[in] rdp       pointer to a @p Rf24gDriver object
 * @param[in] config    the architecture-dependent serial driver configuration.
 *                      If this parameter is set to @p NULL then a default
 *                      configuration is used.
 *
 * @api
 */
void rf24gStart(Rf24gDriver *rdp, RFConfig *config) {

  osalDbgCheck(rdp != NULL);

  osalSysLock();
  osalDbgAssert((rdp->state == RF24G_STOP) || (rdp->state == RF24G_READY),
                "invalid state");
  rdp->config = config;
  rf24g_lld_start(rdp);
  rdp->state = RF24G_READY;
  osalSysUnlock();
}

/**
 * @brief   Stops the driver.
 * @details Any thread waiting on the driver's queues will be awakened with
 *          the message @p Q_RESET.
 *
 * @param[in] rdp       pointer to a @p Rf24gDriver object
 *
 * @api
 */
void rf24gStop(Rf24gDriver *rdp) {

  osalDbgCheck(rdp != NULL);

  osalSysLock();
  osalDbgAssert((rdp->state == RF24G_STOP) || (rdp->state == RF24G_READY),
                "invalid state");
  rf24g_lld_stop(rdp);
  rdp->state = RF24G_STOP;
  oqResetI(&rdp->oqueue);
  iqResetI(&rdp->iqueue);
  osalOsRescheduleS();
  osalSysUnlock();
}

/**
 * @brief   Handles incoming data.
 * @details This function must be called from the input interrupt service
 *          routine in order to enqueue incoming data and generate the
 *          related events.
 * @note    The incoming data event is only generated when the input queue
 *          becomes non-empty.
 * @note    In order to gain some performance it is suggested to not use
 *          this function directly but copy this code directly into the
 *          interrupt service routine.
 *
 * @param[in] rdp       pointer to a @p Rf24gDriver structure
 * @param[in] b         the byte to be written in the driver's Input Queue
 *
 * @iclass
 */
void rf24gIncomingDataI(Rf24gDriver *rdp, uint8_t b) {

  osalDbgCheckClassI();
  osalDbgCheck(rdp != NULL);

  if (iqIsEmptyI(&rdp->iqueue))
    chnAddFlagsI(rdp, CHN_INPUT_AVAILABLE);
  iqPutI(&rdp->iqueue, b) ;
  if (iqPutI(&rdp->iqueue, b) < Q_OK)
    chnAddFlagsI(rdp, RF24G_OVERRUN_ERROR);
}

/**
 * @brief   Handles outgoing data.
 * @details Must be called from the output interrupt service routine in order
 *          to get the next byte to be transmitted.
 * @note    In order to gain some performance it is suggested to not use
 *          this function directly but copy this code directly into the
 *          interrupt service routine.
 *
 * @param[in] rdp       pointer to a @p Rf24gDriver structure
 * @return              The byte value read from the driver's output queue.
 * @retval Q_EMPTY      if the queue is empty (the lower driver usually
 *                      disables the interrupt source when this happens).
 *
 * @iclass
 */
msg_t rf24gRequestDataI(Rf24gDriver *rdp) {
  msg_t  b;

  osalDbgCheckClassI();
  osalDbgCheck(rdp != NULL);

  b = oqGetI(&rdp->oqueue);
  if (b < Q_OK)
    chnAddFlagsI(rdp, CHN_OUTPUT_EMPTY);
  return b;
}

/**
 * @brief   switch rf to PRX mode
 *
 * @iclass
 */
void rf24gStartReceiveI(void) {

	uint8_t tmp;

	rf_lld_Rd_Reg(MAC6200_BANK0_CONFIG, &tmp, 1);
	tmp |= 0x01;
	rf_lld_Wr_Reg(MAC6200_BANK0_CONFIG, &tmp, 1);
	rf_lld_CE_High();
}

void MAC6200_set_freq(unsigned int freq)
{
  uint8_t reg_value = freq-2400;
  MAC6200_CE_Low();
  MAC6200_Bank0_Activate();
  MAC6200_Write_Reg(MAC6200_BANK0_RF_CH, &reg_value, 1);
  MAC6200_CE_High();
}

void MAC6200_dump_RF_register(BaseSequentialStream *chp)
{
  uint8_t reg_value;
  uint8_t temp[5]; 
  int8_t i;
  
  MAC6200_Bank0_Activate();
    
  MAC6200_Read_Reg(MAC6200_BANK0_CONFIG, &reg_value, 1);
  chprintf(chp, "MAC6200_BANK0_CONFIG: %02x\r\n", reg_value);  
  
  MAC6200_Read_Reg(MAC6200_BANK0_EN_AA, &reg_value, 1);
  chprintf(chp, "MAC6200_BANK0_EN_AA: %02x\r\n", reg_value); 
  
  MAC6200_Read_Reg(MAC6200_BANK0_EN_RXADDR, &reg_value, 1);
  chprintf(chp, "MAC6200_BANK0_EN_RXADDR: %02x\r\n", reg_value); 

  MAC6200_Read_Reg(MAC6200_BANK0_SETUP_AW, &reg_value, 1);
  chprintf(chp, "MAC6200_BANK0_SETUP_AW: %02x\r\n", reg_value); 

  MAC6200_Read_Reg(MAC6200_BANK0_SETUP_RETR, &reg_value, 1);
  chprintf(chp, "MAC6200_BANK0_SETUP_RETR: %02x\r\n", reg_value);  
  
  MAC6200_Read_Reg(MAC6200_BANK0_RF_CH, &reg_value, 1);
  chprintf(chp, "MAC6200_BANK0_RF_CH: %02x\r\n", reg_value); 
  
  MAC6200_Read_Reg(MAC6200_BANK0_RF_SETUP, &reg_value, 1);
  chprintf(chp, "MAC6200_BANK0_RF_SETUP: %02x\r\n", reg_value); 

  MAC6200_Read_Reg(MAC6200_BANK0_STATUS, &reg_value, 1);
  chprintf(chp, "MAC6200_BANK0_STATUS: %02x\r\n", reg_value); 
  
  MAC6200_Read_Reg(MAC6200_BANK0_OBSERVE_TX, &reg_value, 1);
  chprintf(chp, "MAC6200_BANK0_OBSERVE_TX: %02x\r\n", reg_value); 
  
  MAC6200_Read_Reg(MAC6200_BANK0_PRE_LEN, &reg_value, 1);
  chprintf(chp, "MAC6200_BANK0_PRE_LEN: %02x\r\n", reg_value);

  MAC6200_Read_Reg(MAC6200_BANK0_RX_ADDR_P0, temp, 5);
  chprintf(chp, "MAC6200_BANK0_RX_ADDR_P0: "); 
  for(i=4;i>=0;i--)
    chprintf(chp, "%02x " , temp[i]);
  chprintf(chp, "\r\n");
  
  MAC6200_Read_Reg(MAC6200_BANK0_RX_ADDR_P1, &reg_value, 1);
  chprintf(chp, "MAC6200_BANK0_RX_ADDR_P1: %02x\r\n", reg_value);  
  
  MAC6200_Read_Reg(MAC6200_BANK0_RX_ADDR_P2, &reg_value, 1);
  chprintf(chp, "MAC6200_BANK0_RX_ADDR_P2: %02x\r\n", reg_value); 
  
  MAC6200_Read_Reg(MAC6200_BANK0_RX_ADDR_P3, &reg_value, 1);
  chprintf(chp, "MAC6200_BANK0_RX_ADDR_P3: %02x\r\n", reg_value); 

  MAC6200_Read_Reg(MAC6200_BANK0_RX_ADDR_P4, &reg_value, 1);
  chprintf(chp, "MAC6200_BANK0_RX_ADDR_P4: %02x\r\n", reg_value);
  
  MAC6200_Read_Reg(MAC6200_BANK0_RX_ADDR_P5, &reg_value, 1);
  chprintf(chp, "MAC6200_BANK0_RX_ADDR_P5: %02x\r\n", reg_value);  
  
  MAC6200_Read_Reg(MAC6200_BANK0_TX_ADDR, temp, 5);
  chprintf(chp, "MAC6200_BANK0_TX_ADDR: "); 
  for(i=4;i>=0;i--)
    chprintf(chp, "%02x " , temp[i]);
  chprintf(chp, "\r\n");
  
  MAC6200_Read_Reg(MAC6200_BANK0_RX_PW_P0, &reg_value, 1);
  chprintf(chp, "MAC6200_BANK0_RX_PW_P0: %02x\r\n", reg_value); 

  MAC6200_Read_Reg(MAC6200_BANK0_RX_PW_P1, &reg_value, 1);
  chprintf(chp, "MAC6200_BANK0_RX_PW_P1: %02x\r\n", reg_value); 

  MAC6200_Read_Reg(MAC6200_BANK0_RX_PW_P2, &reg_value, 1);
  chprintf(chp, "MAC6200_BANK0_RX_PW_P2: %02x\r\n", reg_value);  
  
  MAC6200_Read_Reg(MAC6200_BANK0_RX_PW_P3, &reg_value, 1);
  chprintf(chp, "MAC6200_BANK0_RX_PW_P3: %02x\r\n", reg_value); 
  
  MAC6200_Read_Reg(MAC6200_BANK0_RX_PW_P4, &reg_value, 1);
  chprintf(chp, "MAC6200_BANK0_RX_PW_P4: %02x\r\n", reg_value); 

  MAC6200_Read_Reg(MAC6200_BANK0_RX_PW_P5, &reg_value, 1);
  chprintf(chp, "MAC6200_BANK0_RX_PW_P5: %02x\r\n", reg_value); 
  
  MAC6200_Read_Reg(MAC6200_BANK0_FIFO_STATUS, &reg_value, 1);
  chprintf(chp, "MAC6200_BANK0_FIFO_STATUS: %02x\r\n", reg_value);  

  MAC6200_Read_Reg(MAC6200_BANK0_RX_TIMOUT_H, &reg_value, 1);
  chprintf(chp, "MAC6200_BANK0_RX_TIMOUT_H: %02x\r\n", reg_value);  
  
  MAC6200_Read_Reg(MAC6200_BANK0_DYNPD, &reg_value, 1);
  chprintf(chp, "MAC6200_BANK0_DYNPD: %02x\r\n", reg_value); 
  
  MAC6200_Read_Reg(MAC6200_BANK0_FEATURE, &reg_value, 1);
  chprintf(chp, "MAC6200_BANK0_FEATURE: %02x\r\n", reg_value); 


  MAC6200_Read_Reg(MAC6200_BANK0_SETUP_VALUE, temp, 5);
  chprintf(chp, "MAC6200_BANK0_SETUP_VALUE: ");
  for(i=4;i>=0;i--)
    chprintf(chp, "%02x " , temp[i]);
  chprintf(chp, "\r\n");
  
  
  MAC6200_Read_Reg(MAC6200_BANK0_PRE_GURD, &reg_value, 1);
  chprintf(chp, "MAC6200_BANK0_PRE_GURD: %02x\r\n\n\n", reg_value);  
  
  MAC6200_Bank1_Activate();

  MAC6200_Read_Reg(MAC6200_BANK1_LINE, temp, 2);
  chprintf(chp, "MAC6200_BANK1_LINE: ");
  for(i=1;i>=0;i--)
    chprintf(chp, "%02x " , temp[i]);
  chprintf(chp, "\r\n"); 
  
  MAC6200_Read_Reg(MAC6200_BANK1_PLL_CTL0, temp, 4);
  chprintf(chp, "MAC6200_BANK1_PLL_CTL0: ");
  for(i=3;i>=0;i--)
    chprintf(chp, "%02x " , temp[i]);
  chprintf(chp, "\r\n");  
  
  MAC6200_Read_Reg(MAC6200_BANK1_PLL_CTL1, temp, 4);
  chprintf(chp, "MAC6200_BANK1_PLL_CTL1: ");
  for(i=3;i>=0;i--)
    chprintf(chp, "%02x " , temp[i]);
  chprintf(chp, "\r\n");

  MAC6200_Read_Reg(MAC6200_BANK1_CAL_CTL, temp, 5);
  chprintf(chp, "MAC6200_BANK1_CAL_CTL: ");
  for(i=4;i>=0;i--)
    chprintf(chp, "%02x " , temp[i]);
  chprintf(chp, "\r\n");

  MAC6200_Read_Reg(MAC6200_BANK1_A_CNT_REG, &reg_value, 1);
  chprintf(chp, "MAC6200_BANK1_A_CNT_REG: %02x\r\n", reg_value);   

  MAC6200_Read_Reg(MAC6200_BANK1_B_CNT_REG, &reg_value, 1);
  chprintf(chp, "MAC6200_BANK1_B_CNT_REG: %02x\r\n", reg_value);  

  MAC6200_Read_Reg(MAC6200_BANK1_RESERVED1, &reg_value, 1);
  chprintf(chp, "MAC6200_BANK1_RESERVED1: %02x\r\n", reg_value);  

  MAC6200_Read_Reg(MAC6200_BANK1_STATUS, &reg_value, 1);
  chprintf(chp, "MAC6200_BANK1_STATUS: %02x\r\n", reg_value);  

  MAC6200_Read_Reg(MAC6200_BANK1_STATE, temp, 2);
  chprintf(chp, "MAC6200_BANK1_STATE: ");
  for(i=1;i>=0;i--)
    chprintf(chp, "%02x " , temp[i]);
  chprintf(chp, "\r\n");  

  MAC6200_Read_Reg(MAC6200_BANK1_CHAN, temp, 4);
  chprintf(chp, "MAC6200_BANK1_CHAN: ");
  for(i=3;i>=0;i--)
    chprintf(chp, "%02x " , temp[i]);
  chprintf(chp, "\r\n");  
  
  MAC6200_Read_Reg(MAC6200_BANK1_IF_FREQ, temp, 3);
  chprintf(chp, "MAC6200_BANK1_IF_FREQ: ");
  for(i=2;i>=0;i--)
    chprintf(chp, "%02x " , temp[i]);
  chprintf(chp, "\r\n");

  MAC6200_Read_Reg(MAC6200_BANK1_AFC_COR, temp, 3);
  chprintf(chp, "MAC6200_BANK1_AFC_COR: ");
  for(i=2;i>=0;i--)
    chprintf(chp, "%02x " , temp[i]);
  chprintf(chp, "\r\n");

  MAC6200_Read_Reg(MAC6200_BANK1_FDEV, &reg_value, 1);
  chprintf(chp, "MAC6200_BANK1_FDEV: %02x\r\n", reg_value);   

  MAC6200_Read_Reg(MAC6200_BANK1_DAC_RANGE, &reg_value, 1);
  chprintf(chp, "MAC6200_BANK1_DAC_RANGE: %02x\r\n", reg_value);  

  MAC6200_Read_Reg(MAC6200_BANK1_DAC_IN, &reg_value, 1);
  chprintf(chp, "MAC6200_BANK1_DAC_IN: %02x\r\n", reg_value);

  MAC6200_Read_Reg(MAC6200_BANK1_CTUNING, temp, 2);
  chprintf(chp, "HS6206_BANK1_CTUNING: ");
  for(i=1;i>=0;i--)
    chprintf(chp, "%02x " , temp[i]);
  chprintf(chp, "\r\n"); 

  MAC6200_Read_Reg(MAC6200_BANK1_FTUNING, temp, 2);
  chprintf(chp, "MAC6200_BANK1_FTUNING: ");
  for(i=1;i>=0;i--)
    chprintf(chp, "%02x " , temp[i]);
  chprintf(chp, "\r\n"); 
  
  MAC6200_Read_Reg(MAC6200_BANK1_RX_CTRL, temp, 4);
  chprintf(chp, "MAC6200_BANK1_RX_CTRL: ");
  for(i=3;i>=0;i--)
    chprintf(chp, "%02x " , temp[i]);
  chprintf(chp, "\r\n");  
  
  MAC6200_Read_Reg(MAC6200_BANK1_FAGC_CTRL, temp, 4);
  chprintf(chp, "MAC6200_BANK1_FAGC_CTRL: ");
  for(i=3;i>=0;i--)
    chprintf(chp, "%02x " , temp[i]);
  chprintf(chp, "\r\n");

  MAC6200_Read_Reg(MAC6200_BANK1_FAGC_CTRL_1, temp, 4);
  chprintf(chp, "MAC6200_BANK1_FAGC_CTRL_1: ");
  for(i=3;i>=0;i--)
    chprintf(chp, "%02x " , temp[i]);
  chprintf(chp, "\r\n");

  MAC6200_Read_Reg(MAC6200_BANK1_DAC_CAL_LOW, &reg_value, 1);
  chprintf(chp, "MAC6200_BANK1_DAC_CAL_LOW: %02x\r\n", reg_value);   

  MAC6200_Read_Reg(MAC6200_BANK1_DAC_CAL_HI, &reg_value, 1);
  chprintf(chp, "MAC6200_BANK1_DAC_CAL_HI: %02x\r\n", reg_value);  

  MAC6200_Read_Reg(MAC6200_BANK1_RESERVED3, &reg_value, 1);
  chprintf(chp, "MAC6200_BANK1_RESERVED3: %02x\r\n", reg_value);  

  MAC6200_Read_Reg(MAC6200_BANK1_DOC_DACI, &reg_value, 1);
  chprintf(chp, "MAC6200_BANK1_DOC_DACI: %02x\r\n", reg_value);  

  MAC6200_Read_Reg(MAC6200_BANK1_DOC_DACQ, &reg_value, 1);
  chprintf(chp, "MAC6200_BANK1_DOC_DACQ: %02x\r\n", reg_value);   

  MAC6200_Read_Reg(MAC6200_BANK1_AGC_CTRL, temp, 4);
  chprintf(chp, "MAC6200_BANK1_AGC_CTRL: ");
  for(i=3;i>=0;i--)
    chprintf(chp, "%02x " , temp[i]);
  chprintf(chp, "\r\n"); 
  
  MAC6200_Read_Reg(MAC6200_BANK1_AGC_GAIN, temp, 4);
  chprintf(chp, "MAC6200_BANK1_AGC_GAIN: ");
  for(i=3;i>=0;i--)
    chprintf(chp, "%02x " , temp[i]);
  chprintf(chp, "\r\n");  
  
  MAC6200_Read_Reg(MAC6200_BANK1_RF_IVGEN, temp, 4);
  chprintf(chp, "MAC6200_BANK1_RF_IVGEN: ");
  for(i=3;i>=0;i--)
    chprintf(chp, "%02x " , temp[i]);
  chprintf(chp, "\r\n");

  MAC6200_Read_Reg(MAC6200_BANK1_TEST_PKDET, temp, 4);
  chprintf(chp, "MAC6200_BANK1_TEST_PKDET: ");
  for(i=3;i>=0;i--)
    chprintf(chp, "%02x " , temp[i]);
  chprintf(chp, "\r\n");  
  MAC6200_Bank0_Activate();
}

#endif /* HAL_USE_RF */
