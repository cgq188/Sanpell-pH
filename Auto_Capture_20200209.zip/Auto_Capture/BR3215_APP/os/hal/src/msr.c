/*
    ChibiOS - Copyright (C) 2019 BRMICRO Technologies
              

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    msr.c
 * @brief   MSR (Magnetic Strip Reader) Driver code.
 *
 * @addtogroup MSR
 * @{
 */

#include <string.h>
#include "hal.h"

#if (HAL_USE_MSR == TRUE) || defined(__DOXYGEN__)

#define LEAD_CODE_COUNT1    5

#define TrackI_Byte_Bits 6
#define TrackII_Byte_Bits 4
#define TrackIII_Byte_Bits 4
#define JISII_Byte_Bits 7
#define Track1_End_Char 0x1f
#define Track2_End_Char 0x0f
#define Track3_End_Char 0x0f
#define JISII_End_Char  0x7f

#define TRACK_ONE_MIN_BYTE 3
#define TRACK_TWO_MIN_BYTE 3
#define TRACK_THREE_MIN_BYTE 3

#define TRACK_ONE  0x01
#define TRACK_TWO  0x02
#define TRACK_THREE 0x04

#ifndef uchar
typedef unsigned char uchar;
#endif

#ifndef false
#define false 0
#endif

#ifndef true
#define true 1
#endif

/*===========================================================================*/
/* Driver local definitions.                                                 */
/*===========================================================================*/
// 2��������10ms
// 1�����200us
static uint8_t _msr_filter(uint8_t *obuf, uint16_t *ibuf, uint16_t ilen)
{
    unsigned short lastPls1 = 0;
    unsigned short filterPls1 = 0;
    unsigned short curPls1 = 0;
    unsigned char leadCodeCount1 = 0;
    unsigned short byteCount1 = 0;
    unsigned char curByte1 = 0;
    unsigned char bitCount1 = 0;
    unsigned char tmpBit = 0;
    int i;

    for (i = 0; i < ilen; i++) {
        curPls1 = ibuf[i];
        if (curPls1 > filterPls1 * 3 / 4) {
            tmpBit = 0;
        } else {
            tmpBit = 1;
            if (leadCodeCount1 == LEAD_CODE_COUNT1 && lastPls1 < 1) {
                lastPls1 = curPls1;
                continue;
            }
        }

        if (leadCodeCount1 == LEAD_CODE_COUNT1) {
            if (tmpBit == 1) {
                curByte1 |= 0x80 >> bitCount1;
            }

            bitCount1++;
            if (bitCount1 == 8) {
                bitCount1 = 0;
                if (byteCount1 < 255) {
                    obuf[byteCount1++] = curByte1;
                    curByte1 = 0;
                }
            }
        } else {
            if (0 == tmpBit) {
                leadCodeCount1++;
            } else {
                leadCodeCount1 = 0;
            }
        }

        filterPls1 = curPls1 + lastPls1;
        lastPls1 = 0;
    }
        
    return byteCount1;
}

// �ɹ����ؽ����ַ��� ʧ�ܷ���0
static uchar parse_track_data(
                       const uchar *in,
                       const uchar in_len,
                       uchar *out,
                       uchar out_len,
                       const uchar bits,
                       const uchar end_char,
                       const uchar positive)
{
    uchar curBit = 0;
    uchar bitCount = 0;
    uchar byteCount = 0;
    uchar lrcByte = 0;
    uchar lrcResult = 0;
    uchar curByte = 0;
    uchar parityBit = 0;
    uchar parityResult = 0;
    uchar i = 0;
    uchar tmp = 0;
    uchar start_flag = false;
    uchar end_flag = false;
    uchar j = 0;
    uchar mask = 0;

    memset(out, 0, out_len);
    if (TrackI_Byte_Bits == bits) {
        mask = 0x3f;
    } else if(JISII_Byte_Bits == bits) {
        mask = 0x7f;
        parityResult = 1;
        lrcResult = 0x7f;
    } else {
        mask = 0x0f;
    }

    for(i = 0; i < in_len; i++) {
        tmp = positive? in[i]: in[in_len - 1 - i];
        for(j = 0; j < 8; j++) {
            if (positive) {
                curBit = (tmp & 0x80) == 0x80? 1: 0;
                tmp <<= 1;
            } else {
                curBit = (tmp & 0x01) == 0x01? 1: 0;
                tmp >>= 1;
            }

            if (false == start_flag) {
                if (0x01 == curBit) {
                    if (positive) {
                        if (((i + 1 < in_len) && (0 != in[i + 1]))
                         || ((i + 2 < in_len) && (0 != in[i + 2]))) {
                            start_flag = true;
                            bitCount = 1;
                            curByte = 1;
                            parityBit ^= curBit;
                        }
                    } else {
                        if (((i + 1 < in_len) && (0 != in[in_len - i]))
                         || ((i + 2 < in_len) && (0 != in[in_len - i - 1]))) {
                            start_flag = true;
                            bitCount = 1;
                            curByte = 1;
                            parityBit ^= curBit;
                        }
                    }
                }
            } else {
                curByte |= (curBit << bitCount);
                parityBit ^= curBit;
                bitCount++;
                if (bitCount > bits) {
                    bitCount = 0;
                    curByte &= mask;
                    lrcByte ^= curByte;
                    if (false == end_flag) {
                        if (end_char == curByte && byteCount > 1) {
                            end_flag = true;
                        }
                    } else {
                        if (lrcResult == lrcByte) return byteCount;
                        return 0;
                    }

                    if (byteCount > out_len - 1) return 0;
                    if (bits == TrackI_Byte_Bits) {
                        out[byteCount++] = (curByte & 0x3f) + 0x20;
                    } else if (bits == JISII_Byte_Bits) {
                        if (byteCount == 0 && curByte !=  0x7f) {
                            return 0;
                        }

                        out[byteCount++] = curByte;
                    } else {
                        out[byteCount++] = (curByte & 0x0F) + '0';
                    }

                    if (parityResult == parityBit) {
                        return 0;
                    }

                    parityBit = 0;
                    curByte = 0;
                }
            }
        }
    }

    return 0;
}

static int track_analyze(uchar* bufferIn, int lenIn, uchar* bufferOut, int lenOut, const int track)
{
    int len = 0;
    if (track != TRACK_ONE) {
        len = parse_track_data(bufferIn, lenIn, bufferOut, lenOut, TrackII_Byte_Bits, Track2_End_Char, true);
        if (len > TRACK_TWO_MIN_BYTE) return len;
        len = parse_track_data(bufferIn, lenIn, bufferOut, lenOut, TrackII_Byte_Bits, Track2_End_Char, false);
        if (len > TRACK_TWO_MIN_BYTE) return len;
    } else {
        len = parse_track_data(bufferIn, lenIn, bufferOut, lenOut, TrackI_Byte_Bits, Track1_End_Char, true);
        if (len > TRACK_ONE_MIN_BYTE) return len;
        len = parse_track_data(bufferIn, lenIn, bufferOut, lenOut, TrackI_Byte_Bits, Track1_End_Char, false);
        if (len > TRACK_ONE_MIN_BYTE) return len;
    }

    return 0;
}

/*===========================================================================*/
/* Driver exported variables.                                                */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local variables and types.                                         */
/*===========================================================================*/


/*===========================================================================*/
/* Driver local functions.                                                   */
/*===========================================================================*/


/*===========================================================================*/
/* Driver exported functions.                                                */
/*===========================================================================*/

/**
 * @brief   MSR Driver initialization.
 * @note    This function is implicitly invoked by @p halInit(), there is
 *          no need to explicitly initialize the driver.
 *
 * @init
 */
void msrInit(void) {

  msr_lld_init();
}

/**
 * @brief   Initializes the standard part of a @p MSRDriver structure.
 *
 * @param[out] msrp     pointer to the @p MSRDriver object
 *
 * @init
 */
void msrObjectInit(MSRDriver *msrp) {

  msrp->state    = SD_STOP;
  msrp->errors   = MSR_NO_ERROR;
  msrp->config   = NULL;
}

/**
 * @brief   Configures and activates the MSR peripheral.
 *
 * @param[in] msrp      pointer to the @p MSRDriver object
 * @param[in] config    pointer to the @p MSRConfig object, can be @p NULL if
 *                      the driver supports a default configuration or
 *                      requires no configuration
 *
 * @api
 */
void msrStart(MSRDriver *msrp, const MSRConfig *config) {

  osalDbgCheck(msrp != NULL);

  osalSysLock();
  osalDbgAssert((msrp->state == MSR_STOP) || (msrp->state == MSR_ACTIVE),
                "invalid state");
  msrp->state = MSR_ACTIVE;
  msrp->errors = MSR_NO_ERROR;
  msr_lld_start(msrp, config);
  osalSysUnlock();
}

/**
 * @brief   Deactivates the MSR peripheral.
 *
 * @param[in] msrp      pointer to the @p MSRDriver object
 *
 * @api
 */
void msrStop(MSRDriver *msrp) {

  osalDbgCheck(msrp != NULL);

  osalSysLock();
  osalDbgAssert((msrp->state == MSR_STOP) || (msrp->state == MSR_ACTIVE),
                "invalid state");
  msr_lld_stop(msrp);
  msrp->state = MSR_STOP;
  osalSysUnlock();
}

/**
 * @brief   Decode the captured F2F data to ISO7810.
 *
 * @param[in] msrp      pointer to the @p MSRDriver object
 *
 * @api
 */
static uint8_t tbuf[120];
bool msrDecode(MSRDriver *msrp) {
  int i, track;

  if (msrp->errors)
    return HAL_FAILED;

  for (track = 0; track < MSR_MAX_NR_TRACKS; track++) {
    uint16_t tlen, len = msrp->f2f_len[track];
    if (((1u << track) & msrp->config->bitmap_tracks) &&
        (len > 0)) {
      uint16_t *buf = msrp->f2f_buf[track];
      uint8_t *obuf = msrp->dec_buf[track];
      /* translate absolute time counter into delta */
      for (i = 0; i < len-1; i++) {
        if ( buf[i+1] > buf[i])
          buf[i] = buf[i+1] - buf[i];
        else
          buf[i] = 65536 - buf[i] + buf[i+1];
      }
      tlen = _msr_filter(tbuf, buf, len);
      if (len < 250/*FIXME*/)
        msrp->mag_bytes[track] = track_analyze(tbuf, tlen, obuf, MSR_TRACK2_CHARS, TRACK_TWO);
      else
        msrp->mag_bytes[track] = track_analyze(tbuf, tlen, obuf, MSR_TRACK3_CHARS, TRACK_THREE);
    }
  }
  
  return HAL_SUCCESS;
}

int msrDecodeTest(MSRDriver *msrp, int index, int track) {
  uint8_t chars[3] = {MSR_TRACK1_CHARS, MSR_TRACK2_CHARS, MSR_TRACK3_CHARS};
  uint16_t tlen, len = msrp->f2f_len[index];
  uint16_t *buf = msrp->f2f_buf[index];
  uint8_t *obuf = msrp->dec_buf[index];

  if (index >= MSR_MAX_NR_TRACKS)
    return 0;
  if (track/*1,2,3*/ > MSR_MAX_NR_TRACKS)
    return 0;
  tlen = _msr_filter(tbuf, buf, len);
  tlen = track_analyze(tbuf, tlen, obuf, chars[track-1], 1u << (track-1));
  
  return tlen;
}

#endif /* HAL_USE_MSR == TRUE */

/** @} */

