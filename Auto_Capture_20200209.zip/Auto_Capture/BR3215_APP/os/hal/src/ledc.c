/*
    ChibiOS - Copyright (C) 2006..2015 Giovanni Di Sirio

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    ledc.c
 * @brief   LEDC Driver code.
 *
 * @addtogroup LEDC
 * @{
 */

#include "hal.h"

#if (HAL_USE_LEDC == TRUE) || defined(__DOXYGEN__)

/*===========================================================================*/
/* Driver local definitions.                                                 */
/*===========================================================================*/
//
//                  -PIN1  -PIN2  -PIN3  -PIN4  -PIN5  -PIN6  -PIN7
//
// K_PLY   -----a-----    -----a-----           -----a-----       -----a-----    K_MP3
//         |         |    |         |           |         |       |         |
//         f         b    f         b           f         b       f         b
// K_PSE   |         |    |         |           |         |       |         |    K_AUX
//          -----g-----    -----g-----  K_DOT2   -----g-----       -----g-----
// K_USB   |         |    |         |           |         |       |         |    K_FM
//         e         c    e         c           e         c       e         c
//         |         |    |         |           |         |       |         |
// K_SD    |----d----|    |----d----|           |----d----| K_DOT |----d----|    K_MHZ
//             DIG1           DIG2                  DIG3              DIG4
//
//                  -PIN1  -PIN2  -PIN3  -PIN4  -PIN5  -PIN6  -PIN7
//
#define PIN_OUTHIGH(pin)    ((1<<((pin)-1))+(1<<(8+(pin)-1)))
#define PIN_OUTLOW(pin)     ((0<<((pin)-1))+(1<<(8+(pin)-1)))
#define PIN_IN(pin)         (0x00)

#define DIGX_X     (PIN_IN(1) + PIN_IN(2) + PIN_IN(3) + PIN_IN(4) + PIN_IN(5) + PIN_IN(6) + PIN_IN(7))

//DIGX_X, K_X encode. Need to modified according to LED spec.

#if defined(hscAudiophile)

#define LEDC_MAX_DIG_LED_NUM      DISPLAY_LED_SEGMENT_NUM
#define LEDC_MAX_K_LED_NUM        DISPLAY_LED_ICON_NUM
#define LEDC_MAX_DIG_NUM          DISPLAY_LED_DIGIT_NUM
#define LEDC_MAX_LED_NUM     ((LEDC_MAX_DIG_LED_NUM*LEDC_MAX_DIG_NUM + LEDC_MAX_K_LED_NUM)

#else

#define LEDC_MAX_DIG_LED_NUM      7    /*led number for every dig display*/
#define LEDC_MAX_K_LED_NUM       10    /*led num for every k display*/
#define LEDC_MAX_DIG_NUM          4    /*dig num for LED screen*/
#define LEDC_MAX_LED_NUM     ((LEDC_MAX_DIG_LED_NUM*LEDC_MAX_DIG_NUM + LEDC_MAX_K_LED_NUM)

#define DIG1_A    (PIN_OUTHIGH(1) + PIN_OUTLOW(2))
#define DIG1_B    (PIN_OUTHIGH(1) + PIN_OUTLOW(3))
#define DIG1_C    (PIN_OUTHIGH(4) + PIN_OUTLOW(1))
#define DIG1_D    (PIN_OUTHIGH(5) + PIN_OUTLOW(1))
#define DIG1_E    (PIN_OUTHIGH(1) + PIN_OUTLOW(4))
#define DIG1_F    (PIN_OUTHIGH(2) + PIN_OUTLOW(1))
#define DIG1_G    (PIN_OUTHIGH(3) + PIN_OUTLOW(1))

#define DIG2_A    (PIN_OUTHIGH(2) + PIN_OUTLOW(3))
#define DIG2_B    (PIN_OUTHIGH(2) + PIN_OUTLOW(4))
#define DIG2_C    (PIN_OUTHIGH(5) + PIN_OUTLOW(2))
#define DIG2_D    (PIN_OUTHIGH(2) + PIN_OUTLOW(6))
#define DIG2_E    (PIN_OUTHIGH(2) + PIN_OUTLOW(5))
#define DIG2_F    (PIN_OUTHIGH(3) + PIN_OUTLOW(2))
#define DIG2_G    (PIN_OUTHIGH(4) + PIN_OUTLOW(2))

#define DIG3_A    (PIN_OUTHIGH(5) + PIN_OUTLOW(4))
#define DIG3_B    (PIN_OUTHIGH(3) + PIN_OUTLOW(5))
#define DIG3_C    (PIN_OUTHIGH(4) + PIN_OUTLOW(5))
#define DIG3_D    (PIN_OUTHIGH(6) + PIN_OUTLOW(1))
#define DIG3_E    (PIN_OUTHIGH(6) + PIN_OUTLOW(3))
#define DIG3_F    (PIN_OUTHIGH(4) + PIN_OUTLOW(3))
#define DIG3_G    (PIN_OUTHIGH(5) + PIN_OUTLOW(3))

#define DIG4_A    (PIN_OUTHIGH(7) + PIN_OUTLOW(6))
#define DIG4_B    (PIN_OUTHIGH(6) + PIN_OUTLOW(7))
#define DIG4_C    (PIN_OUTHIGH(5) + PIN_OUTLOW(6))
#define DIG4_D    (PIN_OUTHIGH(6) + PIN_OUTLOW(4))
#define DIG4_E    (PIN_OUTHIGH(4) + PIN_OUTLOW(6))
#define DIG4_F    (PIN_OUTHIGH(6) + PIN_OUTLOW(5))
#define DIG4_G    (PIN_OUTHIGH(5) + PIN_OUTLOW(7))

#define K_AUX     (PIN_OUTHIGH(7) + PIN_OUTLOW(1))
#define K_USB     (PIN_OUTHIGH(6) + PIN_OUTLOW(2))
#define K_SD      (PIN_OUTHIGH(1) + PIN_OUTLOW(5))
#define K_DOT2    (PIN_OUTHIGH(3) + PIN_OUTLOW(4))
#define K_DOT     (PIN_OUTHIGH(7) + PIN_OUTLOW(5))
#define K_PLY     (PIN_OUTHIGH(1) + PIN_OUTLOW(6))
#define K_PSE     (PIN_OUTHIGH(3) + PIN_OUTLOW(6))
#define K_MHZ     (PIN_OUTHIGH(7) + PIN_OUTLOW(2))
#define K_FM      (PIN_OUTHIGH(7) + PIN_OUTLOW(3))
#define K_MP3     (PIN_OUTHIGH(3) + PIN_OUTLOW(7))
#endif

#define SEG_X  (0<<0)
#define SEG_A  (1<<0)
#define SEG_B  (1<<1)
#define SEG_C  (1<<2)
#define SEG_D  (1<<3)
#define SEG_E  (1<<4)
#define SEG_F  (1<<5)
#define SEG_G  (1<<6)
/*===========================================================================*/
/* Driver exported variables.                                                */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local variables.                                                   */
/*===========================================================================*/
#if !defined(hscAudiophile)
static const uint16_t led_mode_encode[] ={
  K_AUX,K_USB,K_SD,K_DOT2,K_DOT,K_PLY,K_PSE,K_MHZ,K_FM,K_MP3
};

static const uint16_t ledc_on_pin_config[LEDC_MAX_DIG_NUM][LEDC_MAX_DIG_LED_NUM] = {
    {DIG1_A, DIG1_B, DIG1_C, DIG1_D, DIG1_E, DIG1_F, DIG1_G},
    {DIG2_A, DIG2_B, DIG2_C, DIG2_D, DIG2_E, DIG2_F, DIG2_G},
    {DIG3_A, DIG3_B, DIG3_C, DIG3_D, DIG3_E, DIG3_F, DIG3_G},
    {DIG4_A, DIG4_B, DIG4_C, DIG4_D, DIG4_E, DIG4_F, DIG4_G},
};
#endif

static const uint8_t led_font_hyphen = SEG_G;

static const uint8_t led_font_numeric[]= {
  /*0*/SEG_A + SEG_B + SEG_C + SEG_D + SEG_E + SEG_F,
  /*1*/SEG_B + SEG_C,
  /*2*/SEG_A + SEG_B + SEG_D + SEG_E + SEG_G,
  /*3*/SEG_A + SEG_B + SEG_C + SEG_D + SEG_G,
  /*4*/SEG_B + SEG_C + SEG_F + SEG_G,
  /*5*/SEG_A + SEG_C + SEG_D + SEG_F + SEG_G,
  /*6*/SEG_A + SEG_C + SEG_D + SEG_E + SEG_F + SEG_G,
  /*7*/SEG_A + SEG_B + SEG_C,
  /*8*/SEG_A + SEG_B + SEG_C + SEG_D + SEG_E + SEG_F + SEG_G,
  /*9*/SEG_A + SEG_B + SEG_C + SEG_D + SEG_F + SEG_G,
};

static const uint8_t led_font_alphabet[]= {
  /*A*/SEG_A | SEG_B | SEG_C | SEG_E | SEG_F | SEG_G,
  /*b*/SEG_C | SEG_D | SEG_E | SEG_F | SEG_G,
  /*C*/SEG_A | SEG_D | SEG_E | SEG_F,
  /*d*/SEG_B | SEG_C | SEG_D | SEG_E | SEG_G,
  /*E*/SEG_A | SEG_D | SEG_E | SEG_F | SEG_G,
  /*F*/SEG_A | SEG_E | SEG_F | SEG_G,
  /*9*/SEG_A | SEG_B | SEG_C | SEG_D | SEG_F | SEG_G,
  /*h*/SEG_C | SEG_E | SEG_F | SEG_G,
  /*i*/SEG_C,
  /*J*/SEG_B | SEG_C | SEG_D,
  /*K*/SEG_E | SEG_F | SEG_G,
  /*L*/SEG_D | SEG_E | SEG_F,
  /*-*/SEG_G,
  /*n*/SEG_C | SEG_E | SEG_G,
  /*0*/SEG_A | SEG_B | SEG_C | SEG_D | SEG_E | SEG_F,
  /*P*/SEG_A | SEG_B | SEG_E | SEG_F | SEG_G,
  /*q*/SEG_A | SEG_B | SEG_C | SEG_F | SEG_G,
  /*r*/SEG_E | SEG_G,
  /*S*/SEG_A | SEG_C | SEG_D | SEG_F | SEG_G,
  /*t*/SEG_D | SEG_E | SEG_F | SEG_G,
  /*U*/SEG_B | SEG_C | SEG_D | SEG_E | SEG_F,
  /*u*/SEG_C | SEG_D | SEG_E,
  /*-*/SEG_G,
  /*H*/SEG_B | SEG_C | SEG_E | SEG_F | SEG_G,
  /*y*/SEG_B | SEG_C | SEG_D | SEG_F | SEG_G,
  /*2*/SEG_A | SEG_B | SEG_D | SEG_E | SEG_G,
};


/*===========================================================================*/
/* Driver local functions.                                                   */
/*===========================================================================*/

/**
 * @brief   LEDC Driver initialization.
 * @note    This function is implicitly invoked by @p halInit(), there is
 *          no need to explicitly initialize the driver.
 *
 * @init
 */
void ledcInit(void) {
    
  ledc_lld_init();
}

/**
 * @brief   Configures and activates the LEDC peripheral.
 *
 * @param[in] ledcp      pointer to the @p LEDCDriver object
 * @param[in] config    pointer to the @p LEDCConfig object
 *
 * @api
 */
void ledcStart(LEDCDriver *ledcp, const LEDCConfig *config) {

  osalDbgCheck((ledcp != NULL) && (config != NULL));

  osalSysLock();
  osalDbgAssert((ledcp->state == LEDC_STOP) || (ledcp->state == LEDC_READY),
                "invalid state");
  ledcp->config = config;
  ledc_lld_start(ledcp);
  ledcp->state = LEDC_READY;
  osalSysUnlock();
}

/**
 * @brief   Deactivates the LEDC peripheral.
 *
 * @param[in] ledcp      pointer to the @p LEDCDriver object
 *
 * @api
 */
void ledcStop(LEDCDriver *ledcp) {

  syssts_t sts;
  osalDbgCheck(ledcp != NULL);

  sts = osalSysGetStatusAndLockX();
  osalDbgAssert((ledcp->state == LEDC_STOP) || (ledcp->state == LEDC_READY), "invalid state");
  ledc_lld_stop(ledcp);
  ledcp->state = LEDC_STOP;
  osalSysRestoreStatusX(sts);
}

static void _ledc_get_dig_encode(LEDCDriver *ledcp, char chr, uint32_t dig_index, uint16_t* char_encode)
{
  (void)ledcp;
  uint32_t i;
  uint8_t font;

  if (('0' <= chr) && (chr <= '9')) {
    font = led_font_numeric[chr-'0'];
  }
  else if (('a' <= chr) && (chr <= 'z')) {
    font = led_font_alphabet[chr-'a'];
  }
  else if (('A' <= chr) && (chr <= 'Z')) {
    font = led_font_alphabet[chr-'A'];
  }
  else if (' ' == chr) {
    font = 0;
  }
  else {
    font = led_font_hyphen;
  }

  for(i=0x00; i<LEDC_MAX_DIG_LED_NUM; i++){
    if (font & (1<<i)) {
      #if defined(hscAudiophile)
      char_encode[i] = PIN_OUTHIGH((ledcp->config->seg_table[DISPLAY_LED_DIGIT_NUM-dig_index][i]>>4) & 0x0f) |
        PIN_OUTLOW(ledcp->config->seg_table[DISPLAY_LED_DIGIT_NUM-dig_index][i] & 0x0f);
      #else
      char_encode[i] = ledc_on_pin_config[(dig_index-1) % LEDC_MAX_DIG_NUM][i];
      #endif
    }
    else {
      char_encode[i] = SEG_X;
    }
  }
}

void ledcDispDig(LEDCDriver *ledcp, const uint32_t data, uint32_t dig_index){
    
  syssts_t sts;
  uint16_t char_encode[LEDC_MAX_DIG_LED_NUM];

  osalDbgCheck(ledcp != NULL);
  osalDbgAssert(((dig_index >= 1) && (dig_index <= LEDC_MAX_DIG_NUM)) , "parameter error");
  
  _ledc_get_dig_encode(ledcp, '0' + data, dig_index, char_encode);

  sts = osalSysGetStatusAndLockX();
  osalDbgAssert(ledcp->state == LEDC_READY, "not ready");
  ledc_lld_scan_reg(ledcp, char_encode, LEDC_MAX_DIG_LED_NUM, (dig_index-1)*LEDC_MAX_DIG_LED_NUM);
  osalSysRestoreStatusX(sts);
}

void ledcClearDig(LEDCDriver *ledcp, uint32_t dig_index){
    
  syssts_t sts;
  osalDbgCheck(ledcp != NULL);
  osalDbgAssert(((dig_index >= 1) && (dig_index <= LEDC_MAX_DIG_NUM)) , "parameter error");

  sts = osalSysGetStatusAndLockX();
  osalDbgAssert(ledcp->state == LEDC_READY, "not ready");
  ledc_lld_clear_reg(ledcp, (dig_index-1)*LEDC_MAX_DIG_LED_NUM, (dig_index*LEDC_MAX_DIG_LED_NUM-1));
  osalSysRestoreStatusX(sts);
}

void ledcDispMode(LEDCDriver *ledcp, ledc_mode_t mode, ledc_on_t on){
  
  syssts_t sts;
  uint32_t i;
  uint32_t reg_addr;
  uint16_t scan_pair;

  sts = osalSysGetStatusAndLockX();
  osalDbgAssert(ledcp->state == LEDC_READY, "not ready");
  for(i=0x00; i<LEDC_MODE_NUM; i++){
    if(mode & (1<<i)){
      reg_addr = LEDC_MAX_DIG_LED_NUM*LEDC_MAX_DIG_NUM + i;
      #if defined(hscAudiophile)
      scan_pair = PIN_OUTHIGH((ledcp->config->icon_table[i]>>4) & 0x0f) |
        PIN_OUTLOW(ledcp->config->icon_table[i] & 0x0f);
      #else
      scan_pair = led_mode_encode[i];
      #endif
      if(on)
        ledc_lld_scan_reg(ledcp, &scan_pair, 1, reg_addr);
      else
        ledc_lld_clear_reg(ledcp, reg_addr, reg_addr);
    }
  }
  osalSysRestoreStatusX(sts);
}

void ledcClear(LEDCDriver *ledcp){

  syssts_t sts;
  osalDbgCheck(ledcp != NULL);

  sts = osalSysGetStatusAndLockX();
  osalDbgAssert(ledcp->state == LEDC_READY, "not ready");
  ledc_lld_clear_reg(ledcp, 0x00, LEDC_MAX_SCAN_REG-1);
  osalSysRestoreStatusX(sts);
}

/**
 * @brief
 *
 * @param[in] ledcp      pointer to the @p LEDDriver object
 *
 * @api
 */
void ledcDispStr(LEDCDriver *ledcp, const char* str) {

  syssts_t sts;
  uint32_t i;
  uint32_t reg_addr=0x00;
  uint16_t char_encode[LEDC_MAX_DIG_LED_NUM];

  osalDbgCheck(ledcp != NULL);
  osalDbgAssert(ledcp->state == LEDC_READY, "not ready");

  sts = osalSysGetStatusAndLockX();

  for(i=0x00; str[i]!='\0'; i++){
    _ledc_get_dig_encode(ledcp, str[i], i+1, char_encode);
    ledc_lld_scan_reg(ledcp, char_encode, LEDC_MAX_DIG_LED_NUM, reg_addr);
    reg_addr += LEDC_MAX_DIG_LED_NUM;
  }
  if(reg_addr < (LEDC_MAX_DIG_LED_NUM * LEDC_MAX_DIG_NUM)){
    ledc_lld_clear_reg(ledcp, reg_addr, (LEDC_MAX_DIG_LED_NUM * LEDC_MAX_DIG_NUM));
  }

  osalSysRestoreStatusX(sts);
}

void ledcDispInt(LEDCDriver *ledcp, const uint32_t data){
    
    syssts_t sts;
    uint32_t i;
    uint8_t char_index;
    uint32_t disp_data = data;
    uint16_t char_encode[LEDC_MAX_DIG_LED_NUM];

    osalDbgCheck(ledcp != NULL);
    sts = osalSysGetStatusAndLockX();
    osalDbgAssert(ledcp->state == LEDC_READY, "not ready");

    for(i=0x00; i<LEDC_MAX_DIG_NUM; i++){
      char_index = disp_data %10;
      //ledcDispDig(ledcp, (disp_data%10), LEDC_MAX_DIG_NUM-i);
      _ledc_get_dig_encode(ledcp, '0'+char_index, LEDC_MAX_DIG_NUM-i, char_encode);
      ledc_lld_scan_reg(ledcp, char_encode, LEDC_MAX_DIG_LED_NUM, (LEDC_MAX_DIG_NUM-1-i)*LEDC_MAX_DIG_LED_NUM);
      disp_data /= 10;
    }
    osalSysRestoreStatusX(sts);
}

#endif /* HAL_USE_LEDC == TRUE */

/** @} */
