/*
    ChibiOS - Copyright (C) 2006..2015 Giovanni Di Sirio

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    adc.c
 * @brief   ADC Driver code.
 *
 * @addtogroup ADC
 * @{
 */

#include <stdlib.h>
#include "hal.h"

#if (HAL_USE_ADC == TRUE) || defined(__DOXYGEN__)

/*===========================================================================*/
/* Driver local definitions.                                                 */
/*===========================================================================*/

/*===========================================================================*/
/* Driver exported variables.                                                */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local variables and types.                                         */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local functions.                                                   */
/*===========================================================================*/

/*===========================================================================*/
/* Driver exported functions.                                                */
/*===========================================================================*/

/**
 * @brief   ADC Driver initialization.
 * @note    This function is implicitly invoked by @p halInit(), there is
 *          no need to explicitly initialize the driver.
 *
 * @init
 */
void adcInit(void) {

  adc_lld_init();
}

/**
 * @brief   Initializes the standard part of a @p ADCDriver structure.
 *
 * @param[out] adcp     pointer to the @p ADCDriver object
 *
 * @init
 */
void adcObjectInit(ADCDriver *adcp) {

  adcp->state    = ADC_STOP;
  adcp->config   = NULL;
  adcp->samples  = NULL;
  adcp->depth    = 0;
  adcp->grpp     = NULL;
#if ADC_USE_WAIT == TRUE
  adcp->thread   = NULL;
#endif
#if ADC_USE_MUTUAL_EXCLUSION == TRUE
  osalMutexObjectInit(&adcp->mutex);
#endif
#if defined(ADC_DRIVER_EXT_INIT_HOOK)
  ADC_DRIVER_EXT_INIT_HOOK(adcp);
#endif
}

/**
 * @brief   Configures and activates the ADC peripheral.
 *
 * @param[in] adcp      pointer to the @p ADCDriver object
 * @param[in] config    pointer to the @p ADCConfig object. Depending on
 *                      the implementation the value can be @p NULL.
 *                      Generaly, set it to NULL to use default settings
 *                      is all enough.
 * @api
 */
msg_t adcStart(ADCDriver *adcp, const ADCConfig *config) {

  osalDbgCheck(adcp != NULL);
  osalDbgAssert((adcp->state == ADC_STOP) || (adcp->state == ADC_READY),
                "invalid state");

  //osalSysLock();
  syssts_t sts = osalSysGetStatusAndLockX();

  msg_t res = MSG_OK;

  if(adcp == NULL)
    res = ADC_ERROR_NULLPTR;
  else if((adcp->state != ADC_STOP) && (adcp->state != ADC_READY))
    res = ADC_ERROR_STATE;
  else {
    adcp->config = config;
  	adc_lld_start(adcp);
  	adcp->state = ADC_READY;
  }

  osalSysRestoreStatusX(sts);
  //osalSysUnlock();
  return res;
}

/**
 * @brief   Deactivates the ADC peripheral.
 *
 * @param[in] adcp      pointer to the @p ADCDriver object
 *
 * @api
 */
void adcStop(ADCDriver *adcp) {

  osalDbgCheck(adcp != NULL);
  osalDbgAssert((adcp->state == ADC_STOP) || (adcp->state == ADC_READY),
                "invalid state");

  //osalSysLock();
  syssts_t sts = osalSysGetStatusAndLockX();

  adc_lld_stop(adcp);
  adcp->state = ADC_STOP;

  osalSysRestoreStatusX(sts);
  //osalSysUnlock();
}


/**
 * @brief   Starts an ADC conversion.
 * @details Starts an asynchronous conversion operation.
 * @note    The buffer is organized as a matrix of M*N elements where M is the
 *          channels number configured into the conversion group and N is the
 *          buffer depth. The samples are sequentially written into the buffer
 *          with no gaps.
 * @note    Temperature data is in 10 degree Celsius.
 *
 * @param[in] adcp      Pointer to the @p ADCDriver object
 * @param[in] grpp      Pointer to a @p ADCConversionGroup object
 * @param[out] samples  Pointer to the samples buffer
 * @param[in] depth     Buffer depth (matrix rows number). The buffer depth
 *                      must be one or an even number (in order to enable
 *                      half-filled callback in circular mode).
 *
 * @retval              Execution status.
 *
 * @api
 */
int adcStartConversion(ADCDriver *adcp,
                       const ADCConversionGroup *grpp,
                       adcsample_t *samples,
                       size_t depth) {

  int res;

  osalSysLock();
  res = adcStartConversionI(adcp, grpp, samples, depth);
  osalSysUnlock();

  return res;
}

/**
 * @brief   Starts an ADC conversion.
 * @details Starts an asynchronous conversion operation.
 * @post    The callbacks associated to the conversion group will be invoked
 *          on buffer fill and error events.
 * @note    The buffer is organized as a matrix of M*N elements where M is the
 *          channels number configured into the conversion group and N is the
 *          buffer depth. The samples are sequentially written into the buffer
 *          with no gaps.
 * @note    Temperature data is in 10 degree Celsius.
 *
 * @param[in] adcp      Pointer to the @p ADCDriver object
 * @param[in] grpp      Pointer to a @p ADCConversionGroup object
 * @param[out] samples  Pointer to the samples buffer
 * @param[in] depth     Buffer depth (matrix rows number). The buffer depth
 *                      must be greater than zero.
 *
 * @retval              Execution status.
 *
 * @iclass
 */
int adcStartConversionI(ADCDriver *adcp,
                         const ADCConversionGroup *grpp,
                         adcsample_t *samples,
                         size_t depth) {

  osalDbgCheckClassI();
  osalDbgCheck((adcp != NULL) && (grpp != NULL) && (samples != NULL) &&
  		(depth > 0));
  osalDbgAssert((adcp->state == ADC_READY) ||
                (adcp->state == ADC_COMPLETE) ||
                (adcp->state == ADC_ERROR),
                "not ready");

  if(adcp == NULL)
    return ADC_ERROR_NULLPTR;

  if((adcp->state != ADC_READY)
    && (adcp->state != ADC_ACTIVE))
    return ADC_ERROR_STATE;

  adcp->samples  = samples;
  adcp->depth    = depth;
  adcp->grpp     = grpp;
  adcp->state    = ADC_ACTIVE;
  return adc_lld_start_conversion(adcp);
}

#if (HS_HAS_DMA == TRUE) && (ADC_USE_DMA == TRUE)
int adcStartConversionWithDMA(ADCDriver *adcp, uint8_t *pDmaBuf, uint32_t DmaLen) {

  osalDbgCheck((adcp != NULL));
  if(adcp == NULL)
  {
    return ADC_ERROR_NULLPTR;
  }

  if((adcp->state != ADC_READY)
    && (adcp->state != ADC_ACTIVE))
  {
    return ADC_ERROR_STATE;
  }

  adcp->state = ADC_DMAACTIVE;
  return adc_lld_start_conversionWithDMA(adcp, pDmaBuf, DmaLen);
}

int adcDmaWaitForDone(ADCDriver *adcp, systime_t timeout) {

  int res;

  osalDbgCheck((adcp != NULL));
  if(adcp == NULL)
  {
    return ADC_ERROR_NULLPTR;
  }

  if(adcp->state != ADC_DMAACTIVE)
  {
    return ADC_ERROR_STATE;
  }

  osalSysLock();
  res = adc_lld_dmaWaitForDone(adcp, timeout);
  osalSysUnlock();

  adcp->state = ADC_READY;
  return res;
}
#endif

/**
 * @brief   Stops an ongoing conversion.
 * @details This function stops the currently ongoing conversion and returns
 *          the driver in the @p ADC_READY state. If there was no conversion
 *          being processed then the function does nothing.
 *
 * @param[in] adcp      pointer to the @p ADCDriver object
 *
 * @api
 */
void adcStopConversion(ADCDriver *adcp) {

  osalDbgCheck(adcp != NULL);

  osalSysLock();
  osalDbgAssert((adcp->state == ADC_READY) || (adcp->state == ADC_ACTIVE),
                "invalid state");

  if (adcp->state != ADC_READY) {
    adc_lld_stop_conversion(adcp);
    adcp->grpp  = NULL;
    adcp->state = ADC_READY;
    _adc_reset_s(adcp);
  }
  osalSysUnlock();
}

/**
 * @brief   Stops an ongoing conversion.
 * @details This function stops the currently ongoing conversion and returns
 *          the driver in the @p ADC_READY state. If there was no conversion
 *          being processed then the function does nothing.
 *
 * @param[in] adcp      pointer to the @p ADCDriver object
 *
 * @iclass
 */
void adcStopConversionI(ADCDriver *adcp) {

  osalDbgCheckClassI();
  osalDbgCheck(adcp != NULL);
  osalDbgAssert((adcp->state == ADC_READY) ||
                (adcp->state == ADC_ACTIVE) ||
                (adcp->state == ADC_COMPLETE),
                "invalid state");

  if (adcp->state != ADC_READY) {
			adc_lld_stop_conversion(adcp);
			adcp->grpp  = NULL;
			adcp->state = ADC_READY;
			_adc_reset_i(adcp);
	}
}

#if (ADC_USE_WAIT == TRUE) || defined(__DOXYGEN__)
/**
 * @brief   Performs a synchronous, one-shot, ADC conversion.
 * @details Performs a synchronous conversion operation, one-shot.
 * @note    The buffer is organized as a matrix of M*N elements where M is the
 *          channels number configured into the conversion group and N is the
 *          buffer depth. The samples are sequentially written into the buffer
 *          with no gaps.
 *          A synchronous conversion must be an one-shot one.
 * @note    Temperature data is in 10 degree Celsius.
 *
 * @param[in] adcp      Pointer to the @p ADCDriver object
 * @param[in] grpp      Pointer to a @p ADCConversionGroup object
 * @param[out] samples  Pointer to the samples buffer
 * @param[in] depth     Buffer depth (matrix rows number). The buffer depth
 *                      must be one or an even number.
 * @param [in] timeout  Timeout time.
 * @return              The operation result.
 * @retval MSG_OK       Conversion finished.
 * @retval MSG_RESET    The conversion has been stopped using
 *                      @p acdStopConversion() or @p acdStopConversionI(),
 *                      the result buffer may contain incorrect data.
 * @retval MSG_TIMEOUT  The conversion has been stopped because an hardware
 *                      error.
 *
 * @api
 */
msg_t adcConvert(ADCDriver *adcp,
                 const ADCConversionGroup *grpp,
                 adcsample_t *samples,
                 size_t depth,
                 systime_t timeout) {
  msg_t msg;

  osalSysLock();
  osalDbgAssert(adcp->thread == NULL, "already waiting");

  /**
   * TODO:
	 * Circular-Buffer mode has no sense for synchronous conversion.
   * Now deals with this in _adc_isr_full_code()
   * conditions ((adcp)->grpp->circular && ((adcp)->thread==NULL)).
   * since adcp->grpp is a const parameter.
	 */

  adcStartConversionI(adcp, grpp, samples, depth);
  /**
   * Issue of soft-trigger-event in soft-trigger mode:
   * Synchronous conversion:  issued immediately as following.
   * Asynchronous conversion: it is up to the user to assert the issue.
   */
  if (adcp->grpp->trigger.source == ADC_TRIGGER_SOURCE_SW)
  	adc_lld_soft_trigger(adcp);
	msg = osalThreadSuspendTimeoutS(&adcp->thread, timeout);
  osalSysUnlock();
  return msg;
}
#endif /* ADC_USE_WAIT == TRUE */

#if (ADC_USE_MUTUAL_EXCLUSION == TRUE) || defined(__DOXYGEN__)
/**
 * @brief   Gains exclusive access to the ADC peripheral.
 * @details This function tries to gain ownership to the ADC bus, if the bus
 *          is already being used then the invoking thread is queued.
 * @pre     In order to use this function the option
 *          @p ADC_USE_MUTUAL_EXCLUSION must be enabled.
 *
 * @param[in] adcp      pointer to the @p ADCDriver object
 *
 * @api
 */
void adcAcquireBus(ADCDriver *adcp) {

  osalDbgCheck(adcp != NULL);

  osalMutexLock(&adcp->mutex);
}

/**
 * @brief   Releases exclusive access to the ADC peripheral.
 * @pre     In order to use this function the option
 *          @p ADC_USE_MUTUAL_EXCLUSION must be enabled.
 *
 * @param[in] adcp      pointer to the @p ADCDriver object
 *
 * @api
 */
void adcReleaseBus(ADCDriver *adcp) {

  osalDbgCheck(adcp != NULL);

  osalMutexUnlock(&adcp->mutex);
}
#endif /* ADC_USE_MUTUAL_EXCLUSION == TRUE */

////////////////////////
//---------------------------------------------------------------------------
// ADC conversion group operations.
//---------------------------------------------------------------------------
/**
 * @brief   Determine VCM based on max and min voltages of positive input channel.
 * @param max   max voltage in mV, >= 0.
 * @param min   min voltage in mV, >= 0.
 * @retval      a value of @p adc_vcm_t.
 */
static adc_vcm_t adc_get_vcm(int max, int min) {

	(void)min;

#if defined(BR3215)
	return ADC_VCM_SEL_000mV;
#endif

	/**
	 * Use of VCM only when you have to.
	 * This policy is based on the fact that using VCM is worse than not.
	 */
	if (max <= 1800)
		return ADC_VCM_SEL_000mV;
	else
		return ADC_VCM_SEL_1000mV;
}

/**
 * @brief   Determine gain of pre-gain-amplifier (PGA) based on voltage range of signal.
 * @param range   voltage range of signal in mV.
 * @retval        a value of @p adc_pga_gain_t.
 */
static adc_pga_gain_t adc_get_gain(int range) {

#if defined(BR3215)
	return ADC_PGA_GAIN_0P5;
#endif

	int gain;
	if (range <= 200)          // [0mV, 200mV]
		gain = ADC_PGA_GAIN_4;
	else if (range <= 400)     // [200mV, 400mV]
		gain = ADC_PGA_GAIN_2;
	else if (range <= 900)     // [400mV, 900mV]
		gain = ADC_PGA_GAIN_1;
	else if (range <= 1800)    // [900mV, 1800mV]
		gain = ADC_PGA_GAIN_0P5;
	else                       // [1800mV, --], Out of range, external attenuation is needed.
		gain = ADC_PGA_GAIN_0P5;

	return gain;
}

/**
 * @brief   Build ADC conversion group with empty channels.
 *
 * @param grpp             Pointer to an @p ADCConversionGroup object.
 * @param circular         Enable the circular buffer mode for the group.
 * @param cal_en           Enable calibration compensation for the group.
 * @param trigger_source   Specify trigger source for the group.
 * @param trigger_edge     Specify hardware trigger edge for the group.
 * @param trigger_target   Specify trigger target for the group.
 * @param end_cb           Pointer to ADC notification callback function of type
 *                         @p adccallback_t. Can be NULL.
 * @param error_cb         Pointer to ADC error callback function of type
 *                         @p adcerrorcallback_t. Can be NULL.
 */
void adcBuildConversionGroup(ADCConversionGroup *grpp,
                             bool circular,
                             bool cal_en,
                             adc_trigger_source_t trigger_source,
                             adc_trigger_edge_t trigger_edge,
                             adc_trigger_target_t trigger_target,
                             adccallback_t end_cb,
                             adcerrorcallback_t error_cb) {

	adc_lld_build_conversion_group(grpp, circular, cal_en, trigger_source,
			trigger_edge, trigger_target, end_cb, error_cb);
}

/**
 * @brief   Add a single-ended channel to an @p ADCConversionGroup.
 * @note    Single-ended is the special case of which inn == ADC_CHANNEL_CHIP_VCM.
 *          An ADCConversionGroup must contain all single-ended channels or all
 *          differential channels, because the two compensation methods are different
 *          and there's only one control for all channels.
 * @param grpp          Pointer to an @p ADCConversionGroup object.
 * @param chn           The single-ended input channel, the signal must >= 0V.
 * @param max_mv        max voltage of chn in mV, used for single-ended only
 * @param min_mv        min voltage of chn in mV, used for single-ended only
 * @param gpio_pin      Specify GPIO pin num for channel of ADC_CHANNEL_EXTERN_PIN0/1/2,
 *                      for BR3215e only.
 *                      gpio_pin = 0 stands for NONE pin.
 *                      Pin number stands for GPIOx, which x = gpio_pin.
 *                      ADC_CHANNEL_EXTERN_PIN0: GPIOx, x = 2/3/4/5/9.
 *                      ADC_CHANNEL_EXTERN_PIN1: GPIOx, x = 10/11/12/13/16.
 *                      ADC_CHANNEL_EXTERN_PIN2: GPIOx, x = 17/18/19/20/21.
 * @return              Number of channels in the group.
 */
int adcAddChannelSingleEnded(ADCConversionGroup *grpp,
		                         adc_channel_t chn,
		                         int max_mv,
		                         int min_mv,
		                         uint32_t gpio_pin) {

	// the battery channel has a fixed attenuation of 1/3 internally.
	if (chn == ADC_CHANNEL_CHIP_BATTERY) {
		max_mv /= 3;
		min_mv /= 3;
	}
#if defined(BR3215e)
	else if (chn == ADC_CHANNEL_CHIP_1V4) {
		max_mv *= 5; max_mv /= 7;
		min_mv *= 5; min_mv /= 7;
	}
	else if (chn == ADC_CHANNEL_CHIP_3V3) {
		max_mv /= 2;
		min_mv /= 2;
	}
#else
	(void)gpio_pin;
#endif

	adc_vcm_t vcm = adc_get_vcm(max_mv, min_mv);
	adc_pga_gain_t gain = adc_get_gain(max_mv);
	return adc_lld_add_channel(grpp, chn, ADC_CHANNEL_CHIP_VCM, vcm, gain, gpio_pin, 0);
}

/**
 * @brief   Add a differential channel to an @p ADCConversionGroup.
 * @note    Differential is the special case of which inn != ADC_CHANNEL_CHIP_VCM.
 *          An ADCConversionGroup must contain all single-ended channels or all
 *          differential channels, because the two compensation methods are different
 *          and there's only one control for all channels.
 * @param grpp          Pointer to an @p ADCConversionGroup object.
 * @param chn_pos       Positive input channel, the signal must >= 0V.
 * @param chn_neg       Negative input channel, the signal must >= 0V.
 * @param max_abs_vpn   max(abs(vip-vin)) in mV, used for differential only
 * @param gpio_pin_inp  Specify GPIO pin num for chn_pos of ADC_CHANNEL_EXTERN_PIN0/1/2,
 * @param gpio_pin_inn  Specify GPIO pin num for chn_neg of ADC_CHANNEL_EXTERN_PIN0/1/2,
 *                      for BR3215e only.
 *                      gpio_pin = 0 stands for NONE pin.
 *                      Pin number stands for GPIOx, which x = gpio_pin.
 *                      ADC_CHANNEL_EXTERN_PIN0: GPIOx, x = 2/3/4/5/9.
 *                      ADC_CHANNEL_EXTERN_PIN1: GPIOx, x = 10/11/12/13/16.
 *                      ADC_CHANNEL_EXTERN_PIN2: GPIOx, x = 17/18/19/20/21.
 * @return              Number of channels in the group.
 */
int adcAddChannelDifferential(ADCConversionGroup *grpp,
                              adc_channel_t chn_pos,
                              adc_channel_t chn_neg,
                              int max_abs_vpn,
                              uint32_t gpio_pin_inp,
                              uint32_t gpio_pin_inn) {

#if !defined(BR3215e)
	(void)gpio_pin_inp;
	(void)gpio_pin_inn;
#endif

	// VCM is not used in differential mode, set it to default value of 0.
	adc_vcm_t vcm = ADC_VCM_SEL_000mV;
	// determine gain based on max_abs_vpn
	adc_pga_gain_t gain = adc_get_gain(max_abs_vpn);
	return adc_lld_add_channel(grpp, chn_pos, chn_neg, vcm, gain,
			gpio_pin_inp, gpio_pin_inn);
}

int adcAddChannelTemperature(ADCConversionGroup *grpp) {

#if 0
	return adc_lld_add_channel_temperature(grpp);
#else
	return adcAddChannelSingleEnded(grpp, ADC_CHANNEL_CHIP_TEMPERATURE, 739+250, 739-250, 0);
#endif
}

int adcAddChannelBattery(ADCConversionGroup *grpp) {

	return adcAddChannelSingleEnded(grpp, ADC_CHANNEL_CHIP_BATTERY, 4200, 0, 0);
}

#if defined(BR3215e)
int adcAddChannel1V4(ADCConversionGroup *grpp) {

	return adcAddChannelSingleEnded(grpp, ADC_CHANNEL_CHIP_1V4, 1800, 0, 0);
}

int adcAddChannel3V3(ADCConversionGroup *grpp) {

#if 0
	return adc_lld_add_channel(grpp, ADC_CHANNEL_CHIP_3V3, ADC_CHANNEL_CHIP_VCM, 8, 0, 0, 0);
#else
	return adcAddChannelSingleEnded(grpp, ADC_CHANNEL_CHIP_3V3, 3600, 0, 0);
#endif
}
#endif

/**
 * @brief  Convert sample data from fixed-point (Q4.11) format to
 *         floating-point format.
 *
 * @param fdata     buffer to store converted floating-point data.
 * @param samples   buffer of data in @adcsample_t (Q4.11) format.
 * @param num       number of data to be converted.
 */
void adcDataFixedToFloat(float *fdata, adcsample_t *samples, uint32_t num) {

	uint16_t i;
	for (i = 0; i < num; i++)
		fdata[i] = adc_data_q2f(samples[i]);
}

static void adcConfigExternalChannelPin(adc_channel_t chn, uint32_t gpio_pin) {

	if (chn >= ADC_CHANNEL_EXTERN_PIN0 && chn < ADC_CHANNEL_PEAK_DETECTOR) {
#if defined(BR3215e)
		uint32_t gpio_sel = adc_gpio_pin_to_gpio_sel(gpio_pin);
		HS_PMU->WAKEUP_COMN_CFG &= ~(0x0Fu << 12);
		HS_PMU->WAKEUP_COMN_CFG |= (gpio_sel << 12); // select GPIO pin to ADC
		HS_PMU->PADC_CON[gpio_pin] &= ~0x7u; // connect analog input to ADC
#endif
		palSetPinMode(gpio_pin,
			PAL_MODE_INPUT | PAL_MODE_ALTERNATE(PAD_FUNC_GPIO) | PAL_MODE_DRIVE_CAP(3));
	}
}

static void adcRestoreExternalChannelPin(adc_channel_t chn, uint32_t gpio_pin) {

	if (chn >= ADC_CHANNEL_EXTERN_PIN0 && chn < ADC_CHANNEL_PEAK_DETECTOR) {
#if defined(BR3215e)
		HS_PMU->WAKEUP_COMN_CFG &= ~(0x0Fu << 12); // disable GPIO pin to ADC
		HS_PMU->PADC_CON[gpio_pin] |= 0x1u; // disconnect analog input to ADC
		palSetPinMode(gpio_pin,
				PAL_MODE_INPUT | PAL_MODE_ALTERNATE(PAD_FUNC_JTAG) | PAL_MODE_DRIVE_CAP(3));
#else
		palSetPinMode(gpio_pin,
			  PAL_MODE_INPUT_PULLUP | PAL_MODE_ALTERNATE(PAD_FUNC_JTAG) | PAL_MODE_DRIVE_CAP(3));
#endif
	}
}

/**
 * @brief   Configure ADC external channel pins of the conversion group,
 *          including negative input pin of differential channels.
 *
 * @param grpp   Pointer to a @p ADCConversionGroup object
 */
void adcConfigExternalChannelPins(ADCConversionGroup *grpp) {

	int i;
	for (i = 0; i < grpp->num_channels; i++) {
		adc_channel_t chn = grpp->channel[i];
#if defined(BR3215e)
		uint32_t gpio_pin = adc_gpio_sel_to_gpio_pin(grpp->channel_param[chn].gpio_sel);
		adcConfigExternalChannelPin(chn, gpio_pin);
		// currently, BR3215e can not do differential measurement.
		// adcConfigExternalChannelPin(inn, grpp->channel_param[chn].gpio_sel_inn);
#else
		adcConfigExternalChannelPin(chn, chn-ADC_CHANNEL_EXTERN_PIN0+1);

		adc_channel_t inn = grpp->channel_param[chn].sel_inn;
		adcConfigExternalChannelPin(inn, inn-ADC_CHANNEL_EXTERN_PIN0+1);
#endif
	}
}

/**
 * @brief   Restore ADC external channel pins to their default settings,
 *          including negative input pin of differential channels.
 *
 * @param grpp   Pointer to a @p ADCConversionGroup object
 */
void adcRestoreExternalChannelPins(ADCConversionGroup *grpp) {

	int i;
	for (i = 0; i < grpp->num_channels; i++) {
		adc_channel_t chn = grpp->channel[i];
		if (chn >= ADC_CHANNEL_EXTERN_PIN0 && chn < ADC_CHANNEL_PEAK_DETECTOR) {
#if defined(BR3215e)
			uint32_t gpio_pin = adc_gpio_sel_to_gpio_pin(grpp->channel_param[chn].gpio_sel);
			adcRestoreExternalChannelPin(chn, gpio_pin);
			// currently, BR3215e can not do differential measurement.
#else
			adcRestoreExternalChannelPin(chn, chn-ADC_CHANNEL_EXTERN_PIN0+1);
			adc_channel_t inn = grpp->channel_param[chn].sel_inn;
			adcRestoreExternalChannelPin(inn, inn-ADC_CHANNEL_EXTERN_PIN0+1);
#endif
		}
	}
}

/**
 * @brief  Configure ADC external trigger pin of GPIO12.
 */
void adcConfigExternalTriggerPin(void) {

	/* Set GPIO12 in SFLASH mode */
	palSetPadMode(GPIOA, 12, PAL_MODE_INPUT_PULLDOWN
				| PAL_MODE_ALTERNATE(PAD_FUNC_SFLASH)	| PAL_MODE_DRIVE_CAP(3));
}

//---------------------------------------------------------------------------
// ADC Calibration
//---------------------------------------------------------------------------

#define ADC_CAL_MEASURE_COUNT       100//1000

/**
 * @brief   Execute a ADC measurement under given conditions.
 * @param adcp         Pointer to an @p ADCDriver object.
 * @param cal_table    Pointer to the calibration table used to measure the parameter.
 * @param inp          Positive input channel.
 * @param inn          Negative input channel.
 * @param vcm
 * @param gain         gain of pre-gain-amplifier (PGA), @p adc_pga_gain_t.
 * @return             value of type @p adcsample_t in fixed-point format of Q4.11.
 */
static adcsample_t adc_cal_measure(ADCDriver *adcp, adc_cal_table_t *cal_table,
                                adc_channel_t inp, adc_channel_t inn,
																adc_vcm_t vcm, adc_pga_gain_t gain) {

	ADCConversionGroup group;
	adcsample_t samples[ADC_CAL_MEASURE_COUNT];

	adcBuildConversionGroup(&group, false, true, ADC_TRIGGER_SOURCE_SW,
									ADC_TRIGGER_EDGE_NOTUSED, ADC_TRIGGER_TARGET_GROUP_CONTINUOUS,
									NULL, NULL);
	adc_lld_add_channel(&group,	inp, inn, vcm, gain, 0, 0);

	adcAcquireBus(adcp);
	adcp->cal_table = cal_table;
	adcStart(adcp, NULL);
	adcConvert(adcp, &group, samples, ADC_CAL_MEASURE_COUNT, TIME_INFINITE);
	adcStop(adcp);
	adcReleaseBus(adcp);

	int i;
	int32_t average = 0;

	for (i = 0; i < ADC_CAL_MEASURE_COUNT; i++) {
		average += (int32_t)samples[i];
	}
	average /= ADC_CAL_MEASURE_COUNT;

	return (adcsample_t)average;
}

/**
 * @brief Calibrate the vos_mod compensation parameter.
 * @note
 *
 * Single-ended:
 * inp    : Pin0 = [1.4, 0.8, 0.4, 0.2]v
 * inn    : VCM  = 0v
 * gain   : [0.5, 1, 2, 4]
 * ideal  : [0x0B30, 0x0666, 0x0333, 0x019A]
 * formula: vos_mod = d1 - ideal*gain.
 *                  = (d3(vos_mod=0,gain_mod=1,vcm=0) - ideal)*gain.
 * Differential:
 * inp    : Pin0 = [1+0.7, 1+0.4, 1+0.2, 1+0.1]v
 * inn    : Pin1 = [1-0.7, 1-0.4, 1-0.2, 1-0.1]v
 * gain   : [0.5, 1, 2, 4]
 * ideal  : [0x0B30, 0x0666, 0x0333, 0x019A]
 * formula: vos_mod = d1 - ideal*gain.
 *                  = (d3(vos_mod=0,gain_mod=1,vcm=0) - ideal)*gain.
 *
 * @param adcp         Pointer to an @p ADCDriver object.
 * @param cal_table    Pointer to the calibration table used to measure the parameter.
 * @param inp          Positive input channel.
 * @param inn          Negative input channel.
 * @param gain         gain of pre-gain-amplifier (PGA), @p adc_pga_gain_t.
 * @return             value of type @p adcsample_t in fixed-point format of Q4.11.
 */
static adcsample_t adc_cal_vos_mod(ADCDriver *adcp, adc_cal_table_t *cal_table,
															  adc_channel_t inp, adc_channel_t inn, adc_pga_gain_t gain) {

	const int16_t gain_val[] = {0x0800>>1, 0x0800, 0x0800<<1, 0x0800<<2}; // UQ1.11 of [0.5, 1, 2, 4]
	const adcsample_t ideal[] = {0x0B30, 0x0666, 0x0333, 0x019A}; // Q4.11 of [1.4, 0.8, 0.4, 0.2]
	adcsample_t d3 = adc_cal_measure(adcp, cal_table, inp, inn, ADC_VCM_SEL_000mV, gain);
#if !HS_ADC_HAS_HARD_CAL && defined(HS_ADC_EXTENDED_RANGE_ENABLE)
	adcsample_t vos_mod = (adcsample_t)adc_data_qmul((d3 - ideal[gain]*4), gain_val[gain]);
#else
	adcsample_t vos_mod = (adcsample_t)adc_data_qmul((d3 - ideal[gain]), gain_val[gain]);
#endif
	// Convert vos_mod from Q4.11 to Q0.11
	if (vos_mod & 0x8000) {
		vos_mod |= 0x0800;
	}
	vos_mod &= 0x0FFF;

	return vos_mod;
}

/**
 * @brief Calibrate the gain_mod compensation parameter.
 * @note
 *
 * Single-ended:
 * inp    : Pin0 = [1.4, 0.8, 0.4, 0.2]v
 * inn    : VCM  = 0v
 * gain   : [0.5, 1, 2, 4]
 * ideal  : [0x0B30, 0x0666, 0x0333, 0x019A]
 * formula: gain_mod = ideal / d2(gain_mod=1).
 *                   = ideal / d3(gain_mod=1,vcm=0).
 * Differential:
 * inp    : Pin0 = [1+0.7, 1+0.4, 1+0.2, 1+0.1]v
 * inn    : Pin1 = [1-0.7, 1-0.4, 1-0.2, 1-0.1]v
 * gain   : [0.5, 1, 2, 4]
 * ideal  : [0x0B30, 0x0666, 0x0333, 0x019A]
 * formula: gain_mod = ideal / d2(gain_mod=1).
 *                   = ideal / d3(gain_mod=1,vcm=0).
 *
 * @param adcp         Pointer to an @p ADCDriver object.
 * @param cal_table    Pointer to the calibration table used to measure the parameter.
 * @param inp          Positive input channel.
 * @param inn          Negative input channel.
 * @param gain         gain of pre-gain-amplifier (PGA), @p adc_pga_gain_t.
 * @return             gain_mod in fixed-point format of UQ1.11.
 */
static int16_t adc_cal_gain_mod(ADCDriver *adcp, adc_cal_table_t *cal_table,
																 adc_channel_t inp, adc_channel_t inn, adc_pga_gain_t gain) {

	const adcsample_t ideal[] = {0x0B30, 0x0666, 0x0333, 0x019A}; // Q4.11 of [1.4, 0.8, 0.4, 0.2]
	adcsample_t d3 = adc_cal_measure(adcp, cal_table, inp, inn, ADC_VCM_SEL_000mV, gain);
#if !HS_ADC_HAS_HARD_CAL && defined(HS_ADC_EXTENDED_RANGE_ENABLE)
	int16_t gain_mod = (int16_t)adc_data_qdiv(ideal[gain]*4, d3);
#else
	int16_t gain_mod = (int16_t)adc_data_qdiv(ideal[gain], d3);
#endif
  gain_mod &= 0x0FFF;

	return gain_mod;
}

/**
 * @brief Calibrate the vcm_mod compensation parameter.
 * @note
 *
 * Single-ended:
 * inp    : Pin0 = 0v
 * inn    : VCM  = [1, 0.5, 0.25, 0.125]v
 * gain   : [0.5, 1, 2, 4]
 * vcm_ideal : [0x0400, 0x0200, 0x0100, 0x0080]
 * formula: vcm_mod = 1 + (ideal - d3(vcm_mod=1))/vcm.
 *
 * Differential:
 *     Not applicable.
 *
 * @param adcp         Pointer to an @p ADCDriver object.
 * @param cal_table    Pointer to the calibration table used to measure the parameter.
 * @param inp          Positive input channel.
 * @param gain         gain of pre-gain-amplifier (PGA), @p adc_pga_gain_t.
 * @return             vcm_mod in fixed-point format of UQ1.11.
 */
static int16_t adc_cal_vcm_mod(ADCDriver *adcp, adc_cal_table_t *cal_table,
															  adc_channel_t inp, adc_pga_gain_t gain) {

	// VCM is used only when ADC_PGA_GAIN_0P5 is used.
	if (gain != ADC_PGA_GAIN_0P5)
		return 0x0800; // default value

	adcsample_t d3 = adc_cal_measure(adcp, cal_table, inp, ADC_CHANNEL_CHIP_VCM, ADC_VCM_SEL_1000mV, gain);
	int16_t vcm_mod = 0x0800 + adc_data_qdiv(0x0F33 - (int32_t)d3, 0x0800); // ideal = 0x0F33 = 1.9f
	vcm_mod = abs(vcm_mod) & 0x0FFF;

#if 0 // if cal vcm_mod?
	return vcm_mod;
#else
	return 0x0800; // default value.
#endif
}

/**
 *  @brief Calibrate ADC and initialize ADC compensation parameters.
 *         Used during CP/FT.
 *
 *  @note  Before ATE issues the test command, it should have prepared the
 *         specified voltages at ch0 and ch1 to be ready. Please refer to
 *         @p adc_cal_cmd_t for the specified voltages.
 *
 *         When all the calibration parameters are calibrated, burn the table
 *         to flash memory at address @p ADC_CAL_TABLE.
 *         @p ADC_CAL_TABLE should be well defined before FT test.
 *
 *         BR3215c:
 *         0. ADC_CAL_TABLE should be defined pointing to an @p adc_cal_table_t.
 *         1. Calibrate all parameters in @p adc_cal_table_t.
 *         2. Store the @p adc_cal_table_t object to @p ADC_CAL_TABLE in Flash.
 *
 *         BR3215:
 *         0. ADC_CAL_TABLE should be defined pointing to an
 *            @p adc_cal_param_3215_t.
 *         1. Need only calibrate s_vos_mod_0 and s_gain_mod_0.
 *         2. Convert s_vos_mod_0 and s_gain_mod_0 into an
 *            @p adc_cal_param_3215_t object.
 *         3. Store the @p adc_cal_param_3215_t object to @p ADC_CAL_TABLE in
 *            Flash.
 *
 *  @param adcp        Pointer to @p ADCDriver object.
 *  @param cal_table   Pointer to @p adc_cal_table_t object where the
 *                     calibration parameters are to be returned.
 *  @param cmd         Test command of type @p adc_cal_cmd_t, issued by ATE.
 */
void adcCalibrate(ADCDriver *adcp, adc_cal_table_t *cal_table,
		              adc_cal_cmd_t cmd, adc_channel_t ch0, adc_channel_t ch1) {

	adcInit();

	adc_pga_gain_t gain;

	/**
	 * Calibration process, order must be followed:
	 * 1. vos_mod
	 * 2. gain_mod
   * 3. vcm_mod
	 */
	switch (cmd) {
	case ADC_CAL_CMD_BEGIN:
#if defined(BR3215e)
		adcConfigExternalChannelPin(ch0, 9);
#else
		adcConfigExternalChannelPin(ch0, ch0-2);
		adcConfigExternalChannelPin(ch1, ch1-2);
#endif
		break;
	case ADC_CAL_CMD_SINGLE_ENDED_0:
		cal_table->s_vos_mod_0  = adcp->cal_table_default->s_vos_mod_0;
		cal_table->s_gain_mod_0 = adcp->cal_table_default->s_gain_mod_0;
		cal_table->s_vcm_mod_0  = adcp->cal_table_default->s_vcm_mod_0;
		gain = ADC_PGA_GAIN_0P5;
		cal_table->s_vos_mod_0  = adc_cal_vos_mod( adcp, cal_table, ch0, ADC_CHANNEL_CHIP_VCM, gain);
		cal_table->s_gain_mod_0 = adc_cal_gain_mod(adcp, cal_table, ch0, ADC_CHANNEL_CHIP_VCM, gain);
		cal_table->s_vcm_mod_0  = adc_cal_vcm_mod( adcp, cal_table, ch1, gain);
		break;
	case ADC_CAL_CMD_SINGLE_ENDED_1:
		cal_table->s_vos_mod_1  = adcp->cal_table_default->s_vos_mod_1;
		cal_table->s_gain_mod_1 = adcp->cal_table_default->s_gain_mod_1;
		cal_table->s_vcm_mod_1  = adcp->cal_table_default->s_vcm_mod_1;
		gain = ADC_PGA_GAIN_1;
		cal_table->s_vos_mod_1  = adc_cal_vos_mod( adcp, cal_table, ch0, ADC_CHANNEL_CHIP_VCM, gain);
		cal_table->s_gain_mod_1 = adc_cal_gain_mod(adcp, cal_table, ch0, ADC_CHANNEL_CHIP_VCM, gain);
		cal_table->s_vcm_mod_1  = adc_cal_vcm_mod( adcp, cal_table, ch1, gain);
		break;
	case ADC_CAL_CMD_SINGLE_ENDED_2:
		cal_table->s_vos_mod_2  = adcp->cal_table_default->s_vos_mod_2;
		cal_table->s_gain_mod_2 = adcp->cal_table_default->s_gain_mod_2;
		cal_table->s_vcm_mod_2  = adcp->cal_table_default->s_vcm_mod_2;
		gain = ADC_PGA_GAIN_2;
		cal_table->s_vos_mod_2  = adc_cal_vos_mod( adcp, cal_table, ch0, ADC_CHANNEL_CHIP_VCM, gain);
		cal_table->s_gain_mod_2 = adc_cal_gain_mod(adcp, cal_table, ch0, ADC_CHANNEL_CHIP_VCM, gain);
		cal_table->s_vcm_mod_2  = adc_cal_vcm_mod( adcp, cal_table, ch1, gain);
		break;
	case ADC_CAL_CMD_SINGLE_ENDED_3:
		cal_table->s_vos_mod_3  = adcp->cal_table_default->s_vos_mod_3;
		cal_table->s_gain_mod_3 = adcp->cal_table_default->s_gain_mod_3;
		cal_table->s_vcm_mod_3  = adcp->cal_table_default->s_vcm_mod_3;
		gain = ADC_PGA_GAIN_4;
		cal_table->s_vos_mod_3  = adc_cal_vos_mod( adcp, cal_table, ch0, ADC_CHANNEL_CHIP_VCM, gain);
		cal_table->s_gain_mod_3 = adc_cal_gain_mod(adcp, cal_table, ch0, ADC_CHANNEL_CHIP_VCM, gain);
		cal_table->s_vcm_mod_3  = adc_cal_vcm_mod( adcp, cal_table, ch1, gain);
		break;
	case ADC_CAL_CMD_DIFFERENTIAL_0:
		cal_table->d_vos_mod_0  = adcp->cal_table_default->d_vos_mod_0;
		cal_table->d_gain_mod_0 = adcp->cal_table_default->d_gain_mod_0;
		gain = ADC_PGA_GAIN_0P5;
		cal_table->d_vos_mod_0  = adc_cal_vos_mod( adcp, cal_table, ch0, ch1, gain);
		cal_table->d_gain_mod_0 = adc_cal_gain_mod(adcp, cal_table, ch0, ch1, gain);
		break;
	case ADC_CAL_CMD_DIFFERENTIAL_1:
		cal_table->d_vos_mod_1  = adcp->cal_table_default->d_vos_mod_1;
		cal_table->d_gain_mod_1 = adcp->cal_table_default->d_gain_mod_1;
		gain = ADC_PGA_GAIN_1;
		cal_table->d_vos_mod_1  = adc_cal_vos_mod( adcp, cal_table, ch0, ch1, gain);
		cal_table->d_gain_mod_1 = adc_cal_gain_mod(adcp, cal_table, ch0, ch1, gain);
		break;
	case ADC_CAL_CMD_DIFFERENTIAL_2:
		cal_table->d_vos_mod_2  = adcp->cal_table_default->d_vos_mod_2;
		cal_table->d_gain_mod_2 = adcp->cal_table_default->d_gain_mod_2;
		gain = ADC_PGA_GAIN_2;
		cal_table->d_vos_mod_2  = adc_cal_vos_mod( adcp, cal_table, ch0, ch1, gain);
		cal_table->d_gain_mod_2 = adc_cal_gain_mod(adcp, cal_table, ch0, ch1, gain);
		break;
	case ADC_CAL_CMD_DIFFERENTIAL_3:
		cal_table->d_vos_mod_3  = adcp->cal_table_default->d_vos_mod_3;
		cal_table->d_gain_mod_3 = adcp->cal_table_default->d_gain_mod_3;
		gain = ADC_PGA_GAIN_4;
		cal_table->d_vos_mod_3  = adc_cal_vos_mod( adcp, cal_table, ch0, ch1, gain);
		cal_table->d_gain_mod_3 = adc_cal_gain_mod(adcp, cal_table, ch0, ch1, gain);
		break;
	case ADC_CAL_CMD_END:
#if defined(BR3215e)
		adcRestoreExternalChannelPin(ch0, 9);
#else
		adcRestoreExternalChannelPin(ch0, ch0-2);
		adcRestoreExternalChannelPin(ch1, ch1-2);
#endif
	default:
		break;
	}

#if 0
	if (cmd == ADC_CAL_CMD_DIFFERENTIAL_3) {
		// Burn to the specified address in FLASH:
		sfWrite(&SFD, ADC_CAL_TABLE, cal_table, sizeof(cal_table));
		adcp->cal_table = ADC_CAL_TABLE;
	}
#endif

}

#endif /* HAL_USE_ADC == TRUE */

/** @} */
