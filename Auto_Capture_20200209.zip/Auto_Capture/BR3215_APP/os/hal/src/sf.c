/*
    ChibiOS/RT - Copyright (C) 2006,2007,2008,2009,2010,
                 2011,2012,2013 Giovanni Di Sirio.
                 Copyright (C) 2019 BRMICRO Technologies
                 

    This file is part of ChibiOS/RT.

    ChibiOS/RT is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    ChibiOS/RT is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

                                      ---

    A special exception to the GPL can be applied should you wish to distribute
    a combined work that includes ChibiOS/RT, without being obliged to provide
    the source code for any proprietary components. See the file exception.txt
    for full details of how and when the exception can be applied.
*/

/**
 * @file    sf.c
 * @brief   SPI flash interface Driver code.
 *
 * @addtogroup SF
 * @{
 */

#include "hal.h"

#if HAL_USE_SF || defined(__DOXYGEN__)

/*===========================================================================*/
/* Driver local definitions.                                                 */
/*===========================================================================*/

/*===========================================================================*/
/* Driver exported variables.                                                */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local variables and types.                                         */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local functions.                                                   */
/*===========================================================================*/

/*===========================================================================*/
/* Driver exported functions.                                                */
/*===========================================================================*/

/**
 * @brief   SPI flash interface Driver initialization.
 * @note    This function is implicitly invoked by @p halInit(), there is
 *          no need to explicitly initialize the driver.
 *
 * @init
 */
void sfInit(void) {
  sf_lld_init();
}

/**
 * @brief   Initializes the standard part of a @p SFDriver structure.
 *
 * @param[out] sfp     pointer to the @p SFDriver object
 *
 * @init
 */
void sfObjectInit(SFDriver *sfp) { 
  sfp->state = SF_STOP;
  sfp->config = NULL;
  
#if SF_USE_MUTUAL_EXCLUSION
  osalMutexObjectInit(&sfp->mutex);
#endif /* SF_USE_MUTUAL_EXCLUSION */
}

/**
 * @brief   Configures and activates the SPI flash interface.
 *
 * @param[in] sfp      pointer to the @p SFDriver object
 * @param[in] config    pointer to the @p SFConfig object
 *
 * @api
 */
int sfStart(SFDriver *sfp, const SFConfig *config) {
  int res;
  
  if((sfp == NULL) || (config == NULL)) {
    return SF_RES_ERROR_NULLPTR;
  }

  osalSysLock();
  
  if((sfp->state != SF_STOP) && (sfp->state != SF_READY))
  {
    osalSysUnlock();
    return SF_RES_ERROR_STATE;
  }
  
  sfp->config = config;
  res = sf_lld_start(sfp);
  if(res == 0)
    sfp->state = SF_READY;
  
  osalSysUnlock();

  return res;
}

/**
 * @brief Deactivates the SPI flash interface.
 * @note  Deactivating the peripheral also enforces a release of the slave
 *        select line.
 *
 * @param[in] sfp      pointer to the @p SFDriver object
 *
 * @api
 */
int sfStop(SFDriver *sfp) {
  int res;
  
  if(sfp == NULL) {
    return SF_RES_ERROR_NULLPTR;
  }

  osalSysLock();
  if((sfp->state != SF_STOP) && (sfp->state != SF_READY) && (sfp->state != SF_FOUND))
  {    
    osalSysUnlock();
    return SF_RES_ERROR_STATE;
  }
  
  res = sf_lld_stop(sfp);
  if(res == 0) {
    sfp->state = SF_STOP;
  }
  
  osalSysUnlock();
  return res;
}

/**
 * @brief probe the SPI flash.
 * @note  
 *
 * @param[in] sfp      pointer to the @p SFDriver object
 *
 * @api
 */
int sfProbe(SFDriver *sfp, systime_t to) {
  int res;
  
  if(sfp == NULL) {
    return SF_RES_ERROR_NULLPTR;
  }

  osalSysLock();
  if((sfp->state != SF_READY) && (sfp->state != SF_FOUND)) {
    osalSysUnlock();
    return SF_RES_ERROR_STATE;
  }
  
  sfp->timeout = to;
  res = sf_lld_probe(sfp);
  if(res >= 0)
    sfp->state = SF_FOUND;
  
  osalSysUnlock();
  return res;
}

/**
 * @brief erase the SPI flash.
 * @note  If offset or len is not sector-size aligned, extra data in flash will be erased.
 *
 * @param[in] sfp      pointer to the @p SFDriver object
 * @param[in] offset   the flash address to erase, which is sector-size aligned
 * @param[in] len      the length of space to erase, which is sector-size aligned
 * @param[in] to       the number of ticks before the operation timeouts
 *
 * @api
 */
int sfErase(SFDriver *sfp, uint32_t offset, size_t len, systime_t to) {
  int res;

  if(sfp == NULL) {
    return SF_RES_ERROR_NULLPTR;
  }

  osalSysLock();  
  sfp->timeout = to;  
  res = sf_lld_erase(sfp, offset, len);

  osalSysUnlock();

  return res;
}

/**
 * @brief read data from the SPI flash.
 * @note  rdbuf and len must be dword aligned, due to the limitation of AHB DMA behavior.
 *
 * @param[in] sfp      pointer to the @p SFDriver object
 * @param[in] offset   the flash address to read
 * @param[in] rdbuf    the buffer address to read, which is dword aligned
 * @param[in] len      the length of space to read, which is dword aligned
 * @param[in] to       the number of ticks before the operation timeouts
 *
 * @api
 */
int sfRead(SFDriver *sfp, uint32_t offset, void *rdbuf, size_t len, systime_t to) {
  int res;

  if(sfp == NULL) {
    return SF_RES_ERROR_NULLPTR;
  }

  osalSysLock();
  
  sfp->timeout = to;
  res = sf_lld_read(sfp, offset, rdbuf, len);
  
  osalSysUnlock();

  return res;
}

/**
 * @brief program data to the SPI flash.
 * @note  wrbuf and len must be dword aligned, due to the limitation of AHB DMA behavior.
 *
 * @param[in] sfp      pointer to the @p SFDriver object
 * @param[in] offset   the flash address to program, which is dword aligned due to some special flash memory
 * @param[in] wrbuf    the buffer address to program, which is dword aligned
 * @param[in] len      the length of space to program, which is dword aligend
 * @param[in] to       the number of ticks before the operation timeouts
 *
 * @api
 */
int sfWrite(SFDriver *sfp, uint32_t offset, void *wrbuf, size_t len, systime_t to) {
  int res;

  if(sfp == NULL) {
    return SF_RES_ERROR_NULLPTR;
  }

  osalSysLock();
  
  sfp->timeout = to;
  res = sf_lld_write(sfp, offset, wrbuf, len);
  osalSysUnlock();

  return res;
}

uint32_t sfReadStatus(SFDriver *sfp, systime_t to) {

  uint32_t status;
  
  if(sfp == NULL) {
    return SF_RES_ERROR_NULLPTR;
  }

  osalSysLock();
  sfp->timeout = to;
  status = sf_read_status(sfp);
  osalSysUnlock();
  
  return status;
}

int sfQuadEn(SFDriver *sfp, sfqe_t qe, systime_t to) {
  
  if(sfp == NULL) {
    return SF_RES_ERROR_NULLPTR;
  }

  osalSysLock();
  if(sfp->state != SF_FOUND) {
    osalSysUnlock();
    return SF_RES_ERROR_STATE;
  }

  sfp->timeout = to;
  sf_lld_QuadEn(sfp, qe);
  osalSysUnlock();
  
  return HAL_SUCCESS;
}

#if SF_USE_MUTUAL_EXCLUSION || defined(__DOXYGEN__)
/**
 * @brief   Gains exclusive access to the SPI flash interface bus.
 * @details This function tries to gain ownership to the SPI bus, if the bus
 *          is already being used then the invoking thread is queued.
 * @pre     In order to use this function the option @p SF_USE_MUTUAL_EXCLUSION
 *          must be enabled.
 *
 * @param[in] sfp      pointer to the @p SFDriver object
 *
 * @api
 */
void sfAcquireBus(SFDriver *sfp) {

  osalDbgCheck(sfp != NULL);

  osalMutexLock(&sfp->mutex);
}

/**
 * @brief   Releases exclusive access to the SPI bus.
 * @pre     In order to use this function the option @p SF_USE_MUTUAL_EXCLUSION
 *          must be enabled.
 *
 * @param[in] sfp      pointer to the @p SFDriver object
 *
 * @api
 */
void sfReleaseBus(SFDriver *sfp) {

  osalDbgCheck(sfp != NULL);

  osalMutexUnlock(&sfp->mutex);
}
#endif /* SF_USE_MUTUAL_EXCLUSION */

#endif /* HAL_USE_SF */

/** @} */
