/*
    ChibiOS/RT - Copyright (C) 2006,2007,2008,2009,2010,
                 2011,2012,2013 Giovanni Di Sirio.
                 Copyright (C) 2018 BRMicro Technologies
                 hongwei.li@BRMicro.com.cn
                 
                 

    This file is part of ChibiOS/RT.

    ChibiOS/RT is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    ChibiOS/RT is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

                                      ---

    A special exception to the GPL can be applied should you wish to distribute
    a combined work that includes ChibiOS/RT, without being obliged to provide
    the source code for any proprietary components. See the file exception.txt
    for full details of how and when the exception can be applied.
*/

/**
 * @file    audio.c
 * @brief   audio system Driver code.
 *
 * @addtogroup audio
 * @{
 */

#include <string.h>
#include "hal.h"
#include "chprintf.h"
#if defined(hscAudiophile)
#include "hs_config.h"
#endif

#if HAL_USE_AUDIO || defined(__DOXYGEN__)

#define HS_AUDIO_USE_HW_REPAIR     1

#if 1//HS_USE_BGBT
#define AUDIO_DMA_LOCK();          do { NVIC_DisableIRQ(DMAC_IRQn);
#define AUDIO_DMA_UNLOCK();        NVIC_EnableIRQ(DMAC_IRQn); } while (0)
#else
#define AUDIO_DMA_LOCK();          do { syssts_t __sts = osalSysGetStatusAndLockX();
#define AUDIO_DMA_UNLOCK();        osalSysRestoreStatusX(__sts); } while(0)
#endif

/*===========================================================================*/
/* Driver local definitions.                                                 */
/*===========================================================================*/

/* sw resource */
#define HS_PLAY_BUF_SIZE   (1024 * 6)
#define HS_RECORD_BUF_SIZE (1024)

/* hw resource */
#define HS_AUDIO_DMA_PERIOD_LEN   (256)
#define HS_AUDIO_DMA_PERIOD_NUM   (4)
#define HS_AUDIO_DMA_BUFFER_SIZE  (HS_AUDIO_DMA_PERIOD_LEN * HS_AUDIO_DMA_PERIOD_NUM)

/* repair algorithm */
#define REPAIR_POINT_NUM          64
#define AUDIO_INTERPOLATION(this, i, prev)                  \
  (((this) * (REPAIR_POINT_NUM - ((i) + 1)) + (prev) * ((i) + 1)) / REPAIR_POINT_NUM)

static hs_audio_t m_audio_info;
static bool bPlayBufferReady = false;

static uint8_t m_audio_dma_buf[HS_AUDIO_DMA_BUFFER_SIZE * 2] __DMA_DATA__;

/*===========================================================================*/
/* Driver exported variables.                                                */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local variables and types.                                         */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local functions.                                                   */
/*===========================================================================*/
#define __audio_wait_for_interrupt(stmp)              \
do                                                    \
{                                                     \
  osalSysLock();                                        \
  stmp->thread = chThdGetSelfX();                     \
  chSchGoSleepS(CH_STATE_SUSPENDED);                  \
  osalSysUnlock();                                      \
} while(0)
  //chSchDoYieldS();

static void _audio_wakeup_in_isr(hs_audio_stream_t *stmp)
{
  if (stmp->thread) {
    thread_t *tp = stmp->thread;
    stmp->thread = NULL;
    tp->p_u.rdymsg = MSG_OK;
    chSchReadyI(tp);
  }
}

static void _audio_wakeup_in_vt(void *arg)
{
  hs_audio_stream_t *stmp = (hs_audio_stream_t *)arg;

  if (stmp->thread) {
    thread_t *tp = stmp->thread;
    stmp->thread = NULL;
    tp->p_u.rdymsg = MSG_TIMEOUT;
    osalSysLockFromISR();
    chSchReadyI(tp);
    osalSysUnlockFromISR();
  }
}

#if !AUDIO_USE_MIXER

#define hs_mixer_init(vol, tab1, size1, tab2, size2, tab3, size3)
#define hs_mixer_setup(rate, channels)
#define hs_mixer_is_busy() false
#define hs_mixer_stop()
#define hs_mixer_add(buf, len)
#define hs_mixer_start(samples)

#else

void hs_mixer_init(int16_t vol,
                   const int16_t *tab32k, uint16_t siz32k,
                   const int16_t *tab44k, uint16_t siz44k,
                   const int16_t *tab48k, uint16_t siz48k);
void hs_mixer_setup(uint32_t rate, uint8_t channels);
uint16_t hs_mixer_is_busy(void);
void hs_mixer_stop(void);
uint32_t hs_mixer_add(int16_t *buf, uint32_t len);
void hs_mixer_start(uint16_t samples);

#endif /* AUDIO_USE_MIXER */

static void _audio_setup_dmacfg(hs_audio_stream_t *stmp, hs_dma_config_t *dmaCfg, hs_audio_config_t *cfgp, hs_audio_dir_t dir)
{
  if (24 == cfgp->sample_bits) {
    dmaCfg->src_addr_width = DMA_SLAVE_BUSWIDTH_32BITS;
    dmaCfg->dst_addr_width = DMA_SLAVE_BUSWIDTH_32BITS;
  }
  else {
    dmaCfg->src_addr_width = DMA_SLAVE_BUSWIDTH_16BITS;
    dmaCfg->dst_addr_width = DMA_SLAVE_BUSWIDTH_16BITS;
  }

  dmaCfg->src_burst = DMA_BURST_LEN_1UNITS;
  dmaCfg->dst_burst = DMA_BURST_LEN_1UNITS;
  dmaCfg->dev_flow_ctrl = FALSE;

  dmaCfg->lli_en = 1;
  dmaCfg->lli_loop_en = TRUE;

  if (AUDIO_STREAM_PLAYBACK == dir) {
    dmaCfg->lli_src_addr = stmp->dma_buffer;
    dmaCfg->lli_dst_addr = (uint32_t)&HS_I2S_TX->TXDMA;
    dmaCfg->slave_id = I2S_TX_DMA_ID;
    dmaCfg->direction = DMA_MEM_TO_DEV;
  }
  else {
    dmaCfg->lli_src_addr = (uint32_t)&HS_I2S_RX->RXDMA;
    dmaCfg->lli_dst_addr = stmp->dma_buffer;
    dmaCfg->slave_id = I2S_RX_DMA_ID;
    dmaCfg->direction = DMA_DEV_TO_MEM;
  }
  dmaCfg->lli_block_num = stmp->period_num;
  dmaCfg->lli_block_len = stmp->period_len;

  /* initial dma address */
  stmp->dma_pending = stmp->dma_buffer;
}

static void _audio_play_isr(void *arg, hs_dma_cb_para_t *var)
{
  hs_audio_stream_t *stmp = (hs_audio_stream_t *)arg;
  uint8_t *dma_buf1, *dma_buf2;
  uint32_t dma_len1, dma_len2, tlen;

  stmp->performance.int_cnt++;
  if (DMA_TRANS_OPER_OK != var->oper_res) {
    stmp->performance.int_err_cnt++;
    return;
  }

  if (var->curr_src_addr > stmp->dma_pending) {
    dma_buf1 = (uint8_t *)stmp->dma_pending;
    dma_len1 = var->curr_src_addr - stmp->dma_pending;
    tlen = dma_len1 & ~(stmp->period_len - 1);
    stmp->dma_pending = var->curr_src_addr - (dma_len1 - tlen);
    dma_len1 = tlen;

    dma_len2 = 0;
  }
  else {
    dma_buf1 = (uint8_t *)stmp->dma_pending;
    dma_len1 = stmp->dma_buffer_end - stmp->dma_pending;

    dma_buf2 = (uint8_t *)stmp->dma_buffer;
    dma_len2 = var->curr_src_addr - stmp->dma_buffer;
    tlen = dma_len2 & ~(stmp->period_len - 1);
    stmp->dma_pending = var->curr_src_addr - (dma_len2 - tlen);
    dma_len2 = tlen;
  }
  //HS_UART1->THR='0'+(dma_len1 / stmp->period_len);
  //HS_UART1->THR='0'+(dma_len2 / stmp->period_len);

  if (!bPlayBufferReady) {
    if (ringbuffer_data_len(&stmp->rb) < stmp->ring_buffer_size/2) {
      /* play silence data if start threshold is not enough */
      memset(dma_buf1, 0x00, dma_len1);
      if (dma_len2) {
        memset(dma_buf2, 0x00, dma_len2);
      }
      hs_mixer_add((int16_t *)dma_buf1, dma_len1);
      return;
    }
    bPlayBufferReady = true;
  }

  tlen = ringbuffer_get(&stmp->rb, dma_buf1, dma_len1);
  if (tlen != dma_len1) {
    /* don't make underflow longer */
    //bPlayBufferReady = false;
    /* play silence data if underflow */
    memset(dma_buf1+tlen, 0x00, dma_len1-tlen);
    if (dma_len2) {
      memset(dma_buf2, 0x00, dma_len2);
    }
    stmp->performance.flow_cnt++;
    _audio_wakeup_in_isr(stmp);
    return;
  }
  hs_mixer_add((int16_t *)dma_buf1, dma_len1);

  if (dma_len2) {
    tlen = ringbuffer_get(&stmp->rb, dma_buf2, dma_len2);
    if (tlen != dma_len2) {
      //bPlayBufferReady = false;
      /* play silence data if underflow */
      memset(dma_buf2+tlen, 0x00, dma_len2-tlen);
      stmp->performance.flow_cnt++;
      _audio_wakeup_in_isr(stmp);
      return;
    }
  }

  if (ringbuffer_space_len(&stmp->rb) >= stmp->period_len) {
    _audio_wakeup_in_isr(stmp);
  }
}

static void _audio_record_isr(void *arg, hs_dma_cb_para_t *var)
{
  hs_audio_stream_t *stmp = (hs_audio_stream_t *)arg;
  uint8_t *dma_buf1, *dma_buf2;
  int dma_len1, dma_len2, tlen;

  stmp->performance.int_cnt++;
  if (DMA_TRANS_OPER_OK != var->oper_res) {
    stmp->performance.int_err_cnt++;
    return;
  }

  if (var->curr_dst_addr > stmp->dma_pending) {
    dma_buf1 = (uint8_t *)stmp->dma_pending;
    /* FIXME: check alignement to period_len */
    dma_len1 = var->curr_dst_addr - stmp->dma_pending;
    dma_len2 = 0;
    stmp->dma_pending = var->curr_dst_addr;
  }
  else {
    dma_buf1 = (uint8_t *)stmp->dma_buffer;
    /* FIXME: check alignement to period_len */
    dma_len1 = stmp->dma_buffer_end - stmp->dma_pending;
    dma_buf2 = (uint8_t *)var->curr_dst_addr;
    dma_len2 = var->curr_dst_addr - stmp->dma_buffer;
    stmp->dma_pending = var->curr_dst_addr;
  }

  tlen = ringbuffer_put(&stmp->rb, dma_buf1, dma_len1);
  if (tlen != dma_len1) {
    stmp->performance.flow_cnt++;
    _audio_wakeup_in_isr(stmp);
    return;
  }

  if (dma_len2) {
    tlen = ringbuffer_put(&stmp->rb, dma_buf2, dma_len2);
    if (tlen != dma_len2) {
      stmp->performance.flow_cnt++;
      _audio_wakeup_in_isr(stmp);
      return;
    }
  }

  _audio_wakeup_in_isr(stmp);
}

void _audio_play_repair(int16_t *samples, int8_t type)
{
  int32_t temp;
  int16_t i,j;

  if (type > 0) {
    int16_t prev_l = samples[0];
    int16_t prev_r = samples[1];
    samples -= 2;
    samples[0] = prev_l;
    samples[1] = prev_r;
    for (i=1; i<REPAIR_POINT_NUM; i++) {
      j = 2 * i;
      temp = samples[j];
      samples[j] = AUDIO_INTERPOLATION(temp, i, prev_l);
      prev_l = temp;

      j += 1;
      temp = samples[j];
      samples[j] = AUDIO_INTERPOLATION(temp, i, prev_r);
      prev_r = temp;
    }
    samples[REPAIR_POINT_NUM*2] = prev_l;
    samples[REPAIR_POINT_NUM*2 + 1] = prev_r;
  }
  else {
    for (i=0; i<REPAIR_POINT_NUM-1; i++) {
      j = 2 * i;
      temp = samples[j];
      samples[j] = AUDIO_INTERPOLATION(temp, i, samples[j+2]);

      j += 1;
      temp = samples[j];
      samples[j] = AUDIO_INTERPOLATION(temp, i, samples[j+2]);
    }
  }
}

/*===========================================================================*/
/* Driver exported functions.                                                */
/*===========================================================================*/
void audioPlayMixerStart(uint16_t samples)
{
#if !AUDIO_USE_MIXER
  (void)samples;
#else
  if (AUDIO_STOP == m_audio_info.ply.state) {
    return;
  }
  hs_mixer_start(samples);
#endif
}

/**
 * @brief   audio Driver initialization.
 * @note    This function is implicitly invoked by @p halInit(), there is
 *          no need to explicitly initialize the driver.
 *
 * @init
 */
void audioInit(void)
{
  i2s_lld_init();
  codec_lld_init();

  m_audio_info.pcodec = &CODECD;
  m_audio_info.pi2s = &I2SD;

  m_audio_info.rec.state = AUDIO_INIT;
  m_audio_info.ply.state = AUDIO_INIT;
}

/**
 * @brief   Configures and activates the audio system.
 *
 * @api
 */
void audioStart(void)
{
  if (m_audio_info.rec.state != AUDIO_INIT) return;
  if (m_audio_info.ply.state != AUDIO_INIT) return;

  m_audio_info.rec.state = AUDIO_IDLE;
  m_audio_info.ply.state = AUDIO_IDLE;

  /* sw resource */
  m_audio_info.ply.ring_buffer_size = HS_PLAY_BUF_SIZE;
  m_audio_info.rec.ring_buffer_size = HS_RECORD_BUF_SIZE;
  m_audio_info.ply.ring_buffer = osalHeapAlloc(NULL, m_audio_info.ply.ring_buffer_size);
  m_audio_info.rec.ring_buffer = osalHeapAlloc(NULL, m_audio_info.rec.ring_buffer_size);
  if ((NULL == m_audio_info.ply.ring_buffer) ||
      (NULL == m_audio_info.rec.ring_buffer)) {
    if (m_audio_info.rec.ring_buffer) {
      osalHeapFree(m_audio_info.rec.ring_buffer);
    }
    if (m_audio_info.ply.ring_buffer) {
      osalHeapFree(m_audio_info.ply.ring_buffer);
    }
    return;
  }

  /* hw resource */
  m_audio_info.ply.dma_buffer = (uint32_t)m_audio_dma_buf;
  m_audio_info.ply.period_num = HS_AUDIO_DMA_PERIOD_NUM;
  m_audio_info.ply.period_len = HS_AUDIO_DMA_PERIOD_LEN;
  m_audio_info.ply.dma_buffer_end = m_audio_info.ply.dma_buffer + HS_AUDIO_DMA_BUFFER_SIZE;
  m_audio_info.rec.dma_buffer = m_audio_info.ply.dma_buffer_end;
  m_audio_info.rec.period_num = HS_AUDIO_DMA_PERIOD_NUM;
  m_audio_info.rec.period_len = HS_AUDIO_DMA_PERIOD_LEN;
  m_audio_info.rec.dma_buffer_end = m_audio_info.rec.dma_buffer + HS_AUDIO_DMA_BUFFER_SIZE;

  ringbuffer_init(&m_audio_info.ply.rb, m_audio_info.ply.ring_buffer,
                  m_audio_info.ply.ring_buffer_size);
  ringbuffer_init(&m_audio_info.rec.rb, m_audio_info.rec.ring_buffer,
                  m_audio_info.rec.ring_buffer_size);

  i2s_lld_start(m_audio_info.pi2s);
  codec_lld_start(m_audio_info.pcodec);
}

/**
 * @brief Deactivates the audio.
 *
 * @api
 */
void audioStop(void)
{
  i2s_lld_stop(m_audio_info.pi2s);
  codec_lld_stop(m_audio_info.pcodec);

  if (m_audio_info.rec.ring_buffer) {
    osalHeapFree(m_audio_info.rec.ring_buffer);
  }
  if (m_audio_info.ply.ring_buffer) {
    osalHeapFree(m_audio_info.ply.ring_buffer);
  }

  m_audio_info.rec.state = AUDIO_INIT;
  m_audio_info.ply.state = AUDIO_INIT;
}

int audioPlayStart(hs_audio_config_t *cfgp)
{
  hs_dma_config_t dmaCfg;
  hs_audio_stream_t *stmp = &m_audio_info.ply;

  //printf("%s: state=%d\n", __FUNCTION__, stmp->state);
  if ((NULL == cfgp) ||
      (cfgp->sample_channels > 2) ||
      (cfgp->sample_bits > 32) ||
      (cfgp->sample_rate > 96000)) {
    return ERRNO_AUDIO_PAR_ERR;
  }

  while (hs_mixer_is_busy()) {
    osalThreadSleepMilliseconds(1);
  }

  if (AUDIO_START == stmp->state) {
    /* don't save the previous audio settings yet */
    return ERRNO_AUDIO_TRY_AGAIN;
  }
  /* allow to inherit the previous audio settings if NULL */
  if (NULL == cfgp) {
    cfgp = &m_audio_info.pcodec->cfg_ply;
  }

  if (NULL == stmp->dma) {
    stmp->dma = dmaStreamAllocate(HS_I2S_DMA_PRIORITY, (hs_dmaisr_t)_audio_play_isr, (void *)stmp);
  }
  if (NULL == stmp->dma) {
    return ERRNO_AUDIO_NO_DMA;
  }
  _audio_setup_dmacfg(stmp, &dmaCfg, cfgp, AUDIO_STREAM_PLAYBACK);
  dmaStreamSetMode(stmp->dma, &dmaCfg);

  /* sample bits is 16-bit always */
  hs_mixer_setup(cfgp->sample_rate, cfgp->sample_channels);

#if HS_AUDIO_USE_STATISTIC
  memset(&stmp->performance, 0x00, sizeof(hs_audio_debug_t));
#endif
  bPlayBufferReady = false;

  codec_lld_play_start(m_audio_info.pcodec, cfgp);
  i2s_lld_play_start(m_audio_info.pi2s, cfgp);
  dmaStreamStartByLli(stmp->dma);

  stmp->state = AUDIO_START;
  return 0;
}

void audioPlayStop(void)
{
  hs_audio_stream_t *stmp = &m_audio_info.ply;

  /* allow to call stop w/o start */
  if (AUDIO_IDLE == stmp->state) {
    return;
  }

  //printf("%s: state=%d\n", __FUNCTION__, stmp->state);
  /* in case of play buffer in half-full always */
  bPlayBufferReady = true;
  /* wait the pending data in ring buffer become empty */
  while (ringbuffer_data_len(&stmp->rb)) {
    __audio_wait_for_interrupt(stmp);
  }

  codec_lld_play_stop(m_audio_info.pcodec);
  i2s_lld_play_stop(m_audio_info.pi2s);
  dmaStreamDisable(stmp->dma);

  stmp->state = AUDIO_STOP;
  stmp->repair = 0;

  hs_mixer_stop();

  if (stmp->performance.flow_cnt > 1) {
    #if defined(hscAudiophile)
    if (g_hs_cfg && !(g_hs_cfg->debug.bitmap & CFG_DEBUG_AUDIO_PLAY)) return;
    #endif
    audio_stc("\n[ply]write count: %lu"
      "\n[ply]sleep count: %lu"
      "\n[ply]underflow count: %lu"
      "\n[ply]error count: %lu"
      "\n[ply]interrupt count: %lu"
      "\n[ply]repair count: %u %u\n",
      stmp->performance.rw_cnt,
      stmp->performance.sleep_cnt,
      stmp->performance.flow_cnt,
      stmp->performance.int_err_cnt,
      stmp->performance.int_cnt,
      stmp->performance.repair_inc_cnt,
      stmp->performance.repair_dec_cnt);
  }
}

uint32_t audioPlayWrite(uint8_t *pData, uint32_t size)
{
  hs_audio_stream_t *stmp = &m_audio_info.ply;
  uint32_t tlen, ret = size;
  int8_t repair = 0;

  //printf("%s: size=%lu\n", __FUNCTION__, size);
  stmp->performance.rw_cnt++;

  /* access stmp->repair atomically */
  if (stmp->repair && (size == 512)) {
    repair = stmp->repair;
  }
  #if !HS_AUDIO_USE_HW_REPAIR
  if (repair) {
    size -= 4*REPAIR_POINT_NUM;
  }
  #endif

  /* submit all the data into ring buffer */
  while (1) {
    /* access the play's ring buffer atomically */
    AUDIO_DMA_LOCK();
    tlen = ringbuffer_put(&stmp->rb, pData, size > 0xffff ? 0xffff : size);
    AUDIO_DMA_UNLOCK();
    pData += tlen;
    size -= tlen;
    if (0 == size) break;
    stmp->performance.sleep_cnt++;
    __audio_wait_for_interrupt(stmp);
  }
  ret -= size;

  #if HS_AUDIO_USE_HW_REPAIR
  if (repair) {
    uint32_t cfg = HS_PSO->CODEC_CFG;
    cfg = (cfg & ~(0xffff << 16)) | (1024 << 16);
    cfg |= (1 << 9) | ((repair>0 ? 0:1) << 8);
    HS_PSO->CODEC_CFG = cfg;
    if (repair > 0)
      stmp->performance.repair_inc_cnt++;
    else
      stmp->performance.repair_dec_cnt++;
  }
  else {
    HS_PSO->CODEC_CFG &= ~(1<<9);
  }
  #else
  /* trick: ~1% adjust for SBC streaming data */
  if (repair) {
    _audio_play_repair((int16_t *)pData, repair);
    if (repair > 0) {
      pData -= 4;
      size = 4 * (REPAIR_POINT_NUM+1);
      stmp->performance.repair_inc_cnt++;
    }
    else {
      size = 4 * (REPAIR_POINT_NUM-1);
      stmp->performance.repair_dec_cnt++;
    }
    while (1) {
      /* access the play's ring buffer atomically */
      AUDIO_DMA_LOCK();
      tlen = ringbuffer_put(&stmp->rb, pData, size);
      AUDIO_DMA_UNLOCK();
      pData += tlen;
      size -= tlen;
      if (0 == size) break;
      stmp->performance.sleep_cnt++;
      __audio_wait_for_interrupt(stmp);
    }
    ret -= size;
  }
  #endif

  return ret;
}

void audioPlayRepair(int8_t req)
{
  m_audio_info.ply.repair = req;
}

hs_audio_errno_t audioPlayGetConfig(hs_audio_config_t *cfgp)
{
  hs_audio_stream_t *stmp = &m_audio_info.ply;

  if (NULL == cfgp) {
    return ERRNO_AUDIO_PAR_ERR;
  }

  if (AUDIO_START == stmp->state) {
    memcpy(cfgp, &m_audio_info.pcodec->cfg_ply, sizeof(hs_audio_config_t));
    return 0;
  }
  /* ircorrect play state */
  return ERRNO_AUDIO_TRY_AGAIN;
}

hs_audio_errno_t audioRecordStart(hs_audio_config_t *cfgp)
{
  hs_dma_config_t dmaCfg;
  hs_audio_stream_t *stmp = &m_audio_info.rec;

  /* allow to inherit the previous audio settings if NULL */
  if (NULL == cfgp) {
    cfgp = &m_audio_info.pcodec->cfg_rec;
  }

  if (NULL == stmp->dma) {
    stmp->dma = dmaStreamAllocate(HS_I2S_DMA_PRIORITY, (hs_dmaisr_t)_audio_record_isr, (void *)stmp);
  }
  if (NULL == stmp->dma) {
    return ERRNO_AUDIO_NO_DMA;
  }
  _audio_setup_dmacfg(stmp, &dmaCfg, cfgp, AUDIO_STREAM_RECORD);
  dmaStreamSetMode(stmp->dma, &dmaCfg);

#if HS_AUDIO_USE_STATISTIC
  memset(&stmp->performance, 0x00, sizeof(hs_audio_debug_t));
#endif

  codec_lld_record_start(m_audio_info.pcodec, cfgp);
  i2s_lld_record_start(m_audio_info.pi2s, cfgp);
  dmaStreamStartByLli(stmp->dma);

  stmp->state = AUDIO_START;
  return 0;
}

void audioRecordStop(void)
{
  hs_audio_stream_t *stmp = &m_audio_info.rec;

  /* allow to call stop w/o start */
  if (AUDIO_IDLE == stmp->state) {
    return;
  }

  dmaStreamDisable(stmp->dma);
  i2s_lld_record_stop(m_audio_info.pi2s);
  codec_lld_record_stop(m_audio_info.pcodec);

  /* resetting the ring buffer if not empty */
  if (RINGBUFFER_HALFFULL == ringbuffer_status(&stmp->rb)) {
    ringbuffer_init(&m_audio_info.rec.rb, m_audio_info.rec.ring_buffer,
                    m_audio_info.rec.ring_buffer_size);
  }

  stmp->state = AUDIO_STOP;

  #if defined(hscAudiophile)
  if (g_hs_cfg && !(g_hs_cfg->debug.bitmap & CFG_DEBUG_AUDIO_RECORD)) return;
  #endif
  audio_stc("\n[rec]read count: %lu"
            "\n[rec]sleep count: %lu"
            "\n[rec]overflow count: %lu"
            "\n[rec]error count: %lu"
            "\n[rec]interrupt count: %lu\n",
            stmp->performance.rw_cnt,
            stmp->performance.sleep_cnt,
            stmp->performance.flow_cnt,
            stmp->performance.int_err_cnt,
            stmp->performance.int_cnt);
}

uint32_t audioRecordRead(uint8_t *pData, uint32_t size)
{
  hs_audio_stream_t *stmp = &m_audio_info.rec;
  uint32_t tlen, ret = size;
  virtual_timer_t vt;
  systime_t timeout = OSAL_MS2ST(size / 8/*sample_rate*/ + 1);

  stmp->performance.rw_cnt++;

  /* timeout is required for record */
  chVTObjectInit(&vt);
  chVTSet(&vt, timeout, _audio_wakeup_in_vt, (void *)stmp);

  while (1) {
    AUDIO_DMA_LOCK();
    tlen = ringbuffer_get(&stmp->rb, pData, size);
    AUDIO_DMA_UNLOCK();
    size -= tlen;
    if (0 == size) break;
    pData += tlen;
    stmp->performance.sleep_cnt++;
    __audio_wait_for_interrupt(stmp);
    if (MSG_TIMEOUT == stmp->thread->p_u.rdymsg) {
      break;
    }
  }

  if (chVTIsArmed(&vt)) {
    chVTReset(&vt);
  }
  ret -= size;
  return ret;
}

uint32_t audioRecordPlay(uint8_t *pData, uint32_t size)
{
  hs_audio_stream_t *rec = &m_audio_info.rec;
  hs_audio_stream_t *ply = &m_audio_info.ply;
  uint32_t tlen, ret = size;
  virtual_timer_t vt;
  systime_t timeout = MS2ST(size / 8/*sample_rate*/ + 1);

  rec->performance.rw_cnt++;

  /* timeout is required for record */
  chVTObjectInit(&vt);
  chVTSet(&vt, timeout, _audio_wakeup_in_vt, (void *)rec);

  while (1) {
    tlen = ringbuffer_get(&rec->rb, pData, size);
    if (tlen > 0) {
      ringbuffer_put(&ply->rb, pData, tlen);
    }
    size -= tlen;
    if (0 == size) break;
    pData += tlen;
    rec->performance.sleep_cnt++;
    __audio_wait_for_interrupt(rec);
    if (MSG_TIMEOUT == rec->thread->p_u.rdymsg) {
      break;
    }
  }

  if (chVTIsArmed(&vt)) {
    chVTReset(&vt);
  }
  ret -= size;
  return ret;
}

void audioRecordSetVolume(int ddb_left, int ddb_right)
{
  codec_lld_record_set_volume(m_audio_info.pcodec, ddb_left, ddb_right);
}

void audioRecordGetVolume(int *ddb_left, int *ddb_right)
{
  codec_lld_record_get_volume(m_audio_info.pcodec, ddb_left, ddb_right);
}

void audioRecordMute(bool bMute)
{
  codec_lld_record_mute(m_audio_info.pcodec, bMute);
}

void audioPlaySetVolume(int ddb_left, int ddb_right)
{
  codec_lld_play_set_volume(m_audio_info.pcodec, ddb_left, ddb_right);
}

void audioPlayGetVolume(int *ddb_left, int *ddb_right)
{
  codec_lld_play_get_volume(m_audio_info.pcodec, ddb_left, ddb_right);
}

void audioPlayMute(bool bMute)
{
  codec_lld_play_mute(m_audio_info.pcodec, bMute);
}

#endif /* HAL_USE_AUDIO */

/** @} */
