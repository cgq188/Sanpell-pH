//------------------------------------------------------------------------------------
// hal_rf.c
//------------------------------------------------------------------------------------
// Copyright 2015, BRMICRO
// 
// 2015-03-20
//
// Program Description: MAC6200 RF test program
//
//
//

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "hal.h"

#if (HAL_USE_RF == TRUE) || defined(__DOXYGEN__)

/**
 * @param en     Enable of TX guard and whitening.
 */
void rf62_setup_guard(bool en)
{
  uint8_t cal_ctl[5];
  uint8_t config;

  // TX guard //BR3215 & BR3234
  MAC6200_Read_Reg(MAC6200_BANK0_CONFIG, &config, 1);
  if (en)
    config |= 0x80;
  else
    config &= ~0x80;
  MAC6200_Write_Reg(MAC6200_BANK0_CONFIG, &config, 1);

  MAC6200_Bank1_Activate();
  MAC6200_Read_Reg(MAC6200_BANK1_CAL_CTL, cal_ctl, 5);
  if (en)
    cal_ctl[2] |= (1u << 4);  //scramble_en
  else
    cal_ctl[2] &= ~(1u << 4);  //��nrf2401ͨѶ����Ҫȥ�׻�
  MAC6200_Write_Reg(MAC6200_BANK1_CAL_CTL, cal_ctl, 5);
  MAC6200_Bank0_Activate();
}

void rf62_setup_rate(int rate)
{
  uint8_t regval, rate_flag = 0x00;

  switch (rate)
  {
  	  case 2000*1000:
  		  HS_BTPHY->H_IDX=0;    // 2Mbps h_idx = 0.32
  		  regval = 0x10;
  		  rate_flag = 0x08;
  		  break;
  	  case 1000*1000:
  		  HS_BTPHY->H_IDX=0;    // 1Mbps h_idx = 0.32
  		  regval = 0x10;
  		  rate_flag = 0x00;
  		  break;
  	  case 500*1000:
  		  HS_BTPHY->H_IDX=1;    // 500Kbps h_idx = 0.5
  		  regval = 0x10;
  		  rate_flag = (0x20+0x08);
  		  break;
  	  case 250*1000:
  		  HS_BTPHY->H_IDX=2;   // 250kbps = 0.75
  		  regval = 0x20;
  		  rate_flag = 0x20;
  		  break;
  	  default:
  		  HS_BTPHY->H_IDX=0;    // 1Mbps h_idx = 0.32
  		  regval = 0x10;
  		  rate_flag = 0x00;
  		  break;
  }

  #if !defined(BR3215)
  MAC6200_Write_Reg(MAC6200_BANK0_RX_TIMOUT_H, &regval, 1);
  #endif
  MAC6200_Read_Reg(MAC6200_BANK0_RF_SETUP, &regval, 1);
  regval &= ~((1u << 5) | (1u << 3)); //RF_DR_LOW,RF_DR_HIGH
  regval |= rate_flag;
  MAC6200_Write_Reg(MAC6200_BANK0_RF_SETUP, &regval, 1);
}

void rf62_setup_code(uint8_t code)
{
  uint8_t fagc_ctrl[4];

  MAC6200_Bank1_Activate();
  MAC6200_Read_Reg(MAC6200_BANK1_FAGC_CTRL, fagc_ctrl, 4);
  fagc_ctrl[0] &= ~((1u << 7) | (1u << 6)); //ch_code
  fagc_ctrl[0] |= code << 6;
  MAC6200_Write_Reg(MAC6200_BANK1_FAGC_CTRL, fagc_ctrl, 4);
  MAC6200_Bank0_Activate();
}

void rf62_setup_crc(uint8_t crc)
{
  uint8_t config;

  MAC6200_Read_Reg(MAC6200_BANK0_CONFIG, &config, 1);
  if (crc == 0) {
    uint8_t en_aa = 0;
    config &= ~MAC6200_CRCO;
    config &= ~MAC6200_EN_CRC;
    /* clear EN_AA before clear CONFIG.EN_CRC */
    MAC6200_Write_Reg(MAC6200_BANK0_EN_AA, &en_aa, 1);
  }
  else {
    config &= ~MAC6200_CRCO;
    config |= MAC6200_EN_CRC;
    if (crc == 1)
      config |= MAC6200_CRCO_1_BYTES;
    else if (crc == 2)
      config |= MAC6200_CRCO_2_BYTES;
  }
  MAC6200_Write_Reg(MAC6200_BANK0_CONFIG, &config, 1);
}

void rf62_setup_txgain(uint8_t lvl)
{
#if defined(BR32xx_FPGA)
  uint8_t rf_setup;

  MAC6200_Read_Reg(MAC6200_BANK0_RF_SETUP, &rf_setup, 1);
  rf_setup &= ~((1u << 6) | (7u << 0)); //PA_PWR[3:0]
  rf_setup |= lvl & 0x8 ? (1u << 6) : 0;
  rf_setup |= lvl & 0x7;
  MAC6200_Write_Reg(MAC6200_BANK0_RF_SETUP, &rf_setup, 1);
#else
  HS_ANA->REGS.GSEL_PA = lvl & 0x03; //BR3215 only
#endif
}

void rf62_setup_freq(int freq)
{
  (void)freq;

#if defined(BR32xx_FPGA)
  uint8_t reg_val;
  reg_val = mhz - 2400;
  MAC6200_Write_Reg(MAC6200_BANK0_RF_CH, &reg_val, 1);    //channel
#else
  HS_BTPHY->SPI_APB_SWITCH=0;

  /* workaround: [8]bt_synth_con_mmd_mn=1 [7:0]bt_synth_con_mmd=0x00 to turn off mmd during BT's RXENA is high, before change the new frequency */
  //__hal_set_bitsval(HS_ANA->SDM_CFG, 0, 8, 0x100);
  osalThreadSleepMilliseconds(1);

  HS_BTPHY->ANALOGUE[0x44] = freq; //frequency: 2392 ~ 2490 MHz
  HS_BTPHY->ANALOGUE[0x44] = freq+(1<<12); //[12]: w1 trigger?

  /* this step is not required if BT TRX? */
  HS_ANA->VCO_AFC_CFG[0] |= (1<<16); //[16]rf_pll_afc_tlu
  HS_ANA->VTRACK_CFG = 0x14;

  /* workaround: [8]bt_synth_con_mmd_mn=1 to turn on mmd, FM PLL will become lock */
  //__hal_set_bitsval(HS_ANA->SDM_CFG, 0, 8, 0x000);

  HS_BTPHY->SPI_APB_SWITCH=1;
#endif
}

void rf62_power_up(bool rx_en)
{
  uint8_t config;

  MAC6200_Read_Reg(MAC6200_BANK0_CONFIG, &config, 1);
  config |= MAC6200_PWR_UP;
  if (rx_en)
    config |= MAC6200_PRIM_RX;
  else
    config &= ~MAC6200_PRIM_RX;
  MAC6200_Write_Reg(MAC6200_BANK0_CONFIG, &config, 1);
}

void rf62_power_down(void)
{
  uint8_t config;

  MAC6200_Read_Reg(MAC6200_BANK0_CONFIG, &config, 1);
  config &= ~MAC6200_PWR_UP;
  MAC6200_Write_Reg(MAC6200_BANK0_CONFIG, &config, 1);
}

static void rf62_init(uint8_t *rx_addr, int rx_addr_len, bool scramble_en)
{
    uint8_t reg_value = 0x00;
    uint8_t temp[5];

    HS_MAC6200->SPIRCON |= RF_MAC_SELECT;  //RF PHY Select MAC6200
    HS_MAC6200->SPIRCON |= (RF_IRQ_RXFIFO_FULL + RF_IRQ_RXDATA_READY
            + RF_IRQ_TxFIFO_EMPTY + RF_IRQ_TXFIFO_READY);  //disable all spi interrupt

#if 0
    MAC6200_Calibration();
    MAC6200_Analog_Init();
#endif

    reg_value = 0x3f;
    MAC6200_Write_Reg(MAC6200_BANK0_EN_RXADDR, &reg_value, 1);  //enable all RX pipe

    reg_value = 0x25;
    MAC6200_Write_Reg(MAC6200_BANK0_SETUP_RETR, &reg_value, 1);  //disable translate auto retry

    reg_value = rx_addr_len-2;
    MAC6200_Write_Reg(MAC6200_BANK0_SETUP_AW, &reg_value, 1);
    MAC6200_Write_Reg(MAC6200_BANK0_RX_ADDR_P0, rx_addr, rx_addr_len);
    MAC6200_Write_Reg(MAC6200_BANK0_TX_ADDR, rx_addr, rx_addr_len);

    MAC6200_Flush_Rx_Fifo();
    MAC6200_Flush_Tx_Fifo();

    reg_value = 0x70;
    MAC6200_Write_Reg(MAC6200_BANK0_STATUS, &reg_value, 1);

    temp[0] = 0x3c;//+10*24/16; //RX_SETUP_VALUE: the setup time of standby to rx in 16/24us
    temp[1] = 0x4b; //TX_SETUP_VALUE: the setup time of standby to tx in 16/24us
    temp[2] = 0xff; //RX_TM_CNT:      rx timeout counter              in 16/24us
    temp[3] = 0x10; //REG_MBG_WAIT:   main band gap wait counter      in 16/24us
    temp[4] = 0x01;
    //temp[4] = 0x6f; //REG_LNA_WAIT:   lna wait counter                in cycle @24mhz
    MAC6200_Write_Reg(MAC6200_BANK0_SETUP_VALUE, temp, 5);

    MAC6200_Bank1_Activate();

    temp[0] = 0x20;
    temp[1] = 0x08;
    /**
     * scramble:    | (1u << 7) | (1u << 3) | (1u << 2) | (1u << 1) | (1u << 0);
     * [23]bp_ch_chg=1 [20]scramble_en [19]bp_dc=1 [18]bp_dac=1 [17]bp_afc=1 [16]bp_rc=1
     *
     * no scramble: | (1u << 7) | (1u << 3) | (1u << 2) | (1u << 1) | (1u << 0);
     * [23]bp_ch_chg=1 [20]scramble_en [19]bp_dc=1 [18]bp_dac=1 [17]bp_afc=1 [16]bp_rc=1
     */
    temp[2] = scramble_en ? 0x54 : 0x44;
    temp[3] = 0x2b; //RX_PLL_WAIT: pll lock wait time in rx mode      in cycle @24mhz
    temp[4] = 0x78; //TX_WAIT_CNT: wait cycles between retransmits    in cycle @24mhz
    MAC6200_Write_Reg(MAC6200_BANK1_CAL_CTL, temp, 5);

    #if defined(BR3215)
    temp[0] = 0x0f; //REG_AFC_WAIT: the time between RC done and AFC start          in 16/24us
    temp[1] = 0x28; //TX_PLL_WAIT:  pll lock wait time in tx mode                   in 16/24us
    #endif
    #if defined(BR3215c)
    temp[0] = 0x6e; //REG_AFC_WAIT: the time between RC done and AFC start          in 16/24us
    temp[1] = 0x60; //TX_PLL_WAIT:  pll lock wait time in tx mode                   in 16/24us
    #endif
    temp[2] = 0x6f; //REG_TX_PA_WAIT: the time between power up PA to transmit data in cycle @24mhz
    temp[3] = 0x00;
    MAC6200_Write_Reg(MAC6200_BANK1_PLL_CTL1, temp, 5);

    MAC6200_Bank0_Activate();

    //nvicEnableVector(IRQ_6200_RF, ANDES_PRIORITY_MASK(HS_RF_INTR_PRIORITY));
}

//for test
static void _BR3215_MOD_TX_EN(void)
{
    HS_BTPHY->TX_RX_EN = 0x80;    //rx_en set 0, and bandband(CEVA or MAC6200) controls tx
    HS_MAC6200->SPIRCON = 0;
}
static void _BR3215_MOD_RX_EN(void)
{
    HS_BTPHY->TX_RX_EN = 0x82;    //rx en
    //HS_ANA->MAIN_ST_CFG[1] = (HS_ANA->MAIN_ST_CFG[1] & 0xFFFF0FFF) | 0x3000;    //agc_sync_timeout = 3
    //HS_MAC6200->SPIRCON |= RF_MAC_SELECT;
}

void BR3215_BT_ON(uint8_t tx)
{
  MAC6200_CEVA_RXENA(false);
  MAC6200_CEVA_TXENA(false);
  osalThreadSleepMicroseconds(500);

  if (tx==1) {
    _BR3215_MOD_TX_EN();
    MAC6200_CEVA_TXENA(true);
  }
  else {
	  _BR3215_MOD_RX_EN();
    MAC6200_CEVA_RXENA(true);
  }
}

void rf_2p4G_init(uint8_t *rx_addr, int rx_addr_len, int datarate, int freq_MHz)
{
    uint8_t reg_value;
    MAC6200_PHY_Enable();
    BR3215_mac6200_init();
    rf62_init(rx_addr, rx_addr_len, true);

    rf62_setup_rate(datarate);
    rf62_setup_code(0);
    rf62_setup_freq(freq_MHz);

    reg_value = 0x8e;
    MAC6200_Write_Reg(MAC6200_BANK0_CONFIG, &reg_value, 1);
    reg_value = 0x3f; //ENAA
    MAC6200_Write_Reg(MAC6200_BANK0_EN_AA, &reg_value, 1);
    reg_value = 32; //Payload width 32Byte
    MAC6200_Write_Reg(MAC6200_BANK0_RX_PW_P0, &reg_value, 1);
    reg_value = 0x3f;
    MAC6200_Write_Reg(MAC6200_BANK0_DYNPD, &reg_value, 1);
    reg_value = 0x07;
    MAC6200_Write_Reg(MAC6200_BANK0_FEATURE, &reg_value, 1);
}

#endif
