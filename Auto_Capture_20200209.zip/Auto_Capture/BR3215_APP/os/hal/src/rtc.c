/*
    ChibiOS - Copyright (C) 2006..2015 Giovanni Di Sirio

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/
/*
   Concepts and parts of this file have been contributed by Uladzimir Pylinsky
   aka barthess.
 */

/**
 * @file    rtc.c
 * @brief   RTC Driver code.
 *
 * @addtogroup RTC
 * @{
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "hal.h"

#if (HAL_USE_RTC == TRUE) || defined(__DOXYGEN__)

/*===========================================================================*/
/* Driver local definitions.                                                 */
/*===========================================================================*/
/**
 * @brief   Determine if a year is a leap year.
 * @note    Open source code from: http://rosettacode.org/wiki/Leap_year#C
 *
 * @param year  The year to determine.
 * @return      1: leap year; 0: not leap year.
 */
static int is_leap_year(int year)
{
	return ( ( !(year % 4) && (year % 100) ) || !(year % 400) ) ? 1 : 0;
}
/*===========================================================================*/
/* Driver exported variables.                                                */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local variables and types.                                         */
/*===========================================================================*/

/*
 * Lookup table with months' length
 */
static const uint8_t month_len[12] = {
  31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31
};

static const uint8_t month_len_of_leap_year[12] = {
  31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31
};

/*===========================================================================*/
/* Driver local functions.                                                   */
/*===========================================================================*/

/*===========================================================================*/
/* Driver exported functions.                                                */
/*===========================================================================*/

/**
 * @brief   RTC Driver initialization.
 * @note    This function is implicitly invoked by @p halInit(), there is
 *          no need to explicitly initialize the driver.
 *
 * @init
 */
void rtcInit(void) {

  rtc_lld_init();
}

/**
 * @brief   Initializes a generic RTC driver object.
 * @details The HW dependent part of the initialization has to be performed
 *          outside, usually in the hardware initialization code.
 *
 * @param[out] rtcp     pointer to RTC driver structure
 *
 * @init
 */
void rtcObjectInit(RTCDriver *rtcp) {

  (void)rtcp;

#if RTC_USE_MUTUAL_EXCLUSION
  osalMutexObjectInit(&rtcp->mutex);
#endif

}

/**
 * @brief   Set current time.
 * @note    This function can be called from any context but limitations
 *          could be imposed by the low level implementation. It is
 *          guaranteed that the function can be called from thread
 *          context.
 * @note    The function can be reentrant or not reentrant depending on
 *          the low level implementation.
 *
 * @param[in] rtcp      pointer to RTC driver structure
 * @param[in] timespec  pointer to a @p RTCDateTime structure
 *
 * @special
 */
void rtcSetTime(RTCDriver *rtcp, const RTCDateTime *timespec) {

  osalDbgCheck((rtcp != NULL) && (timespec != NULL));

  rtc_lld_set_time(rtcp, timespec);
}

void rtcSetTimeOfStructTm(RTCDriver *rtcp, const struct tm *timp, uint32_t ms) {

  osalDbgCheck((rtcp != NULL) && (timp != NULL));

  RTCDateTime timespec;
  rtcConvertStructTmToDateTime(timp, ms, &timespec);
  rtc_lld_set_time(rtcp, &timespec);
}

/* @brief   Sets RTC time with Unix time format,
 *          which is the seconds from GMT 1970-01-01 00:00:00.
 *
 * @param[in] rtcp      pointer to RTC driver structure
 * @param[in] tv_sec    Unix time value in seconds.
 *
 * @api
 */
void rtcSetTimeOfUnixTime(RTCDriver *rtcp, time_t tv_sec) {
  struct tm timp;

  localtime_r(&tv_sec, &timp);
  rtcSetTimeOfStructTm(rtcp, &timp, 0);
}

void rtcSetTimeOfString(RTCDriver *rtcp, const char *timestr) {

  osalDbgCheck((rtcp != NULL) && (timestr != NULL));

  RTCDateTime dt;
  rtcConvertStingToDateTime(timestr, &dt);
  rtc_lld_set_time(rtcp, &dt);
}

/**
 * @brief   Get current time.
 * @note    This function can be called from any context but limitations
 *          could be imposed by the low level implementation. It is
 *          guaranteed that the function can be called from thread
 *          context.
 * @note    The function can be reentrant or not reentrant depending on
 *          the low level implementation.
 *
 * @param[in] rtcp      pointer to RTC driver structure
 * @param[out] timespec pointer to a @p RTCDateTime structure
 *
 * @special
 */
void rtcGetTime(RTCDriver *rtcp, RTCDateTime *timespec) {

  osalDbgCheck((rtcp != NULL) && (timespec != NULL));

  rtc_lld_get_time(rtcp, timespec);
}

void rtcGetTimeOfStructTm(RTCDriver *rtcp, struct tm *timp, uint32_t *tv_msec) {

  osalDbgCheck((rtcp != NULL) && (timp != NULL));

  RTCDateTime timespec;
  rtc_lld_get_time(rtcp, &timespec);
  rtcConvertDateTimeToStructTm(&timespec, timp, tv_msec);
}

/**
 * @brief   Gets raw time from RTC and converts it to Unix time,
 * 					which is the seconds from GMT 1970-01-01 00:00:00.
 *
 * @param[in] rtcp      pointer to RTC driver structure
 * @return              Unix time value in seconds.
 *
 * @api
 */
time_t rtcGetTimeOfUnixTime(RTCDriver *rtcp) {
  struct tm timp;

  rtcGetTimeOfStructTm(rtcp, &timp, NULL);
  return mktime(&timp);
}

uint32_t rtcGetTimeOfFAT(RTCDriver *rtcp) {

  osalDbgCheck(rtcp != NULL);

  RTCDateTime timespec;
  rtc_lld_get_time(rtcp, &timespec);
  return rtcConvertDateTimeToFAT(&timespec);
}

/**
 * @brief   Get current time in string format,
 *          e.g. "Fri Nov 17 17:31:03 2017".
 *
 * @param[in]  rtcp      pointer to RTC driver structure
 * @return               pointer to the string of time.
 */
char * rtcGetTimeOfString(RTCDriver *rtcp) {

  osalDbgCheck(rtcp != NULL);

  struct tm tm0;
  rtcGetTimeOfStructTm(rtcp, &tm0, NULL);
  return asctime(&tm0);
}

#if (RTC_ALARMS > 0) || defined(__DOXYGEN__)
/**
 * @brief   Set alarm time.
 * @note    This function can be called from any context but limitations
 *          could be imposed by the low level implementation. It is
 *          guaranteed that the function can be called from thread
 *          context.
 * @note    The function can be reentrant or not reentrant depending on
 *          the low level implementation.
 *
 * @param[in] rtcp      pointer to RTC driver structure
 * @param[in] alarm     alarm identifier: 0=A, 1=B
 * @param[in] alarmspec pointer to a @p RTCAlarm structure or @p NULL
 *
 * @special
 */
void rtcSetAlarm(RTCDriver *rtcp,
                 rtcalarm_t alarm,
                 const RTCAlarm *alarmspec) {

  osalDbgCheck((rtcp != NULL) && (alarm < (rtcalarm_t)RTC_ALARMS));

  rtc_lld_set_alarm(rtcp, alarm, alarmspec);
}

void rtcSetAlarmEx( RTCDriver 	*rtcp,
										rtcalarm_t 	alarm,
										bool 				is_weekday,
										uint32_t 		date,
										uint32_t 		hour,
										uint32_t 		minute,
										uint32_t 		second,
										bool 				date_en,
										bool 				hour_en,
										bool 				minute_en,
										bool 				second_en) {

  osalDbgCheck((rtcp != NULL) && (alarm < (rtcalarm_t)RTC_ALARMS));

  RTCAlarm alarmspec;
  rtcBuildAlarmStruct(&alarmspec, is_weekday, date, hour, minute, second,
                      date_en, hour_en, minute_en, second_en);
  rtc_lld_set_alarm(rtcp, alarm, &alarmspec);
}

/**
 * @brief   Get current alarm.
 * @note    If an alarm has not been set then the returned alarm specification
 *          is not meaningful.
 * @note    This function can be called from any context but limitations
 *          could be imposed by the low level implementation. It is
 *          guaranteed that the function can be called from thread
 *          context.
 * @note    The function can be reentrant or not reentrant depending on
 *          the low level implementation.
 *
 * @param[in] rtcp      pointer to RTC driver structure
 * @param[in] alarm     alarm identifier: 0=A, 1=B
 * @param[out] alarmspec pointer to a @p RTCAlarm structure
 *
 * @special
 */
void rtcGetAlarm(RTCDriver *rtcp,
                 rtcalarm_t alarm,
                 RTCAlarm *alarmspec) {

  osalDbgCheck((rtcp != NULL) &&
               (alarm < (rtcalarm_t)RTC_ALARMS) &&
               (alarmspec != NULL));

  rtc_lld_get_alarm(rtcp, alarm, alarmspec);
}
#endif /* RTC_ALARMS > 0 */

#if (RTC_SUPPORTS_CALLBACKS == TRUE) || defined(__DOXYGEN__)
/**
 * @brief   Enables or disables RTC callbacks.
 * @details This function enables or disables the callback, use a @p NULL
 *          pointer in order to disable it.
 * @note    This function can be called from any context but limitations
 *          could be imposed by the low level implementation. It is
 *          guaranteed that the function can be called from thread
 *          context.
 * @note    The function can be reentrant or not reentrant depending on
 *          the low level implementation.
 *
 * @param[in] rtcp      pointer to RTC driver structure
 * @param[in] callback  callback function pointer or @p NULL
 *
 * @special
 */
void rtcSetCallback(RTCDriver *rtcp, rtccb_t callback) {

  osalDbgCheck(rtcp != NULL);

  rtc_lld_set_callback(rtcp, callback);
}
#endif /* RTC_SUPPORTS_CALLBACKS == TRUE */

/**
 * @brief   Convert @p RTCDateTime to broken-down time structure.
 *
 * @param[in]  timespec   pointer to a @p RTCDateTime structure
 * @param[out] timp       pointer to a broken-down time structure
 * @param[out] tv_msec    pointer to milliseconds value or @p NULL
 *
 * @api
 */
void rtcConvertDateTimeToStructTm(const RTCDateTime *timespec,
                                  struct tm *timp,
                                  uint32_t *tv_msec) {
  int tmp;

  timp->tm_year  = (int)timespec->year + (RTC_BASE_YEAR - RTC_STRUCT_TM_BASE_YEAR);
  timp->tm_mon   = (int)timespec->month - 1;
  timp->tm_mday  = (int)timespec->day;
  timp->tm_wday  = timespec->dayofweek == 7U ? 0 : (int)timespec->dayofweek; // added
  timp->tm_isdst = (int)timespec->dstflag;

  tmp = (int)timespec->millisecond / 1000;
  timp->tm_sec  = tmp % 60;
  tmp -= timp->tm_sec;
  timp->tm_min  = (tmp % 3600) / 60;
  tmp -= timp->tm_min * 60;
  timp->tm_hour = tmp / 3600;

  if (NULL != tv_msec) {
    *tv_msec = (uint32_t)timespec->millisecond % 1000U;
  }
}

/**
 * @brief   Convert broken-down time structure to @p RTCDateTime.
 *
 * @param[in] timp        pointer to a broken-down time structure
 * @param[in] tv_msec     milliseconds value
 * @param[out] timespec   pointer to a @p RTCDateTime structure
 *
 * @api
 */
void rtcConvertStructTmToDateTime(const struct tm *timp,
                                  uint32_t tv_msec,
                                  RTCDateTime *timespec) {

  /*lint -save -e9034 [10.4] Verified assignments to bit fields.*/
  timespec->year      = (uint32_t)timp->tm_year + RTC_STRUCT_TM_BASE_YEAR - RTC_BASE_YEAR;
  timespec->month     = (uint32_t)timp->tm_mon + 1U;
  timespec->day       = (uint32_t)timp->tm_mday;
  timespec->dayofweek = timp->tm_wday == 0 ? 7U : (uint32_t)timp->tm_wday;
  if (-1 == timp->tm_isdst) {
    timespec->dstflag = 0U;  /* set zero if dst is unknown */
  }
  else {
    timespec->dstflag = (uint32_t)timp->tm_isdst;
  }
  /*lint -restore*/
  /*lint -save -e9033 [10.8] Verified assignments to bit fields.*/
  timespec->millisecond = tv_msec + (uint32_t)(((timp->tm_hour * 3600) +
                                                (timp->tm_min * 60) +
                                                 timp->tm_sec) * 1000);
  /*lint -restore*/
}

/**
 * @brief   Get current time in format suitable for usage in FAT file system.
 * @note    The information about day of week and DST is lost in DOS
 *          format, the second field loses its least significant bit.
 *
 *          FAT time format: uint32_t.
 *          [31..25]:   Year origin from 1980 (0..127, e.g. 37 for 2017)
 *          [24..21]:   Month (1..12)
 *          [20..16]:   Day of month (1..31)
 *          [15..11]:   Hour (0..23)
 *          [10.. 5]:   Minute (0..59)
 *          [ 4.. 0]:   Second/2 (0..29, e.g. 25 for 50)
 *
 * @param[out] timespec pointer to a @p RTCDateTime structure
 * @return              FAT date/time value.
 *
 * @api
 */
uint32_t rtcConvertDateTimeToFAT(const RTCDateTime *timespec) {
  uint32_t fattime;
  uint32_t sec, min, hour, day, month, tmp;

  tmp = timespec->millisecond / 1000U;
  sec = tmp % 60U;
  min = (tmp - sec) % 3600U;
  hour = ((tmp - sec) - (min * 60U)) / 3600U;
  day = timespec->day;
  month = timespec->month;

  /* handle DST flag */
  if (1U == timespec->dstflag) { // Convert to DST time: adjust forward 1 hour.
    hour += 1U;
    if (hour == 24U) {
      hour = 0U;
      day += 1U;
      // Fixed: dealing with leap year.
      uint32_t month_length = is_leap_year(timespec->year + RTC_BASE_YEAR) ?
      		month_len_of_leap_year[month - 1U] : month_len[month - 1U];
      if (day > month_length) {
        day = 1U;
        month += 1U;
      }
    }
  }

  fattime  = sec   >> 1U;
  fattime |= min   << 5U;
  fattime |= hour  << 11U;
  fattime |= day   << 16U;
  fattime |= month << 21U;
  fattime |= ((uint32_t)timespec->year + RTC_BASE_YEAR - RTC_FAT_BASE_YEAR) << 25U;

  return fattime;
}

/**
 * @brief   Convert @p DateTime structure to date time in string format,
 *          e.g. "Fri Nov 17 17:31:03.625 2017".
 *
 * @param[in]  datetimespec  pointer to a @p RTCDateTime structure
 * @param[out] str           pointer to a string to output the result,
 *                           the string length should not less than 35 bytes.
 * @return                   pointer to the saved string.
 */
char * rtcConvertDateTimeToString(const RTCDateTime *datetimespec, char *str) {
	struct tm tm0;
	uint32_t ms;
	char year[10];
	rtcConvertDateTimeToStructTm(datetimespec, &tm0, &ms);
	asctime_r(&tm0, str);
	strcpy(year, str+19);
	year[5] = '\0';
	sprintf(str+19, ".%d", (int)ms); // ".65535" = 6 chars
	strcat(str, year);
	return str;
}

/**
 * @brief   Convert datetime in string format to broken-down time structure.
 *
 * @param str				pointer to a datetime in string format, e.g.: "20171101150637".
 * @param tv_tim		pointer to a broken-down time structure @p struct tm.
 */
void rtcConvertStingToStructTm(const char *str,  struct tm *tv_tim)
{
  if((NULL == str) || (NULL == tv_tim))
    return;

  char ch[5];

  tv_tim->tm_isdst = -1;

  strncpy(ch, str, 4);
  tv_tim->tm_year = atol(ch) - RTC_STRUCT_TM_BASE_YEAR;

  memset(ch, 0, 4);
  strncpy(ch, str+4, 2);
  tv_tim->tm_mon = atoi(ch) - 1;

  strncpy(ch, str+6, 2);
  tv_tim->tm_mday = atoi(ch);

  strncpy(ch, str+8, 2);
  tv_tim->tm_hour = atoi(ch);

  strncpy(ch, str+10, 2);
  tv_tim->tm_min = atoi(ch);

  strncpy(ch, str+12, 2);
  tv_tim->tm_sec = atoi(ch);

  mktime(tv_tim); // Set tm_yday and tm_wday.
}

/**
 * @brief   Convert datetime in string format to @p RTCDateTime structure.
 *
 * @param str				pointer to a datetime in string format, e.g.: "20171101150637".
 * @param timespec	pointer to a @p RTCDateTime structure.
 */
void rtcConvertStingToDateTime(const char *str, RTCDateTime *timespec)
{
  if((NULL == str) || (NULL == timespec))
    return;

  struct tm tv_tim;
  rtcConvertStingToStructTm(str, &tv_tim);
  rtcConvertStructTmToDateTime(&tv_tim, 0, timespec);
}

#if HS_HAS_RTC_STM32
/**
 * @brief     Convert broken-down time structure to @p RTCAlarm.
 *
 * @param[in] timp      pointer to a broken-down time structure.
 * @param[in] alarmspec Pointer to RTC alarm structure.
 * @param[in] mask      alarm match mask, can be any combination of:
 *                      @p RTC_ALRMBR_DATE
 *                      @p RTC_ALRMBR_HOUR
 *                      @p RTC_ALRMBR_MIN
 *                      @p RTC_ALRMBR_SEC
 *
 * @api
 */
 #if 0
void rtcConvertStructTmToStructAlarm(struct tm *timp, RTCAlarm *alarmspec, uint32_t mask)
{
  uint32_t v = 0;

  alarmspec->tv_datetime = 0x00;

  v = timp->tm_mday;
  alarmspec->tv_datetime |= ((v / 10) << RTC_ALARM_DT_OFFSET) & RTC_ALRM_DT;
  alarmspec->tv_datetime |= ((v % 10) << RTC_ALARM_DU_OFFSET) & RTC_ALRM_DU;

  v = timp->tm_hour;
  alarmspec->tv_datetime |= ((v / 10) << RTC_ALARM_HT_OFFSET) & RTC_ALRM_HT;
  alarmspec->tv_datetime |= ((v % 10) << RTC_ALARM_HU_OFFSET) & RTC_ALRM_HU;

  v = timp->tm_min;
  alarmspec->tv_datetime |= ((v / 10) << RTC_ALARM_MT_OFFSET) & RTC_ALRM_MNT;
  alarmspec->tv_datetime |= ((v % 10) << RTC_ALARM_MU_OFFSET) & RTC_ALRM_MNU;

  v = timp->tm_sec;
  alarmspec->tv_datetime |= ((v / 10) << RTC_ALARM_ST_OFFSET) & RTC_ALRM_ST;
  alarmspec->tv_datetime |= ((v % 10) << RTC_ALARM_SU_OFFSET) & RTC_ALRM_SU;

  alarmspec->tv_datetime |= mask;
}

void rtcBuildAlarmStruct(RTCAlarm *alarmspec, bool use_weekday,
												 uint32_t date, uint32_t hour, uint32_t minute, uint32_t second,
												 bool date_en, bool hour_en, bool minute_en, bool second_en)
{
	alarmspec->tv_datetime = 0x00;

	if (use_weekday)
		alarmspec->tv_datetime |= RTC_ALRM_WDSEL;

	alarmspec->tv_datetime |= ((date / 10) << RTC_ALARM_DT_OFFSET) & RTC_ALRM_DT;
	alarmspec->tv_datetime |= ((date % 10) << RTC_ALARM_DU_OFFSET) & RTC_ALRM_DU;

	alarmspec->tv_datetime |= ((hour / 10) << RTC_ALARM_HT_OFFSET) & RTC_ALRM_HT;
	alarmspec->tv_datetime |= ((hour % 10) << RTC_ALARM_HU_OFFSET) & RTC_ALRM_HU;

	alarmspec->tv_datetime |= ((minute / 10) << RTC_ALARM_MT_OFFSET) & RTC_ALRM_MNT;
	alarmspec->tv_datetime |= ((minute % 10) << RTC_ALARM_MU_OFFSET) & RTC_ALRM_MNU;

	alarmspec->tv_datetime |= ((second / 10) << RTC_ALARM_ST_OFFSET) & RTC_ALRM_ST;
	alarmspec->tv_datetime |= ((second % 10) << RTC_ALARM_SU_OFFSET) & RTC_ALRM_SU;

	alarmspec->tv_datetime |= (date_en   ? 0 : RTC_ALARM_DATE_MASK_OFFSET) |
														(hour_en   ? 0 : RTC_ALARM_HOUR_MASK_OFFSET) |
														(minute_en ? 0 : RTC_ALARM_MIN_MASK_OFFSET)  |
														(second_en ? 0 : RTC_ALARM_SEC_MASK_OFFSET)  ;
	// disable AM/PM notation.
}
#else
void rtcConvertStructTmToStructAlarm(struct tm *timp, RTCAlarm *alarmspec, uint32_t mask)
{
	uint32_t v = 0;

	mktime(timp); // Set tm_yday and tm_wday.
  alarmspec->tv_datetime = 0x00;

  v = timp->tm_mday;
  alarmspec->date_tens = v / 10;
  alarmspec->date_unit = v % 10;

  v = timp->tm_hour;
  alarmspec->hour_tens = v / 10;
  alarmspec->hour_unit = v % 10;

  v = timp->tm_min;
  alarmspec->minute_tens = v / 10;
  alarmspec->minute_unit = v % 10;

  v = timp->tm_sec;
  alarmspec->second_tens = v / 10;
  alarmspec->second_unit = v % 10;

  alarmspec->tv_datetime |= mask;
}

void rtcBuildAlarmStruct(RTCAlarm 	*alarmspec,
												bool 				is_weekday,
												uint32_t 		date,
												uint32_t 		hour,
												uint32_t 		minute,
												uint32_t 		second,
												bool 				date_en,
												bool 				hour_en,
												bool 				minute_en,
												bool 				second_en) {

	alarmspec->tv_datetime = 0x00;

	alarmspec->date_tens = date / 10;
	alarmspec->date_unit = date % 10;

	alarmspec->hour_tens = hour / 10;
	alarmspec->hour_unit = hour % 10;

	alarmspec->minute_tens = minute / 10;
	alarmspec->minute_unit = minute % 10;

	alarmspec->second_tens = second / 10;
	alarmspec->second_unit = second % 10;

	if (is_weekday)
		alarmspec->weekday_sel = 1;
	if (!date_en)
		alarmspec->date_mask = 1;
	if (!hour_en)
		alarmspec->hour_mask = 1;
	if (!minute_en)
		alarmspec->minute_mask = 1;
	if (!second_en)
		alarmspec->second_mask = 1;

	// disable AM/PM notation.
}
#endif
#else /* #if HS_HAS_RTC_STM32 */
void rtcConvertStructTmToStructAlarm(struct tm *timp, RTCAlarm *alarmspec, uint32_t mask)
{
  (void)mask;
  rtcConvertStructTmToDateTime(timp, 0, alarmspec);
}
#endif /* #if HS_HAS_RTC_STM32 */

/**
 * @brief     Sets time of periodic wakeup.
 *
 * @note      Default value after BKP domain reset is 0x0000FFFF
 *
 * @param[in] rtcp       pointer to RTC driver structure
 * @param clock_sel      Wake-up clock selection, can be any one of the following:
 *                       @p RTC_WAKEUP_CLK_DIV_16
 *                       @p RTC_WAKEUP_CLK_DIV_8
 *                       @p RTC_WAKEUP_CLK_DIV_4
 *                       @p RTC_WAKEUP_CLK_DIV_2
 *                       @p RTC_WAKEUP_CLK_CK_SPRE_1Hz
 *
 * @param count          Cycles to count down before wake-up occurs. Range:
 *                       clock_sel:
 *                       = RTC_WAKEUP_CLK_CK_SPRE_1Hz: count = [0, 0x1FFFF];
 *                       = RTC_WAKEUP_CLK_DIV_2:       count = [1, 0x0FFFF];
 *                       = other:                      count = [0, 0x0FFFF];
 * @api
 */
void rtcSetPeriodicWakeup(RTCDriver *rtcp, uint32_t clock_sel, uint32_t count) {
	RTCWakeup wakeupspec;
	wakeupspec.wakeup = count & 0x0FFFF;

	if (!count)
		rtc_lld_disable_periodic_wakeup(rtcp);

	/* hardware forbidden combination */
	if (clock_sel == RTC_WAKEUP_CLK_DIV_2 && (wakeupspec.wakeup & 0xFFFF) == 0)
		return;

	wakeupspec.wakeup |= clock_sel<<16;

	if (clock_sel == RTC_WAKEUP_CLK_CK_SPRE_1Hz) {
		wakeupspec.wakeup |= (count & 0x10000U)<<1;
	}

	rtc_lld_set_periodic_wakeup(rtcp, &wakeupspec);
}

/**
 * @brief     Gets time of periodic wakeup.
 *
 * @note      Default value after BKP domain reset is 0x0000FFFF
 *
 * @param[in] rtcp        pointer to RTC driver structure
 * @param[out] wakeupspec pointer to a @p RTCWakeup structure
 *
 * @api
 */
void rtcGetPeriodicWakeup(RTCDriver *rtcp, uint32_t *clock_sel, uint32_t *count) {
	RTCWakeup wakeupspec;
	uint32_t tmp;

	if (clock_sel == NULL || count == NULL)
		return;

	rtc_lld_get_periodic_wakeup(rtcp, &wakeupspec);

	tmp = wakeupspec.wakeup>>16 & RTC_CR_WUCKSEL;
	if (tmp >= RTC_WAKEUP_CLK_CK_SPRE_1Hz) {
		*clock_sel = RTC_WAKEUP_CLK_CK_SPRE_1Hz;
		*count = (wakeupspec.wakeup & (1U<<17))>>1 | (wakeupspec.wakeup & 0xFFFFU);
	}
	else {
		*clock_sel = tmp;
		*count = wakeupspec.wakeup & 0xFFFFU;
	}
}

#if HS_HAS_RTC_STM32
/**
 * @brief   Generate RTC calibration register value.
 *
 * @param pulses      Number of RTCCLK_32K pulses to be added or subtracted
 *                    every @p cal_period seconds: [-511, +512].
 * @param cal_period  Calibration cycle period: [8, 16, 32] seconds.
 * @return            Calibration register value.
 */
static uint32_t rtc_cal_reg_val(int pulses, int cal_period) {

	if (pulses == 0)
		return 0U;

	int calp, calm;

	if (pulses > 0) {
		calp = 1;
		calm = 512 - pulses;
	}
	else {
		calp = 0;
		calm = 0 - pulses;
	}

	uint32_t calr = (calp<<15) | calm;
	if (cal_period == 8)
		calr |= RTC_CALR_CALW8;
	else if (cal_period == 16)
		calr |= RTC_CALR_CALW16;

	return calr;
}

/**
 * @brief   RTC smooth digital calibration.
 *
 * @param rtcp        Pointer to a @p RTCDriver structure.
 * @param pulses      Number of RTCCLK_32K pulses to be added or subtracted
 *                    every @p cal_period seconds: [-511, +512].
 * @param cal_period  Calibration cycle period: [8, 16, 32] seconds.
 */
void rtcCal(RTCDriver *rtcp, int pulses, int cal_period) {

  uint32_t calr = rtc_cal_reg_val(pulses, cal_period);
	if (calr)
  	rtc_lld_smooth_cal(rtcp, calr);
}

/**
 * @brief   RTC digital calibration on the fly.
 *
 * @param rtcp        Pointer to a @p RTCDriver structure.
 * @param pulses      Number of RTCCLK_32K pulses to be added or subtracted
 *                    every @p cal_period seconds: [-511, +512].
 * @param cal_period  Calibration cycle period: [8, 16, 32] seconds.
 */
void rtcCalOnTheFly(RTCDriver *rtcp, int pulses, int cal_period) {

	uint32_t calr = rtc_cal_reg_val(pulses, cal_period);
	if (calr)
		rtc_lld_recal_on_the_fly(rtcp, calr);
}
#endif

#if RTC_USE_MUTUAL_EXCLUSION || defined(__DOXYGEN__)
void rtcAcquireBus(RTCDriver *rtcp) {

	osalDbgCheck(rtcp != NULL);

  osalMutexLock(&rtcp->mutex);
}

void rtcReleaseBus(RTCDriver *rtcp) {

  osalDbgCheck(rtcp != NULL);

  osalMutexUnlock(&rtcp->mutex);
}
#endif /* RTC_USE_MUTUAL_EXCLUSION */


#endif /* HAL_USE_RTC == TRUE */

/** @} */
