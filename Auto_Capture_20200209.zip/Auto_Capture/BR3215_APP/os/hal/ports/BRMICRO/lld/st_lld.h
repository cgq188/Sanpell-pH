/*
    ChibiOS - Copyright (C) 2006..2015 Giovanni Di Sirio

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    BRMICRO/st_lld.h
 * @brief   ST Driver subsystem low level driver header.
 * @details This header is designed to be include-able without having to
 *          include other files from the HAL.
 *
 * @addtogroup ST
 * @{
 */

#ifndef _ST_LLD_H_
#define _ST_LLD_H_

#include "mcuconf.h"
#include "hs_registry.h"

/*===========================================================================*/
/* Driver constants.                                                         */
/*===========================================================================*/

/*===========================================================================*/
/* Driver pre-compile time settings.                                         */
/*===========================================================================*/

/**
 * @name    Configuration options
 * @{
 */
/**
 * @brief   SysTick timer IRQ priority.
 */
#if !defined(HS_ST_IRQ_PRIORITY) || defined(__DOXYGEN__)
#define HS_ST_IRQ_PRIORITY          2
#endif

/**
 * @brief   TIMx unit (by number) to be used for free running operations.
 * @note    You must select a 32 bits timer if a 32 bits @p systick_t type
 *          is required, see CH_CFG_ST_RESOLUTION.
 * @note    TIM0,1,2 is 16-bit.
 */
#if !defined(HS_ST_USE_TIM) || defined(__DOXYGEN__)
#define HS_ST_USE_TIM               2
#endif
/** @} */

/*===========================================================================*/
/* Derived constants and error checks.                                       */
/*===========================================================================*/

#if HS_ST_USE_TIM == 2
#if !HS_HAS_TIM2
#error "TIM2 not present"
#endif
#define HS_ST_TIM                   HS_TIM2

#elif HS_ST_USE_TIM == 1
#if !HS_HAS_TIM1
#error "TIM1 not present"
#endif
#define HS_ST_TIM                   HS_TIM1

#elif HS_ST_USE_TIM == 0
#if !HS_HAS_TIM0
#error "TIM0 not present"
#endif
#define HS_ST_TIM                   HS_TIM0

#else
#error "HS_ST_USE_TIM specifies an unsupported timer"
#endif

/*===========================================================================*/
/* Driver data structures and types.                                         */
/*===========================================================================*/

/*===========================================================================*/
/* Driver macros.                                                            */
/*===========================================================================*/

#define _systick_lld_set_cr(bit)                \
  do {                                          \
    while (0 == (HS_SYSTICK->CR & (1u << 8)))   \
      ;                                         \
    HS_SYSTICK->CR |= (bit);                    \
  } while (0)

#define _systick_lld_clr_cr(bit)                \
  do {                                          \
    while (0 == (HS_SYSTICK->CR & (1u << 8)))   \
      ;                                         \
    HS_SYSTICK->CR &= ~(bit);                   \
  } while (0)

#define _systick_lld_set_tick(ms)               \
  do {                                          \
    while (0 == (HS_SYSTICK->CR & (1u << 9)))   \
      ;                                         \
    HS_SYSTICK->TICK = (ms);                    \
  } while (0)

#define _systick_lld_set_alarm(ms)              \
  do {                                          \
    while (0 == (HS_SYSTICK->CR & (1u << 10)))  \
      ;                                         \
    HS_SYSTICK->ALARM = (ms);                   \
  } while (0)

/*===========================================================================*/
/* External declarations.                                                    */
/*===========================================================================*/

#ifdef __cplusplus
extern "C" {
#endif
  void st_lld_init(void);
  void st_lld_reinit(int hz);
  void st_lld_deinit(void);
#ifdef __cplusplus
}
#endif

/*===========================================================================*/
/* Driver inline functions.                                                  */
/*===========================================================================*/

/**
 * @brief   Returns the time counter value.
 *
 * @return              The counter value.
 *
 * @notapi
 */
static inline systime_t st_lld_get_counter(void) {

  #if HS_HAS_RTC_YGW
  return (systime_t)(HS_SYSTICK->CNT >> 5);
  #else
  return (systime_t)HS_ST_TIM->CNT;
  #endif
}

/**
 * @brief   Starts the alarm.
 * @note    Makes sure that no spurious alarms are triggered after
 *          this call.
 *
 * @param[in] time      the time to be set for the first alarm
 *
 * @notapi
 */
static inline void st_lld_start_alarm(systime_t time) {

  #if HS_HAS_RTC_YGW
  _systick_lld_set_alarm(time << 5);
  HS_SYSTICK->INTMASK = RTC_INT_ALARM;
  #else
  HS_ST_TIM->CCR[0] = (uint32_t)time;
  HS_ST_TIM->SR     = 0;
  HS_ST_TIM->DIER   = TIM_DIER_CC1IE;
  #endif
}

/**
 * @brief   Stops the alarm interrupt.
 *
 * @notapi
 */
static inline void st_lld_stop_alarm(void) {

  #if HS_HAS_RTC_YGW
  HS_SYSTICK->INTMASK &= ~RTC_INT_ALARM;
  #else
  HS_ST_TIM->DIER = 0;
  #endif
}

/**
 * @brief   Sets the alarm time.
 *
 * @param[in] time      the time to be set for the next alarm
 *
 * @notapi
 */
static inline void st_lld_set_alarm(systime_t time) {

  #if HS_HAS_RTC_YGW
  _systick_lld_set_alarm(time << 5);
  #else
  HS_ST_TIM->CCR[0] = (uint32_t)time;
  #endif
}

/**
 * @brief   Returns the current alarm time.
 *
 * @return              The currently set alarm time.
 *
 * @notapi
 */
static inline systime_t st_lld_get_alarm(void) {

  #if HS_HAS_RTC_YGW
  return (systime_t)(HS_SYSTICK->ALARM >> 5);
  #else
  return (systime_t)HS_ST_TIM->CCR[0];
  #endif
}

/**
 * @brief   Determines if the alarm is active.
 *
 * @return              The alarm status.
 * @retval false        if the alarm is not active.
 * @retval true         is the alarm is active
 *
 * @notapi
 */
static inline bool st_lld_is_alarm_active(void) {

  #if HS_HAS_RTC_YGW
  return (bool)((HS_SYSTICK->INTMASK & RTC_INT_ALARM) != 0);
  #else
  return (bool)((HS_ST_TIM->DIER & TIM_DIER_CC1IE) != 0);
  #endif
}

#endif /* _ST_LLD_H_ */

/** @} */
