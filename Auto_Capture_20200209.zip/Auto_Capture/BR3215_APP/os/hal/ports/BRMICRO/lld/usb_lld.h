/*
    ChibiOS/RT - Copyright (C) 2006-2013 Giovanni Di Sirio
    PengJiang, 20140710
    luwei, 201704

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

#ifndef _USB_LLD_H_
#define _USB_LLD_H_

#if HAL_USE_USB || HAL_USE_USBH || defined(__DOXYGEN__)

/*===========================================================================*/
/* Driver constants.                                                         */
/*===========================================================================*/

/**
 * @brief USB Full-Speed Dual-Role Controller Configuration.
 * Number of DMA channels: 3
 * Size of DMA buffer (bytes): 32
 * Dynamic FIFO Sizing
 * Total RAM Size (bytes): 512
 * Number of Tx endpoints (in addition to ep0): 3
 * Number of Rx endpoints (in addition to ep0): 3
 * Disable pull-up resistor during peripheral transmit
 * gate count: 35100;  RAM size: 512 bytes
 */

/**
 * @brief   Maximum endpoint address.
 */
#define USB_MAX_ENDPOINTS                HS_USB_NUM_ENDPOINTS

/**
 * @brief   Memory size for dynamic FIFO
 */
#define USB_FIFO_MEM_SIZE                HS_USB_FIFO_SIZE

/*===========================================================================*/
/* Driver pre-compile time settings.                                         */
/*===========================================================================*/

/**
 * @brief   USB0 driver enable switch.
 * @details If set to @p TRUE the support for USB0 is included.
 * @note    The default is @p TRUE.
 */
#if !defined(HS_USB_USE_USB0) || defined(__DOXYGEN__)
#define HS_USB_USE_USB0                  FALSE
#endif

/**
 * @brief   USB0 interrupt priority level setting.
 */
#if !defined(HS_USB_USB0_IRQ_PRIORITY) || defined(__DOXYGEN__)
#define HS_USB_USB0_IRQ_PRIORITY         3
#endif

#if !defined(HS_USB_USB0_DMA_IRQ_PRIORITY) || defined(__DOXYGEN__)
#define HS_USB_USB0_DMA_IRQ_PRIORITY     2
#endif

/*===========================================================================*/
/* Derived constants and error checks.                                       */
/*===========================================================================*/

/*===========================================================================*/
/* Driver data structures and types.                                         */
/*===========================================================================*/


/*===========================================================================*/
/* Driver macros.                                                            */
/*===========================================================================*/

#define HS_TRACE_USB                0


/*===========================================================================*/
/* External declarations.                                                    */
/*===========================================================================*/

#ifdef __cplusplus
extern "C" {
#endif
  bool usbdrc_get_vbus(void);
  void usbdrc_connect_vbus(bool bForce);
  void usbdrc_disconnect_vbus(void);
  void usbdrc_flush_fifo(void);
  void usbdrc_reset_core(void);

  void usbdrc_setup_dma_in(uint8_t ch, uint8_t ep, uint16_t mps, const uint8_t *txbuf, size_t txsize);
  void usbdrc_setup_dma_out(uint8_t ch, uint8_t ep, uint16_t mps, uint8_t *rxbuf, size_t rxsize);
  void usbdrc_handle_dma_in(uint8_t ch);
  void usbdrc_handle_dma_out(uint8_t ch);

  #if HS_TRACE_USB
  void usb_trace(char c, uint8_t n);
  void usb_trace_setup(char c, uint8_t *setup);
  void usb_trace_prefix(char c, uint8_t n);
  #else
  #define usb_trace(c,n)
  #define usb_trace_setup(c,setup)
  #define usb_trace_prefix(c,n)
  #endif
#ifdef __cplusplus
}
#endif

static inline int binary_search(uint16_t n)
{
  int b, bits = 1;
  for (b = 16; b >= 1; b /= 2) {
    int s = 1 << b;
    if (n >= s) { n>>=b; bits+=b; }
  }
  return bits;
}

#endif /* HAL_USE_USB || HAL_USE_USBH */

#endif /* _USB_LLD_H_ */

/** @} */
