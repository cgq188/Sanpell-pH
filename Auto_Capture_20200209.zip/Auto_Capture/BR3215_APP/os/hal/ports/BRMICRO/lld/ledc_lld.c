#include "hal.h"

#if (HAL_USE_LEDC == TRUE) || defined(__DOXYGEN__)

/*===========================================================================*/
/* Driver exported variables.                                                */
/*===========================================================================*/

LEDCDriver LEDCD0;

/**
 * @brief   Low level LEDC driver initialization.
 *
 * @notapi
 */
void ledc_lld_init(void){

  uint32_t i;

  LEDCD0.state = LEDC_STOP;
  LEDCD0.ledc  = HS_LEDC;

  /*stop ledc when init*/
  for(i=0x00; i<LEDC_MAX_SCAN_REG; i++){
    LEDCD0.ledc->REG[i] = 0x00;
  }

  LEDCD0.ledc->DISCTL = 0x00;
}

void ledc_lld_start(LEDCDriver *ledcp) {
    
  uint32_t i;
  uint32_t reg;

  for(i=0x00; i<LEDC_MAX_SCAN_REG; i++){
    ledcp->ledc->REG[i] = 0x00;
  }

  #if defined(hscAudiophile)
  i = ledcp->config->digit_num * 7 + DISPLAY_LED_ICON_NUM; /* the number of segments */
  reg = ledcp->config->rate / 200; /* rate 1000Hz to period 5? */
  reg |= (1<<24) | (i<<16);
  #else
  reg = (ledcp->config->period) + (ledcp->config->max_scan_num << 16) + (1<<24);
  #endif
  ledcp->ledc->DISCTL = reg;
}

void ledc_lld_clear_reg(LEDCDriver *ledcp, uint32_t reg_start, uint32_t reg_end)
{
  uint32_t i;

  osalDbgAssert(reg_start < LEDC_MAX_SCAN_REG, "ledc scan num exceeded");
  osalDbgAssert(reg_end < LEDC_MAX_SCAN_REG, "ledc scan num exceeded");

  for(i=reg_start; i<=reg_end; i++){
    ledcp->ledc->REG[i] = 0x00;
  }
}

void ledc_lld_scan_reg(LEDCDriver *ledcp, const uint16_t *scan_reg, uint32_t scan_reg_len, uint32_t reg_start)
{
  uint32_t i;

  osalDbgAssert(reg_start < LEDC_MAX_SCAN_REG, "ledc scan num exceeded");

  for(i=0; i<scan_reg_len; i++){
    ledcp->ledc->REG[reg_start+i] = scan_reg[i];
  }
}

void ledc_lld_stop(LEDCDriver *ledcp){
    
  uint32_t i;

  for(i=0x00; i<LEDC_MAX_SCAN_REG; i++){
    ledcp->ledc->REG[i] = 0x00;
  }

  /*stop ledc*/
  ledcp->ledc->DISCTL &=~(1<<24);
}


#endif
