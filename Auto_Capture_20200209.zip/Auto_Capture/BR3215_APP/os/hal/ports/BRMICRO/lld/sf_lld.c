/*
    ChibiOS/RT - Copyright (C) 2006-2013 Giovanni Di Sirio
                 Copyright (C) 2019 BRMICRO Technologies
                 

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    br32xx/sf_lld.c
 * @brief   SPI flash interface Driver subsystem low level driver source template.
 *
 * @addtogroup SF
 * @{
 */

#include <string.h>
#include "hal.h"
#include "Type.h"

#if HAL_USE_SF || defined(__DOXYGEN__)


/*===========================================================================*/
/* Driver local definitions.                                                 */
/*===========================================================================*/

#define SR_WIP                (1u << 0)    /* Write in progress */
#define SR_WEL                (1u << 1)    /* Write enable latch */
#define	SR_BP0                (1u << 2)    /* Block protect 0 */
#define	SR_BP1                (1u << 3)    /* Block protect 1 */
#define	SR_BP2                (1u << 4)    /* Block protect 2 */
#define	SR_SRP0               (1u << 7)    /* SR write protect */
#define	SR_SRP1               (1u << 8)    /* SR write protect */
#define SR_QE                 (1u << 9)    /* Quad enable */
#define SR_LB1                (1u << 11)   /* OTP */
#define SR_LB2                (1u << 12)   /* OTP */
#define SR_LB3                (1u << 13)   /* OTP */
#define SR_CMP                (1u << 14)   /* conjunction BPx */

#define SFLASH_PAGE_SIZE    256
#if defined(BR3215)
static uint8_t m_sf_dma_buf[SFLASH_PAGE_SIZE] __DMA_DATA__;
#endif

extern unsigned char __ilm_base__[];

/*===========================================================================*/
/* Driver exported variables.                                                */
/*===========================================================================*/

/**
 * @brief   SF driver identifier.
 */
#if HS_SF_USE_SF0 && !defined(__DOXYGEN__)
SFDriver SFD;
#endif

/*===========================================================================*/
/* Driver local variables and types.                                         */
/*===========================================================================*/

static const SFlashInfo_t g_SFInfo[] = {
//                              page_size sector_size sector_num block_size block_num
  {"General flash",   0xFFFFFF, 256,      4*1024,     128,       64*1024,    8},
  {"EN25F40",         0x1c3113, 256,      4*1024,     128,       64*1024,    8},
  {"EN25T80",         0x1c5114, 256,      4*1024,     256,       64*1024,   16},
  {"XD25D40",         0x504013, 256,      4*1024,     128,       64*1024,    8},
  {"MD25D40",         0x514013, 256,      4*1024,     128,       64*1024,    8},
  {"MD25D80",         0x514014, 256,      4*1024,     256,       64*1024,   16},
  {"GD25Q80",         0xc84014, 256,      4*1024,     256,       64*1024,   16},
  {"BY25Q80",         0xe04014, 256,      4*1024,     256,       64*1024,   16},
  {"PN25F08B",        0x5e4014, 256,      4*1024,     256,       64*1024,   16},
  {"P25R080H",        0x856014, 256,      4*1024,     256,       64*1024,   16},
  {"TH25Q04H",        0xEB6013, 256,      4*1024,     256,       64*1024,   16},
};

static const uint32_t  g_SFCnt = sizeof(g_SFInfo)/sizeof(SFlashInfo_t);

/*===========================================================================*/
/* Driver local functions.                                                   */
/*===========================================================================*/

__attribute__((always_inline)) __STATIC_INLINE void sf_clear(SFDriver *sfp)
{
  (void)sfp;
  HS_SF->RAW_INTR_STATUS = SF_INTR_CLRSTS;
}

static __ONCHIP_CODE__ void sf_wait(SFDriver *sfp)
{
  (void)sfp;
  while (HS_SF->RAW_INTR_STATUS == 0)
    ;
  HS_SF->RAW_INTR_STATUS = SF_INTR_CLRSTS;
}

static uint32_t sf_read_mid(SFDriver *sfp) __ONCHIP_CODE__;
static uint32_t sf_read_mid(SFDriver *sfp) {
  HS_SF_Type *sfrp = sfp->sf;
  uint32_t mid, cmd_r = 0;

#if defined(BR3215)
  uint16_t fmode = sfrp->CONFIGURATION_1;
  sfrp->CONFIGURATION_1 = fmode & ~(1u << 10);
#endif

  cmd_r |= SF_CMD_WIDTH(32);
  cmd_r |= sfp->config->cs << 4;
  cmd_r |= SF_CMD_READ;
  cmd_r |= SF_CMD_KEEPCS;

  sf_clear(sfp);
  sfrp->COMMAND_DATA0_REG = SF_CMD_RDID;
  sfrp->COMMAND = cmd_r;

  sf_wait(sfp);

#if defined(BR3215)
  sfrp->CONFIGURATION_1 = fmode;
#endif

  mid = sfrp->READ0_REG & 0xffffff;

  return mid;
}

#if 0
static __ONCHIP_CODE__ void sf_reset_flash(SFDriver *sfp)
{
  HS_SF_Type *sfrp = sfp->sf;
  uint32_t cmd_r = 0;

#if defined(BR3215)
  uint16_t fmode = sfrp->CONFIGURATION_1;
  sfrp->CONFIGURATION_1 = fmode & ~(1u << 10);
#endif

  cmd_r |= SF_CMD_WIDTH(8);
  cmd_r |= sfp->config->cs << 4;
  cmd_r |= SF_CMD_READ;
  cmd_r |= SF_CMD_KEEPCS;

  sf_clear(sfp);
  sfrp->COMMAND_DATA0_REG = SF_CMD_RSTEN;
  sfrp->COMMAND = cmd_r;
  sf_wait(sfp);

  sfrp->COMMAND_DATA0_REG = SF_CMD_RST;
  sfrp->COMMAND = cmd_r;
  sf_wait(sfp);

#if defined(BR3215)
  sfrp->CONFIGURATION_1 = fmode;
#endif
}
#endif

static __ONCHIP_CODE__ void sf_read_uid(SFDriver *sfp)
{
  HS_SF_Type *sfrp = sfp->sf;
  uint32_t cmd_r = 0, cmd_d = 0;

  cmd_r |= SF_DATA_CNT(16);
  cmd_r |= SF_CMD_WIDTH(40);
  cmd_r |= sfp->config->cs << 4;
  cmd_r |= SF_CMD_READ;
  cmd_r |= SF_CMD_KEEPCS;

  cmd_d |= SF_CMD_RUID;

  sf_clear(sfp);
  sfrp->COMMAND_DATA0_REG = cmd_d;
#if defined(BR3215)
  sfrp->ADDRESS_REG = (uint32_t)m_sf_dma_buf;
#else
  sfrp->ADDRESS_REG = (uint32_t)sfp->uid;
#endif
  sfrp->COMMAND = cmd_r;

  sf_wait(sfp);

#if defined(BR3215)
  memcpy(&sfp->uid[0], m_sf_dma_buf, 16);
#endif
}

void chip_id(void)
{
	//sf_read_uid(&SFD);
/*
    SFDriver* sfp = &SFD;

	HS_SF_Type* sfrp = sfp->sf;
	uint32_t cmd_r = 0, cmd_d = 0;

	cmd_r |= SF_DATA_CNT(16);
	cmd_r |= SF_CMD_WIDTH(40);
	cmd_r |= sfp->config->cs << 4;
	cmd_r |= SF_CMD_READ;
	cmd_r |= SF_CMD_KEEPCS;

	cmd_d |= SF_CMD_RUID;

	//sf_clear(sfp);
	HS_SF->RAW_INTR_STATUS = SF_INTR_CLRSTS;

	sfrp->COMMAND_DATA0_REG = cmd_d;
	sfrp->ADDRESS_REG = (uint32_t)sfp->uid;
	sfrp->COMMAND = cmd_r;

	//sf_wait(sfp);
	while (HS_SF->RAW_INTR_STATUS == 0)
		;
	HS_SF->RAW_INTR_STATUS = SF_INTR_CLRSTS;

    dUart_Printf("%x, %x, %x, %x, %x, %x, %x\r\n",
        cmd_r,
        cmd_d,
        (unsigned int)&HS_SF->RAW_INTR_STATUS,
        (unsigned int)&HS_SF->COMMAND_DATA0_REG,
        (unsigned int)&HS_SF->ADDRESS_REG,
        (unsigned int)&HS_SF->COMMAND,
        SF_INTR_CLRSTS);
    //102801, 4b000000, 42800004, 42800010, 42800020, 4280000c, 1
*/
	* (VUINT32*)0x42800004 = 1; //HS_SF->RAW_INTR_STATUS = SF_INTR_CLRSTS;
	*(VUINT32*)0x42800010 = 0x4b000000; //sfrp->COMMAND_DATA0_REG = cmd_d;
    *(VUINT32*)0x42800020 = (uint32_t)SFD.uid; //sfrp->ADDRESS_REG = (uint32_t)sfp->uid;
    *(VUINT32*)0x4280000c = 0x102801; //sfrp->COMMAND = cmd_r;

	while (*(VUINT32*)0x42800004 == 0) //while (HS_SF->RAW_INTR_STATUS == 0)
		;
	*(VUINT32*)0x42800004 = 1; //HS_SF->RAW_INTR_STATUS = SF_INTR_CLRSTS;
}

uint32_t sf_read_status_0(SFDriver *sfp) __ONCHIP_CODE__;
uint32_t sf_read_status_0(SFDriver *sfp) {
  HS_SF_Type *sfrp = sfp->sf;
  uint32_t status, cmd_r = 0;

  cmd_r |= SF_CMD_WIDTH(16);
  cmd_r |= sfp->config->cs << 4;
  cmd_r |= SF_CMD_READ;
  cmd_r |= SF_CMD_KEEPCS;

  sf_clear(sfp);
  sfrp->COMMAND_DATA0_REG = SF_CMD_RDSTAS;
  sfrp->COMMAND = cmd_r;

  sf_wait(sfp);

  status = sfrp->READ0_REG & 0xff;

  return status;
}

uint32_t sf_read_status_1(SFDriver *sfp) __ONCHIP_CODE__;
uint32_t sf_read_status_1(SFDriver *sfp) {
  HS_SF_Type *sfrp = sfp->sf;
  uint32_t status, cmd_r = 0;

  cmd_r |= SF_CMD_WIDTH(16);
  cmd_r |= sfp->config->cs << 4;
  cmd_r |= SF_CMD_READ;
  cmd_r |= SF_CMD_KEEPCS;

  sf_clear(sfp);
  sfrp->COMMAND_DATA0_REG = SF_CMD_RDSTAS1;
  sfrp->COMMAND = cmd_r;

  sf_wait(sfp);

  status = sfrp->READ0_REG & 0xff;

  return status;
}

uint32_t sf_read_status(SFDriver *sfp) __ONCHIP_CODE__;
uint32_t sf_read_status(SFDriver *sfp){
  uint32_t status;

  status  = sf_read_status_1(sfp) << 8;
  status = sf_read_status_0(sfp) + status;

  return status;
}

void sf_write_status(SFDriver *sfp, uint32_t status) __ONCHIP_CODE__;
void sf_write_status(SFDriver *sfp, uint32_t status) {
  HS_SF_Type *sfrp = sfp->sf;
  uint32_t cmd_r = 0, cmd_data = 0;

  cmd_r |= SF_CMD_WIDTH(24);
  cmd_r |= sfp->config->cs << 4;
  cmd_r |= SF_CMD_WRITE;
  cmd_r |= SF_CMD_KEEPCS;

  cmd_data = SF_CMD_WRSTAS;
  cmd_data |= (status & 0xff) << 16;
  cmd_data |= ((status >> 8) & 0xff) << 8;

  sf_clear(sfp);
  sfrp->COMMAND_DATA0_REG = cmd_data;
  sfrp->COMMAND = cmd_r;

  sf_wait(sfp);

  while(1) {
    status = sf_read_status(sfp);
    if((status & SR_WIP) == 0) {
      break;
    }
  }
}

void sf_write_enable(SFDriver *sfp) __ONCHIP_CODE__;
void sf_write_enable(SFDriver *sfp) {
  HS_SF_Type *sfrp = sfp->sf;
  uint32_t cmd_r = 0;

  cmd_r |= SF_CMD_WIDTH(8);
  cmd_r |= sfp->config->cs << 4;
  cmd_r |= SF_CMD_WRITE;
  cmd_r |= SF_CMD_KEEPCS;

  sf_clear(sfp);
  sfrp->COMMAND_DATA0_REG = SF_CMD_WREN;
  sfrp->COMMAND = cmd_r;

  sf_wait(sfp);
}

void sf_sector_erase(SFDriver *sfp, uint32_t offset) __ONCHIP_CODE__;
void sf_sector_erase(SFDriver *sfp, uint32_t offset) {
  HS_SF_Type *sfrp = sfp->sf;
  uint32_t status, cmd_r = 0, cmd_d = 0;

  sf_write_enable(sfp);

  cmd_r |= SF_CMD_WIDTH(32);
  cmd_r |= sfp->config->cs << 4;
  cmd_r |= SF_CMD_WRITE;
  cmd_r |= SF_CMD_KEEPCS;

  cmd_d |= SF_CMD_SE;
  cmd_d |= offset & 0xffffff;

  sf_clear(sfp);
  sfrp->COMMAND_DATA0_REG = cmd_d;
  sfrp->COMMAND = cmd_r;

  sf_wait(sfp);

  while(1) {
    status = sf_read_status_0(sfp);
    if((status & SR_WIP) == 0) {

      break;
    }
  }
}

void sf_chip_erase(SFDriver *sfp) __ONCHIP_CODE__;
void sf_chip_erase(SFDriver *sfp) {
  HS_SF_Type *sfrp = sfp->sf;
  uint32_t status, cmd_r = 0, cmd_d = 0;

  sf_write_enable(sfp);

  cmd_r |= SF_CMD_WIDTH(8);
  cmd_r |= sfp->config->cs << 4;
  cmd_r |= SF_CMD_WRITE;
  cmd_r |= SF_CMD_KEEPCS;

  cmd_d |= SF_CMD_CE;

  sf_clear(sfp);
  sfrp->COMMAND_DATA0_REG = cmd_d;
  sfrp->COMMAND = cmd_r;

  sf_wait(sfp);

  while(1) {
    status = sf_read_status_0(sfp);
    if((status & SR_WIP) == 0) {
      break;
    }
  }
}

static void sf_read(SFDriver *sfp, uint32_t offset, void *rdbuf, size_t len) __ONCHIP_CODE__;
static void sf_read(SFDriver *sfp, uint32_t offset, void *rdbuf, size_t len) {
  HS_SF_Type *sfrp = sfp->sf;
  uint32_t cmd_r = 0, cmd_d = 0;

  cmd_r |= SF_DATA_CNT(len);
  cmd_r |= SF_CMD_WIDTH(40);
  cmd_r |= sfp->config->cs << 4;
  cmd_r |= SF_CMD_READ;
  cmd_r |= SF_CMD_KEEPCS;

  cmd_d |= SF_CMD_FTRD;
  cmd_d |= offset & 0xffffff;

  sf_clear(sfp);
  sfrp->COMMAND_DATA0_REG = cmd_d;
  sfrp->COMMAND_DATA1_REG = 0;
#if defined(BR3215)
  if ((uint32_t)rdbuf >= (uint32_t)__ilm_base__) {
    sfrp->ADDRESS_REG = (uint32_t)m_sf_dma_buf;
  }
  else {
    sfrp->ADDRESS_REG = (uint32_t)rdbuf;
  }
#else
  sfrp->ADDRESS_REG = (uint32_t)rdbuf;
#endif
  sfrp->COMMAND = cmd_r;

  sf_wait(sfp);

#if defined(BR3215)
  if ((uint32_t)rdbuf >= (uint32_t)__ilm_base__) {
    memcpy(rdbuf, m_sf_dma_buf, len);
  }
#endif
}

void sf_page_write(SFDriver *sfp, uint32_t offset, void *wrbuf, size_t len) __ONCHIP_CODE__;
void sf_page_write(SFDriver *sfp, uint32_t offset, void *wrbuf, size_t len) {
  HS_SF_Type *sfrp = sfp->sf;
  const SFlashInfo_t *sfinfop = sfp->sfinfo;
  uint32_t status, cmd_r = 0, cmd_d = 0;

  if(len > sfinfop->page_size || len == 0) {
    return ;
  }

#if defined(BR3215)
  if ((uint32_t)wrbuf >= (uint32_t)__ilm_base__) {
    memcpy(m_sf_dma_buf, wrbuf, len);
    #if defined(__nds32__) && NDS_HAS_dCACHE
    nds32_dcache_clean();
    #endif
  }
#endif

  sf_write_enable(sfp);

  cmd_r |= SF_DATA_CNT(len);
  cmd_r |= SF_CMD_WIDTH(32);
  cmd_r |= sfp->config->cs << 4;
  cmd_r |= SF_CMD_WRITE;
  cmd_r |= SF_CMD_KEEPCS;

  cmd_d |= SF_CMD_PP;
  cmd_d |= offset & 0xffffff;

  sf_clear(sfp);
  sfrp->COMMAND_DATA0_REG = cmd_d;
#if defined(BR3215)
  if ((uint32_t)wrbuf >= (uint32_t)__ilm_base__) {
    sfrp->ADDRESS_REG = (uint32_t)m_sf_dma_buf;
  }
  else {
    sfrp->ADDRESS_REG = (uint32_t)wrbuf;
  }
#else
  sfrp->ADDRESS_REG = (uint32_t)wrbuf;
#endif
  sfrp->COMMAND = cmd_r;

  sf_wait(sfp);

  while(1) {
    status = sf_read_status(sfp);
    if((status & SR_WIP) == 0) {
      break;
    }
  }
}

/*===========================================================================*/
/* Driver interrupt handlers.                                                */
/*===========================================================================*/
/**
 * @brief   SF interrupt handler.
 *
 * @isr
 */
OSAL_IRQ_HANDLER(SF_IRQHandler) {

  OSAL_IRQ_PROLOGUE();

  osalDbgCheck(NULL != NULL);

  OSAL_IRQ_EPILOGUE();
}
/*===========================================================================*/
/* Driver exported functions.                                                */
/*===========================================================================*/

/**
 * @brief   Low level SF driver initialization.
 *
 * @notapi
 */
void sf_lld_init(void) {

#if HS_SF_USE_SF0
  /* Driver initialization.*/
  sfObjectInit(&SFD);

  SFD.sf = HS_SF;
  SFD.timeout = TIME_INFINITE;
  HS_SF->INTR_MASK = 0;
#endif /* HS_SF_USE_SF0 */
}

#define SF_USE_QUAD_96MHZ			FALSE

/**
 * @brief   Configures and activates the SF peripheral.
 *
 * @param[in] sfp      pointer to the @p SFDriver object
 *
 * @notapi
 */
int __ONCHIP_CODE__ sf_lld_start(SFDriver *sfp)
{
  const SFConfig *sfcp;
  HS_SF_Type *sfrp;
  uint32_t config;
  uint32_t speed;

  sfcp = sfp->config;
  sfrp = sfp->sf;
  config = 0;

  if (sfcp == NULL) {
    return -1;
  }

  speed = sfcp->speed;
  #if defined(BR3215) || defined(BR3215e)
  if (cpm_is_test_ng_mode()) {
    speed = 64000000;
  }
  #endif
  if (sfp->state == SF_STOP) {
    uint32_t divider;

    nvicDisableVector(SF_IRQn);

    sfrp->INTR_MASK = 0;
    sfrp->RAW_INTR_STATUS = SF_INTR_CLRSTS;
    sfp->mid = sf_read_mid(sfp);
    if (0x85/*puya*/ == (sfp->mid >> 16)) {
      //sf_reset_flash(sfp);
      sf_read_uid(sfp);
    }

    if ((0xBBBB == HS_SF->READ_OPCODE_REG)/*BR3215*/ ||
        (0x3B3B == HS_SF->READ_OPCODE_REG)/*BR3215c*/) {
      sf_lld_QuadEn(sfp, QUAD_ENABLE);
    }
#if (SF_USE_QUAD_96MHZ == FALSE)
    if ((96000000 == speed) &&
        (0xEBEB == HS_SF->READ_OPCODE_REG)) {
    	speed = 48000000;
    }
#endif

    /* don't call cpm_get_clock() */
    if(speed == 64000000) {
      cpm_set_clock(HS_SF_CLK, 64000000);
      sfp->clock = 64000000;
    }
    else {
      cpm_set_clock(HS_SF_CLK, 96000000);
      sfp->clock = 96000000;
    }

	config |= WIDTH_8BIT << 16;
	config |= CLKMODE_0 << 8;
	/* limitation: divider must be even; minimum divider is 2 */
	divider = DIV_ROUND_UP(sfp->clock, speed) / 2 * 2;
	if (divider < 2)
	  divider = 2;
	if (divider > 0xff)
	  divider = 0xff;
	/* the wanted speed vs. the true master clock */
	sfp->mclk = sfp->clock / divider;
	config |= divider;

	if(speed == 48000000)
	  config |= (1u << 12);
    else if((speed == 96000000) || (speed == 64000000))
	{
#if (SF_USE_CLK_DELAY_IN_CPM == FALSE)
	  config |= (4u << 12);
#endif
	  config |= (1u << 10);
      sfp->mclk = sfp->clock;
	}

    if (0 == sfcp->cs) {
      sfrp->CS_CONFIGURATION_0 = 0x1010100;
      sfrp->CONFIGURATION_0 = config;
#if defined(BR3215)
      /* don't call sf_inner_select() */
      HS_PMU->BASIC |= (1u<<3);  //inner
      HS_PMU->BASIC |= (1u<<30); //update
#endif
    }
#if !defined(BR3215)
    else if (1 == sfcp->cs) {
      sfrp->CS_CONFIGURATION_1 = 0x1010100;
      sfrp->CONFIGURATION_1 = config;
    }
    else if (2 == sfcp->cs) {
      sfrp->CS_CONFIGURATION_2 = 0x1010100;
      sfrp->CONFIGURATION_2 = config;
    }
    else if (3 == sfcp->cs) {
      sfrp->CS_CONFIGURATION_3 = 0x1010100;
      sfrp->CONFIGURATION_3 = config;
    }
#endif
  }

#if defined(BR3215c)
  HS_PMU->PADC_CSF |= 1<<17; // pulldown so
#endif
  return 0;
}

/**
 * @brief   Deactivates the SF peripheral.
 *
 * @param[in] sfp      pointer to the @p SFDriver object
 *
 * @notapi
 */
int sf_lld_stop(SFDriver *sfp) {

  if (sfp->state != SF_STOP) {
    nvicDisableVector(SF_IRQn);
    sfp->sf->INTR_MASK = 0;
  }

  return 0;
}

/**
 * @brief   probe spi flash.
 *
 * @param[in] sfp      pointer to the @p SFDriver object
 *
 * @notapi
 */
int sf_lld_probe(SFDriver *sfp) {
  uint32_t mid, i;

  if ((0 == sfp->mid) || (0xffffff == sfp->mid)) {
    mid = sf_read_mid(sfp);
    sfp->mid = mid;
  }
  mid = sfp->mid;

  for(i = 1; i < g_SFCnt; i++) {
    if (mid == g_SFInfo[i].mid) {
      sfp->sfinfo = &g_SFInfo[i];
      return 0;
    }
  }

  if(((mid & 0xffffff) == 0xffffff) || ((mid & 0xffffff) == 0)) {
    sfp->sfinfo = NULL;
    return -1;
  }

  sfp->sfinfo = &g_SFInfo[0];
  return 1;
}

/**
 * @brief   erase spi flash.
 *
 * @param[in] sfp      pointer to the @p SFDriver object
 * @param[in] offset   flash base address erased
 * @param[in] len      erase length
 *
 * @notapi
 */
int sf_lld_erase(SFDriver *sfp, uint32_t offset, size_t len) {
  const SFlashInfo_t *sfinfop = sfp->sfinfo;
  uint32_t i, h_len, t_len, setor_num = 0;

  if(sfp->sfinfo == NULL) {
    return -1;
  }

  if(len == 0) {
    /* don't support chip erase yet */
    return 0;
  }

#if defined(__nds32__) && NDS_HAS_dCACHE
  nds32_dcache_flush();
#endif

  if(len < sfinfop->sector_size) {
    setor_num = 1;
  }
  else {  
    h_len = offset & (sfinfop->sector_size - 1);

    if(h_len) {
      setor_num ++;
      h_len = sfinfop->sector_size - h_len;
    }
    else {
      h_len = 0;
    }

    t_len = (offset + len) & (sfinfop->sector_size - 1);

    if(t_len) {
      setor_num ++;
    }

    setor_num += (len - h_len - t_len) / sfinfop->sector_size;
  }

  for(i = 0; i < setor_num; i++) {
    sf_sector_erase(sfp, offset);
    offset += sfinfop->sector_size;
  }

  return 0;
}

/**
 * @brief   read spi flash.
 *
 * @param[in] sfp      pointer to the @p SFDriver object
 * @param[in] offset   flash base address erased
 * @param[in] rdbuf    data buffer, must alignment with 4bytes
 * @param[in] len      read length
 *
 * @notapi
 */
int sf_lld_read(SFDriver *sfp, uint32_t offset, void *rdbuf, size_t len) {
  char *bufp;
  uint32_t i, cnt, transLen;

  if(sfp->sfinfo == NULL) {
    return -1;
  }

#if defined(__nds32__) && NDS_HAS_dCACHE
  nds32_dcache_flush();
#endif

  bufp = rdbuf;

  if(len % SFLASH_PAGE_SIZE)
    cnt = len / SFLASH_PAGE_SIZE + 1;
  else
    cnt = len / SFLASH_PAGE_SIZE;

  for(i = 0; i < cnt; i++) {
    if(len > SFLASH_PAGE_SIZE)
      transLen = SFLASH_PAGE_SIZE;
    else
      transLen = len;

    sf_read(sfp, offset, bufp, transLen);

    offset += transLen;
    bufp += transLen;
    len -= transLen;
  }

  return 0;
}

/**
 * @brief   write spi flash.
 *
 * @param[in] sfp      pointer to the @p SFDriver object
 * @param[in] offset   flash base address erased
 * @param[in] wrbuf    data buffer, must alignment with 4bytes
 * @param[in] len      read length
 *
 * @notapi
 */
int sf_lld_write(SFDriver *sfp, uint32_t offset, void *wrbuf, size_t len) {
  char *bufp;
  const SFlashInfo_t *sfinfop = sfp->sfinfo;
  uint32_t i, cnt, transLen;

  if(sfp->sfinfo == NULL) {
    return -1;
  }

#if defined(__nds32__) && NDS_HAS_dCACHE
  nds32_dcache_flush();
#endif

  bufp = wrbuf;

  if(offset % sfinfop->page_size) {
    transLen = sfinfop->page_size - (offset % sfinfop->page_size);

    transLen = len > transLen ? transLen : len;

    sf_page_write(sfp, offset, bufp, transLen);

    offset += transLen;
    bufp += transLen;
    len -= transLen;

    if(len == 0)
      goto write_exit;
  }

  if(len % sfinfop->page_size)
    cnt = len / sfinfop->page_size + 1;
  else
    cnt = len / sfinfop->page_size;

  for(i = 1; i <= cnt; i++) {
    if(len > sfinfop->page_size)
      transLen = sfinfop->page_size;
    else
      transLen = len;

    sf_page_write(sfp, offset, bufp, transLen);

    offset += transLen;
    bufp += transLen;
    len -= transLen;
  }

write_exit:
  return 0;
}

void sf_lld_QuadEn(SFDriver *sfp, sfqe_t qe) __ONCHIP_CODE__;
void sf_lld_QuadEn(SFDriver *sfp, sfqe_t qe){
  HS_SF_Type *sfrp = sfp->sf;
  uint32_t status;
  uint8_t mid = sfp->mid >> 16;

  //return;//BR3215c COB
  if ((mid != 0xc8/*GD*/) && (mid != 0xe0/*boya*/) && (mid != 0xEF/*WB*/) && (mid != 0x85/*puya*/) && (mid != 0x0b/*xtx*/) && (mid != 0xEB/*tx*/))
    return;

  sf_write_enable(sfp);

  status = sf_read_status(sfp);
  if(QUAD_DISABLE == qe) {
    sf_write_status(sfp, status & ~SR_QE);
  }
  else {
    sf_write_status(sfp, status | SR_QE);
  }

  status = sf_read_status(sfp);
  if (status & SR_QE) {
    sfrp->READ_OPCODE_REG = 0xEBEB;
#if defined(BR3215)
    sfrp->CONFIGURATION_1 &= ~(1u << 10); //EB
#endif
  }
  else {
#if defined(BR3215)
    sfrp->READ_OPCODE_REG = 0xBBBB;
    sfrp->CONFIGURATION_1 |= (1u << 10); //BB->3B; EB->6B(not functional)
#else
    sfrp->READ_OPCODE_REG = 0x3B3B;
#endif
  }
}

#endif /* HAL_USE_SF */

/** @} */
