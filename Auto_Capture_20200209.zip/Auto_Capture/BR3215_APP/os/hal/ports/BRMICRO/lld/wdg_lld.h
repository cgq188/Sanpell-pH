/*
    ChibiOS - Copyright (C) 2016 Stephane D'Alu
              Copyright (C) 2019 BRMICRO Technologies
              

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    wdg_lld.h
 * @brief   WDG Driver subsystem low level driver header.
 *
 * @addtogroup WDG
 * @{
 */

#ifndef _WDG_LLD_H_
#define _WDG_LLD_H_

#if (HAL_USE_WDG == TRUE) || defined(__DOXYGEN__)

/*===========================================================================*/
/* Driver constants.                                                         */
/*===========================================================================*/

#define WDG_MAX_TIMEOUT_MS 67000
#define HS_WDT_TOP_MAX	   15
#define HS_WDT_FREQ        32000

/*===========================================================================*/
/* Driver pre-compile time settings.                                         */
/*===========================================================================*/

/**
 * @name    Configuration options
 * @{
 */
/**
 * @brief   SDHC interrupt priority level setting.
 */
#if !defined(HS_WDT_IRQ_PRIORITY) || defined(__DOXYGEN__)
#define HS_WDT_IRQ_PRIORITY                    3
#endif

/**
 * @brief   WDG driver implement timeout callback.
 * @note    The default is @p FALSE.
 */
#if !defined(WDG_USE_TIMEOUT_CALLBACK) || defined(__DOXYGEN__)
#define WDG_USE_TIMEOUT_CALLBACK               FALSE
#endif
/** @} */

/*===========================================================================*/
/* Derived constants and error checks.                                       */
/*===========================================================================*/

/*===========================================================================*/
/* Driver data structures and types.                                         */
/*===========================================================================*/

/**
 * @brief   Type of a structure representing an WDG driver.
 */
typedef struct WDGDriver WDGDriver;

/**
 * @brief   Driver configuration structure.
 * @note    It could be empty on some architectures.
 */
typedef struct {
  /**
   *
   */
  uint32_t timeout_ms;
#if WDG_USE_TIMEOUT_CALLBACK == TRUE
  /**
   * @brief  Notification callback when watchdog timedout
   *
   * @note   About 2 cycles at NRF5_LFCLK_FREQUENCY are available
   *         before automatic reboot.
   *
   */
  void (*callback)(void);
#endif
} WDGConfig;

/**
 * @brief   Structure representing an WDG driver.
 */
struct WDGDriver {
  /**
   * @brief   Driver state.
   */
  wdgstate_t                state;
  /**
   * @brief   Current configuration data.
   */
  const WDGConfig           *config;
  /* End of the mandatory fields.*/
  /**
   * @brief   Pointer to the WDG registers block.
   */
  HS_WDT_Type               *wdt;
};

/*===========================================================================*/
/* Driver macros.                                                            */
/*===========================================================================*/

/*===========================================================================*/
/* External declarations.                                                    */
/*===========================================================================*/

extern WDGDriver WDGD0;

#ifdef __cplusplus
extern "C" {
#endif
  void wdg_lld_init(void);
  void wdg_lld_start(WDGDriver *wdgp);
  void wdg_lld_stop(WDGDriver *wdgp);
  void wdg_lld_reset(WDGDriver *wdgp);
#ifdef __cplusplus
}
#endif

#endif /* HAL_USE_WDG == TRUE */

#endif /* _WDG_LLD_H_ */

/** @} */
