/*
    ChibiOS/RT - Copyright (C) 2006-2013 Giovanni Di Sirio
    PengJiang, 20140710
    luwei, 201704

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    usb_lld.c
 * @brief   USB device subsystem low level driver source.
 *
 * @addtogroup USB
 * @{
 */

#include <string.h>
#include "hal.h"

#if HAL_USE_USB || HAL_USE_USBH || defined(__DOXYGEN__)

#if HS_TRACE_USB
#define TRACE_BUF_SIZE 2048
char usb_trace_buf[TRACE_BUF_SIZE];
int usb_trace_idx;
static char hex2char[]={'0', '1', '2', '3', '4', '5', '6', '7',
                        '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};
void usb_trace(char c, uint8_t n)
{
  if ((usb_trace_idx+3) > TRACE_BUF_SIZE) {
    usb_trace_idx = 0;
  }
  usb_trace_buf[usb_trace_idx++] = c;
  usb_trace_buf[usb_trace_idx++] = hex2char[(n>>4)&0xf];
  usb_trace_buf[usb_trace_idx++] = hex2char[n&0xf];
  usb_trace_buf[usb_trace_idx] = '!';
}
void usb_trace_setup(char c, uint8_t *setup)
{
  int i;
  if ((usb_trace_idx+9) > TRACE_BUF_SIZE) {
    usb_trace_idx = 0;
    memset(usb_trace_buf, 0, TRACE_BUF_SIZE);
  }
  usb_trace_buf[usb_trace_idx++] = c;
  for (i=0; i<8; i++) {
    uint8_t n=setup[i];
    usb_trace_buf[usb_trace_idx++] = hex2char[(n>>4)&0xf];
    usb_trace_buf[usb_trace_idx++] = hex2char[n&0xf];
  }
  usb_trace_buf[usb_trace_idx] = '!';
}
void usb_trace_prefix(char c, uint8_t n)
{
  usb_trace_buf[usb_trace_idx++] = ' ';
  usb_trace(c, n);
}
#endif

/*===========================================================================*/
/* Driver local definitions.                                                 */
/*===========================================================================*/

/*===========================================================================*/
/* Driver exported variables.                                                */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local variables and types.                                         */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local functions.                                                   */
/*===========================================================================*/

/*===========================================================================*/
/* Driver interrupt handlers and threads.                                    */
/*===========================================================================*/

/**
 * @brief   USB dual-role controller interrupt handler.
 *
 * @isr
 */
OSAL_IRQ_HANDLER(USB_IRQHandler)
{
  OSAL_IRQ_PROLOGUE();

  /* read to clear interrupt */
  uint8_t intr_usb = HS_USB->INTR_USB;

  if (intr_usb & USB_INTR_VBUS_ERROR) {
    usbdrc_disconnect_vbus();
    OSAL_IRQ_EPILOGUE();
    return;
  }

  if (usbdrc_get_vbus() || (intr_usb & USB_INTR_RESET) ||
      ((intr_usb & USB_INTR_DISCONNECT) && (USB_ACTIVE == USBD0.state))) {
    /* PC VBUS is ready */
    #if HAL_USE_USB
    usbd_lld_serve_interrupt(&USBD0, intr_usb);
    #endif
  }
  else {
    /* usb device's power supply is VBAT */
    #if HAL_USE_USBH
    osalSysLockFromISR();
    usbh_lld_serve_interrupt(&USBHD0, intr_usb);
    osalSysUnlockFromISR();
    #endif
  }

  OSAL_IRQ_EPILOGUE();
}

OSAL_IRQ_HANDLER(USBDMA_IRQHandler) {
  OSAL_IRQ_PROLOGUE();

  if (usbdrc_get_vbus()) {
    #if HAL_USE_USB
    usbd_lld_serve_interrupt_dma(&USBD0);
    #endif
  }
  else {
    #if HAL_USE_USBH
    osalSysLockFromISR();
    //usbh_lld_serve_interrupt_dma(&USBHD0);
    osalSysUnlockFromISR();
    #endif
  }

  OSAL_IRQ_EPILOGUE();
}


/*===========================================================================*/
/* Driver exported functions.                                                */
/*===========================================================================*/

void usbdrc_reset_core(void)
{
  /* enable clock and reset.*/
  nvicDisableVector(USB_IRQn);
  cpmDisableUSB();
  cpmResetUSB();
  cpmEnableUSB();

  osalSysPolledDelayX(24);

  /* Make sure the FIFOs are flushed. */
  usbdrc_flush_fifo();

  #if defined(hscAudiophile)
  /* interrupt SOF will hurt usbh */
  HS_USB->INTR_USBEN = (usbdrc_get_vbus() ? 0xff : 0xf7);
  #else
  /* BR3215A3's vbus detect is unstable? */
  HS_USB->INTR_USBEN = 0xff; /* enable all interrupts, including SOF */
  #endif
  HS_USB->INTR_RXEN = 0;
  HS_USB->INTR_TXEN = 0x0001; /* EP0 interrupt */

  /* Enables IRQ vector.*/
  nvicEnableVector(USB_IRQn, HS_USB_USB0_IRQ_PRIORITY);
  nvicEnableVector(USB_DMA_IRQn, HS_USB_USB0_DMA_IRQ_PRIORITY);
}

#endif /* HAL_USE_USB */
