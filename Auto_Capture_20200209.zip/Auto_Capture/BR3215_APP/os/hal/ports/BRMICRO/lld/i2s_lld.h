/*
    ChibiOS/RT - Copyright (C) 2006-2013 Giovanni Di Sirio
                 Copyright (C) 2019 BRMICRO Technologies
                 
                 
                 

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    br32xx/i2s_lld.h
 * @brief   audio interface Driver subsystem low level driver header template.
 *
 * @addtogroup I2S
 * @{
 */

#ifndef _I2S_LLD_H_
#define _I2S_LLD_H_

#if HAL_USE_AUDIO || defined(__DOXYGEN__)

#include "dma_lld.h"

/*===========================================================================*/
/* Driver constants.                                                         */
/*===========================================================================*/

#define HS_I2S_MCLK               24000000

/*===========================================================================*/
/* Driver pre-compile time settings.                                         */
/*===========================================================================*/

/**
 * @name    Configuration options
 * @{
 */


/** @} */

/*===========================================================================*/
/* Derived constants and error checks.                                       */
/*===========================================================================*/


/**
 * @brief   I2S interrupt priority level setting.
 */
#if !defined(HS_I2S_IRQ_PRIORITY) || defined(__DOXYGEN__)
#define HS_I2S_IRQ_PRIORITY         3
#endif

#if !defined(HS_I2S_DMA_PRIORITY) || defined(__DOXYGEN__)
#define HS_I2S_DMA_PRIORITY         3
#endif

/*===========================================================================*/
/* Driver data structures and types.                                         */
/*===========================================================================*/

struct hs_audio_config; //audio.h
typedef struct hs_audio_config hs_audio_config_t;

/**
 * @brief   Structure representing an I2S driver.
 * @note    Implementations may extend this structure to contain more,
 *          architecture dependent, fields.
 */
typedef struct
{
  HS_I2S_Type            *rx_i2s;
  HS_I2S_Type            *tx_i2s;
} I2SDriver;

/*===========================================================================*/
/* Driver macros.                                                            */
/*===========================================================================*/


#define __i2s_clr_bit(val, bit)            (val) &= ~(1u<<bit)
#define __i2s_set_bit(val, bit)            (val) |= (1u<<bit)

#define __i2s_set_bitval(val, bit, bitval)        \
do{                                                 \
  uint32_t mask;                                    \
  mask = 1u<<(bit);                                 \
  (val) = ((val)&~mask) | (((bitval)<<(bit))&mask); \
}while(0)

#define __i2s_set_bitsval(val, s, e, bitval)      \
do{                                                 \
  uint32_t mask;                                    \
  mask = ((1u<<((e)-(s)+1)) - 1) << (s);              \
  (val) = ((val)&~mask) | (((bitval)<<(s))&mask);   \
}while(0)

#define __i2s_set_rxsamplewidth(i2sp, width)      (i2sp)->CHN_R0.RCR = (width)
#define __i2s_set_txsamplewidth(i2sp, width)      (i2sp)->CHN_R0.TCR = (width)
#define __i2s_set_workmode(i2sp, mode)            __i2s_set_bitval((i2sp)->CER, 0, mode)
#define __i2s_set_i2smode(i2sp, mode)             __i2s_set_bitval((i2sp)->IER, 4, mode)

#define __i2s_set_enable(i2sp, en)                __i2s_set_bitval((i2sp)->IER, 0, en)

#define __i2s_enable_rx(i2sp, en)                 (i2sp)->IRER = (en)
#define __i2s_enable_tx(i2sp, en)                 (i2sp)->ITER = (en)

#define __i2s_enable_rxChn(i2sp, en)              (i2sp)->CHN_R0.RER = (en)
#define __i2s_enable_txChn(i2sp, en)              (i2sp)->CHN_R0.TER = (en)

#define __i2s_set_rxFifoDepth(i2sp, depth)        (i2sp)->CHN_R0.RFCR = (depth)
#define __i2s_set_txFifoDepth(i2sp, depth)        (i2sp)->CHN_R0.TFCR = (depth)

#define __i2s_mask_allInt(i2sp)                   (i2sp)->CHN_R0.IMR = 0x33
#define __i2s_unmask_allInt(i2sp)                 (i2sp)->CHN_R0.IMR = 0

#define __i2s_flush_rxFifo(i2sp)                  (i2sp)->CHN_R0.RFF = 1
#define __i2s_flush_txFifo(i2sp)                  (i2sp)->CHN_R0.TFF = 1

#define __i2s_reset_allRxFifo(i2sp)               (i2sp)->RXFFR = 1
#define __i2s_reset_allTxFifo(i2sp)               (i2sp)->TXFFR = 1

#define __i2s_set_wss(i2sp, val)                  __i2s_set_bitsval((i2sp)->CCR, 3, 4, val)   /*(i2sp)->i2s->CCR |= (val) << 3*/
#define __i2s_set_sclkGate(i2sp, val)             __i2s_set_bitsval((i2sp)->CCR, 0, 2, val)   /*(i2sp)->i2s->CCR |= (val) << 0*/

#define __i2s_reset_rxDma(i2sp)                   (i2sp)->RRXDMA = 1
#define __i2s_reset_txDma(i2sp)                   (i2sp)->RTXDMA = 1

/* output function */
#define i2s_lld_play_triger(i2sp)                 dmaStreamStartByLli((i2sp)->pdmatx);
/*===========================================================================*/
/* External declarations.                                                    */
/*===========================================================================*/

#if !defined(__DOXYGEN__)
extern I2SDriver I2SD;
#endif


#ifdef __cplusplus
extern "C" {
#endif

  void i2s_lld_init(void);
  void i2s_lld_start(I2SDriver *i2sp);
  void i2s_lld_stop(I2SDriver *i2sp);

  int32_t i2s_lld_record_start(I2SDriver *i2sp, hs_audio_config_t *cfgp);
  int32_t i2s_lld_record_stop(I2SDriver *i2sp);

  int32_t i2s_lld_play_start(I2SDriver *i2sp, hs_audio_config_t *cfgp);
  int32_t i2s_lld_play_stop(I2SDriver *i2sp);

#ifdef __cplusplus
}
#endif

#endif /* HAL_USE_AUDIO */

#endif /* _I2S_LLD_H_ */

/** @} */
