/*
    ChibiOS/RT - Copyright (C) 2006-2013 Giovanni Di Sirio
    PengJiang, 20140710
    luwei, 201704

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    usb_lld.c
 * @brief   USB device subsystem low level driver source.
 *
 * @addtogroup USB
 * @{
 */

#include <string.h>
#include "hal.h"

#if HAL_USE_USB || defined(__DOXYGEN__)

/*===========================================================================*/
/* Driver local definitions.                                                 */
/*===========================================================================*/

#define EP0_MAX_INSIZE          64
#define EP0_MAX_OUTSIZE         64

/*===========================================================================*/
/* Driver exported variables.                                                */
/*===========================================================================*/

/**
 * @brief   USB device driver identifier.
 */
#if HS_USB_USE_USB0 && !defined(__DOXYGEN__)
USBDriver USBD0;
#endif

/*===========================================================================*/
/* Driver local variables and types.                                         */
/*===========================================================================*/

/**
 * @brief   EP0 state.
 * @note    It is an union because IN and OUT endpoints are never used at the
 *          same time for EP0.
 */
static union {
  /**
   * @brief   IN EP0 state.
   */
  USBInEndpointState in;
  /**
   * @brief   OUT EP0 state.
   */
  USBOutEndpointState out;
} ep0_state;

/**
 * @brief   EP0 initialization structure.
 */
static const USBEndpointConfig ep0config = {
  USB_EP_MODE_TYPE_CTRL,
  USB_EP_MODE_TYPE_CTRL,
  _usb_ep0setup,
  _usb_ep0in,
  _usb_ep0out,
  0x40,
  0x40,
  &ep0_state.in,
  &ep0_state.out,
  0, 0,
  0, //0:single-packet buffering
};

/*===========================================================================*/
/* Driver local functions.                                                   */
/*===========================================================================*/

/**
 * @brief   Resets the FIFO RAM memory allocator.
 *
 * @param[in] usbp      pointer to the @p USBDriver object
 *
 * @notapi
 */
static void usb_fifo_ram_reset(USBDriver *usbp)
{
  usbp->ramnext = 0;
}

/**
 * @brief   Allocates a block from the FIFO RAM memory.
 *
 * @param[in] usbp      pointer to the @p USBDriver object
 * @param[in] size      size of the packet buffer to allocate in words
 *
 * @notapi
 */
static uint32_t usb_fifo_ram_alloc(USBDriver *usbp, size_t size, uint8_t dpb)
{
  uint32_t addr;

  addr = usbp->ramnext;
  usbp->ramnext += size * (dpb + 1);
  osalDbgAssert(usbp->ramnext <= USB_FIFO_MEM_SIZE,
                "FIFO memory overflow");

  return USB_FIFO_SZ(size) | USB_FIFO_DPB(dpb) | USB_FIFO_AD(addr);
}

static size_t usb_fifo_write(USBDriver *usbp, usbep_t ep, size_t n)
{
  const USBEndpointConfig *epcp = usbp->epc[ep];
  USBInEndpointState *isp = epcp->in_state;
  syssts_t sts;
  volatile uint32_t *txfifo = (volatile uint32_t *)&HS_USB->EPnFIFO[ep];
  uint32_t *src = (uint32_t *)isp->txbuf;
  uint8_t words, bytes;

  usb_trace_prefix('W', n);
  osalDbgCheck((n&0x0ff) != 0xf3);
  if (n == 0) {
    isp->last_tx_size = 0;
    return 0;
  }

  if (n > epcp->in_maxsize)
    n = epcp->in_maxsize;

  words = n >> 2;
  bytes = n;
  /* Must lock for entire operation to ensure nothing changes the ENUM value */
  sts = osalSysGetStatusAndLockX();
  if ((bytes & 3) || ((uint32_t)src & 3)) {
    volatile uint8_t *bdst = (volatile uint8_t *)txfifo;
    uint8_t *bsrc = (uint8_t *)src;
    while (bytes--) {
      *bdst = *bsrc++;
    }
  }
  else {
    while (words--) {
      *txfifo = *src++;
    }
  }
  isp->txbuf += n;
  isp->last_tx_size = n;
  osalSysRestoreStatusX(sts);
  return n;
}

static size_t usb_fifo_read(USBDriver *usbp, usbep_t ep, size_t n)
{
  const USBEndpointConfig *epcp = usbp->epc[ep];
  USBOutEndpointState *osp = epcp->out_state;
  syssts_t sts;
  volatile uint32_t *rxfifo = (volatile uint32_t *)&HS_USB->EPnFIFO[ep];
  uint32_t *dst = (uint32_t *)osp->rxbuf;
  uint8_t words, bytes;

  if (n > epcp->out_maxsize)
    n = epcp->out_maxsize;

  if ((NULL == osp->rxbuf) || (0 == (usbp->receiving & (1 << ep)))) {
    /* OUT interrupt occurs prior to start_out() */
    n = 0;
  }
  /* Fix AVR's bug which would destroy rxbuf */
  if ((epcp->out_state->rxsize > 0) &&
      (n > epcp->out_state->rxsize)) {
    n = epcp->out_state->rxsize;
  }

  usb_trace('R', n);
  if (n == 0) {
    return 0;
  }

  words = n >> 2;
  bytes = n;
  /* Must lock for entire operation to ensure nothing changes the ENUM value */
  sts = osalSysGetStatusAndLockX();
  if ((bytes & 3) || ((uint32_t)dst & 3)) {
    volatile uint8_t *bsrc = (volatile uint8_t *)rxfifo;
    uint8_t *bdst = (uint8_t *)dst;
    while (bytes--) {
      *bdst++ = *bsrc;
    }
  }
  else {
    while (words--) {
      *dst++ = *rxfifo;
    }
  }
  osp->rxbuf += n;
  if (0 == ep) {
    /* clear in usb_ep0_handler() */
    //HS_USB->CSR0 |= USB_CSR0_P_SERVICED_RXPKTRDY | USB_CSR0_P_DATAEND;
    //HS_USB->CSR0 |= USB_CSR0_P_SERVICED_RXPKTRDY;
  }
  else {
    /* Mark Rx FIFO processed to allow more data to be received */
    HS_USB->RXCSR &= ~USB_RXCSR_P_RXPKTRDY;
  }
  osalSysRestoreStatusX(sts);
  return n;
}

/*===========================================================================*/
/* Driver interrupt handlers and threads.                                    */
/*===========================================================================*/

static void usb_ep0_handler(USBDriver *usbp, uint16_t csr0)
{
  uint8_t ep = 0;
  const USBEndpointConfig *epcp = usbp->epc[ep];

  /* Know-how: unsupport setup command DeviceQualifier,
     hw has sent a STALL to host at status stage */
  if (csr0 & USB_CSR0_P_SENTSTALL) {
    bool out = (USB_EP0_RX == usbp->ep0state) ? true : false;
    usb_trace('S', csr0 + (usbp->ep0state<<4));
    usb_lld_clear_in(usbp, ep);
    if (out) {
      usbp->ep0state = USB_EP0_WAITING_STS;
      _usb_isr_invoke_out_cb(usbp, ep);
    }
    else {
      usbp->ep0state = USB_EP0_SENDING_STS;
      _usb_isr_invoke_in_cb(usbp, ep);
    }
    return;
  }
  /* disable this assert because the next setup packet may arrival if high CPU load */
  //osalDbgAssert(!(csr0 & USB_CSR0_P_SETUPEND), "EP0 setup end!");
  if (csr0 & USB_CSR0_P_SETUPEND) {
    usb_trace('X', csr0);
    /* sw set ServicedSetupEnd to clear SetupEnd */
    HS_USB->CSR0 |= USB_CSR0_P_SERVICED_SETUPEND;
    /* double buffering, FlushFIFO has no effect unless TxPktRdy/RxPktRdy is set. */
    HS_USB->CSR0 |= USB_CSR0_FLUSHFIFO;
    HS_USB->CSR0 |= USB_CSR0_FLUSHFIFO;
    //return;
  }

  if (usbp->ep0state == USB_EP0_WAITING_SETUP) {
    osalDbgAssert((csr0 & USB_CSR0_P_RXPKTRDY), "EP0 no RxPktRdy during setup!");
    /* Received SETUP data */
    /* Reset transaction state for endpoint */
    epcp->in_state->txcnt = 0;
    epcp->in_state->txsize = 0;
    epcp->in_state->last_tx_size = 0;
    /* Setup packets handling, setup packets are handled using a
       specific callback.*/
    _usb_isr_invoke_setup_cb(usbp, ep);
  }
  else if (usbp->ep0state == USB_EP0_SENDING_STS) {
    /* Zero Data Requests: when host moves to the status stage, In ZLP */
    usb_trace('Z', csr0);
    /* disable this assert because the next setup packet may arrival if high CPU load,
       such as set volume during play usb audio */
    //osalDbgAssert(!(csr0 & USB_CSR0_P_RXPKTRDY), "EP0 RxPktRdy during tx/in ZLP!");
    /* call ep0endcb(), such as set_address() */
    _usb_isr_invoke_in_cb(usbp, ep);
  }
  /* Received OUT data from host */
  else if (usbp->ep0state == USB_EP0_WAITING_STS) {
    /* Read Requests: when host moves to the status stage, Out ZLP */
    usb_trace('z', csr0);
    /* SETUP/control transaction complete, invoke the callback. */
    _usb_isr_invoke_out_cb(usbp, ep);

    /* Know-how: EP0's RxPktRdy occurs due to the next Setup pkt comes */
    //osalDbgAssert(!(csr0 & USB_CSR0_P_RXPKTRDY), "EP0 RxPktRdy during rx/out ZLP!");
    if (csr0 & USB_CSR0_P_RXPKTRDY) {
      /* Received SETUP data */
      /* Reset transaction state for endpoint */
      epcp->in_state->txcnt = 0;
      epcp->in_state->txsize = 0;
      epcp->in_state->last_tx_size = 0;
      /* Setup packets handling, setup packets are handled using a
         specific callback.*/
      _usb_isr_invoke_setup_cb(usbp, ep);
    }
  }
  else if (csr0 & USB_CSR0_P_RXPKTRDY) {
    /* Check the FIFO byte count to see how many bytes were received */
    size_t n = HS_USB->COUNT0;

    n = usb_fifo_read(usbp, ep, n);

    /* sw set ServiceRxPktRdy to clear RxPktRdy bit;
       sw set DataEnd when clearing RxPktRdy after unloading the last data packet. */

    /* Transaction state update */
    epcp->out_state->rxcnt += n;
    epcp->out_state->rxsize -= n;
    if (n > 0)
      epcp->out_state->rxpkts -= 1;
    if (n < epcp->out_maxsize || epcp->out_state->rxpkts == 0) {
      /* Mark Rx FIFO processed to allow more data to be received */
      /* no more data is expected */
      HS_USB->CSR0 |= USB_CSR0_P_SERVICED_RXPKTRDY | USB_CSR0_P_DATAEND;
      usb_trace('D', epcp->out_state->rxcnt);
      /* Transfer complete, invokes the callback.*/
      _usb_isr_invoke_out_cb(usbp, ep);
    } else {
      /* Mark Rx FIFO processed to allow more data to be received */
      HS_USB->CSR0 |= USB_CSR0_P_SERVICED_RXPKTRDY;
      usb_trace('P', epcp->out_state->rxcnt);
    }
  }
}

static void usb_tx_epin_handler(USBDriver *usbp, uint8_t ep)
{
  const USBEndpointConfig *epcp = usbp->epc[ep];
  size_t n;

  /* EP0,1,2,3 */
  HS_USB->INDEX = ep;

  if (0 == ep) {
    uint16_t csr0 = HS_USB->CSR0;
    usb_trace('0'+usbp->ep0state, csr0);
    /* ep0: setup or out/rx */
    if ((usbp->ep0state != USB_EP0_TX) &&
        1)//(usbp->ep0state != USB_EP0_SENDING_STS))
      return usb_ep0_handler(usbp, csr0);

    /* ep0: in/tx */
  }

  if (ep) {
    uint16_t txcsr = HS_USB->TXCSR;
    usb_trace('0'+ep, txcsr);
    /* TODO: if stalling is needed/expected remove this check */
    osalDbgAssert(!(txcsr & USB_TXCSR_P_SENTSTALL), "Endpoint tx stalled!");
    if (txcsr & USB_TXCSR_P_SENTSTALL) {
      usb_lld_clear_in(usbp, ep);
      usbp->transmitting &= ~(1 << ep);
      return;
    }

    /* disable this assert due to ep3 in iso */
    //osalDbgAssert(!(txcsr & USB_TXCSR_P_UNDERRUN), "Endpoint fifo underrun!");
    if (txcsr & USB_TXCSR_P_UNDERRUN) {
      HS_USB->TXCSR &= ~USB_TXCSR_P_UNDERRUN;
      HS_UART1->THR = 'u';
    }

    #if 1
    /* a dummy interrupt if DMA interrupt occured before? */
    if (epcp->in_state->txcnt >= epcp->in_state->txsize) {
      return;
    }
    #else
    osalDbgAssert(!(txcsr & USB_TXCSR_P_FIFONOTEMPTY), "Endpoint fifo not empty!");
    if (txcsr & USB_TXCSR_P_FIFONOTEMPTY) {
      /* double buffering */
      HS_USB->TXCSR |= USB_TXCSR_P_FLUSHFIFO;
      HS_USB->TXCSR |= USB_TXCSR_P_FLUSHFIFO;
    }
    #endif
    //osalDbgAssert(!(txcsr & USB_TXCSR_DMAMODE), "dma mode!");
  }
  else {
    uint16_t csr0 = HS_USB->CSR0;
    /* TODO: if stalling is needed/expected remove this check */
    osalDbgAssert(!(csr0 & USB_CSR0_P_SENTSTALL), "EP0 stalled!");
    if (csr0 & USB_CSR0_P_SENTSTALL) {
      usb_lld_clear_in(usbp, ep);
      return;
    }
  }

  /* Ready to accept more IN data to transmit to host */
  /* Update transaction counts to reflect newly transmitted bytes */
  epcp->in_state->txcnt += epcp->in_state->last_tx_size;
  n = epcp->in_state->txsize - epcp->in_state->txcnt;
  if (n > 0) {
    /* Transfer not completed, there are more packets to send. */
    usb_fifo_write(usbp, ep, n);

    /* sw sets this bit after loading a data packet into the FIFO;
       hw clears this bit when the data packet has been transmitted,
       also an interrupt is generated. */
    if (ep) {
      HS_USB->TXCSR |= USB_TXCSR_P_TXPKTRDY;
    }
    else {
      if (n <= epcp->in_maxsize) {
        /* sw set DataEnd when setting TxPktRdy for the last data packet or ZLP. */
        HS_USB->CSR0 |= USB_CSR0_P_TXPKTRDY | USB_CSR0_P_DATAEND;
        usb_trace('d', epcp->in_state->txcnt);
      }
      else {
        HS_USB->CSR0 |= USB_CSR0_P_TXPKTRDY;
        usb_trace('p', epcp->in_state->txcnt);
      }
    }
    /* Enable the TX complete interrupt */
    //HS_USB->INTTXEN |= (1 << ep);
  }
  else {
    /* Disable TXIN interrupt */
    //HS_USB->INTTXEN &= ~(1 << ep);
    /* hw clears TxPktRdy automatically */
    _usb_isr_invoke_in_cb(usbp, ep);
  }
}

static void usb_rx_epout_handler(USBDriver *usbp, uint8_t ep)
{
  const USBEndpointConfig *epcp = usbp->epc[ep];
  size_t n;

  osalDbgAssert(0 != ep, "ep0 must be in in/INTRTX, not in out/INTRRX");

  /* EP1,2,3 */
  HS_USB->INDEX = ep;

  usb_trace('C', HS_USB->RXCSR);
  if (HS_USB->RXCSR & USB_RXCSR_P_OVERRUN) {
    HS_USB->RXCSR &= ~USB_RXCSR_P_OVERRUN;
    HS_UART1->THR = 'o';
  }

  /* TODO: if stalling is needed/expected remove this check */
  osalDbgAssert(!(HS_USB->RXCSR & USB_RXCSR_P_SENTSTALL), "Endpoint rx stalled!");
  if (HS_USB->RXCSR & USB_RXCSR_P_SENTSTALL) {
    usb_lld_clear_out(usbp, ep);
    return;
  }

  /* disable this assert because ep2 interrupt in iso may lost */
  //osalDbgAssert(HS_USB->RXCSR & USB_RXCSR_P_RXPKTRDY, "RXPKTRDY is not set");
  if (0 == (HS_USB->RXCSR & USB_RXCSR_P_RXPKTRDY)) {
    return;
  }

  /* Check the FIFO byte count to see how many bytes were received */
  n = HS_USB->RXCOUNT;
  if (0 == n) {
    if (HS_USB->RXCSR & USB_RXCSR_P_FIFOFULL) {
      n = epcp->out_maxsize;
    }
    else {
      n = epcp->out_state->rxsize;
    }
  }
  n = usb_fifo_read(usbp, ep, n);
  if (0 == n) {
    /* to read fifo and clear RXPKTRDY in the first usbReceive()/start_out() */
    HS_USB->INTR_RXEN &= ~(1 << ep);
    return;
  }

  /* Transaction state update */
  epcp->out_state->rxcnt += n;
  epcp->out_state->rxsize -= n;
  if (n > 0)
    epcp->out_state->rxpkts -= 1;
  if (n < epcp->out_maxsize || epcp->out_state->rxpkts == 0) {
    /* Disable OUT interrupt in case of the next scsi command out of order */
    HS_USB->INTR_RXEN &= ~(1 << ep);
    usb_trace('D', epcp->out_state->rxcnt);
    /* Transfer complete, invokes the callback. But hw cannot raise irq when received ZLP? */
    _usb_isr_invoke_out_cb(usbp, ep);
    /* stop the monitor of zlp */
    usbp->zlp_mon_ep = 0;
    usbp->zlp_mon_count = 0;
  }
  else {
    /* start the monitor of zlp */
    usbp->zlp_mon_ep = ep;
  }
}

void usbd_lld_serve_interrupt(USBDriver *usbp, uint8_t int_usb)
{
  /* read to clear interrupt */
  uint16_t int_tx = HS_USB->INTR_TX;
  uint16_t int_rx = HS_USB->INTR_RX;
  uint8_t epnum_orig = 0;

#if HS_TRACE_USB
  if (int_usb & ~USB_INTR_SOF) {
    HS_UART1->THR='i';
    HS_UART1->THR='0'+(int_usb>>4);
    HS_UART1->THR='0'+(int_usb&0x0f);
    usb_trace_prefix('i', int_usb);
  }
  if (int_tx) {
    HS_UART1->THR='t';
    HS_UART1->THR='0'+(int_tx&0x0f);
    usb_trace_prefix('t', int_tx);
  }
  if (int_rx) {
    HS_UART1->THR='r';
    HS_UART1->THR='0'+(int_rx&0x0f);
    usb_trace_prefix('r', int_rx);
  }
#endif

  if (int_usb) {
    if (int_usb & USB_INTR_VBUS_ERROR) {
      //handle vbus error
    }
    if (int_usb & USB_INTR_SESS_REQ) {
      //handle session for OTG?
    }

    #if defined(hscAudiophile)
    extern void hs_pnp_emit_usbd_status(bool bOn);
    if (int_usb & USB_INTR_RESET) {
      hs_pnp_emit_usbd_status(true);
    }
    if (int_usb & USB_INTR_DISCONNECT) {
      hs_pnp_emit_usbd_status(false);
    }
    #endif

    /* disconnected when VBUS is off in hw */
    if (int_usb & USB_INTR_DISCONNECT) {
    	//printf("$#us2\r\n");
      _usb_reset(usbp); // disconnect
    }
    if (int_usb & USB_INTR_CONNECT) {
      /* FIXME */
    }

    /* Start-Of-Frame handling to flush output queue for serial_usb */
    if(int_usb & USB_INTR_SOF) {
      _usb_isr_invoke_sof_cb(usbp);
      if (usbp->config->sof_cb == NULL) {
        HS_USB->INTR_USBEN &= ~USB_INTR_SOF;
      }
      /* zlp monitor in sof */
      if (usbp->zlp_mon_ep > 0) {
        if (usbp->zlp_mon_count++ > 3) {
          _usb_isr_invoke_out_cb(usbp, usbp->zlp_mon_ep);
          usbp->zlp_mon_ep = 0;
          usbp->zlp_mon_count = 0;
        }
      }
    }

    /* received Reset signaling on bus */
    if (int_usb & USB_INTR_RESET) {
      /* FIXME: disable suspend interrupt, enable wakeup interrupt */
      /* FIXME: Reinitialize EP0. */

      //_usb_isr_invoke_event_cb(usbp, USB_EVENT_RESET);
    	//printf("$#us1\r\n");
      _usb_reset(usbp); // reset
      //HS_USB->POWER |= 0x01;//enable suspend for test

      /* Preventing execution of more handlers, the core has been reset.*/
      return;
    }

    if (int_usb & USB_INTR_RESUME) {
      uint8_t power = HS_USB->POWER;
      /* FIXME: unfreeze the clock */
      /* FIXME: disable wakeup interrupt, enable suspend interrupt */
      /* FIXME: clear the Remote Wake-up Signaling */

      if (!(power & USB_POWER_VBUSVAL)) {
        /* 0: VBUS below the VBUS Valid threshold */
        uint8_t int_usb_new = int_usb;
        int_usb_new |= USB_INTR_DISCONNECT;
        int_usb_new &= ~USB_INTR_SUSPEND;
        HS_USB->INTR_USB = int_usb_new;
      }
      //_usb_isr_invoke_event_cb(usbp, USB_EVENT_WAKEUP);
      _usb_wakeup(usbp);
    }

    if (int_usb & USB_INTR_SUSPEND) {
      /* FIXME: disable suspend interrupt, enable wakeup interrupt */
      /* FIXME: Freeze the USB core clock to reduce power consumption */

      //_usb_isr_invoke_event_cb(usbp, USB_EVENT_SUSPEND);
      _usb_suspend(usbp);
      //HS_SYS->USB_CTRL |= (0x1u<<8); //[8]usb_bus_mon_en=1, enable usb bus activity monitor
    }
  }

  if (int_rx || int_tx)
    epnum_orig = HS_USB->INDEX;

  if (int_rx) {
    uint8_t epnum;
    for (epnum = 0; epnum <= USB_MAX_ENDPOINTS; ++epnum) {
      if (int_rx & (1 << epnum)) {
        usb_rx_epout_handler(usbp, epnum);
      }
      #if defined(hscAudiophile)
      /* ep2 interrupt in iso may lost when play file in msd over usb audio */
      else if ((2 == epnum) && (usbp->epc[epnum]->out_state->rxpkts > 0)) {
        usb_rx_epout_handler(usbp, epnum);
      }
      #endif
    }
  }

  if (int_tx) {
    uint8_t epnum;
    for (epnum = 0; epnum <= USB_MAX_ENDPOINTS; ++epnum) {
      if (int_tx & (1 << epnum)) {
        usb_tx_epin_handler(usbp, epnum);
      }
    }
  }

  /* Restore endpoint selector to pre-interrupt state */
  if (int_rx || int_tx)
    HS_USB->INDEX = epnum_orig;
}

void usbd_lld_serve_interrupt_dma(USBDriver *usbp)
{
  uint32_t int_dma = HS_USB->DMA_INTR;
#if HS_TRACE_USB
  HS_UART1->THR='d';
  HS_UART1->THR='0'+int_dma;
  usb_trace_prefix('d', int_dma);
#endif

  uint8_t ch, ep, ep_saved;
  ep_saved = HS_USB->INDEX;
  for (ch = 0; ch <= HS_USB_NUM_DMA_CHANNELS; ++ch) {
    if (0 == (int_dma & (1 << ch))) continue;
    //usb_dma_ch_handler(usbp, ch);
    for (ep = 1; ep <= HS_USB_NUM_ENDPOINTS; ++ep) {
      const USBEndpointConfig *epcp = usbp->epc[ep];
      if (epcp) {
        if (ch == epcp->dma_ch_out) {
          HS_USB->INDEX = ep;
          usbdrc_handle_dma_out(ch);
          #if HS_TRACE_USB
          HS_UART1->THR='O';
          HS_UART1->THR='0' + ep;
          HS_UART1->THR='0' + ch;
          usb_trace_prefix('O', ep*16+ch);
          #endif
          epcp->out_state->rxpkts = 0;
          epcp->out_state->rxcnt = epcp->out_state->rxsize;
          _usb_isr_invoke_out_cb(usbp, ep);
        }
        else if (ch == epcp->dma_ch_in) {
          HS_USB->INDEX = ep;
          usbdrc_handle_dma_in(ch);
          #if HS_TRACE_USB
          HS_UART1->THR='I';
          HS_UART1->THR='0' + ep;
          HS_UART1->THR='0' + ch;
          usb_trace_prefix('I', ep*16+ch);
          #endif
          _usb_isr_invoke_in_cb(usbp, ep);
        }
      }
    } /* for ep */
  } /* for ch */
  HS_USB->INDEX = ep_saved;
}

/*===========================================================================*/
/* Driver exported functions.                                                */
/*===========================================================================*/

/**
 * @brief   Low level USB driver initialization.
 *
 * @notapi
 */
void usb_lld_init(void)
{
#if HS_USB_USE_USB0
  /* Driver initialization.*/
  usbObjectInit(&USBD0);
#endif
}

/**
 * @brief   Configures and activates the USB peripheral.
 *
 * @param[in] usbp      pointer to the @p USBDriver object
 *
 * @notapi
 */

void usb_lld_start(USBDriver *usbp)
{
  if (usbp->state == USB_STOP) {
    /* Clock activation.*/
#if HS_USB_USE_USB0
    if (&USBD0 == usbp) {
      /* FIXME: disable pad drivers as first step in case bootloader left it on. */
    }
#endif

    usbdrc_reset_core();

    /* Reset procedure enforced on driver start.*/
    //_usb_reset(usbp);
  }
}

/**
 * @brief   Deactivates the USB peripheral.
 *
 * @param[in] usbp      pointer to the @p USBDriver object
 *
 * @notapi
 */
void usb_lld_stop(USBDriver *usbp)
{
  if (usbp->state != USB_STOP) {

#if HS_USB_USE_USB0
    /* If in ready state then disables the USB clock.*/
    if (&USBD0 == usbp) {
      nvicDisableVector(USB_IRQn);
      nvicDisableVector(USB_DMA_IRQn);
      cpmDisableUSB();
    }
#endif
  }
}

/**
 * @brief   USB low level reset routine.
 *
 * @param[in] usbp      pointer to the @p USBDriver object
 *
 * @notapi
 */
void usb_lld_reset(USBDriver *usbp)
{
  /* Post-reset initialization.*/
  uint16_t fifo_setup;

  /* Set Device mode */
  /* TODO: Support HOST/OTG mode if needed */

  /* Flush the FIFOs.*/
  usbdrc_flush_fifo();

  /* Endpoint interrupts all disabled and cleared.*/
  HS_USB->INTR_USB;
  HS_USB->INTR_TX;
  HS_USB->INTR_RX;

  /* Resets the FIFO memory allocator.*/
  usb_fifo_ram_reset(usbp);

  /* Resets the device address to zero.*/
  HS_USB->FADDR = 0x00;

  /* Enables also EP-related interrupt sources.*/
  HS_USB->INTR_TXEN = 0x0001; /* EP0 interrupt */
  HS_USB->INTR_RXEN = 0x0000;
  /* keep the settings of INTR_USBEN because interrupt SOF will hurt usbh */

  /* EP0 initialization, it is a special case: w/o TXMAXP or RXMAXP */
  usbp->epc[0] = &ep0config;
  HS_USB->INDEX = 0;
  /* EP0's fifo size is always 64-byte? */
  fifo_setup = usb_fifo_ram_alloc(usbp, ep0config.in_maxsize, ep0config.dpb);
  HS_USB->TXFIFO = fifo_setup;
  HS_USB->RXFIFO = fifo_setup;
}

/**
 * @brief   Sets the USB address.
 *
 * @param[in] usbp      pointer to the @p USBDriver object
 *
 * @notapi
 */
void usb_lld_set_address(USBDriver *usbp)
{
  HS_USB->FADDR = usbp->address;
}

/**
 * @brief   Enables an endpoint.
 *
 * @param[in] usbp      pointer to the @p USBDriver object
 * @param[in] ep        endpoint number
 *
 * @notapi
 */
void usb_lld_init_endpoint(USBDriver *usbp, usbep_t ep)
{
  const USBEndpointConfig *epcp = usbp->epc[ep];

  osalDbgAssert(ep <= USB_MAX_ENDPOINTS, "usb_lld_init_endpoint()");

  /* Select this endpoint number for subsequent commands */
  HS_USB->INDEX = ep;

  /* CTRL endpoint is setup in usb_lld_reset() */
  if (epcp/*->in_cb*/) {
    if (ep && epcp->in_maxsize) {
      /* ISOC, BULK, INTR endpoints */
      uint16_t pktsize = epcp->in_maxsize;
      HS_USB->TXMAXP = pktsize / 8;
      /* FIFO allocation for the IN endpoint.*/
      HS_USB->TXFIFO = usb_fifo_ram_alloc(usbp, pktsize, epcp->dpb);

      osalDbgCheck(0 == (HS_USB->TXCSR&USB_TXCSR_P_FIFONOTEMPTY)); //_usb_txfifo_flush(usbp, ep);
      if ((epcp->in_ep_mode & USB_EP_MODE_TYPE) == USB_EP_MODE_TYPE_ISOC) {
        HS_USB->TXCSR |= USB_TXCSR_ISO;
      }

      /* Enable the TX complete (Transmitter Ready) interrupt once this EP is up */
      //if (ep != 1/*msd*/) HS_USB->INTR_TXEN |= (1 << ep);
    }
  }
  if (epcp/*->out_cb*/) {
    if (ep && epcp->out_maxsize) {
      uint16_t pktsize = epcp->out_maxsize;
      HS_USB->RXMAXP = pktsize / 8;
      /* FIFO allocation for the OUT endpoint.*/
      HS_USB->RXFIFO = usb_fifo_ram_alloc(usbp, pktsize, epcp->dpb);

      if ((epcp->out_ep_mode & USB_EP_MODE_TYPE) == USB_EP_MODE_TYPE_ISOC) {
        HS_USB->RXCSR |= USB_RXCSR_ISO;
      }

      /* Enable the Received OUT data interrupt once this EP is up */
      //if (ep != 2/*audio*/) HS_USB->INTR_RXEN |= (1 << ep);
    }
  }
}

/**
 * @brief   Disables all the active endpoints except the endpoint zero.
 *
 * @param[in] usbp      pointer to the @p USBDriver object
 *
 * @notapi
 */
void usb_lld_disable_endpoints(USBDriver *usbp)
{
  (void)usbp;
  uint8_t ep;

  /* Resets the FIFO memory allocator except for EP0. */
  usb_fifo_ram_reset(usbp);
  usb_fifo_ram_alloc(usbp, ep0config.in_maxsize, ep0config.dpb);
  usb_fifo_ram_alloc(usbp, ep0config.out_maxsize, ep0config.dpb);

  for (ep = 1; ep <= USB_MAX_ENDPOINTS; ++ep) {
    HS_USB->INDEX = ep;
    HS_USB->TXMAXP = 0;
    HS_USB->TXFIFO = 0;
    HS_USB->RXMAXP = 0;
    HS_USB->RXFIFO = 0;

    HS_USB->INTR_TXEN &= ~(1 << ep);
    HS_USB->INTR_RXEN &= ~(1 << ep);
  }
}

/**
 * @brief   Returns the status of an OUT endpoint.
 *
 * @param[in] usbp      pointer to the @p USBDriver object
 * @param[in] ep        endpoint number
 * @return              The endpoint status.
 * @retval EP_STATUS_DISABLED The endpoint is not active.
 * @retval EP_STATUS_STALLED  The endpoint is stalled.
 * @retval EP_STATUS_ACTIVE   The endpoint is active.
 *
 * @notapi
 */
usbepstatus_t usb_lld_get_status_out(USBDriver *usbp, usbep_t ep)
{
  (void)usbp;

  osalDbgAssert(ep <= USB_MAX_ENDPOINTS, "usb_lld_get_status_out()");

  HS_USB->INDEX = ep;
  if (ep) {
    if (0 == HS_USB->RXMAXP)
      return EP_STATUS_DISABLED;
    if (HS_USB->RXCSR & USB_RXCSR_P_SENTSTALL)
      return EP_STATUS_STALLED;
  }
  else {
    if (HS_USB->CSR0 & USB_CSR0_P_SENTSTALL)
      return EP_STATUS_STALLED;
  }
  return EP_STATUS_ACTIVE;
}

/**
 * @brief   Returns the status of an IN endpoint.
 *
 * @param[in] usbp      pointer to the @p USBDriver object
 * @param[in] ep        endpoint number
 * @return              The endpoint status.
 * @retval EP_STATUS_DISABLED The endpoint is not active.
 * @retval EP_STATUS_STALLED  The endpoint is stalled.
 * @retval EP_STATUS_ACTIVE   The endpoint is active.
 *
 * @notapi
 */
usbepstatus_t usb_lld_get_status_in(USBDriver *usbp, usbep_t ep)
{
  (void)usbp;

  osalDbgAssert(ep <= USB_MAX_ENDPOINTS, "usb_lld_get_status_in()");

  HS_USB->INDEX = ep;
  if (ep) {
    if (0 == HS_USB->TXMAXP)
      return EP_STATUS_DISABLED;
    if (HS_USB->TXCSR & USB_TXCSR_P_SENTSTALL)
      return EP_STATUS_STALLED;
  }
  else {
    if (HS_USB->CSR0 & USB_CSR0_P_SENTSTALL)
      return EP_STATUS_STALLED;
  }
  return EP_STATUS_ACTIVE;
}

/**
 * @brief   Reads a setup packet from the dedicated packet buffer.
 * @details This function must be invoked in the context of the @p setup_cb
 *          callback in order to read the received setup packet.
 * @pre     In order to use this function the endpoint must have been
 *          initialized as a control endpoint.
 * @post    The endpoint is ready to accept another packet.
 *
 * @param[in] usbp      pointer to the @p USBDriver object
 * @param[in] ep        endpoint number
 * @param[out] buf      buffer where to copy the packet data
 *
 * @notapi
 */
void usb_lld_read_setup(USBDriver *usbp, usbep_t ep, uint8_t *buf)
{
  (void)usbp;
  uint32_t setup_pkt[2];

  osalDbgAssert(ep == 0, "usb_lld_read_setup()");
  setup_pkt[0] = HS_USB->EPnFIFO[ep];
  setup_pkt[1] = HS_USB->EPnFIFO[ep];
  memcpy(buf, &setup_pkt[0], 8);
  usb_trace_setup('s', (uint8_t *)setup_pkt);
}

/**
 * @brief   Ends a SETUP transaction
 * @details This function must be invoked in the context of the @p setup_cb
 *          callback in order to finish an entire setup packet.
 * @pre     In order to use this function the endpoint must have been
 *          initialized as a control endpoint.
 * @post    The endpoint is ready to accept another packet.
 *
 * @param[in] usbp      pointer to the @p USBDriver object
 * @param[in] ep        endpoint number
 *
 * @notapi
 */
void usb_lld_end_setup(USBDriver *usbp, usbep_t ep)
{
  osalDbgAssert(ep == 0, "usb_lld_end_setup()");

  usb_trace('e', usbp->ep0state);
  /* Select this endpoint number for subsequent commands */
  HS_USB->INDEX = ep;

  /* Zero Data Requests:
     get here after usb_lld_read_setup() is called and setup[7:6]==0.
     sw set ServiceRxPktRdy to clear RxPktRdy bit;
     sw set DataEnd when clearing RxPktRdy after unloading the last data packet. */
  if (USB_EP0_SENDING_STS == usbp->ep0state) {
    HS_USB->CSR0 |= USB_CSR0_P_SERVICED_RXPKTRDY | USB_CSR0_P_DATAEND;
  }
  /* workaround on usb.c:_usb_ep0in(): USB_EP0_TX fall through USB_EP0_WAITING_TX0  */
  if (USB_EP0_WAITING_STS == usbp->ep0state) {
    //usbp->ep0state = USB_EP0_WAITING_SETUP;
  }

  if ((usbp->setup[0] & USB_RTYPE_DIR_MASK) == USB_RTYPE_DIR_DEV2HOST) {
    /* Enable interrupt and wait for OUT packet */
    usbp->epc[ep]->out_state->rxsize = 0;
    usbp->epc[ep]->out_state->rxpkts = 1;
  } else {
    /* Enable interrupt and wait for IN packet */
    usbp->epc[ep]->in_state->last_tx_size = 0;
    usbp->epc[ep]->in_state->txcnt = 0;
    usbp->epc[ep]->in_state->txsize = 0;
  }
}

/**
 * @brief   Starts a receive operation on an OUT endpoint.
 *
 * @param[in] usbp      pointer to the @p USBDriver object
 * @param[in] ep        endpoint number
 *
 * @notapi
 */
size_t usb_lld_start_out(USBDriver *usbp, usbep_t ep)
{
  const USBEndpointConfig *epcp = usbp->epc[ep];
  USBOutEndpointState *osp = epcp->out_state;
  syssts_t sts;
  uint32_t rxcsr;

  osalDbgAssert(ep <= USB_MAX_ENDPOINTS, "usb_lld_start_out()");

  /* Select this endpoint number for subsequent commands */
  /* Must lock for entire operation to ensure nothing changes the INDEX value */
  sts = osalSysGetStatusAndLockX();
  HS_USB->INDEX = ep;
  rxcsr = HS_USB->RXCSR;

  if ((0 != ep) &&
      ((epcp->out_ep_mode & USB_EP_MODE_TYPE) == USB_EP_MODE_TYPE_ISOC) &&
      (epcp->dma_ch_out < HS_USB_NUM_DMA_CHANNELS)) {
    uint8_t ch = epcp->dma_ch_out;
#if HS_TRACE_USB
    HS_UART1->THR='S';
    HS_UART1->THR='0'+ep;
    HS_UART1->THR='0'+ch;
    usb_trace_prefix('S', ep*16+ch);
#endif
    if (rxcsr & USB_RXCSR_P_OVERRUN) {
      HS_USB->RXCSR &= ~USB_RXCSR_P_OVERRUN;
      HS_UART1->THR = 'o';
    }
    osp->rxcnt = 0;
    osp->rxpkts = 1;
    usbdrc_setup_dma_out(ch, ep, epcp->out_maxsize, osp->rxbuf, osp->rxsize);
    osalSysRestoreStatusX(sts);
    return 0;
  }

  #if defined(hscAudiophile)
  /* workaround for usb storage: threading usbReceive() vs. realtime usb traffic without double buffer */
  if ((ep > 0) && (USB_RXCSR_P_RXPKTRDY & rxcsr) &&
      /* (USB_RXCSR_P_FIFOFULL & rxcsr) && */
      (epcp->out_cb == NULL)) {
    int n;
    /* the first scsi command or the next scsi command in pipeline */
  Lread_imm:
    n = HS_USB->RXCOUNT;
    if (0 == n) {
      if (HS_USB->RXCSR & USB_RXCSR_P_FIFOFULL) {
        n = epcp->out_maxsize;
      }
      else {
        n = osp->rxsize;
      }
    }
    n = usb_fifo_read(usbp, ep, n);
    osp->rxcnt += n;
    if (((n > 0) && (n < epcp->out_maxsize)) ||
        (osp->rxcnt >= osp->rxsize)) {
      /* a part of _usb_isr_invoke_out_cb() */
      usbp->receiving &= ~(1 << ep);
      if (epcp->out_cb != NULL) {
        /* usb serial case is interrupt or thread context, but out_cb() must be called in interrupt context */
        //epcp->out_cb(usbp, ep);
      }
      else {
        /* usb storage case is interrupt context */
      }
      //osalThreadResume(&osp->thread, osp->rxcnt);
      osalSysRestoreStatusX(sts);
      return osp->rxcnt;
    }
    /* fall through */
  }
  #endif

  /* Initialize transfer by recording how many packets we expect to receive. */
  if (osp->rxsize == 0)         /* Special case for zero sized packets.*/
    osp->rxpkts = 1;
  else
    osp->rxpkts = (osp->rxsize - osp->rxcnt + usbp->epc[ep]->out_maxsize - 1) /
                  usbp->epc[ep]->out_maxsize;
  if ((ep == 0) && (osp->rxsize > EP0_MAX_OUTSIZE))
    osp->rxsize = EP0_MAX_OUTSIZE;

  if (0 == ep) {
    /* Write Requests:
       get here after usb_lld_read_setup() is called and setup[7:6]!=0. */
    HS_USB->CSR0 |= USB_CSR0_P_SERVICED_RXPKTRDY;
    usb_trace('o', osp->rxsize);
  }
  else {
    /* Enable the Received OUT data interrupt */
    HS_USB->INTR_RXEN |= (1 << ep);
    usb_trace('O', osp->rxsize);
    #if defined(hscAudiophile)
    if ((USB_RXCSR_P_RXPKTRDY & HS_USB->RXCSR) &&
        (epcp->out_cb == NULL)) {
      /* workaround for scsi command in pipeline */
      HS_USB->INTR_RXEN &= ~(1 << ep);
      goto Lread_imm;
    }
    #endif
  }
  osalSysRestoreStatusX(sts);
  return 0;
}

/**
 * @brief   Starts a transmit operation on an IN endpoint.
 *
 * @param[in] usbp      pointer to the @p USBDriver object
 * @param[in] ep        endpoint number
 *
 * @notapi
 */
void usb_lld_start_in(USBDriver *usbp, usbep_t ep)
{
  const USBEndpointConfig *epcp = usbp->epc[ep];
  USBInEndpointState *isp = epcp->in_state;
  syssts_t sts;

  osalDbgAssert(ep <= USB_MAX_ENDPOINTS, "usb_lld_start_in()");

  /* Select this endpoint number for subsequent commands */
  /* Must lock for entire operation to ensure nothing changes the INDEX value */
  sts = osalSysGetStatusAndLockX();
  HS_USB->INDEX = ep;

  if ((0 != ep) &&
      ((isp->txsize >= 512) ||
       ((epcp->in_ep_mode & USB_EP_MODE_TYPE) == USB_EP_MODE_TYPE_ISOC)) &&
      (epcp->dma_ch_in < HS_USB_NUM_DMA_CHANNELS)) {
    uint8_t ch = epcp->dma_ch_in;
    #if HS_TRACE_USB
    HS_UART1->THR='S';
    HS_UART1->THR='0'+ep;
    HS_UART1->THR='0'+ch;
    usb_trace_prefix('S', ep*16+ch);
    #endif
    usbdrc_setup_dma_in(ch, ep, epcp->in_maxsize, isp->txbuf, isp->txsize);
    osalSysRestoreStatusX(sts);
    return;
  }

  if (0 == ep) {
    /* Read Requests:
       get here after usb_lld_read_setup() is called and setup[7:6]!=0. */
    HS_USB->CSR0 |= USB_CSR0_P_SERVICED_RXPKTRDY;
    usb_trace('i', isp->txsize);
  }

  /* Initialize transfer by filling FIFO with passed data. */
  usb_fifo_write(usbp, ep, isp->txsize);

  /* Mark TxPktRdy to send the data in the FIFO */
  if (ep) {
    HS_USB->TXCSR |= USB_TXCSR_P_TXPKTRDY;
    if (0 == isp->txsize) {
      /* If the total size of the data block is a multiple of TxMaxP,
         the host will need to send a null packet after all the data has been sent.
         This is done by setting TxPktRdy after the last interrupt is received,
         without loading any data into the FIFO.
         See section 5.8.3 Bulk Transfer Packet Size Constraints. */
      usbp->transmitting &= ~(1 << ep);
      osalSysRestoreStatusX(sts);
      return;
    }
  }
  else {
    if (isp->txsize <= epcp->in_maxsize) {
      /* sw set DataEnd when setting TxPktRdy for the last data packet or ZLP. */
      HS_USB->CSR0 |= USB_CSR0_P_TXPKTRDY | USB_CSR0_P_DATAEND;
      usb_trace('d', isp->last_tx_size);
    }
    else {
      HS_USB->CSR0 |= USB_CSR0_P_TXPKTRDY;
      usb_trace('p', isp->last_tx_size);
    }
  }

  /* Enable the TX complete (Transmitter Ready) interrupt in irq mode */
  HS_USB->INTR_TXEN |= (1 << ep);

  osalSysRestoreStatusX(sts);
}

/**
 * @brief   Brings an OUT endpoint in the stalled state.
 *
 * @param[in] usbp      pointer to the @p USBDriver object
 * @param[in] ep        endpoint number
 *
 * @notapi
 */
void usb_lld_stall_out(USBDriver *usbp, usbep_t ep)
{
  (void)usbp;
  syssts_t sts;

  osalDbgAssert(ep <= USB_MAX_ENDPOINTS, "usb_lld_stall_out()");
  usb_trace('S', ep);

  /* Select this endpoint number for subsequent commands */
  /* Must lock for entire operation to ensure nothing changes the INDEX value */
  sts = osalSysGetStatusAndLockX();
  HS_USB->INDEX = ep;
  if (ep) {
    HS_USB->RXCSR |= USB_RXCSR_P_SENDSTALL;
  }
  else {
    /* EP0's SendStall will send a STALL handshake to host, i.e. IN only */
    /* when host moves to the status stage, hw sends a STALL;
       then raises the 2nd EP0 interrupt with CSR0.D2=SentStall=1 */
    //HS_USB->CSR0 |= USB_CSR0_P_SENDSTALL | USB_CSR0_P_SERVICED_RXPKTRDY;
  }
  osalSysRestoreStatusX(sts);
}

/**
 * @brief   Brings an IN endpoint in the stalled state.
 *
 * @param[in] usbp      pointer to the @p USBDriver object
 * @param[in] ep        endpoint number
 *
 * @notapi
 */
void usb_lld_stall_in(USBDriver *usbp, usbep_t ep)
{
  (void)usbp;
  syssts_t sts;

  osalDbgAssert(ep <= USB_MAX_ENDPOINTS, "usb_lld_stall_in()");
  usb_trace('S', ep);

  /* Select this endpoint number for subsequent commands */
  /* Must lock for entire operation to ensure nothing changes the INDEX value */
  sts = osalSysGetStatusAndLockX();
  HS_USB->INDEX = ep;
  if(ep) {
    /* enable stall request */
    HS_USB->TXCSR |= USB_TXCSR_P_SENDSTALL;
  }
  else {
    /* unknown requests:
       get here after usb_lld_read_setup() is called and unknown commands.
       when host moves to the status stage, hw sends a STALL;
       then raises the 2nd EP0 interrupt with CSR0.D2=SentStall=1 */
    HS_USB->CSR0 |= USB_CSR0_P_SENDSTALL | USB_CSR0_P_SERVICED_RXPKTRDY;
  }
  osalSysRestoreStatusX(sts);
}

/**
 * @brief   Brings an OUT endpoint in the active state.
 *
 * @param[in] usbp      pointer to the @p USBDriver object
 * @param[in] ep        endpoint number
 *
 * @notapi
 */
void usb_lld_clear_out(USBDriver *usbp, usbep_t ep)
{
  (void)usbp;
  syssts_t sts;

  osalDbgAssert(ep <= USB_MAX_ENDPOINTS, "usb_lld_clear_out()");

  /* Select this endpoint number for subsequent commands */
  /* Must lock for entire operation to ensure nothing changes the INDEX value */
  sts = osalSysGetStatusAndLockX();
  HS_USB->INDEX = ep;
  if (ep) {
    /* disable stall request */
    HS_USB->RXCSR &= ~(USB_RXCSR_P_SENDSTALL|USB_RXCSR_P_SENTSTALL);
  }
  else {
    HS_USB->CSR0 &= ~(USB_CSR0_P_SENDSTALL|USB_CSR0_P_SENTSTALL);
  }
  osalSysRestoreStatusX(sts);
}

/**
 * @brief   Brings an IN endpoint in the active state.
 *
 * @param[in] usbp      pointer to the @p USBDriver object
 * @param[in] ep        endpoint number
 *
 * @notapi
 */
void usb_lld_clear_in(USBDriver *usbp, usbep_t ep)
{
  (void)usbp;
  syssts_t sts;

  osalDbgAssert(ep <= USB_MAX_ENDPOINTS, "usb_lld_clear_in()");

  /* Select this endpoint number for subsequent commands */
  /* Must lock for entire operation to ensure nothing changes the INDEX value */
  sts = osalSysGetStatusAndLockX();
  HS_USB->INDEX = ep;
  if(ep) {
    HS_USB->TXCSR &= ~(USB_TXCSR_P_SENDSTALL|USB_TXCSR_P_SENTSTALL);
  }
  else {
    HS_USB->CSR0 &= ~(USB_CSR0_P_SENDSTALL|USB_CSR0_P_SENTSTALL);
  }
  osalSysRestoreStatusX(sts);
}

/**
 * @brief   Connects the USB device.
 *
 * @api
 */
void usb_lld_connect_bus(USBDriver *usbp)
{
  (void)usbp;
  usbdrc_connect_vbus(true/*bForce*/);
}

/**
 * @brief   Disconnect the USB device.
 *
 * @api
 */
void usb_lld_disconnect_bus(USBDriver *usbp)
{
  (void)usbp;
  usbdrc_disconnect_vbus();
}

#endif /* HAL_USE_USB */
