/*
    ChibiOS - Copyright (C) 2006..2018 Giovanni Di Sirio

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    UARTv1/hal_uart_lld.c
 * @brief   HS low level UART driver code.
 *
 * @addtogroup UART
 * @{
 */

#include "hal.h"

#if HAL_USE_UART || defined(__DOXYGEN__)

/*===========================================================================*/
/* Driver local definitions.                                                 */
/*===========================================================================*/

#if 0 && HS_HAS_DMA
#define UART0_RX_DMA_CHANNEL                                               \
  HS_DMA_GETCHANNEL(HS_UART_UART0_RX_DMA_STREAM,                     \
                       HS_UART0_RX_DMA_CHN)

#define UART0_TX_DMA_CHANNEL                                               \
  HS_DMA_GETCHANNEL(HS_UART_UART0_TX_DMA_STREAM,                     \
                       HS_UART0_TX_DMA_CHN)

#define UART1_RX_DMA_CHANNEL                                               \
  HS_DMA_GETCHANNEL(HS_UART_UART1_RX_DMA_STREAM,                     \
                       HS_UART1_RX_DMA_CHN)

#define UART1_TX_DMA_CHANNEL                                               \
  HS_DMA_GETCHANNEL(HS_UART_UART1_TX_DMA_STREAM,                     \
                       HS_UART1_TX_DMA_CHN)

#define UART2_RX_DMA_CHANNEL                                               \
  HS_DMA_GETCHANNEL(HS_UART_UART2_RX_DMA_STREAM,                     \
                       HS_UART2_RX_DMA_CHN)

#define UART2_TX_DMA_CHANNEL                                               \
  HS_DMA_GETCHANNEL(HS_UART_UART2_TX_DMA_STREAM,                     \
                       HS_UART2_TX_DMA_CHN)
#endif /* HS_HAS_DMA */

/*===========================================================================*/
/* Driver exported variables.                                                */
/*===========================================================================*/

/** @brief UART0 UART driver identifier.*/
#if HS_UART_USE_UART0 || defined(__DOXYGEN__)
UARTDriver UARTD0;
#endif

/** @brief UART1 UART driver identifier.*/
#if HS_UART_USE_UART1 || defined(__DOXYGEN__)
UARTDriver UARTD1;
#endif

/** @brief UART2 UART driver identifier.*/
#if HS_UART_USE_UART2 || defined(__DOXYGEN__)
UARTDriver UARTD2;
#endif

/*===========================================================================*/
/* Driver local variables and types.                                         */
/*===========================================================================*/

/**
 * @brief   Driver default configuration.
 */
static const UARTConfig default_config = {
	NULL, NULL, NULL, NULL, NULL,
  SERIAL_DEFAULT_BITRATE,
  FALSE,
};

/*===========================================================================*/
/* Driver local functions.                                                   */
/*===========================================================================*/

/**
 * @brief   Status bits translation.
 *
 * @param[in] lsr        UART LSR register value
 *
 * @return  The error flags.
 */
static uartflags_t translate_errors(uint32_t lsr) {
  uartflags_t sts = 0;

  if (lsr & UART_LSR_OE)
    sts |= UART_OVERRUN_ERROR;
  if (lsr & UART_LSR_PE)
    sts |= UART_PARITY_ERROR;
  if (lsr & UART_LSR_FE)
    sts |= UART_FRAMING_ERROR;
  if (lsr & UART_LSR_BI)
    sts |= UART_BREAK_DETECTED;

  return sts;
}

/**
 * @brief   Puts the receiver in the UART_RX_IDLE state.
 *
 * @param[in] uartp     pointer to the @p UARTDriver object
 */
static void uart_enter_rx_idle_loop(UARTDriver *uartp) {

  /* RX buffer preparation, if the char callback is defined then the
     TCIE interrupt is enabled too. ? */
//  if (uartp->config->rxchar_cb != NULL)
//    uartp->uart->IER |= UART_IER_THRI;

  uartp->rxbuf = (uint8_t *)&uartp->rxbuf_idle;
  uartp->rxbuf_size = 1;
  uartp->rxbytes = 0;
}

/**
 * @brief   UART de-initialization.
 * @details This function must be invoked with interrupts disabled.
 *
 * @param[in] uartp     pointer to the @p UARTDriver object
 */
static void uart_stop(UARTDriver *uartp) {
	HS_UART_Type *u = uartp->uart;

  u->LCR = 0x00;
  u->IER = 0x00;
  u->FCR = UART_FCR_CLEAR_RCVR | UART_FCR_CLEAR_XMIT;
}

/**
 * @brief   UART initialization.
 * @details This function must be invoked with interrupts disabled.
 * @note    Copy from serial_lld.uart_init(), they are exactly the same.
 *
 * @param[in] uartp     pointer to the @p UARTDriver object
 */
static void uart_start(UARTDriver *uartp) {
  HS_UART_Type *u = uartp->uart;

#define MODE_X_DIV 16
  /* Compute divisor value. Normally, we should simply return:
   *   NS16550_CLK / MODE_X_DIV / baudrate
   * but we need to round that value by adding 0.5.
   * Rounding is especially important at high baud rates.
   */
  int baud_divisor =  (uartp->clock + (uartp->config->speed * (MODE_X_DIV / 2))) /
    (MODE_X_DIV * uartp->config->speed);

  (void)u->LSR; /* clear errors */
  u->IER = 0x00;
  u->LCR = UART_LCR_DLAB;
  u->DLL = 0;
  u->DLH = 0;

  u->LCR = 0x00;
  if (HS_UART0 != u) {
    if (uartp->config->ctsrts)
      u->MCR = UART_MCR_AFCE | UART_MCR_RTS;
    else
      u->MCR = 0;
    u->FCR = UART_FCR_CLEAR_RCVR | UART_FCR_CLEAR_XMIT |
      UART_FCR_FIFO_EN | UART_FCR_TRIGGER_1;
  } else {
    u->MCR = 0x00;
    u->FCR = UART_FCR_CLEAR_RCVR | UART_FCR_CLEAR_XMIT;
  }

  /* Baud rate setting.*/
  u->LCR = UART_LCR_DLAB;
  u->DLL = baud_divisor & 0xff;
  u->DLH = (baud_divisor >> 8) & 0xff;
  /* 8 data, 1 stop, no parity */
  u->LCR = UART_LCR_8N1;

  /* enable interrupts.
   * Mustn't ever set THRI here - if done, it causes an immediate
   * interrupt.
   */
  if (uartp->config->ctsrts)
    u->IER = /*UART_IER_THRI | */UART_IER_RLSI | UART_IER_RDI | UART_IER_MSI;
  else
    u->IER = /*UART_IER_THRI | */UART_IER_RLSI | UART_IER_RDI;
  uartp->can_send = TRUE;

  /* Starting the receiver idle loop.*/
  uart_enter_rx_idle_loop(uartp);
}

/**
 * @brief   RX DMA common service routine.
 *
 * @param[in] uartp     pointer to the @p UARTDriver object
 * @param[in] flags     pre-shifted content of the ISR register
 */
static void uart_lld_serve_rx_end_irq(UARTDriver *uartp, uint32_t flags) {

	(void)flags;

  if (uartp->rxstate == UART_RX_IDLE) {
    /* Receiver in idle state, a callback is generated, if enabled, for each
       received character and then the driver stays in the same state.*/
    _uart_rx_idle_code(uartp);
  }
  else {
    /* Receiver in active state, a callback is generated, if enabled, after
       a completed transfer.*/
    _uart_rx_complete_isr_code(uartp); /* RX complete? RX buffer full-filled. */
  }
}

/**
 * @brief   TX common service routine.
 *
 * @param[in] uartp     pointer to the @p UARTDriver object
 * @param[in] flags     pre-shifted content of the ISR register
 */
static void uart_lld_serve_tx_end_irq(UARTDriver *uartp, uint32_t flags) {

  (void)flags;

  /* A callback is generated, if enabled, after a completed transfer.*/
  _uart_tx1_isr_code(uartp);
}

/**
 * @brief   UART common service routine.
 *
 * @param[in] uartp     pointer to the @p UARTDriver object
 */
static void serve_uart_irq(UARTDriver *uartp) {
  HS_UART_Type *u = uartp->uart;
  uint8_t msr;

  while (TRUE) {
    switch (u->IIR & UART_IIR_ID) {
    case UART_IIR_NO_INT:
      return;

    case UART_IIR_BDI: //busy detect
      /* The DesignWare APB UART has an Busy Detect (0x07)
       * interrupt meaning an LCR write attempt occured while the
       * UART was busy. The interrupt must be cleared by reading
       * the UART status register (USR) and the LCR re-written. */
      u->USR;
      break;

    case UART_IIR_MSI:
      msr = u->MSR;
      if (msr & UART_MSR_DCTS) {
				if (msr & UART_MSR_CTS) {
					uartp->can_send = TRUE;
					/* re-enable transmit interrupt to send if oqueue is not empty */
					osalSysLockFromISR();
					if (uartp->txbytes)
            u->IER |= UART_IER_THRI;
					osalSysUnlockFromISR();
				} else {
					uartp->can_send = FALSE;
				}
      }
      break;

    case UART_IIR_RLSI:
    	osalSysLockFromISR();
      _uart_rx_error_isr_code(uartp, translate_errors(u->LSR));
      osalSysUnlockFromISR();
      break;
    case UART_IIR_CTI: //receive timeout
    case UART_IIR_RDI: //received data
			osalSysLockFromISR();
			while (u->LSR & UART_LSR_DR) {
				uartp->rxbuf[uartp->rxbytes++] = u->RBR;
				if (uartp->rxbytes >= uartp->rxbuf_size) {
					/* RX omplete (RX buffer full-filled), a callback is generated.*/
					uartp->rxbytes = 0;
					uart_lld_serve_rx_end_irq(uartp, 0);
					break;
				}
			}
			osalSysUnlockFromISR();
			break;

    case UART_IIR_THRI: //tx: THR or tFIFO empty
			/* disable transmit interrupt if hardware flow control disallows send */
			if (!uartp->can_send) {
				u->IER &= ~UART_IER_THRI;
			}
			else {
				int i = (HS_UART0 == u) ? 0 : ((u->CPR >> 16) & 0x0f) * 16; //FIFO size
				osalSysLockFromISR();
				do {
					if (uartp->txbytes >= uartp->txbuf_size) {
						/* disable transmit interrupt if physical TX end. */
						u->IER &= ~UART_IER_THRI;
						uartp->can_send = false;
						/* Physical end of transmission, a callback is generated.*/
						_uart_tx2_isr_code(uartp);
						break;
					}
					else {
						u->THR = uartp->txbuf[uartp->txbytes++];
						if (uartp->txbytes >= uartp->txbuf_size) {
							/* End of transmission buffer, a callback is generated.*/
							uart_lld_serve_tx_end_irq(uartp, 0);
							break;
						}
					}
				} while (--i > 0);
				osalSysUnlockFromISR();
			}
      break;

    default:
      (void) u->THR;
      (void) u->RBR;
    }
  }
}

/*===========================================================================*/
/* Driver interrupt handlers.                                                */
/*===========================================================================*/

#if HS_UART_USE_UART0 || defined(__DOXYGEN__)
#if !defined(UART0_IRQHandler)
#error "UART0_IRQHandler not defined"
#endif
/**
 * @brief   UART0 IRQ handler.
 *
 * @isr
 */
OSAL_IRQ_HANDLER(UART0_IRQHandler) {

  OSAL_IRQ_PROLOGUE();

  serve_uart_irq(&UARTD0);

  OSAL_IRQ_EPILOGUE();
}
#endif /* HS_UART_USE_UART0 */

#if HS_UART_USE_UART1 || defined(__DOXYGEN__)
#if !defined(UART1_IRQHandler)
#error "UART1_IRQHandler not defined"
#endif
/**
 * @brief   UART1 IRQ handler.
 *
 * @isr
 */
OSAL_IRQ_HANDLER(UART1_IRQHandler) {

  OSAL_IRQ_PROLOGUE();

  serve_uart_irq(&UARTD1);

  OSAL_IRQ_EPILOGUE();
}
#endif /* HS_UART_USE_UART1 */

#if HS_UART_USE_UART2 || defined(__DOXYGEN__)
#if !defined(UART2_IRQHandler)
#error "UART2_IRQHandler not defined"
#endif
/**
 * @brief   UART2 IRQ handler.
 *
 * @isr
 */
OSAL_IRQ_HANDLER(UART2_IRQHandler) {

  OSAL_IRQ_PROLOGUE();

  serve_uart_irq(&UARTD2);

  OSAL_IRQ_EPILOGUE();
}
#endif /* HS_UART_USE_UART2 */

/*===========================================================================*/
/* Driver exported functions.                                                */
/*===========================================================================*/

/**
 * @brief   Low level UART driver initialization.
 *
 * @notapi
 */
void uart_lld_init(void) {

#if HS_UART_USE_UART0
  uartObjectInit(&UARTD0);
  UARTD0.uart = HS_UART0;
#endif

#if HS_UART_USE_UART1
  uartObjectInit(&UARTD1);
  UARTD0.uart = HS_UART1;
#endif

#if HS_UART_USE_UART2
  uartObjectInit(&UARTD2);
  UARTD0.uart = HS_UART2;
#endif
}

/**
 * @brief   Configures and activates the UART peripheral.
 *
 * @param[in] uartp     pointer to the @p UARTDriver object
 *
 * @notapi
 */
void uart_lld_start(UARTDriver *uartp) {

	if (uartp->config == NULL)
		uartp->config = &default_config;

  if (uartp->state == UART_STOP) {
#if HS_UART_USE_UART0
    if (&UARTD0 == uartp) {
      cpmEnableUART0();
      cpmResetUART0();
      UARTD0.clock = cpm_get_clock(HS_UART0_CLK);
      nvicEnableVector(UART0_IRQn, HS_UART_UART0_IRQ_PRIORITY);
    }
#endif

#if HS_UART_USE_UART1
    if (&UARTD1 == uartp) {
      cpmEnableUART1();
      cpmResetUART1();
      UARTD1.clock = cpm_get_clock(HS_UART1_CLK);
      nvicEnableVector(UART1_IRQn, HS_UART_UART1_IRQ_PRIORITY);
    }
#endif

#if HS_UART_USE_UART2
    if (&UARTD2 == uartp) {
      cpmEnableUART2();
      cpmResetUART2();
      UARTD2.clock = cpm_get_clock(HS_UART2_CLK);
      nvicEnableVector(UART2_IRQn, HS_UART_UART2_IRQ_PRIORITY);
    }
#endif

    uartp->rxbuf_idle = 0;
  }

  uartp->rxstate = UART_RX_IDLE;
  uartp->txstate = UART_TX_IDLE;
  uart_start(uartp);
}

/**
 * @brief   Deactivates the UART peripheral.
 *
 * @param[in] uartp     pointer to the @p UARTDriver object
 *
 * @notapi
 */
void uart_lld_stop(UARTDriver *uartp) {

  if (uartp->state == UART_READY) {
  	/* Resets the peripheral.*/
    uart_stop(uartp);

#if HS_UART_USE_UART0
    if (&UARTD0 == uartp) {
      nvicDisableVector(UART0_IRQn);
      cpmDisableUART0();
      return;
    }
#endif

#if HS_UART_USE_UART1
    if (&UARTD1 == uartp) {
      nvicDisableVector(UART1_IRQn);
      cpmDisableUART1();
      return;
    }
#endif

#if HS_UART_USE_UART2
    if (&UARTD2 == uartp) {
      nvicDisableVector(UART2_IRQn);
      cpmDisableUART2();
      return;
    }
#endif
  }
}

/**
 * @brief   Starts a transmission on the UART peripheral.
 * @note    The buffers are organized as uint8_t arrays for data sizes below
 *          or equal to 8 bits else it is organized as uint16_t arrays.
 *
 * @param[in] uartp     pointer to the @p UARTDriver object
 * @param[in] n         number of data frames to send
 * @param[in] txbuf     the pointer to the transmit buffer
 *
 * @notapi
 */
void uart_lld_start_send(UARTDriver *uartp, size_t n, const void *txbuf) {

	/* Stopping previous activity (idle state).*/
	uart_lld_stop_send(uartp);

  /* TX buffer preparation.*/
  uartp->txbuf = txbuf;
  uartp->txbuf_size = n;
  uartp->txbytes = 0;

  /* Starting transfer.*/
  uartp->can_send = TRUE;
	(void)uartp->uart->IIR; /* Clear TX interrupt status */
	uartp->uart->IER |= UART_IER_THRI; /* Enable TX interrupt */
}

/**
 * @brief   Stops any ongoing transmission.
 * @note    Stopping a transmission also suppresses the transmission callbacks.
 *
 * @param[in] uartp     pointer to the @p UARTDriver object
 *
 * @return              The number of data frames not transmitted by the
 *                      stopped transmit operation.
 *
 * @notapi
 */
size_t uart_lld_stop_send(UARTDriver *uartp) {

  uartp->can_send = FALSE;
  uartp->uart->FCR |= UART_FCR_CLEAR_XMIT;

  return uartp->txbuf_size - uartp->txbytes;
}

/**
 * @brief   Starts a receive operation on the UART peripheral.
 * @note    The buffers are organized as uint8_t arrays for data sizes below
 *          or equal to 8 bits else it is organized as uint16_t arrays.
 *
 * @param[in] uartp     pointer to the @p UARTDriver object
 * @param[in] n         number of data frames to send
 * @param[out] rxbuf    the pointer to the receive buffer
 *
 * @notapi
 */
void uart_lld_start_receive(UARTDriver *uartp, size_t n, void *rxbuf) {

  /* Stopping previous activity (idle state).*/
	uart_lld_stop_receive(uartp);

  /* RX buffer preparation.*/
  uartp->rxbuf = rxbuf;
  uartp->rxbuf_size = n;
  uartp->rxbytes = 0;

  /* Starting transfer. */
  (void)uartp->uart->RBR; /* Clear RX interrupt status. */
  uartp->uart->IER |= (UART_IER_RDI | UART_IER_RLSI); /* Enable RX interrupt. */
}

/**
 * @brief   Stops any ongoing receive operation.
 * @note    Stopping a receive operation also suppresses the receive callbacks.
 *
 * @param[in] uartp     pointer to the @p UARTDriver object
 *
 * @return              The number of data frames not received by the
 *                      stopped receive operation.
 *
 * @notapi
 */
size_t uart_lld_stop_receive(UARTDriver *uartp) {
  size_t n;

  uartp->uart->FCR |= UART_FCR_CLEAR_RCVR;
  n = uartp->rxbuf_size - uartp->rxbytes;
  uart_enter_rx_idle_loop(uartp);

  return n;
}

#endif /* HAL_USE_UART */

/** @} */
