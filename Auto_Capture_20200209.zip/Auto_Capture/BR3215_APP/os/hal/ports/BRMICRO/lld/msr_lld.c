/*
    ChibiOS - Copyright (C) 2017 BRMICRO Technologies
              

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    br32xx/msr_lld.c
 * @brief   MSR (Magnetic Strip Reader) Driver subsystem low level driver source.
 *
 * @addtogroup MSR
 * @{
 */

#include <string.h>
#include "hal.h"

#if HAL_USE_MSR || defined(__DOXYGEN__)

/*===========================================================================*/
/* Driver local definitions.                                                 */
/*===========================================================================*/

/*===========================================================================*/
/* Driver exported variables.                                                */
/*===========================================================================*/

/**
 * @brief   MSRD0 driver identifier.
 */
MSRDriver MSRD0;

/*===========================================================================*/
/* Driver local variables and types.                                         */
/*===========================================================================*/

/**
 * @brief   Driver default configuration.
 */
static const MSRConfig msr_default_config = {
  0x7, //bitmap_tracks
  160, //sample rate in 160khz
  { 0, 0, 0 }, //th_low
  { 0, 0, 0 }, //th_gap
  { 0x400, 0x200, 0x400}, //f2f_len
};

/*===========================================================================*/
/* Driver local functions.                                                   */
/*===========================================================================*/

static void _msr_swipe_timeout(void *arg)
{
  MSRDriver *msrp = (MSRDriver *)arg;

  osalSysLockFromISR();
  chVTResetI(&msrp->f2f_vt);

  HS_MSR->INT_MSK = 0;

  if ((HS_MSR->DMA_CNT[0] > HS_MSR->DMA_LEN[0]/4) ||
      (HS_MSR->DMA_CNT[1] > HS_MSR->DMA_LEN[1]/4) ||
      (HS_MSR->DMA_CNT[2] > HS_MSR->DMA_LEN[2]/4)) {
    if (HS_MSR->DMA_CNT[0] > 0)
      msrp->f2f_len[0] = HS_MSR->DMA_CNT[0] - 1;
    if (HS_MSR->DMA_CNT[1] > 0)
      msrp->f2f_len[1] = HS_MSR->DMA_CNT[1] - 1;
    if (HS_MSR->DMA_CNT[2] > 0)
      msrp->f2f_len[2] = HS_MSR->DMA_CNT[2] - 1;
    chEvtSignalI(msrp->f2f_thd, MSR_SIGNAL_END);
  }
  else {
    HS_UART1->THR='E';
    msrp->errors |= MSR_TIMEOUT_ERROR;
    chEvtSignalI(msrp->f2f_thd, MSR_SIGNAL_ERROR);
  }

  osalSysUnlockFromISR();
}

/**
 * @brief   Common IRQ handler.
 *
 * @param[in] msrp      pointer to the @p MSRDriver object
 */
static void msr_serve_interrupt(MSRDriver *msrp) {

  uint16_t sr;

  osalDbgAssert(!(HS_MSR->CTL & (1u << 3)), "start DMA failed!");

  osalSysLockFromISR();

  sr = HS_MSR->INT_STA;
  HS_MSR->INT_STA = 0;
  HS_MSR->INT_MSK = ~sr; //temp workaround
  if (sr & (0x1 << 7)) {
    chVTSetI(&msrp->f2f_vt, OSAL_MS2ST(2000), _msr_swipe_timeout, &MSRD0);
    chEvtSignalI(msrp->f2f_thd, MSR_SIGNAL_START);
  }

  if (sr & (0xf << 3)) {
    if (sr & (0x9 << 3))
      msrp->errors |= MSR_BUS_ERROR;
    if (sr & (0x6 << 3))
      msrp->errors |= MSR_OVERRUN_ERROR;
    chVTResetI(&msrp->f2f_vt);
    chEvtSignalI(msrp->f2f_thd, MSR_SIGNAL_ERROR);
  }

  sr &= (0x1 << MSR_MAX_NR_TRACKS) - 1;
  msrp->pending ^= sr;
  if (0 == msrp->pending) {
    chVTResetI(&msrp->f2f_vt);
    chEvtSignalI(msrp->f2f_thd, MSR_SIGNAL_END);
  }

  osalSysUnlockFromISR();
}

/*===========================================================================*/
/* Driver interrupt handlers.                                                */
/*===========================================================================*/

/**
 * @brief   MSR IRQ handler.
 *
 * @isr
 */
OSAL_IRQ_HANDLER(MSR_IRQHandler) {

  OSAL_IRQ_PROLOGUE();

  msr_serve_interrupt(&MSRD0);

  OSAL_IRQ_EPILOGUE();
}

/*===========================================================================*/
/* Driver exported functions.                                                */
/*===========================================================================*/

/**
 * @brief   Low level MSR driver initialization.
 *
 * @notapi
 */
void msr_lld_init(void) {

  msrObjectInit(&MSRD0);
  chVTObjectInit(&MSRD0.f2f_vt);

  cpmResetSDHC();
  cpmEnableSDHC();
  HS_MSR->CTL = 1u << 4; //w1 to reset, hw clear
  HS_ANA->MAG_CFG = (1u << 0); //assert soft reset
  //HS_ANA->MAG_CFG |= (1u << 4); //dcoc cali en
  osalDbgAssert(!(HS_MSR->CTL & (1u << 4)), "reset failed!");
  HS_MSR->INT_MSK = 0xff; //enable all interrupts
  HS_ANA->MAG_CFG &= ~(1u << 0); //deassert soft reset
  nvicEnableVector(MSR_IRQn, HS_MSR_IRQ_PRIORITY);
}

/**
 * @brief   Configures and activates the MSR peripheral.
 *
 * @param[in] msrp      pointer to the @p MSRDriver object
 * @param[in] config    the architecture-dependent serial driver configuration.
 *                      If this parameter is set to @p NULL then a default
 *                      configuration is used.
 *
 * @notapi
 */
void msr_lld_start(MSRDriver *msrp, const MSRConfig *config) {

  uint16_t *buf = msrp->f2f_buf[0];
  int track;

  if (NULL == buf)
    return;

  if (NULL == config)
    config = &msr_default_config;

  if (msrp->state == MSR_STOP) {
    cpmEnableSDHC();
  }
  HS_MSR->CTL = 1u << 4; //w1 to reset, hw clear
  osalDbgAssert(!(HS_MSR->CTL & (1u << 4)), "reset failed!");

  HS_MSR->TH_LOW = (config->th_low[2] << 18) |
    (config->th_low[1] << 9) | (config->th_low[0] << 0);
  HS_MSR->TH_GAP = (config->th_gap[2] << 18) |
    (config->th_gap[1] << 9) | (config->th_gap[0] << 0);
  HS_ANA->MAG_TIMING = (HS_ANA->MAG_TIMING & 0x0000FFFF) |
    ((16000 / config->sample_rate) << 16u); //sample interval in 16mhz
  HS_MSR->DET_CNT = 4; //card swipe detect

  for (track = 0; track < MSR_MAX_NR_TRACKS; track++) {
    uint16_t len = config->f2f_len[track];
    if (((1u << track) & config->bitmap_tracks) &&
        (len > 0)) {
      HS_MSR->DMA_ADDR[track] = (uint32_t)buf;
      buf += len;
      HS_MSR->DMA_LEN[track] = len;
      HS_MSR->CTL |= (1u << (0+track));
      HS_ANA->MAG_CFG |= (1u << (8+track));
    }
  }
  for (track = 0; track < MSR_MAX_NR_TRACKS; track++) {
    msrp->f2f_buf[track] = (uint16_t *)HS_MSR->DMA_ADDR[track];
    msrp->dec_buf[track] = (uint8_t *)buf;
    buf += HS_MSR->DMA_LEN[track] / 5 / 2;
  }
  msrp->pending = config->bitmap_tracks;
  msrp->config = config;
  msrp->errors = MSR_NO_ERROR;

  nds32_dcache_flush();
  HS_MSR->INT_MSK = 0xff;
  HS_MSR->CTL |= (1u << 3); //start DMA
}

/**
 * @brief   Deactivates the MSR peripheral.
 *
 * @param[in] msrp      pointer to the @p MSRDriver object
 *
 * @notapi
 */
void msr_lld_stop(MSRDriver *msrp) {

  if (msrp->state != MSR_STOP) {

    HS_MSR->INT_MSK = 0;
    cpmDisableSDHC();
  }
}

#endif /* HAL_USE_MSR */

/** @} */
