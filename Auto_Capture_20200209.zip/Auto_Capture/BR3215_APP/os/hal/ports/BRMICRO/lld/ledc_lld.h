#ifndef _LEDC_LLD_H_
#define _LEDC_LLD_H_

#if (HAL_USE_LEDC == TRUE) || defined(__DOXYGEN__)

/*===========================================================================*/
/* Driver constants.                                                         */
/*===========================================================================*/

#define LEDC_MAX_SCAN_REG     42
#define LEDC_MAX_PIN_NUM       7

/**
 * @brief   Type of a structure representing an LEDC driver.
 */
typedef struct LEDCDriver LEDCDriver;

/**
 * @brief   Driver configuration structure.
 * @note    It could be empty on some architectures.
 */
typedef struct {
  #if defined(hscAudiophile)
  /**
   * @brief   User defined 7-segment display, see hs_cfg_led_ssd_t
   */
  uint8_t  pins[DISPLAY_LED_SSD_PIN_NUM];
  uint8_t  seg_table[DISPLAY_LED_DIGIT_NUM][DISPLAY_LED_SEGMENT_NUM];
  uint8_t  icon_table[DISPLAY_LED_ICON_NUM];
  uint8_t  pin_num;
  uint8_t  digit_num;
  uint8_t  icon_num;
  uint16_t rate;
  #else
  /**
   *
   */
    uint16_t period;
    uint8_t max_scan_num;
  #endif
} LEDCConfig;

/**
 * @brief   Structure representing an WDG driver.
 */
struct LEDCDriver {
  /**
   * @brief   Driver state.
   */
  ledcstate_t                state;
  /**
   * @brief   Current configuration data.
   */
  const LEDCConfig           *config;
  /* End of the mandatory fields.*/
  /**
   * @brief   Pointer to the LEDC registers block.
   */
  HS_LEDC_Type               *ledc;
};


/*===========================================================================*/
/* External declarations.                                                    */
/*===========================================================================*/

extern LEDCDriver LEDCD0;

#ifdef __cplusplus
extern "C" {
#endif
  void ledc_lld_init(void);
  void ledc_lld_start(LEDCDriver *ledcp);
  void ledc_lld_clear_reg(LEDCDriver *ledcp, uint32_t reg_start, uint32_t reg_end);
  void ledc_lld_scan_reg(LEDCDriver *ledcp, const uint16_t *scan_reg, uint32_t scan_reg_len, uint32_t reg_start);
  void ledc_lld_stop(LEDCDriver *ledcp);
#ifdef __cplusplus
}
#endif

#endif  /*HAL_USE_LEDC == TRUE*/

#endif  /* _LEDC_LLD_H_ */

