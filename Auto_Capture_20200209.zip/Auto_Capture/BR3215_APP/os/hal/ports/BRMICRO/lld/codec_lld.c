/*
    ChibiOS/RT - Copyright (C) 2006-2013 Giovanni Di Sirio
                 Copyright (C) 2019 BRMICRO Technologies
                 
                 

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    br32xx/codec_lld.c
 * @brief   audio codec Driver subsystem low level driver source template.
 *
 * @addtogroup CODEC
 * @{
 */

#include <string.h>
#include "hal.h"
#include "chprintf.h"

#if HAL_USE_AUDIO || defined(__DOXYGEN__)

#if defined(hscAudiophile)
extern void hs_audio_PAon(void);
extern void hs_audio_PAoff(void);
extern bool hs_audio_PAisOn(void);
extern void hs_codec_init(void);
#else
#define hs_audio_PAon()
#define hs_audio_PAoff()
#define hs_audio_PAisOn() true
static void hs_codec_init(void)
{
  uint8_t drv_type = 1;
  uint8_t dac_latency = 30; //30*10ms
  uint8_t drv_gain = 0;
  uint8_t mic_type = 3; //RR
  uint8_t dac_mixer = 0, adc_mixer = 0;
  #if defined(BR3215e)
  drv_gain = 0x0f; //0dB
  #endif

  #if defined(BR3215)
  if (drv_type == 1/*single*/) {
    /* reg<299:302> */
    HS_ANA->REGS.EN_VCM_LDO   = 1;
    HS_ANA->REGS.SEL_PA_RES   = 0;
    HS_ANA->REGS.EN_PA_VCM    = 1;
    HS_ANA->REGS.EN_PA_SINGLE = 1;
  }
  else {
    HS_ANA->REGS.EN_VCM_LDO   = 0;
    HS_ANA->REGS.SEL_PA_RES   = 0;
    HS_ANA->REGS.EN_PA_VCM    = 0;
    HS_ANA->REGS.EN_PA_SINGLE = 0;
  }
  /* reg<300> */
  HS_ANA->REGS.SEL_PA_RES = 0; //1: inner resister in xKohm to AGND
  /* reg<303> */
  HS_ANA->REGS.SEL_PKG = 1; //pkg_type=1: single path
  /* reg<36> */
  HS_ANA->REGS.DRV_GAIN = drv_gain;
  #endif

  #if defined(BR3215e)
  /* en_pa_single_au */
  __codec_set_bitsval(HS_CODEC->ANA_CTRL_2, 16, 16, drv_type);
  /* en_innres_au=0: don't use inner resister */
  __codec_clr_bit(HS_CODEC->ANA_CTRL_2, 22);
  /* drv_gain_l/r_au<5:0> */
  __codec_set_bitsval(HS_CODEC->ANA_CTRL_3, 0, 5, drv_gain);
  __codec_set_bitsval(HS_CODEC->ANA_CTRL_3, 8, 13, drv_gain);
  #endif

  __codec_dac_enable();
  __codec_adc_enable();
  __codec_set_bitsval(HS_CODEC->DAC_VOL_CTRL, 3, 3, dac_mixer);
  __codec_set_bitsval(HS_CODEC->ADC_VOL_CTRL, 3, 3, adc_mixer);
  __codec_set_bitsval(HS_CODEC->IF_CTRL,      2, 3, mic_type);
  //__codec_dac_disable();
  //__codec_adc_disable();

  CODECD.dac_latency = dac_latency;
}
#endif

/*===========================================================================*/
/* Driver local definitions.                                                 */
/*===========================================================================*/
/* play digital gain: in 0.1dB, max (149-100)/2=24dB, min (0-100)/2=-50dB, default 95=-2.5dB */
#define DDB2VOL_DAC(ddb)    (uint8_t)((ddb)/10 < -50 ? 0 : (ddb)/10 > 24 ? 149 : (ddb)/5 + 100)
#define DDB2VOL_DAC_WM(ddb) (uint8_t)((ddb)/10 < -73 ? 0 : (ddb)/10 * 1 + 0x079)
#define VOL2DDB_DAC(vol)    (((int)vol - 100) * 10 / 2)

/* record digital gain: in 0.1dB, max (149-100)/2=24dB, min (0-100)/2=-50dB */
#define DDB2VOL_ADC(ddb)    (uint8_t)((ddb)/10 < -50 ? 0 : (ddb)/10 > 24 ? 149 : (ddb)/5 + 100)
#define DDB2VOL_ADC_WM(ddb) (uint8_t)((ddb) < -97 ? 0 : (ddb) * 2 + 0x0c3)
#define VOL2DDB_ADC(vol)    (((int)vol - 100) * 10 / 2)

/* play fade in/out: 2^fade/sampe_rate*vol = ms *2? */
#define MS2FADE(ms, sample_rate) ((ms) == 0 ? 0 : 32 - __CLZ(DIV_ROUND((ms) * (sample_rate), 1000 * ((HS_CODEC->DAC_VOL_CTRL >> 8) & 0xff))))

/* CODEC_TEST_MODE register value */
#define LOOP_MODE_0                 0x01  //digital loopback

#define POWER_ON_FSM_HW             0

enum {
    I2S_BCLK_3MHZ     = 0,
    I2S_BCLK_6MHZ     ,
    I2S_BCLK_12MHZ    ,
    I2S_BCLK_0P6MHZ   ,
    I2S_BCLK_1P2MHZ   ,
    I2S_BCLK_2P4MHZ   ,
    I2S_BCLK_4P8MHZ   ,
};

#if HS_CODEC_USE_WM8753
/* DAC control */
#define WM8753_DACMUTE      1

/* digital hi-fi audio interface format */
#define WM8753_WL_32        3
#define WM8753_WL_24        2
#define WM8753_WL_20        1
#define WM8753_WL_16        0

#define WM8753_FT_DSP       (3 << 0)
#define WM8753_FT_I2S       (2 << 0)
#define WM8753_FT_LEFT      (1 << 0)
#define WM8753_FT_RIGHT     (0 << 0)

/* power management 1*/
#define VMIDSEL_DISABLED    0
#define VMIDSEL_50K         1
#define VMIDSEL_500K        2
#define VMIDSEL_5K          3

/* power management 2 */
#define MICAMP1EN           1
#define MICAMP2EN           1
#define ALCMIX              1
#define PGAL                1
#define PGAR                1
#define ADCL                1
#define ADCR                1
#define RXMIX               1
#define LINEMIX             1

/* power management 3*/
#define LOUT1               1
#define ROUT1               1

/* power management 4 */
#define RIGHTMIX            1
#define LEFTMIX             1

#define VREF                1
#define MICB                1
#define VDAC                1
#define DACL                1
#define DACR                1
#define DIGENB              0

/* clock inputs */
#define WM8753_MCLK         0
#define WM8753_PCMCLK       1

/* clock divider id's */
#define WM8753_PCMDIV       0
#define WM8753_BCLKDIV      1
#define WM8753_VXCLKDIV     2

/* left mixer control 1 */
#define LD2LO               1
#define LM2LO               1

/* left output mixer control 1 */
#define RD2RO               1
#define RM2RO               1

/* PCM clock dividers */
#define WM8753_PCM_DIV_1    (0 << 6)
#define WM8753_PCM_DIV_3    (2 << 6)
#define WM8753_PCM_DIV_5_5  (3 << 6)
#define WM8753_PCM_DIV_2    (4 << 6)
#define WM8753_PCM_DIV_4    (5 << 6)
#define WM8753_PCM_DIV_6    (6 << 6)
#define WM8753_PCM_DIV_8    (7 << 6)

/* BCLK clock dividers */
#define WM8753_BCLK_DIV_1   (0 << 3)
#define WM8753_BCLK_DIV_2   (1 << 3)
#define WM8753_BCLK_DIV_4   (2 << 3)
#define WM8753_BCLK_DIV_8   (3 << 3)
#define WM8753_BCLK_DIV_16  (4 << 3)

/* VXCLK clock dividers */
#define WM8753_VXCLK_DIV_1  (0 << 6)
#define WM8753_VXCLK_DIV_2  (1 << 6)
#define WM8753_VXCLK_DIV_4  (2 << 6)
#define WM8753_VXCLK_DIV_8  (3 << 6)
#define WM8753_VXCLK_DIV_16 (4 << 6)

#define WM8753_DAI_HIFI     0
#define WM8753_DAI_VOICE    1

#define WM8753_MAC1ALC      1

/* SAMPCTRL values for the supported samplerates (24MHz MCLK/USB): */
#define WM8753_USB24_8000HZ   0x60
#define WM8753_USB24_8021HZ   0x17
#define WM8753_USB24_11025HZ  0x19
#define WM8753_USB24_12000HZ  0x08
#define WM8753_USB24_16000HZ  0x0A
#define WM8753_USB24_22058HZ  0x1B
#define WM8753_USB24_24000HZ  0x1C
#define WM8753_USB24_32000HZ  0x0C
#define WM8753_USB24_44118HZ  0x11
#define WM8753_USB24_48000HZ  0x00
#define WM8753_USB24_88235HZ  0x1F
#define WM8753_USB24_96000HZ  0x0E

#define WM8753_DAC        0x01
#define WM8753_ADC        0x02
#define WM8753_PCM        0x03
#define WM8753_HIFI       0x04
#define WM8753_IOCTL      0x05
#define WM8753_SRATE1     0x06
#define WM8753_SRATE2     0x07
#define WM8753_LDAC       0x08
#define WM8753_RDAC       0x09
#define WM8753_BASS       0x0a
#define WM8753_TREBLE     0x0b
#define WM8753_ALC1       0x0c
#define WM8753_ALC2       0x0d
#define WM8753_ALC3       0x0e
#define WM8753_NGATE      0x0f
#define WM8753_LADC       0x10
#define WM8753_RADC       0x11
#define WM8753_ADCTL1     0x12
#define WM8753_3D         0x13
#define WM8753_PWR1       0x14
#define WM8753_PWR2       0x15
#define WM8753_PWR3       0x16
#define WM8753_PWR4       0x17
#define WM8753_ID         0x18
#define WM8753_INTPOL     0x19
#define WM8753_INTEN      0x1a
#define WM8753_GPIO1      0x1b
#define WM8753_GPIO2      0x1c
#define WM8753_RESET      0x1f
#define WM8753_RECMIX1    0x20
#define WM8753_RECMIX2    0x21
#define WM8753_LOUTM1     0x22
#define WM8753_LOUTM2     0x23
#define WM8753_ROUTM1     0x24
#define WM8753_ROUTM2     0x25
#define WM8753_MOUTM1     0x26
#define WM8753_MOUTM2     0x27
#define WM8753_LOUT1V     0x28
#define WM8753_ROUT1V     0x29
#define WM8753_LOUT2V     0x2a
#define WM8753_ROUT2V     0x2b
#define WM8753_MOUTV      0x2c
#define WM8753_OUTCTL     0x2d
#define WM8753_ADCIN      0x2e
#define WM8753_INCTL1     0x2f
#define WM8753_INCTL2     0x30
#define WM8753_LINVOL     0x31
#define WM8753_RINVOL     0x32
#define WM8753_MICBIAS    0x33
#define WM8753_CLOCK      0x34
#define WM8753_PLL1CTL1   0x35
#define WM8753_PLL1CTL2   0x36
#define WM8753_PLL1CTL3   0x37
#define WM8753_PLL1CTL4   0x38
#define WM8753_PLL2CTL1   0x39
#define WM8753_PLL2CTL2   0x3a
#define WM8753_PLL2CTL3   0x3b
#define WM8753_PLL2CTL4   0x3c
#define WM8753_BIASCTL    0x3d
#define WM8753_ADCTL2     0x3f

#define WM8753_PLL1       0
#define WM8753_PLL2       1

struct reg_default {
	unsigned int reg;
	unsigned int def;
};
#endif /* HS_CODEC_USE_WM8753 */

/*===========================================================================*/
/* Driver exported variables.                                                */
/*===========================================================================*/

/**
* @brief   CODEC driver identifier.
*/
#if !defined(__DOXYGEN__)
CODECDriver CODECD;
#endif

/*===========================================================================*/
/* Driver local variables and types.                                         */
/*===========================================================================*/

#if HS_CODEC_USE_WM8753

#define WM8753_DEV_I2C            (&I2CD0)
#define WM8753_I2C_ADDR           0x1a
#define WM8753_I2C_WRCMD_LEN      2
#endif

/*===========================================================================*/
/* Driver local functions.                                                   */
/*===========================================================================*/
static void codec_lld_start_dac_drv(CODECDriver *codecp);
static void codec_lld_stop_dac_drv(CODECDriver *codecp);
static void _codec_set_drv_input(hs_codec_drv_input_t input, hs_codec_channel_t ch);

static void udelay(int us)
{
  //delay_4cycles(us * (cpm_get_clock(HS_CPU_CLK) / 1000 / 1000 / 4));
  osalSysPolledDelayX(us * CODECD.cpu_mhz);
}

#if HS_CODEC_USE_INSIDE
#if defined(BR3215e)
typedef enum {
  ANALOG_ALL,
  ANALOG_COMMON,
  ANALOG_PLAY,
  ANALOG_RECORD,
} hs_codec_analog_module_t;

__STATIC_INLINE void _codec_analog_fsm(bool bOn, hs_codec_analog_module_t module)
{
  /* 0: controlled by fsm */
  #define ALL_BITS    0x1ffffff
  #define COMMON_BITS (1u<<(5-5))
  #define RECORD_BITS ((1u<<(13-5) | (1u<<(12-5)) | (1u<<(11-5)) | (1u<<(10-5)) | (1u<<(9-5)) | (1u<<(8-5)) | (1u<<(6-5))))
  switch (module) {
  case ANALOG_ALL:
    __codec_set_bitsval(HS_CODEC->ANA_CTRL_4, 5, 29, 0);
    __codec_set_bitsval(HS_CODEC->ANA_PWR_4, 24, 25, 0);
    break;
  case ANALOG_COMMON:
    /* audio_ldo_ctrl=0 */
    __codec_set_bitsval(HS_CODEC->ANA_CTRL_4, 5, 29, ALL_BITS & ~COMMON_BITS);
    __codec_set_bitsval(HS_CODEC->ANA_PWR_4, 24, 25, 0x3);
    break;
  case ANALOG_PLAY:
    __codec_set_bitsval(HS_CODEC->ANA_CTRL_4, 5, 29, COMMON_BITS | RECORD_BITS);
    __codec_set_bitsval(HS_CODEC->ANA_PWR_4, 24, 25, 0);
    break;
  case ANALOG_RECORD:
    /* pd_adc_core, pd_adc_bias, pd_pga, audio_adc_ctrl =0 */
    __codec_set_bitsval(HS_CODEC->ANA_CTRL_4, 5, 29, ALL_BITS & ~RECORD_BITS);
    __codec_set_bitsval(HS_CODEC->ANA_PWR_4, 24, 25, 0x3);
    break;
  default:
    break;
  }

  /* workaround of on twice, with toggle clk_32k_en */
  __codec_clr_bit(HS_CODEC->CLK_CTRL_1, 4);
  udelay(1);
  __codec_set_bit(HS_CODEC->CLK_CTRL_1, 4);
  if (bOn) {
    /* audio_on_en=1 */
    __codec_set_bit(HS_CODEC->ANA_PWR_4, 26);
  }
  else {
    /* audio_on_en=0 */
    __codec_clr_bit(HS_CODEC->ANA_PWR_4, 26);
    /* audio_off_en=1 */
    __codec_set_bit(HS_CODEC->ANA_PWR_4, 27);
  }
}

void _codec_debug_timing(int t)
{
  #if 1
  (void)t;
  #else
  uint32_t ac2 = HS_CODEC->ANA_CTRL_2;
  uint32_t ac3 = HS_CODEC->ANA_CTRL_3;
  debug("t%d: 2=0x%8lx 3=0x%8lx\n", t, ac2, ac3);
  printf("drv1=%lx ", (ac2 >> 30) & 0x3);
  printf("drv=%lx ", (ac2 >> 28) & 0x3);
  printf("vramp=%1lx ", (ac2 >> 19) & 0x1);
  printf("vcom0=%1lx ", (ac2 >> 18) & 0x1);
  printf("vcombuf=%1lx ", (ac2 >> 17) & 0x1);
  printf("balance=%1lx ", (ac2 >> 14) & 0x1);
  printf("tia1=%lx ", (ac2 >> 10) & 0x3);
  printf("tia=%lx ", (ac2 >> 8) & 0x3);
  printf("dac=%lx ", (ac2 >> 6) & 0x3);

  printf("avdd12=%1lx ", (ac3 >> 31) & 0x1);
  printf("ldo_drv=%1lx ", (ac3 >> 30) & 0x1);
  printf("en_byp_auref=%1lx ", (ac3 >> 21) & 0x1);
  printf("auref=%1lx ", (ac3 >> 20) & 0x1);
  printf("s2=%lx ", (ac3 >> 18) & 0x3);
  printf("s1=%1lx%1lx ", (ac3 >> 15) & 0x1, (ac3 >> 7) & 0x1);
  printf("s0=%1lx%01lx\n", (ac3 >> 14) & 0x1, (ac3 >> 6) & 0x1);
  #endif
}
#endif

__STATIC_INLINE void _codec_analog_drv1(bool bOn)
{
  #if defined(BR3215)
  /* reg<319,318> */
  if (bOn) {
    HS_ANA->REGS.PD_DRV1_L = 0;
    HS_ANA->REGS.PD_DRV1_R = 0;
  }
  else {
    HS_ANA->REGS.PD_DRV1_L = 1;
    HS_ANA->REGS.PD_DRV1_R = 1;
  }
  #endif

  #if defined(BR3215e)
  /* pd_drv1_l/r_au */
  __codec_set_bitsval(HS_CODEC->ANA_CTRL_2, 30, 31, bOn ? 0 : 3);
  #endif
}

__STATIC_INLINE void _codec_analog_drv(bool bOn)
{
  #if defined(BR3215)
  /* pd_audrv_l/r_1p2 */
  __codec_set_bitsval(HS_ANA->AU_ANA_CFG[0], 7, 8, bOn ? 0 : 3);
  #endif

  #if defined(BR3215e)
  /* pd_drv_l/r_au */
  __codec_set_bitsval(HS_CODEC->ANA_CTRL_2, 28, 29, bOn ? 0 : 3);
  #endif
}

static void _lazy_turn_on_audio_pa(void *parg)
{
  (void)parg;
  hs_audio_PAon();
}

#if defined(BR3215)
static void _lazy_turn_on_audio_drv(void *parg)
{
  (void)parg;
  _codec_analog_drv(true);
}
#endif

static void _codec_setup_dac_drv_pa_timing(CODECDriver *codecp, bool enable)
{
  //debug("enable=%d PA=%d DAC=%d CLK=%d\n", enable, hs_audio_PAisOn(), HS_CODEC->DAC_CTRL & (1u << 8), HS_CODEC->CLK_CTRL_1 & (1u << 3));

  if (enable) {
    /* don't double enable */
    if (!codecp->isPlayed) {
      codecp->isPlayed = true;
      /* start dac & drv & audio PA */
      codec_lld_start_dac_drv(codecp);
    }
  }
  else {
    if (codecp->isPlayed) {
      codecp->isPlayed = false;
      /* stop dac & drv & audio PA */
      codec_lld_stop_dac_drv(codecp);
    }
  }
}

static inline void _codec_analog_audioPowerOn(void)
{
  #if defined(BR3215)
  /* pd_au_ldo_1p2 */
  __codec_clr_bit(HS_ANA->AU_ANA_CFG[0], 17);
  udelay(2);
  #endif

  #if defined(BR3215e)
  /* pd_ldo_drv_au=pd_ldo_drv */
  __codec_clr_bit(HS_CODEC->ANA_CTRL_3, 30);
  osalThreadSleepMilliseconds(2);
  #endif
}

static inline void _codec_analog_audioPowerOff(void)
{
  #if defined(BR3215)
  __codec_set_bit(HS_ANA->AU_ANA_CFG[0], 17);
  #endif

  #if defined(BR3215e)
  __codec_set_bit(HS_CODEC->ANA_CTRL_3, 30);
  #endif
}

static inline void _codec_analog_refPowerOn(void)
{
  #if defined(BR3215)
  /* AUDIO_v02_20170811.pdf by zhou */
  /* pd_au_biasgen_1p2 */
  __codec_clr_bit(HS_ANA->AU_ANA_CFG[0], 19);
  /* pd_au_ref_1p2 */
  __codec_clr_bit(HS_ANA->AU_ANA_CFG[0], 14);
  HS_ANA->REGS.REF_FAST = 1;
  HS_ANA->REGS.REF_BYP  = 1;

  osalThreadSleepMilliseconds(30);
  HS_ANA->REGS.REF_FAST = 0;

  osalThreadSleepMilliseconds(100-30);
  HS_ANA->REGS.REF_BYP  = 0;
  #endif

  #if defined(BR3215e)
  /* pd_auref */
  __codec_clr_bit(HS_CODEC->ANA_CTRL_3, 20);
  /* en_byp_auref_au=en_auref_byp=1 for fast settling */
  __codec_set_bit(HS_CODEC->ANA_CTRL_3, 21);
  osalThreadSleepMilliseconds(50);
  /* pd_bias_gen_au=pd_bias_gen */
  __codec_clr_bit(HS_CODEC->ANA_CTRL_3, 22);
  udelay(1);
  #endif
}

static inline void _codec_analog_refPowerOff(void)
{
  #if defined(BR3215)
  __codec_set_bit(HS_ANA->AU_ANA_CFG[0], 19);
  __codec_set_bit(HS_ANA->AU_ANA_CFG[0], 14);
  /* reg<28> */
  HS_ANA->REGS.REF_FAST = 0;
  /* reg<27> */
  HS_ANA->REGS.REF_BYP  = 0;
  #endif

  #if defined(BR3215e)
  __codec_set_bit(HS_CODEC->ANA_CTRL_3, 22);
  __codec_set_bit(HS_CODEC->ANA_CTRL_3, 20);
  #endif
}

static inline void _codec_analog_clkPowerOn(void)
{
  #if defined(BR3215)
  /* pd_au_ck_1p2 */
  __codec_clr_bit(HS_ANA->AU_ANA_CFG[0], 18);
  udelay(2);
  #endif

  #if defined(BR3215e)
  /* pd_clk_au=pd_clk */
  __codec_clr_bit(HS_CODEC->ANA_CTRL_1, 29);
  /* en_byp_auref_au=en_auref_byp=0 */
  __codec_clr_bit(HS_CODEC->ANA_CTRL_3, 21);
  #endif
}

static inline void _codec_analog_clkPowerOff(void)
{
  #if defined(BR3215)
  __codec_set_bit(HS_ANA->AU_ANA_CFG[0], 18);
  udelay(2);
  #endif

  #if defined(BR3215e)
  __codec_set_bit(HS_CODEC->ANA_CTRL_1, 29);
  #endif
}

static inline void _codec_analog_vddPowerOn(void)
{
  #if defined(BR3215)
  /* pd_audvdd_ldo_1p2 */
  __codec_clr_bit(HS_ANA->AU_ANA_CFG[0], 6);
  /* pd_auavdd_ldo_1p2 */
  __codec_clr_bit(HS_ANA->AU_ANA_CFG[0], 15);
  /* pd_audrv_ldo_1p2 */
  __codec_clr_bit(HS_ANA->AU_ANA_CFG[0], 9);
  udelay(100); //LDO settle time
  #endif

  #if defined(BR3215e)
  /* pd_ldo_dvdd_au=pd_dldo12 */
  __codec_clr_bit(HS_CODEC->ANA_CTRL_4, 4);
  /* pd_ldo_avdd12_au=pd_aldo12 */
  __codec_clr_bit(HS_CODEC->ANA_CTRL_3, 31);
  udelay(2);
  #endif
}

static inline void _codec_analog_vddPowerOff(void)
{
  #if defined(BR3215)
  __codec_set_bit(HS_ANA->AU_ANA_CFG[0], 9);
  __codec_set_bit(HS_ANA->AU_ANA_CFG[0], 15);
  __codec_set_bit(HS_ANA->AU_ANA_CFG[0], 6);
  #endif

  #if defined(BR3215e)
  __codec_set_bit(HS_CODEC->ANA_CTRL_4, 4);
  __codec_set_bit(HS_CODEC->ANA_CTRL_3, 31);
  #endif
  udelay(2);
}

static inline void _codec_analog_adcPowerOn(void)
{
  #if defined(BR3215)
  /* pd_auadc_l/r_1p2 */
  __codec_set_bitsval(HS_ANA->AU_ANA_CFG[0], 12, 13, 0);
  HS_ANA->REGS.RST_ADC = 1;
  HS_ANA->REGS.EN_ADC_DITHER = 1;
  HS_ANA->REGS.EN_ADC_DEM = 1;
  udelay(1);
  HS_ANA->REGS.RST_ADC = 0;
  HS_ANA->REGS.SHRT_ADC = 0;
  udelay(10);
  #endif

  #if defined(BR3215e)
  /* pd_adc_bias_l_au */
  __codec_clr_bit(HS_CODEC->ANA_CTRL_1, 18);
  /* pd_adc_bias_r_au */
  __codec_clr_bit(HS_CODEC->ANA_CTRL_1, 22);
  /* pd_adc_core_l_au */
  __codec_clr_bit(HS_CODEC->ANA_CTRL_1, 19);
  /* pd_adc_core_r_au */
  __codec_clr_bit(HS_CODEC->ANA_CTRL_1, 23);
  udelay(1);
  /* rst_adc high -> low */
  __codec_set_bit(HS_CODEC->ANA_CTRL_1, 30);
  udelay(1);
  __codec_clr_bit(HS_CODEC->ANA_CTRL_1, 30);
  #endif
}

static inline void _codec_analog_adcPowerOff(void)
{
  #if defined(BR3215)
  __codec_set_bitsval(HS_ANA->AU_ANA_CFG[0], 12, 13, 3);
  udelay(10);
  #endif

  #if defined(BR3215e)
  __codec_set_bitsval(HS_CODEC->ANA_CTRL_1, 18, 19, 3);
  __codec_set_bitsval(HS_CODEC->ANA_CTRL_1, 22, 23, 3);
  #endif
}

/*
 * @pga_gain_index
 *  BR3215:  000=-6dB;001=-3dB; 010=0dB;011=3dB;100=6dB;101=12dB;110=18dB;111=24dB
 *  BR3215e: line-in mode [1011:0000]=19dB:-14dB 3dB/step
 *           mic-in mode  [1011:0000]=30dB:-3dB  3dB/step
 */
static inline void _codec_analog_pgaPowerOn(int pga_gain_idx)
{
  #if defined(BR3215)
  /* pd_aupga_l/r_1p2 */
  __codec_set_bitsval(HS_ANA->AU_ANA_CFG[0], 4, 5, 0);
  udelay(2);
  HS_ANA->REGS.PGA_GAIN = pga_gain_idx;
  HS_ANA->REGS.SEL_ADC_INPUT = 0; //0=normal input
  udelay(10);
  #endif

  #if defined(BR3215e)
  /* pd_pgavref_au */
  __codec_clr_bit(HS_CODEC->ANA_CTRL_1, 28);
  udelay(2);
  /* pd_pga_l_au */
  __codec_clr_bit(HS_CODEC->ANA_CTRL_1, 3);
  /* pd_pga_r_au */
  __codec_clr_bit(HS_CODEC->ANA_CTRL_1, 11);
  udelay(1);
  /* pga_gain_l_au */
  __codec_set_bitsval(HS_CODEC->ANA_CTRL_1, 4, 7, pga_gain_idx);
  /* pga_gain_r_au */
  __codec_set_bitsval(HS_CODEC->ANA_CTRL_1, 12, 15, pga_gain_idx);
  /* sel_adc_input_au=0: normal input */
  __codec_clr_bit(HS_CODEC->ANA_CTRL_2, 4);
  #endif
}

static inline void _codec_analog_pgaPowerOff(void)
{
  #if defined(BR3215)
  __codec_set_bitsval(HS_ANA->AU_ANA_CFG[0], 4, 5, 3);
  udelay(2);
  #endif

  #if defined(BR3215e)
  __codec_set_bit(HS_CODEC->ANA_CTRL_1, 28);
  __codec_set_bit(HS_CODEC->ANA_CTRL_1, 3);
  __codec_set_bit(HS_CODEC->ANA_CTRL_1, 11);
  #endif
}

static int _codec_analog_micbiasCalibration(void)
{
  #if defined(BR3215)
  uint32_t tune = 0;
  /* pd_micbias_1p2, pd_micbias_cali_1p2 */
  __codec_set_bitsval(HS_ANA->AU_ANA_CFG[0], 0, 1, 0);
  udelay(2);

  HS_ANA->REGS.MICBIAS_TUNE = tune++;
  udelay(10);

  while( (HS_ANA->AU_ANA_CFG[0] & 0x80000000) == 0)
  {
    HS_ANA->REGS.MICBIAS_TUNE = tune++;
    udelay(10);

    if(tune > 15)
    {
      __codec_set_bit(HS_ANA->AU_ANA_CFG[0], 0);
      return -1;
    }
  }

  __codec_set_bit(HS_ANA->AU_ANA_CFG[0], 0);
  #endif
  return 0;
}

static void _codec_analog_commonPowerOn(void)
{
#if defined(BR3215e) && POWER_ON_FSM_HW
  _codec_analog_fsm(true, ANALOG_COMMON);
  return;
#endif

  _codec_analog_audioPowerOn();
  _codec_analog_refPowerOn();

  _codec_analog_vddPowerOn();
  _codec_analog_clkPowerOn();
}

static void _codec_analog_playPowerOn(CODECDriver *codecp)
{
#if defined(BR3215e) && POWER_ON_FSM_HW
  _codec_analog_fsm(true, ANALOG_PLAY);
  return;
#endif

  /* AUDIO_v02_20170811.pdf by zhou: timing TIA_DRV -> DAC -> DRV1 -> AUDRV */
  #if defined(BR3215)
  /* pd_autia_l/r_1p2 */
  __codec_set_bitsval(HS_ANA->AU_ANA_CFG[0], 2, 3, 0);
  udelay(100);
  /* pd_audac_l/r_1p2 */
  __codec_set_bitsval(HS_ANA->AU_ANA_CFG[0], 10, 11, 0);

  if (codecp->isVirgin) {
    udelay(100);
    _codec_analog_drv1(true);

    /* turn on audrv at the point of "blank" audio stream playback, SPK reaches ~1.4V for >600ms */
    chVTReset(&codecp->drv_timer);
    chVTSet(&codecp->drv_timer, OSAL_MS2ST(codecp->dac_latency*10), _lazy_turn_on_audio_drv, (void *)codecp);
    //osalThreadSleepMilliseconds(600);
    //_codec_analog_drv(true);

    codecp->isVirgin = false;
  }
  #endif

  #if defined(BR3215e)
  if (codecp->dac_latency == 23) {
    if (!codecp->isVirgin) {
      /* en_dac_balance=0 */
      __codec_clr_bit(HS_CODEC->ANA_CTRL_2, 14);
      return;
    }
    codecp->isVirgin = false;
    /* fall through when the 1st power on */
  }
  /* en_vcombuf=0? */
  //osalDbgCheck(0 == (HS_CODEC->ANA_CTRL_2 & (1u << 17)));
  if (0 != (HS_CODEC->ANA_CTRL_2 & (1u << 17))) { debug("ANA_CTRL 1=0x%08lx 2=0x%08lx 3=0x%08lx\n", HS_CODEC->ANA_CTRL_1, HS_CODEC->ANA_CTRL_2, HS_CODEC->ANA_CTRL_3); }
  /* s210=001 */
  __codec_set_bitsval(HS_CODEC->ANA_CTRL_3, 18, 19, 0);
  __codec_set_bitsval(HS_CODEC->ANA_CTRL_3, 14, 15, 1);
  __codec_set_bitsval(HS_CODEC->ANA_CTRL_3,  6,  7, 1);
  udelay(1);
  _codec_debug_timing(0);
  if (codecp->dac_latency < 30) {
    /* optimized timing of shorter power up */
    /* t1: s20=10 */
    __codec_set_bitsval(HS_CODEC->ANA_CTRL_3, 18, 19, 3);
    __codec_set_bitsval(HS_CODEC->ANA_CTRL_3, 14, 14, 0);
    __codec_set_bitsval(HS_CODEC->ANA_CTRL_3,  6,  6, 0);
    udelay(2);
    /* t2: sel_drv_input=2b'00 */
    _codec_set_drv_input(DRV_INPUT_FLOATING, CODEC_CHANNEL_BOTH);
    udelay(2);
    /* t3: en_dac_balance=1 */
    __codec_set_bit(HS_CODEC->ANA_CTRL_2, 14);
    udelay(2);
    /* t4: pd_dac=0 */
    __codec_set_bitsval(HS_CODEC->ANA_CTRL_2, 6, 7, 0);
    udelay(2);
    /* t5: pd_tia=0 */
    __codec_set_bitsval(HS_CODEC->ANA_CTRL_2, 8, 9, 0);
    udelay(2);
    /* t6: pd_tia1=0 */
    __codec_set_bitsval(HS_CODEC->ANA_CTRL_2, 10, 11, 0);
    udelay(2);
    /* t7: pd_drv=0 */
    __codec_set_bitsval(HS_CODEC->ANA_CTRL_2, 28, 29, 0);
    udelay(2);
    /* t8: pd_drv1=0 */
    __codec_set_bitsval(HS_CODEC->ANA_CTRL_2, 30, 31, 0);
    udelay(2);
    /* t9: en_vramp=1, en_vcom0=1 */
    __codec_set_bit(HS_CODEC->ANA_CTRL_2, 19);
    __codec_set_bit(HS_CODEC->ANA_CTRL_2, 18);
    if (codecp->pa_latency > 0) {
      /* reduce the time of power up, and hide the pop noise with PCB PA */
      osalThreadSleepMilliseconds(1);
    }
    else {
      osalThreadSleepMilliseconds(codecp->dac_latency * 10);
    }
    /* t10: en_vcombuf=1 */
    __codec_set_bit(HS_CODEC->ANA_CTRL_2, 17);
    udelay(10);
    /* t11: en_vramp=0, en_vcom0=0 */
    __codec_clr_bit(HS_CODEC->ANA_CTRL_2, 19);
    __codec_clr_bit(HS_CODEC->ANA_CTRL_2, 18);
    udelay(2);
    /* t12: sel_drv_input=2'b01 */
    _codec_set_drv_input(DRV_INPUT_DAC, CODEC_CHANNEL_BOTH);
    udelay(2);
    /* t13: en_dac_balance=0 */
    __codec_clr_bit(HS_CODEC->ANA_CTRL_2, 14);
    udelay(2);
  }
  else {
    /* t0: s1=1 */
    __codec_set_bit(HS_CODEC->ANA_CTRL_3, 15);
    __codec_set_bit(HS_CODEC->ANA_CTRL_3, 7);
    udelay(2);
    _codec_debug_timing(1);
    /* t1: s0=0 */
    __codec_clr_bit(HS_CODEC->ANA_CTRL_3, 14);
    __codec_clr_bit(HS_CODEC->ANA_CTRL_3, 6);
    udelay(2);
    _codec_debug_timing(2);
    /* t2: en_vramp=1 */
    __codec_set_bit(HS_CODEC->ANA_CTRL_2, 19);
    udelay(2);
    _codec_debug_timing(3);
    /* t3: en_vcom0=1 */
    __codec_set_bit(HS_CODEC->ANA_CTRL_2, 18);
    if (codecp->pa_latency > 0) {
      /* reduce the time of power up, and hide the pop noise with PCB PA */
      osalThreadSleepMilliseconds(1);
    }
    else {
      osalThreadSleepMilliseconds(codecp->dac_latency * 10);
    }

    /* t4: pd_dac=0, en_dac_balance=1 */
    __codec_set_bitsval(HS_CODEC->ANA_CTRL_2, 6, 7, 0);
    __codec_set_bit(HS_CODEC->ANA_CTRL_2, 14);
    udelay(1);
    /* t5: pd_tia=0 */
    __codec_set_bitsval(HS_CODEC->ANA_CTRL_2, 8, 9, 0);
    udelay(2);
    /* t6: pd_tia1=0 */
    __codec_set_bitsval(HS_CODEC->ANA_CTRL_2, 10, 11, 0);
    udelay(2);
    /* t7: en_vramp=0 */
    __codec_clr_bit(HS_CODEC->ANA_CTRL_2, 19);
    udelay(2);
    /* t8: en_vcombuf=1 */
    __codec_set_bit(HS_CODEC->ANA_CTRL_2, 17);
    udelay(10);
    /* t9: s21=10 */
    __codec_set_bitsval(HS_CODEC->ANA_CTRL_3, 18, 19, 3);
    __codec_clr_bit(HS_CODEC->ANA_CTRL_3, 15);
    __codec_clr_bit(HS_CODEC->ANA_CTRL_3, 7);
    udelay(2);
    /* t10: en_vcom0=0 */
    __codec_clr_bit(HS_CODEC->ANA_CTRL_2, 18);
    udelay(2);
    /* t11: pd_drv=0 */
    __codec_set_bitsval(HS_CODEC->ANA_CTRL_2, 28, 29, 0);
    udelay(2);
    /* t12: pd_drv1=0 */
    __codec_set_bitsval(HS_CODEC->ANA_CTRL_2, 30, 31, 0);
    udelay(2);
    /* t13: en_dac_balance=0 */
    __codec_clr_bit(HS_CODEC->ANA_CTRL_2, 14);
    udelay(1);
  }
  /* t6: toggle pd_tia1 for some "bad" chips at lower volume level */
  __codec_set_bitsval(HS_CODEC->ANA_CTRL_2, 10, 11, 3);
  udelay(2);
  __codec_set_bitsval(HS_CODEC->ANA_CTRL_2, 10, 11, 0);
  udelay(2);
  #endif
}

static void _codec_analog_playPowerOff(CODECDriver *codecp)
{
#if defined(BR3215e) && POWER_ON_FSM_HW
  _codec_analog_fsm(false, ANALOG_PLAY);
  return;
#endif

  #if defined(BR3215)
  (void)codecp;
  #if 0 //keep drv & drv1 always on to reduce pop noise
  _codec_analog_drv(false);
  osalThreadSleepMilliseconds(100); /* due to _lazy_turn_off_dac_drv() */
  //udelay(1000);
  _codec_analog_drv1(false);
  udelay(100);
  #endif
  /* pd_audac_l/r_1p2 */
  __codec_set_bitsval(HS_ANA->AU_ANA_CFG[0], 10, 11, 3);
  udelay(100);
  /* pd_autia_l/r_1p2 */
  __codec_set_bitsval(HS_ANA->AU_ANA_CFG[0], 2, 3, 3);
  #endif

  #if defined(BR3215e)
  if (codecp->dac_latency == 23) {
    if (!codecp->isVirgin) {
      /* keep dac & tia & drv always on to reduce pop noise when playing is paused */
      /* en_dac_balance=1 */
      __codec_set_bit(HS_CODEC->ANA_CTRL_2, 14);
      return;
    }
    /* fall through when system power off */
  }
  _codec_debug_timing(0);
  /* t0: en_dac_balance=1 */
  __codec_set_bit(HS_CODEC->ANA_CTRL_2, 14);
  udelay(1);
  _codec_debug_timing(1);
  /* t1: pd_drv1=1 */
  __codec_set_bitsval(HS_CODEC->ANA_CTRL_2, 30, 31, 3);
  udelay(2);
  _codec_debug_timing(2);
  /* t2: pd_drv=1 */
  __codec_set_bitsval(HS_CODEC->ANA_CTRL_2, 28, 29, 3);
  udelay(2);
  _codec_debug_timing(3);
  /* t3: pd_tia=1, pd_tia1=1, pd_dac=1 */
  __codec_set_bitsval(HS_CODEC->ANA_CTRL_2, 8, 9, 3);
  __codec_set_bitsval(HS_CODEC->ANA_CTRL_2, 10, 11, 3);
  __codec_set_bitsval(HS_CODEC->ANA_CTRL_2, 6, 7, 3);
  udelay(1);
  _codec_debug_timing(4);
  /* t4: s21=01, en_vramp=1 */
  __codec_set_bitsval(HS_CODEC->ANA_CTRL_3, 18, 19, 0);
  __codec_set_bit(HS_CODEC->ANA_CTRL_3, 15);
  __codec_set_bit(HS_CODEC->ANA_CTRL_3, 7);
  __codec_set_bit(HS_CODEC->ANA_CTRL_2, 19);
  udelay(2);
  _codec_debug_timing(5);
  /* t5: en_vcombuf=0 */
  __codec_clr_bit(HS_CODEC->ANA_CTRL_2, 17);
  if (codecp->pa_latency > 0) {
    /* reduce the time of power down, and hide the pop noise with PCB PA */
    osalThreadSleepMilliseconds(1);
  }
  else {
    /* the time of discharge is longer than charge */
    osalThreadSleepMilliseconds(codecp->dac_latency * 10 + 100);
  }

  _codec_debug_timing(6);
  /* t6: s0=1 */
  __codec_set_bit(HS_CODEC->ANA_CTRL_3, 14);
  __codec_set_bit(HS_CODEC->ANA_CTRL_3, 6);
  udelay(1);
  _codec_debug_timing(7);
  /* t7: s1=0, en_vramp=0 */
  __codec_clr_bit(HS_CODEC->ANA_CTRL_3, 15);
  __codec_clr_bit(HS_CODEC->ANA_CTRL_3, 7);
  __codec_clr_bit(HS_CODEC->ANA_CTRL_2, 19);
  udelay(1);
  _codec_debug_timing(8);
  #endif
}

static void _codec_analog_recPowerOn(uint32_t pga_gain)
{
#if defined(BR3215e) && POWER_ON_FSM_HW
  _codec_analog_fsm(true, ANALOG_RECORD);
  return;
#endif

  _codec_analog_pgaPowerOn(pga_gain);
  _codec_analog_adcPowerOn();
}

static void _codec_analog_recPowerOff(void)
{
#if defined(BR3215e) && POWER_ON_FSM_HW
  _codec_analog_fsm(false, ANALOG_RECORD);
  return;
#endif

  _codec_analog_adcPowerOff();
  _codec_analog_pgaPowerOff();
}

static void _codec_analog_commonPowerOff(void)
{
#if defined(BR3215e) && POWER_ON_FSM_HW
  _codec_analog_fsm(false, ANALOG_ALL);
  return;
#endif

  _codec_analog_clkPowerOff();
  _codec_analog_vddPowerOff();

  _codec_analog_refPowerOff();
  _codec_analog_audioPowerOff();
}

static void _codec_set_deci_filt(CODECDriver *codecp, uint32_t sample_rate)
{
  if (sample_rate == 44100 ||
      sample_rate == 22050 ||
      sample_rate == 11025) {
       codecp->codec->ADC_DECI_FILT_11 = 0xd9f753aa;
       codecp->codec->ADC_DECI_FILT_12 = 0xe6fd133a;
       codecp->codec->ADC_DECI_FILT_13 = 0x133a;

       codecp->codec->ADC_DECI_FILT_21 = 0xce6b55b0;
       codecp->codec->ADC_DECI_FILT_22 = 0xdae922e1;
       codecp->codec->ADC_DECI_FILT_23 = 0x22e1;

       codecp->codec->ADC_DECI_FILT_31 = 0xe44c51f0;
       codecp->codec->ADC_DECI_FILT_32 = 0xee4f0e3c;
       codecp->codec->ADC_DECI_FILT_33 = 0x0e3c;

       codecp->codec->ADC_DECI_FILT_41 = 0xc6955755;

       codecp->codec->ADC_DECI_FILT_42 = 0xf648133a;
       codecp->codec->ADC_DECI_FILT_43 = 0x133a;

       codecp->codec->ADC_DECI_FILT_51 = 0xc1dc58f8;

       codecp->codec->ADC_DECI_FILT_52 = 0x11e10e51;
       codecp->codec->ADC_DECI_FILT_53 = 0x0e51;
  }
  else{
    codecp->codec->ADC_DECI_FILT_11 = 0xcbed6256;
    codecp->codec->ADC_DECI_FILT_12 = 0xe7b7117f;
    codecp->codec->ADC_DECI_FILT_13 = 0x117f;

    codecp->codec->ADC_DECI_FILT_21 = 0xd59c5ea3;
    codecp->codec->ADC_DECI_FILT_22 = 0xcbe12186;
    codecp->codec->ADC_DECI_FILT_23 = 0x2186;

    codecp->codec->ADC_DECI_FILT_31 = 0xc56b6500;
    codecp->codec->ADC_DECI_FILT_32 = 0xf3d60cb5;
    codecp->codec->ADC_DECI_FILT_33 = 0x0cb5;

    codecp->codec->ADC_DECI_FILT_41 = 0xde5f5b59;

    codecp->codec->ADC_DECI_FILT_42 = 0xe567118f;
    codecp->codec->ADC_DECI_FILT_43 = 0x118f;

    codecp->codec->ADC_DECI_FILT_51 = 0xc1866709;

    codecp->codec->ADC_DECI_FILT_52 = 0x0b1e0cb5;
    codecp->codec->ADC_DECI_FILT_53 = 0x0cb5;
  }
}

static void _codec_set_drv_input(hs_codec_drv_input_t input, hs_codec_channel_t ch)
{
  #if defined(BR3215)
  (void)ch;
  switch (input) {
  case DRV_INPUT_DAC:
    HS_ANA->REGS.DRV_SEL_INPUT = 0;
    break;
  case DRV_INPUT_PGA:
    HS_ANA->REGS.DRV_SEL_INPUT = 1;
    break;
  default:
    break;
  }
  #endif

  #if defined(BR3215e)
  if ((CODEC_CHANNEL_LEFT == ch) || (CODEC_CHANNEL_BOTH == ch)) {
    __codec_set_bitsval(HS_CODEC->ANA_CTRL_2, 24, 25, input);
  }
  if ((CODEC_CHANNEL_RIGHT == ch) || (CODEC_CHANNEL_BOTH == ch)) {
    __codec_set_bitsval(HS_CODEC->ANA_CTRL_2, 26, 27, input);
  }
  #endif
}

static void _codec_set_pga_input(hs_codec_pga_input_t input, hs_codec_channel_t ch)
{
  #if defined(BR3215)
  (void)ch;
  switch (input) {
  case PGA_INPUT_VIP_MIC:
    HS_ANA->REGS.SEL_PGA_INPUT = 0;
    break;
  case PGA_INPUT_VIP_LINE:
    HS_ANA->REGS.SEL_PGA_INPUT = 1;
    break;
  default:
    break;
  }
  #endif

  #if defined(BR3215e)
  if ((CODEC_CHANNEL_LEFT == ch) || (CODEC_CHANNEL_BOTH == ch)) {
    __codec_set_bitsval(HS_CODEC->ANA_CTRL_1, 0, 2, input);
  }
  if ((CODEC_CHANNEL_RIGHT == ch) || (CODEC_CHANNEL_BOTH == ch)) {
    __codec_set_bitsval(HS_CODEC->ANA_CTRL_1, 8, 10, input);
  }
  /* [30]en_pga_singlein_au */
  switch (input) {
  case PGA_INPUT_VIP_MIC:
  case PGA_INPUT_VIP_MIC_1:
  case PGA_INPUT_VIP_MIC_2:
    /* single input */
    HS_CODEC->ANA_CTRL_4 |= (1u << 30);
    break;
  case PGA_INPUT_VIP_LINE:
  case PGA_INPUT_VIP_LINE_1:
  case PGA_INPUT_VIP_LINE_2:
  case PGA_INPUT_VIP_LINE_3:
    /* difference input */
    HS_CODEC->ANA_CTRL_4 &= ~(1u << 30);
    break;
  default:
    break;
  }
  #endif
}

#endif  //HS_CODEC_USE_INSIDE

static uint32_t _codec_get_bclk(uint32_t sample_rate, uint32_t width, uint32_t *pbclk)
{
  uint32_t bclk, res = 12000000, bclk_flg = I2S_BCLK_12MHZ;

  bclk = sample_rate * 2 * (width + 1);
  if ((sample_rate == 44100) ||
      (sample_rate == 22050) ||
      (sample_rate == 11025)) {
    bclk = 3000000;
  }

  if(bclk <= 600000)
  {
    bclk_flg = I2S_BCLK_0P6MHZ;
    res = 600000;
  }

  if(bclk > 600000)
  {
    bclk_flg = I2S_BCLK_1P2MHZ;
    res = 1200000;
  }

  if(bclk > 1200000)
  {
    bclk_flg = I2S_BCLK_2P4MHZ;
    res = 2400000;
  }

  if(bclk > 2400000)
  {
    bclk_flg = I2S_BCLK_3MHZ;
    res = 3000000;
  }

  if(bclk > 3000000)
  {
    bclk_flg = I2S_BCLK_4P8MHZ;
    res = 4800000;
  }

  if(bclk > 4800000)
  {
    bclk_flg = I2S_BCLK_6MHZ;
    res = 6000000;
  }

  if(bclk > 6000000)
  {
    bclk_flg = I2S_BCLK_12MHZ;
    res = 12000000;
  }

  *pbclk = bclk_flg;

  return res;
}

static void _codec_set_samplerate(CODECDriver *codecp, uint32_t sample_rate, hs_audio_dir_t dir)
{
  uint32_t ws_width = 32; //always 32-bit on I2S bus regardless sample bits is 8/16/24.
  uint32_t bclk, bclk_reg, ws_pulse, ws_odd;
#if HS_CODEC_USE_INSIDE
  uint32_t rate_cfg=0x21, dmic_cfg=0;
#endif

#if HS_CODEC_USE_INSIDE
  if (AUDIO_ICODEC == codecp->codec_type) {
    switch (sample_rate) {
    case 8000:
      rate_cfg = 0x44; //sr_32k,sr_4x
      dmic_cfg = 1;
      break;
    case 16000:
      rate_cfg = 0x42; //sr_32k,sr_2x
      dmic_cfg = 1;
      break;
    case 32000:
      rate_cfg = 0x41; //sr_32k,sr_1x
      dmic_cfg = 1;
      break;

    case 12000:
      rate_cfg = 0x14; //sr_48k,sr_4x
      dmic_cfg = 1;
      break;
    case 24000:
      rate_cfg = 0x12; //sr_48k,sr_2x
      dmic_cfg = 1;
      break;
    case 48000:
      rate_cfg = 0x11; //sr_48k,sr_1x
      dmic_cfg = 1;
      break;
    case 96000:
      rate_cfg = 0x81; //sr_96k,sr_1x
      dmic_cfg = 1;
      break;

    case 11025:
      rate_cfg = 0x24; //sr_44k,sr_4x
      dmic_cfg = 0;
      break;
    case 22050:
      rate_cfg = 0x22; //sr_44k,sr_2x
      dmic_cfg = 0;
      break;
    case 44100:
      rate_cfg = 0x21; //sr_44k,sr_1x
      dmic_cfg = 0;
      break;

    default:
      rate_cfg = 0x11; //48000
      dmic_cfg = 1;
      break;
    };
  }
#endif

  bclk = _codec_get_bclk(sample_rate, ws_width, &bclk_reg);
  ws_width = bclk / sample_rate;
  ws_pulse =  ws_width / 2; //high_pulse of i2s_tx_ws or i2s_rx_ws
  ws_odd = 0; //low_pulse = high_pulse
  if(ws_width % 2)
  {
    ws_odd = 1; //low_pulse = high_pulse - 1
    ws_pulse += 1;
  }
  if (AUDIO_STREAM_PLAYBACK == dir) {
    __codec_set_bitsval(codecp->codec->CLK_CTRL_2, 20, 22, bclk_reg); //rx_sel
    __codec_set_bitsval(codecp->codec->CLK_CTRL_2, 23, 23, ws_odd);   //rx_ws: play path
    __codec_set_bitsval(codecp->codec->CLK_CTRL_2, 24, 31, ws_pulse);
  }
  else {
    __codec_set_bitsval(codecp->codec->CLK_CTRL_2, 8, 10, bclk_reg);  //tx_sel
    __codec_set_bitsval(codecp->codec->CLK_CTRL_2, 11, 11, ws_odd);   //tx_ws: record path
    __codec_set_bitsval(codecp->codec->CLK_CTRL_2, 12, 19, ws_pulse);
  }

#if HS_CODEC_USE_INSIDE
  if (AUDIO_ICODEC == codecp->codec_type) {
    if(dir == AUDIO_STREAM_PLAYBACK)
    {
      __codec_set_bitsval(codecp->codec->DAC_CTRL, 0, 7, rate_cfg);
      __codec_set_bitval(HS_PSO->CODEC_CFG, 9, 0); //0=24m bypass; 1=frc mode
    }
    else
    {
      __codec_set_bitsval(codecp->codec->ADC_CTRL, 8, 14, rate_cfg);
      __codec_set_bitsval(codecp->codec->CLK_CTRL_2, 7, 7, dmic_cfg);
    }
  }
#endif
}

#if HS_CODEC_USE_WM8753

/*
* wm8753 register cache
* We can't read the WM8753 register space when we
* are using 2 wire for device control, so we cache them instead.
*/
static struct reg_default wm8753_regs[] = {
	{ 0x00, 0x0000 },
	{ 0x01, 0x0008 },
	{ 0x02, 0x0000 },
	{ 0x03, 0x000a },
	{ 0x04, 0x000a },
	{ 0x05, 0x0033 },
	{ 0x06, 0x0000 },
	{ 0x07, 0x0007 },
	{ 0x08, 0x00ff },
	{ 0x09, 0x00ff },
	{ 0x0a, 0x000f },
	{ 0x0b, 0x000f },
	{ 0x0c, 0x007b },
	{ 0x0d, 0x0000 },
	{ 0x0e, 0x0032 },
	{ 0x0f, 0x0000 },
	{ 0x10, 0x00c3 },
	{ 0x11, 0x00c3 },
	{ 0x12, 0x00c0 },
	{ 0x13, 0x0000 },
	{ 0x14, 0x0000 },
	{ 0x15, 0x0000 },
	{ 0x16, 0x0000 },
	{ 0x17, 0x0000 },
	{ 0x18, 0x0000 },
	{ 0x19, 0x0000 },
	{ 0x1a, 0x0000 },
	{ 0x1b, 0x0000 },
	{ 0x1c, 0x0000 },
	{ 0x1d, 0x0000 },
	{ 0x1e, 0x0000 },
	{ 0x1f, 0x0000 },
	{ 0x20, 0x0055 },
	{ 0x21, 0x0005 },
	{ 0x22, 0x0050 },
	{ 0x23, 0x0055 },
	{ 0x24, 0x0050 },
	{ 0x25, 0x0055 },
	{ 0x26, 0x0050 },
	{ 0x27, 0x0055 },
	{ 0x28, 0x0079 },
	{ 0x29, 0x0079 },
	{ 0x2a, 0x0079 },
	{ 0x2b, 0x0079 },
	{ 0x2c, 0x0079 },
	{ 0x2d, 0x0000 },
	{ 0x2e, 0x0005 },//adc input mode line
	{ 0x2f, 0x0000 },
	{ 0x30, 0x0000 },
	{ 0x31, 0x0097 },
	{ 0x32, 0x0097 },
	{ 0x33, 0x0000 },
	{ 0x34, 0x0004 },
	{ 0x35, 0x0000 },
	{ 0x36, 0x0083 },
	{ 0x37, 0x0024 },
	{ 0x38, 0x01ba },
	{ 0x39, 0x0000 },
	{ 0x3a, 0x0083 },
	{ 0x3b, 0x0024 },
	{ 0x3c, 0x01ba },
	{ 0x3d, 0x0000 },
	{ 0x3e, 0x0000 },
	{ 0x3f, 0x0000 },
};

static void _codec_wm8753_write(uint8_t reg_addr, uint16_t val)
{
#if HAL_USE_I2C
  uint8_t txBuf[WM8753_I2C_WRCMD_LEN];
  systime_t u32TimeOut = OSAL_MS2ST(40);
  msg_t s32Status = MSG_OK;

  txBuf[0] = reg_addr<<1 | ((val>>8)&1);
  txBuf[1] = val;

  i2cAcquireBus(WM8753_DEV_I2C);
  /*
  s32Status = i2cMasterTransmitTimeout(WM8753_DEV_I2C, WM8753_I2C_ADDR, txBuf,
      WM8753_I2C_WRCMD_LEN, NULL, 0, u32TimeOut);
      */
  s32Status = i2cMemWriteTimeout(WM8753_DEV_I2C, WM8753_I2C_ADDR, txBuf[0],
    1, &txBuf[1], 1, u32TimeOut);
  i2cReleaseBus(WM8753_DEV_I2C);

  if (s32Status != MSG_OK)
  {
    audio_dbg("[wm8753 write]addr:0x%x value0x%x write error\r\n", reg_addr, val);
  }
#else
  (void)reg_addr;
  (void)val;
#endif
}

static void _codec_wm8753_set(uint8_t reg_addr, uint8_t start, uint8_t end, uint16_t val)
{
  __codec_set_bitsval(wm8753_regs[reg_addr].def, start, end, val);
  _codec_wm8753_write(reg_addr, wm8753_regs[reg_addr].def);
}

static void _codec_wm8753_set_sample(uint32_t sample_rate)
{
  uint32_t rate_cfg = 0;

  switch(sample_rate)
  {
  case 8000:
    rate_cfg = 0x6;
    break;

  case 16000:
    rate_cfg = 0xa;
    break;

  case 32000:
    rate_cfg = 0xc;
    break;

  case 44100:
    rate_cfg = 0x11;
    break;

  case 48000:
    rate_cfg = 0x00;
    break;

  default:
    rate_cfg = 0x00;
    break;
  };

  _codec_wm8753_set(WM8753_SRATE1, 0, 0, 0x01);     //USB mode
  _codec_wm8753_set(WM8753_SRATE1, 1, 5, rate_cfg); //sample rate
}
#endif //HS_CODEC_USE_WM8753

static void codec_lld_start_dac_drv(CODECDriver *codecp)
{
#if HS_CODEC_USE_INSIDE
  if (AUDIO_ICODEC == codecp->codec_type) {

    /* 100 under reset state */
    //__codec_dac_enable();
    __codec_dac_set_fir(codecp->codec, 1);
    udelay(10);
    __codec_dac_set_fir(codecp->codec, 0);

    /* digital mute as once: 011<->100 toggles during mute state, the average is 000 */
    __codec_dac_set_fade_out(0);
    __codec_dac_mute();
    osalThreadSleepMilliseconds(1);

    if (codecp->pa_latency == 0) {
      hs_audio_PAon();
      osalThreadSleepMilliseconds(1);
    }

    _codec_analog_playPowerOn(codecp);

    /* digital fade in */
    hs_audio_config_t *cfgp = &codecp->cfg_ply;
    __codec_dac_set_fade_in(MS2FADE(cfgp->fade_in,  cfgp->sample_rate));
    __codec_dac_unmute();

    if (codecp->pa_latency > 0) {
      /* hide the pop noise */
      if (codecp->pa_latency % 2) {
        osalThreadSleepMilliseconds(codecp->pa_latency * 10);
        hs_audio_PAon();
      }
      else {
        if (!hs_audio_PAisOn() && !chVTIsArmed(&codecp->pa_timer)) {
          chVTSet(&codecp->pa_timer, MS2ST(10 * codecp->pa_latency),
                  _lazy_turn_on_audio_pa, codecp);
        }
      }
    }
  }
#endif

#if HS_CODEC_USE_WM8753
  if (AUDIO_XCODEC_WM8753 == codecp->codec_type) {
    _codec_wm8753_set(WM8753_DAC, 3, 3, WM8753_DACMUTE);
    _codec_wm8753_set(WM8753_PWR1, 2, 3, (DACL << 1) | DACR);

    _codec_wm8753_set(WM8753_PWR3, 7, 8, (LOUT1 << 1) | ROUT1);
    _codec_wm8753_set(WM8753_PWR4, 0, 1, (LEFTMIX << 1)| RIGHTMIX);

    _codec_wm8753_set(WM8753_LOUTM1, 8, 8, LD2LO);
    _codec_wm8753_set(WM8753_ROUTM1, 8, 8, RD2RO);

    _codec_wm8753_set(WM8753_LOUTM1, 4, 6, 0);  //left mixer volume +6dB
    _codec_wm8753_set(WM8753_ROUTM1, 4, 6, 0);  //right mixer volume +6dB

    _codec_wm8753_set(WM8753_DAC, 3, 3, ~WM8753_DACMUTE);

  }
#endif
}

static void codec_lld_stop_dac_drv(CODECDriver *codecp)
{
#if HS_CODEC_USE_INSIDE
  if (AUDIO_ICODEC == codecp->codec_type) {
    /* digital fade out */
    hs_audio_config_t *cfgp = &codecp->cfg_ply;
    __codec_dac_set_fade_out(MS2FADE(cfgp->fade_out,  cfgp->sample_rate));
    __codec_dac_mute();
    osalThreadSleepMilliseconds(cfgp->fade_out*2);

    if (codecp->pa_latency > 0) {
      /* Reset is required to avoid hook the same timer into the dual-link-list */
      chVTReset(&codecp->pa_timer);
      hs_audio_PAoff();
      /* now the pop noise of power down is very weak */
      //osalThreadSleepMilliseconds(codecp->pa_latency * 10);
    }

    _codec_analog_playPowerOff(codecp);

    if (codecp->pa_latency == 0) {
      hs_audio_PAoff();
    }

    //__codec_dac_disable();
  }
#endif

#if HS_CODEC_USE_WM8753
  if (AUDIO_XCODEC_WM8753 == codecp->codec_type) {
    _codec_wm8753_set(WM8753_DAC, 3, 3, WM8753_DACMUTE);
    _codec_wm8753_set(WM8753_PWR3, 0, 8, 0);
    _codec_wm8753_set(WM8753_PWR4, 0, 8, 0);
  }
#endif
}

/*===========================================================================*/
/* Driver exported functions.                                                */
/*===========================================================================*/

/**
* @brief   Low level CODEC driver initialization.
*
* @notapi
*/
void codec_lld_init(void)
{
  CODECD.codec = HS_CODEC;

  CODECD.cpu_mhz = cpm_get_clock(HS_CPU_CLK) / 1000000;
  /* they will be overwritten by config */
  CODECD.dac_db_min = -50;
  CODECD.pa_latency = 0;
}

/**
* @brief   Configures and activates the codec peripheral.
*
* @param[in] codecp      pointer to the @p CODECDriver object
*
* @notapi
*/
void codec_lld_start(CODECDriver *codecp)
{
  HS_CODEC_Type *codec_r = codecp->codec;

  cpmResetCODEC();
  cpmEnableCODEC();

#if defined(BR32xx_FPGA)
  codecp->codec_type = AUDIO_XCODEC_WM8753;
#else
  codecp->codec_type = AUDIO_ICODEC;
#endif
  codecp->isVirgin = true;
  codecp->isPlayed = false;

  __codec_set_bitsval(codec_r->CLK_CTRL_1, 0, 1, 0x3); //clk_en_reg=1, rstn_reg=1
  __codec_set_bitsval(codec_r->CLK_CTRL_2, 0, 3, 0xf); //div_clk_en=b'1111 (0.6M,12M,6M,3MHz)

#if HS_CODEC_USE_INSIDE
  /* force test iCODEC in loop0 on FPGA */
  if (1) {//AUDIO_ICODEC == codecp->codec_type) {

    /* user defined initialization in board.c */
    hs_codec_init();

    hs_audio_PAoff();
    /* debug only: test pop noise when audio PA is always on */
    //hs_audio_PAon(); osalThreadSleepMilliseconds(45);

    #if defined(BR3215)
    HS_ANA->AU_ANA_CFG[0] = 0xffffffff;
    HS_ANA->REGS.REF_BYP  = 0;
    HS_ANA->REGS.REF_FAST = 0;
    HS_ANA->REGS.EN_DAC_DEM = 0;
    HS_ANA->REGS.MICBIAS_TUNE = 0;
    _codec_analog_drv1(false);
    /* reg<22:21> */
    HS_ANA->REGS.LDO_DRV_CTRL = 2;
    /* reg<34> */
    HS_ANA->REGS.EN_DAC_DEM = 1;
    /* reg<40:37> */
    HS_ANA->REGS.MICBIAS_TUNE = 8;
    #endif
    #if defined(BR3215e)
    #if POWER_ON_FSM_HW
    /* 0: controlled by fsm */
    __codec_set_bitsval(HS_CODEC->ANA_CTRL_4, 5, 29, 0);
    __codec_set_bitsval(HS_CODEC->ANA_PWR_4, 24, 25, 0);
    #else
    __codec_set_bitsval(HS_CODEC->ANA_CTRL_4, 5, 29, 0x1ffffff);
    __codec_set_bitsval(HS_CODEC->ANA_PWR_4, 24, 25, 0x3);
    #endif
    /* ctrl_ldo_drv_au<1:0>: avdd28 b'01 b'11=3.0V */
    __codec_set_bitsval(HS_CODEC->ANA_CTRL_4, 2, 3, 3);
    /* ctrl_ldo12_au<1:0>: b'01 */
    __codec_set_bitsval(HS_CODEC->ANA_CTRL_4, 0, 1, 1);
    /* sel_vcom_au<1:0>: vcom b'10=1.5V */
    __codec_set_bitsval(HS_CODEC->ANA_CTRL_2, 20, 21, 2);
    /* en_dac_dem_au */
    __codec_set_bitsval(HS_CODEC->ANA_CTRL_2, 12, 12, 1);
    /* sel_bias_au<1:0>: b'00=7.5uA b'01=10uA b'10=12.5uA b'11=15uA */
    __codec_set_bitsval(HS_CODEC->ANA_CTRL_3, 28, 29, 1);
    #endif
    _codec_set_pga_input(PGA_INPUT_VIP_MIC, CODEC_CHANNEL_BOTH);
    _codec_analog_commonPowerOn();
    _codec_analog_micbiasCalibration();

    __codec_dac_unreset();
    __codec_dac_enable();
    /* DAC's other register fields become accessable after enabled */
    __codec_dac_set_anticlip(0);
    //__codec_dac_set_mutebypass(0);
    /* DAC's ramp down time 2^0*vol/44.1=3ms if vol=149; 2^4*vol/8=200ms if vol=100 */
    __codec_dac_set_fade_in(4);
    __codec_dac_set_fade_out(0);
    __codec_set_bitsval(codec_r->ADC_VOL_CTRL, 4, 7, 0);
    //__codec_dac_disable();
  }
#endif

#if HS_CODEC_USE_WM8753
  if (AUDIO_XCODEC_WM8753 == codecp->codec_type) {
    _codec_wm8753_set(WM8753_RESET, 0, 8, 0);
    _codec_wm8753_set(WM8753_PWR1, 6, 8, (VMIDSEL_50K << 1) | VREF);
  }
#endif

  /*
   * AHB I2S_TX's sdo output to  0=iCODEC's sdi; 0/1=xCODEC's sdi via i2s_sdo (WM8753's DACDAT)
   * AHB I2S_RX's sdi input from 0=iCODEC's sdo;   1=xCODEC's sdo via sdi_gpio (WM8753's VXDOUT)
   */
  __codec_set_bitsval(codec_r->IF_CTRL, 7, 7, codecp->codec_type ? 1 : 0);
}

/**
* @brief   Deactivates the I2S peripheral.
*
* @param[in] i2sp      pointer to the @p I2SDriver object
*
* @notapi
*/
void codec_lld_stop(CODECDriver *codecp)
{
#if HS_CODEC_USE_INSIDE
  if (AUDIO_ICODEC == codecp->codec_type) {
    codecp->codec->IF_CTRL = 0x00;

    /* force the total timing of play power off */
    codecp->isVirgin = true;
    codecp->isPlayed = true;
    codec_lld_play_stop(codecp);
    codec_lld_record_stop(codecp);

    _codec_analog_commonPowerOff();

    hs_audio_PAoff();
    _codec_analog_drv1(false);
    _codec_analog_drv(false);
    #if defined(BR3215)
    HS_ANA->AU_ANA_CFG[0] = 0xffffffff;
    #endif
    codecp->isVirgin = true;
  }
#endif

#if HS_CODEC_USE_WM8753
  if (AUDIO_XCODEC_WM8753 == codecp->codec_type) {
    _codec_wm8753_set(WM8753_PWR1, 0, 8, 0x00);
    _codec_wm8753_set(WM8753_PWR2, 0, 8, 0x00);
    _codec_wm8753_set(WM8753_PWR3, 0, 8, 0x00);
    _codec_wm8753_set(WM8753_PWR4, 0, 8, 0x00);
  }
#endif

  __codec_set_bitsval(codecp->codec->CLK_CTRL_2, 0, 3, 0); //div_clk_en=0
  __codec_set_bitsval(codecp->codec->CLK_CTRL_1, 0, 1, 0); //clk_en_reg=0, rstn_reg=0
  cpmDisableCODEC();
}

void codec_lld_record_start(CODECDriver *codecp, hs_audio_config_t *cfgp)
{
  HS_CODEC_Type *codec_r = codecp->codec;

  /* allow to inherit the previous audio settings if NULL */
  if (NULL != cfgp) {
    memcpy(&codecp->cfg_rec, cfgp, sizeof(hs_audio_config_t));
  }
  else {
    cfgp = &codecp->cfg_rec;
  }
  codecp->cpu_mhz = cpm_get_clock(HS_CPU_CLK) / 1000000;

  /* config i2s clock */
  _codec_set_samplerate(codecp, cfgp->sample_rate, AUDIO_STREAM_RECORD);

#if HS_CODEC_USE_INSIDE
  /* force test iCODEC in loop0 on FPGA */
  if (AUDIO_RECORD_LOOP0 == cfgp->source) {
    codecp->codec_type = AUDIO_ICODEC;
    __codec_set_bitsval(codec_r->IF_CTRL, 7, 7, codecp->codec_type ? 1 : 0);
  }
  if (AUDIO_ICODEC == codecp->codec_type) {
    __codec_set_bitsval(codec_r->ADC_CTRL, 4, 6, 3); //adc_cic_scale=3: 6dB
    __codec_set_bitsval(codec_r->ADC_CTRL, 3, 3, 1); //adc_dc_en=1
    __codec_set_bitsval(codec_r->IF_CTRL, 2, 3, codecp->mic_select);

    if (AUDIO_RECORD_LOOP0 == cfgp->source) {
      /* loop0 test case keeps ADC gain x1 */
      codec_lld_record_set_volume(codecp, 0/*dB*/, 0/*dB*/);
    }

    /* power on record path */
    __codec_adc_mute();
    _codec_analog_recPowerOn(codecp->pga_gain_mic);
    __codec_adc_unmute();

    __codec_adc_unreset();
    __codec_adc_enable();
  }
#endif

#if HS_CODEC_USE_INSIDE
  if (AUDIO_ICODEC == codecp->codec_type) {
    _codec_set_deci_filt(codecp, cfgp->sample_rate);
  }
#endif
#if HS_CODEC_USE_WM8753
  if (AUDIO_XCODEC_WM8753 == codecp->codec_type) {
    _codec_wm8753_set_sample(cfgp->sample_rate);
    _codec_wm8753_set(WM8753_PWR2, 2, 3, (ADCL << 1) | ADCR);
    _codec_wm8753_set(WM8753_IOCTL, 0, 8, 0x2c);
    _codec_wm8753_set(WM8753_SRATE2, 0, 8, 0x05);

    if (24 == cfgp->sample_bits) {
      _codec_wm8753_set(WM8753_PCM,  0, 3, (WM8753_WL_24 << 2) | WM8753_FT_I2S | (1 << 4));
      _codec_wm8753_set(WM8753_HIFI, 0, 3, (WM8753_WL_24 << 2) | WM8753_FT_I2S);
    }
    else {
      _codec_wm8753_set(WM8753_PCM,  0, 3, (WM8753_WL_16 << 2) | WM8753_FT_I2S | (1 << 4));
      _codec_wm8753_set(WM8753_HIFI, 0, 3, (WM8753_WL_16 << 2) | WM8753_FT_I2S);
    }
  }
#endif

  /* reset special audio path */
  __codec_set_bitsval(codec_r->IF_CTRL, 4, 4, 0x00); //i2s interface
  __codec_set_bitsval(codec_r->DAC_MOD_CTRL, 10, 10, 0x0); //fm_out_en=0
  HS_CODEC->LOOP_MODE = 0;

  switch (cfgp->source) {
  case AUDIO_RECORD_LINEIN:
#if HS_CODEC_USE_INSIDE
    if (AUDIO_ICODEC == codecp->codec_type) {
      __codec_set_bitsval(codec_r->IF_CTRL, 2, 3, 0); //mic_sel=0: LR
      _codec_analog_pgaPowerOn(codecp->pga_gain_aux);
      _codec_set_pga_input(PGA_INPUT_VIP_LINE, CODEC_CHANNEL_BOTH);
      _codec_set_drv_input(DRV_INPUT_PGA, CODEC_CHANNEL_BOTH);
      /* for auto mute in sofware? */
      HS_CODEC->ADC_DITHER_CTRL_1 |= (1 << 13);		/*1: adc_dither is enable*/
      HS_CODEC->ADC_DITHER_CTRL_1 &= ~(1 << 12);	/*1: adc_dither_clk is power down*/
    }
#endif
#if HS_CODEC_USE_WM8753
    if (AUDIO_XCODEC_WM8753 == codecp->codec_type) {
      _codec_wm8753_set(WM8753_ADCIN, 0, 3, 0x05);
    }
#endif
    break;

  case AUDIO_RECORD_DMIC:
#if HS_CODEC_USE_INSIDE
    if (AUDIO_ICODEC == codecp->codec_type) {
      __codec_adc_dmic_enable(codec_r);
    }
#endif
#if HS_CODEC_USE_WM8753
#endif
    break;

  case AUDIO_RECORD_MIC:
#if HS_CODEC_USE_INSIDE
    if (AUDIO_ICODEC == codecp->codec_type) {
      __codec_set_bitsval(codec_r->IF_CTRL, 2, 3, codecp->mic_select);
      _codec_analog_pgaPowerOn(codecp->pga_gain_mic);
      _codec_set_pga_input(PGA_INPUT_VIP_MIC, CODEC_CHANNEL_BOTH);
      _codec_set_drv_input(DRV_INPUT_PGA, CODEC_CHANNEL_BOTH);
    }
#endif
#if HS_CODEC_USE_WM8753
    if (AUDIO_XCODEC_WM8753 == codecp->codec_type) {
      _codec_wm8753_set(WM8753_PWR1, 5, 5, MICB);
      _codec_wm8753_set(WM8753_PWR2, 8, 8, MICAMP1EN);
      _codec_wm8753_set(WM8753_PWR2, 4, 6, (ALCMIX << 2) | (PGAL << 1) | PGAR);

      _codec_wm8753_set(WM8753_ADCIN, 0, 3, 0);
      _codec_wm8753_set(WM8753_INCTL2, 1, 1, WM8753_MAC1ALC);
      _codec_wm8753_set(WM8753_LINVOL, 0, 8, 0x119);        //0x139);        //pga gain = 28.5dB
      _codec_wm8753_set(WM8753_RINVOL, 0, 8, 0x119);        //pga gain = 28.5dB

      //_codec_wm8753_set(WM8753_INCTL1, 0, 8, 0x60);      	//mic boost = 30dB
      //_codec_wm8753_set(WM8753_INCTL1, 5, 6, 3);
      _codec_wm8753_set(WM8753_ALC1, 0, 8, 0x1cb);//0x1fb);        //alc off
      //_codec_wm8753_set(WM8753_ALC3, 0, 7, 0x0);
      //_codec_wm8753_set(WM8753_ALC2, 4, 7, 6);

      //_codec_wm8753_set(WM8753_ADC, 0, 0, 0x1);

      _codec_wm8753_set(WM8753_MICBIAS, 0, 0, 1);           // Mic Bias Current Comparator Circuit enable
    }
#endif
    break;

  case AUDIO_RECORD_FM:
#if HS_CODEC_USE_INSIDE
    if (AUDIO_ICODEC == codecp->codec_type) {
      __codec_set_bitsval(codec_r->DAC_MOD_CTRL, 10, 10, 0x01); //fm_out_en=1
    }
#endif
    break;

  case AUDIO_RECORD_LOOP0:
#if HS_CODEC_USE_INSIDE
    if (AUDIO_ICODEC == codecp->codec_type) {
      HS_CODEC->LOOP_MODE = LOOP_MODE_0;
    }
#endif
    break;

  default:
    break;
  }
}

void codec_lld_record_stop(CODECDriver *codecp)
{
  codecp->cfg_rec.source = AUDIO_SOURCE_NULL;

#if HS_CODEC_USE_INSIDE
  if (AUDIO_ICODEC == codecp->codec_type) {
    __codec_adc_mute();
    _codec_analog_recPowerOff();
    /* tricky: keep mic input in default, see @AUDIO_PLAY_RAM 's LOOP_MODE */
    _codec_set_pga_input(PGA_INPUT_VIP_MIC, CODEC_CHANNEL_BOTH);

    __codec_adc_disable();
    __codec_adc_unreset();
  }
#endif

#if HS_CODEC_USE_WM8753
  if (AUDIO_XCODEC_WM8753 == codecp->codec_type) {
    _codec_wm8753_set(WM8753_PWR2, 0, 8, 0);
  }
#endif
}

void codec_lld_record_mute(CODECDriver *codecp, bool bMute)
{
#if HS_CODEC_USE_INSIDE
  if (AUDIO_ICODEC == codecp->codec_type) {
    if (bMute) {
      __codec_adc_mute();
    }
    else {
      __codec_adc_unmute();
    }
  }
#endif
#if HS_CODEC_USE_WM8753
#endif
}

void codec_lld_record_set_volume(CODECDriver *codecp, int ddb_left, int ddb_right)
{
  uint32_t vol_left, vol_right;

#if HS_CODEC_USE_INSIDE
  if (AUDIO_ICODEC == codecp->codec_type) {
    vol_left = DDB2VOL_ADC(ddb_left);
    vol_right = DDB2VOL_ADC(ddb_right);
    __codec_adc_set_vol(vol_left, vol_right);;
  }
#endif

#if HS_CODEC_USE_WM8753
  if (AUDIO_XCODEC_WM8753 == codecp->codec_type) {
    vol_left = DDB2VOL_ADC_WM(ddb_left);
    vol_right = DDB2VOL_ADC_WM(ddb_right);
    _codec_wm8753_set(WM8753_LADC, 0, 8, vol_left | 0x100);
    _codec_wm8753_set(WM8753_RADC, 0, 8, vol_right | 0x100);
  }
#endif
}

void codec_lld_record_get_volume(CODECDriver *codecp, int *ddb_left, int *ddb_right)
{
  uint8_t vol_left, vol_right;

#if HS_CODEC_USE_INSIDE
  if (AUDIO_ICODEC == codecp->codec_type) {
    vol_left = (HS_CODEC->ADC_VOL_CTRL >> 8) & 0xff;
    vol_right = (HS_CODEC->ADC_VOL_CTRL >> 16) & 0xff;
    if (ddb_left) *ddb_left = VOL2DDB_ADC(vol_left);
    if (ddb_right) *ddb_right = VOL2DDB_ADC(vol_right);
  }
#endif

#if HS_CODEC_USE_WM8753
  if (AUDIO_XCODEC_WM8753 == codecp->codec_type) {
    /* TBD */
    if (ddb_left) *ddb_left = 0;
    if (ddb_right) *ddb_right = 0;
  }
#endif
}

void codec_lld_play_start(CODECDriver *codecp, hs_audio_config_t *cfgp)
{
  HS_CODEC_Type *codec_r = codecp->codec;

  /* allow to inherit the previous audio settings if NULL */
  if (NULL != cfgp) {
    memcpy(&codecp->cfg_ply, cfgp, sizeof(hs_audio_config_t));
  }
  codecp->cpu_mhz = cpm_get_clock(HS_CPU_CLK) / 1000000;

  //__codec_dac_enable();
  __codec_dac_set_fade_in(MS2FADE(cfgp->fade_in,  cfgp->sample_rate));

  /* start_dac_drv() is done inside */
  _codec_setup_dac_drv_pa_timing(codecp, TRUE);

  /* config i2s clock */
  _codec_set_samplerate(codecp, cfgp->sample_rate, AUDIO_STREAM_PLAYBACK);

#if HS_CODEC_USE_INSIDE
  if (2 == cfgp->sample_channels) {
    __codec_set_bitsval(codec_r->IF_CTRL, 0, 1, 0); //0=LR
  }
  else {
    __codec_set_bitsval(codec_r->IF_CTRL, 0, 1, 2); //0=LL
  }
#endif
#if HS_CODEC_USE_WM8753
  if (AUDIO_XCODEC_WM8753 == codecp->codec_type) {
    #if defined(BR3215e) && defined(BR32xx_FPGA)
    /* RAM -> AHB I2S -> xCODEC: to use i2s_sdo */
    palSetPinMode(PB6, PAL_MODE_OUTPUT | PAL_MODE_ALTERNATE(PAD_FUNC_I2S_SDO)    | PAL_MODE_DRIVE_CAP(0));
    #endif
    if (2 == cfgp->sample_channels) {
        _codec_wm8753_set(WM8753_DAC, 4, 5, 0);
    }
    else {
        _codec_wm8753_set(WM8753_DAC, 4, 5, 3);
    }
  }
#endif

  /* reset special audio path */
  __codec_set_bitsval(codec_r->IF_CTRL, 4, 4, 0x00); //i2s interface
  if (LOOP_MODE_0 != HS_CODEC->LOOP_MODE) HS_CODEC->LOOP_MODE = 0; //disable loop mode unless AUDIO_RECORD_LOOP0
  __codec_set_bitval(codec_r->ADC_SIDE_CTRL, 16, 0);   //adc_side_en=0
  __codec_set_bitsval(codec_r->DAC_MOD_CTRL, 6, 7, 3); //dac_peak_en=1, dac_peak_rstn=1
  __codec_set_bitsval(codec_r->DAC_MOD_CTRL, 9, 9, 0x00); //fm_in_en=0
  __codec_set_bitsval(codec_r->DAC_MOD_CTRL, 10, 10, 0x0); //fm_out_en=0
  _codec_set_drv_input(DRV_INPUT_DAC, CODEC_CHANNEL_BOTH);

  #if 0
  /* DRC settings */
  __codec_set_bitsval(codec_r->DAC_DRC_CTRL_3, 2,  6,  7);      //-1 db   LT
  __codec_set_bitsval(codec_r->DAC_DRC_CTRL_3, 8,  14, 12);     //-7 db   CT
  __codec_set_bitsval(codec_r->DAC_DRC_CTRL_3, 16, 22, 0x7f);   //-36 db  ET
  __codec_set_bitsval(codec_r->DAC_DRC_CTRL_3, 24, 26, 7);      //-42 db  NT
  __codec_set_bitsval(codec_r->DAC_DRC_CTRL_4, 0, 2, 4);	    //cs
  __codec_set_bitsval(codec_r->DAC_DRC_CTRL_4, 3, 5, 5);	    //es
  __codec_set_bitsval(codec_r->DAC_DRC_CTRL_3, 0, 1, 3);        //enable drc with left/right as reference
  #endif

#if HS_CODEC_USE_INSIDE
  if (AUDIO_ICODEC == codecp->codec_type) {
    _codec_set_deci_filt(codecp, cfgp->sample_rate);
  }
#endif
#if HS_CODEC_USE_WM8753
  if (AUDIO_XCODEC_WM8753 == codecp->codec_type) {
    _codec_wm8753_set_sample(cfgp->sample_rate);
    if (24 == cfgp->sample_bits) {
      _codec_wm8753_set(WM8753_HIFI, 0, 3, (WM8753_WL_24 << 2) | WM8753_FT_I2S);
    }
    else {
      _codec_wm8753_set(WM8753_HIFI, 0, 3, (WM8753_WL_16 << 2) | WM8753_FT_I2S);
    }
  }
#endif

  switch (cfgp->source) {
  case AUDIO_PLAY_RAM:
#if HS_CODEC_USE_INSIDE
    if (AUDIO_ICODEC == codecp->codec_type) {
      if (AUDIO_RECORD_LINEIN == codecp->cfg_rec.source) {
        /* linein -> AnaD(PGA) -> ADC ->(full_loop)-> DAC -> DAna(DRV) -> speaker, w/o I2S */
        /* please call audioRecordStart() firstly to turn on ADC path also */
        HS_CODEC->LOOP_MODE = 8; //codec_full_loop
      }
    }
#endif
#if HS_CODEC_USE_WM8753
    if (AUDIO_XCODEC_WM8753 == codecp->codec_type) {
      _codec_wm8753_set(WM8753_BASS, 7, 7, 1);
      _codec_wm8753_set(WM8753_BASS, 4, 6, 0);
      _codec_wm8753_set(WM8753_BASS, 0, 3, 1);

      //_codec_wm8753_set(WM8753_TREBLE, 6, 6, 1);
      //_codec_wm8753_set(WM8753_TREBLE, 0, 3, 0xb);
    }
#endif
    break;

  case AUDIO_PLAY_SCO:
    __codec_set_bitsval(codec_r->IF_CTRL, 8, 8, 0x00); //pcm_con_ctrl=0: to i2s rather than gpio?
    __codec_set_bitsval(codec_r->IF_CTRL, 6, 6, 0x01); //transmit_en=1?
    __codec_set_bitsval(codec_r->IF_CTRL, 4, 4, 0x01); //pcm interface
    break;

  case AUDIO_PLAY_LINEIN:
#if HS_CODEC_USE_INSIDE
    if (AUDIO_ICODEC == codecp->codec_type) {
      __codec_set_bitsval(codec_r->IF_CTRL, 2, 3, 0); //mic_sel=0: LR
      _codec_analog_pgaPowerOn(codecp->pga_gain_aux);
      _codec_set_pga_input(PGA_INPUT_VIP_LINE, CODEC_CHANNEL_BOTH);
      /* linein -> AnaD(PGA) -> DAna(DRV), w/o digital path */
      _codec_set_drv_input(DRV_INPUT_PGA, CODEC_CHANNEL_BOTH);
    }
#endif
#if HS_CODEC_USE_WM8753
    if (AUDIO_XCODEC_WM8753 == codecp->codec_type) {
      _codec_wm8753_set(WM8753_PWR3, 7, 8, (LOUT1 << 1) | ROUT1);
      _codec_wm8753_set(WM8753_PWR4, 0, 1, (LEFTMIX << 1)| RIGHTMIX);

      _codec_wm8753_set(WM8753_LOUTM1, 7, 7, LM2LO);
      _codec_wm8753_set(WM8753_ROUTM1, 7, 7, RM2RO);
    }
#endif
    break;

  case AUDIO_PLAY_FM:
    __codec_set_bitsval(codec_r->IF_CTRL, 6, 6, 0x01); //transmit_en=1?

#if HS_CODEC_USE_INSIDE
    if (AUDIO_ICODEC == codecp->codec_type) {
      __codec_set_bitsval(codec_r->DAC_MOD_CTRL, 9, 9, 0x01); //fm_in_en=1
    }
#endif
#if HS_CODEC_USE_WM8753
    if (AUDIO_XCODEC_WM8753 == codecp->codec_type) {
      #if defined(BR3215e) && defined(BR32xx_FPGA)
      /* FM -> iCODEC I2S_TX -> xCODEC: to use codec_sdo, tx_sck, tx_ws */
      palSetPinMode(PB6, PAL_MODE_OUTPUT | PAL_MODE_ALTERNATE(PAD_FUNC_I2S_CODEC_SDO)  | PAL_MODE_DRIVE_CAP(0));
      HS_CODEC->IF_CTRL |= (1u << 6);    /* [6]transmit_en=1: enable tx_sck */
      HS_CODEC->CLK_CTRL_1 |= (1u << 2); /* [2]i2s_txclk_rstn_reg=1: deassert reset to tx_sck */
      _codec_set_samplerate(codecp, 32000/*sample_rate*/, AUDIO_STREAM_RECORD); /* configurate tx_ws */
      #endif
      __codec_set_bitsval(codec_r->DAC_MOD_CTRL, 9, 9, 0x00); //fm_in_en=0
      __codec_set_bitsval(codec_r->DAC_MOD_CTRL, 10, 10, 0x01); //fm_out_en=1
    }
#endif

    /* FM receiver decode data's sample rate is 32000Hz */
    __codec_set_bitsval(codec_r->ADC_CTRL, 1, 1, 0x01); //adc_sw_resetn=1
    __codec_set_bitsval(codec_r->ADC_CTRL, 14, 14, 0x01); //adc_sr_32k=1
    __codec_set_bitsval(codec_r->ADC_CTRL, 8, 8, 0x01);   //adc_sr_1x=1
    __codec_set_bitsval(codec_r->ADC_CTRL, 10, 10, 0x00); //adc_sr_4x=0
    __codec_set_bitsval(codec_r->ADC_CTRL, 0, 0, 0x01);   //adc_en=1

    __codec_set_bitsval(codec_r->DAC_CTRL, 6, 6, 0x01);   //dac_sr_32k=1
    __codec_set_bitsval(codec_r->DAC_CTRL, 0, 0, 0x01);   //dac_sr_1x=1
    __codec_set_bitsval(codec_r->DAC_CTRL, 2, 2, 0x00);   //dac_sr_4x=0
    /* don't enable DAC here, but in codec_lld_start_dac_drv(), so no noise between min volume tone & fm */
    //__codec_set_bitsval(codec_r->DAC_CTRL, 8, 8, 0x01);
    //osalThreadSleep(OSAL_MS2ST(10));
    break;

  case AUDIO_PLAY_MIC:
#if HS_CODEC_USE_INSIDE
    if (AUDIO_ICODEC == codecp->codec_type) {
      __codec_set_bitsval(codec_r->IF_CTRL, 2, 3, codecp->mic_select);
      _codec_analog_pgaPowerOn(codecp->pga_gain_mic);
      _codec_set_pga_input(PGA_INPUT_VIP_MIC, CODEC_CHANNEL_BOTH);
      _codec_set_drv_input(DRV_INPUT_PGA, CODEC_CHANNEL_BOTH);
      //HS_CODEC->LOOP_MODE = 8; //codec_full_loop
      HS_CODEC->ADC_SIDE_CTRL = 0x18080; //adc_side_en=1, gain=0x80
    }
#endif
#if HS_CODEC_USE_WM8753
    if (AUDIO_XCODEC_WM8753 == codecp->codec_type) {
      _codec_wm8753_set(WM8753_PWR1, 5, 5, MICB);
      _codec_wm8753_set(WM8753_PWR2, 8, 8, MICAMP1EN);

      _codec_wm8753_set(WM8753_INCTL1, 0, 8, 0x60);      //mic boost = 30dB
      _codec_wm8753_set(WM8753_INCTL2, 4, 5, 0x01);

      _codec_wm8753_set(WM8753_PWR1, 2, 3, (DACL << 1) | DACR);

      _codec_wm8753_set(WM8753_PWR3, 7, 8, (LOUT1 << 1) | ROUT1);
      _codec_wm8753_set(WM8753_PWR4, 0, 1, (LEFTMIX << 1)| RIGHTMIX);

      _codec_wm8753_set(WM8753_LOUTM1, 4, 6, 0);  //left mixer volume +6dB
      _codec_wm8753_set(WM8753_ROUTM1, 4, 6, 0);  //right mixer volume +6dB

      _codec_wm8753_set(WM8753_LOUTM2, 7, 7, 1);
      _codec_wm8753_set(WM8753_LOUTM2, 4, 6, 1);
      _codec_wm8753_set(WM8753_ROUTM2, 7, 7, 1);
      _codec_wm8753_set(WM8753_ROUTM2, 4, 6, 1);
    }
#endif
    break;

  default:
    break;
  }
}

void codec_lld_play_stop(CODECDriver *codecp)
{
  HS_CODEC_Type *codec_r = codecp->codec;

  codecp->cfg_ply.source = AUDIO_SOURCE_NULL;

  __codec_set_bitsval(codec_r->DAC_MOD_CTRL, 6, 7, 0); //dac_peak_en=0, dac_peak_rstn=0
  __codec_set_bitval(codec_r->ADC_SIDE_CTRL, 16, 0);   //adc_side_en=0

  _codec_setup_dac_drv_pa_timing(codecp, FALSE);
  /* stop_dac_drv() is done inside */
}

void codec_lld_play_mute(CODECDriver *codecp, bool bMute)
{
  //debug("bMute=%d PA=%d DAC_VOL_CTRL=%08lx DAC_CTRL=%08lx CLK_CTRL=%08lx DAC_MODE=%08lx\n", bMute, hs_audio_PAisOn(), HS_CODEC->DAC_VOL_CTRL, HS_CODEC->DAC_CTRL, HS_CODEC->CLK_CTRL_1, HS_CODEC->DAC_MOD_CTRL);

#if HS_CODEC_USE_INSIDE
  if (AUDIO_ICODEC == codecp->codec_type) {
    if (bMute) {
      _codec_setup_dac_drv_pa_timing(codecp, FALSE);
      /* stop_dac_drv() is done inside */
    }
    else {
      uint8_t vol_min = DDB2VOL_DAC((int)codecp->dac_db_min * 10);
      /* if local volume is small enough, stop unmute of the remote phone */
      if ((((HS_CODEC->DAC_VOL_CTRL >> 8) & 0xFF) <= vol_min) &&
          (((HS_CODEC->DAC_VOL_CTRL >> 16) & 0xFF) <= vol_min)) {
        return;
      }
      /* start_dac_drv() is done inside */
      _codec_setup_dac_drv_pa_timing(codecp, TRUE);
    }
  }
#endif

#if HS_CODEC_USE_WM8753
  if (AUDIO_XCODEC_WM8753 == codecp->codec_type) {
    if (bMute) {
      _codec_wm8753_set(WM8753_DAC, 3, 3, WM8753_DACMUTE);
    }
    else {
      _codec_wm8753_set(WM8753_DAC, 3, 3, ~WM8753_DACMUTE);
    }
  }
#endif
}

void codec_lld_play_set_volume(CODECDriver *codecp, int ddb_left, int ddb_right)
{
  uint32_t vol_left, vol_right;

#if HS_CODEC_USE_INSIDE
  if (AUDIO_ICODEC == codecp->codec_type) {
    vol_left = DDB2VOL_DAC(ddb_left);
    vol_right = DDB2VOL_DAC(ddb_right);
    __codec_dac_set_vol(vol_left, vol_right);;
    /* wait a clock in sample rate */
  }
#endif

#if HS_CODEC_USE_WM8753
  if (AUDIO_XCODEC_WM8753 == codecp->codec_type) {
    vol_left = DDB2VOL_DAC_WM(ddb_left);
    vol_right = DDB2VOL_DAC_WM(ddb_right);
    _codec_wm8753_set(WM8753_LOUT1V, 0, 8, vol_left | 0x100);
    _codec_wm8753_set(WM8753_ROUT1V, 0, 8, vol_right | 0x100);
  }
#endif
}

void codec_lld_play_get_volume(CODECDriver *codecp, int *ddb_left, int *ddb_right)
{
  uint8_t vol_left, vol_right;

#if HS_CODEC_USE_INSIDE
  if (AUDIO_ICODEC == codecp->codec_type) {
    vol_left = (HS_CODEC->DAC_VOL_CTRL >> 8) & 0xff;
    vol_right = (HS_CODEC->DAC_VOL_CTRL >> 16) & 0xff;
    if (ddb_left) *ddb_left = VOL2DDB_DAC(vol_left);
    if (ddb_right) *ddb_right = VOL2DDB_DAC(vol_right);
  }
#endif

#if HS_CODEC_USE_WM8753
  if (AUDIO_XCODEC_WM8753 == codecp->codec_type) {
    /* TBD */
    if (ddb_left) *ddb_left = 0;
    if (ddb_right) *ddb_right = 0;
  }
#endif
}

#endif /* HAL_USE_AUDIO */

/** @} */
