/*
    ChibiOS/RT - Copyright (C) 2006-2013 Giovanni Di Sirio
                 Copyright (C) 2019 BRMICRO Technologies
                 
                 
                 

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    br32xx/codec_lld.h
 * @brief   audio interface Driver subsystem low level driver header template.
 *
 * @addtogroup codec
 * @{
 */

#ifndef _CODEC_LLD_H_
#define _CODEC_LLD_H_

#if HAL_USE_AUDIO || defined(__DOXYGEN__)

/*===========================================================================*/
/* Driver constants.                                                         */
/*===========================================================================*/

/*===========================================================================*/
/* Driver pre-compile time settings.                                         */
/*===========================================================================*/

/**
 * @brief   CODEC interrupt priority level setting.
 */
#if !defined(HS_CODEC_IRQ_PRIORITY) || defined(__DOXYGEN__)
#define HS_CODEC_IRQ_PRIORITY       3
#endif

/*===========================================================================*/
/* Derived constants and error checks.                                       */
/*===========================================================================*/

/*===========================================================================*/
/* Driver data structures and types.                                         */
/*===========================================================================*/

typedef enum
{
  AUDIO_ICODEC            = 0,
  AUDIO_XCODEC_WM8753     ,
  AUDIO_XCODEC_XXXXXX     ,
} hs_codec_type_t;

typedef enum {
  TRACK_LR                        = 0,
  TRACK_RL                        ,
  TRACK_LL                        ,
  TRACK_RR                        ,
} hs_codec_micsel_t;

typedef enum
{
  AUDIO_PLAY_RAM          = 0,      //play pcm format from memory to DAC,       for music
  AUDIO_PLAY_LINEIN       ,         //route line-in to ADC to DAC,              for aux
  AUDIO_PLAY_FM           ,         //route fm radio to DAC,                    for fm
  AUDIO_PLAY_SCO          ,         //route bt SCO to DAC, not used due to aec
  AUDIO_PLAY_MIC          ,         //route mic to DAC with ADC side control,   for speaker
  AUDIO_RECORD_LINEIN     = 0x10,   //record from line-in     to ADC to memory, for rec in aux
  AUDIO_RECORD_DMIC       ,         //record from digital mic to ADC to memory
  AUDIO_RECORD_MIC        ,         //record from analog mic  to ADC to memory, for phone
  AUDIO_RECORD_FM         ,         //record from fm radio    to        memory, for rec in fm
  AUDIO_RECORD_LOOP0      = 0x20,   //record from DAC output  to ADC to memory, for iCODEC test
  AUDIO_SOURCE_NULL       = 0x80,
} hs_codec_route_t;

typedef enum {
  CODEC_CHANNEL_LEFT = 0,
  CODEC_CHANNEL_RIGHT,
  CODEC_CHANNEL_BOTH,
} hs_codec_channel_t;

typedef enum {
  DRV_INPUT_FLOATING = 0,
  ///I2S      -> DAC -> DRV
  DRV_INPUT_DAC,
  ///LINE/MIC -> PGA -> DRV
  DRV_INPUT_PGA,
  ///            DAC+PGA -> DRV
  DRV_INPUT_MIX_DAC_PGA,
} hs_codec_drv_input_t;

typedef enum {
  PGA_INPUT_VIP_MIC = 0,
  PGA_INPUT_VIP_MIC_1,
  PGA_INPUT_VIP_MIC_2,
  PGA_INPUT_FLOATING,
  PGA_INPUT_VIP_LINE,
  PGA_INPUT_VIP_LINE_1,
  PGA_INPUT_VIP_LINE_2,
  PGA_INPUT_VIP_LINE_3,
} hs_codec_pga_input_t;

typedef struct hs_audio_config
{
  uint32_t sample_rate;   //8000,16000,32000; 11025,22050,44100; 12000,24000,48000; 96000
  uint8_t sample_channels;//1-mono 2-stereo
  uint8_t sample_bits;    //8,16,24
  uint16_t fade_in;       //unmute rate in ms
  uint16_t fade_out;      //mute rate in ms
  hs_codec_route_t source;
} hs_audio_config_t;

/**
 * @brief   Structure representing an I2S driver.
 * @note    Implementations may extend this structure to contain more,
 *          architecture dependent, fields.
 */
typedef struct
{
  HS_CODEC_Type          *codec;
  hs_codec_type_t         codec_type;

  ///treat as muted status if current gain <= dac_db_min
  int8_t                  dac_db_min;
  ///the latency is used to hide pop noise with PA on PCB
  uint8_t                 pa_latency;
  ///the latency is used to power up dac analog
  uint8_t                 dac_latency;
  ///mic select, i.e. switch input between linein and mic
  uint8_t                 mic_select;
  ///pga gain switch between linein and mic
  uint8_t                 pga_gain_aux : 4;
  uint8_t                 pga_gain_mic : 4;
  ///pop noise
  bool                    isVirgin;
  ///avoid double open
  bool                    isPlayed;
  ///timing in cpu cycle
  uint8_t                 cpu_mhz;

  ///audio settings
  hs_audio_config_t       cfg_ply;
  hs_audio_config_t       cfg_rec;

  virtual_timer_t         pa_timer;
  virtual_timer_t         drv_timer;
}CODECDriver;

/*===========================================================================*/
/* Driver macros.                                                            */
/*===========================================================================*/

#define RC_CALIBRATE_NUMBER   5
#define PGA_GAIN_MAXIDX       7

#define __codec_clr_bit(val, bit)            (val) &= ~(1u<<bit)
#define __codec_set_bit(val, bit)            (val) |= (1u<<bit)

#define __codec_set_bitval(val, bit, bitval)        \
do{                                                 \
  uint32_t mask;                                    \
  mask = 1u<<(bit);                                 \
  (val) = ((val)&~mask) | (((bitval)<<(bit))&mask); \
}while(0)

#define __codec_set_bitsval(val, s, e, bitval)      \
do{                                                 \
  uint32_t mask;                                    \
  mask = ((1u<<((e)-(s)+1)) - 1) << (s);            \
  (val) = ((val)&~mask) | (((bitval)<<(s))&mask);   \
}while(0)

#define __codec_adc_enable()                  __codec_set_bit(HS_CODEC->ADC_CTRL, 0)
#define __codec_adc_disable()                 __codec_clr_bit(HS_CODEC->ADC_CTRL, 0)
#define __codec_adc_unreset()                 __codec_set_bit(HS_CODEC->ADC_CTRL, 1)
#define __codec_adc_dmic_enable(codec)        __codec_set_bit((codec)->ADC_CTRL, 2)
#define __codec_adc_dmic_disable(codec)       __codec_clr_bit((codec)->ADC_CTRL, 2)
#define __codec_adc_dc_enable(codec)          __codec_set_bit((codec)->ADC_CTRL, 3)
#define __codec_adc_dc_disable(codec)         __codec_clr_bit((codec)->ADC_CTRL, 3)

#define __codec_adc_mute()                                              \
  /* [24]adc_vol_update=0 [2]adc_mute_bypass=0 [1]adcunmu=0 [0]adcmu=1 */ \
  do {                                                                  \
    HS_CODEC->ADC_VOL_CTRL = (HS_CODEC->ADC_VOL_CTRL & ~((1<<24) | (1<<2) | (1<<1) | (1<<0))) | \
      (0<<24) | (0<<2) | (0<<1) | (1<<0);                               \
  } while (0)
#define __codec_adc_unmute()                                            \
  /* [24]adc_vol_update=0 [2]adc_mute_bypass=0 [1]adcunmu=1 [0]adcmu=0 */ \
  do {                                                                  \
    HS_CODEC->ADC_VOL_CTRL = (HS_CODEC->ADC_VOL_CTRL & ~((1<<24) | (1<<2) | (1<<1) | (1<<0))) | \
      (0<<24) | (0<<2) | (1<<1) | (0<<0);                               \
  } while (0)
#define __codec_adc_set_vol(left, right)                                \
  /* [24]adc_vol_update=1 [23:16]radcvol [15:8]ladcvol [2]adc_mute_bypass=1 [1]adcunmu=0 [0]adcmu=0 */ \
  do {                                                                  \
    HS_CODEC->ADC_VOL_CTRL = (HS_CODEC->ADC_VOL_CTRL & ~((1<<24) | (0xff<<16) | (0xff<<8) | (1<<2) | (1<<1) | (1<<0))) | \
      (1<<24) | ((right)<<16) | ((left)<<8) | (1<<2);                   \
  } while (0)
#define __codec_adc_set_fade_in(in)                                     \
  /* [24]adc_vol_update=0 [31:28]unmute_rate [2]adc_mute_bypass=0 */    \
  do {                                                                  \
    HS_CODEC->ADC_VOL_CTRL = (HS_CODEC->ADC_VOL_CTRL & ~((1<<24) | (0xf<<28) | (1<<2))) | \
      (0<<24) | ((in)<<28) | (0<<2);                                    \
  } while (0)
#define __codec_adc_set_fade_out(out)                                   \
  /* [24]adc_vol_update=0 [7:4]mute_rate [2]adc_mute_bypass=0 */        \
  do {                                                                  \
    HS_CODEC->ADC_VOL_CTRL = (HS_CODEC->ADC_VOL_CTRL & ~((1<<24) | (0xf<<4) | (1<<2))) | \
      (0<<24) | ((out)<<4) | (0<<2);                                    \
  } while (0)

#define __codec_dac_short_fir_enable(codec)   __codec_set_bit((codec)->DAC_CTRL, 11)
#define __codec_dac_short_fir_disable(codec)  __codec_clr_bit((codec)->DAC_CTRL, 11)
#define __codec_dac_unreset()                 __codec_set_bit(HS_CODEC->DAC_CTRL, 9)
#define __codec_dac_enable()                  __codec_set_bit(HS_CODEC->DAC_CTRL, 8)
#define __codec_dac_disable()                 __codec_clr_bit(HS_CODEC->DAC_CTRL, 8)
#define __codec_dac_set_fir(codec, val)       __codec_set_bitval((codec)->DAC_CTRL, 10, (val))
#define __codec_dac_set_anticlip(val)         __codec_set_bitval(HS_CODEC->DAC_CTRL, 13, (val))

#define __codec_dac_mute()                                              \
  /* [24]dac_vol_update=0 [2]dac_mute_bypass=0 [1]dacunmu=0 [0]dacmu=1 */ \
  do {                                                                  \
    HS_CODEC->DAC_VOL_CTRL = (HS_CODEC->DAC_VOL_CTRL & ~((1<<24) | (1<<2) | (1<<1) | (1<<0))) | \
      (0<<24) | (0<<2) | (0<<1) | (1<<0);                               \
  } while (0)
#define __codec_dac_unmute()                                            \
  /* [24]dac_vol_update=0 [2]dac_mute_bypass=0 [1]dacunmu=1 [0]dacmu=0 */ \
  do {                                                                  \
    HS_CODEC->DAC_VOL_CTRL = (HS_CODEC->DAC_VOL_CTRL & ~((1<<24) | (1<<2) | (1<<1) | (1<<0))) | \
      (0<<24) | (0<<2) | (1<<1) | (0<<0);                               \
  } while (0)
#define __codec_dac_set_vol(left, right)                                \
  /* [24]dac_vol_update=1 [23:16]rdacvol [15:8]ldacvol [2]dac_mute_bypass=1(rate_bypass) [1]dacunmu=0 [0]dacmu=0 */ \
  do {                                                                  \
    HS_CODEC->DAC_VOL_CTRL = (HS_CODEC->DAC_VOL_CTRL & ~((1<<24) | (0xff<<16) | (0xff<<8) | (1<<2) | (1<<1) | (1<<0))) | \
      (1<<24) | ((right)<<16) | ((left)<<8) | (1<<2);                   \
  } while (0)
#define __codec_dac_set_fade_in(in)                                     \
  /* [24]dac_vol_update=0 [31:28]unmute_rate [2]dac_mute_bypass=0 */    \
  do {                                                                  \
    HS_CODEC->DAC_VOL_CTRL = (HS_CODEC->DAC_VOL_CTRL & ~((1<<24) | (0xf<<28) | (1<<2))) | \
      (0<<24) | ((in)<<28) | (0<<2);                                    \
  } while (0)
#define __codec_dac_set_fade_out(out)                                   \
  /* [24]dac_vol_update=0 [7:4]mute_rate [2]dac_mute_bypass=0 */        \
  do {                                                                  \
    HS_CODEC->DAC_VOL_CTRL = (HS_CODEC->DAC_VOL_CTRL & ~((1<<24) | (0xf<<4) | (1<<2))) | \
      (0<<24) | ((out)<<4) | (0<<2);                                    \
  } while (0)


/*===========================================================================*/
/* External declarations.                                                    */
/*===========================================================================*/

#if !defined(__DOXYGEN__)
extern CODECDriver CODECD;
#endif

#define codec_lld_set_band1_gain(codecp, gain) \
  __codec_set_bitsval(HS_CODEC->DAC_EQ_CTRL_1, 16, 20, (gain)+12)
#define codec_lld_set_band1_coeff(codecp, coeff) \
  __codec_set_bitsval(HS_CODEC->DAC_EQ_CTRL_1, 0, 15, (coeff))

#define codec_lld_set_band2_gain(codecp, gain) \
  __codec_set_bitsval(HS_CODEC->DAC_EQ_CTRL_8, 0, 4, (gain)+12)
#define codec_lld_set_band2_coeff(codecp, coeff) \
  do { \
    __codec_set_bitsval(HS_CODEC->DAC_EQ_CTRL_2,  0, 15, (coeff)>>16); \
    __codec_set_bitsval(HS_CODEC->DAC_EQ_CTRL_2, 16, 31, (coeff)0xffff); \
  } while (0)

#define codec_lld_set_band3_gain(codecp, gain) \
  __codec_set_bitsval(HS_CODEC->DAC_EQ_CTRL_8, 8, 12, (gain)+12)
#define codec_lld_set_band3_coeff(codecp, coeff) \
  do { \
    __codec_set_bitsval(HS_CODEC->DAC_EQ_CTRL_3,  0, 15, (coeff)>>16); \
    __codec_set_bitsval(HS_CODEC->DAC_EQ_CTRL_3, 16, 31, (coeff)0xffff); \
  } while (0)

#define codec_lld_set_band4_gain(codecp, gain) \
  __codec_set_bitsval(HS_CODEC->DAC_EQ_CTRL_8, 16, 20, (gain)+12)
#define codec_lld_set_band4_coeff(codecp, coeff) \
  do { \
    __codec_set_bitsval(HS_CODEC->DAC_EQ_CTRL_4,  0, 15, (coeff)>>16); \
    __codec_set_bitsval(HS_CODEC->DAC_EQ_CTRL_4, 16, 31, (coeff)0xffff); \
  } while (0)

#define codec_lld_set_band5_gain(codecp, gain) \
  __codec_set_bitsval(HS_CODEC->DAC_EQ_CTRL_8, 24, 28, (gain)+12)
#define codec_lld_set_band5_coeff(codecp, coeff) \
  do { \
    __codec_set_bitsval(HS_CODEC->DAC_EQ_CTRL_5,  0, 15, (coeff)>>16); \
    __codec_set_bitsval(HS_CODEC->DAC_EQ_CTRL_5, 16, 31, (coeff)0xffff); \
  } while (0)

#define codec_lld_set_band6_gain(codecp, gain) \
  __codec_set_bitsval(HS_CODEC->DAC_EQ_CTRL_7, 16, 20, (gain)+12)
#define codec_lld_set_band6_coeff(codecp, coeff) \
  do { \
    __codec_set_bitsval(HS_CODEC->DAC_EQ_CTRL_6,  0, 15, (coeff)>>16); \
    __codec_set_bitsval(HS_CODEC->DAC_EQ_CTRL_6, 16, 31, (coeff)0xffff); \
  } while (0)

#define codec_lld_set_band7_gain(codecp, gain) \
  __codec_set_bitsval(HS_CODEC->DAC_EQ_CTRL_7, 24, 28, (gain)+12)
#define codec_lld_set_band7_coeff(codecp, coeff) \
  __codec_set_bitsval(HS_CODEC->DAC_EQ_CTRL_7, 0, 15, (coeff))

#define codec_lld_set_eq(codecp, enable) \
  __codec_set_bitsval(codec_r->DAC_EQ_CTRL_1, 24, 24, (enable) ? 0 : 1)

#define codec_lld_get_rms(codecp) \
  (((HS_CODEC->DAC_PEAK_READ >> 16) & 0xffff) + (HS_CODEC->DAC_PEAK_READ & 0xffff)) / 2

#ifdef __cplusplus
extern "C" {
#endif

  void codec_lld_init(void);
  void codec_lld_start(CODECDriver *codecp);
  void codec_lld_stop(CODECDriver *codecp);

  void codec_lld_record_start(CODECDriver *codecp, hs_audio_config_t *cfgp);
  void codec_lld_record_stop(CODECDriver *codecp);
  void codec_lld_record_mute(CODECDriver *codecp, bool bMute);
  void codec_lld_record_set_volume(CODECDriver *codecp, int ddb_left, int ddb_right);
  void codec_lld_record_get_volume(CODECDriver *codecp, int *ddb_left, int *ddb_right);

  void codec_lld_play_start(CODECDriver *codecp, hs_audio_config_t *cfgp);
  void codec_lld_play_stop(CODECDriver *codecp);
  void codec_lld_play_mute(CODECDriver *codecp, bool bMute);
  void codec_lld_play_set_volume(CODECDriver *codecp, int ddb_left, int ddb_right);
  void codec_lld_play_get_volume(CODECDriver *codecp, int *ddb_left, int *ddb_right);

#ifdef __cplusplus
}
#endif

#endif /* HAL_USE_AUDIO */

#endif /* _CODEC_LLD_H_ */

/** @} */
