/*
    ChibiOS - Copyright (C) 2019 BRMICRO Technologies
              

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    br32xx/mscr_lld.h
 * @brief   MSR (Magnetic Strip Reader) Driver subsystem low level driver header.
 *
 * @addtogroup MSR
 * @{
 */

#ifndef _MSR_LLD_H_
#define _MSR_LLD_H_

#if HAL_USE_MSR || defined(__DOXYGEN__)

/*===========================================================================*/
/* Driver constants.                                                         */
/*===========================================================================*/

#define MSR_MAX_NR_TRACKS     3

/**
 * @name    MSR signals
 */
#define MSR_SIGNAL_START      1U
#define MSR_SIGNAL_END        2U
#define MSR_SIGNAL_ERROR      0x10U

/*===========================================================================*/
/* Driver pre-compile time settings.                                         */
/*===========================================================================*/

/**
 * @name    Configuration options
 * @{
 */
/**
 * @brief   MSR interrupt priority level setting.
 */
#if !defined(HS_MSR_IRQ_PRIORITY) || defined(__DOXYGEN__)
#define HS_MSR_IRQ_PRIORITY             3
#endif
/** @} */

/*===========================================================================*/
/* Derived constants and error checks.                                       */
/*===========================================================================*/

#if HS_MSR_IRQ_PRIORITY > 3
#error "Invalid IRQ priority assigned to MSR"
#endif

/*===========================================================================*/
/* Driver data structures and types.                                         */
/*===========================================================================*/

/**
 * @brief   Type of a structure representing a MSR driver.
 */
typedef struct MSRDriver MSRDriver;

/**
 * @brief   Driver configuration structure.
 * @note    It could be empty on some architectures.
 */
typedef struct {
  uint8_t                     bitmap_tracks;
  uint8_t                     sample_rate; //in khz
  uint16_t                    th_low[MSR_MAX_NR_TRACKS];
  uint16_t                    th_gap[MSR_MAX_NR_TRACKS];
  uint16_t                    f2f_len[MSR_MAX_NR_TRACKS]; //in half-word
} MSRConfig;

/**
 * @brief   Structure representing a MSR driver.
 */
struct MSRDriver {
  /**
   * @brief Current configuration data.
   */
  const MSRConfig             *config;
  /**
   * @brief Driver state.
   */
  msr_state_t                 state;
  /**
   * @brief Errors flags.
   */
  uint32_t                    errors;
  /**
   * @brief Capture buffer in F2F.
   */
  uint16_t                    *f2f_buf[MSR_MAX_NR_TRACKS];
  /**
   * @brief Decode buffer.
   */
  uint8_t                     *dec_buf[MSR_MAX_NR_TRACKS];
  /**
   * @brief Thread waiting for I/O completion IRQ.
   */
  thread_reference_t          f2f_thd;
  /* End of the mandatory fields.*/

  /* @brief The pending bitmap of tracks. */
  virtual_timer_t             f2f_vt;
  uint16_t                    f2f_len[MSR_MAX_NR_TRACKS]; //in half-word
  uint8_t                     mag_bytes[MSR_MAX_NR_TRACKS];
  uint8_t                     pending;
};

/*===========================================================================*/
/* Driver macros.                                                            */
/*===========================================================================*/

/**
 * @name    R1 response utilities
 * @{
 */
/** @} */

/*===========================================================================*/
/* External declarations.                                                    */
/*===========================================================================*/

#if !defined(__DOXYGEN__)
extern MSRDriver MSRD0;
#endif

#ifdef __cplusplus
extern "C" {
#endif
  void msr_lld_init(void);
  void msr_lld_start(MSRDriver *msrp, const MSRConfig *config);
  void msr_lld_stop(MSRDriver *msrp);
#ifdef __cplusplus
}
#endif

#endif /* HAL_USE_MSR */

#endif /* _MSR_LLD_H_ */

/** @} */
