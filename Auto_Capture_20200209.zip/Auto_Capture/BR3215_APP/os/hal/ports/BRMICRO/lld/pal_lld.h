/*
    ChibiOS/RT - Copyright (C) 2006-2013 Giovanni Di Sirio
                 Copyright (C) 2019 BRMICRO Technologies
                 

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    BR32xx/pal_lld.h
 * @brief   BR32xx PAL low level driver header.
 *
 * @addtogroup PAL
 * @{
 */

#ifndef _PAL_LLD_H_
#define _PAL_LLD_H_

#if HAL_USE_PAL || defined(__DOXYGEN__)

#ifndef BR3215e
#define BR3215e
#endif
/*===========================================================================*/
/* Unsupported modes and specific modes                                      */
/*===========================================================================*/

#undef PAL_MODE_RESET
#undef PAL_MODE_UNCONNECTED
#undef PAL_MODE_INPUT
#undef PAL_MODE_INPUT_PULLUP
#undef PAL_MODE_INPUT_PULLDOWN
#undef PAL_MODE_INPUT_ANALOG
#undef PAL_MODE_OUTPUT_PUSHPULL
#undef PAL_MODE_OUTPUT_OPENDRAIN

enum {
  PA0         = 0,
  PA1         ,
  PA2         ,
  PA3         ,
  PA4         ,
  PA5         ,
  PA6         ,
  PA7         ,
  PA8         ,
  PA9         ,
  PA10        ,
  PA11        ,
  PA12        ,
  PA13        ,
  PA14        ,
  PA15        ,

  PB0         ,
  PB1         ,
  PB2         ,
  PB3         ,
  PB4         ,
  PB5         ,
  PB6         ,
  PB7         ,

#if defined(BR3215e)
  PB8         ,
  PB9         ,
#endif

  PIN_NUM
};

/**
 * @name    BR32xx-specific I/O PAD number
 * @{
 */
#define    PAD_FUNC_JTAG             (0)
#define    PAD_FUNC_DEBUG            (1)
#define    PAD_FUNC_TIMER_1AND2      (2)
#define    PAD_FUNC_SFLASH           (3)
#define    PAD_FUNC_SD_USB           (4)
#define    PAD_FUNC_GPIO             (5)
#if defined (BR3215e)
#define    PAD_FUNC_DMIC_IN          (6)
#define    PAD_FUNC_DMIC_CLK         (7)
#else
#define    PAD_FUNC_I2S_TEST         (6) /* PA4=o_i2s_codec_sdo */
#define    PAD_FUNC_PCM_TEST         (7)
#endif
#define    PAD_FUNC_I2C_SCK          (8)
#define    PAD_FUNC_I2C_SDA          (9)
#define    PAD_FUNC_SPI0_MISO        (10)
#define    PAD_FUNC_SPI0_MOSI        (11)
#define    PAD_FUNC_SPI0_CSN         (12)
#define    PAD_FUNC_SPI0_SCK         (13)
#define    PAD_FUNC_SPI1_MISO        (14)
#define    PAD_FUNC_SPI1_MOSI        (15)
#define    PAD_FUNC_SPI1_CSN         (16)
#define    PAD_FUNC_SPI1_SCK         (17)
#define    PAD_FUNC_UART0_RX         (18)
#define    PAD_FUNC_UART0_TX         (19)
#define    PAD_FUNC_UART0_SIR_RX     (20)
#define    PAD_FUNC_UART0_SIR_TX     (21)
#define    PAD_FUNC_UART1_RX         (22)
#define    PAD_FUNC_UART1_TX         (23)
#define    PAD_FUNC_UART1_CTS        (24)
#define    PAD_FUNC_UART1_RTS        (25)
#define    PAD_FUNC_UART2_RX         (50)
#define    PAD_FUNC_UART2_TX         (51)
#if defined(BR3215e)
#define    PAD_FUNC_TIMER2_TOGGLE0   (26)
#define    PAD_FUNC_TIMER2_TOGGLE1   (27)
#define    PAD_FUNC_TIMER2_TOGGLE2   (28)
#define    PAD_FUNC_TIMER2_TOGGLE3   (29)
#define    PAD_FUNC_I2S_WS_TX        (30)
#define    PAD_FUNC_I2S_SCK_TX       (31)
#define    PAD_FUNC_I2S_WS_RX        (32)
#define    PAD_FUNC_I2S_SCK_RX       (33)
#define    PAD_FUNC_I2S_SDI          (34)
#define    PAD_FUNC_I2S_SDO          (35)
#define    PAD_FUNC_TIMER0_TOGGLE0   (36)
#define    PAD_FUNC_TIMER0_TOGGLE1   (37)
#define    PAD_FUNC_TIMER0_TOGGLE2   (38)
#define    PAD_FUNC_TIMER0_TOGGLE3   (39)
#define    PAD_FUNC_TIMER1_TOGGLE0   (40)
#define    PAD_FUNC_XTAL_BUF         (41)    //xclk output
#define    PAD_FUNC_SD_DETECT        (42)
#define    PAD_FUNC_SD_WP            (43)
#define    PAD_FUNC_TIMER1_TOGGLE1   (44)
#define    PAD_FUNC_AU_CLK24M        (45)
#define    PAD_FUNC_CODEC_CLK12M     (46)
#define    PAD_FUNC_TIMER1_TOGGLE2   (47)
#define    PAD_FUNC_TIMER1_TOGGLE3   (48)
#define    PADC_FUNC_ADC_DITHER_OUT  (49)    //fixed configure at PA6,PA7 pin.
#define    PADC_FUNC_ADC_ANA_OUT_L   (49)    //fixed configure at PA8,PA9,PA10 pin.
#define    PADC_FUNC_ADC_ANA_OUT_R   (49)    //fixed configure at PA11,PA12,PA13 pin.
#define    PAD_FUNC_I2S_CODEC_SDO    (50)
#define    PAD_FUNC_DAC_SDM_FP       (51)    //fixed configure at PA5,PA6,PA7 pin.
#define    PAD_FUNC_DAC_LSW_OUT      (51)    //fixed configure at PA11,PA12,PA13 pin.
#define    PAD_FUNC_DAC_RSW_OUT      (51)    //fixed configure at PA8,PA9,PA10 pin.
#define    PAD_FUNC_LED_DISP0        (52)
#define    PAD_FUNC_LED_DISP1        (53)
#define    PAD_FUNC_LED_DISP2        (54)
#define    PAD_FUNC_LED_DISP3        (55)
#define    PAD_FUNC_LED_DISP4        (56)
#define    PAD_FUNC_LED_DISP5        (57)
#define    PAD_FUNC_LED_DISP6        (58)
#else    //BR3215 BR3215c
#define    PAD_FUNC_RTC_TI1_EVENT    (26)
#define    PAD_FUNC_RTC_TI2_EVENT    (27)
#define    PAD_FUNC_RTC_AFO_ALARM    (28)
#define    PAD_FUNC_RTC_AFO_CALIB    (29)
#define    PAD_FUNC_I2S_SCK_TX       (30)
#define    PAD_FUNC_I2S_SCK_RX       (31)
#define    PAD_FUNC_I2S_WS_TX        (32)
#define    PAD_FUNC_I2S_WS_RX        (33)
#define    PAD_FUNC_I2S_SDI          (34)
#define    PAD_FUNC_I2S_SDO          (35)
#define    PAD_FUNC_TIMER0_CH0       (36)
#define    PAD_FUNC_TIMER0_CH1       (37)
#define    PAD_FUNC_TIMER0_CH2       (38)
#define    PAD_FUNC_TIMER0_CH3       (39)
#define    PAD_FUNC_TIMER0_BKIN      (40)
#define    PAD_FUNC_TIMER0_TOGGLE0   (47)
#define    PAD_FUNC_TIMER0_TOGGLE1   (48)
#define    PAD_FUNC_TIMER0_TOGGLE2   (49)
#define    PAD_FUNC_SD_DETECT        (42)
#define    PAD_FUNC_SD_WP            (43)
#define    PAD_FUNC_DMIC_CLK         (44)
#define    PAD_FUNC_DMIC_IN          (45)
#define    PAD_CODEC_CLK12M          (46)
#endif

/**
 * @name    BR32xx-specific I/O mode flags
 * @{
 */
#define PAL_HS_MODE_MASK             (1 << 0)
#define PAL_HS_MODE_INPUT            (1 << 0)
#define PAL_HS_MODE_OUTPUT           (0 << 0)

#define PAL_HS_PUDR_MASK             (3 << 1)
#define PAL_HS_PUDR_NOPUPDR          (0 << 1)
#define PAL_HS_PUDR_PULLUP           (1 << 1)
#define PAL_HS_PUDR_PULLDOWN         (2 << 1)

#define PAL_HS_DRCAP_MASK            (3 << 3)
#define PAL_HS_DRCAP(n)              ((n&3) << 3)

#define PAL_HS_ALTERNATE_MASK        (0x3f << 5)
#define PAL_HS_ALTERNATE(n)          ((n&0x3f) << 5)


/**
 * @brief   Alternate function.
 *
 * @param[in] n         alternate function selector
 */
#define PAL_MODE_ALTERNATE(n)       PAL_HS_ALTERNATE(n)
/** @} */


/**
 * @brief   pad drive capability function.
 *
 * @param[in] n         drive capability selector
 *                      3: max drive
 *                      0: min drive
 */
#define PAL_MODE_DRIVE_CAP(n)     PAL_HS_DRCAP(n) 
/** @} */


/**
 * @name    Standard I/O mode flags
 * @{
 */
/**
 * @brief   This mode is implemented as input.
 */
#define PAL_MODE_RESET                  PAL_HS_MODE_INPUT

/**
 * @brief   This mode is implemented as input with pull-up.
 */
#define PAL_MODE_UNCONNECTED            PAL_MODE_INPUT_PULLUP

/**
 * @brief   Regular input high-Z pad.
 */
#define PAL_MODE_INPUT                  (PAL_HS_MODE_INPUT |             \
                                        PAL_HS_PUDR_NOPUPDR)

/**
 * @brief   Input pad with weak pull up resistor.
 */
#define PAL_MODE_INPUT_PULLUP           (PAL_HS_MODE_INPUT |             \
                                         PAL_HS_PUDR_PULLUP)

/**
 * @brief   Input pad with weak pull down resistor.
 */
#define PAL_MODE_INPUT_PULLDOWN         (PAL_HS_MODE_INPUT |             \
                                         PAL_HS_PUDR_PULLDOWN)

/**
 * @brief   Regular output high-Z pad.
 */
#define PAL_MODE_OUTPUT                 (PAL_HS_MODE_OUTPUT |             \
                                        PAL_HS_PUDR_NOPUPDR)

/**
 * @brief   Pullup output pad.
 */
#define PAL_MODE_OUTPUT_PULLUP         (PAL_HS_MODE_OUTPUT |            \
                                         PAL_HS_PUDR_PULLUP)

/**
 * @brief   pulldown output pad.
 */
#define PAL_MODE_OUTPUT_PULLDOWN       (PAL_HS_MODE_OUTPUT |            \
                                         PAL_HS_PUDR_PULLDOWN)

/** @} */


#if !defined(HS_GPIO_INTR_PRIORITY) || defined(__DOXYGEN__)
#define HS_GPIO_INTR_PRIORITY        3
#endif

/*===========================================================================*/
/* I/O Ports Types and constants.                                            */
/*===========================================================================*/

/**
 * @brief   PAL port setup info.
 */
typedef struct {
  uint32_t      data;
  uint32_t      out;
  uint32_t      altfunc;
  uint32_t      inten;
  uint32_t      inttype;
  uint32_t      intpol;
} hs_gpio_setup_t;


/**
 * @brief   PAL interrupt type (polarity).
 */
typedef enum {
  FALLING_EDGE = 0,
  RISING_EDGE,
  BOTH_EDGE,
  LOW_LEVEL,
  HIGH_LEVEL,
}hs_gpio_itype_t;

/**
 * @brief   PAL interrupt callback.
 */
typedef void (*hs_gpio_isr_t)(void *arg);

/**
 * @brief   HS PAL static initializer.
 * @details An instance of this structure must be passed to @p palInit() at
 *          system startup time in order to initialize the digital I/O
 *          subsystem. This represents only the initial setup, specific pads
 *          or whole ports can be reprogrammed at later time.
 */
typedef struct {
  hs_gpio_setup_t    gpio0;
  hs_gpio_setup_t    gpio1;
} PALConfig;

/**
 * @brief   Width, in bits, of an I/O port.
 */
#define PAL_IOPORTS_WIDTH 16

/**
 * @brief   Whole port mask.
 * @details This macro specifies all the valid bits into a port.
 */
#define PAL_WHOLE_PORT ((ioportmask_t)0xFFFF)

/**
 * @brief Digital I/O port sized unsigned type.
 */
typedef uint32_t ioportmask_t;

/**
 * @brief   Digital I/O modes.
 */
typedef uint32_t iomode_t;

/**
 * @brief   Port Identifier.
 * @details This type can be a scalar or some kind of pointer, do not make
 *          any assumption about it, use the provided macros when populating
 *          variables of this type.
 */
typedef HS_GPIO_Type * ioportid_t;

typedef enum {
  VCMP_ADKEY,
  VCMP_VBUS,
  VCMP_VBAT,
  VCMP_NUM,
  ///act as gpio
  VCMP_PA0,
} vcmp_dev_t;

/*===========================================================================*/
/* I/O Ports Identifiers.                                                    */
/* The low level driver wraps the definitions already present in the HS   */
/* firmware library.                                                         */
/*===========================================================================*/

/**
 * @brief   PAL port 0 identifier.
 */
#if HS_HAS_GPIO0 || defined(__DOXYGEN__)
#define GPIOA         HS_GPIO0
#define IOPORT0       HS_GPIO0
#endif

/**
 * @brief   PAL port 1 identifier.
 */
#if HS_HAS_GPIO1 || defined(__DOXYGEN__)
#define GPIOB         HS_GPIO1
#define IOPORT1       HS_GPIO1
#endif

/*===========================================================================*/
/* Implementation, some of the following macros could be implemented as      */
/* functions, if so please put them in pal_lld.c.                            */
/*===========================================================================*/

/**
 * @brief   GPIO[0..31] to GPIOA/B[0..15]
 */
#define pal_lld_gpio_to_port(gpio)      (gpio<PAL_IOPORTS_WIDTH ? GPIOA : GPIOB)
#define pal_lld_gpio_to_port_pin(gpio)  (gpio<PAL_IOPORTS_WIDTH ? gpio : (gpio-PAL_IOPORTS_WIDTH))

/**
 * @brief   GPIOA/B[0..15] to GPIO[0..31]
 */
#define pal_lld_port_pin_to_gpio(port, pin)  ((port == GPIOA) ? pin : (pin+PAL_IOPORTS_WIDTH))

/**
 * @brief   PAL ports subsystem initialization.
 *
 * @notapi
 */
#define pal_lld_init(config) _pal_lld_init(config)

/**
 * @brief   Reads an I/O port.
 * @details This function is implemented by reading the PAL DATA register.
 * @note    This function is not meant to be invoked directly by the application
 *          code.
 *
 * @param[in] port      port identifier
 * @return              The port bits.
 *
 * @notapi
 */
#define pal_lld_readport(port) ((port)->DATA)

/**
 * @brief   Reads the output latch.
 * @details This function is implemented by reading the PAL DATAOUT register.
 * @note    This function is not meant to be invoked directly by the application
 *          code.
 *
 * @param[in] port      port identifier
 * @return              The latched logical states.
 *
 * @notapi
 */
#define pal_lld_readlatch(port) ((port)->DATAOUT)

/**
 * @brief   Writes on a I/O port.
 * @details This function is implemented by writing the PAL DATAOUT register.
 * @note    Writing on pads programmed as pull-up or pull-down has the side
 *          effect to modify the resistor setting because the output latched
 *          data is used for the resistor selection.
 *
 * @param[in] port      port identifier
 * @param[in] bits      bits to be written on the specified port
 *
 * @notapi
 */
#define pal_lld_writeport(port, bits) ((port)->DATAOUT = (bits))

/**
 * @brief   Pads group mode setup.
 * @details This function programs a pads group belonging to the same port
 *          with the specified mode.
 * @note    @p PAL_MODE_UNCONNECTED is implemented as output as recommended by
 *          the MSP430x1xx Family User's Guide.
 * @note    This function does not alter the @p PxSEL registers. Alternate
 *          functions setup must be handled by device-specific code.
 *
 * @param[in] port      port identifier
 * @param[in] pad       pad number within the port
 * @param[in] mode      mode
 *
 * @notapi
 */
#define pal_lld_setgroupmode(port, mask, offset, mode) \
   (_pal_lld_setgroupmode(port, mask << offset, mode))

/**
 * @brief   Pad mode setup.
 *
 * @param[in] port      port identifier
 * @param[in] pad       pad number within the port
 * @param[in] mode      mode
 */
#define pal_lld_setpadmode(port, pad, mode) \
	_pal_lld_set_pin_mode((port == GPIOA) ? pad : (pad + PAL_IOPORTS_WIDTH), mode)

#define pal_lld_read_pin(pin)                       (_pal_lld_read_pin(pin))
#define pal_lld_set_pin(pin)                        (_pal_lld_set_pin(pin))
#define pal_lld_clear_pin(pin)                      (_pal_lld_clear_pin(pin))
#define pal_lld_toggle_pin(pin)                     (_pal_lld_toggle_pin(pin))
#define pal_lld_set_pin_mode(pin, mode)             (_pal_lld_set_pin_mode(pin, mode))
#define pal_lld_register_isr(pin, itype, cb, arg)   (_pal_lld_register_isr(pin, itype, cb, arg))
#define pal_lld_unregister_isr(pin)                 (_pal_lld_unregister_isr(pin))
#define pal_lld_register_wakeup(pin, itype, cb)     (_pal_lld_register_wakeup(pin, itype, cb))

/**
 * @brief    Set GPIO pin wakeup.
 * @note     Note for BR3215c:
 *           1. In versions before A3, only PA0 can be used as wakeup pin.
 *           2. In version A3, all pins can be used as wakeup pins.
 *              When two or more pins are simultaneously used as wakeup pins,
 *              all pins must be in invalid level state just before the wakeup
 *              event to occur, otherwise the internal posedge or negedge can
 *              not be generated.
 *
 * @param gpio_bitmap    gpio[0..31]; 0-bit not affected; 1-bit to be set.
 * @param mask_bitmap    gpio[0..31]; 0-disable wakeup; 1-enable wakeup.
 * @param polar_bitmap   gpio[0..31]; 0-high level wakeup;  1-low level wakeup.
 */
#if defined(BR3215c)
#define pal_lld_set_wakeup(gpio_bitmap, mask_bitmap, polar_bitmap) \
do {\
	HS_PMU->GPIO_MASK &= ~(gpio_bitmap);  /* clear */\
	HS_PMU->GPIO_MASK |= (mask_bitmap);   /* 0-disable wakeup; 1-enable wakeup. */\
	HS_PMU->GPIO_POLAR &= ~(gpio_bitmap); /* clear */\
	HS_PMU->GPIO_POLAR |= (polar_bitmap); /* 0-high wakeup; 1-low wakeup. */\
	HS_PMU->BASIC |= (1UL<<30);           /* update */\
} while (0)
#else
#define pal_lld_set_wakeup(gpio_bitmap, mask_bitmap, polar_bitmap) (void)(gpio_bitmap); (void)(mask_bitmap); (void)(polar_bitmap);
#endif

/**
 * @brief   Get GPIO wakeup mask bitmap.
 * @note    0-disable wakeup; 1-enable wakeup.
 */
#define pal_lld_get_wakeup_mask()  (HS_PMU->GPIO_MASK)

/**
 * @brief   Get GPIO wakeup polar bitmap.
 * @note    0-high level wakeup; 1-low level wakeup.
 */
#define pal_lld_get_wakeup_polar() (HS_PMU->GPIO_POLAR)

extern const PALConfig pal_default_config;

#ifdef __cplusplus
extern "C" {
#endif

  void _pal_lld_init(const PALConfig *config);
  void _pal_lld_setgroupmode(ioportid_t port,
                             ioportmask_t mask,
                             iomode_t mode);

  int _pal_lld_read_pin(uint8_t pin);
  void _pal_lld_set_pin(uint8_t pin);
  void _pal_lld_clear_pin(uint8_t pin);
  void _pal_lld_toggle_pin(uint8_t pin);
  void _pal_lld_set_pin_mode(uint8_t pin, iomode_t mode);

  /**
   * @brief   Enable and register the Interrupt Service Routine for the specific pin.
   *
   * @param[in] pin           the interrupt pin
   * @param[in] itype         the interrupt type
   * @param[in] cb            the Interrupt Service Routine on this interrupt pin
   * @param[in] arg           the argument of ISR
   */
  void _pal_lld_register_isr(uint8_t pin, hs_gpio_itype_t itype, hs_gpio_isr_t cb, void *arg);
  /**
   * @brief   Disable and unregister the Interrupt Service Routine for the specific pin.
   *
   * @param[in] pin           the interrupt pin
   */
  void _pal_lld_unregister_isr(uint8_t pin);

  /**
   * @brief   Register the callback for the specific wakeup pin(s).
   * @note    The wakeup capability on the other pins will be disabled.
   * @note    The wakeup callback will be cleared after executed.
   *
   * @param[in] pin_bitmap    the wakeup pin(s) in bitmap
   * @param[in] itype         the wakeup type
   * @param[in] cb            the callback to be executed when wakeup
   */
  void _pal_lld_register_wakeup(uint32_t pin_bitmap, hs_gpio_itype_t itype, hs_gpio_isr_t cb);

  /* voltage comparators */
  void vcmp_lld_enable_irq(vcmp_dev_t dev);
  void vcmp_lld_disable_irq(vcmp_dev_t dev);
  void vcmp_lld_register_isr(vcmp_dev_t dev, hs_gpio_isr_t cb, void *arg);

#ifdef __cplusplus
}
#endif

#endif /* HAL_USE_PAL */

#endif /* _PAL_LLD_H_ */

/** @} */
