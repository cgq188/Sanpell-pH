/*
    ChibiOS/RT - Copyright (C) 2006-2013 Giovanni Di Sirio
                 Copyright (C) 2019 BRMICRO Technologies
                 

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/
/*
   Concepts and parts of this file have been contributed by Uladzimir Pylinsky
   aka barthess.
 */

/**
 * @file    br32xx/rtc_lld_hs.c
 * @brief   BR3215e RTC subsystem low level driver header.
 *
 * @addtogroup RTC
 * @{
 */

#include <time.h>
#include "hal.h"

#if (HAL_USE_RTC && HS_HAS_RTC_YGW) || defined(__DOXYGEN__)

/*===========================================================================*/
/* Driver local definitions.                                                 */
/*===========================================================================*/

/*===========================================================================*/
/* Driver exported variables.                                                */
/*===========================================================================*/

/**
 * @brief RTC driver identifier.
 */
RTCDriver RTCD0;

/*===========================================================================*/
/* Driver local variables and types.                                         */
/*===========================================================================*/
static time_t _rtc_lld_unixtime_base;

/*===========================================================================*/
/* Driver local functions.                                                   */
/*===========================================================================*/
#define _rtc_lld_set_cr(bit)                    \
  do {                                          \
    while (0 == (HS_RTC->CR & (1u << 8)))       \
      ;                                         \
    HS_RTC->CR |= (bit);                        \
  } while (0)

#define _rtc_lld_clr_cr(bit)                    \
  do {                                          \
    while (0 == (HS_RTC->CR & (1u << 8)))       \
      ;                                         \
    HS_RTC->CR &= ~(bit);                       \
  } while (0)

#define _rtc_lld_set_tick(ms)                   \
  do {                                          \
    while (0 == (HS_RTC->CR & (1u << 9)))       \
      ;                                         \
    HS_RTC->TICK = (ms);                        \
  } while (0)

#define _rtc_lld_set_alarm(ms)                  \
  do {                                          \
    while (0 == (HS_RTC->CR & (1u << 10)))      \
      ;                                         \
    HS_RTC->ALARM = (ms);                       \
  } while (0)

/*===========================================================================*/
/* Driver interrupt handlers.                                                */
/*===========================================================================*/
/**
 * @brief   RTC interrupt handler.
 *
 * @isr
 */
OSAL_IRQ_HANDLER(RTC1_IRQHandler)
{
  uint32_t flags;
  RTCDriver *rtcp = &RTCD0;

  OSAL_IRQ_PROLOGUE();

  flags = HS_RTC->INTSTAT;

  if (flags & RTC_INT_TICK) {
  	HS_RTC->INTRAWSTAT = RTC_INT_TICK;
    if (rtcp->callback) {
      rtcp->callback(rtcp, RTC_EVENT_AUTO_WAKEUP);
    }
  }

  if (flags & RTC_INT_ALARM) {
  	HS_RTC->INTRAWSTAT = RTC_INT_ALARM;
    if (rtcp->callback) {
      rtcp->callback(rtcp, RTC_EVENT_ALARMA);
    }
  }

  OSAL_IRQ_EPILOGUE();
}

/*===========================================================================*/
/* Driver exported functions.                                                */
/*===========================================================================*/

/**
 * @brief   Enable access to registers.
 *
 * @api
 */
void rtc_lld_init(void) {

  RTCDriver *rtcp = &RTCD0;

  rtcObjectInit(rtcp);
  rtcp->id_rtc = HS_RTC;
  rtcp->callback = NULL;

  #if defined(BR3215e)
  /* the resolution of sleep timer 1 is 1ms */
  HS_PMU_CPM->CRY_CFG = (32u << 7) | (1u << 4) | (1u << 0);
  HS_PMU_CPM->UPD = 1;
  #endif

  if (0 == _rtc_lld_unixtime_base) {
    /* Aug  3 16:03:17 2018 */
    _rtc_lld_unixtime_base = 1533311552;
  }
  _rtc_lld_set_cr(RTC_CR_TIMER_ON);
  HS_RTC->INTMASK = RTC_INT_ALARM | RTC_INT_TICK;
  nvicEnableVector(RTC1_IRQn, HS_RTC_IRQ_PRIORITY);
}


/**
 * @brief   Set current time.
 * @note    Fractional part will be silently ignored.
 *
 * @param[in] rtcp      pointer to RTC driver structure
 * @param[in] timespec  pointer to a @p RTCDateTime structure
 *
 * @api
 */
void rtc_lld_set_time(RTCDriver *rtcp, const RTCDateTime *timespec) {

  (void)rtcp;
  struct tm tim;

  rtcConvertDateTimeToStructTm(timespec, &tim, NULL);
  _rtc_lld_unixtime_base = mktime(&tim);

  /* reset and enable timer counter, upto 49 days */
  _rtc_lld_clr_cr(RTC_CR_TIMER_ON);
  _rtc_lld_set_cr(RTC_CR_TIMER_ON);
}

/**
 * @brief   Get current time.
 *
 * @param[in] rtcp      pointer to RTC driver structure
 * @param[out] timespec pointer to a @p RTCDateTime structure
 *
 * @api
 */
void rtc_lld_get_time(RTCDriver *rtcp, RTCDateTime *timespec) {

  (void)rtcp;
  struct tm tim;
  uint32_t ms;

  localtime_r(&_rtc_lld_unixtime_base, &tim);
  ms = HS_RTC->CNT;
  rtcConvertStructTmToDateTime(&tim, ms, timespec);
}

/**
 * @brief     Set alarm time.
 *
 * @note      Default value after BKP domain reset for both comparators is 0.
 * @note      Function does not performs any checks of alarm time validity.
 *
 * @param[in] rtcp      	Pointer to RTC driver structure.
 * @param[in] alarmx  		Alarm identifier: 0=A, 1=B.
 * @param[in] alarmspec 	Pointer to a @p RTCAlarm structure.
 *
 * @api
 */
void rtc_lld_set_alarm(RTCDriver *rtcp,
                       rtcalarm_t alarmx,
                       const RTCAlarm *alarmspec) {

  (void)rtcp;
  (void)alarmx;
  struct tm tim;
  time_t unixtime;

  if (alarmspec == NULL) {
    return;
  }
  rtcConvertDateTimeToStructTm(alarmspec, &tim, NULL);
  unixtime = mktime(&tim);
  if (unixtime < _rtc_lld_unixtime_base) {
    return;
  }
  if (unixtime - _rtc_lld_unixtime_base > (int)(0xffffffffUL / 1000)) {
    /* beyond the counter limiter */
    return;
  }
  _rtc_lld_set_alarm((unixtime - _rtc_lld_unixtime_base) * 1000);
  _rtc_lld_set_cr(RTC_CR_ALARM_WAKEUP_EN);
}

/**
 * @brief   Get alarm time.
 *
 * @param[in] rtcp       pointer to RTC driver structure
 * @param[in] alarmx     alarm identifier: 0=A, 1=B.
 * @param[out] alarmspec pointer to a @p RTCAlarm structure
 *
 * @api
 */
void rtc_lld_get_alarm(RTCDriver *rtcp,
                       rtcalarm_t alarmx,
                       RTCAlarm *alarmspec) {

  (void)rtcp;
  (void)alarmx;
  struct tm tim;
  uint32_t ms;

  if (alarmspec == NULL) {
    return;
  }
  localtime_r(&_rtc_lld_unixtime_base, &tim);
  ms = HS_RTC->ALARM;
  rtcConvertStructTmToDateTime(&tim, ms, alarmspec);
}

/**
 * @brief   Disable alarm A/B.
 *
 * @param[in] rtcp       pointer to RTC driver structure
 * @param[in] alarmx     alarm identifier: 0=A, 1=B.
 *
 * @api
 */
void rtc_lld_disable_alarm(RTCDriver *rtcp,
                       rtcalarm_t alarmx) {

  (void)rtcp;
  (void)alarmx;
  _rtc_lld_clr_cr(RTC_CR_ALARM_WAKEUP_EN);
}

/**
 * @brief     Sets time of periodic wakeup.
 *
 * @param[in] rtcp       pointer to RTC driver structure
 * @param[in] wakeupspec pointer to a @p RTCWakeup structure
 *
 * @api
 */
void rtc_lld_set_periodic_wakeup(RTCDriver *rtcp, RTCWakeup *wakeupspec) {

  (void)rtcp;
  /* support resolution 1Hz only */
  uint32_t count = wakeupspec->wakeup & 0x0FFFF;
  _rtc_lld_set_tick(count * 1000);
  _rtc_lld_set_cr(RTC_CR_TICK_WAKEUP_EN);
}

/**
 * @brief     Gets time of periodic wakeup.
 *
 * @param[in] rtcp        pointer to RTC driver structure
 * @param[out] wakeupspec pointer to a @p RTCWakeup structure
 *
 * @api
 */
void rtc_lld_get_periodic_wakeup(RTCDriver *rtcp, RTCWakeup *wakeupspec) {

  (void)rtcp;
  wakeupspec->wakeup = HS_RTC->TICK / 1000;
}

/**
 * @brief     Disable periodic wakeup.
 *
 * @param[in] rtcp       pointer to RTC driver structure
 *
 * @api
 */
void rtc_lld_disable_periodic_wakeup(RTCDriver *rtcp) {

  (void)rtcp;
  _rtc_lld_clr_cr(RTC_CR_TICK_WAKEUP_EN);
}

#endif /* HAL_USE_RTC */

/** @} */
