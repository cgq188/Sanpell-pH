/*
    ChibiOS/RT - Copyright (C) 2006-2013 Giovanni Di Sirio
                 Copyright (C) 2019 BRMICRO Technologies
                 

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    br32xx/i2c_lld.c
 * @brief   I2C Driver subsystem low level driver source.
 *
 * @addtogroup I2C
 * @{
 */
#include <string.h>
#include "hal.h"

#if HAL_USE_I2C || defined(__DOXYGEN__)

static bool s_stop_flag = false;

/*===========================================================================*/
/* Driver local definitions.                                                 */
/*===========================================================================*/
// Since there is a delay between CPU write/read of the IC_DATA_CMD (TX/RX_FIFO)
// and the TXFLR/RXFLR reflecting of the change, CPU may write the TX_FIFO to
// go overflow or read the RX_FIFO to go underflow. To avoid this, CPU writes to
// TX_FIFO must not be too fast for the TXFLR to reflect. We can set
// TX_EMPTY_THRESHOLD_LEVEL to be half of tx_fifo_depth, and in each TX empty
// interrupt write less data, half of the threshold for example, to the TX_FIFO
// to avoid overflow it. A similar strategy is used to RX FIFO reading.
#define TX_FIFO_DEPTH				(i2cp->tx_fifo_depth)
#define RX_FIFO_DEPTH				(i2cp->rx_fifo_depth)
#define TX_EMPTY_THRESHOLD_LEVEL	(TX_FIFO_DEPTH/2)
#define RX_FULL_THRESHOLD_LEVEL		(RX_FIFO_DEPTH/2)
#define TX_LIMIT					(TX_EMPTY_THRESHOLD_LEVEL/2)
#define RX_LIMIT					(RX_FULL_THRESHOLD_LEVEL/2)

// Interrupt masks
#define I2C_INTR_ERROR_MASK			(\
									I2C_INTR_TX_ABRT  |\
									I2C_INTR_RX_UNDER |\
									I2C_INTR_RX_OVER  |\
									I2C_INTR_TX_OVER   \
									)

#define I2C_INTR_MASTER_MASK	  	(\
									I2C_INTR_RX_FULL    |\
					 				I2C_INTR_TX_EMPTY   |\
					 				I2C_INTR_STOP_DET   |\
					 				I2C_INTR_ERROR_MASK  \
                      				)
#define I2C_INTR_MASTER_TX_MASK     (\
									I2C_INTR_MASTER_MASK &~\
									I2C_INTR_RX_FULL\
									)
#define I2C_INTR_MASTER_RX_MASK     (\
									I2C_INTR_MASTER_MASK &~\
									I2C_INTR_TX_EMPTY\
									)

#define I2C_INTR_SELF_DMA_MASK		(\
									I2C_INTR_STOP_DET   |\
									I2C_INTR_ERROR_MASK  \
									)
#define I2C_INTR_SLAVE_MASK         (I2C_INTR_RD_REQ | \
                                     I2C_INTR_TX_ABRT | \
                                     I2C_INTR_RX_FULL | \
                                     I2C_INTR_STOP_DET)

#define I2C_INTR_SLAVE_RX_MASK      (I2C_INTR_SLAVE_MASK &~ \
									 I2C_INTR_RD_REQ)
#define I2C_INTR_SLAVE_TX_MASK      (I2C_INTR_SLAVE_MASK &~ \
									 I2C_INTR_RX_FULL)


#define I2C_ENBALE_CLOCK(i2cp)       \
  if (&I2CD0 == i2cp) {\
    cpmEnableI2C0();\
  }

#define I2C_DISBALE_CLOCK(i2cp)       \
  if (&I2CD0 == i2cp) {\
    cpmDisableI2C0();\
  }

/*===========================================================================*/
/* Driver exported variables.                                                */
/*===========================================================================*/

/**
 * @brief   I2C0 driver identifier.
 */
#if HS_I2C_USE_I2C0 || defined(__DOXYGEN__)
I2CDriver I2CD0;
#endif


/*===========================================================================*/
/* Driver local variables and types.                                         */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local functions.                                                   */
/*===========================================================================*/
uint32_t prepare_con1(bool is_rx, size_t rxbytes, bool is_timered, int timer_channel, uint32_t timer_edge) {
	uint32_t con1 = I2C_CON1_TIMER_MODE_DISABLE;

	if (is_timered)
		con1 = ((timer_channel << I2C_CON1_TIMER_CHN_POS) & I2C_CON1_TIMER_CHN_MASK) |
		       (timer_edge & I2C_CON1_TIMER_EDGEMASK);

	if (is_rx)
		con1 |= ((rxbytes << I2C_CON1_RX_LEN_POS) & I2C_CON1_RX_LEN_MASK) |
                I2C_CON1_RX_ENABLE |
                I2C_CON1_RX_LEN_UPDATE;

	return con1;
}
#define config_rx(is_rx)		(prepare_con1(is_rx, i2cp->rxbytes,\
								i2cp->config->con_mode == CONMODE_I2C_AUTO_WR,\
								i2cp->config->timer_control_channel,\
								I2C_CON1_TIMER_POSEDGE))

#if (HS_I2C_HAS_SELF_DMA == TRUE)
#if 0
void self_dma_init(I2CDriver *i2cp, uint8_t *txbuf, size_t txbytes, uint8_t *rxbuf, size_t rxbytes){
	HS_I2C_Type *dp = i2cp->i2c;

    dp->SELF_DMA_CON2 = I2C_SELF_DMA_CON2_EN | I2C_SELF_DMA_CON2_RX_ADDR_INC_OVER_BURSTS;

    if (txbuf && txbytes>0) {
		dp->SELF_DMA_ADDR = (uint32_t)txbuf;
		dp->SELF_DMA_CON1 = I2C_SELF_DMA_CON1_TX_EN |
							(((txbytes-1) & 0x0FFFUL) << I2C_SELF_DMA_CON1_TX_LEN_POS); // txbytes must be reduced by 1.
	  }

    if (rxbuf && rxbytes>0) {
	  dp->SELF_DMA_ADDR = (uint32_t)rxbuf;
	  dp->SELF_DMA_CON1 = I2C_SELF_DMA_CON1_RX_EN;
	}

    dp->INTR_MASK = I2C_INTR_SELF_DMA_MASK;
}
#endif
#endif

static uint32_t i2c_lld_scl_hcnt(uint32_t ic_clk, uint32_t tSYMBOL, uint32_t tf, int cond, int offset)
{
	/*
   * DesignWare I2C core doesn't seem to have solid strategy to meet
   * the tHD;STA timing spec.  Configuring _HCNT based on tHIGH spec
   * will result in violation of the tHD;STA spec.
   */
	if (cond)
    /*
		 * Conditional expression:
		 *
		 *   IC_[FS]S_SCL_HCNT + (1+4+3) >= IC_CLK * tHIGH
		 *
		 * This is based on the manuals, and represents an ideal
		 * configuration.  The resulting I2C bus speed will be
		 * faster than any of the others.
		 *
		 * If your hardware is free from tHD;STA issue, try this one.
		 */
		return (ic_clk * tSYMBOL + 5000) / 10000 - 8 + offset;
	else
		/*
		 * Conditional expression:
		 *
		 *   IC_[FS]S_SCL_HCNT + 3 >= IC_CLK * (tHD;STA + tf)
		 *
		 * This is just experimental rule; the tHD;STA period turned
		 * out to be proportinal to (_HCNT + 3).  With this setting,
		 * we could meet both tHIGH and tHD;STA timing specs.
		 *
		 * If unsure, you'd better to take this alternative.
		 *
		 * The reason why we need to take into account "tf" here,
		 * is the same as described in i2c_lld_scl_lcnt().
		 */
		return (ic_clk * (tSYMBOL + tf) + 5000) / 10000 - 3 + offset;
}

static uint32_t i2c_lld_scl_lcnt(uint32_t ic_clk, uint32_t tLOW, uint32_t tf, int offset)
{
	/*
	 * Conditional expression:
	 *
	 *   IC_[FS]S_SCL_LCNT + 1 >= IC_CLK * (tLOW + tf)
	 *
	 * DW I2C core starts counting the SCL CNTs for the LOW period
	 * of the SCL clock (tLOW) as soon as it pulls the SCL line.
	 * In order to meet the tLOW timing spec, we need to take into
	 * account the fall time of SCL signal (tf).  Default tf value
	 * should be 0.3 us, for safety.
	 */
	return ((ic_clk * (tLOW + tf) + 5000) / 10000) - 1 + offset;
}

/**
 * @brief   Aborts an I2C transaction.
 *
 * @param[in] i2cp      pointer to the @p I2CDriver object
 *
 * @notapi
 */
static void i2c_lld_abort_operation(I2CDriver *i2cp) {
  HS_I2C_Type *dp = i2cp->i2c;

  /* Stops the I2C peripheral.*/
  dp->INTR_MASK = 0;
  dp->ENABLE = 0;
#if (HS_I2C_HAS_SELF_DMA == TRUE)
  dp->SELF_DMA_CON2 = 0;
#endif
}



/**
 * @brief   Set clock speed.
 *
 * @param[in] i2cp      pointer to the @p I2CDriver object
 *
 * @notapi
 */
static void i2c_lld_set_clock(I2CDriver *i2cp) {
  HS_I2C_Type *dp = i2cp->i2c;
  int32_t clock_speed = i2cp->config->clock_speed;
  //i2cdutycycle_t duty = i2cp->config->duty_cycle;
  uint32_t con = dp->CON;
  volatile uint32_t clk = cpm_get_clock(HS_I2C0_CLK);

  osalDbgCheck((i2cp != NULL) && (clock_speed > 0) && (clock_speed <= 4000000));

  /* set standard and fast speed dividers for high/low periods */

  /* Standard-mode @100k */
  dp->SS_SCL_HCNT = i2c_lld_scl_hcnt(clk/1000,
				     40,/* tHD;STA = tHIGH = 4.0 us */
				     3,	/* tf = 0.3 us */
				     0,	/* 0: default, 1: Ideal */
				     0);/* No offset */
  dp->SS_SCL_LCNT = i2c_lld_scl_lcnt(clk/1000,
				     47,/* tLOW = 4.7 us */
				     3,	/* tf = 0.3 us */
				     0);/* No offset */

  /* Fast-mode @400k */
  dp->FS_SCL_HCNT = i2c_lld_scl_hcnt(clk/1000,
				     6,	/* tHD;STA = tHIGH = 0.6 us */
				     3,	/* tf = 0.3 us */
				     0,	/* 0: default, 1: Ideal */
				     0);/* No offset */
  dp->FS_SCL_LCNT = i2c_lld_scl_lcnt(clk/1000,
				     13,/* tLOW = 1.3 us */
				     3,	/* tf = 0.3 us */
				     0);/* No offset */

  if (clock_speed <= 100000) {
#if 0
    /* Configure clock_div in standard mode.*/
    osalDbgAssert(duty == STD_DUTY_CYCLE,
                "i2c_lld_set_clock(), #1",
                "Invalid standard mode duty cycle");
#endif

    /* Standard mode clock_div calculate: Tlow/Thigh = 1/1.*/
    /* Sets the Maximum Rise Time for standard mode.*/
    dp->CON &= (con & ~0x6) | I2C_CON_SPEED_STD;
  }
  else if (clock_speed <= 400000) {
#if 0
    /* Configure clock_div in fast mode.*/
    osalDbgAssert((duty == FAST_DUTY_CYCLE_2) || (duty == FAST_DUTY_CYCLE_16_9),
                "i2c_lld_set_clock(), #4",
                "Invalid fast mode duty cycle");

    if (duty == FAST_DUTY_CYCLE_2) {
      /* Fast mode clock_div calculate: Tlow/Thigh = 2/1.*/
    }
    else if (duty == FAST_DUTY_CYCLE_16_9) {
      /* Fast mode clock_div calculate: Tlow/Thigh = 16/9.*/
    }
#endif
    /* Sets the Maximum Rise Time for fast mode.*/
    dp->CON &= (con & ~0x6) | I2C_CON_SPEED_FAST;
  }
}

static void i2c_lld_enable_restart(I2CDriver *i2cp, bool enable){
	HS_I2C_Type *dp = i2cp->i2c;

	if (enable)
		dp->CON |= I2C_CON_RESTART_EN;
	else
		dp->CON &= ~I2C_CON_RESTART_EN;
}

/**
 * @brief   Set operation mode of I2C hardware.
 *
 * @param[in] i2cp      pointer to the @p I2CDriver object
 *
 * @notapi
 */
static void i2c_lld_set_opmode(I2CDriver *i2cp) {
  HS_I2C_Type *dp = i2cp->i2c;
  i2copmode_t opmode = i2cp->config->op_mode;

  dp->CON1 = I2C_CON1_TIMER_MODE_DISABLE;

  switch (opmode) {
  case OPMODE_I2C_MASTER:
    dp->CON = I2C_CON_MASTER | I2C_CON_SLAVE_DISABLE | I2C_CON_RESTART_EN;
    break;
  case OPMODE_I2C_SLAVE:
	  dp->CON = I2C_CON_RESTART_EN;
    break;
  case OPMODE_SMBUS_DEVICE:
    dp->CON = I2C_CON_10BITADDR_SLAVE | I2C_CON_RESTART_EN;
    break;
  case OPMODE_SMBUS_HOST:
    dp->CON = I2C_CON_MASTER | I2C_CON_SLAVE_DISABLE | I2C_CON_10BITADDR_MASTER | I2C_CON_RESTART_EN;
    break;
  }
}

/**
 * @brief   Common ISR code to clear interrupt cause of error status
 *
 * @param[in] i2cp      pointer to the @p I2CDriver object
 *
 * @notapi
 */
static uint32_t i2c_lld_read_interrupts_and_clear_errors(I2CDriver *i2cp) {
  HS_I2C_Type *dp = i2cp->i2c;
  uint32_t dummy, stat = dp->INTR_STAT;

#if defined(I2C_USE_DEBUG_INFO)
  i2cp->hw_status.intr_stat = stat & 0x00000FFFUL;
  i2cp->hw_status.raw_intr_stat = dp->RAW_INTR_STAT & 0x0FFFUL;
  i2cp->hw_status.tx_abrt_source = dp->TX_ABRT_SOURCE & 0xFFFFUL;
#endif
  /* Do not use the IC_CLR_INTR register to clear interrupts. */
  if (stat & I2C_INTR_RX_UNDER) {
    i2cp->errors |= I2CD_OVERRUN;
    dummy = dp->CLR_RX_UNDER;
  }
  if (stat & I2C_INTR_RX_OVER) {
    i2cp->errors |= I2CD_OVERRUN;
    dummy = dp->CLR_RX_OVER;
  }
  if (stat & I2C_INTR_TX_OVER) {
    i2cp->errors |= I2CD_OVERRUN;
    dummy = dp->CLR_TX_OVER;
  }
  if (stat & I2C_INTR_TX_ABRT) {
    /*
     * The IC_TX_ABRT_SOURCE register is cleared whenever
     * the IC_CLR_TX_ABRT is read.  Preserve it beforehand.
     */
    dummy = dp->TX_ABRT_SOURCE;
    if (dummy & I2C_TX_ARB_LOST)
      i2cp->errors |= I2CD_ARBITRATION_LOST;
    if (dummy & I2CD_TX_ABRT_ALL_NOACK)
      i2cp->errors |= I2CD_ACK_FAILURE;
    if (dummy & 0xfe0)
      i2cp->errors |= I2CD_BUS_ERROR; /* it is triggered by wrong sw behaviors */
    dummy = dp->CLR_TX_ABRT;
  }

  /** Misc **
  if (stat & I2C_INTR_ACTIVITY)
    dummy = dp->CLR_ACTIVITY;
  if (stat & I2C_INTR_START_DET)
    dummy = dp->CLR_START_DET;
  if (stat & I2C_INTR_GEN_CALL)
    dummy = dp->CLR_GEN_CALL;
  */

  (void)dummy;
  return stat;
}

/**
 * @brief   Common ISR code to read received data from RX_FIFO.
 *
 * @param[in] i2cp      pointer to the @p I2CDriver object
 *
 * @notapi
 */
static void i2c_lld_read_rx_fifo(I2CDriver *i2cp) {
  HS_I2C_Type *dp = i2cp->i2c;
  uint32_t rx_valid;
  
  if (i2cp->config->op_mode == OPMODE_I2C_MASTER)
  	dp->INTR_MASK = I2C_INTR_MASTER_RX_MASK;
  else
	dp->INTR_MASK = I2C_INTR_SLAVE_RX_MASK;
  
  if (i2cp->rxbuf && i2cp->rxbytes > 0) {
	rx_valid = i2cp->rxbytes;
    if (s_stop_flag) {
		if (rx_valid > RX_FIFO_DEPTH) {
			i2cp->errors |= I2CD_OVERRUN;
			rx_valid = RX_FIFO_DEPTH;
		}
	}
    else if (rx_valid >= RX_FULL_THRESHOLD_LEVEL)
    {
		rx_valid = dp->RXFLR;
		if (rx_valid > RX_LIMIT)
			rx_valid = RX_LIMIT;
    }

    for (; i2cp->rxbytes > 0 && rx_valid > 0; i2cp->rxbytes--, rx_valid--)
      *(i2cp->rxbuf)++ = dp->DATA_CMD;
  }
}

/**
 * @brief   Common ISR code to write data to TX_FIFO.
 *
 * @param[in] i2cp      pointer to the @p I2CDriver object
 *
 * @notapi
 */
static void i2c_lld_write_tx_fifo(I2CDriver *i2cp) {
  HS_I2C_Type *dp = i2cp->i2c;
  uint32_t tx_limit;

  if (i2cp->txbuf && i2cp->txbytes > 0) {
	  // First data transfer byte number between tx_buffer and tx_fifo
	  // should be as much as possible to avoid tx underflow.
	  if (!i2cp->busy) {
		i2cp->busy = true;
		tx_limit = i2cp->tx_fifo_depth;
	  }
	  else {
		tx_limit = i2cp->tx_fifo_depth - dp->TXFLR;
		if (tx_limit > TX_LIMIT)
			tx_limit = TX_LIMIT;
	  }
	  while (i2cp->txbytes > 0 && tx_limit > 0) {
		dp->DATA_CMD = *(i2cp->txbuf)++;
		tx_limit--;
		i2cp->txbytes--;
	  }
  }

  if (i2cp->txbytes == 0) { /* no more bytes to be written, prepare for rx start */
	if (i2cp->config->op_mode == OPMODE_I2C_MASTER)
	  dp->INTR_MASK = I2C_INTR_MASTER_RX_MASK;
	else
	  dp->INTR_MASK = I2C_INTR_SLAVE_RX_MASK;

	if (i2cp->rxbuf && i2cp->rxbytes > 0) {
		dp->CON1 = config_rx(i2cp->config->op_mode == OPMODE_I2C_MASTER);
	}
  }
}

/*===========================================================================*/
/* Driver interrupt handlers.                                                */
/*===========================================================================*/
/**
 * @brief   Common IRQ handler.
 *
 * @param[in] i2cp       communication channel associated to the I2C
 */
static void i2c_serve_interrupt(I2CDriver *i2cp) {
  HS_I2C_Type *dp = i2cp->i2c;
  uint32_t stat, dummy;
  (void)dummy;

  if ((0 == i2cp->i2c->ENABLE) || (0 == (i2cp->i2c->RAW_INTR_STAT & ~I2C_INTR_ACTIVITY)))
    return;

  stat = i2c_lld_read_interrupts_and_clear_errors(i2cp);

  /** Anytime i2cp->errors is set, the contents of the tx/rx
   *  buffers are flushed.  Make sure to skip them.
   */
  if (i2cp->errors) {
      i2c_lld_abort_operation(i2cp);
      goto end_transfer;
  }

  if (stat & I2C_INTR_RX_FULL) { // master or slave role, auto cleared by hardware
	  i2c_lld_read_rx_fifo(i2cp);
  }

  if (stat & I2C_INTR_RX_DONE) { // slave role
    dummy = dp->CLR_RX_DONE;
  }

  // Master's TX_EMPTY interrupt is equivalent to Slave's RD_REQ interrupt,
  // there's no need to distinguish between the two.
  if (stat & I2C_INTR_TX_EMPTY || // master role, auto cleared by hardware
	  stat & I2C_INTR_RD_REQ) {   // slave role
    // fill data first
	  i2c_lld_write_tx_fifo(i2cp);
	// then, clear interrupt and release clock stretching.
	// Needed only in slave role.
    dummy = dp->CLR_RD_REQ;
  }

  if (stat & I2C_INTR_STOP_DET) {
	dummy = dp->CLR_STOP_DET;
    s_stop_flag = true;
#if (HS_I2C_HAS_SELF_DMA == TRUE)
	if (!i2cp->config->use_self_dma)
#endif
	  i2c_lld_read_rx_fifo(i2cp);
	s_stop_flag = false;

	if (i2cp->config->con_mode == CONMODE_I2C_AUTO_WR) {
	  i2cp->i2c->CON1 |=  I2C_CON1_TIMER_MODE_DISABLE;
	  i2cp->i2c->CON1 &= ~I2C_CON1_TIMER_MODE_DISABLE;
	}

  	if (
#if (HS_I2C_HAS_SELF_DMA == TRUE)
		!i2cp->config->use_self_dma &&
#endif
		i2cp->txbuf && i2cp->txbytes > 0)
	  i2cp->errors |= I2CD_OVERRUN; // TX FIFO underflow

  	goto end_transfer;
  }
  
  return;

end_transfer:
  i2cp->busy = false;
  if (i2cp->i2c_callback)
	i2cp->i2c_callback(i2cp);
  _i2c_wakeup_isr(i2cp);
}

#if HS_I2C_USE_I2C0 || defined(__DOXYGEN__)
/**
 * @brief   I2C0 interrupt handler.
 *
 * @notapi
 */

OSAL_IRQ_HANDLER(I2C0_IRQHandler)
{
  OSAL_IRQ_PROLOGUE();
  i2c_serve_interrupt(&I2CD0);
  OSAL_IRQ_EPILOGUE();  
}
#endif /* HS_I2C_USE_I2C0 */

/*===========================================================================*/
/* Driver exported functions.                                                */
/*===========================================================================*/

/**
 * @brief   Low level I2C driver initialization.
 *
 * @notapi
 */
void i2c_lld_init(void) {

#if HS_I2C_USE_I2C0
  i2cObjectInit(&I2CD0);
  I2CD0.thread = NULL;
  I2CD0.i2c    = HS_I2C0;

  cpmEnableI2C0();
  osalDbgAssert(HS_I2C0->COMP_TYPE == 0x44570140, "wrong IP type");
  I2CD0.tx_fifo_depth = ((HS_I2C0->COMP_PARAM_1 >> 16) & 0xff) + 1;
  I2CD0.rx_fifo_depth = ((HS_I2C0->COMP_PARAM_1 >> 8) & 0xff) + 1;

  HS_I2C0->INTR_MASK = 0;
#endif /* HS_I2C_USE_I2C0 */
}

/**
 * @brief   Configures and activates the I2C peripheral.
 *
 * @param[in] i2cp      pointer to the @p I2CDriver object
 *
 * @notapi
 */
void i2c_lld_start(I2CDriver *i2cp) {
  HS_I2C_Type *dp = i2cp->i2c;

  /* Enables the peripheral.*/
  dp->INTR_MASK = 0; // by hgz, disable peripheral interrupt before enable nvicEnableVector()

#if HS_I2C_USE_I2C0
  if (&I2CD0 == i2cp) {
    cpmResetI2C0();
    cpmEnableI2C0();
    nvicEnableVector(I2C0_IRQn, ANDES_PRIORITY_MASK(HS_I2C_I2C0_IRQ_PRIORITY));
  }
#endif /* HS_I2C_USE_I2C0 */

  /* Configures the peripheral.*/

  /* Disable the adapter */
  dp->ENABLE = 0;

  /* Setup I2C parameters.*/
  i2c_lld_set_opmode(i2cp);
  i2c_lld_set_clock(i2cp);

  /* Configure Tx/Rx FIFO threshold levels */
  dp->TX_TL = TX_EMPTY_THRESHOLD_LEVEL;
  dp->RX_TL = RX_FULL_THRESHOLD_LEVEL - 1;

#if (HS_I2C_HAS_SELF_DMA == TRUE)
  dp->SELF_DMA_CON2 = 0;
#endif
  
  /* i2c enter SLAVE mode */
  if (i2cp->config->op_mode == OPMODE_I2C_SLAVE) 
    /* setting I2C slave addr */
    dp->SAR = i2cp->config->slave_addr; //I2C_SLAVE_DEFAULT_ADDR;

  /* disable interrupts */
  dp->INTR_MASK = 0;

  if (&I2CD0 == i2cp) {
    cpmDisableI2C0();
  }
}

/**
 * @brief   Deactivates the I2C peripheral.
 *
 * @param[in] i2cp      pointer to the @p I2CDriver object
 *
 * @notapi
 */
void i2c_lld_stop(I2CDriver *i2cp) {

  if (i2cp->state != I2C_STOP) {
    /* Resets the peripheral.*/

    /* I2C disable.*/
    i2c_lld_abort_operation(i2cp);

    /* Disables the peripheral.*/
#if HS_I2C_USE_I2C0
    if (&I2CD0 == i2cp) {
      nvicDisableVector(I2C0_IRQn);
      cpmDisableI2C0();
    }
#endif /* HS_I2C_USE_I2C0 */
  }

  i2cp->i2c->CON1 = I2C_CON1_TIMER_MODE_DISABLE;
}

/**
 * @brief   Transmits data via the I2C bus as master.
 *
 * @param[in] i2cp      pointer to the @p I2CDriver object
 * @param[in] addr      slave device address
 * @param[in] txbuf     pointer to the transmit buffer, must be 4-byte aligned when DMA is used.
 * @param[in] txbytes   number of bytes to be transmitted
 * @param[out] rxbuf    pointer to the receive buffer, must be 4-byte aligned when DMA is used.
 * @param[in] rxbytes   number of bytes to be received
 * @param[in] timeout   the number of ticks before the operation timeouts,
 *                      the following special values are allowed:
 *                      - @a TIME_INFINITE no timeout.
 *                      .
 * @return              The operation status.
 * @retval MSG_OK       if the function succeeded.
 * @retval MSG_RESET    if one or more I2C errors occurred, the errors can
 *                      be retrieved using @p i2cGetErrors().
 * @retval MSG_TIMEOUT  if a timeout occurred before operation end. <b>After a
 *                      timeout the driver must be stopped and restarted
 *                      because the bus is in an uncertain state</b>.
 *
 * @notapi
 */
msg_t i2c_lld_master_transmit_timeout(I2CDriver *i2cp, i2caddr_t addr,
										const uint8_t *txbuf, size_t txbytes,
										const uint8_t *rxbuf, size_t rxbytes,
										systime_t timeout) {

  HS_I2C_Type *dp = i2cp->i2c;
  systime_t start, end;
  volatile msg_t ret;
  uint32_t intr_mask;
  uint32_t con1 = 0;

  bool tx_valid = txbuf && txbytes>0;
  bool rx_valid = rxbuf && rxbytes>0;

#if (HS_I2C_HAS_SELF_DMA == TRUE)
  if (i2cp->config->use_self_dma)
	  nds32_dcache_flush();
#endif

  I2C_ENBALE_CLOCK(i2cp);

  /* Releases the lock from high level driver.*/
  osalSysUnlock();

  /* Calculating the time window for the timeout on the busy bus condition.*/
  start = osalOsGetSystemTimeX();
  end = start + OSAL_MS2ST(HS_I2C_BUSY_TIMEOUT);

  /* Waits until BUSY flag is reset and the STOP from the previous operation
     is completed, alternatively for a timeout condition.*/
  while (true) {
    osalSysLock();

    if ((dp->STATUS & I2C_STATUS_ACTIVITY) == 0) break;
    //if ((dp->RAW_INTR_STAT & I2C_INTR_STOP_DET) == 0) break;

    if (!osalOsIsTimeWithinX(osalOsGetSystemTimeX(), start, end)) {
      I2C_DISBALE_CLOCK(i2cp);
      return MSG_TIMEOUT;
    }

    osalSysUnlock();
  }

  dp->INTR_MASK = 0;
  dp->ENABLE = 0;

  // Note: always tx before rx as long as tx is valid.
  i2cp->errors = 0;
  i2cp->busy = false;
#if defined(I2C_USE_DEBUG_INFO)
  i2cp->hw_status.intr_stat = 0;
  i2cp->hw_status.raw_intr_stat = 0;
  i2cp->hw_status.tx_abrt_source = 0;
#endif

  i2cp->txbuf = (uint8_t*)txbuf;
  i2cp->txbytes = txbytes;
  i2cp->rxbuf = (uint8_t*)rxbuf;
  i2cp->rxbytes = rxbytes;

  if (tx_valid){
	intr_mask = i2cp->config->op_mode == OPMODE_I2C_MASTER ?
			I2C_INTR_MASTER_MASK : I2C_INTR_SLAVE_MASK;
  }
  else if (rx_valid){
	intr_mask = i2cp->config->op_mode == OPMODE_I2C_MASTER ?
			I2C_INTR_MASTER_RX_MASK : I2C_INTR_SLAVE_RX_MASK;
  }
  else {
	  I2C_DISBALE_CLOCK(i2cp);
	  i2cp->errors |= I2CD_ERROR_NULLPTR;
	  return MSG_RESET;
  }

  // SelfDMA requires that RESTART must be ON/OFF as really required,
  // otherwise it will not work correctly.
  i2c_lld_enable_restart(i2cp, tx_valid && rx_valid);

  /* set the slave (target) address, needed only in master role */
  dp->TAR = addr;
  /* set I2C slave addr, needed only in slave role */
  dp->SAR = i2cp->config->slave_addr;

  i2cp->i2c_callback = i2cp->config->i2c_callback;
  dp->CON1 = I2C_CON1_TIMER_MODE_DISABLE; // reset CON1

#if (HS_I2C_HAS_SELF_DMA == TRUE)
  if (i2cp->config->use_self_dma) {
	  dp->SELF_DMA_CON2 = I2C_SELF_DMA_CON2_EN | I2C_SELF_DMA_CON2_RX_ADDR_INC_OVER_BURSTS;

	  if (tx_valid) {
		dp->SELF_DMA_ADDR = (uint32_t)txbuf;
		dp->SELF_DMA_CON1 = I2C_SELF_DMA_CON1_TX_EN |
							(((txbytes-1) & 0x0FFFUL) << I2C_SELF_DMA_CON1_TX_LEN_POS); // txbytes must be reduced by 1.
	  }

	  if (rx_valid){
		dp->SELF_DMA_ADDR = (uint32_t)rxbuf;
		dp->SELF_DMA_CON1 = I2C_SELF_DMA_CON1_RX_EN;
	  }

	  intr_mask = I2C_INTR_SELF_DMA_MASK;
	  // when SelfDma is enabled, the first transfer is determined by the tx_en bit of the first item
	  // in FIFO SELF_DMA_CON1, no matter what IC_CON1's Tx/Rx bit is. IC_CON1's content takes effect
	  // only when corresponding item in FIFO SELF_DMA_CON1 kicks in.
	  con1 = config_rx((i2cp->config->op_mode == OPMODE_I2C_MASTER) && rx_valid);
  }
  else
#endif
	  // CON1's RX_ENABLE is a master role functionality, and it must be disabled when in slave role.
	  con1 = config_rx((i2cp->config->op_mode == OPMODE_I2C_MASTER) && !tx_valid);

  dp->CON1 = con1;

  /* Enable interrupts */
  dp->INTR_MASK = intr_mask;

  if (i2cp->config->con_mode == CONMODE_I2C_NO_AUTO_WR)
    /* Enable the adapter */
    dp->ENABLE = 1;

  /* Waits for the operation completion or a timeout.*/
  ret = osalThreadSuspendTimeoutS(&i2cp->thread, timeout);
#if (HS_I2C_HAS_SELF_DMA == TRUE)
  if (i2cp->config->use_self_dma) {
	  while (!(dp->SELF_DMA_CON2 & I2C_SELF_DMA_CON2_DMA_IDLE_FLAG))
		  ; // Risk: DMA may have not started at all.
  }
#endif

  dp->INTR_MASK = 0;
  dp->CON1 = I2C_CON1_TIMER_MODE_DISABLE;
  dp->ENABLE = 0;
  // while ( IC_ENABLE_STATUS.IC_EN == 1);
#if (HS_I2C_HAS_SELF_DMA == TRUE)
  dp->SELF_DMA_CON2 = 0;
#endif

  i2c_lld_enable_restart(i2cp, true);
  I2C_DISBALE_CLOCK(i2cp);

#if (HS_I2C_HAS_SELF_DMA == TRUE)
  if (i2cp->config->use_self_dma)
	  nds32_dcache_flush();
#endif

  if (i2cp->errors)
  	return MSG_RESET;

  return ret;
}

/**
 * @brief   Receives data via the I2C bus as master.
 *
 * @param[in] i2cp      pointer to the @p I2CDriver object
 * @param[in] addr      slave device address
 * @param[out] rxbuf    pointer to the receive buffer
 * @param[in] rxbytes   number of bytes to be received
 * @param[in] timeout   the number of ticks before the operation timeouts,
 *                      the following special values are allowed:
 *                      - @a TIME_INFINITE no timeout.
 *                      .
 * @return              The operation status.
 * @retval MSG_OK       if the function succeeded.
 * @retval MSG_RESET    if one or more I2C errors occurred, the errors can
 *                      be retrieved using @p i2cGetErrors().
 * @retval MSG_TIMEOUT  if a timeout occurred before operation end. <b>After a
 *                      timeout the driver must be stopped and restarted
 *                      because the bus is in an uncertain state</b>.
 *
 * @notapi
 */
msg_t i2c_lld_master_receive_timeout(I2CDriver *i2cp, i2caddr_t addr,
		const uint8_t *rxbuf, size_t rxbytes, systime_t timeout) {

	return i2c_lld_master_transmit_timeout(i2cp, addr,
		  NULL, 0, rxbuf, rxbytes, timeout);
}

//----------- Slave role ------------------------
msg_t i2c_lld_slave_receive_timeout(I2CDriver *i2cp, const uint8_t *rxbuf,
				    size_t rxbytes, systime_t timeout) {

	return i2c_lld_master_receive_timeout(i2cp, i2cp->config->slave_addr, rxbuf, rxbytes, timeout);
}

msg_t i2c_lld_slave_transmit_timeout(I2CDriver *i2cp, const uint8_t *txbuf,
				     size_t txbytes, systime_t timeout){

	return i2c_lld_master_transmit_timeout(i2cp, i2cp->config->slave_addr, txbuf, txbytes, NULL, 0, timeout);
}

msg_t i2c_lld_slave_transfer_timeout(I2CDriver     *i2cp,
									 i2caddr_t      addr,
									 const uint8_t *txbuf,
									 size_t         txbytes,
									 const uint8_t *rxbuf,
									 size_t         rxbytes,
									 systime_t      timeout)
{
	(void)i2cp;
	(void)addr;
	(void)txbuf;
	(void)txbytes;
	(void)rxbuf;
	(void)rxbytes;
	(void)timeout;


	// slave-rx: can NACK by setting SLV_DATA_NACK_ONLY to 1.
	// slave-tx: can't NACK, will auto-clock-stretching when RD_REQ interrupt occurs, clear RD_REQ to start TX.
	//           What about clear RD_REQ without write to TX_FIFO? Will it generate a STOP?

	return MSG_OK;
}

#endif /* HAL_USE_I2C */

/** @} */
