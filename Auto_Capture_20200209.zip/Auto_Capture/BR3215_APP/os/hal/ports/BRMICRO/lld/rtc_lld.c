/*
    ChibiOS/RT - Copyright (C) 2006-2013 Giovanni Di Sirio
                 Copyright (C) 2019 BRMICRO Technologies
                 

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/
/*
   Concepts and parts of this file have been contributed by Uladzimir Pylinsky
   aka barthess.
 */

/**
 * @file    br32xx/rtc_lld.c
 * @brief   BR32xx RTC subsystem low level driver header.
 *
 * @addtogroup RTC
 * @{
 */

#include <time.h>
#include "hal.h"

#if (HAL_USE_RTC && HS_HAS_RTC_STM32) || defined(__DOXYGEN__)

/*===========================================================================*/
/* Driver local definitions.                                                 */
/*===========================================================================*/

/* Hardware bug:
   Almost all control bits in CR require time to take effect, including those
   having no waiting flags. So a delay must be added after write to the CR
   register.
   Moreover, ISR.ALARMAWF/ALARMBWF is wrongly tied up to high and hence there's
   no use to wait for it and a delay must also be added.
*/
#define DELAY_COUNT    (50*1000)
#define delay_counter(count)\
do {\
  volatile uint32_t i = count; \
  while (i--); \
} while (0)

/*===========================================================================*/
/* Driver exported variables.                                                */
/*===========================================================================*/

/**
 * @brief RTC driver identifier.
 */
RTCDriver RTCD0;

/*===========================================================================*/
/* Driver local variables and types.                                         */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local functions.                                                   */
/*===========================================================================*/

#define rtc_lld_enable_irq()\
nvicEnableVector(RTC_IRQn, ANDES_PRIORITY_MASK(HS_RTC_IRQ_PRIORITY))

#define rtc_lld_disable_irq()\
nvicDisableVector(RTC_IRQn)

/**
 * @brief   Disable RTC register write protection.
 * @note    RTC register write protection:
 *          After power-on reset, all the RTC registers except for
 *          RTC_ISR[13:8](TAMP1F, TSOVF, TSF, WUTF, ALRBF, ALRAF),
 *          RTC_TAFCR, and RTC_BKPxR, are write-protected.
 *          The protection mechanism is not affected by system reset.
 */
#define rtc_lld_write_enable()\
do {\
	rtc_lld_disable_irq();\
  rtcp->id_rtc->WPR = 0x00;\
  rtcp->id_rtc->WPR = 0xCA;\
  rtcp->id_rtc->WPR = 0x53;\
} while (0)

/**
 * @brief   Enable RTC register write protection.
 */
#define rtc_lld_write_disable()\
do {\
  rtcp->id_rtc->WPR = 0xFF;\
  rtc_lld_enable_irq();\
} while (0)

/**
 * Bypass calendar shadow registers (RTC_SSRx, RTC_TRx and RTC_DRx).
 */
#define rtc_lld_bypass_shadow_reg() \
do {\
  rtcp->id_rtc->CR |= RTC_CR_BYPSHAD;\
  delay_counter(DELAY_COUNT);\
} while (0)

/**
 * Unbypass calendar shadow registers (RTC_SSRx, RTC_TRx and RTC_DRx).
 */
#define rtc_lld_unbypass_shadow_reg() \
do {\
  rtcp->id_rtc->CR &= ~RTC_CR_BYPSHAD;\
  delay_counter(DELAY_COUNT);\
} while (0)

/**
 * @brief   Wait for calendar shadow registers (RTC_SSRx, RTC_TRx and RTC_DRx)
 *          to be synchronized to calendar counters (the synchronization
 *          occurs once every two RTCCLK cycles).
 * @details This function must be invoked before trying to read calendar
 *          registers (RTC_SSRx, RTC_TRx and RTC_DRx) when not in bypass
 *          shadow register mode.
 *
 * @notapi
 */
#define rtc_lld_wait_shadow_reg_sync() \
do {\
  while ((rtcp->id_rtc->ISR & RTC_ISR_RSF) == 0);\
} while (0)

/**
 * @brief   Clear calendar shadow registers sync flag ISR.RSF.
 *
 * @note    In case the software makes read accesses to the calendar in a time
 *          interval smaller than 2 RTCCLK periods: RSF must be cleared by
 *          software after the first calendar read, and then the software must
 *          wait until RSF is set before reading again the RTC_SSR, RTC_TR and
 *          RTC_DR registers.
 *
 *          After waking up from low power mode (Stop or Standby), RSF must be
 *          cleared by software. The software must then wait until it is set
 *          again before reading the RTC_SSR, RTC_TR and RTC_DR registers.
 *
 *          The RSF bit must be cleared after wakeup and not before entering
 *          low power mode
 *
 *          TODO: call this function after wakeup.
 */
#define rtc_lld_clear_shadow_reg_sync_flag() \
do {\
  rtcp->id_rtc->ISR &= ~RTC_ISR_RSF;\
} while (0)


/**
 * @brief   Enter into initialization mode.
 *
 * @note    Initialization mode used to program time and date register
 *          (RTC_TR and RTC_DR), and prescaler register (RTC_PRER).
 *          Counters are stopped and start counting from the new value
 *          when INIT is reset.
 * @notapi
 */
#define rtc_lld_enter_init() \
do {                                                \
  rtcp->id_rtc->ISR |= RTC_ISR_INIT;                \
  while ((rtcp->id_rtc->ISR & RTC_ISR_INITF) == 0); \
} while (0)

/**
 * @brief   Exit from initialization mode.
 *
 * @notapi
 */
#define rtc_lld_exit_init() \
do {\
	rtcp->id_rtc->ISR &= ~RTC_ISR_INIT;\
	while ((rtcp->id_rtc->ISR & RTC_ISR_INITF) != 0); \
	delay_counter(DELAY_COUNT);\
} while (0)

/**
 * @brief   Enter into alarm A/B write mode.
 * @param x   A: alarm A.
 *            B: alarm B.
 */
#define rtc_lld_disable_alarm_x(x)\
do {\
  rtcp->id_rtc->CR &= ~(RTC_CR_ALR##x##E | RTC_CR_ALR##x##IE);\
  delay_counter(DELAY_COUNT);\
  while ((rtcp->id_rtc->ISR & RTC_ISR_ALR##x##WF) == 0); \
} while (0)

/**
 * @brief   Exit from alarm A/B write mode.
 * @param x   A: alarm A.
 *            B: alarm B.
 */
#define rtc_lld_enable_alarm_x(x)\
do {\
  rtcp->id_rtc->CR |= (RTC_CR_ALR##x##E | RTC_CR_ALR##x##IE);\
  delay_counter(DELAY_COUNT);\
} while (0)

/**
 * @brief   Poll alarm A/B interrupt flag.
 * @param x   A: alarm A.
 *            B: alarm B.
 */
#define rtc_lld_poll_alarm_flag_x(x)\
	(rtcp->id_rtc->ISR & RTC_ISR_ALR##x##F)

/**
 * @brief   Clear alarm A/B interrupt flag.
 * @param x   A: alarm A.
 *            B: alarm B.
 */
#define rtc_lld_clear_alarm_flag_x(x)\
	(rtcp->id_rtc->ISR &= ~RTC_ISR_ALR##x##F)

/**
 * @brief   Enter into wakeup timer write mode.
 */
#define rtc_lld_disable_wakeup()\
do {                                                \
  rtcp->id_rtc->CR &= ~(RTC_CR_WUTE | RTC_CR_WUTIE);\
  while ((rtcp->id_rtc->ISR & RTC_ISR_WUTWF) == 0); \
} while (0)

/**
 * @brief   Exit from wakeup timer write mode.
 */
#define rtc_lld_enable_wakeup()\
do {                                                \
  rtcp->id_rtc->CR |= (RTC_CR_WUTE | RTC_CR_WUTIE);\
  while ((rtcp->id_rtc->ISR & RTC_ISR_WUTWF) != 0); \
} while (0)

/**
 * @brief   Clear timestamp flag.
 * @note    It is recommended to check and then clear TSOVF only after
 *          clearing the TSF bit. Otherwise, an overflow might not be
 *          noticed if a timestamp event occurs immediately before the
 *          TSF bit is cleared.
 */
#define rtc_lld_clear_timestamp_flag()\
do {\
	rtcp->id_rtc->ISR &= ~RTC_ISR_TSF;\
	if (rtcp->id_rtc->ISR & RTC_ISR_TSOVF)\
		rtcp->id_rtc->ISR &= ~RTC_ISR_TSOVF;\
} while (0)

/*===========================================================================*/
/* Driver interrupt handlers.                                                */
/*===========================================================================*/
/**
 * @brief   RTC interrupt handler.
 *
 * @isr
 */
OSAL_IRQ_HANDLER(RTC_IRQHandler)
{
  uint32_t flags;

  OSAL_IRQ_PROLOGUE();

  RTCDriver *rtcp = &RTCD0;
  /* This wait works only when AHB1 bus was previously powered off by any
     reason (standby, reset, etc). In other cases it does nothing.*/
  rtc_lld_wait_shadow_reg_sync();

  /* Mask of all enabled and pending sources.*/
  flags = rtcp->id_rtc->ISR;

  if (flags & RTC_ISR_ALRAF) {
  	rtcp->id_rtc->ISR &= ~RTC_ISR_ALRAF;

		/* not compatible with STM32F4 */
		/* disable Alarm A and Alarm B to clear wakeup signal to PMU */
		rtc_lld_write_enable();
		rtcp->id_rtc->CR &= ~RTC_CR_ALRAE;
		//delay_counter(DELAY_COUNT);
		rtc_lld_write_disable();

		if (rtcp->callback)
			rtcp->callback(rtcp, RTC_EVENT_ALARMA);
  }

  if (flags & RTC_ISR_ALRBF) {
  	rtcp->id_rtc->ISR &= ~RTC_ISR_ALRBF;

  	/* not compatible with STM32F4 */
		/* disable Alarm A and Alarm B to clear wakeup signal to PMU */
		rtc_lld_write_enable();
		rtcp->id_rtc->CR &= ~RTC_CR_ALRBE;
		//delay_counter(DELAY_COUNT);
		rtc_lld_write_disable();

		if (rtcp->callback)
			rtcp->callback(rtcp, RTC_EVENT_ALARMB);
  }

  if (flags & RTC_ISR_WUTF) {
  	rtcp->id_rtc->ISR &= ~RTC_ISR_WUTF;

		if (rtcp->callback)
			rtcp->callback(rtcp, RTC_EVENT_AUTO_WAKEUP);
  }

  /** Hardware Bug:
   *    Clearing RTC_ISR_TSF also clears RTC_TSTR, RTC_TSDR and RTC_TSSSR.
   *  Walk around:
   *    Read time stamp registers ahead of clearing RTC_ISR_TSF.
   */
  if (flags & RTC_ISR_TSF) {
		if (rtcp->callback)
			rtcp->callback(rtcp, RTC_EVENT_TIMSTAMP);
		rtcp->id_rtc->ISR &= ~RTC_ISR_TSF;

		if (rtcp->id_rtc->ISR & RTC_ISR_TSOVF) {
			if (rtcp->callback)
				rtcp->callback(rtcp, RTC_EVENT_TIMSTAMP_OVERFLOW);
			rtcp->id_rtc->ISR &= ~RTC_ISR_TSOVF;
		}
  }

  OSAL_IRQ_EPILOGUE();
}

/*===========================================================================*/
/* Driver exported functions.                                                */
/*===========================================================================*/

/**
 * @brief   Enable access to registers.
 *
 * @api
 */
void rtc_lld_init(void){

	RTCDriver *rtcp = &RTCD0;

	rtcObjectInit(rtcp);
	rtcp->id_rtc = HS_RTC;
  rtcp->callback = NULL;

  // disable interruption and enable write
  rtc_lld_write_enable();

  /* If calendar not init yet (RTC_ISR_INITS status is kept in deep sleep) */
  if (!(rtcp->id_rtc->ISR & RTC_ISR_INITS))
  {
  	rtc_lld_enter_init();

    /* Asynchronous part of preloader. Set it to maximum value. */
    uint32_t prediv_a = 0x7F;
    uint32_t prediv_s = (((cpm_get_clock(HS_RTC_CLK) / (prediv_a + 1)) - 1) & 0x7FFF);

    /* To generate a 1 Hz clock for the calendar counter, program first
     * the synchronous prescaler factor in RTC_PRER register, and then
     * program the asynchronous prescaler factor. Even if only one of
     * the two fields needs to be changed, 2 separate write accesses
     * must be performed to the TC_PRER register.
     */
    rtcp->id_rtc->PRER  = prediv_s;
    rtcp->id_rtc->PRER |= (prediv_a << 16);
  }

  //rtc_lld_bypass_shadow_reg();
  rtc_lld_unbypass_shadow_reg();
	rtc_lld_exit_init(); // move out of ISR.INITS block in case ISR.INITF is set unexpectedly.

  //rtc_lld_disable_wakeup(); // FIXME: often stuck here.

	// disable write and enable interruption.
	rtc_lld_write_disable();
}


/**
 * @brief   Convert RTCDateTime to RTC register format.
 *
 * @param[in] dt      pointer to @p RTCDateTime structure
 * @param[in] regdt   pointer to a @p RegRTCTime structure
 * @param[in] h12     true to use AM/FM hour format; false to use 24 hour format.
 *
 * @note     Generally, there's need to use AM/FM hour format since it is just
 *           a presentation problem.
 *
 * @notapi
 */
static void rtc_reg_datetime_encode(const RTCDateTime *dt, RegRTCTime *regdt, bool h12) {
		regdt->h12 = h12;
  	regdt->dst = dt->dstflag;

	  regdt->tv_date = 0;
	  regdt->tv_time = 0;

	  regdt->tv_date |= (((dt->year+RTC_BASE_YEAR-RTC_REG_BASE_YEAR) / 10) << RTC_DR_YT_OFFSET) & RTC_DR_YT;
	  regdt->tv_date |= (((dt->year+RTC_BASE_YEAR-RTC_REG_BASE_YEAR) % 10) << RTC_DR_YU_OFFSET) & RTC_DR_YU;

	  regdt->tv_date |= ((dt->month / 10) << RTC_DR_MT_OFFSET) & RTC_DR_MT;
	  regdt->tv_date |= ((dt->month % 10) << RTC_DR_MU_OFFSET) & RTC_DR_MU;

	  regdt->tv_date |= ((dt->day / 10) << RTC_DR_DT_OFFSET) & RTC_DR_DT;
	  regdt->tv_date |= ((dt->day % 10) << RTC_DR_DU_OFFSET) & RTC_DR_DU;

	  regdt->tv_date |= (dt->dayofweek << RTC_DR_WDU_OFFSET) & RTC_DR_WDU;

		uint32_t s = dt->millisecond / 1000;
		uint32_t h = s / 3600, m = (s % 3600) / 60;
		s = (s % 3600) % 60;
	  if (h12 && h >= 12) {
				h -= 12;
				regdt->tv_time |= RTC_TR_PM;
		}
		else
				regdt->tv_time &= ~RTC_TR_PM;

	  regdt->tv_time |= ((h / 10) << RTC_TR_HT_OFFSET) & RTC_TR_HT;
	  regdt->tv_time |= ((h % 10) << RTC_TR_HU_OFFSET) & RTC_TR_HU;

	  regdt->tv_time |= ((m / 10) << RTC_TR_MNT_OFFSET) & RTC_TR_MNT;
	  regdt->tv_time |= ((m % 10) << RTC_TR_MNU_OFFSET) & RTC_TR_MNU;

	  regdt->tv_time |= ((s / 10) << RTC_TR_ST_OFFSET) & RTC_TR_ST;
	  regdt->tv_time |= ((s % 10) << RTC_TR_SU_OFFSET) & RTC_TR_SU;

	  regdt->tv_msec = dt->millisecond % 1000;
}

static void rtc_reg_datetime_decode(const RegRTCTime *regdt, RTCDateTime *dt) {
	  uint32_t tens = 0, unit = 0;
		dt->dstflag = regdt->dst;

		tens = (regdt->tv_date & RTC_DR_YT) >> RTC_DR_YT_OFFSET;
	  unit = (regdt->tv_date & RTC_DR_YU) >> RTC_DR_YU_OFFSET;
	  dt->year = tens*10 + unit + RTC_REG_BASE_YEAR - RTC_BASE_YEAR;

	  tens = (regdt->tv_date & RTC_DR_MT) >> RTC_DR_MT_OFFSET;
	  unit = (regdt->tv_date & RTC_DR_MU) >> RTC_DR_MU_OFFSET;
	  dt->month = tens*10 + unit;

	  tens = (regdt->tv_date & RTC_DR_DT) >> RTC_DR_DT_OFFSET;
	  unit = (regdt->tv_date & RTC_DR_DU) >> RTC_DR_DU_OFFSET;
	  dt->day = tens*10 + unit;

	  dt->dayofweek = (regdt->tv_date & RTC_DR_WDU) >> RTC_DR_WDU_OFFSET;

		uint32_t hour = 0, minute = 0, second = 0;
	  tens = (regdt->tv_time & RTC_TR_HT) >> RTC_TR_HT_OFFSET;
	  unit = (regdt->tv_time & RTC_TR_HU) >> RTC_TR_HU_OFFSET;
	  hour = tens*10 + unit;
		if (regdt->h12 && (regdt->tv_time & RTC_TR_PM))
			hour += 12;

		tens = (regdt->tv_time & RTC_TR_MNT) >> RTC_TR_MNT_OFFSET;
	  unit = (regdt->tv_time & RTC_TR_MNU) >> RTC_TR_MNU_OFFSET;
	  minute = tens*10 + unit;

		tens = (regdt->tv_time & RTC_TR_ST) >> RTC_TR_ST_OFFSET;
	  unit = (regdt->tv_time & RTC_TR_SU) >> RTC_TR_SU_OFFSET;
	  second = tens*10 + unit;

	  dt->millisecond = (hour*3600 + minute*60 + second) * 1000 + regdt->tv_msec;
}

/**
 * @brief   Set current time.
 * @note    Fractional part will be silently ignored.
 *
 * @param[in] rtcp      pointer to RTC driver structure
 * @param[in] timespec  pointer to a @p RTCDateTime structure
 *
 * @api
 */
void rtc_lld_set_time(RTCDriver *rtcp, const RTCDateTime *datetimespec) {

  /* BR32xx HW RTC calendar range: [RTC_REG_BASE_YEAR, RTC_REG_BASE_YEAR+100) */
  osalDbgCheck((datetimespec->year+RTC_BASE_YEAR >= RTC_REG_BASE_YEAR) &&
  		         (datetimespec->year+RTC_BASE_YEAR <  RTC_REG_BASE_YEAR+100));

  RegRTCTime regdt;
  rtc_reg_datetime_encode(datetimespec, &regdt, false); // no need to use AM/FM format

  rtc_lld_write_enable();
  rtc_lld_enter_init();

  if (regdt.h12)
  	rtcp->id_rtc->CR |= RTC_CR_FMT;
  else
  	rtcp->id_rtc->CR &= ~RTC_CR_FMT;

  if (regdt.dst)
  	rtcp->id_rtc->CR |= RTC_CR_DST;
  else
  	rtcp->id_rtc->CR &= ~RTC_CR_DST;

  rtcp->id_rtc->TR = regdt.tv_time;
  rtcp->id_rtc->DR = regdt.tv_date;

  rtc_lld_exit_init();
  rtc_lld_write_disable();
}

#define Get_REG_DateTime(rtcp, regdt, dr, tr, ssr) do {\
		uint32_t prer = rtcp->id_rtc->PRER;\
		regdt.tv_msec =\
		      (1000 * ((prer & 0x7FFF) - rtcp->id_rtc->ssr)) /\
		      ((prer & 0x7FFF) + 1);\
		regdt.tv_time = rtcp->id_rtc->tr;\
		regdt.tv_date = rtcp->id_rtc->dr;\
		regdt.h12 = rtcp->id_rtc->CR & RTC_CR_FMT;\
		regdt.dst = rtcp->id_rtc->CR & RTC_CR_DST;\
	} while (0)

/**
 * @brief   Get current time.
 *
 * @param[in] rtcp      pointer to RTC driver structure
 * @param[out] timespec pointer to a @p RTCDateTime structure
 *
 * @api
 */
void rtc_lld_get_time(RTCDriver *rtcp, RTCDateTime *datetimespec) {
  (void)rtcp;
  RegRTCTime regdt;

	rtc_lld_wait_shadow_reg_sync();

#if defined(CONFIG_CH_DBG)
  /* flash to service interrupt */
  osalSysUnlock(); __NOP(); osalSysLock();
#endif
  Get_REG_DateTime(rtcp, regdt, DR, TR, SSR);

  rtc_lld_clear_shadow_reg_sync_flag();
  rtc_reg_datetime_decode(&regdt, datetimespec);
}

/**
 * @brief     Set alarm time.
 *
 * @note      Default value after BKP domain reset for both comparators is 0.
 * @note      Function does not performs any checks of alarm time validity.
 *
 * @param[in] rtcp      	Pointer to RTC driver structure.
 * @param[in] alarmx  		Alarm identifier: 0=A, 1=B.
 * @param[in] alarmspec 	Pointer to a @p RTCAlarm structure.
 *
 * @api
 */
void rtc_lld_set_alarm(RTCDriver *rtcp,
                       rtcalarm_t alarmx,
                       const RTCAlarm *alarmspec) {

	if (alarmspec == NULL)
		return;

	rtc_lld_write_enable();

  if (alarmx == 0){
  	rtc_lld_disable_alarm_x(A);
		rtc_lld_clear_alarm_flag_x(A);

  	do {
			rtcp->id_rtc->ALRMAR = alarmspec->tv_datetime;
			rtcp->id_rtc->ALRMASSR = 0; // disable subseconds
		} while (rtcp->id_rtc->ALRMAR != alarmspec->tv_datetime);

		rtc_lld_enable_alarm_x(A);
  }
  else if (alarmx == 1){
  	rtc_lld_disable_alarm_x(B);
		rtc_lld_clear_alarm_flag_x(B);

  	do {
			rtcp->id_rtc->ALRMBR = alarmspec->tv_datetime;
			rtcp->id_rtc->ALRMBSSR = 0; // disable subseconds
		} while (rtcp->id_rtc->ALRMBR != alarmspec->tv_datetime);

		rtc_lld_enable_alarm_x(B);
  }

  rtc_lld_write_disable();
}

/**
 * @brief   Get alarm time.
 *
 * @param[in] rtcp       pointer to RTC driver structure
 * @param[in] alarmx     alarm identifier: 0=A, 1=B.
 * @param[out] alarmspec pointer to a @p RTCAlarm structure
 *
 * @api
 */
void rtc_lld_get_alarm(RTCDriver *rtcp,
                       rtcalarm_t alarmx,
                       RTCAlarm *alarmspec) {

	if (alarmx == 0)
    alarmspec->tv_datetime = rtcp->id_rtc->ALRMAR;
  else if (alarmx == 1)
    alarmspec->tv_datetime = rtcp->id_rtc->ALRMBR;
}

/**
 * @brief   Disable alarm A/B.
 *
 * @param[in] rtcp       pointer to RTC driver structure
 * @param[in] alarmx     alarm identifier: 0=A, 1=B.
 *
 * @api
 */
void rtc_lld_disable_alarm(RTCDriver *rtcp,
                       rtcalarm_t alarmx) {

	rtc_lld_write_enable();

  if (alarmx == 0) {
  	rtc_lld_disable_alarm_x(A);
		rtc_lld_clear_alarm_flag_x(A);
  }
  else if (alarmx == 1) {
  	rtc_lld_disable_alarm_x(B);
		rtc_lld_clear_alarm_flag_x(B);
  }

	rtc_lld_write_disable();
}

bool rtc_lld_poll_alarm_flag(RTCDriver *rtcp, rtcalarm_t alarm) {
	if (alarm == 0)
		return rtc_lld_poll_alarm_flag_x(A);
	else if (alarm == 1)
		return rtc_lld_poll_alarm_flag_x(B);
	else
		return 0;
}

void rtc_lld_clear_alarm_flag(RTCDriver *rtcp, rtcalarm_t alarm) {
	if (alarm == 0)
		rtc_lld_clear_alarm_flag_x(A);
	else if (alarm == 1)
		rtc_lld_clear_alarm_flag_x(B);
}

/**
 * @brief   Configure RTC time stamp triggered via pin AF1 or AF2.
 * @param rtcp      Pointer to @p RTCDriver struct.
 * @param afx       Timestamp trigger pin selection:
 *                  1 = AF1 pin to be set,
 *                  2 = AF2 pin to be set.
 * @param posedge   true = posedge, false = negedge.
 * @param intr_en   true = enable interrupt, false = disable interrupt.
 */
void rtc_lld_set_timestamp(RTCDriver *rtcp, int afx, bool posedge, bool intr_en)
{
	rtc_lld_write_enable();

	// Disable time stamp.
	rtcp->id_rtc->CR &= ~(RTC_CR_TSE | RTC_CR_TSIE | RTC_CR_TSEDGE);
	delay_counter(DELAY_COUNT);
	rtc_lld_clear_timestamp_flag();

	if (afx == 1)
		rtcp->id_rtc->TAFCR &= ~RTC_TAFCR_TSINSEL; // AF1 time stamp
	else if (afx == 2)
		rtcp->id_rtc->TAFCR |= RTC_TAFCR_TSINSEL;  // AF2 time stamp
	else
		goto local_exit;

	if (!posedge)
		rtcp->id_rtc->CR |= RTC_CR_TSEDGE;

	if (intr_en)
		rtcp->id_rtc->CR |= RTC_CR_TSIE;

	// Enable time stamp.
	rtcp->id_rtc->CR |= RTC_CR_TSE;

local_exit:
	rtc_lld_write_disable();
}

/**
 * @brief   Get current timestamp.
 *
 * @param[in] rtcp      pointer to RTC driver structure
 * @param[out] timespec pointer to a @p RTCDateTime structure
 *
 * @api
 */
void rtc_lld_get_timestamp(RTCDriver *rtcp, RTCDateTime *datetimespec) {
  (void)rtcp;
  RegRTCTime regdt;

  Get_REG_DateTime(rtcp, regdt, TSDR, TSTR, TSSSR);

  rtc_reg_datetime_decode(&regdt, datetimespec);
}

/**
 * @brief   Disable timestamp.
 *
 * @param[in] rtcp      pointer to RTC driver structure
 *
 * @api
 */
void rtc_lld_disable_timestamp(RTCDriver *rtcp) {

	rtc_lld_write_enable();

	rtcp->id_rtc->CR &= ~(RTC_CR_TSE | RTC_CR_TSIE | RTC_CR_TSEDGE);
	delay_counter(DELAY_COUNT);
	rtc_lld_clear_timestamp_flag();

	rtc_lld_write_disable();
}

/**
 * @brief     Sets time of periodic wakeup.
 *
 * @note      Default value after BKP domain reset is 0x0000FFFF
 *
 * @param[in] rtcp       pointer to RTC driver structure
 * @param[in] wakeupspec pointer to a @p RTCWakeup structure
 *
 * @api
 */
 void rtc_lld_set_periodic_wakeup(RTCDriver *rtcp, RTCWakeup *wakeupspec) {

	/* ((WUTR == 0) && (WUCKSEL == 3)) is forbidden combination. */
  osalDbgCheck((wakeupspec != NULL) &&
  		(wakeupspec->wakeup & 0x7FFFFU) != 0x30000U);

  if ((wakeupspec == NULL) ||
			(wakeupspec->wakeup & 0x7FFFFU) == 0x30000U)
		return;

  rtc_lld_write_enable();
  rtc_lld_disable_wakeup();

	rtcp->id_rtc->WUTR = wakeupspec->wakeup & 0xFFFFU;
	rtcp->id_rtc->CR  &= ~RTC_CR_WUCKSEL;
	rtcp->id_rtc->CR  |= (wakeupspec->wakeup >> 16) & 0x7U;

	rtc_lld_enable_wakeup();
	rtc_lld_write_disable();
}

/**
 * @brief     Gets time of periodic wakeup.
 *
 * @note      Default value after BKP domain reset is 0x0000FFFF
 *
 * @param[in] rtcp        pointer to RTC driver structure
 * @param[out] wakeupspec pointer to a @p RTCWakeup structure
 *
 * @api
 */
void rtc_lld_get_periodic_wakeup(RTCDriver *rtcp, RTCWakeup *wakeupspec){

	wakeupspec->wakeup  = 0;
  wakeupspec->wakeup |= rtcp->id_rtc->WUTR;
  wakeupspec->wakeup |= (((uint32_t)rtcp->id_rtc->CR) & 0x7) << 16;
}

/**
 * @brief     Disable periodic wakeup.
 *
 * @param[in] rtcp       pointer to RTC driver structure
 *
 * @api
 */
 void rtc_lld_disable_periodic_wakeup(RTCDriver *rtcp) {

  rtc_lld_write_enable();
  rtc_lld_disable_wakeup();
	rtc_lld_write_disable();
}

/**
 * @brief   Select RTC alarm output and polarity.
 *
 * @param[in] rtcp       pointer to RTC driver structure
 * @param[in] sel        Selection of output signal:
 *                       0: Output disabled
 *                       1: Alarm A output
 *                       2: Alarm B output
 *                       3: Wakeup output
 * @param[in] pol        Ouput polarity:
 *                       0: High represents alarm/wakeup asserted.
 *                       1: Low  represents alarm/wakeup asserted.
 */
void rtc_lld_set_alarm_output(RTCDriver *rtcp, int sel, bool pol) {

	rtc_lld_write_enable();
	rtcp->id_rtc->CR &= ~(RTC_CR_OSEL | RTC_CR_POL);
	rtcp->id_rtc->CR |= ((sel & RTC_CR_OSEL) | (pol & RTC_CR_POL));
	rtc_lld_write_disable();
}

/**
 * @brief   RTC smooth digital calibration.
 *
 * @param rtcp   Pointer to a @p RTCDriver structure.
 * @param calr   The value to be write to RTC_CALR register.
 */
void rtc_lld_smooth_cal(RTCDriver *rtcp, uint32_t calr) {

	rtc_lld_write_enable();
	rtcp->id_rtc->CALR = calr;
	rtc_lld_write_disable();
}

/**
 * @brief   RTC Re-calibration on-the-fly.
 *
 * @param rtcp   Pointer to a @p RTCDriver structure.
 * @param calr   The value to be write to RTC_CALR register.
 */
void rtc_lld_recal_on_the_fly(RTCDriver *rtcp, uint32_t calr) {

	while (rtcp->id_rtc->ISR & RTC_ISR_RECALPF);

	rtc_lld_write_enable();
	rtcp->id_rtc->CALR = calr;
	rtc_lld_write_disable();
	//while (rtcp->id_rtc->ISR & RTC_ISR_RECALPF == 0);
}

/**
 * @brief   Select RTC calibration output.
 *
 * @param[in] rtcp       pointer to RTC driver structure
 * @param[in] sel        Selection of output signal:
 *                       0: Output disabled
 *                       1: Calibration output is 512 Hz
 *                       2: Calibration output is 1 Hz
 */
void rtc_lld_set_cal_output(RTCDriver *rtcp, int sel) {

	rtc_lld_write_enable();

	rtcp->id_rtc->CR &= ~(RTC_CR_COE | RTC_CR_COSEL);
	if (sel == 1)
		rtcp->id_rtc->CR |= RTC_CR_COE;
	else if (sel == 2)
		rtcp->id_rtc->CR |= RTC_CR_COE | RTC_CR_COSEL;

	rtc_lld_write_disable();
}

#endif /* HAL_USE_RTC */

/** @} */
