/*
    ChibiOS/RT - Copyright (C) 2006-2013 Giovanni Di Sirio
                 Copyright (C) 2019 BRMICRO Technologies
                 

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    br32xx/spi_lld.c
 * @brief   SPI Driver subsystem low level driver source template.
 *
 * @addtogroup SPI
 * @{
 */

#include "hal.h"
#include "chprintf.h"
#include "string.h"

#if HAL_USE_SPI || defined(__DOXYGEN__)

/*===========================================================================*/
/* Driver local definitions.                                                 */
/*===========================================================================*/

/*===========================================================================*/
/* Driver exported variables.                                                */
/*===========================================================================*/
/**
 * @brief   SPI1 driver identifier.
 */
#if HS_SPI_USE_SPI0 || defined(__DOXYGEN__)
SPIDriver SPID0;
#endif

/**
 * @brief   SPI1 driver identifier.
 */
#if HS_SPI_USE_SPI1 || defined(__DOXYGEN__)
SPIDriver SPID1;
#endif

/*===========================================================================*/
/* Driver local variables and types.                                         */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local functions.                                                   */
/*===========================================================================*/
/**
 * @brief   RX DMA common service routine.
 *
 * @param[in] spip     pointer to the @p SPIDriver object
 * @param[in] error     error status
 */
#if (SPI_USE_DMA == TRUE) && (HS_HAS_DMA == TRUE)
static void spi_lld_serve_rx_end_irq(SPIDriver *spip, hs_dma_cb_para_t *var)
{
  /* DMA errors handling.*/
  if (DMA_TRANS_OPER_OK != var->oper_res) {
    osalSysHalt("DMA failure");
    return;
  }

	if (spip->dmarx) dmaStreamDisable(spip->dmarx);
	spip->rxstate = SPI_RX_COMPLETE;
	if(spip->rxstate != SPI_RX_ACTIVE && spip->txstate != SPI_TX_ACTIVE)
	{
		osalSysUnlockFromISR();
		_spi_isr_code(spip);
		osalSysLockFromISR();
	}
}
#endif
/**
 * @brief   TX DMA common service routine.
 *
 * @param[in] uartp     pointer to the @p UARTDriver object
 * @param[in] error     error status
 */
#if (SPI_USE_DMA == TRUE) && (HS_HAS_DMA == TRUE)
static void spi_lld_serve_tx_end_irq(SPIDriver *spip, hs_dma_cb_para_t *var)
{
  /* DMA errors handling.*/
  if (DMA_TRANS_OPER_OK != var->oper_res) {
    osalSysHalt("DMA failure");
    return;
  }

	if (spip->dmatx) dmaStreamDisable(spip->dmatx);
	spip->txstate = SPI_TX_COMPLETE;

	if(spip->rxstate != SPI_RX_ACTIVE && spip->txstate != SPI_TX_ACTIVE)
	{
		osalSysUnlockFromISR();
		_spi_isr_code(spip);
		osalSysLockFromISR();
	}
}
#endif
/**
 * @brief   spi common service routine.
 *
 * @param[in] spi     pointer to the @p SPIDriver object
 */
__ONCHIP_CODE__ static void serve_spi_irq(SPIDriver *spip)
{
	HS_SPI_Type *s 					= spip->spi;
	volatile uint8_t i 				= 0;
	volatile uint8_t rxbytes 		= (s->STAT>>8)&0xff;

	spislavecallback_par_t *paras 	= spip->config->paras;

	if((paras->txdata_len - paras->txdata_num) < SPI0_TRIGGRE_BYTENUM(3))
	{
		s->CTR &= SPI0_SET_TRIGGER_MASK;
	}
	if(spip->config->role == SPI_MASTER_MODE)
	{
		if(s->STAT & SPI0_TX_EMPTY_STATUS_MASK)
		{
			s->STAT &= ~SPI0_RX_TRIGGER_STATUS_MASK;

			if(paras->txdata_num < paras->txdata_len)
			{
				s->WDATA = *(paras->txdata++);
				paras->txdata_num++;
			}
			else paras->txdata -= paras->txdata_len;
		}
		if(s->STAT & SPI0_RX_TRIGGER_STATUS_MASK)
		{
			while(rxbytes--)
			{
				*(paras->rxdata++) = s->RDATA;
				if(++paras->rxdata_num >= paras->rxdata_len)
				{
					paras->rxdata -= paras->rxdata_len;
					_spi_wakeup_isr(spip);
					return;
				}
			}
		}
	}
	else
	{
		if (s->STAT & SPI0_RX_TRIGGER_STATUS_MASK)
		{
			while(rxbytes--)
			{
				if (paras->dev_status == PRO_INT_STATUS)
				{
					if (!paras->cmd_num)
					{
						paras->op_dir = s->RDATA;
						if ((paras->op_dir == SPI_SLAVE_READ_DIR) || (paras->op_dir == SPI_SLAVE_WRITE_DIR))
						{
							paras->dev_status = PRO_CMD_STATUS;
							paras->cmd_num++;
						}
						continue;
					}
				}
				if (paras->dev_status == PRO_CMD_STATUS)
				{
					if (paras->cmd_num == 1)
					{
						paras->cmd = s->RDATA;
						//spip->config->slave_cb(spip, paras);
						paras->cmd_num++;
						continue;
					}
					i = s->RDATA;
					if (++paras->cmd_num == SPI_SLAVE_PROTOCOL_CMD_NUM)
					{
						if (paras->op_dir == SPI_SLAVE_READ_DIR)
						{
							spip->config->slave_cb(spip, paras);
							paras->dev_status = PRO_READ_STATUS;
						}
						else if (paras->op_dir == SPI_SLAVE_WRITE_DIR)
							paras->dev_status = PRO_WRITE_STATUS;
						continue;
					}
				}
				if (paras->dev_status == PRO_WRITE_STATUS)
				{
					if (paras->rxdata_num < SPI_SLAVE_PROTOCOL_DATA_NUM)
					{
						*(paras->rxdata++) = s->RDATA;
						if(++paras->rxdata_num == SPI_SLAVE_PROTOCOL_DATA_NUM)
						{
							paras->rxdata -=  SPI_SLAVE_PROTOCOL_DATA_NUM;
							paras->dev_status = PRO_WRITE_CMP_STATUS;
							spip->config->slave_cb(spip, paras);
							break;
						}
					}
				}
			}
		}
		if (s->STAT & SPI0_TX_EMPTY_STATUS_MASK)
		{
			s->STAT &= ~SPI0_RX_TRIGGER_STATUS_MASK;
			if (paras->dev_status == PRO_READ_STATUS)
			{
				spi_lld_unselect(&SPID0);
				s->CTR |= (SPI0_RESET | SPI0_TX_FIFO_RESET | SPI0_RX_FIFO_RESET);
				__NOP();
				s->CTR &= (~SPI0_RESET & ~SPI0_TX_FIFO_RESET & ~SPI0_RX_FIFO_RESET);

				s->CTR &= ~SPI0_RX_FIFO_ENABLE;
				s->CTR |=  SPI0_TX_FIFO_ENABLE;

				for (i=0; i<SPI_SLAVE_PROTOCOL_DATA_NUM; i++)
				{
					//s->WDATA = *(paras->txdata + paras->cmd_num - 1);
					//paras->txdata++;
					s->WDATA = *paras->txdata++;
					paras->dev_status = PRO_READ_CMP_STATUS;
				}
				paras->txdata -= (SPI_SLAVE_PROTOCOL_DATA_NUM);
				#if 0
				if (++paras->data_num == SPI_SLAVE_PROTOCOL_DATA_NUM)
				{
					paras->dev_status = PRO_READ_CMP_STATUS;
					paras->data -=  SPI_SLAVE_PROTOCOL_DATA_NUM;
					spip->config->slave_cb(spip, paras);
					s->CTR &= ~SPI0_TX_FIFO_ENABLE;
					s->CTR |=  SPI0_RX_FIFO_ENABLE;
				}
				#endif
			}
		}
	}
	return;
}

/**
 * @brief   SPI initialization.
 * @details This function must be invoked with interrupts disabled.
 *
 * @param[in] spip     pointer to the @p SPIDriver object
 */

static void spi_start(SPIDriver *spip)
{
    HS_SPI_Type *s = spip->spi;
	const SPIConfig *config = spip->config;
    uint32_t clk_div;
	uint32_t ctrl = 0;

	clk_div = (spip->clock >> 1) / config->speed - 1;
	if (clk_div < 3)
		clk_div = 3;
    ctrl = s->CTR;
	ctrl = ctrl | SPI0_RESET | SPI0_TX_FIFO_RESET | SPI0_RX_FIFO_RESET;

	/* reset spi hardware, tx fifo and rx fifo */
	s->CTR = ctrl;

	/* clear rx fifo and tx fifo reset*/
	ctrl = ctrl & (~SPI0_TX_FIFO_RESET & ~SPI0_RX_FIFO_RESET);
	s->CTR = ctrl;

	ctrl = (ctrl & 0xffff0000) | clk_div;
	s->CTR = ctrl;

	ctrl |= SPI0_MSB;
    
    if (spip->config->role == SPI_MASTER_MODE)
      ctrl |= SPI0_MASTER;
    else
      ctrl &= ~SPI0_MASTER; //slave mode
    
	s->CTR = ctrl;

	if (spip->config->role == SPI_MASTER_MODE)
	  ctrl |= SPI0_TX_FIFO_ENABLE | SPI0_RX_FIFO_ENABLE;
	else {
	  ctrl |= SPI0_RX_FIFO_ENABLE;
	  ctrl &= ~SPI0_TX_FIFO_ENABLE;
	}
	s->CTR = ctrl;

	ctrl = (ctrl & 0xFFDDFFFF) | ((config->mode & 0x01) << 17) | (((config->mode >> 1) & 0x01) << 21);
	s->CTR = ctrl;
	#if (SPI_USE_DMA == TRUE) && (HS_HAS_DMA == TRUE)
		if (spip->config->role == SPI_MASTER_MODE)
		{
			s->DMACR = 0x03;
			s->DMATDLR = (32 >> 1);  							//tx data level = fifo_depth / 2
			s->DMARDLR = 0;          							//rx data level
		}
		else if (spip->config->role == SPI_SLAVE_MODE) 			/* slave interrupt */
		{
			s->CTR &= SPI0_SET_TRIGGER_MASK;
			s->CTR |= SPI0_SET_TRIGGER_LEVEL(0); 				/* rx 1 byte trigger */
			//s->CTR |= (1ul<<22);
			s->STAT |= SPI0_SET_TX_EMPTY_INT | SPI0_SET_RX_TRIGGER_INT;
			s->STAT &= ~SPI0_INT_EN_MASK;
			s->CTR &= ~SPI0_RESET;

			if (&SPID0 == spip)
			nvicEnableVector(SPI0_IRQn, ANDES_PRIORITY_MASK(HS_SPI_SPI0_IRQ_PRIORITY));
			else
			nvicEnableVector(SPI1_IRQn, ANDES_PRIORITY_MASK(HS_SPI_SPI1_IRQ_PRIORITY));
		}
	#else
		s->CTR &= SPI0_SET_TRIGGER_MASK;
		s->CTR |= SPI0_SET_TRIGGER_LEVEL(0);
		s->STAT |= SPI0_SET_TX_EMPTY_INT | SPI0_SET_RX_TRIGGER_INT;
		s->STAT &= ~SPI0_INT_EN_MASK;
		s->CTR &= ~SPI0_RESET;

		if (&SPID0 == spip)
		nvicEnableVector(SPI0_IRQn, ANDES_PRIORITY_MASK(HS_SPI_SPI0_IRQ_PRIORITY));
		else
		nvicEnableVector(SPI1_IRQn, ANDES_PRIORITY_MASK(HS_SPI_SPI1_IRQ_PRIORITY));
	#endif
}

/**
 * @brief   SPI de-initialization.
 * @details This function must be invoked with interrupts disabled.
 *
 * @param[in] spip     pointer to the @p SPIDriver object
 */
static void spi_stop(SPIDriver *spip)
{
	HS_SPI_Type *s = spip->spi;
	s->CTR = s->CTR | SPI0_RESET;

	#if (SPI_USE_DMA == TRUE) && (HS_HAS_DMA == TRUE)
		if (spip->config->role == SPI_SLAVE_MODE)
		{
			if (&SPID0 == spip)nvicDisableVector(SPI0_IRQn);
			else nvicDisableVector(SPI1_IRQn);
		}
	#else
		if (&SPID0 == spip)nvicDisableVector(SPI0_IRQn);
		else nvicDisableVector(SPI1_IRQn);
	#endif
}

/*===========================================================================*/
/* Driver interrupt handlers.                                                */
/*===========================================================================*/

#if HS_SPI_USE_SPI0
/**
 * @brief   SPI0 IRQ handler.
 *
 * @isr
 */
OSAL_IRQ_HANDLER(SPI0_IRQHandler) {

  OSAL_IRQ_PROLOGUE();

  serve_spi_irq(&SPID0);

  OSAL_IRQ_EPILOGUE();
}
#endif /* HS_SPI_USE_SPI1 */

#if HS_SPI_USE_SPI1
/**
 * @brief   SPI1 IRQ handler.
 *
 * @isr
 */
OSAL_IRQ_HANDLER(SPI1_IRQHandler) {

  OSAL_IRQ_PROLOGUE();

  serve_spi_irq(&SPID1);

  OSAL_IRQ_EPILOGUE();
}
#endif /* HS_SPI_USE_SPI1 */

/*===========================================================================*/
/* Driver exported functions.                                                */
/*===========================================================================*/

/**
 * @brief   Low level SPI driver initialization.
 *
 * @notapi
 */
void spi_lld_init(void) {
	/* Driver initialization.*/
#if HS_SPI_USE_SPI0
  spiObjectInit(&SPID0);
	SPID0.spi = HS_SPI0;
#if (SPI_USE_DMA == TRUE) && (HS_HAS_DMA == TRUE)
	SPID0.dmarx = NULL;
	SPID0.dmatx = NULL;
#endif
#endif /* HS_SPI_USE_SPI0 */

	/* Driver initialization.*/
#if HS_SPI_USE_SPI1
  spiObjectInit(&SPID1);
	SPID1.spi = HS_SPI1;
#if (SPI_USE_DMA == TRUE) && (HS_HAS_DMA == TRUE)
	SPID1.dmarx = NULL;
	SPID1.dmatx = NULL;
#endif
#endif /* HS_SPI_USE_SPI1 */
}

/**
* @brief   Configures and activates the SPI peripheral.
*
* @param[in] spip      pointer to the @p SPIDriver object
*
* @notapi
*/
void spi_lld_start(SPIDriver *spip)
{
	#if (SPI_USE_DMA == TRUE) && (HS_HAS_DMA == TRUE)
	hs_dma_config_t sconfig;
	#endif
	if (spip->state == SPI_STOP)
	{
		/* Enables the peripheral.*/
		#if HS_SPI_USE_SPI0
			if (&SPID0 == spip)
			{
				#if (SPI_USE_DMA == TRUE) && (HS_HAS_DMA == TRUE)
					if (spip->config->role == SPI_MASTER_MODE)
					{
						/* save a DMA channel if TX only */
						if (0 == (spip->config->mode & 0x80)) {
							spip->dmarx = dmaStreamAllocate(HS_SPI_SPI0_DMA_PRIORITY,
							(hs_dmaisr_t)spi_lld_serve_rx_end_irq,
							(void *)spip);
							osalDbgAssert(spip->dmarx != NULL, "stream already allocated");
						}
						spip->dmatx = dmaStreamAllocate(HS_SPI_SPI0_DMA_PRIORITY,
						(hs_dmaisr_t)spi_lld_serve_tx_end_irq,
						(void *)spip);
						osalDbgAssert(spip->dmatx != NULL, "stream already allocated");
					}
				#else
					nvicEnableVector(SPI0_IRQn, ANDES_PRIORITY_MASK(HS_SPI_SPI0_IRQ_PRIORITY));
				#endif
				cpmEnableSPI0();
				SPID0.clock = cpm_get_clock(HS_SPI0_CLK);
			}
		#endif /* HS_SPI_USE_SPI0 */

		/* Enables the peripheral.*/
		#if HS_SPI_USE_SPI1
			if (&SPID1 == spip)
			{
				#if (SPI_USE_DMA == TRUE) && (HS_HAS_DMA == TRUE)
					if (spip->config->role == SPI_MASTER_MODE)
					{
						/* save a DMA channel if TX only */
						if (0 == (spip->config->mode & 0x80)) {
							spip->dmarx = dmaStreamAllocate(HS_SPI_SPI1_DMA_PRIORITY,
							(hs_dmaisr_t)spi_lld_serve_rx_end_irq,
							(void *)spip);
							osalDbgAssert(spip->dmarx != NULL, "stream already allocated");
						}
						spip->dmatx = dmaStreamAllocate(HS_SPI_SPI1_DMA_PRIORITY,
						(hs_dmaisr_t)spi_lld_serve_tx_end_irq,
						(void *)spip);
						osalDbgAssert(spip->dmatx != NULL, "stream already allocated");
					}
				#else
					nvicEnableVector(SPI1_IRQn, ANDES_PRIORITY_MASK(HS_SPI_SPI1_IRQ_PRIORITY));
				#endif
				cpmEnableSPI1();
				SPID1.clock = cpm_get_clock(HS_SPI1_CLK);
			}
		#endif /* HS_SPI_USE_SPI1 */
		#if (SPI_USE_DMA == TRUE) && (HS_HAS_DMA == TRUE)
			if (spip->config->role == SPI_MASTER_MODE)
			{
				/* Static DMA setup */
				sconfig.direction = DMA_DEV_TO_MEM;
				sconfig.src_addr_width = DMA_SLAVE_BUSWIDTH_8BITS;
				sconfig.dst_addr_width = DMA_SLAVE_BUSWIDTH_8BITS;
				sconfig.src_burst = DMA_BURST_LEN_1UNITS;
				sconfig.dst_burst = DMA_BURST_LEN_1UNITS;
				sconfig.dev_flow_ctrl = FALSE;

				#if HS_SPI_USE_SPI0
					if (&SPID0 == spip)
					{
						sconfig.slave_id = SPI0_RX_DMA_ID;
					}
				#endif
				#if HS_SPI_USE_SPI1
					if (&SPID1 == spip)
					{
						sconfig.slave_id = SPI1_RX_DMA_ID;
					}
				#endif
				sconfig.lli_en = 0;
				dmaStreamSetMode(spip->dmarx, &sconfig);

				sconfig.direction = DMA_MEM_TO_DEV;
				sconfig.src_addr_width = DMA_SLAVE_BUSWIDTH_8BITS;
				sconfig.dst_addr_width = DMA_SLAVE_BUSWIDTH_8BITS;
				sconfig.src_burst = DMA_BURST_LEN_1UNITS;
				sconfig.dst_burst = DMA_BURST_LEN_1UNITS;
				sconfig.dev_flow_ctrl = FALSE;
				#if HS_SPI_USE_SPI0
					if (&SPID0 == spip)
					{
						sconfig.slave_id = SPI0_TX_DMA_ID;
					}
				#endif
				#if HS_SPI_USE_SPI1
					if (&SPID1 == spip)
					{
						sconfig.slave_id = SPI1_TX_DMA_ID;
					}
				#endif
				sconfig.lli_en = 0;
				dmaStreamSetMode(spip->dmatx, &sconfig);
			}
		#endif
		}

	/* Configures the peripheral.*/
	spip->rxstate = SPI_RX_IDLE;
	spip->txstate = SPI_TX_IDLE;
	spi_start(spip);
}

/**
* @brief   Deactivates the SPI peripheral.
*
* @param[in] spip      pointer to the @p SPIDriver object
*
* @notapi
*/
void spi_lld_stop(SPIDriver *spip)
{
	if (spip->state == SPI_READY)
	{
		spi_stop(spip);
		#if (SPI_USE_DMA == TRUE) && (HS_HAS_DMA == TRUE)
			if (spip->config->role == SPI_MASTER_MODE)
			{
				/* Resets the peripheral.*/
				dmaStreamRelease(spip->dmarx);
				dmaStreamRelease(spip->dmatx);
			}
		#endif
		/* Disables the peripheral.*/
		#if HS_SPI_USE_SPI0
			if (&SPID0 == spip)cpmDisableSPI0();
		#endif /* HS_SPI_USE_SPI1 */
		#if HS_SPI_USE_SPI1
			if (&SPID1 == spip)cpmDisableSPI1();
		#endif /* HS_SPI_USE_SPI1 */
	}
}

/**
* @brief   Asserts the slave select signal and prepares for transfers.
*
* @param[in] spip      pointer to the @p SPIDriver object
*
* @notapi
*/
void spi_lld_select(SPIDriver *spip) {
  const SPIConfig *config = spip->config;

#if HS_SPI_USE_SPI0
  if (&SPID0 == spip) {
    if (config->cs_pin != 0) {
      palClearPin(config->cs_pin);
    }
  }
#endif /* HS_SPI_USE_SPI1 */
#if HS_SPI_USE_SPI1
  if (&SPID1 == spip) {
    if (config->cs_pin != 0) {
      palClearPin(config->cs_pin);
    }
  }
#endif /* HS_SPI_USE_SPI1 */
}

/**
* @brief   Deasserts the slave select signal.
* @details The previously selected peripheral is unselected.
*
* @param[in] spip      pointer to the @p SPIDriver object
*
* @notapi
*/
void spi_lld_unselect(SPIDriver *spip) {
  const SPIConfig *config = spip->config;

#if HS_SPI_USE_SPI0
  if (&SPID0 == spip) {
    if (config->cs_pin != 0) {
      palSetPin(config->cs_pin);
    }
  }
#endif /* HS_SPI_USE_SPI1 */
#if HS_SPI_USE_SPI1
  if (&SPID1 == spip) {
    if (config->cs_pin != 0) {
      palSetPin(config->cs_pin);
    }
  }
#endif /* HS_SPI_USE_SPI1 */
}

#if (SPI_USE_DMA == TRUE) && (HS_HAS_DMA == TRUE)

static void spi_xfer(SPIDriver *spip, size_t n, const void *txbuf, void *rxbuf)
{
	HS_SPI_Type *s = spip->spi;

	#if defined(__nds32__)
	nds32_dcache_flush();
	#endif

	s->CTR &= ~SPI0_RESET;
	s->CTR |= (SPI0_RX_FIFO_ENABLE | SPI0_TX_FIFO_ENABLE);
	if (spip->dmarx) dmaStreamStart(spip->dmarx, &s->RDATA, rxbuf, n);
	if (spip->dmatx) dmaStreamStart(spip->dmatx, txbuf, &s->WDATA, n);
}

#else

static void spi_isr_stream_start(SPIDriver *spip, size_t n, void *buf)
{
	HS_SPI_Type *s = spip->spi;
	volatile spislavecallback_par_t *paras = spip->config->paras;
	systime_t tmo = OSAL_MS2ST(n);

	paras->txdata_len = paras->rxdata_len = n;
	paras->txdata_num = paras->rxdata_num = 0;
	paras->txdata = paras->rxdata = buf;
	memcpy(paras->txdata,buf,n);

	s->WDATA = *paras->txdata++;
	paras->txdata_num++;

	(void)osalThreadSuspendTimeoutS(&spip->thread, tmo);

	paras->rxdata_num = paras->txdata_num = 0;
	memcpy(buf,paras->rxdata,n);
}

/**
* @brief   Exchange data over the SPI bus.
* @details This synchronous function exchange the data by interrupt.
* 		   it starts a simultaneous transmit/receive operation.
* @note
* @param[in] spip      pointer to the @p SPIDriver object
* @param[in] n         number of words to send
* @param[in] txbuf     the pointer to the transmit buffer
* @param[in] rxbuf     the pointer to the receive buffer
*
* @notapi
*/
static void spi_lld_exchange_byisr(SPIDriver *spip, size_t n,const void *txbuf, void *rxbuf)
{
	HS_SPI_Type *s = spip->spi;
	volatile spislavecallback_par_t *paras = spip->config->paras;
	systime_t tmo = OSAL_MS2ST(n);

	s->CTR 				&= ~SPI0_RESET;
	s->CTR 				|= (SPI0_RX_FIFO_ENABLE | SPI0_TX_FIFO_ENABLE);
	s->STAT 			|= (SPI0_SET_TX_EMPTY_INT | SPI0_SET_RX_TRIGGER_INT);

	paras->txdata_len = paras->rxdata_len = n;
	paras->txdata_num = paras->rxdata_num = 0;
	paras->rxdata = rxbuf;
	paras->txdata = (void *)txbuf;
	memcpy(paras->txdata,txbuf,n);

	s->WDATA = *paras->txdata++;
	paras->txdata_num++;

	(void)osalThreadSuspendTimeoutS(&spip->thread, tmo);

	paras->txdata_num = paras->rxdata_num = 0;
	memcpy(rxbuf,paras->rxdata,n);
}

#endif

/**
* @brief   Ignores data on the SPI bus.
* @details This asynchronous function starts the transmission of a series of
*          idle words on the SPI bus and ignores the received data.
* @post    At the end of the operation the configured callback is invoked.
*
* @param[in] spip      pointer to the @p SPIDriver object
* @param[in] n         number of words to be ignored
*
* @notapi
*/
void spi_lld_ignore(SPIDriver *spip, size_t n)
{
	HS_SPI_Type *s = spip->spi;

	#if defined(__nds32__)
	nds32_dcache_clean();
	#endif

	s->CTR &= ~SPI0_RESET;
	s->CTR |= SPI0_TX_FIFO_ENABLE;
	#if (SPI_USE_DMA == TRUE) && (HS_HAS_DMA == TRUE)
		if (spip->dmatx) dmaStreamStart(spip->dmatx, spip, &s->WDATA, n);
	#else
		spi_isr_stream_start(spip,n,(void *)&s->WDATA);
	#endif
}

/**
* @brief   Exchanges data on the SPI bus.
* @details This asynchronous function starts a simultaneous transmit/receive
*          operation.
* @post    At the end of the operation the configured callback is invoked.
* @note    The buffers are organized as uint8_t arrays for data sizes below or
*          equal to 8 bits else it is organized as uint16_t arrays.
*
* @param[in] spip      pointer to the @p SPIDriver object
* @param[in] n         number of words to be exchanged
* @param[in] txbuf     the pointer to the transmit buffer
* @param[out] rxbuf    the pointer to the receive buffer
*
* @notapi
*/
void spi_lld_exchange(SPIDriver *spip, size_t n,const void *txbuf, void *rxbuf)
{
	spip->rxstate = SPI_RX_ACTIVE;
	spip->txstate = SPI_TX_ACTIVE;
	#if (SPI_USE_DMA == TRUE) && (HS_HAS_DMA == TRUE)
		spi_xfer(spip, n, txbuf, rxbuf);
	#else
		(spip)->state = SPI_READY;
		spi_lld_exchange_byisr(spip, n, txbuf, rxbuf);
	#endif
}

/**
* @brief   Sends data over the SPI bus.
* @details This asynchronous function starts a transmit operation.
* @post    At the end of the operation the configured callback is invoked.
* @note    The buffers are organized as uint8_t arrays for data sizes below or
*          equal to 8 bits else it is organized as uint16_t arrays.
*
* @param[in] spip      pointer to the @p SPIDriver object
* @param[in] n         number of words to send
* @param[in] txbuf     the pointer to the transmit buffer
*
* @notapi
*/
void spi_lld_send(SPIDriver *spip, size_t n, const void *txbuf)
{
	HS_SPI_Type *s = spip->spi;
	#if defined(__nds32__)
		nds32_dcache_clean();
	#endif
	s->CTR &= ~SPI0_RESET;
	s->CTR |= SPI0_TX_FIFO_ENABLE;
	s->STAT|= (SPI0_SET_TX_EMPTY_INT | SPI0_SET_RX_TRIGGER_INT);
	#if (SPI_USE_DMA == TRUE) && (HS_HAS_DMA == TRUE)
		spip->txstate = SPI_TX_ACTIVE;
		if (spip->dmatx) dmaStreamStart(spip->dmatx, txbuf, &s->WDATA, n);
	#else
		(spip)->state = SPI_READY;
		spi_isr_stream_start(spip,n,(void*)txbuf);
	#endif
}

/**
* @brief   Receives data from the SPI bus.
* @details This asynchronous function starts a receive operation.
* @post    At the end of the operation the configured callback is invoked.
* @note    The buffers are organized as uint8_t arrays for data sizes below or
*          equal to 8 bits else it is organized as uint16_t arrays.
*
* @param[in] spip      pointer to the @p SPIDriver object
* @param[in] n         number of words to receive
* @param[out] rxbuf    the pointer to the receive buffer
*
* @notapi
*/
void spi_lld_receive(SPIDriver *spip, size_t n, void *rxbuf)
{
	HS_SPI_Type *s = spip->spi;

	#if defined(__nds32__)
	nds32_dcache_flush();
	#endif

	s->CTR &= ~SPI0_RESET;
	s->CTR |= SPI0_RX_FIFO_ENABLE;
	spip->rxstate = SPI_RX_ACTIVE;
	spip->txstate = SPI_TX_ACTIVE;
	#if (SPI_USE_DMA == TRUE) && (HS_HAS_DMA == TRUE)
		if (spip->dmarx) dmaStreamStart(spip->dmarx, &s->RDATA, rxbuf, n);
		if (spip->dmatx) dmaStreamStart(spip->dmatx, rxbuf, &s->WDATA, n);
	#else
		(spip)->state = SPI_READY;
		spi_isr_stream_start(spip,n,rxbuf);
	#endif
}

/**
* @brief   Exchanges one frame using a polled wait.
* @details This synchronous function exchanges one frame using a polled
*          synchronization method. This function is useful when exchanging
*          small amount of data on high speed channels, usually in this
*          situation is much more efficient just wait for completion using
*          polling than suspending the thread waiting for an interrupt.
*
* @param[in] spip      pointer to the @p SPIDriver object
* @param[in] frame     the data frame to send over the SPI bus
* @return              The received data frame from the SPI bus.
*/
uint16_t spi_lld_polled_exchange(SPIDriver *spip, uint16_t frame)
{
	HS_SPI_Type *s = spip->spi;
	unsigned char buf[2] = {frame & 0xff, frame >> 8};

	s->CTR &= ~SPI0_RESET;
	s->CTR |= (SPI0_RX_FIFO_ENABLE | SPI0_TX_FIFO_ENABLE);
	s->STAT &= ~(SPI0_SET_TX_EMPTY_INT | SPI0_SET_RX_TRIGGER_INT);

	s->WDATA = buf[0];
	while(!(s->STAT & SPI0_TX_EMPTY_STATUS_MASK));		/*wait for transmission complete*/
	buf[0] = s->RDATA;

	s->WDATA = buf[1];
	while(!(s->STAT & SPI0_TX_EMPTY_STATUS_MASK));		/*wait for transmission complete*/
	buf[1] = s->RDATA;

	return (buf[1] << 8) + buf[0];
}

#endif /* HAL_USE_SPI */

/** @} */
