/*
 * rf_phy_lld.h
 *
 *  Created on: Apr 28, 2017
 *      Author: china
 */

#ifndef MAX2829_LLD_H_
#define MAX2829_LLD_H_

#if HAL_USE_RF

#if defined(BR32xx_FPGA) || defined(__DOXYGEN__)
/*-------------------------------------------------------------
 * MAX2829 init
 */
void MAX2829_init(void);
void MAX2829_RxMode_init(void);
void MAX2829_CEVA_RXENA(bool rxena_on);
void MAX2829_CEVA_TXENA(bool txena_on);
void MAX2829_CEVA_Set_Freq(uint8_t index);

/*--------------------------------------------------------------
 * Configure MAX2829 as RX mode
 * channel:  recevice channel
 */
void rf_lld_MAX2829_RX(uint8_t channel);

/*--------------------------------------------------------------
 * Configure MAX2829 as TX mode
 * channel:  send channel
 */
void rf_lld_MAX2829_TX(uint8_t channel);

/*--------------------------------------------------------------
 * Configure MAX2829 as RX gain
 * gain:step-0.5dB
 */
void rf_lld_MAX2829_RX_gain(uint8_t gain);

/*--------------------------------------------------------------
 * Configure MAX2829 as TX gain
 * gain:step-0.5dB
 */
void rf_lld_MAX2829_TX_gain(uint8_t gain);

#endif /* BR32xx_FPGA */

void MAC6200_CEVA_RXENA(bool rxena_on);
void MAC6200_CEVA_TXENA(bool txena_on);
void MAC6200_CEVA_Set_Freq(uint8_t index);

#endif /* HAL_USE_RF */

#endif /* MAX2829_LLD_H_ */
