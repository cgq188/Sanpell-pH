/*
    ChibiOS/RT - Copyright (C) 2006-2013 Giovanni Di Sirio
                 Copyright (C) 2019 BRMICRO Technologies
                 

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/
/*
   Concepts and parts of this file have been contributed by Uladzimir Pylinsky
   aka barthess.
 */

/**
 * @file    br32xx/rf_lld.h
 * @brief   BR32xx RF subsystem low level driver header.
 *
 * @addtogroup RF
 * @{
 */

#ifndef _RF_LLD_H_
#define _RF_LLD_H_


#if HAL_USE_RF || defined(__DOXYGEN__)

/*===========================================================================*/
/* Driver pre-compile time settings.                                         */
/*===========================================================================*/

/**
 * @brief   RF controller interrupt priority level setting.
 */
#if !defined(HS_RF_IRQ_PRIORITY) || defined(__DOXYGEN__)
#define HS_RF_IRQ_PRIORITY             3
#endif


/*===========================================================================*/
/* Driver constants.                                                         */
/*===========================================================================*/

/* configure register defines */
#define RF_MAC_SELECT			(1UL << 7)
#define RF_IRQ_RXFIFO_FULL 		(1UL << 3)
#define RF_IRQ_RXDATA_READY		(1UL << 2)
#define RF_IRQ_TxFIFO_EMPTY		(1UL << 1)
#define RF_IRQ_TXFIFO_READY		(1UL << 0)

/* status register defines */
#define RF_SPI_BUSY  			(1UL << 4)
#define RF_RX_FULL  			(1UL << 3)
#define RF_RXDATA_READY 		(1UL << 2)
#define RF_TXFIFO_EMPTY			(1UL << 1)
#define RF_TXFIFO_READY			(1UL << 0)

/* RF Configure register defines */
#define RF_CSN      			(1UL << 1)
#define RF_CE       			(1UL << 0)

/* RF Clear Interrupt register defines */
#define RF_ICR      			(1UL << 0)

#define HS_RF_INTR_PRIORITY     3

/**
 * @name   Max Payload length
 * @{
 */
#define RF_MAX_PAYLOAD_LEN         32
/** @} */

//-------------RF command---------------------
#define MAC6200_R_REGISTER                 0x00 // Define read command to register
#define MAC6200_W_REGISTER                 0x20 // Define write command to register
#define MAC6200_R_RX_PAYLOAD               0x61 // Define RX payload register address
#define MAC6200_W_TX_PAYLOAD               0xA0 // Define TX payload register address
#define MAC6200_FLUSH_TX                   0xE1 // Define flush TX register command
#define MAC6200_FLUSH_RX                   0xE2 // Define flush RX register command
#define MAC6200_REUSE_TX_PL                0xE3 // Define reuse TX payload register command
#define MAC6200_ACTIVATE                   0x50 // Define ACTIVATE features register command
#define MAC6200_R_RX_PL_WID                0x60 // Define read RX payload width register command
#define MAC6200_W_ACK_PAYLOAD              0xA8 // Define write ACK payload register command
#define MAC6200_W_TX_PAYLOAD_NOACK         0xB0 // Define disable TX ACK for one time register command
#define MAC6200_NOP                        0xFF // Define No Operation, might be used to read status register

#define MAC6200_ACTIVATE_DATA              0x53

//MAC6200 Bank0 Register Addr
/**************************************************/
#define MAC6200_BANK0_CONFIG                     0x00 // 'Config' register address
#define MAC6200_BANK0_EN_AA                      0x01 // 'Enable Auto Acknowledgment' register address
#define MAC6200_BANK0_EN_RXADDR                  0x02 // 'Enabled RX addresses' register address
#define MAC6200_BANK0_SETUP_AW                   0x03 // 'Setup address width' register address
#define MAC6200_BANK0_SETUP_RETR                 0x04 // 'Setup Auto. Retrans' register address
#define MAC6200_BANK0_RF_CH                      0x05 // 'RF channel' register address
#define MAC6200_BANK0_RF_SETUP                   0x06 // 'RF setup' register address
#define MAC6200_BANK0_STATUS                     0x07 // 'Status' register address
#define MAC6200_BANK0_OBSERVE_TX                 0x08 // 'Observe TX' register address
#define MAC6200_BANK0_PRE_LEN                    0x09
#define MAC6200_BANK0_RX_ADDR_P0                 0x0A // 'RX address pipe0' register address
#define MAC6200_BANK0_RX_ADDR_P1                 0x0B // 'RX address pipe1' register address
#define MAC6200_BANK0_RX_ADDR_P2                 0x0C // 'RX address pipe2' register address
#define MAC6200_BANK0_RX_ADDR_P3                 0x0D // 'RX address pipe3' register address
#define MAC6200_BANK0_RX_ADDR_P4                 0x0E // 'RX address pipe4' register address
#define MAC6200_BANK0_RX_ADDR_P5                 0x0F // 'RX address pipe5' register address
#define MAC6200_BANK0_TX_ADDR                    0x10 // 'TX address' register address
#define MAC6200_BANK0_RX_PW_P0                   0x11 // 'RX payload width, pipe0' register address
#define MAC6200_BANK0_RX_PW_P1                   0x12 // 'RX payload width, pipe1' register address
#define MAC6200_BANK0_RX_PW_P2                   0x13 // 'RX payload width, pipe2' register address
#define MAC6200_BANK0_RX_PW_P3                   0x14 // 'RX payload width, pipe3' register address
#define MAC6200_BANK0_RX_PW_P4                   0x15 // 'RX payload width, pipe4' register address
#define MAC6200_BANK0_RX_PW_P5                   0x16 // 'RX payload width, pipe5' register address
#define MAC6200_BANK0_FIFO_STATUS                0x17 // 'FIFO Status Register' register address
#define MAC6200_BANK0_RX_TIMOUT_H                0x1B
#define MAC6200_BANK0_DYNPD                      0x1C // 'Enable dynamic payload length' register address
#define MAC6200_BANK0_FEATURE                    0x1D // 'Feature' register address
#define MAC6200_BANK0_SETUP_VALUE                0x1E
#define MAC6200_BANK0_PRE_GURD                   0x1F

//MAC6200_BANK0_SETUP_AW
//#define MAC6200_AW_BITS     (0x01+0x02)
//#define MAC6200_AW_4_BYTES   0x02
//#define MAC6200_AW_5_BYTES  (0x01+0x02)

/*------------------------------5.PA power-----------------------------------*/
#define MAC6200_BANK0_PA_POWER              (0x04+0x02+0x01)
#define MAC6200_BANK0_PA_POWER_n18dBm        0x00
#define MAC6200_BANK0_PA_POWER_n12dBm        0x02
#define MAC6200_BANK0_PA_POWER_n6dBm         0x04
#define MAC6200_BANK0_PA_POWER_0dBm         (0x04+0x02)
#define MAC6200_BANK0_PA_POWER_5dBm          0x01

//Cont wave
#define MAC6200_BANK0_CONT_WAVE              0x80
#define MAC6200_BANK0_PRX                    0x01


//MAC6200 Bank1 register
#define MAC6200_BANK1_LINE                 0x00
#define MAC6200_BANK1_PLL_CTL0             0x01
#define MAC6200_BANK1_PLL_CTL1             0x02
#define MAC6200_BANK1_CAL_CTL              0x03
#define MAC6200_BANK1_A_CNT_REG            0x04
#define MAC6200_BANK1_B_CNT_REG            0x05
#define MAC6200_BANK1_RESERVED1            0x06
#define MAC6200_BANK1_STATUS               0x07
#define MAC6200_BANK1_STATE                0x08
#define MAC6200_BANK1_CHAN                 0x09
#define MAC6200_BANK1_IF_FREQ              0x0A
#define MAC6200_BANK1_AFC_COR              0x0B
#define MAC6200_BANK1_FDEV                 0x0C
#define MAC6200_BANK1_DAC_RANGE            0x0D
#define MAC6200_BANK1_DAC_IN               0x0E
#define MAC6200_BANK1_CTUNING              0x0F
#define MAC6200_BANK1_FTUNING              0x10
#define MAC6200_BANK1_RX_CTRL              0x11
#define MAC6200_BANK1_FAGC_CTRL            0x12
#define MAC6200_BANK1_FAGC_CTRL_1          0x13
#define MAC6200_BANK1_DAC_CAL_LOW          0x17
#define MAC6200_BANK1_DAC_CAL_HI           0x18
#define MAC6200_BANK1_RESERVED3            0x19
#define MAC6200_BANK1_DOC_DACI             0x1A
#define MAC6200_BANK1_DOC_DACQ             0x1B
#define MAC6200_BANK1_AGC_CTRL             0x1C
#define MAC6200_BANK1_AGC_GAIN             0x1D
#define MAC6200_BANK1_RF_IVGEN             0x1E
#define MAC6200_BANK1_TEST_PKDET           0x1F

#define MAC6200_BANK_BIT    0x80      /*bank ָʾλ*/
#define MAC6200_BANK1       0x80
#define MAC6200_BANK0       0x00

/**************************************************
                 MAC6200 �Ĵ���λ
**************************************************/
// CONFIG
#define MAC6200_MASK_RX_DR                 0x40
#define MAC6200_MASK_TX_DS                 0x20
#define MAC6200_MASK_MAX_RT                0x10
#define MAC6200_EN_CRC                     0x08
#define MAC6200_CRCO                       0x04
#define MAC6200_CRCO_1_BYTES               0x00
#define MAC6200_CRCO_2_BYTES               0x04
#define MAC6200_PWR_UP_MASK                0x02
#define MAC6200_PWR_UP_CODE                0x02
#define MAC6200_PWR_DWN_CODE               0x00
#define MAC6200_PWR_UP                     0x02
#define MAC6200_PWR_DWN                    0x00
#define MAC6200_PRIM_RX                    0x01
#define MAC6200_PRX                        0x01
#define MAC6200_PTX                        0x00
// EN_AA
#define MAC6200_EN_AA_P5                   0x20
#define MAC6200_EN_AA_P4                   0x10
#define MAC6200_EN_AA_P3                   0x08
#define MAC6200_EN_AA_P2                   0x04
#define MAC6200_EN_AA_P1                   0x02
#define MAC6200_EN_AA_P0                   0x01
// EN_RXADDR
#define MAC6200_ERX_P5                     0x20
#define MAC6200_ERX_P4                     0x10
#define MAC6200_ERX_P3                     0x08
#define MAC6200_ERX_P2                     0x04
#define MAC6200_ERX_P1                     0x02
#define MAC6200_ERX_P0                     0x01
// SETUP_AW
#define MAC6200_AW_BITS                    0x03
#define MAC6200_AW_3_BYTES                 0x01
#define MAC6200_AW_4_BYTES                 0x02
#define MAC6200_AW_5_BYTES                 0x03
// SETUP_RETR: ARD | ARC
#define MAC6200_ARD_BITS                   0xF0
#define MAC6200_ARD_250_US                 0x00
#define MAC6200_ARD_500_US                 0x01
#define MAC6200_ARD_750_US                 0x02
#define MAC6200_ARD_1000_US                0x03
#define MAC6200_ARD_1250_US                0x04
#define MAC6200_ARD_1500_US                0x05
#define MAC6200_ARD_1750_US                0x06
#define MAC6200_ARD_2000_US                0x07
#define MAC6200_ARD_2250_US                0x08
#define MAC6200_ARD_2500_US                0x09
#define MAC6200_ARD_2750_US                0x0A
#define MAC6200_ARD_3000_US                0x0B
#define MAC6200_ARD_3250_US                0x0C
#define MAC6200_ARD_3500_US                0x0D
#define MAC6200_ARD_3750_US                0x0E
#define MAC6200_ARD_4000_US                0x0F
#define MAC6200_ARC_BITS                   0x0F
#define MAC6200_AUTORETR_DISABLED          0x00
#define MAC6200_ARC_00                     0x00
#define MAC6200_ARC_01                     0x01
#define MAC6200_ARC_02                     0x02
#define MAC6200_ARC_03                     0x03
#define MAC6200_ARC_04                     0x04
#define MAC6200_ARC_05                     0x05
#define MAC6200_ARC_06                     0x06
#define MAC6200_ARC_07                     0x07
#define MAC6200_ARC_08                     0x08
#define MAC6200_ARC_09                     0x09
#define MAC6200_ARC_10                     0x0A
#define MAC6200_ARC_11                     0x0B
#define MAC6200_ARC_12                     0x0C
#define MAC6200_ARC_13                     0x0D
#define MAC6200_ARC_14                     0x0E
#define MAC6200_ARC_15                     0x0F
// RF_CH: 0~125, F0=2400+RF_CH[MHz]=2.400GHz~2.525GHz.
#define MAC6200_RF_CH_BITS                 0x7F

// RF_SETUP
#define MAC6200_CONT_WAVE                  0x80
#define MAC6200_RF_DR_LOW                  0x20
#define MAC6200_RF_DR_HIGH                 0x08
#define MAC6200_RF_DR_500_Kbps             0x20
#define MAC6200_RF_DR_1_Mbps               0x00
#define MAC6200_RF_DR_2_Mbps               0x08
#define MAC6200_PLL_LOCK                   0x10
#define MAC6200_RF_PWR_n18_dBm             0x00
#define MAC6200_RF_PWR_n12_dBm             0x02
#define MAC6200_RF_PWR_n6_dBm              0x04
#define MAC6200_RF_PWR_0_dBm               0x06
#define MAC6200_RF_PWR_5_dBm               0x07
#define MAC6200_LNA_HCURR                  0x01

// STATUS
#define MAC6200_RX_DR                      0x40
#define MAC6200_TX_DS                      0x20
#define MAC6200_MAX_RT                     0x10
#define MAC6200_RX_P_NO                    0x0E
#define MAC6200_RX_FIFO_EMPTY              0x0E
#define MAC6200_TX_FIFO_FULL               0x01 // �� FIFO_STATUS �� TX_FULL ��־λ�ظ�

// OBSERVE_TX
#define MAC6200_PLOS_CNT                   0xF0
#define MAC6200_ARC_CNT                    0x0F
// PRD
#define MAC6200_RPD_BITS                   0x01
// RX_PW_PX
#define MAC6200_RX_PW_BITS                 0x3F

// FIFO_STATUS
#define MAC6200_FIFO_STATUS_TX_REUSE       0x40
#define MAC6200_FIFO_STATUS_TX_FULL        0x20 // �� STATUS �� TX_FULL ��־λ�ظ�
#define MAC6200_FIFO_STATUS_TX_EMPTY       0x10
#define MAC6200_FIFO_STATUS_RX_FULL        0x02
#define MAC6200_FIFO_STATUS_RX_EMPTY       0x01

// DYNPD
#define MAC6200_DPL_P5                     0x20 // ���ö���ͨ��
#define MAC6200_DPL_P4                     0x10 // ���ö���ͨ��
#define MAC6200_DPL_P3                     0x08 // ���ö���ͨ��
#define MAC6200_DPL_P2                     0x04 // ���ö���ͨ��
#define MAC6200_DPL_P1                     0x02 // ���ö���ͨ��
#define MAC6200_DPL_P0                     0x01 // ���ö���ͨ��

// FEATURE
#define MAC6200_EN_DPL                     0x04 // ���ö�̬�س�
#define MAC6200_EN_DPL_MASK                0x04
#define MAC6200_EN_DPL_CODE                0x04

#define MAC6200_EN_ACK_PAY                 0x02 // ��������Ӧ��
#define MAC6200_EN_DYN_ACK                 0x01 // ���ö�̬Ӧ��

/*===========================================================================*/
/* Driver data structures and types.                                         */
/*===========================================================================*/

/*
 * @brief   Type of an RF Power.
 */
typedef enum {
	RF_POWER_n18dBm = 0x00,
	RF_POWER_n12dBm = 0x02,
	RF_POWER_n6dBm = 0x04,
	RF_POWER_0dBm = 0x06,
	RF_POWER_5dBm = 0x07,
} RFPower_t;

/*
 * @brief   Type of an RF Data rate.
 */
typedef enum {
	RF_DR_250Kbps = 250*1000,
	RF_DR_500Kbps = 500*1000,
	RF_DR_1Mbps = 1000*1000,
	RF_DR_2Mbps = 2000*1000,
} RFDataRate_t;

/*
 * @brief   Type of an RF Communication Mode.
 */
typedef enum { 
	COMMODE_SPL_SA_NAK_ZZ = 0x00, // �������޴�	
	COMMODE_SPL_SA_ACK_AE = 0x02, // �������մ�	
	COMMODE_SPL_DA_ACK_AE = 0x06, // �������մ�
	COMMODE_DPL_SA_NAK_ZZ = 0x0a, // �������޴�	
	COMMODE_DPL_SA_ACK_AP = 0x0b, // �������ش�
	COMMODE_DPL_DA_ACK_AE = 0x0e, // �������մ�
	COMMODE_DPL_DA_ACK_AP = 0x0f, // �������ش�
	COMMODE_MUL_SLAVE_NO_ACK = 0x10, // -�������Ӧ��
	COMMODE_MUL_SLAVE_ACK = 0x11, // -����Ӵ�Ӧ��
    COMMODE_DPL_SA_NAK_ZZ_CRC_1Bit = 0x12, //�������޴�CRC 1bit
} RFCommuicationMode_t;

/*
 * @brief   role of the RF when Communicate.
 */
typedef enum { 
	COMROLE_PTX = 0x00,
	COMROLE_PRX = 0x01, 
} RFRole_t;

/*
 * @brief   CRC Length of the RF.
 */
typedef enum { 
	COMCRC_1BIT = 0x00,
	COMCRC_2BIT = 0x01,
    COMCRC_DISABLE = 0x02,
} RFCRC_t;
/**
 * @brief   Structure representing a RF driver.
 */
typedef struct RFAddress {
  /**
   * @brief rf address length.
   */
  uint8_t Addr_len;
  /**
   * @brief RF address
   */
  uint8_t Addr[5];
  
} RFAddress;

/**
 * @brief   Structure representing a RF driver.
 */
typedef struct RFConfig {
  /**
   * @brief RF address .
   */
  RFAddress *pAddr;
  /**
   * @brief RF communication power.
   */
  RFPower_t Power;
  /**
   * @brief RF communication data rate.
   */
  RFDataRate_t DataRate;
  /**
   * @brief rf as PTX or PRX .
   */
  RFRole_t Role;  
  /**
   * @brief communication chanle .
   */
  uint16_t Channel;
}RFConfig;

/**
  * @brief Driver state machine possible states.
  */
 typedef enum {
   RF24G_UNINIT = 0,                    /**< Not initialized.                   */
   RF24G_STOP = 1,                      /**< Stopped.                           */
   RF24G_READY = 2                      /**< Ready.                             */
 } rfstate_t;


/**
 * @extends BaseAsynchronousChannel
 *
 * @brief   Full duplex serial driver class.
 * @details This class extends @p BaseAsynchronousChannel by adding physical
 *          I/O queues.
 */
struct Rf24gDriver {
  /** @brief Virtual Methods Table.*/
  const struct Rf24gDriverVMT *vmt;
  _base_asynchronous_channel_data
  /* Input queue.*/
  input_queue_t             iqueue;
  /* Output queue.*/
  output_queue_t            oqueue;
  /* Input circular buffer.*/
  uint8_t                   *ib;
  /* Output circular buffer.*/
  uint8_t                   *ob;
  /* Driver state.*/
  rfstate_t                 state;
  /* Allow rf to send data  */
  bool_t                    can_send;
  /* Allow rf to send data  */
  RFConfig                  *config;

};


typedef struct Rf24gDriver Rf24gDriver;

/*===========================================================================*/
/* External declarations.                                                    */
/*===========================================================================*/

#if !defined(__DOXYGEN__)
extern RFConfig MAC6200;
extern volatile uint8_t RF_Status;
#endif

#ifdef __cplusplus
extern "C" {
#endif
/*-------------------------------------------------------------
 * Select MAC6200 as rf PHY. 
 */
void rf_lld_Select_MAC6200(void);

/*-------------------------------------------------------------
 *  Change RF's SPI CSN to high.
 */
void rf_lld_CSN_High(void);

/*-------------------------------------------------------------
 *  Change RF's SPI CSN to low.
 */
void rf_lld_CSN_Low(void);

/*-------------------------------------------------------------
 *  Change RF's CE to high.
 */
void rf_lld_CE_High(void);

/*-------------------------------------------------------------
 *  Change RF's CE to low.
 */
void rf_lld_CE_Low(void);

/*-------------------------------------------------------------
 * Write RF's register by SPI interface.
 * Reg:       RF register.
 * Reg_val:   ready to write RF register value to rf register.
 * Reg_Width: reg_value width.   
 */
void rf_lld_Wr_Reg(uint8_t Reg,uint8_t *Reg_Val,uint8_t len);

/*-------------------------------------------------------------
 * Read RF's register by SPI interface.
 * Reg:       RF register.
 * Reg_val:   ready to write RF register value to rf register.
 * Reg_Width: reg_value width.   
 */
void rf_lld_Rd_Reg(uint8_t Reg,uint8_t *Reg_Val,uint8_t len);

/*-------------------------------------------------------------
 * Write RF's register by SPI interface.
 * Reg:       RF register.
 * Reg_val:   ready to write RF register value to rf register.
 * Reg_Width: reg_value width.   
 */
void rf_lld_Wr_Reg_int(uint8_t Reg,uint8_t *Reg_Val,uint8_t len);

/*-------------------------------------------------------------
 * Read RF's register by SPI interface.
 * Reg:       RF register.
 * Reg_val:   ready to write RF register value to rf register.
 * Reg_Width: reg_value width.   
 */
void rf_lld_Rd_Reg_int(uint8_t Reg,uint8_t *Reg_Val,uint8_t len);

/*--------------------------------------------------------------
 * No Operation. Might be used to read RF's STATUS register.
 */
uint8_t rf_lld_Nop(void);

/*--------------------------------------------------------------
 * Flush RF's Tx Fifo
 */
void rf_lld_Flush_Tx_Fifo(void);

/*--------------------------------------------------------------
 * Flush RF's Rx Fifo
 */
void rf_lld_Flush_Rx_Fifo(void);

/*--------------------------------------------------------------
 * switch Rf's bank to Bank0
 */
void rf_lld_Bank0_Activate(void);

/*--------------------------------------------------------------
 * switch Rf's bank to Bank1
 */
void rf_lld_Bank1_Activate(void);

/*--------------------------------------------------------------
 * Read receive payload's length at the dynamic payload length mode
 */
uint8_t rf_lld_Read_Rx_Payload_Width(void);

/*--------------------------------------------------------------
 * Read receive payload's length at the static payload length mode
 * Pipe_num: pipe index. vaild value is 0-5 
 */
uint8_t rf_lld_Read_Rx_Pipe_Static_Payload_Width(uint8_t Pipe_Num);

/*---------------------------------------------------------------
 * Read received payload
 * pBuf:  received payload, and maximum payload length is 32 Bytes.
 * bytes: paylaod length which ready to read, valid length is 1-32 bytes.
 */
void rf_lld_Read_Rx_Payload(uint8_t *pBuf, uint8_t bytes);

/*---------------------------------------------------------------
 * Write Acknowledge payload
 * PipeNum : pipe index to write to ACk paylaod
 * pBuf:     ready to write payload, and valid length is 1-32bytes
 * byres:    acknowldge paylaod length, valid length is 1-32 bytes.   
 */ 
void rf_lld_Write_Ack_Payload(uint8_t PipeNum, uint8_t *pBuf, uint8_t bytes);

/*-----------------------------------------------------------------
 * Write Tx paylaod use the comand of W_TX_PAYLOAD_NOACK, it does not need ackpayload after send the payload. 
 * pBuf: ready to send paylaod value
 * bytes: ready to seng payload length, and valid value is 1-32 bytes.
 */
void rf_lld_Write_Tx_Payload_No_Ack(uint8_t *pBuf, uint8_t bytes);

/*-----------------------------------------------------------------
 * Write Tx paylaod use the comand of W_TX_PAYLOAD, it may be need ackpayload after send the payload. 
 * pBuf: ready to send paylaod value
 * bytes: ready to seng payload length, and valid value is 1-32 bytes.
 */
void rf_lld_Write_Tx_Payload(uint8_t *pBuf, uint8_t bytes);

/*-----------------------------------------------------------------
 * set MAC6200 device address 
 * Px_Addr_Reg:   pipe  address register
 * pPipeAddr:  point of pipe address 
 * Addr_Width: length of address
 */
void rf_lld_Write_Pipe_Addr(uint8_t Px_Addr_Reg, uint8_t *pPipeAddr, uint8_t Addr_Width);

/*-----------------------------------------------------------------
 * write ack payload
 * PipeNum:   pipe  which will be write
 * pBuf:  point to the ack buffer 
 * bytes: length of ack payload
 */
void rf_lld_Write_Ack_Payload(uint8_t PipeNum, uint8_t *pBuf, uint8_t bytes);

void BR3215_mac6200_init(void);
void rf24g_lld_init(void);
void rf24g_lld_start(Rf24gDriver *rf24gp);
void rf24g_lld_stop(Rf24gDriver *rf24gp);

#ifdef __cplusplus
}
#endif

#endif  /* HAL_USE_RF */
#endif /* _RF_LLD_H_ */

/** @} */
