/*
    ChibiOS/RT - Copyright (C) 2006-2013 Giovanni Di Sirio
                 Copyright (C) 2014 BRMICRO Technologies

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file   /fm_lld.h
 * @brief   FM Driver subsystem low level driver header.
 *
 * @addtogroup FM
 * @{
 */

#ifndef _FM_LLD_H_
#define _FM_LLD_H_

#if HAL_USE_FM || defined(__DOXYGEN__)

/*===========================================================================*/
/* Driver constants.                                                         */
/*===========================================================================*/
#define FM_STEREO_RSSI_TH_DELTA     10

/*===========================================================================*/
/* Driver pre-compile time settings.                                         */
/*===========================================================================*/

/*===========================================================================*/
/* Derived constants and error checks.                                       */
/*===========================================================================*/

/*===========================================================================*/
/* Driver data structures and types.                                         */
/*===========================================================================*/

/**
 * @brief Driver configuration structure.
 */
typedef struct {
  uint8_t  chhc;
  uint8_t  lrhc;
  int8_t   rssi;
  int8_t   snr; //ncfo2 if BR3215e
  int8_t   ncfo;
  uint8_t  opt;
  int8_t   rssi_stereo;
  int8_t   snr_stereo;
} FMConfig;

/**
 * @brief   Type of a structure representing an FM driver.
 */
typedef struct FMDriver FMDriver;

/**
 * @brief Structure representing an fm driver.
 */
struct FMDriver {
  /**
   * @brief   Driver state.
   */
  uint32_t                  state;
  /**
   * @brief   Current configuration data.
   */
  const FMConfig            *config;
  /**
   * @brief   Error flags.
   */
  uint32_t                  errors;
  /**
   * @brief   Mutex protecting the bus.
   */
  mutex_t                   mutex;

  /* End of the mandatory fields.*/
  int                       freq_current; //100kHz

  uint16_t                  freqs[4];
  int8_t                    rssis[4];
  #if defined(BR3215)
  int8_t                    snrs[4];
  #elif defined(BR3215e)
  int8_t                    ncfos[4];
  int8_t                    rssi_noise;
  ///backup of hw registers
  uint32_t                  ana_cfg_new;
  uint32_t                  rx_fil_cfg;
  #endif
  uint8_t                   num_tracks;
};

/*===========================================================================*/
/* Driver macros.                                                            */
/*===========================================================================*/
#define fm_lld_get_errors(fmp) ((fmp)->errors)
#define MODE_FM           (1 << 0)
#define MODE_STEREO       (0 << 4)
#define MODE_MONO         (1 << 4)

#define BT_MHZ_MIN  2400  //mHZ
#define BT_MHZ_MAX  2600  //mHZ
/*===========================================================================*/
/* External declarations.                                                    */
/*===========================================================================*/

#if !defined(__DOXYGEN__)
#if HAL_USE_FM
extern FMDriver FMD0;
#endif
#endif

#ifdef __cplusplus
extern "C" {
#endif
  void fm_lld_init(void);
  void fm_lld_start(FMDriver *fmp);
  void fm_lld_stop(FMDriver *fmp);
  int fm_lld_set_freq(FMDriver *fmp, int freq);
  int fm_lld_get_freq(FMDriver *fmp);
  int fm_lld_check_freq_old(FMDriver *fmp, int freq);
  int fm_lld_check_freq(FMDriver *fmp, int freq, bool bNext);
  int8_t fm_lld_get_rssi(FMDriver *fmp);
  int8_t fm_lld_get_snr(FMDriver *fmp);
  uint16_t fm_lld_get_hwctx(FMDriver *fmp);
  void fm_lld_set_hwctx(FMDriver *fmp, uint16_t ctx);
#ifdef __cplusplus
}
#endif

#endif /* HAL_USE_FM */

#endif /* _FM_LLD_H_ */

/** @} */
