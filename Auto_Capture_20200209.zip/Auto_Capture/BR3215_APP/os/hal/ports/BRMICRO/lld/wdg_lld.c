/*
    ChibiOS - Copyright (C) 2016 Stephane D'Alu
              Copyright (C) 2019 BRMICRO Technologies
              

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    wdg_lld.c
 * @brief   WDG Driver subsystem low level driver source.
 *
 * @addtogroup WDG
 * @{
 */

#include "hal.h"

#if (HAL_USE_WDG == TRUE) || defined(__DOXYGEN__)

/*===========================================================================*/
/* Driver local definitions.                                                 */
/*===========================================================================*/

#define RELOAD_REQUEST_VALUE         0x76

/*===========================================================================*/
/* Driver exported variables.                                                */
/*===========================================================================*/

WDGDriver WDGD0;

/*===========================================================================*/
/* Driver local variables.                                                   */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local functions.                                                   */
/*===========================================================================*/
static inline uint32_t wdt_top2seconds(uint8_t top)
{
  /*
   * There are 16 possible timeout values in 0..15 where the number of
   * cycles is 2 ^ (16 + i) and the watchdog counts down.
   */
  return (1 << (16 + top)) / HS_WDT_FREQ;
}

/*===========================================================================*/
/* Driver interrupt handlers.                                                */
/*===========================================================================*/

#if WDG_USE_TIMEOUT_CALLBACK == TRUE
/**
 * @brief   Watchdog vector.
 * @details This interrupt is used when watchdog timeout.
 *
 * @isr
 */
OSAL_IRQ_HANDLER(WDT_IRQHandler) {

  OSAL_IRQ_PROLOGUE();
  osalSysLockFromISR();

  /* Notify */
  if (WDGD0.config->callback)
      WDGD0.config->callback();

  /* Wait for reboot */
  while (1) { /* */ }

  osalSysUnlockFromISR();
  OSAL_IRQ_EPILOGUE();
}
#endif

/*===========================================================================*/
/* Driver exported functions.                                                */
/*===========================================================================*/

/**
 * @brief   Get Watchdog Current Counter Value
 *
 * @return  Current Counter Value.
 * @notapi
 */
uint32_t wdt_time_left(void){
	return HS_WDT->CCVR / HS_WDT_FREQ;	
}

/**
 * @brief   Get Watchdog Timeout value
 *
 * @return   Watchdog Timeout value.
 * @notapi
 */

uint32_t wdt_get_timeout(void) {

  uint8_t top = HS_WDT->TORR & 0xF;

  return wdt_top2seconds(top);	
}

/**
 * @brief   Set Watchdog Timeout value
 *
 * @param[in] seconds   seconds Timeout TO set to Watchdog
 *
 * @return    The real Watchdog Timeout value TO set to Watchdog
 *
 * @notapi
 */

uint32_t wdt_set_timeout(uint32_t seconds) {
  uint8_t top;

  /*
   * Iterate over the timeout values until we find the closest match. We
   * always look for >=.
   */
  for (top = 0; top <= HS_WDT_TOP_MAX; ++top) {
    if (wdt_top2seconds(top) >= seconds) {
      break;
    }
  }

  /* Set the new value in the watchdog. */
  HS_WDT->TORR = (top << 4) | top;

  return wdt_top2seconds(top);	
}

/**
 * @brief   Low level WDG driver initialization.
 *
 * @notapi
 */
void wdg_lld_init(void) {
  WDGD0.state = WDG_STOP;
  WDGD0.wdt   = HS_WDT;
  /* stop watchdog when init */
  WDGD0.wdt->CLOCK_EN = 0;
}

/**
 * @brief   Configures and activates the WDG peripheral.
 *
 * @param[in] wdgp      pointer to the @p WDGDriver object
 *
 * @notapi
 */
void wdg_lld_start(WDGDriver *wdgp) {
  uint32_t reg;

  //osalDbgAssert((wdgp->state == WDG_STOP), "This WDG driver cannot be restarted once activated");

  cpmEnableWDT();

  /* Set Clock Enable */
  wdgp->wdt->CLOCK_EN = 0x03;

  /* clear wdt interrupt */
  reg = wdgp->wdt->EOI;
  reg = 0;
        
  osalDbgAssert(wdgp->config->timeout_ms <= WDG_MAX_TIMEOUT_MS, "watchdog timout value exceeded");
  wdt_set_timeout(wdgp->config->timeout_ms / 1000/*seconds*/);
	
  /* Reset pluse length: 256 cycles */
  reg |= WDT_CR_RPL_256;
	
  /* Generate interrupt on timeout */
#if WDG_USE_TIMEOUT_CALLBACK == TRUE
  /* First generate an interrupt and if it isnot cleared by the time a 
     second timeout occurs then generate a system reset*/
  reg |= WDT_CR_RMOD_INT;
  /* enable watchdog interrupt */
  nvicEnableVector(WDT_IRQn, HS_WDT_IRQ_PRIORITY);
#else
  /* Generate a system reset without interrupt */
  reg &= ~WDT_CR_RMOD_INT;
#endif

  /* Once watchdog is enabled, it can be cleared only by a system reset */
  reg |= WDT_CR_EN;
	
  wdgp->wdt->CR = reg;
}

/**
 * @brief   Deactivates the WDG peripheral.
 *
 * @param[in] wdgp      pointer to the @p WDGDriver object
 *
 * @api
 */
void wdg_lld_stop(WDGDriver *wdgp) {
  //osalDbgAssert(false, "This WDG driver cannot be stopped once activated");
  wdgp->wdt->CLOCK_EN = 0;
}

/**
 * @brief   Reloads WDG's counter.
 *
 * @param[in] wdgp      pointer to the @p WDGDriver object
 *
 * @notapi
 */
void wdg_lld_reset(WDGDriver * wdgp) {
  wdgp->wdt->CRR = RELOAD_REQUEST_VALUE;
}

#endif /* HAL_USE_WDG == TRUE */

/** @} */
