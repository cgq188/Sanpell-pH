/*
    ChibiOS/RT - Copyright (C) 2006-2013 Giovanni Di Sirio
                 Copyright (C) 2019 BRMICRO Technologies
                 
                 
                 

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    br32xx/i2s_lld.c
 * @brief   audio interface Driver subsystem low level driver source template.
 *
 * @addtogroup I2S
 * @{
 */

#include <string.h>
#include "hal.h"
#include "chprintf.h"

#if HAL_USE_AUDIO || defined(__DOXYGEN__)

/*===========================================================================*/
/* Driver local definitions.                                                 */
/*===========================================================================*/

/*===========================================================================*/
/* Driver exported variables.                                                */
/*===========================================================================*/

/**
 * @brief   I2S driver identifier.
 */
#if !defined(__DOXYGEN__)
I2SDriver I2SD;
#endif

/*===========================================================================*/
/* Driver local variables and types.                                         */
/*===========================================================================*/


/*===========================================================================*/
/* Driver local functions.                                                   */
/*===========================================================================*/

static void _i2s_hw_init(HS_I2S_Type *i2s, hs_audio_config_t *cfgp, hs_audio_dir_t dir)
{
  uint8_t wlen_reg;

  __i2s_set_enable(i2s, 0);
  __i2s_set_i2smode(i2s, 1 == cfgp->sample_channels ? 1/*mono*/ : 0/*stereo*/);
  __i2s_set_wss(i2s, 2/*ws_width is always 32-bit on I2S bus*/);
  __i2s_set_sclkGate(i2s, 0);
  switch (cfgp->sample_bits) {
  case 12: wlen_reg = 1; break;
  case 16: wlen_reg = 2; break;
  case 20: wlen_reg = 3; break;
  case 24: wlen_reg = 4; break;
  case 32: wlen_reg = 5; break;
  default: wlen_reg = 0; break;
  }

  if(dir == AUDIO_STREAM_PLAYBACK)
  {
    __i2s_set_txsamplewidth(i2s, wlen_reg);
    __i2s_enable_tx(i2s, 0);
    __i2s_enable_txChn(i2s, 0);
    __i2s_set_txFifoDepth(i2s, 7);
  }
  else
  {
    __i2s_set_rxsamplewidth(i2s, wlen_reg);
    __i2s_enable_rx(i2s, 0);
    __i2s_enable_rxChn(i2s, 0);
    __i2s_set_rxFifoDepth(i2s, 7);
  }

  __i2s_set_workmode(i2s, 0); //0=slave, 1=master

  //__i2s_mask_allInt(i2s);
  __i2s_unmask_allInt(i2s);
  __i2s_set_enable(i2s, 1);
}


static void _i2s_record_start(I2SDriver *i2sp)
{
  __i2s_enable_rx(i2sp->rx_i2s, 0);
  __i2s_enable_rxChn(i2sp->rx_i2s, 0);

  __i2s_reset_rxDma(i2sp->rx_i2s);
  __i2s_reset_allRxFifo(i2sp->rx_i2s);
  __i2s_flush_rxFifo(i2sp->rx_i2s);

  __i2s_enable_rx(i2sp->rx_i2s, 1);
  __i2s_enable_rxChn(i2sp->rx_i2s, 1);
}

static void _i2s_play_start(I2SDriver *i2sp)
{
  __i2s_enable_tx(i2sp->tx_i2s, 0);
  __i2s_enable_txChn(i2sp->tx_i2s, 0);

  __i2s_reset_txDma(i2sp->tx_i2s);
  __i2s_reset_allTxFifo(i2sp->tx_i2s);
  __i2s_flush_txFifo(i2sp->tx_i2s);

  __i2s_enable_tx(i2sp->tx_i2s, 1);
  __i2s_enable_txChn(i2sp->tx_i2s, 1);
}

/**
 * @brief   Common IRQ handler.
 *
 * @param[in] i2sp       communication channel associated to the I2S
 */
static void i2s_serve_interrupt(I2SDriver *i2sp)
{
  (void)i2sp;
}

/*===========================================================================*/
/* Driver interrupt handlers.                                                */
/*===========================================================================*/
/**
 * @brief   I2S interrupt handler.
 *
 * @isr
 */
OSAL_IRQ_HANDLER(I2S_IRQHandler) {

  OSAL_IRQ_PROLOGUE();

  i2s_serve_interrupt(&I2SD);

  OSAL_IRQ_EPILOGUE();
}

/*===========================================================================*/
/* Driver exported functions.                                                */
/*===========================================================================*/

/**
 * @brief   Low level I2S driver initialization.
 *
 * @notapi
 */
void i2s_lld_init(void)
{
  I2SD.rx_i2s = HS_I2S_RX;
  I2SD.tx_i2s = HS_I2S_TX;
}

/**
 * @brief   Configures and activates the I2S peripheral.
 *
 * @param[in] i2sp      pointer to the @p I2SDriver object
 *
 * @notapi
 */
void i2s_lld_start(I2SDriver *i2sp)
{
  (void)i2sp;
  cpmEnableI2S();
  cpmResetI2S();
}

/**
 * @brief   Deactivates the I2S peripheral.
 *
 * @param[in] i2sp      pointer to the @p I2SDriver object
 *
 * @notapi
 */
void i2s_lld_stop(I2SDriver *i2sp)
{
  i2s_lld_record_stop(i2sp);
  i2s_lld_play_stop(i2sp);

  __i2s_mask_allInt(i2sp->rx_i2s);
  __i2s_mask_allInt(i2sp->tx_i2s);

  nvicDisableVector(I2S_IRQn);
  cpmDisableI2S();
}

int32_t i2s_lld_record_start(I2SDriver *i2sp, hs_audio_config_t *cfgp)
{
  /* [6]transmit_en=1: enable icodec i2s's txclk for record */
  HS_CODEC->IF_CTRL |= (1u << 6);
  _i2s_hw_init(i2sp->rx_i2s, cfgp, AUDIO_STREAM_RECORD);

  _i2s_record_start(i2sp);
  /* [2]i2s_txclk_rstn_reg=1 (deassert) */
  HS_CODEC->CLK_CTRL_1 |= (1u << 2);

  return 0;
}

int32_t i2s_lld_record_stop(I2SDriver *i2sp)
{
  /* [2]i2s_txclk_rstn_reg=0 (assert) */
  HS_CODEC->CLK_CTRL_1 &= ~(1u << 2);

  __i2s_enable_rx(i2sp->rx_i2s, 0);
  __i2s_enable_rxChn(i2sp->rx_i2s, 0);
  __i2s_set_enable(i2sp->rx_i2s, 0);

  /* [6]transmit_en=0: disable icodec i2s's txclk for record */
  HS_CODEC->IF_CTRL &= ~(1u << 6);

  return 0;
}

int32_t i2s_lld_play_start(I2SDriver *i2sp, hs_audio_config_t *cfgp)
{
  /* [5]receive_en=1: enable icodec i2s's rxclk for play */
  HS_CODEC->IF_CTRL |= (1u << 5);
  _i2s_hw_init(i2sp->tx_i2s, cfgp, AUDIO_STREAM_PLAYBACK);

  _i2s_play_start(i2sp);

  /* [3]i2s_rxclk_rstn_reg=1 (deassert) */
  HS_CODEC->CLK_CTRL_1 |= (1u << 3);

  return 0;
}

int32_t i2s_lld_play_stop(I2SDriver *i2sp)
{
  /* [3]i2s_rxclk_rstn_reg=0 (assert) */
  HS_CODEC->CLK_CTRL_1 &= ~(1u << 3);

  __i2s_enable_tx(i2sp->tx_i2s, 0);
  __i2s_enable_txChn(i2sp->tx_i2s, 0);
  __i2s_set_enable(i2sp->tx_i2s, 0);

  /* [5]receive_en=0: disable icodec i2s's rxclk for play */
  HS_CODEC->IF_CTRL &= ~(1u << 5);

  return 0;
}

#endif /* HAL_USE_AUDIO */

/** @} */
