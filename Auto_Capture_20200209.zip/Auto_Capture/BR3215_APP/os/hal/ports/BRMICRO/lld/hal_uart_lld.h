/*
    ChibiOS - Copyright (C) 2006..2018 Giovanni Di Sirio

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    UARTv1/hal_uart_lld.h
 * @brief   HS low level UART driver header.
 *
 * @addtogroup UART
 * @{
 */

#ifndef HAL_UART_LLD_H
#define HAL_UART_LLD_H

#if HAL_USE_UART || defined(__DOXYGEN__)

/*===========================================================================*/
/* Driver constants.                                                         */
/*===========================================================================*/

/*===========================================================================*/
/* Driver pre-compile time settings.                                         */
/*===========================================================================*/

/**
 * @name    Configuration options
 * @{
 */
#if 1 || !HS_HAS_DMA || !defined(HS_UART_USE_DMA) || defined(__DOXYGEN__)
#define HS_UART_USE_DMA                 FALSE
#endif

/**
 * @brief   UART driver on UART0 enable switch.
 * @details If set to @p TRUE the support for UART0 is included.
 * @note    The default is @p FALSE.
 */
#if !defined(HS_UART_USE_UART0) || defined(__DOXYGEN__)
#define HS_UART_USE_UART0               FALSE
#endif

/**
 * @brief   UART driver on UART1 enable switch.
 * @details If set to @p TRUE the support for UART1 is included.
 * @note    The default is @p FALSE.
 */
#if !defined(HS_UART_USE_UART1) || defined(__DOXYGEN__)
#define HS_UART_USE_UART1               FALSE
#endif

/**
 * @brief   UART driver on UART2 enable switch.
 * @details If set to @p TRUE the support for UART2 is included.
 * @note    The default is @p FALSE.
 */
#if !defined(HS_UART_USE_UART2) || defined(__DOXYGEN__)
#define HS_UART_USE_UART2               FALSE
#endif

/**
 * @brief   UART0 interrupt priority level setting.
 */
#if !defined(HS_UART_UART0_IRQ_PRIORITY) || defined(__DOXYGEN__)
#define HS_UART_UART0_IRQ_PRIORITY      3
#endif

/**
 * @brief   UART1 interrupt priority level setting.
 */
#if !defined(HS_UART_UART1_IRQ_PRIORITY) || defined(__DOXYGEN__)
#define HS_UART_UART1_IRQ_PRIORITY      3
#endif

/**
 * @brief   UART2 interrupt priority level setting.
 */
#if !defined(HS_UART_UART2_IRQ_PRIORITY) || defined(__DOXYGEN__)
#define HS_UART_UART2_IRQ_PRIORITY      3
#endif

/**
 * @brief   UART0 DMA priority (0..3|lowest..highest).
 * @note    The priority level is used for both the TX and RX DMA channels but
 *          because of the channels ordering the RX channel has always priority
 *          over the TX channel.
 */
#if !defined(HS_UART_UART0_DMA_PRIORITY) || defined(__DOXYGEN__)
#define HS_UART_UART0_DMA_PRIORITY      3
#endif

/**
 * @brief   UART1 DMA priority (0..3|lowest..highest).
 * @note    The priority level is used for both the TX and RX DMA channels but
 *          because of the channels ordering the RX channel has always priority
 *          over the TX channel.
 */
#if !defined(HS_UART_UART1_DMA_PRIORITY) || defined(__DOXYGEN__)
#define HS_UART_UART1_DMA_PRIORITY      0
#endif

/**
 * @brief   UART2 DMA priority (0..3|lowest..highest).
 * @note    The priority level is used for both the TX and RX DMA channels but
 *          because of the channels ordering the RX channel has always priority
 *          over the TX channel.
 */
#if !defined(HS_UART_UART2_DMA_PRIORITY) || defined(__DOXYGEN__)
#define HS_UART_UART2_DMA_PRIORITY      0
#endif


/**
 * @brief   UART DMA error hook.
 * @note    The default action for DMA errors is a system halt because DMA
 *          error can only happen because programming errors.
 */
#if !defined(HS_UART_DMA_ERROR_HOOK) || defined(__DOXYGEN__)
#define HS_UART_DMA_ERROR_HOOK(uartp)    osalSysHalt("DMA failure")
#endif
/** @} */

/*===========================================================================*/
/* Derived constants and error checks.                                       */
/*===========================================================================*/

#if HS_UART_USE_UART0 && !HS_HAS_UART0
#error "UART0 not present in the selected device"
#endif

#if HS_UART_USE_UART1 && !HS_HAS_UART1
#error "UART1 not present in the selected device"
#endif

#if HS_UART_USE_UART2 && !HS_HAS_UART2
#error "UART2 not present in the selected device"
#endif

#if !HS_UART_USE_UART0 && !HS_UART_USE_UART1 && !HS_UART_USE_UART2
#error "UART driver activated but no UART peripheral assigned"
#endif

#if HS_UART_USE_UART0 &&                                                \
    !OSAL_IRQ_IS_VALID_PRIORITY(HS_UART_UART0_IRQ_PRIORITY)
#error "Invalid IRQ priority assigned to UART0"
#endif

#if HS_UART_USE_UART1 &&                                                \
    !OSAL_IRQ_IS_VALID_PRIORITY(HS_UART_UART1_IRQ_PRIORITY)
#error "Invalid IRQ priority assigned to UART1"
#endif

#if HS_UART_USE_UART2 &&                                                \
    !OSAL_IRQ_IS_VALID_PRIORITY(HS_UART_UART2_IRQ_PRIORITY)
#error "Invalid IRQ priority assigned to UART2"
#endif

#if HS_HAS_DMA && HS_UART_USE_DMA
#if HS_UART_USE_UART0 &&                                                \
    !HS_DMA_IS_VALID_PRIORITY(HS_UART_UART0_DMA_PRIORITY)
#error "Invalid DMA priority assigned to UART0"
#endif

#if HS_UART_USE_UART1 &&                                                \
    !HS_DMA_IS_VALID_PRIORITY(HS_UART_UART1_DMA_PRIORITY)
#error "Invalid DMA priority assigned to UART1"
#endif

#if HS_UART_USE_UART2 &&                                                \
    !HS_DMA_IS_VALID_PRIORITY(HS_UART_UART2_DMA_PRIORITY)
#error "Invalid DMA priority assigned to UART2"
#endif

/* The following checks are only required when there is a DMA able to
   reassign streams to different channels.*/
#if HS_ADVANCED_DMA
/* Check on the presence of the DMA streams settings in mcuconf.h.*/
#if HS_UART_USE_UART0 && (!defined(HS_UART_UART0_RX_DMA_STREAM) ||  \
                              !defined(HS_UART_UART0_TX_DMA_STREAM))
#error "UART0 DMA streams not defined"
#endif

#if HS_UART_USE_UART1 && (!defined(HS_UART_UART1_RX_DMA_STREAM) ||  \
                              !defined(HS_UART_UART1_TX_DMA_STREAM))
#error "UART1 DMA streams not defined"
#endif

#if HS_UART_USE_UART2 && (!defined(HS_UART_UART2_RX_DMA_STREAM) ||  \
                              !defined(HS_UART_UART2_TX_DMA_STREAM))
#error "UART2 DMA streams not defined"
#endif

/* Check on the validity of the assigned DMA channels.*/
#if HS_UART_USE_UART0 &&                                                \
    !HS_DMA_IS_VALID_ID(HS_UART_UART0_RX_DMA_STREAM,                 \
                           HS_UART0_RX_DMA_MSK)
#error "invalid DMA stream associated to UART0 RX"
#endif

#if HS_UART_USE_UART0 &&                                                \
    !HS_DMA_IS_VALID_ID(HS_UART_UART0_TX_DMA_STREAM,                 \
                           HS_UART0_TX_DMA_MSK)
#error "invalid DMA stream associated to UART0 TX"
#endif

#if HS_UART_USE_UART1 &&                                                \
    !HS_DMA_IS_VALID_ID(HS_UART_UART1_RX_DMA_STREAM,                 \
                           HS_UART1_RX_DMA_MSK)
#error "invalid DMA stream associated to UART1 RX"
#endif

#if HS_UART_USE_UART1 &&                                                \
    !HS_DMA_IS_VALID_ID(HS_UART_UART1_TX_DMA_STREAM,                 \
                           HS_UART1_TX_DMA_MSK)
#error "invalid DMA stream associated to UART1 TX"
#endif

#if HS_UART_USE_UART2 &&                                                \
    !HS_DMA_IS_VALID_ID(HS_UART_UART2_RX_DMA_STREAM,                 \
                           HS_UART2_RX_DMA_MSK)
#error "invalid DMA stream associated to UART2 RX"
#endif

#if HS_UART_USE_UART2 &&                                                \
    !HS_DMA_IS_VALID_ID(HS_UART_UART2_TX_DMA_STREAM,                 \
                           HS_UART2_TX_DMA_MSK)
#error "invalid DMA stream associated to UART2 TX"
#endif
#endif /* HS_ADVANCED_DMA */
#endif /* HS_HAS_DMA */

#if !defined(HS_DMA_REQUIRED)
#define HS_DMA_REQUIRED
#endif

/*===========================================================================*/
/* Driver data structures and types.                                         */
/*===========================================================================*/

/**
 * @brief   UART driver condition flags type.
 */
typedef uint32_t uartflags_t;

/**
 * @brief   Structure representing an UART driver.
 */
typedef struct UARTDriver UARTDriver;

/**
 * @brief   Generic UART notification callback type.
 *
 * @param[in] uartp     pointer to the @p UARTDriver object
 */
typedef void (*uartcb_t)(UARTDriver *uartp);

/**
 * @brief   Character received UART notification callback type.
 *
 * @param[in] uartp     pointer to the @p UARTDriver object
 * @param[in] c         received character
 */
typedef void (*uartccb_t)(UARTDriver *uartp, uint16_t c);

/**
 * @brief   Receive error UART notification callback type.
 *
 * @param[in] uartp     pointer to the @p UARTDriver object
 * @param[in] e         receive error mask
 */
typedef void (*uartecb_t)(UARTDriver *uartp, uartflags_t e);

/**
 * @brief   Driver configuration structure.
 * @note    It could be empty on some architectures.
 */
typedef struct {
  /**
   * @brief End of transmission buffer callback.
   */
  uartcb_t                  txend1_cb;
  /**
   * @brief Physical end of transmission callback.
   */
  uartcb_t                  txend2_cb;
  /**
   * @brief Receive buffer filled callback.
   */
  uartcb_t                  rxend_cb;
  /**
   * @brief Character received while out of the @p UART_RECEIVE state.
   */
  uartccb_t                 rxchar_cb;
  /**
   * @brief Receive error callback.
   */
  uartecb_t                 rxerr_cb;
  /* End of the mandatory fields.*/
  /**
   * @brief Bit rate.
   */
  uint32_t                  speed;
  /**
   * @brief Hardware flow control.
   */
  bool_t                    ctsrts;
} UARTConfig;

/**
 * @brief   Structure representing an UART driver.
 */
struct UARTDriver {
  /**
   * @brief Driver state.
   */
  uartstate_t               state;
  /**
   * @brief Transmitter state.
   */
  uarttxstate_t             txstate;
  /**
   * @brief Receiver state.
   */
  uartrxstate_t             rxstate;
  /**
   * @brief Current configuration data.
   */
  const UARTConfig          *config;
#if (UART_USE_WAIT == TRUE) || defined(__DOXYGEN__)
  /**
   * @brief   Synchronization flag for transmit operations.
   */
  bool                      early;
  /**
   * @brief   Waiting thread on RX.
   */
  thread_reference_t        threadrx;
  /**
   * @brief   Waiting thread on TX.
   */
  thread_reference_t        threadtx;
#endif /* UART_USE_WAIT */
#if (UART_USE_MUTUAL_EXCLUSION == TRUE) || defined(__DOXYGEN__)
  /**
   * @brief   Mutex protecting the peripheral.
   */
  mutex_t                   mutex;
#endif /* UART_USE_MUTUAL_EXCLUSION */
#if defined(UART_DRIVER_EXT_FIELDS)
  UART_DRIVER_EXT_FIELDS
#endif
  /* End of the mandatory fields.*/
  /**
   * @brief Pointer to the UART registers block.
   */
  HS_UART_Type             *uart;
  /* Clock frequency for the associated UART.*/
  uint32_t                  clock;
  /* Allow UART to send or not according to MSR.*/
  bool_t                    can_send;
#if HS_UART_USE_DMA
  /* Don't sumbit DMA if DMA is running.*/
  bool_t                    tx_running;
  /**
   * @brief DMA mode bit mask.
   */
  uint32_t                  dmamode;
  /**
   * @brief Receive DMA channel.
   */
  const hs_dma_stream_t  *dmarx;
  /**
   * @brief Transmit DMA channel.
   */
  const hs_dma_stream_t  *dmatx;
#endif
  /**
   * @brief Default receive buffer while into @p UART_RX_IDLE state.
   */
  volatile uint16_t         rxbuf_idle;
  /**
   * @brief Transmit buffer while into @p UART_TX_ACTIVE state.
   */
  const uint8_t            *txbuf;
  /**
   * @brief   Bytes to transmit.
   */
  size_t                    txbuf_size;
  /**
   * @brief   Bytes transmitted.
   */
  size_t                    txbytes;

  /**
   * @brief Receive buffer while into @p UART_RX_ACTIVE state.
   */
  uint8_t                  *rxbuf;
  /**
   * @brief   Size of the receive buffer.
   */
  size_t                    rxbuf_size;
  /**
   * @brief   Bytes received.
   */
  size_t                    rxbytes;
};

/*===========================================================================*/
/* Driver macros.                                                            */
/*===========================================================================*/

/*===========================================================================*/
/* External declarations.                                                    */
/*===========================================================================*/

#if HS_UART_USE_UART0 && !defined(__DOXYGEN__)
extern UARTDriver UARTD0;
#endif

#if HS_UART_USE_UART1 && !defined(__DOXYGEN__)
extern UARTDriver UARTD1;
#endif

#if HS_UART_USE_UART2 && !defined(__DOXYGEN__)
extern UARTDriver UARTD2;
#endif

#ifdef __cplusplus
extern "C" {
#endif
  void uart_lld_init(void);
  void uart_lld_start(UARTDriver *uartp);
  void uart_lld_stop(UARTDriver *uartp);
  void uart_lld_start_send(UARTDriver *uartp, size_t n, const void *txbuf);
  size_t uart_lld_stop_send(UARTDriver *uartp);
  void uart_lld_start_receive(UARTDriver *uartp, size_t n, void *rxbuf);
  size_t uart_lld_stop_receive(UARTDriver *uartp);
#ifdef __cplusplus
}
#endif

#endif /* HAL_USE_UART */

#endif /* HAL_UART_LLD_H */

/** @} */
