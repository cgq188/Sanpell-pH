/*
    ChibiOS/RT - Copyright (C) 2006-2013 Giovanni Di Sirio
                 Copyright (C) 2019 BRMICRO Technologies
                 

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/
/*
   Concepts and parts of this file have been contributed by Uladzimir Pylinsky
   aka barthess.
 */

/**
 * @file    br32xx/rf_lld.c
 * @brief   BR32xx RF subsystem low level driver header.
 *
 * @addtogroup RF
 * @{
 */

#include "hal.h"
#include "chprintf.h"
#include "string.h"

#if HAL_USE_RF || defined(__DOXYGEN__)

#if !defined(HAL_USE_BT)
#define HAL_USE_BT FALSE
#endif

/*===========================================================================*/
/* Driver local definitions.                                                 */
/*===========================================================================*/
#define MAX2829_TX_VGA_GAIN_MAX    0
#define PHY_CFG_MAX2829            0x360162B8
#define PHY_TYPE_MAX2829           0
#define SER_CFG_BR3214             0x019117ED

/*===========================================================================*/
/* Driver exported variables.                                                */
/*===========================================================================*/

/**
 * @brief RF configuration identifier.
 */
 RFConfig MAC6200;

 Rf24gDriver RF24GD;
/*===========================================================================*/
/* Driver local variables and types.                                         */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local functions.                                                   */
/*===========================================================================*/
/**
 * @brief   Select MAC6200 as rf PHY.
 *
 * @notapi
 */
void rf_lld_Select_MAC6200(void)
{
  cpmEnableBTPHY();
  HS_MAC6200->SPIRCON |= RF_MAC_SELECT;
}

/**
 * @brief   Change RF's SPI CSN to high.
 *
 * @notapi
 */
void rf_lld_CSN_High(void)  
{
  HS_MAC6200->RFCON |= RF_CSN;
}

/**
 * @brief   Change RF's SPI CSN to low.
 *
 * @notapi
 */
void rf_lld_CSN_Low(void) 
{
  HS_MAC6200->RFCON &= ~RF_CSN;
}

/**
 * @brief   Change CE to high.
 *
 * @notapi
 */
void rf_lld_CE_High(void)
{
  HS_MAC6200->RFCON |= RF_CE;
}

/**
 * @brief   Change CE to low.
 *
 * @notapi
 */
void rf_lld_CE_Low()
{
  HS_MAC6200->RFCON &= ~RF_CE;
}

/**
 * @brief  generate a CE high pulse.
 *
 * @notapi
 */
void rf_lld_CE_high_pulse(void)  
{                          
  rf_lld_CE_High();            
  osalThreadSleepMicroseconds(20);  
  rf_lld_CE_Low();          
}

/**
 * @brief  RFSPI write/read 1 Byte to/from RF .
 *
 * @notapi
 */
static uint8_t RF_SPI_WR_Byte_Poll(uint8_t Byte)
{
    while(!(HS_MAC6200->SPIRSTAT & RF_TXFIFO_READY));      //Tx Fifo not ready.
    HS_MAC6200->SPIRDAT=Byte;
    while(!(HS_MAC6200->SPIRSTAT & RF_RXDATA_READY));      //Rx Fifo has data.
    return HS_MAC6200->SPIRDAT;
}


/*===========================================================================*/
/* Driver exported functions.                                                */
/*===========================================================================*/

/**
 * @brief   RF Write register.
 *
 * @notapi
 */
void rf_lld_Wr_Reg(uint8_t Reg, uint8_t *Reg_val, uint8_t len)
{
  uint8_t i;
  
  rf_lld_CSN_Low(); 
  RF_SPI_WR_Byte_Poll(MAC6200_W_REGISTER+Reg);
  for(i=0; i<len; i++) {
    RF_SPI_WR_Byte_Poll(*Reg_val++);  
  }
  rf_lld_CSN_High();  
}

/**
 * @brief   RF Write register.
 *
 * @notapi
 */
void rf_lld_Rd_Reg(uint8_t Reg, uint8_t *Reg_val, uint8_t len)
{
  uint8_t i;
  
  rf_lld_CSN_Low(); 
  RF_SPI_WR_Byte_Poll(MAC6200_R_REGISTER+Reg);
  for(i=0; i<len; i++) {
    Reg_val[i] = RF_SPI_WR_Byte_Poll(0x00);  
  }
  rf_lld_CSN_High();  
}


/**
 * @brief  switch bank0.
 *
 * @notapi
 */
void rf_lld_Bank0_Activate(void)
{
  uint8_t status;
  
  rf_lld_Rd_Reg(MAC6200_BANK0_STATUS, &status, 0x01);
  if((status & MAC6200_BANK_BIT) == MAC6200_BANK1){
    rf_lld_CSN_Low(); 
    RF_SPI_WR_Byte_Poll(MAC6200_ACTIVATE);
    RF_SPI_WR_Byte_Poll(0x53);
    rf_lld_CSN_High(); 
  }
}

/**
 * @brief  switch bank1.
 *
 * @notapi
 */
void rf_lld_Bank1_Activate(void)
{
  uint8_t status;
  
  rf_lld_Rd_Reg(MAC6200_BANK0_STATUS, &status, 0x01);
  if((status & MAC6200_BANK_BIT) == MAC6200_BANK0){
    rf_lld_CSN_Low(); 
    RF_SPI_WR_Byte_Poll(MAC6200_ACTIVATE);
    RF_SPI_WR_Byte_Poll(0x53);
    rf_lld_CSN_High(); 
  }
}


void rf_lld_Read_Rx_Payload(uint8_t *pBuf, uint8_t bytes)
{
  uint8_t i;
  rf_lld_CSN_Low();   //���� 
  RF_SPI_WR_Byte_Poll(MAC6200_R_RX_PAYLOAD);
  for(i=0x00;i<bytes;i++)	pBuf[i] = RF_SPI_WR_Byte_Poll(0x00);
  rf_lld_CE_High();
}

void rf_lld_Write_Tx_Payload(uint8_t *pBuf, uint8_t bytes)
{
  uint8_t i;
  rf_lld_CSN_Low();   //����
  RF_SPI_WR_Byte_Poll(MAC6200_W_TX_PAYLOAD);
  for(i=0x00;i<bytes;i++)
  {
    RF_SPI_WR_Byte_Poll(pBuf[i]);
  }
  rf_lld_CSN_High();	
}

void rf_lld_Flush_Tx_Fifo(void)
{
  rf_lld_CSN_Low();   //����
  RF_SPI_WR_Byte_Poll(MAC6200_FLUSH_TX);    // send command
  rf_lld_CSN_High();                   // CSN high again
}

void rf_lld_Flush_Rx_Fifo(void)
{
  rf_lld_CSN_Low();   //����
  RF_SPI_WR_Byte_Poll(MAC6200_FLUSH_RX);    // send command
  rf_lld_CSN_High();                   // CSN high again
}

uint8_t rf_lld_Read_Rx_Payload_Width(void)
{
  uint8_t Width;
  rf_lld_CSN_Low();   //����
  RF_SPI_WR_Byte_Poll(MAC6200_R_RX_PL_WID); 	
  Width=RF_SPI_WR_Byte_Poll(0x00);
  rf_lld_CSN_High();
  return Width; 
}

void rf_lld_Write_Ack_Payload(uint8_t PipeNum, uint8_t *pBuf, uint8_t bytes)
{
    uint8_t byte_ctr;
    rf_lld_CSN_Low();   //����
    RF_SPI_WR_Byte_Poll(MAC6200_W_ACK_PAYLOAD | PipeNum); 
    for(byte_ctr=0; byte_ctr<bytes; byte_ctr++)	   // then write all byte in buffer(*pBuf)
    {                          
       RF_SPI_WR_Byte_Poll(*pBuf++);
    }
    rf_lld_CSN_High();
}

void rf_lld_Write_Tx_Payload_No_Ack(uint8_t *pBuf, uint8_t bytes)
{
  uint8_t byte_ctr;
  rf_lld_CSN_Low();   //����
  RF_SPI_WR_Byte_Poll(MAC6200_W_TX_PAYLOAD_NOACK); 	 
  for(byte_ctr=0; byte_ctr<bytes; byte_ctr++) // then write all byte in buffer(*pBuf)
  {                          
    RF_SPI_WR_Byte_Poll(*pBuf++);
  }
  rf_lld_CSN_High();			
}

uint8_t rf_lld_Nop(void)
{
  uint8_t status;
  rf_lld_CSN_Low();
  status = RF_SPI_WR_Byte_Poll(MAC6200_NOP);
  rf_lld_CSN_High();
  return (status); 
}

void rf_lld_Set_Addr_Width(uint8_t Addr_Width)
{
  uint8_t Temp;
  switch (Addr_Width)
  {
  //    case 0x03:       //Not support 3 Bytes
  //        Temp=MAC6200_AW_3_BYTES;
  //	break;
    case 0x04:
        Temp=MAC6200_AW_4_BYTES;
    break;
    case 0x05:
        Temp=MAC6200_AW_5_BYTES;
    break;
    default:
        Temp=0x00;
    break;
  }	
  rf_lld_Wr_Reg(MAC6200_BANK0_SETUP_AW,&Temp,1);
}

void rf_lld_Write_Pipe_Addr(uint8_t Px_Addr_Reg, uint8_t *pPipeAddr, uint8_t Addr_Width)
{
  uint8_t byte_ctr; 
  
  rf_lld_CSN_Low();                                      // CSN low, init SPI transaction
  RF_SPI_WR_Byte_Poll(MAC6200_W_REGISTER + Px_Addr_Reg); // Select register to write to and read status byte
  for(byte_ctr=0; byte_ctr<Addr_Width; byte_ctr++)       // then write all byte in buffer(*pBuf)
      RF_SPI_WR_Byte_Poll(*pPipeAddr++);
  rf_lld_CSN_High();                                     // CSN high again                                                           
}

void rf_lld_Read_Pipe_Addr(uint8_t Px_Addr_Reg, uint8_t *pPipeAddr, uint8_t Addr_Width)
{
  uint8_t byte_ctr;
  
  rf_lld_CSN_Low();                                     // CSN low, init SPI transaction
  RF_SPI_WR_Byte_Poll(MAC6200_R_REGISTER + Px_Addr_Reg);// Select register to write to and read status byte
  for(byte_ctr=0; byte_ctr<Addr_Width; byte_ctr++)      // then write all byte in buffer(*pBuf)
      *pPipeAddr++=RF_SPI_WR_Byte_Poll(0x00);
  rf_lld_CSN_High();                                     // CSN high again                                                          
}

uint8_t rf_lld_Is_Auto_Ack_Px(uint8_t Pipe)
{
  uint8_t Temp;
  Temp=0x00;
  rf_lld_Rd_Reg(MAC6200_BANK0_EN_AA,&Temp,1); 
  Temp=Temp & (1<<Pipe);
  return Temp;
}


uint8_t rf_lld_Is_Dyn_Ack_Feature(void)
{
  uint8_t Temp;
  rf_lld_Rd_Reg(MAC6200_BANK0_FEATURE,&Temp,1);
  return  (Temp&0x01);
}

uint8_t rf_lld_Is_DPL_Feature(void)   //�ж��Ƿ��Ƕ���
{
  uint8_t Temp;
  rf_lld_Rd_Reg(MAC6200_BANK0_FEATURE,&Temp,1);
  return  (Temp&0x04);	
}

uint8_t rf_lld_Read_Rx_Pipe_Static_Payload_Width(uint8_t Pipe_Num)
{
  uint8_t Temp;
  rf_lld_Rd_Reg(MAC6200_BANK0_RX_PW_P0+Pipe_Num,&Temp,1);
  return Temp;
}

bool rf_lld_Is_PRX(void)
{
  uint8_t temp;
  
  rf_lld_Rd_Reg(MAC6200_BANK0_CONFIG, &temp, 1);
  if(temp&MAC6200_PRX)
    return TRUE;
  else 
    return FALSE;
}

static RFAddress RFAddr_5Bytes = {
  .Addr_len = 5,
  .Addr[0]  = 0x46,
  .Addr[1]  = 0x0b,
  .Addr[2]  = 0xaf,
  .Addr[3]  = 0x43,
  .Addr[4]  = 0x98,
};

/**
 * @brief   Driver default configuration.
 */
static RFConfig default_config = {
  &RFAddr_5Bytes,
  RF_POWER_5dBm,
  RF_DR_1Mbps,
  COMROLE_PRX,
  2402,
};

/** @brief Input buffer for 2.4G RF.*/
 uint8_t rf24g_in_buf[RF24G_BUFFERS_SIZE];

/** @brief Output buffer for 2.4G RF.*/
 uint8_t rf24g_out_buf[RF24G_BUFFERS_SIZE];

/**
 * @brief   Low level 2.4G rf driver initialization.
 *
 * @notapi
 */
void rf24g_lld_init(void) {
	rf24gObjectInit(&RF24GD, NULL, NULL);
}

/**
 * @brief   Low level 2.4G rf driver configuration and (re)start.
 *
 * @param[in] rf24gp       pointer to a @p 2.4G rfDriver object
 * @param[in] config    the architecture-dependent 2.4G rf driver configuration.
 *                      If this parameter is set to @p NULL then a default
 *                      configuration is used.
 *
 * @notapi
 */
void rf24g_lld_start(Rf24gDriver *rf24gp){

  if (rf24gp->state == RF24G_STOP) {
    /* Enables the peripheral.*/
      /* locked in the upper layer, in 2.4G rf.c */
      osalSysUnlock();
      rf24gp->ib = rf24g_in_buf;
      rf24gp->ob = rf24g_out_buf;
      iqObjectInit(&rf24gp->iqueue, rf24gp->ib, 64, NULL, rf24gp);
      oqObjectInit(&rf24gp->oqueue, rf24gp->ob, 64, NULL, rf24gp);
      osalSysLock();
   }

  if (rf24gp->config == NULL)
	  rf24gp->config = &default_config;

  nvicEnableVector(MAC6200_RF_IRQn, ANDES_PRIORITY_MASK(HS_RF_INTR_PRIORITY));
  /* Configures the peripheral.*/
  rf_2p4G_init(rf24gp->config->pAddr->Addr, rf24gp->config->pAddr->Addr_len, rf24gp->config->DataRate,  rf24gp->config->Channel);
  rf24gp->can_send = TRUE;
  rf24gp->state = RF24G_READY;
}

/**
 * @brief   Low level 2.4G rf driver stop.
 * @details De-initializes the UART, stops the associated clock, resets the
 *          interrupt vector.
 *
 * @param[in] rf24gp       pointer to a @p 2.4G rfDriver object
 *
 * @notapi
 */
void rf24g_lld_stop(Rf24gDriver *rf24gp) {

  if (rf24gp->state == RF24G_READY) {

	  rf24gp->state = RF24G_STOP;
	  rf24gp->can_send = FALSE;
	  iqResetI(&rf24gp->iqueue);
    /* Disables the peripheral.*/
      oqResetI(&rf24gp->oqueue);

      nvicDisableVector(MAC6200_RF_IRQn);
//      cpmDisableBTPHY();
      return;
    }

}

/*===========================================================================*/
/* Driver interrupt handlers.                                                */
/*===========================================================================*/
/**
 * @brief   RF interrupt handler.
 *
 * @isr
 */
 uint8_t count[100] = {0};
 uint8_t idx = 0;
static void MAC6200_serve_interrupt(void)
{
  uint8_t RF_Status;

  Rf24gDriver *rf24gp = &RF24GD;
  rf_lld_CE_Low();
  rf_lld_Rd_Reg(MAC6200_BANK0_STATUS, (uint8_t *)&RF_Status, 1); //read RF status register
  /* clear interrupt */
  rf_lld_Wr_Reg(MAC6200_BANK0_STATUS, &RF_Status, 1);

  if(RF_Status & MAC6200_RX_DR)
  {
	uint8_t len = 0;
	uint8_t buf[RF_MAX_PAYLOAD_LEN];
	uint8_t i=0;

	len =  rf_lld_Read_Rx_Payload_Width();

	if((len <= RF_MAX_PAYLOAD_LEN) && (len > 0))
	{
		rf_lld_Read_Rx_Payload(buf, len);

		rf_lld_Flush_Rx_Fifo();

		if((len == 4) && (buf[0] == 0xaa) &&  (buf[1] == 0xaa) &&  (buf[2] == 0x55) &&  (buf[3] == 0x55))
		{
		  	rf_lld_CE_High();
		}
		else
		{
			osalSysLockFromISR();
			if (iqIsEmptyI(&rf24gp->iqueue))
			chnAddFlagsI(rf24gp, CHN_INPUT_AVAILABLE);
			osalSysUnlockFromISR();
			while (len--) {
				osalSysLockFromISR();
				if (iqPutI(&rf24gp->iqueue, buf[i++]) < Q_OK)
				  chnAddFlagsI(rf24gp, RF24G_OVERRUN_ERROR);
				osalSysUnlockFromISR();
			}
		}
	}
	else
	{
		rf_lld_Flush_Rx_Fifo();
	}

    uint8_t fifo_status = 0;
rf_write_tx_payload:

	rf_lld_Rd_Reg(MAC6200_BANK0_FIFO_STATUS, &fifo_status, 1);
	if(!(fifo_status & MAC6200_FIFO_STATUS_TX_FULL))
	{
		if (!oqIsEmptyI(&rf24gp->oqueue)) {

		i = 0;
		buf[0] = 0x5a;
		do {
			msg_t b;

			osalSysLockFromISR();
			b = oqGetI(&rf24gp->oqueue);
			osalSysUnlockFromISR();
			if (b < Q_OK) {
			  osalSysLockFromISR();
			  chnAddFlagsI(rf24gp, CHN_OUTPUT_EMPTY);
			  osalSysUnlockFromISR();
			  break;
			}

			buf[++i] = b;
			if(i==31)
			{
				buf[0] = 0xa5;
				break;
			}


		   } while (1);

		   rf_lld_Write_Ack_Payload(0, buf, i+1);
		   if(i==31)
			   goto rf_write_tx_payload;
		}

	}

  	rf_lld_CE_High();
  }
#if 0
  else if(RF_Status & MAC6200_TX_DS)
  {
	  uint8_t i=0;
	  uint8_t buf[RF_MAX_PAYLOAD_LEN];

      /* allows send */
      if (rf24gp->can_send) {
    	do {
        msg_t b;

        osalSysLockFromISR();
        b = oqGetI(&rf24gp->oqueue);
        osalSysUnlockFromISR();
        if (b < Q_OK) {
          osalSysLockFromISR();
          chnAddFlagsI(rf24gp, CHN_OUTPUT_EMPTY);
          osalSysUnlockFromISR();
          break;
        }

        buf[i++] = b;
        if(i>=RF_MAX_PAYLOAD_LEN)
           break;
      } while (1);
      rf_lld_Write_Tx_Payload(buf, i);
      rf_lld_CE_high_pulse();
    }
  }
  else if(RF_Status & MAC6200_MAX_RT)
  {

  }
#endif
}

OSAL_IRQ_HANDLER(MAC6200_RF_IRQHandler) {

  OSAL_IRQ_PROLOGUE();
  MAC6200_serve_interrupt();
  OSAL_IRQ_EPILOGUE();
}


/**
 * @brief   RF interrupt handler.
 *
 * @isr
 */
OSAL_IRQ_HANDLER(MAC6200_SPI_IRQHandler)
{
  OSAL_IRQ_PROLOGUE();

  /* Mask of all enabled and pending sources.*/
  HS_MAC6200->ICR |= RF_ICR;   //clear spi interrupt
  OSAL_IRQ_EPILOGUE();
}

#if (HAL_USE_BT == TRUE)
extern void HWradio_Initialise(void);

void BR3215_mac6200_init(void)
{
  HS_BTPHY->SPI_APB_SWITCH=0;

  HWradio_Initialise();

  HS_BTPHY->IF_REG = 0x300; //0x300=750k for bt & rf62; 0x80=125k for fm
  HS_ANA->INTER_FREQ = 0x340000; //0x340000=750k for bt & rf62 on analog

  HS_BTPHY->SPI_APB_SWITCH=1;
}

#else
//---------------------------------------------------------

/*******************************************************************************
 * The following is a define the location of GIO lines in the MAX2829
 *
 * GIO 0   used to control TXENA of MAX2829.
 * GIO 1   used to control RXENA of MAX2829.
 * GIO 2   used to control #SHDN of MAX2829.
 *
 * GIO 6   used to control TXENA in page/inquiry mode
 * GIO 7   used to control RXENA in page/inquiry mode
 *
 *******************************************************************************/
#define GIO_HIGH_TXENA                         0x40018030
#define GIO_LOW_TXENA                          0x40018048
#define GIO_OVERRIDE_MASK_TXENA                0x00008000
#define GIO_TXENA_MASK                         0xFFFF0000

#define GIO_HIGH_RXENA                         0x40018030
#define GIO_LOW_RXENA                          0x40018048
#define GIO_OVERRIDE_MASK_RXENA                0x80000000
#define GIO_RXENA_MASK                         0x0000FFFF


#define GIO_HIGH_SHDN                          0x40018034
#define GIO_LOW_SHDN                           0x4001804C
#define GIO_OVERRIDE_MASK_SHDN                 0x00008000
#define GIO_SHDN_MASK                          0xFFFF0000


#define GIO_HIGH_TXENA_PAGE                    0x4001803C
#define GIO_LOW_TXENA_PAGE                     0x40018054
#define GIO_OVERRIDE_MASK_TXENA_PAGE           0x00008000
#define GIO_TXENA_PAGE_MASK                    0xFFFF0000

#define GIO_HIGH_RXENA_PAGE                    0x4001803C
#define GIO_LOW_RXENA_PAGE                     0x40018054
#define GIO_OVERRIDE_MASK_RXENA_PAGE           0x80000000
#define GIO_RXENA_PAGE_MASK                    0x0000FFFF

#define HWradio_SetOverrideLow(GIO_NAME)  do { \
    *((volatile unsigned int*)GIO_LOW_##GIO_NAME) |= GIO_OVERRIDE_MASK_##GIO_NAME; \
    *((volatile unsigned int*)GIO_HIGH_##GIO_NAME) &= ~(GIO_OVERRIDE_MASK_##GIO_NAME); \
    }while(0)

#define HWradio_SetOverrideHigh(GIO_NAME)  do { \
    *((volatile unsigned int*)GIO_HIGH_##GIO_NAME) |= GIO_OVERRIDE_MASK_##GIO_NAME; \
    *((volatile unsigned int*)GIO_LOW_##GIO_NAME) &= ~(GIO_OVERRIDE_MASK_##GIO_NAME); \
    }while(0)

#define HWradio_SetGIOLowReg(GIO_NAME, value) \
     *((volatile unsigned int*)GIO_LOW_##GIO_NAME) = ((*((volatile unsigned int*)GIO_LOW_##GIO_NAME))  & (GIO_##GIO_NAME##_MASK))| (value)

#define HWradio_SetGIOHighReg(GIO_NAME, value) \
     *((volatile unsigned int*)GIO_HIGH_##GIO_NAME) = ((*((volatile unsigned int*)GIO_HIGH_##GIO_NAME)) & (GIO_##GIO_NAME##_MASK)) | (value)

#define READ_REG_BR3215(n)        ( 0x08000000 | (0<<28) | ((n)<<19) )
#define WRITE_REG_BR3215(n,val)   ( 0x88000000 | (1<<28) | ((n)<<19) | ((val)<<0) )

struct CfgBtHcRfStru
{
    uint8_t phy_type;
    uint8_t debug_mode;
#define RADIO_DEBUG_RXENA_GIO  (0 << 0)
#define RADIO_DEBUG_RXENA_SPI  (1 << 0)
#define RADIO_DEBUG_INTRA_SLOT (1 << 1)
//#define RADIO_DEBUG_CPM_RST_EN (1 << 2)   /*reset CPM when host send HCI_Reset command*/
#define RADIO_DEBUG_TX_CARRIER (1 << 2)
#define RADIO_DEBUG_CALI_RC    (1 << 3)
#define RADIO_DEBUG_CALI_RX    (1 << 4)
#define RADIO_DEBUG_CALI_TX    (1 << 5)
#define RADIO_DEBUG_CALI_AFC   (1 << 6)
#define RADIO_DEBUG_CALI_VCO   (1 << 7)
    uint16_t debug_mon_id;
    uint32_t hw_hab_phy_cfg_word;
    uint32_t ser_eser_cfg_word;

    uint16_t jal_le_ser_eser_tx_time;
    uint16_t jal_le_ser_eser_rx_time;

    /* initialize PHY delays in ms */
    uint8_t osc_startup_time;
    uint8_t phy_startup_delay1;
    uint8_t phy_startup_delay2;
    uint8_t phy_startup_delay3;

    /* radio timing in us */
    uint8_t hw_radio_pll_time;  //T1: PLL for TX and RX
    uint8_t hw_radio_ldo_time;  //T2: LDO, DAC, Up-Mixer for TX; LDO, LNA, Filter, CTSDM for RX
    uint8_t hw_radio_pa_time;   //T3: PA for TX
    uint8_t hw_radio_ramp_time; //T4, T5: Ramp up or Ramp down for TX (1~2us)

    /* input 0, calculate the times above */
    uint8_t hw_radio_tx_setup_time;     //T1+T2+T3+T4
    uint8_t hw_radio_tx_hold_time;      //T5
    uint8_t hw_radio_rx_setup_time;     //T1+T2
    uint8_t hw_radio_rx_hold_time;      //0

    /* input for le timing */
    uint8_t hw_radio_le_tx_setup_time;
    uint8_t hw_radio_le_tx_hold_time;
    uint8_t hw_radio_le_rx_setup_time;
    uint8_t hw_radio_le_rx_hold_time;

    uint8_t hw_radio_tx_tab_delay;
    uint8_t hw_radio_rx_tab_delay;      //including BRMICRO's digital delay
    uint8_t hw_radio_tx_phy_delay;
    uint8_t hw_radio_rx_phy_delay;

    uint8_t edr_tx_edr_delay;
    uint8_t edr_rx_edr_delay;
    uint8_t le_tifs_delay;
    uint8_t le_search_win_delay;

    uint8_t cor;
    uint8_t le_cor;
    uint8_t win_ext;                    //static win_ext for classic
    uint8_t le_win_ext;

    int8_t  rx_golden_rssi_min;
    int8_t  rx_golden_rssi_max;
    int8_t  rssi_adjust;
    uint8_t rssi_mode; //bit7: 0-late  1-early

    uint8_t low_power;

#define DEEP_SLEEP_STOP_BT_24M_CLK        (1<<0)    /*24MHz clock*/
#define DEEP_SLEEP_STOP_PLL               (1<<1)    /*stop pll*/
#define DEEP_SLEEP_DOWN_CPU_CORE_VOLATGE  (1<<2)    /*down CPU core voltage*/
#define DEEP_SLEEP_GATE_BTPHY_APB_CLOCK   (1<<3)    /*gate btphy apb clock*/
#define DEEP_SLEEP_POWER_DOWN_ADC         (1<<4)    /*power down adc*/

    uint8_t rsv4;
    uint8_t epc_max_tx_power_difference;
    uint8_t epc_max_tx_power_threshold;

    int8_t  tx_power_level_min;
    int8_t  tx_power_level_max;
    uint8_t tx_power_level_units; //Class 1: 25 levels, Class 2: 17 levels, Class 3: 15 levels
    uint8_t tx_power_level_step;  //min: 2dB, max: 8dB

    uint8_t power_ctrl_tab[32];
    int8_t  power_ctrl_tab_dBm[32];

#if 1
    /* AFH */
    uint8_t afh_channel_bit_vector[10];
    uint8_t rsv5;
    uint8_t afh_n_min_used_channels;

    /* scan */
    uint16_t inq_scan_interval;  /* scan interval */
    uint16_t inq_scan_window;    /* scan activity window */
    uint16_t page_scan_interval; /* scan interval */
    uint16_t page_scan_window;   /* scan activity window */

    /*RF calibration parameter*/
    uint16_t tx_loft_sample_times;
    uint16_t tx_gain_sample_times;
    uint16_t tx_phase_sample_times;
    uint16_t rx_phase_sample_times;
    uint16_t agc_calibration_wait_time;

    /*low power - halt system parameter*/
    uint8_t cpu_low_power_divider;
    uint8_t apb_low_power_divider;
    uint16_t cpu_core_vol_reg;

#define HALT_SYSTEM_CPM_USB      (1<<0)
#define HALT_SYSTEM_CPM_SDHC     (1<<1)
#define HALT_SYSTEM_CPM_TIM0     (1<<2)
#define HALT_SYSTEM_CPM_TIM1     (1<<3)
#define HALT_SYSTEM_CPM_TIM2     (1<<4)
#define HALT_SYSTEM_CPM_UART0    (1<<5)
#define HALT_SYSTEM_CPM_UART1    (1<<6)
#define HALT_SYSTEM_CPM_SPI0     (1<<7)
#define HALT_SYSTEM_CPM_SPI1     (1<<8)
#define HALT_SYSTEM_CPM_I2S      (1<<9)
#define HALT_SYSTEM_CPM_DMA      (1<<10)

    uint16_t halt_system_cpm_dis_xxx;    //halt system gate xxx clock.
    uint16_t halt_system_cpm_en_xxx;

    uint16_t rsv6[79*4 - 12/2 - 4 - 9];
#else
    uint16_t tx_freq_int_reg[79];
    uint16_t tx_freq_fra_reg[79];
    uint16_t rx_freq_int_reg[79];
    uint16_t rx_freq_fra_reg[79];
#endif

    //RC calibration parameter
    uint16_t rc_counter;     //total RC calibration counters
    uint16_t rx_adc_t1_t2[16];    // rc value of rxadc. from max to min,and the corresponding tune from min->max
    uint16_t tx_dac_t1_t2[16];    // rc value of txdac
    uint16_t rx_filter_t1_t2[8];  // rc value of rx filter
};

struct CfgBtHcRfStru g_sys_rf_cfg = // expose it to cmd_btrf.c
{
    /* common settings for max2829 & br3214 */
    .debug_mode                   =RADIO_DEBUG_CALI_VCO | RADIO_DEBUG_CALI_AFC | RADIO_DEBUG_CALI_RX | RADIO_DEBUG_CALI_TX | RADIO_DEBUG_CALI_RC,
    .debug_mon_id                 =0x135, //DEBUG_MBUS_BTPHY | BB_5

    /*
     * same time for Configure_LE_Spi_For_TxRx_Times()
     *   time = roundup((setup - 75) / 4) = ((87+16)-75)/4 = 7
     */
    .jal_le_ser_eser_tx_time      =0xA980,
    .jal_le_ser_eser_rx_time      =0xA980,

    .osc_startup_time             =10,
    .phy_startup_delay1           =30,
    .phy_startup_delay2           =30,
    .phy_startup_delay3           =250,

    .hw_radio_pll_time            =80,
    .hw_radio_ldo_time            =8,
    .hw_radio_pa_time             =8,
    .hw_radio_ramp_time           =2,

    /* 10us time slipping for rx window */
    .hw_radio_tx_setup_time       =0,
    .hw_radio_tx_hold_time        =0,
    .hw_radio_rx_setup_time       =0,
    .hw_radio_rx_hold_time        =0,

    /* individual LE timing */
    .hw_radio_le_tx_setup_time    =26, //tifs_delay?
    .hw_radio_le_tx_hold_time     =20,
    .hw_radio_le_rx_setup_time    =40, //search_win?
    .hw_radio_le_rx_hold_time     =20,

    .hw_radio_tx_tab_delay        =3,
    .hw_radio_tx_phy_delay        =0,
    .hw_radio_rx_tab_delay        =14,
    .hw_radio_rx_phy_delay        =2,

    .edr_tx_edr_delay             =2,
    .edr_rx_edr_delay             =14, //14=0xe=-2
    .le_tifs_delay                =31,
    .le_search_win_delay          =50,

    .cor                          =7, //HWhab_Set_Sync_Error(7) for Classic
    .le_cor                       =3, //0: BQB
    .le_win_ext                   =0,

    .rssi_mode                    =0x80, //bit7: 1-early 0-late, bit6:rssi_adjust_en, bit[5:4]: save_mode  bit[3:0]: timeout
    .low_power                    =0,  //SYS_LF_OSCILLATOR_PRESENT
    .rsv4                         =0,
    .epc_max_tx_power_difference  =10, //EPC_MAX_TX_POWER_DIFFERENC
    .epc_max_tx_power_threshold   =8,  //EPC_REQ_MAX_TX_POWER_THRESHOLD

    //RC calibration
    //please refer to BR3214_RF shu_mo_jie_kou_v1.1_20150115.pdf
    .rc_counter                   =5,
#if defined(BR32xx_FPGA)
    .rx_adc_t1_t2                 ={356, 346, 335, 324, 313, 302, 292, 281, 270, 259, 248, 238, 227, 216, 205, 194},
    .tx_dac_t1_t2                 ={378, 360, 342, 324, 306, 288, 270, 252, 234, 216, 198, 180, 162, 144, 126, 108},
    .rx_filter_t1_t2              ={360, 330, 300, 270, 240, 210, 180, 150},
#else
    .rx_adc_t1_t2                 ={712, 692, 670, 648, 626, 604, 584, 582, 540, 518, 496, 476, 454, 432, 410, 388},
    .tx_dac_t1_t2                 ={756, 720, 684, 648, 612, 576, 540, 504, 468, 432, 396, 360, 324, 288, 252, 216},
    .rx_filter_t1_t2              ={720, 660, 600, 540, 480, 420, 360, 300},
#endif
#if defined(BR32xx_FPGA)
    .phy_type                     =PHY_TYPE_MAX2829,
    .hw_hab_phy_cfg_word          =PHY_CFG_MAX2829,
    .ser_eser_cfg_word            =SER_CFG_BR3214,//MAX2829,

    .rx_golden_rssi_min           =-56, //0: return rawRSSI
    .rx_golden_rssi_max           =-30,
    .rssi_adjust                  =-20,

    .tx_power_level_min           =-30, //TX_POWER_LEVEL_Pmin
    .tx_power_level_max           =0,   //TX_POWER_LEVEL_Pmax
    .tx_power_level_units         =6,   //HW_RADIO_MAX_TX_POWER_LEVEL 7 levels
    .tx_power_level_step          =5,   //HW_RADIO_TX_POWER_STEP_SIZE 5dBm

    .power_ctrl_tab               ={0x00,0x0C,0x16,0x20,0x2A,0x35,0x3F},
    .power_ctrl_tab_dBm           ={MAX2829_TX_VGA_GAIN_MAX-30, MAX2829_TX_VGA_GAIN_MAX-25, MAX2829_TX_VGA_GAIN_MAX-20,
                                    MAX2829_TX_VGA_GAIN_MAX-15, MAX2829_TX_VGA_GAIN_MAX-10, MAX2829_TX_VGA_GAIN_MAX-5,
                                    MAX2829_TX_VGA_GAIN_MAX-0},

    //.tx_freq_int_reg              ={FREQ_INT_IF0},
    //.tx_freq_fra_reg              ={FREQ_FRA_IF0},
    //.rx_freq_int_reg              ={FREQ_INT_IF750k},
    //.rx_freq_fra_reg              ={FREQ_FRA_IF750k},
#else /* #if defined(BR32xx_FPGA) */
//    .phy_type                     =PHY_TYPE_BR3214,
//    .hw_hab_phy_cfg_word          =PHY_CFG_BR3214,
//    .ser_eser_cfg_word            =SER_CFG_BR3214,
    .rx_golden_rssi_min           =-56,
    .rx_golden_rssi_max           =-30,
    .rssi_adjust                  =0,

    .tx_power_level_min           =-28, //TX_POWER_LEVEL_Pmin
    .tx_power_level_max           =0,   //TX_POWER_LEVEL_Pmax
    .tx_power_level_units         =7,   //HW_RADIO_MAX_TX_POWER_LEVEL 11 levels
    .tx_power_level_step          =4,   //HW_RADIO_TX_POWER_STEP_SIZE 4dBm

    .power_ctrl_tab               ={0x0E,0x0C,0x0A,0x08,0x06,0x04,0x02,0x00,0x11,0x22,0x20 },    // (PA config << 4) + PGA config.
    .power_ctrl_tab_dBm           ={-28, -24, -20, -16, -12, -8, -4, 0, 4, 8, 12},
#endif /* #if defined(BR32xx_FPGA) */
    .afh_channel_bit_vector       ={0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0x7F},
    .afh_n_min_used_channels      =19,

    .inq_scan_interval            =0x0800, /* even, 1.28 Seconds */
    .inq_scan_window              =0x0020, /* 0x12 -> 0x20 */
    .page_scan_interval           =0x0800, /* even, 1.28 Seconds */
    .page_scan_window             =0x0020, /* 0x12 -> 0x20 */

    /*RF calibration parameters*/
    .tx_loft_sample_times         = 3000,
    .tx_gain_sample_times         = 1000,
    .tx_phase_sample_times        = 1000,
    .rx_phase_sample_times        = 3000,

    /*low power - halt system parameter*/
    .cpu_low_power_divider        = 8,
    .apb_low_power_divider        = 8,
    .cpu_core_vol_reg             = 0xad54,     //cpu core @1.1v
    .halt_system_cpm_dis_xxx      = 0x7FF,
    .halt_system_cpm_en_xxx       = 0x7FC,
};

/* 1. VCO amplitude and AFC calibration */
static void _BR3215_VCO_AFC_Calibration(void)
{
  /* fixed agc dead when calibration after disconnecting the connection. */
  //SPI mode:
  //HS_BTPHY->ANALOGUE[0x30] |= (1<<6);    //[6]rx_end: w1 trigger to end rx fsm when rxen is spi mode
  //GIO mode: TXENA=0 RXENA=0
  HWradio_SetGIOLowReg(TXENA,0x8000);
  HWradio_SetGIOLowReg(RXENA,0x8000);
  HWradio_SetGIOLowReg(TXENA_PAGE,0x8000);
  HWradio_SetGIOLowReg(RXENA_PAGE,0x8000);
  HWradio_SetGIOHighReg(TXENA,0x0000);
  HWradio_SetGIOHighReg(RXENA,0x0000);
  HWradio_SetGIOHighReg(TXENA_PAGE,0x0000);
  HWradio_SetGIOHighReg(RXENA_PAGE,0x0000);

#if defined(__nds32__)
  /* test PLL feedback output */
  //HS_ANA->REGS.RF_PLL_TEST = 0;
  //HS_ANA->COMMON_CFG[1] = (HS_ANA->COMMON_CFG[1] & ~(0x7 << 20)) | (2 << 20); //[22:20]tst_digi_ctrl: 2=rf_pll; 4=sys_pll; 1=fm_pll

  //set RF DCOC lut to 0, not random value.
  memset((void *)&HS_ANA->DCOC_LUT_REG[0], 0x00, 51*4);
  cpm_delay_us(500);

  //HS_BTPHY->ANALOGUE[0x6E] &= ~((1<<7)+(1<<8));    //reg<232:231> vref_vc_det: b'00=, cp randge?
  //HS_BTPHY->ANALOGUE[0x6F] = (HS_BTPHY->ANALOGUE[0x6F] & 0x9FFF) | (0<<13) | (1<<14);    //reg<254:253> con_ldo_cp: b'10=
//HS_ANA->REGS.VREF_VC_DET = 0x0;
//HS_ANA->REGS.CON_LDO_CP  = 0x1;

  /* wangxin's AGC settings on 2016.09.23 */
  HS_ANA->FILT_AGC_LUT_REG[0] = 0x00000000;
  HS_ANA->FILT_AGC_LUT_REG[1] = 0x00000000;
  HS_ANA->IF_AGC_LUT_REG[0]   = 0x00000000;
  HS_ANA->IF_AGC_LUT_REG[1]   = 0x00000000;
  HS_ANA->IF_AGC_LUT_REG[2]   = 0x0114010D;
  HS_ANA->IF_AGC_LUT_REG[3]   = 0x01320120;
  HS_ANA->IF_AGC_LUT_REG[4]   = 0x01A0015D;
  HS_ANA->FILT_GAINC_LUT_REG  = 0x00000000; //filt_gainc_lut: 0x012->0x000, referenced by dcoc calibration
  HS_ANA->RX_AGC_CFG[0]       = (HS_ANA->RX_AGC_CFG[0] & ~((0x7 << 20) | (0x3 << 16))) | (0x1 << 20) | (0x1 << 16); //agc_settle_time1,2: 0x22->0x11 (1.5us->1us)
  HS_ANA->RX_AGC_CFG[2]       = 0x814f01f0; //[24:16]agc_pfs2: 0x14f, [8:0]agc_pfs: 0x1fc->0x1f0

  /* power on LDOs of RF PLL: [0]pd_bt_ldodiv, [1]pd_bt_ldommd, [2]pd_bt_synth_cp, [3]pd_bt_synth_ldocp, [4]pd_bt_synth_vc_det, [5]pd_bt_ldopfd, [6]pd_ldo_lobuf, [12]pd_bt_ldovco */
  //HS_BTPHY->ANALOGUE[0x2C] &=~ 0xFE;  //[7:1]pd_ldo_xxx_flag: 0=reg
  //HS_BTPHY->ANALOGUE[0x2B] &=~ 0xFE;  //[7:1]pd_ldo_xxx     : 0=power on
  HS_ANA->PD_CFG[1] &= ~((1 << 28) | (1 << 22) | (1 << 21) | (1 << 20) | (1 << 19) | (1 << 18) | (1 << 17) | (1 << 16)); //xxx_flag
  HS_ANA->PD_CFG[1] &= ~((1 << 12) | (1 <<  6) | (1 <<  5) | (1 <<  4) | (1 <<  3) | (1 <<  2) | (1 <<  1) | (1 <<  0)); //xxx_reg
  cpm_delay_us(8);  //wait pd_ldo_xx setup

    /* VCO amplitude calibration, refer to BR3214_BTPHY_REG_v1.6_20141229.xlsx and RFPLL_IO_0912_v0.2.pdf */
    //HS_BTPHY->ANALOGUE[0x4A] |= 0x10; //[4]vco_amp_cal_start: set 1 to start VCO amplititude calibration
    //while( (HS_BTPHY->ANALOGUE[0x4A] & 0x10) == 0x10 ); //wait VCO amplitude calibration finished
    HS_ANA->PEAKDET_CFG |= 0x10; //[4]vco_amp_cal_start: w1
    while (HS_ANA->PEAKDET_CFG & 0x10); //wait hw self clear

    cpm_delay_us(8);  //wait VCO stable

    /* AFC calibration, refer to BR3214_BTPHY_REG_v1.6_20141229.xlsx and RFPLL_IO_0912_v0.2.pdf */
    //HS_BTPHY->ANALOGUE[0x40] |= 0x100; //[8]afc_start: set 1 to start AFC calibration
    //while( (HS_BTPHY->ANALOGUE[0x40] & 0x100) == 0x100 ); //wait AFC calibration finished
    HS_ANA->VCO_AFC_CFG[0] |= 0x100; //[8]rf_pll_afc_start: w1
    while (HS_ANA->VCO_AFC_CFG[0] & 0x100); //wait hw self clear

    cpm_delay_us(10);  //wait AFC stable

  //HS_BTPHY->ANALOGUE[0x70] |= (1<<13); //reg<269>pfd_rst_b: 1=cali; 0=normal, pull high according yanguang and Yangyi's mail, Feb.13 2015: removed in br3215?

  //HS_BTPHY->ANALOGUE[0x08] = 0x402;    //[15:12]agc_sync_time b'0000=no timeout | [11:8]agc_gain1 b'0100 | [5:4]pkd_reset_time b'00 | [1:0]agc_settle_time b'10=1.5us
//HS_ANA->MAIN_ST_CFG[1] = (HS_ANA->MAIN_ST_CFG[1] & ~(0x0f << 12)) | (0 << 12); //[15:12]agc_sync_time b'0000=no timeout

  //HS_BTPHY->TESTCTRL0 &=~(1<<1);   //pd_core_lv: removed in br3215
  //reg<288:287>sel_amp: b'01=x2 (in default) -> b'00=x1: removed in br3215
  //HS_BTPHY->ANALOGUE[0x71] = (HS_BTPHY->ANALOGUE[0x71] & ~(1 << 15)) | (0 << 15);
  //HS_BTPHY->ANALOGUE[0x72] = (HS_BTPHY->ANALOGUE[0x72] & ~(1 << 0))  | (0 << 0);

  //BR3215A2 fixed high frequency bug, manually modified high freq ctuning table.
    HS_BTPHY->ANALOGUE[0x44] = 2490;
    HS_ANA->VCO_AFC_CFG[0] |=(1<<16);
    cpm_delay_us(1);  //wait AFC stable
    HS_ANA->DBG_IDX = 4;
    HS_ANA->LNA_CLOAD_CFG = (HS_ANA->LNA_CLOAD_CFG & 0xFFFFFFF) | ((HS_ANA->DBG_RDATA & 0x0E)<<27);
#endif
}

static void _HWradio_Init_RF_PHY(void)
{
    HS_BTPHY->DEM_DLY_BKOFF_DPSK=0x0B;   //address 0x4002006C
    HS_BTPHY->SW_VLD_DLY_SEL=0x03;       //address 0x4002005C
    HS_BTPHY->TX_EDR2_DLY_SEL=21;        //address 0x40020034  EDR2 delay
    HS_BTPHY->TX_EDR3_DLY_SEL=17;        //address 0x40020164  EDR3 delay
    HS_BTPHY->GAU_DLY_CNT=32;            //address 0x40020168
    HS_BTPHY->GUARD_DLY_CNT=60;          //address 0x4002016C
    HS_BTPHY->EN_CFO_EST=1;              //address 0x40020018, 1: open CFO, 0 : close CFO
    HS_BTPHY->MAXMIN0_LIM=1;             //address 0x400200F0
    HS_BTPHY->DC_LIM=1;                  //address 0x400200F8
    HS_BTPHY->EN_FAGC=1;                  //address 0x400200B0
    HS_BTPHY->NOISE_DET_EN=0;            //address 0x40020158
    HS_BTPHY->RSSI_EST_SEL=0;            //address 0x400200D4, 1: de-rotator1 output, 0: channel filter output
    HS_BTPHY->RSSI_TIMEOUT_CNST= (g_sys_rf_cfg.rssi_mode >> 0) & 0x0f; /* 0: wait 2^0 cycles @24MHz since fsync_det */
    HS_BTPHY->RSSI_SAVE_MODE   = (g_sys_rf_cfg.rssi_mode >> 4) & 0x03; /* 0: store RSSI after sync detect and stable */

    /* settings in cycles @24MHz */
#if 0//luwei
    HS_ANA->MAIN_ST_CFG[0] = ((((g_sys_rf_cfg.hw_radio_pll_time * 24) & 0xffff) << 16) | //[31:16]pll_wait: in cycles @24MHz
                              (((g_sys_rf_cfg.hw_radio_ldo_time * 24) & 0xffff) << 0));  //[15:0]txldo_wait
    HS_ANA->MAIN_ST_CFG[1] = ((((g_sys_rf_cfg.hw_radio_ldo_time * 24) & 0xffff) << 16) | //[31:16]rxldo_wait
                              (( 0                                    & 0x0f)   << 12) | //[15:12]agc_sync_time: 0=no timeout; 1=10us; 2=20us; ...; 15=15us
                              (((g_sys_rf_cfg.hw_radio_ramp_time -1)  & 0x01)   << 8)  | //[8]ramp_1us: 0=1us; 1=2us
                              (((g_sys_rf_cfg.hw_radio_pa_time * 24)  & 0xff)   << 0));  //[7:0]pa_wait
#endif

    /* debug BB-PHY interface */
    HS_SYS->DEBUG_MON_ID = g_sys_rf_cfg.debug_mon_id;
#if defined(BR32xx_FPGA)
    /* LPO @32000Hz */
    HS_PMU_CPM->RTC_CFG = 0x14;   // RTCCLK source is XTAL
    HS_PSO->BTPHY_CFG = 0x2a04;   // LPO source is XTAL
    HS_PMU_CPM->CRY_CFG = (500 << 7) | 0x11; //FIXME: XTAL@16MHz
    HS_PMU_CPM->UPD = 0x01;
#endif
}

static void _HWhab_Init_RF(void)
{
  volatile uint32_t config_word = 0;

  //donot use autowake up
  *(volatile unsigned int*)0x400180A0 = 0x00000000;

  _HWradio_Init_RF_PHY();

  config_word = 0;
  config_word |= (18 <<5); // 14bit data plus 4 bit address
  config_word |= (1<<10);  // clk pol - 1. data clocked out on rising edge.
  config_word |= (0<<11);  // data pol - 0. data not inverted
  config_word |= (1<<12);  //serial enable -1
  config_word |= (1<<16);  // clk low - 1. number of refclk cycles for which SPI clk is low.
  config_word |= (1<<20);  // clk high -1. number of refclk cycles for which SPI clk is high.
  config_word |= (0<<23);  // clk byp.
  config_word |= (1<<24);  // sel pol - 1. active low select enable.
  config_word |= (0<<27);  // set pol - 0. normal SPI mode.

  *(volatile unsigned int*)0x40016060 = config_word;

  config_word = (1 << 23);  //enable the ESER block
  config_word |= (0 << 0);  //mask -0
  config_word |= (1 << 20); //now -1
  config_word |= (0 << 21); // seq -0

  *(volatile unsigned int*)0x40016064  = config_word;

  //GIO combines - Un combine everything 0x40018000
  *(volatile unsigned int*)0x40018060 = 0x00000000;
  *(volatile unsigned int*)0x40018064 = 0x00000000;
  *(volatile unsigned int*)0x40018068 = 0x00000000;

  /*GIOs Low*/
  HWradio_SetOverrideLow(SHDN);            //SHDN low
  HWradio_SetGIOLowReg(SHDN,0x8000);
  HWradio_SetGIOLowReg(TXENA,0x8000);
  HWradio_SetGIOLowReg(RXENA,0x8000);

  /*GIOs High*/
  HWradio_SetGIOHighReg(SHDN,0x0000);
  HWradio_SetGIOHighReg(TXENA,0x0000);
  HWradio_SetGIOHighReg(RXENA,0x0000);
}

static int HWradio_init(void)
{
                           /* 0x2029080c, 0xb5541014 */
  uint32_t common_pack[10] = {0x2028000c, 0xb5541004, 0x530020aa, 0x535ab30a,
                /*0x72583201*/0x72580201, 0x964c6449, 0x1e0802bc, 0xaaa82a82,
                              0x80002ac1, 0xc010015a};
  int i, ret = 0;

  /* don't reset BTPHY because some calibration had run in main.c */
  //cpmResetBTPHY();
  if (HS_PSO->BTPHY_CFG & CPM_BUS_GATE) {
    cpmEnableBTPHY();
    osalThreadSleepMilliseconds(1);
  }

  /* check default value */
  if ((HS_ANA->COMMON_PACK[0] & 0xfffe03ff) != (common_pack[0] & 0xfffe03ff)) //excluding PGA_GAIN, RCtune
    ret = -1;
  if ((HS_ANA->COMMON_PACK[1] & 0xffffffef) != (common_pack[1] & 0xffffffef)) //excluding DRV_GAIN
    ret = -2;
  if ((HS_ANA->COMMON_PACK[2] & 0xffffffff) != common_pack[2])
    ret = -3;
  if ((HS_ANA->COMMON_PACK[3] & 0xffffffff) != common_pack[3])
    ret = -4;
  if ((HS_ANA->COMMON_PACK[4] & 0xfffc87ff) != (common_pack[4] & 0xfffc87ff)) //excluding GSEL_PA, TXDAC_BW_CAL
    ret = -5;
  for (i = 5; i < 10; i++) {
    if (HS_ANA->COMMON_PACK[i] != common_pack[i]) {
      ret = 0-(i+1);
      break;
    }
  }
  /* reg<252:251>con_ldo_pfd b'01=1.3V; b'11=1.4V */
  if (HS_ANA->REGS.CON_LDO_PFD != pmu_ana_get(251, 252))
    ret = -99;

  /* max tx power */
  HS_BTPHY->TX_DPGA_GC = g_sys_rf_cfg.power_ctrl_tab[10] & 0x0f;
  HS_ANA->REGS.GSEL_PA = (g_sys_rf_cfg.power_ctrl_tab[10] >> 4) & 0x03;

  *(volatile unsigned int*)0x40018028 = 0x360062b8;    //config phy
  *(volatile unsigned int*)0x40018008 =  0x70000;      //config sym
  *(volatile unsigned int*)0x40018008 = 0x170000;      //config cor

  HS_BTPHY->SPI_APB_SWITCH=0;
  _HWhab_Init_RF();
  //_HWradio_Go_To_Idle_State();
  return ret;
}

void BR3215_mac6200_init(void)
{
  HS_BTPHY->SPI_APB_SWITCH=0;

  HWradio_init();
  _BR3215_VCO_AFC_Calibration();

  HS_BTPHY->IF_REG = 0x300; //0x300=750k for bt & rf62; 0x80=125k for fm
  HS_ANA->INTER_FREQ = 0x340000; //0x340000=750k for bt & rf62 on analog

  HS_BTPHY->SPI_APB_SWITCH=1;
}
#endif // HAL_USE_BT



#endif /* HAL_USE_RF */

/** @} */

