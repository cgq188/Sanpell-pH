/*
    ChibiOS/RT - Copyright (C) 2006-2013 Giovanni Di Sirio
                 Copyright (C) 2019 BRMICRO Technologies
                 

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    br32xx/fm_lld.c
 * @brief   RADIO Driver subsystem low level driver source.
 *
 * @addtogroup FM
 * @{
 */

#include <stdlib.h> //abs()
#include <string.h>
#include "hal.h"
#include "chprintf.h"

#if HAL_USE_FM || defined(__DOXYGEN__)

/*===========================================================================*/
/* Driver local definitions.                                                 */
/*===========================================================================*/

/*===========================================================================*/
/* Driver exported variables.                                                */
/*===========================================================================*/

/**
 * @brief   FM driver identifier.
 */
FMDriver FMD0;


/*===========================================================================*/
/* Driver local variables and types.                                         */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local functions.                                                   */
/*===========================================================================*/

/*===========================================================================*/
/* Driver exported functions.                                                */
/*===========================================================================*/

/**
 * @brief   Low level RADIO driver initialization.
 *
 * @notapi
 */
void fm_lld_init(void) {
  fmObjectInit(&FMD0);
}


/**
 * @brief   Configures and activates the FM peripheral.
 *
 * @param[in] fmp      pointer to the @p FMDriver object
 *
 * @notapi
 */
void fm_lld_start(FMDriver *fmp) {
  /* if escape from BT mode, BTPHY must be reset, otherwise FM's rssi will be +40dBm? */
  cpmResetBTPHY();
  cpm_delay_us(1);
  cpmEnableFM();

#if defined(BR3215)
  /* powers: [16]pd_topldo_v1p8 [13]rfldo_v2p8 [10]pd_v2p5ldo [9-7]ldo_v1p5_rf/ana/adda */
  HS_PMU->ANA_CON &= ~((1 << 16) | (1 << 13) | (1 << 10) | (1 << 9) | (1 << 8) | (1 << 7));
#endif

#if defined(BR3215)
  HS_ANA->REGS.RXADC_SEL_INPUT = 0; /* always 0 for br3215; select RXADC input for br3214: BT RX; 1=BT TX cali or FM */
  HS_ANA->REGS.RF_PLL_MODE = 0;     /* RF PLL mode: 1=BT; 0=FM */

  /* by zhangzd on 2016/09/29 */
  HS_ANA->REGS.FM_PDET = 4;       //6 -> 4
  HS_ANA->REGS.FM_PDET_SPACE = 3; //2 -> 3
  HS_ANA->FM_AGC_CFG[1] = 0x00201140; //dpd_thes_l:0x5a -> 0x20; kdp_thes_h:0xb5 -> 0x40
#elif defined(BR3215e)
  HS_ANA->FM_CFG[0] = (3/*fm_pdet_space<1:0>*/ << 16) | (0/*divnum_fm<3:0>*/ << 12) | (3/*fm_vb_mix<2:0>*/ << 5) | (0/*en_fmcktest*/ << 4) | (4/*fm_pdet<3:0>*/ << 0);
  HS_ANA->FM_AGC_CFG[1] = 0x00201140; //dpd_thes_l:0x5a -> 0x20; kdp_thes_h:0xb5 -> 0x40
#endif

  /* fil_gain by fm agc: 6dBm -> 0dBm */
  HS_ANA->FILT_GAINC_LUT_REG  = 0x00000000; //filt_gainc_lut: 0x012->0x000, referenced by dcoc calibration & fm agc

  /* turn off parts of BT RX manually because workaround BT's RXENA fsm will turn on these */
  /* [27][11]pd_rxmix: 1 */
  /* [25][9]pd_rxgm:   1 */
  /* [24][8]pd_rxlna:  1 */
  /* [23][7]pd_rxagc:  1 */
  HS_ANA->PD_CFG[2] &= ~((1 << 27) | (1 << 25) | (1 << 24) | (1 << 23));
  HS_ANA->PD_CFG[2] |=  ((1 << 11) | (1 <<  9) | (1 <<  8) | (1 << 7));
#if defined(BR3215e)
  /* [23][22]pd_tca:   1, i.e. rxgm */
  HS_ANA->PD_CFG[0] &= ~(1 << 23);
  HS_ANA->PD_CFG[0] |= (1 << 22);
#endif

#if defined(BR3215)
  /* power on LDOs of RF PLL: [0]pd_bt_ldodiv, [1]pd_bt_ldommd, [2]pd_bt_synth_cp, [3]pd_bt_synth_ldocp, [4]pd_bt_synth_vc_det, [5]pd_bt_ldopfd, [6]pd_ldo_v1p3_lobuf, [12]pd_bt_ldovco */
  HS_ANA->PD_CFG[1] &= ~((1 << 28) | (1 << 22) | (1 << 21) | (1 << 20) | (1 << 19) | (1 << 18) | (1 << 17) | (1 << 16)); //xxx_flag
  HS_ANA->PD_CFG[1] &= ~((1 << 12) | (1 <<  6) | (1 <<  5) | (1 <<  4) | (1 <<  3) | (1 <<  2) | (1 <<  1) | (1 <<  0)); //xxx_reg
  /* pd_bt_vco_pkdetect: fsm */
#elif defined(BR3215e)
  /* [22][6]pd_ldo_v1p3_lobuf doc bug, but should be removed */
  /* [17][1]:pd_locp [18][2]:pd_pll_all [19][3]:pd_lopfd [20][4]:pd_lobuf [22][6]:pd_lommd [23][7]:pd_clknpath [24][8]:pd_lovco */
  HS_ANA->PD_CFG_NEW[0] &= ~((1 << 24) | (1 << 23) | (1 << 22) | (1 << 20) | (1 << 19) | (1 << 18) | (1 << 17) |
                             (1 <<  8) | (1 <<  7) | (1 <<  6) | (1 <<  4) | (1 <<  3) | (1 <<  2) | (1 <<  1));
  /* [24][8]:pd_bt_tx_lobuf [28][12]:pd_bt_ldovco */
  HS_ANA->PD_CFG[1] &= ~((1 << 28) | (1 << 24) |
                         (1 << 12) | (1 << 8));
  /* [24][8]:pd_lovco=1      during div2buf tuning */
  /* [28][12]:pd_bt_ldovco=1 during div2buf tuning */
  HS_ANA->PD_CFG_NEW[0] |=   (1 <<  8);
  HS_ANA->PD_CFG[1]     |=   (1 << 12);
  /* [21]pd_fmlo (doc bug, but it's not pd_rfcstgm) */
  HS_ANA->PD_CFG[0] &= ~((1 << 21));
  /* [12][10:8]:selfosc_div=6 */
  HS_ANA->DIV2BUF_TUNE_CFG = (HS_ANA->DIV2BUF_TUNE_CFG & ~(0x0F/*selfosc_div_reg*/<<8)) | (1/*selfosc_div_mn*/<<12) | (6/*selfosc_div_reg*/<<8);
  /* reg<187:184>=ctrl_ldo_vco=0xA */
  HS_ANA->COMMON_PACK[5] = (HS_ANA->COMMON_PACK[5] & ~(0x0F<<24)) | (0x0A<<24);
  /* vco div2buf tune with default target */
  HS_ANA->DIV2BUF_TUNE_CFG = (HS_ANA->DIV2BUF_TUNE_CFG & 0xFFFF) + (1<<0) + (0x2620<<16); //[1]:div2buf_tune_start [31:16]tune_target
  while(HS_ANA->DIV2BUF_TUNE_CFG & 0x01);
  /* [24][8]:pd_lovco=0      after div2buf tune */
  /* [28][12]:pd_bt_ldovco=0 after div2buf tune */
  HS_ANA->PD_CFG_NEW[0] &=   ~(1 <<  8);
  HS_ANA->PD_CFG[1]     &=   ~(1 << 12);
#endif

  /* VCO amplitude calibration */
  //HS_ANA->SDM_CFG |= (1 << 12);   //bt_synth_dith_en_sdm
  HS_ANA->PEAKDET_CFG |= 0x10; //[4]vco_amp_cal_start: w1
  osalThreadSleep(OSAL_MS2ST(1));
  osalDbgAssert((HS_ANA->PEAKDET_CFG & (1 << 4))== 0, "vco amplititude calibration");

#if 0 //this step is not required by FM, because it is used to setup ctune/ftune table for BT
  /* AFC calibration */
  HS_ANA->VCO_AFC_CFG[0] |= 0x100; //[8]rf_pll_afc_start: w1
  osalThreadSleep(OSAL_MS2ST(50));
  osalDbgAssert((HS_ANA->VCO_AFC_CFG[0] & (1 << 8)) == 0, "afc calibration");
#endif

  /* [12]bt_synth_dith_en_sdm: 1 */
  osalDbgAssert(HS_ANA->SDM_CFG & (1 << 12), "dither is not enabled");

  /* [15]pd_bt_mmd_fm:    0
     ?[16]pd_fm_synth_ldo: 0, removed in br3215 */
  HS_ANA->PD_CFG[0] &= ~((1 << 16) | (1 << 15));
  /* [12]rf_pll_mode_fm=mode_fm_sdm: b'0=BT b'1=FM */
  /* the inverse is also br3215e's btfm_sel to select rxtia & rxfil mode: 0=FM */
  HS_ANA->VCO_AFC_CFG[0] |= (1 << 12);

  /* [4]rf_pll_track_mn=1 [3:0]rf_pll_track_reg=bt_vco_track=b'100 by yanguang */
  HS_ANA->VTRACK_CFG = (1 << 4) | (0x4 << 0);

#if 1
  fm_lld_set_freq(fmp, 1039);
#else
  /* [15:12]fm_divnum[3:0]=0~15
     [31:0]fm_freq=bt_synth_freq_dem[31:0]: 12-bit=int(mHz) 20-bit=fra
      FM(mHz)= ((fm_freq>>20) + (fm_freq&0xfffff)/(1024*1024)) / (2 * (fm_divnum+8))
      FM(kHz)= ((fm_freq>>20)*1000 + (fm_freq&0xfffff)*1000/(1024*1024)) / (2 * (fm_divnum+8))

     103.9mHz= 103900kHz= 2493600kHz / 24 = ((2493*1000)+(600))kHz / 24
                                                                     fm_divnum=24/2 - 8=4
                                            fm_freq=(2493<<20) + 600*1024*1024/1000

     103.9mHz-125kHz= (103900-125)kHz= 2490600kHz / 24 = ((2490*1000)+(600))kHz / 24
                                                                     fm_divnum=24/2 - 8=4
                                            fm_freq=(2490<<20) + 600*1024*1024/1000
  */
  HS_ANA->FM_CFG[0] = (HS_ANA->FM_CFG[0] & ~(0xf << 12)) | (4/*fm_divnum*/ << 12);
  HS_ANA->FM_CFG[1] = (2490<<20) | 0x99999;
  HS_ANA->VCO_AFC_CFG[0] |= 0x100; //[8]rf_pll_afc_start: w1
  osalThreadSleep(OSAL_MS2ST(50));
  osalDbgAssert((HS_ANA->VCO_AFC_CFG[0] & (1 << 8)) == 0, "fm pll lock");
#endif
  /* workaround: keep BT's RXENA high to un-reset SDM */
#if defined(BR3215e)
  /* [10]reg_rx_en_gio=1 [9]reg_tx_en_gio=0 [8]reg_trx_gio_sel=1:reg */
  HS_BTPHY->TX_RX_EN &= ~(1<<10) + (1<<9);
  HS_BTPHY->TX_RX_EN |= (1<<10) + (1<<8);
#else
  HS_BTPHY->SPI_APB_SWITCH = 0;
  HS_BTPHY->ANALOGUE[0x30] = (1<<7) + (1<<4); //[7]rx_start: w1 trigger to start rx fsm
#endif

  /* [17]pd_fm_lna:   0
     [18]pd_fm_gm:    0
     [19]pd_fm_mixer: 0 */
  HS_ANA->PD_CFG[0] &= ~((1 << 19) | (1 << 18) | (1 << 17));
  osalThreadSleep(OSAL_MS2ST(1));
#if defined(BR3215)
  /* [12]pd_rxadc_dacbias: 0 */
  HS_ANA->PD_CFG[0] &= ~((1 << 12));
#endif

#if defined(BR3215)
  /* [28][12]pd_rxfil:        0, pd_fil is wrong name */
  /* [26][10]pd_rxtia:        0 */
  /* [22][6]pd_rxadc_ovdect:  0 */
  /* [21][5]pd_rxadc_q:       0 */
  /* [20][4]pd_rxadc_i:       0 */
  /* [19][3]pd_rxadc_dem:     0 */
  /* [18][2]pd_rxadc_biasgen: 0 */
  HS_ANA->PD_CFG[2] &= ~((1 << 28) | (1 << 26) | (1 << 22) | (1 << 21) | (1 << 20) | (1 << 19) | (1 << 18));
  HS_ANA->PD_CFG[2] &= ~((1 << 12) | (1 << 10) | (1 <<  6) | (1 <<  5) | (1 <<  4) | (1 <<  3) | (1 <<  2));
#elif defined(BR3215e)
  /* [31][15]rst_rxadc:       1->0 */
  HS_ANA->PD_CFG[2] &= ~((1 << 31) |
                         (1 << 15));
  HS_ANA->PD_CFG[2] |= (1 << 15);
  cpm_delay_us(1);
  HS_ANA->PD_CFG[2] &= ~(1 << 15);
  /* [28][12]pd_rxfil:        0 */
  /* [26][10]pd_rxtia:        0 */
  HS_ANA->PD_CFG[2] &= ~((1 << 28) | (1 << 26) |
                         (1 << 12) | (1 << 10));
  /* [21][5]pd_rxadc:         0 */
  HS_ANA->PD_CFG_NEW[0] &= ~((1 << 21) |
                             (1 <<  5));
#endif

#if defined(BR3215)
  /* [0]sel_mod_dcoc  b'1=BT b'0=FM */
  HS_ANA->ADCOC_CNS &= ~(1 << 0);
  /* [21]pd_rfcstgm [20]pd_dcoc by xuebaiqing; pd_dcoc=1 for fm by wangjianting */
  HS_ANA->PD_CFG[0] &= ~((1 << 21) | (1 << 20));
  HS_ANA->PD_CFG[0] |= (1 << 20);
#elif defined(BR3215e)
  /* [0]en_dcoc */
  HS_ANA->ADCOC_CNS &= ~(1 << 0);
  /* [16][0]pd_cstgm_fm, i.e. pd_rfcstgm */
  HS_ANA->PD_CFG[1] &= ~((1 << 16) | (1 << 0));
#endif

#if defined(BR3215)
  /* rxtia
     [25]fre_sel    b'1=pos b'0=neg
     [23]lp_cp_sel  b'1=complex filter; b'0=LPF for calibration
     [22]modsel_tia b'1=BT b'0=FM */
  /* rxfil
     [13:12]swap_fil b'00=complex filter pos, b'01=neg, b'1x=LPF for DCOC calibration
     [0]modsel_fil  b'1=BT b'0=FM */
  #if 1 //lpf by zhangzd on 2016/09/29
  HS_ANA->COMMON_CFG[0] = (0 << 30) | (0 << 29) | (0 << 25) | (0 << 23) | (0 << 22) | (2 << 14) | (1 << 8) | (8 << 4); //lpf in rxtia
  HS_ANA->RX_FIL_CFG = (3 << 12) | (0 << 8) | (3 << 4) | (0 << 0); //lpf in rxfil
  #else
  //HS_ANA->COMMON_CFG[0] = (0 << 30) | (0 << 29) | (1 << 25) | (1 << 23) | (0 << 22) | (2 << 14) | (1 << 8) | (8 << 4); //pos
  //HS_ANA->RX_FIL_CFG = (0 << 12) | (0 << 8) | (3 << 4) | (0 << 0); //pos
  HS_ANA->COMMON_CFG[0] = (0 << 30) | (0 << 29) | (0 << 25) | (1 << 23) | (0 << 22) | (2 << 14) | (1 << 8) | (8 << 4); //neg
  HS_ANA->RX_FIL_CFG = (1 << 12) | (0 << 8) | (3 << 4) | (0 << 0); //neg
  #endif
#elif defined(BR3215e)
  fmp->ana_cfg_new = HS_ANA->ANA_CFG_NEW;
  fmp->rx_fil_cfg  = HS_ANA->RX_FIL_CFG;
  /* [24]lpcpsel_tia  b'1=complex; b'0=lpf */
  /* [11]swap_tia     b'1=pos;     b'0=neg */
  /* [15:12]adckey_sel is moved to PMU */
  HS_ANA->ANA_CFG_NEW = (0/*cali_rxlan*/ << 26) |
    (0x2/*en_rx_npath_flag/reg*/ << 20) | (0/*tx_cap*/ << 16) |
    (0/*lpcpsel_tia*/ << 24) | (0/*swap_tia*/ << 11) | //lpf
    (HS_ANA->ANA_CFG_NEW & (0x0F<<28)); //keep rc's [31:28 ctune_tia]
  //HS_ANA->COMMON_CFG[0] = (0/*cali_rxatten*/ << 29) | (0/*gsel_txpdet*/ << 27) | (0/*spcl_freq_byps_en_dem*/ << 20) | (0/*sys_pll_afc_en*/ << 9) | (0/*bt_cp_sw_lvl_en*/ << 8) | (0/*modsel_ana1p4*/ << 3) | (0/*byp_dacbias*/ << 2) | (0/*tx_cali_en*/ << 0);
  /* rxfil
     [13:12]swap_fil b'00=complex filter pos, b'01=neg, b'1x=LPF for DCOC calibration
     [9:8][10]gtune_fil<1:0> [0,3,6,6]dB b'00=0dB  <<trx analog-digital interface section 3.5.1>>
     [7:4]ctune_fil<3:0>    b'1000=0% */
  HS_ANA->RX_FIL_CFG = (0/*sel_ifagc*/ << 16) |
    (0x3/*swap_fil*/ << 12) | //lpf
    (0x0/*gtune_fil_reg*/ << 8) | (0/*gtune_fil_flag*/ << 10) |
    (HS_ANA->RX_FIL_CFG & (0x0F<<4));  //keep rc's [6:4]ctune_fil
#endif

  /* fm agc: fm_lna_gm[2:0] fm_lna_ro[2:0] fm_gm_gain[2:0] */
#if defined(BR3215e)
  /* fm gain: pga2_gainc_reg=fm_gm_gain<2:0>,tia_gain<2:0>(buggy,set it in RX_AGC_CFG[4])<1:0>  b'101000=27.48dB b'101010=33.48dB b'101100=39.47dB
                                                                           RX_GAINC_LUT_REG[8]<1:0> and indexed by RX_AGC_CFG[3].gain_idx_reg=8
              pga2_gainc_reg[0] is tia_gain<2>                                                    101000           101010           101001(wrong)
              pga1_gainc_reg=fm_lna_gm<2:0>,fm_lna_ro<2:0>  b'000000=22.7dB */
  HS_ANA->FM_AGC_CFG[0] =
    (0u/*agc2_gain_downstep*/ << 31) | (0u/*pga2_adj_time_down*/ << 28) | (4u/*pga2_adj_time_up*/ << 24) |
    (0u/*agc1_gain_downstep*/ << 23) | (0u/*pga1_adj_time_down*/ << 20) | (4u/*pga1_adj_time_up*/ << 16) |
    (0u/*fm_agc2_flag*/ << 15) | (0x2a/*pga2_gainc_reg*/ << 8) |
    (1u/*fm_agc1_flag*/ <<  7) | (0x00/*pga1_gainc_reg*/ << 0);
#endif
#if defined(BR3215)
  /* turn off BT's rx agc of digital */
  /* rx_gain: [15:14]lna_gain [13]shrt_lna [12]sw_lna [11]en_att [10:9]att_ctrl [8:6]tca_ctrl [5]en_gm [4:2]tia_ctrl(by fm agc) [1:0]filt_gain(0 for fm) */
  HS_ANA->RX_AGC_CFG[4] = 0xA2600000; //[16]rx_gain_flag ...: 0=reg
#elif defined(BR3215e)
  /* rx_gain (bt):    [11]en_lna [10:9]rxlna_gain [8]en_atten [7:6]rxatt_gain [5:3]rxtca_gain
     (bt&fm): [2:0]tia_gain b'010=33.48dB when fm_gm_gain=b'101 <<AGC section 3.3>><<FM_RFAGC section 5.2>>
                              000=27.48dB
                              others wong */
  HS_ANA->RX_AGC_CFG[4] = 0x00000C82; //[16]rx_gain_flag ...: 0=reg
  /* [31][30:24]gain_idx=8 to borrow RX_GAINC_LUT_REG[8]<1:0> */
  HS_ANA->RX_AGC_CFG[3] = 0x08300300;
#endif

#if !defined(BR3215e)
  HS_BTPHY->IF_REG = 0x40;     //fm's if is 125khz
#endif
  HS_BTPHY->EN_DC_REMOVAL = 1; //enable dc removal
  HS_BTPHY->DC_MODE = 2;       //one-order HPF for fm
#if defined(BR3215)
  HS_BTPHY->DCNOTCH_K_SEL = 9; //2^-11 bandwidth? for fm
#elif defined(BR3215e)
  HS_BTPHY->DCNOTCH_K_SEL = 12;//2^-12 bandwidth? for fm
#endif
  /* fm_dc_rmv2_k: wait 0=10ms 1=20ms 2=40ms 3=80ms to get the stable rssi/snr/ncfo */
  HS_BTPHY->RMV2_DEEM = (1u << 28) | (1u << 24) | (3u << 20) | (4u << 16) | (1u << 12) | (1u << 8) | (1u << 4) | (3u << 0); //m_pll_kn=1, fm_dc_rmv2_k=3 on 2017.02.21
  HS_BTPHY->RMV2_DEEM = (1u << 28) | (1u << 24) | (3u << 20) | (4u << 16) | (1u << 12) | (1u << 8) | (1u << 4) | (2u << 0); //m_pll_kn=1, fm_dc_rmv2_k=2 on 2018.10.12

  /* fm stereo new alg by zhangzd on 2016.12.09 */
  HS_BTPHY->FM_MODE = MODE_FM | 0;//MODE_MONO; //fm mode & stereo
  //HS_BTPHY->TX_RX_EN |= 0x02;            //enable bt rx data to modem on br3214?
  HS_BTPHY->FM_RSSI = ((HS_BTPHY->FM_RSSI) & ~0x03) | 0x03;  // fm_rssi_k_sel: 2^-11
#if 0
  /* disable hi-cut for true SNR by zhangzd on 2016.09.30, but it will lost 3+dB */
  HS_BTPHY->FM_CHHC_FILT &= ~((1 << 20) | (1 << 16)); //fm_hc_mode=0: reg set; fm_chhc_filt_en=0 in default
  HS_BTPHY->FM_LRHC_FILT &= ~(1 << 16);               //fm_lrhc_filt_en=0 in default
#else
  /* enable hi-cut manually outside to run SNR/sensitivity benchmark */
  HS_BTPHY->FM_CHHC_FILT = (1 << 20) | (0 << 16) | (16 << 8) | (14 << 0); //fm_hc_mode=1: auto, it will enable hi-cut mode automatically if SNR is worse
  //HS_BTPHY->FM_CHHC_FILT = (1 << 20) | (1 << 16) | (16 << 8) | (14 << 0); //fm_chhc_filt_en=1
  //HS_BTPHY->FM_LRHC_FILT =             (1 << 16) | (16 << 8) | (14 << 0); //fm_lrhc_filt_en=1
#endif
  /* fm stereo by zhangzd on 2016.09.30 */
  //HS_BTPHY->FM_STEREO = (12 << 24) | (22 << 16) | ((uint8_t)-80 << 8) | ((uint8_t)-70 << 0);
  /* fm stereo new alg by zhangzd on 2016.12.09; moved in check_freq() on 2018.04.26 */
  //HS_BTPHY->FM_STEREO = ((uint8_t)(fmp->th.snr_th_stereo)/*snr_thl*/ << 24) | ((uint8_t)(fmp->th.snr_th_stereo+0)/*snr_thh*/ << 16) | ((uint8_t)-80 << 8) | ((uint8_t)-70 << 0);

#if defined(BR32xx_FPGA) && defined(BR3215e)
#else
  HS_BTPHY->IQ_IN_SWAP = 1;                //swap is required by FM; and BT swap it in analog circuit
#endif

  osalThreadSleep(OSAL_MS2ST(1));
  #if 0
  /* huyong
    //config PHY register for FM
    WriteMem32((PHY_BASE|0x240), 0x1);
    WriteMem32((PHY_BASE|0x238), 0x40);
    //cfg0_new
    WriteMem32(0x4000F140,0xfe800000);
    WriteREG32(0x4002023c, 0x0); //iq swap
    WriteREG32(0x4000F100, 0x00001000);
    WriteREG32(0x4000F010, 0x00000200);
    //WriteREG32(0x4000F070, 0x03038080);
    read_data = ReadMem32(0x4000F000);
    WriteMem32(0x4000F000, read_data&0x400000);
    read_data = ReadMem32(0x4000F004);
    WriteMem32(0x4000F004, read_data&0xefc0efc0);
    read_data = ReadMem32(0x4000F008);
    WriteMem32(0x4000F008, read_data&0x00000900);
    read_data = ReadMem32(0x4000F01C);
    WriteMem32(0x4000F01C, read_data&0x100);
    read_data = ReadMem32(0x40020000+0x90<<2);
    WriteMem32((0x40020000+0x90<<2), (read_data|0x1));
    WriteREG32(0x4000F070, 0x03038080);
  */
  HS_BTPHY->FM_MODE = 0x1;
  //HS_ANA->PD_CFG_NEW[0] = 0xfe800000; //[24]pd_lovco, [22~16]
  HS_BTPHY->IQ_IN_SWAP = 0;
  //HS_ANA->VCO_AFC_CFG[0] = 0x00001000; //rf_pll_afc_start=1
  //HS_ANA->COMMON_CFG[0] = 0x00000200; //sys_pll_afc_en=1
  HS_ANA->PD_CFG[0] &= 0x400000; //pd_tca_reg=1
  HS_ANA->PD_CFG[1] &= 0xefc0efc0; //[12]pd_bt_ldovco, [4]pd_bt_synth_vc_det, ?[1]pd_sarq_tr [0]pd_cstgm_fm
  HS_ANA->PD_CFG[2] &= 0x00000900; //[9]pd_rxgm=1 [8]pd_rxlna=1
  HS_ANA->RX_FIL_CFG &= 0x100; //?[8]gtune_fil_reg
  HS_BTPHY->FM_MODE |= 0x1;
  HS_ANA->FM_AGC_CFG[0] = 0x03038080;
  #endif
}

/**
 * @brief   Deactivates the  FM peripheral.
 *
 * @param[in] fmp      pointer to the @p FMDriver object
 *
 * @notapi
 */
void fm_lld_stop(FMDriver *fmp) {
  (void)fmp;

  /* canncel BT's RXENA */
#if defined(BR3215e)
  /* [10]reg_rx_en_gio=0 [9]reg_tx_en_gio=0 [8]reg_trx_gio_sel=0:fsm */
  HS_BTPHY->TX_RX_EN &= ~((1<<10) | (1<<9) | (1<<8));
#else
  HS_BTPHY->ANALOGUE[0x30] = (1<<6) + (1<<4); //[6]rx_end: w1 trigger to end rx fsm when rxen is spi mode
                                              //[4]rxen_sel: 0=gio; 1=spi
#endif

  HS_BTPHY->IQ_IN_SWAP = 0;
#if defined(BR3215)
  HS_ANA->REGS.RXADC_SEL_INPUT = 0;
  HS_ANA->REGS.RF_PLL_MODE = 1;
#endif

  HS_BTPHY->FM_MODE = 0;     //common phy mode for bt
#if !defined(BR3215e)
  HS_BTPHY->IF_REG = 0x300;    //bt's if is 750khz
#endif
  HS_BTPHY->DC_MODE = 0;       //two-order loop for bt
#if defined(BR3215)
  HS_BTPHY->DCNOTCH_K_SEL = 3; //2^-3 bandwidth? for bt
#elif defined(BR3215e)
  HS_BTPHY->DCNOTCH_K_SEL = 5; //2^-5 bandwidth? for bt
#endif
  //HS_BTPHY->TX_RX_EN &= ~0x02;

#if defined(BR3215)
  /* [0]modsel_fil  b'1=BT b'0=FM */
  HS_ANA->RX_FIL_CFG |= (1 << 0);
  /* [22]modsel_tia b'1=BT b'0=FM */
  HS_ANA->COMMON_CFG[0] |= (1 << 22);
  /* [0]sel_mod_dcoc  b'1=BT b'0=FM */
  HS_ANA->ADCOC_CNS |= (1 << 0);
#else
  /* [0]en_dcoc */
  HS_ANA->ADCOC_CNS |= (1 << 0);
  HS_ANA->ANA_CFG_NEW = fmp->ana_cfg_new;
  HS_ANA->RX_FIL_CFG  = fmp->rx_fil_cfg;
#endif

  /* [4]rf_pll_track_mn=0 for BT */
  HS_ANA->VTRACK_CFG = (0 << 4) | (0x4 << 0);

  /* [12]rf_pll_mode_fm=mode_fm_sdm: b'0=BT b'1=FM */
  /* the inverse is also br3215e's btfm_sel to select rxtia & rxfil mode: 1=BT */
  HS_ANA->VCO_AFC_CFG[0] &= ~(1 << 12);

  /* post */
#if defined(BR3215)
  HS_ANA->PD_CFG[0] = 0xFFCFEFFF; //[12]pd_rxadc_dacbias [21]pd_rfcstgm [20]pd_dcoc
  HS_ANA->PD_CFG[1] = 0xFFFFFFEF; //[4]pd_bt_synth_vc_det=0 [20]pd_bt_synth_vc_det_flag(removed)
  HS_ANA->PD_CFG[2] = 0xFFFFFFFF;
  HS_ANA->RX_AGC_CFG[4] = 0xA2610000; //[16]rx_gain_flag ...: 1=fsm to enable rxAGC
#elif defined(BR3215e)
  HS_ANA->PD_CFG[0] = 0xFFFFFFFF;
  HS_ANA->PD_CFG[1] = 0xFFFFFFFF; //?[20][4]pd_bt_synth_vc_det=0 ?[17][1]pd_sarq_tr [16][0]pd_cstgm_fm
  HS_ANA->PD_CFG[2] = 0xFFFFFFFF;
  HS_ANA->PD_CFG_NEW[0] = 0xFFFF0000;
  /* restore to default values to enable rxAGC */
  HS_ANA->RX_AGC_CFG[4] = 0x00010000;
  HS_ANA->RX_AGC_CFG[3] = 0x80300300;
  HS_ANA->FILT_GAINC_LUT_REG = 0x00000102;
#endif

  cpmDisableFM();
}

/**
 * @brief   fm pll afc calibration
 *
 * @param[in] fmp      pointer to the @p FMDriver object
 *
 * @notapi
 */
void fm_lld_afc_calibration(FMDriver *fmp) {
  (void)fmp;
  HS_ANA->VCO_AFC_CFG[0] |= (1 << 8);   //rf_pll_afc_start
  osalThreadSleep(OSAL_MS2ST(50));
  osalDbgAssert((HS_ANA->VCO_AFC_CFG[0] & (1 << 8)) == 0, "afc calibration");
}

/**
 * @brief   set FM frequency. refer to FM_PLL IO�ĵ�.docx
 *
 * @param[in] fmp      pointer to the @p FMDriver object
 * @param[in] frequency   fm frequency
 ��
 * @notapi
 */
int fm_lld_set_freq(FMDriver *fmp, int frequency){
  int div = 0, mhz, fra;

  /* workaround: [8]bt_synth_con_mmd_mn=1 [7:0]bt_synth_con_mmd=0x00 to turn off mmd during BT's RXENA is high, before change the new frequency */
  __hal_set_bitsval(HS_ANA->SDM_CFG, 0, 8, 0x100);
  osalThreadSleep(OSAL_MS2ST(1));

  fmp->freq_current = frequency * 100;
  fmp->freq_current -= 125; /* fm's if */
  for(div = (0+8); div <= (15+8); div++){
    int pllout_khz = fmp->freq_current * 2 * div;
    if((pllout_khz >= BT_MHZ_MIN*1000) && (pllout_khz <= BT_MHZ_MAX*1000)){
      break;
    }
  }

  osalDbgAssert(div < 24, "fm lld set frequency");

  HS_ANA->FM_CFG[0] = (HS_ANA->FM_CFG[0] & 0xFFFF0FFF) | ((div-8) << 12); //fm_divnum
  mhz = fmp->freq_current * 2 * div / 1000;
  fra = fmp->freq_current * 2 * div - mhz * 1000;
  HS_ANA->FM_CFG[1] = (mhz << 20) | (fra*1024*1024/1000);

  fm_lld_afc_calibration(fmp);

  /* workaround: [8]bt_synth_con_mmd_mn=1 to turn on mmd, FM PLL will become lock */
  __hal_set_bitsval(HS_ANA->SDM_CFG, 0, 8, 0x000);

  fmp->freq_current += 125; /* fm's if */
  return fmp->freq_current/100;
}

/**
 * @brief   get FM frequency.
 *
 * @param[in] fmp      pointer to the @p FMDriver object
 *
 * @notapi
 */
int fm_lld_get_freq(FMDriver *fmp){
  (void)fmp;
  return fmp->freq_current/100;
}

/**
 * @brief   get FM signal strength.
 *
 * @param[in] fmp      pointer to the @p FMDriver object
 *
 * @notapi
 */
int8_t fm_lld_get_rssi(FMDriver *fmp)
{
  (void)fmp;
  int8_t rssi;
  rssi = (int8_t)((HS_BTPHY->FM_RSSI >> 12) & 0xff);
  #if defined(BR3215e)
  /* by zhangzd on 2018/10/09 */
  //rssi -= 8;
  #endif
  return rssi;
}

/**
 * @brief   get FM signal noise ratio
 *
 * @param[in] fmp      pointer to the @p FMDriver object
 *
 * @notapi
 */
int8_t fm_lld_get_snr(FMDriver *fmp)
{
  (void)fmp;
  return (int8_t)((HS_BTPHY->FM_RSSI >> 4) & 0xff);
}

#if defined(BR3215)
int fm_lld_check_freq_old(FMDriver *fmp, int freq)
{
  int8_t rssi_th  = (fmp->config ? fmp->config->rssi : 6);
  int8_t snr_th   = (fmp->config ? fmp->config->snr : 0);
  int8_t rssi_th2 = (fmp->config ? fmp->config->rssi_stereo : 22);
  int8_t snr_th2  = (fmp->config ? fmp->config->snr_stereo : -128);
  uint8_t chhc_th = (fmp->config ? fmp->config->chhc : 15);
  uint8_t lrhc_th = (fmp->config ? fmp->config->lrhc : 12);
  int8_t rssi_noise;
  uint16_t fc_seeked = 0;

  /* borrow this API to reset fsm */
  if (0 == freq) {
    fmp->num_tracks = 0;
    return 0;
  }

  fm_lld_set_freq(fmp, freq);

  /* get rssi & snr */
  osalThreadSleep(OSAL_MS2ST(60));
  fmp->rssis[3] = fm_lld_get_rssi(fmp);
  fmp->snrs[3]  = fm_lld_get_snr(fmp);
  fmp->freqs[3] = freq;
  /* temp hack */
  if (fmp->snrs[3] >= 8) {
    fc_seeked = freq;
  }

  if (fmp->num_tracks < 4)
    fmp->num_tracks++;

  /* check threshold */
  if ((fmp->num_tracks == 4) &&
      ((fmp->rssis[2] >= (fmp->rssis[0] + rssi_th)) &&
       (fmp->rssis[3] <=  fmp->rssis[2]) &&
       (fmp->rssis[1] <=  fmp->rssis[2]) &&
       (fmp->snrs[2]  >= snr_th) &&
       /* unreliable at 96.0MHz due to interference by digital source */
       ((fmp->freqs[2] != 960) && (fmp->freqs[2] != 959)))) {
    fmp->num_tracks = 0;
    fc_seeked = fmp->freqs[2];

    /* fm stereo new alg by zhangzd on 2016.12.09 */
    rssi_noise = fmp->rssis[0];
    HS_BTPHY->FM_STEREO =
      ((uint8_t)(snr_th2)/*snr_thl*/ << 24) |
      ((uint8_t)(snr_th2+0)/*snr_thh*/ << 16) |
      ((uint8_t)(rssi_noise+rssi_th2)/*rssi_thl*/ << 8) |
      ((uint8_t)(rssi_noise+rssi_th2+FM_STEREO_RSSI_TH_DELTA)/*rssi_thh*/ << 0);

    if ((fmp->rssis[2] - fmp->rssis[0]) >= chhc_th) {
      HS_BTPHY->FM_CHHC_FILT &= ~(1 << 16); //fm_chhc_filt_en=0
    }
    else {
      HS_BTPHY->FM_CHHC_FILT |= (1 << 16); //fm_chhc_filt_en=1
    }
    if ((fmp->rssis[2] - fmp->rssis[0]) >= lrhc_th) {
      HS_BTPHY->FM_LRHC_FILT &= ~(1 << 16); //fm_lrhc_filt_en=0
    }
    else {
      HS_BTPHY->FM_LRHC_FILT |= (1 << 16); //fm_lrhc_filt_en=1
    }
  }
  else if ((fmp->num_tracks == 4) &&
           ((fmp->rssis[1] >= (fmp->rssis[3] + rssi_th)) &&
            (fmp->rssis[0] <=  fmp->rssis[1]) &&
            (fmp->rssis[3] <=  fmp->rssis[2]) &&
            (fmp->snrs[1]  >= snr_th) &&
           /* unreliable at 96.0MHz due to interference by digital source */
            ((fmp->freqs[1] != 960) && (fmp->freqs[1] != 959)))) {
    fmp->num_tracks = 0;
    fc_seeked = fmp->freqs[1];

    rssi_noise = fmp->rssis[3];
    HS_BTPHY->FM_STEREO =
      ((uint8_t)(snr_th2)/*snr_thl*/ << 24) |
      ((uint8_t)(snr_th2+0)/*snr_thh*/ << 16) |
      ((uint8_t)(rssi_noise+rssi_th2)/*rssi_thl*/ << 8) |
      ((uint8_t)(rssi_noise+rssi_th2+FM_STEREO_RSSI_TH_DELTA)/*rssi_thh*/ << 0);

    if ((fmp->rssis[1] - fmp->rssis[3]) >= chhc_th) {
      HS_BTPHY->FM_CHHC_FILT &= ~(1 << 16); //fm_chhc_filt_en=0
    }
    else {
      HS_BTPHY->FM_CHHC_FILT |= (1 << 16); //fm_chhc_filt_en=1
    }
    if ((fmp->rssis[1] - fmp->rssis[3]) >= lrhc_th) {
      HS_BTPHY->FM_LRHC_FILT &= ~(1 << 16); //fm_lrhc_filt_en=0
    }
    else {
      HS_BTPHY->FM_LRHC_FILT |= (1 << 16); //fm_lrhc_filt_en=1
    }
  }
  else {
    fmp->rssis[0] = fmp->rssis[1];
    fmp->rssis[1] = fmp->rssis[2];
    fmp->rssis[2] = fmp->rssis[3];
    fmp->snrs[0]  = fmp->snrs[1];
    fmp->snrs[1]  = fmp->snrs[2];
    fmp->snrs[2]  = fmp->snrs[3];
    fmp->freqs[0] = fmp->freqs[1];
    fmp->freqs[1] = fmp->freqs[2];
    fmp->freqs[2] = fmp->freqs[3];
  }

  return fc_seeked;
}
#elif defined(BR3215e)
int fm_lld_check_freq(FMDriver *fmp, int freq, bool bNext)
{
  int8_t rssi_th  = (fmp->config ? fmp->config->rssi : 4);
  int8_t ncfo_th  = (fmp->config ? fmp->config->ncfo : 13);
  int8_t ncfo_th2  = (fmp->config ? fmp->config->snr : 25);
  int8_t rssi_th2 = (fmp->config ? fmp->config->rssi_stereo : 40);
  uint8_t chhc_th = (fmp->config ? fmp->config->chhc : 15);
  uint8_t lrhc_th = (fmp->config ? fmp->config->lrhc : 12);
  uint8_t seek_opt = (fmp->config ? fmp->config->opt : 0);
  int8_t rssi_noise;
  uint16_t fc_seeked = 0;

  /* borrow this API to reset fsm */
  if (0 == freq) {
    fmp->num_tracks = 0;
    return 0;
  }

  /* disable hi-cut during scan the valid fm stations, and enable it automatically when seeked one */
  HS_BTPHY->FM_CHHC_FILT &= ~((1 << 20) | (1 << 16)); //fm_hc_mode=0: reg set; fm_chhc_filt_en=0 in default

  fm_lld_set_freq(fmp, freq);
  /* get rssi after demod is stable */
  osalThreadSleep(OSAL_MS2ST(40));
  if (bNext) {
    fmp->rssis[3] = fm_lld_get_rssi(fmp);
    fmp->ncfos[3] = (int8_t)(HS_BTPHY->FM_RSSI >> 24);
    fmp->freqs[3] = freq;
  }
  else {
    fmp->rssis[0] = fm_lld_get_rssi(fmp);
    fmp->ncfos[0] = (int8_t)(HS_BTPHY->FM_RSSI >> 24);
    fmp->freqs[0] = freq;
  }

  /* track 4 adjacent fm stations */
  if (fmp->num_tracks < 4) {
    fmp->num_tracks++;
  }

  /* check threshold after got 4 records */
  if ((fmp->num_tracks == 4) &&
      ((fmp->rssis[2] >= (fmp->rssis[0] + rssi_th)) &&
       (abs(fmp->ncfos[2]) <= ncfo_th) &&
       ( ((seek_opt == 0) && ((fmp->ncfos[3] >= ncfo_th2) || (fmp->ncfos[1] <= -ncfo_th2))) ||
         ((seek_opt == 1) && ((fmp->ncfos[3] >= ncfo_th2) && (fmp->ncfos[1] <= -ncfo_th2))) ||
         ((seek_opt == 2) && (fmp->rssis[2] >= fmp->rssis[1]) && (fmp->rssis[2] >= fmp->rssis[3]))
         ) &&
       /* unreliable at 96.0MHz due to interference by digital source */
       ((fmp->freqs[2] != 960) /*&& (fmp->freqs[2] != 959)*/))) {
    /* hint to invalidate the tracks */
    fmp->num_tracks = 0;
    fc_seeked = fmp->freqs[2];

    rssi_noise = fmp->rssis[0];
    fmp->rssi_noise = rssi_noise;
    debug("  freq=%d at2: rssi=%d ncfo=%d nsnr=%d rssi_noise=%d\n", fc_seeked, fmp->rssis[2], fmp->ncfos[2]*75*1000/64, fmp->rssis[2]-fmp->rssis[0], rssi_noise);
    HS_BTPHY->FM_STEREO =
      ((uint8_t)(rssi_noise+rssi_th2)/*rssi_thl*/ << 8) |
      ((uint8_t)(rssi_noise+rssi_th2+FM_STEREO_RSSI_TH_DELTA)/*rssi_thh*/ << 0);
    HS_BTPHY->FM_CHHC_FILT =
      (1 << 20) | //fm_hc_mode=1: auto, it will enable hi-cut mode automatically if SNR is worse
      ((uint8_t)(rssi_noise+chhc_th)/*chhc_rssi_thl*/ << 0) |
      ((uint8_t)(rssi_noise+chhc_th+FM_STEREO_RSSI_TH_DELTA)/*chhc_rssi_thh*/ << 8);
    HS_BTPHY->FM_LRHC_FILT =
      ((uint8_t)(rssi_noise+lrhc_th)/*lrhc_rssi_thl*/ << 0) |
      ((uint8_t)(rssi_noise+lrhc_th+FM_STEREO_RSSI_TH_DELTA)/*lrhc_rssi_thh*/ << 8);
    #if 0//due to fm_hc_mode=1
    if ((fmp->rssis[2] - fmp->rssis[0]) >= chhc_th) {
      HS_BTPHY->FM_CHHC_FILT &= ~(1 << 16); //fm_chhc_filt_en=0
    }
    else {
      HS_BTPHY->FM_CHHC_FILT |= (1 << 16); //fm_chhc_filt_en=1
    }
    if ((fmp->rssis[2] - fmp->rssis[0]) >= lrhc_th) {
      HS_BTPHY->FM_LRHC_FILT &= ~(1 << 16); //fm_lrhc_filt_en=0
    }
    else {
      HS_BTPHY->FM_LRHC_FILT |= (1 << 16); //fm_lrhc_filt_en=1
    }
    #endif
  }
  else if ((fmp->num_tracks == 4) &&
           ((fmp->rssis[1] >= (fmp->rssis[3] + rssi_th)) &&
            (abs(fmp->ncfos[1]) <= ncfo_th) &&
            ( ((seek_opt == 0) && ((fmp->ncfos[2] >= ncfo_th2) || (fmp->ncfos[0] <= -ncfo_th2))) ||
              ((seek_opt == 1) && ((fmp->ncfos[2] >= ncfo_th2) && (fmp->ncfos[0] <= -ncfo_th2))) ||
              ((seek_opt == 2) && (fmp->rssis[1] >= fmp->rssis[0]) && (fmp->rssis[1] >= fmp->rssis[2]))
              ) &&
           /* unreliable at 96.0MHz due to interference by digital source */
            ((fmp->freqs[1] != 960) /*&& (fmp->freqs[1] != 959)*/))) {
    fmp->num_tracks = 0;
    fc_seeked = fmp->freqs[1];

    rssi_noise = fmp->rssis[3];
    fmp->rssi_noise = rssi_noise;
    debug("  freq=%d at1: rssi=%d ncfo=%d nsnr=%d rssi_noise=%d\n", fc_seeked, fmp->rssis[1], fmp->ncfos[1]*75*1000/64, fmp->rssis[1]-fmp->rssis[3], rssi_noise);
    HS_BTPHY->FM_STEREO =
      ((uint8_t)(rssi_noise+rssi_th2)/*rssi_thl*/ << 8) |
      ((uint8_t)(rssi_noise+rssi_th2+FM_STEREO_RSSI_TH_DELTA)/*rssi_thh*/ << 0);
    HS_BTPHY->FM_CHHC_FILT =
      (1 << 20) | //fm_hc_mode=1: auto, it will enable hi-cut mode automatically if SNR is worse
      ((uint8_t)(rssi_noise+chhc_th)/*chhc_rssi_thl*/ << 0) |
      ((uint8_t)(rssi_noise+chhc_th+FM_STEREO_RSSI_TH_DELTA)/*chhc_rssi_thh*/ << 8);
    HS_BTPHY->FM_LRHC_FILT =
      ((uint8_t)(rssi_noise+lrhc_th)/*lrhc_rssi_thl*/ << 0) |
      ((uint8_t)(rssi_noise+lrhc_th+FM_STEREO_RSSI_TH_DELTA)/*lrhc_rssi_thh*/ << 8);
    #if 0
    if ((fmp->rssis[1] - fmp->rssis[3]) >= chhc_th) {
      HS_BTPHY->FM_CHHC_FILT &= ~(1 << 16); //fm_chhc_filt_en=0
    }
    else {
      HS_BTPHY->FM_CHHC_FILT |= (1 << 16); //fm_chhc_filt_en=1
    }
    if ((fmp->rssis[1] - fmp->rssis[3]) >= lrhc_th) {
      HS_BTPHY->FM_LRHC_FILT &= ~(1 << 16); //fm_lrhc_filt_en=0
    }
    else {
      HS_BTPHY->FM_LRHC_FILT |= (1 << 16); //fm_lrhc_filt_en=1
    }
    #endif
  }
  else {
    /* always keep track unless seeked */
    if (bNext) {
      fmp->rssis[0] = fmp->rssis[1];
      fmp->rssis[1] = fmp->rssis[2];
      fmp->rssis[2] = fmp->rssis[3];
      fmp->ncfos[0] = fmp->ncfos[1];
      fmp->ncfos[1] = fmp->ncfos[2];
      fmp->ncfos[2] = fmp->ncfos[3];
      fmp->freqs[0] = fmp->freqs[1];
      fmp->freqs[1] = fmp->freqs[2];
      fmp->freqs[2] = fmp->freqs[3];
    }
    else {
      fmp->rssis[3] = fmp->rssis[2];
      fmp->rssis[2] = fmp->rssis[1];
      fmp->rssis[1] = fmp->rssis[0];
      fmp->ncfos[3] = fmp->ncfos[2];
      fmp->ncfos[2] = fmp->ncfos[1];
      fmp->ncfos[1] = fmp->ncfos[0];
      fmp->freqs[3] = fmp->freqs[2];
      fmp->freqs[2] = fmp->freqs[1];
      fmp->freqs[1] = fmp->freqs[0];
    }
  }

  return fc_seeked;
}
#endif

/**
 * @brief   get FM phy threshold after scan a channel
 *
 * @param[in] fmp      pointer to the @p FMDriver object
 * @return             [17]lrhc_filt_en [16]chhc_filt_en [15:8]stereo_rssi_thl [7:0]stereo_rssi_thh
 *
 * @notapi
 */
uint16_t fm_lld_get_hwctx(FMDriver *fmp)
{
  #if defined(BR3215)
  (void)fmp;
  uint16_t rssi2 = (HS_BTPHY->FM_STEREO & 0x0000FF00) >> 8;
  /* borrow 2-bit to save the enable bits of high-cut */
  rssi2 |= (HS_BTPHY->FM_CHHC_FILT & (1u << 16)) ? (1 << 8) : 0;
  rssi2 |= (HS_BTPHY->FM_LRHC_FILT & (1u << 16)) ? (1 << 9) : 0;
  return rssi2;

  #elif defined(BR3215e)
  /* the context is rssi_noise */
  return fmp->rssi_noise;
  #endif
}

/**
 * @brief   set FM phy threshold after set a channel
 *
 * @param[in] fmp      pointer to the @p FMDriver object
 *
 * @notapi
 */
void fm_lld_set_hwctx(FMDriver *fmp, uint16_t ctx)
{
  #if defined(BR3215)
  (void)fmp;
  uint8_t rssi2;
  if (0 == ctx)
    return;
  rssi2 = ctx & 0xff;
  HS_BTPHY->FM_STEREO = (HS_BTPHY->FM_STEREO & 0xFFFF0000) |
    (rssi2/*rssi_thl*/ << 8) | ((rssi2+FM_STEREO_RSSI_TH_DELTA)/*rssi_thh*/ << 0);
  if (ctx & (1u << 8))
    HS_BTPHY->FM_CHHC_FILT |= (1u << 16);
  else
    HS_BTPHY->FM_CHHC_FILT &= ~(1u << 16);
  if (ctx & (1u << 9))
    HS_BTPHY->FM_LRHC_FILT |= (1u << 16);
  else
    HS_BTPHY->FM_LRHC_FILT &= ~(1u << 16);

  #elif defined(BR3215e)
  int8_t rssi_th2 = (fmp->config ? fmp->config->rssi_stereo : 24);
  uint8_t chhc_th = (fmp->config ? fmp->config->chhc : 15);
  uint8_t lrhc_th = (fmp->config ? fmp->config->lrhc : 12);
  int8_t rssi_noise = (int8_t)ctx;
  HS_BTPHY->FM_STEREO =
    ((uint8_t)(rssi_noise+rssi_th2)/*rssi_thl*/ << 8) |
    ((uint8_t)(rssi_noise+rssi_th2+FM_STEREO_RSSI_TH_DELTA)/*rssi_thh*/ << 0);
  HS_BTPHY->FM_CHHC_FILT =
    (1 << 20) | //fm_hc_mode=1: auto, it will enable hi-cut mode automatically if SNR is worse
    ((uint8_t)(rssi_noise+chhc_th)/*chhc_rssi_thl*/ << 0) |
    ((uint8_t)(rssi_noise+chhc_th+FM_STEREO_RSSI_TH_DELTA)/*chhc_rssi_thh*/ << 8);
  HS_BTPHY->FM_LRHC_FILT =
    ((uint8_t)(rssi_noise+lrhc_th)/*lrhc_rssi_thl*/ << 0) |
    ((uint8_t)(rssi_noise+lrhc_th+FM_STEREO_RSSI_TH_DELTA)/*lrhc_rssi_thh*/ << 8);
  #endif
}

#endif /* HAL_USE_FM */

/** @} */
