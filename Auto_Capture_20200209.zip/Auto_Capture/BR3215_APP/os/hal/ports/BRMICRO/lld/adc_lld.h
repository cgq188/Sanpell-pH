/*
    ChibiOS/RT - Copyright (C) 2006-2013 Giovanni Di Sirio
    Copyright (C) 2019 BRMICRO Technologies
                 
                 

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    templates/adc_lld.h
 * @brief   ADC Driver subsystem low level driver header template.
 *
 * @addtogroup ADC
 * @{
 */

#ifndef _ADC_LLD_H_
#define _ADC_LLD_H_

#if HAL_USE_ADC || defined(__DOXYGEN__)

/*===========================================================================*/
/* Driver constants.                                                         */
/*===========================================================================*/

/**
 * By setting HS_ANA.COMMEN_PACK[0].bit[31] = 1, the gain of ADC's internal
 * Pre-gain amplifier multiplies 1/4, and the measurable signal input amplitude
 * grows from 1.8v up to 4.2v.
 * But hard-compensation does not include it whose compensation must be done
 * together with compensation of gain, so soft-compensation must be enabled to
 * use it.
 * This extended range should only be used with vcm = 1000
 * and gain = 1 to measure voltage around [3.5v, 4.2v].
 */
#define HS_ADC_EXTENDED_RANGE_ENABLE          FALSE

/**
 * Q: fractional bits of fixed-point format.
 */
#define ADC_Q       (HS_ADC0_RESOLUTION - 1)


/**
 * @brief   The address of ADC calibration parameters table in Flash.
 * @note    The parameters are measured and filled into the table
 *          during FT test.
 */
#if defined(BR3215)
#define ADC_CAL_TABLE     \
	((adc_cal_table_t*)((adc_cal_param_3215_t*)(0x800ff000u + 8)))
#else
#define ADC_CAL_TABLE     \
	((adc_cal_table_t*)(0x80000000 + 512*1024 - sizeof(adc_cal_table_t)))
#endif

/*===========================================================================*/
/* Driver pre-compile time settings.                                         */
/*===========================================================================*/

#if (HS_HAS_DMA == TRUE) && (ADC_USE_DMA == TRUE)
#include "dma_lld.h"

#if !defined(HS_ADC_DMA_PRIORITY) || defined(__DOXYGEN__)
#define HS_ADC_DMA_PRIORITY               0
#endif

#endif // ADC_USE_DMA

/**
 * @name    Configuration options
 * @{
 */
/**
 * @brief   ADC1 driver enable switch.
 * @details If set to @p TRUE the support for ADC1 is included.
 * @note    The default is @p FALSE.
 */
#if !defined(HS_ADC_USE_ADC0) || defined(__DOXYGEN__)
#define HS_ADC_USE_ADC0             TRUE
#endif
/** @} */

#if !defined(HS_ADC_ADC0_IRQ_PRIORITY) || defined(__DOXYGEN__)
#define HS_ADC_ADC0_IRQ_PRIORITY          3
#endif

/*===========================================================================*/
/* Derived constants and error checks.                                       */
/*===========================================================================*/

/**
 * ADC interrupt mask bit definitions.
 * EOC - End of conversion.
 * EOS - End of sequence of conversion.
 */
#define ADC_INTR_MASK_EOS                 (1u << 9)

#define ADC_START_BIT                     (1u<<0)
#define ADC_STOP_BIT                      (1u<<1)

/*===========================================================================*/
/* Driver data structures and types.                                         */
/*===========================================================================*/
/**
 * @brief   ADC sample data type.
 *          In fixed-point format of Q4.11.
 */
typedef int16_t adcsample_t;

/**
 * @brief   Channels number in a conversion group.
 */
typedef uint16_t adc_channels_num_t;

/**
 * @brief   Possible ADC failure causes.
 * @note    Error codes are architecture dependent and should not relied
 *          upon.
 */
typedef enum {
  ADC_ERR_DMAFAILURE = 0,                   /**< DMA operations failure.    */
  ADC_ERR_OVERFLOW = 1,                     /**< ADC overflow condition.    */
  ADC_ERR_AWD = 2                           /**< Analog watchdog triggered. */
} adcerror_t;

/**
 * @brief   Type of a structure representing an ADC driver.
 */
typedef struct ADCDriver ADCDriver;

/**
 * @brief   ADC notification callback type.
 *
 * @param[in] adcp      pointer to the @p ADCDriver object triggering the
 *                      callback
 * @param[in] buffer    pointer to the most recent samples data
 * @param[in] n         number of buffer rows available starting from @p buffer
 */
typedef void (*adccallback_t)(ADCDriver *adcp, adcsample_t *buffer, size_t n);

/**
 * @brief   ADC error callback type.
 *
 * @param[in] adcp      pointer to the @p ADCDriver object triggering the
 *                      callback
 * @param[in] err       ADC error code
 */
typedef void (*adcerrorcallback_t)(ADCDriver *adcp, adcerror_t err);

typedef enum adc_channel_t {
  ADC_CHANNEL_CHIP_TEMPERATURE   = 0,
  ADC_CHANNEL_CHIP_BATTERY       , // vbat, attenuation = 1/3
  ADC_CHANNEL_CHIP_VCM           ,
#if defined(BR3215e)
  ADC_CHANNEL_CHIP_1V4           , // 1.4V, internal, attenuation = 5/7
  ADC_CHANNEL_CHIP_3V3           , // 3.3V, internal, attenuation = 1/2
  /**
   * GPIO pins:
   * 1. GPIO INPUT mode without pullup and pulldown.
   * 2. More info about GPIO selection please refer to comment of
   *    @p ADCConversionGroup.gpio_sel.
   */
  ADC_CHANNEL_EXTERN_PIN0        , // pad_gpio_1<4:0>, selected by HS_PMU->WAKEUP_COMN_CFG[15:12].adckey_sel[3:0]
  ADC_CHANNEL_EXTERN_PIN1        , // pad_gpio_2<4:0>, selected by HS_PMU->WAKEUP_COMN_CFG[15:12].adckey_sel[3:0]
  ADC_CHANNEL_EXTERN_PIN2        , // pad_gpio_3<4:0>, selected by HS_PMU->WAKEUP_COMN_CFG[15:12].adckey_sel[3:0]
#else
  ADC_CHANNEL_EXTERN_PIN0        , // GPIO1, GPIO INPUT mode without pullup and pulldown.
  ADC_CHANNEL_EXTERN_PIN1        , // GPIO2, GPIO INPUT mode without pullup and pulldown.
  ADC_CHANNEL_EXTERN_PIN2        , // GPIO3, GPIO INPUT mode without pullup and pulldown.
  ADC_CHANNEL_EXTERN_PIN3        , // GPIO4, GPIO INPUT mode without pullup and pulldown.
  ADC_CHANNEL_EXTERN_PIN4        , // GPIO5, GPIO INPUT mode without pullup and pulldown.
#endif
  ADC_CHANNEL_PEAK_DETECTOR      , // Not for user, only used for transmitter calibration.
  
  ADC_CHANNEL_NUM
} adc_channel_t;

/**
 * @brief Gain selection of ADC's Pre-Gain-Amplifier (PGA).
 * @note  The PGA is used to adapt input signal to be within the ADC's
 *        valid range. So if the input signal is too large for the ADC,
 *        use a gain of 0.5 to attenuate it. Or if the signal is
 *        so small, use a gain of 2 or 4 to enlarge it to improve
 *        conversion accuracy.
 */
typedef enum adc_pga_gain_t {
  ADC_PGA_GAIN_0P5             = 0,
  ADC_PGA_GAIN_1               ,
  ADC_PGA_GAIN_2               ,
  ADC_PGA_GAIN_4               ,

  ADC_PGA_GAIN_MAX
} adc_pga_gain_t;

/**
 * ADC internal VCM (Common Mode Voltage) selection.
 */
typedef enum adc_vcm_t {
  ADC_VCM_SEL_000mV                 = 0,
  ADC_VCM_SEL_125mV                 ,
  ADC_VCM_SEL_250mV                 ,
  ADC_VCM_SEL_375mV                 ,
  ADC_VCM_SEL_500mV                 ,
  ADC_VCM_SEL_625mV                 ,
  ADC_VCM_SEL_750mV                 ,
  ADC_VCM_SEL_875mV                 ,
  ADC_VCM_SEL_1000mV                ,
  ADC_VCM_SEL_1125mV                ,
  ADC_VCM_SEL_1250mV                ,
  ADC_VCM_SEL_1375mV                ,
  ADC_VCM_SEL_1500mV                ,
  ADC_VCM_SEL_1625mV                ,
  ADC_VCM_SEL_1750mV                ,
  ADC_VCM_SEL_1875mV                ,
  ADC_VCM_MAX
} adc_vcm_t;

/**
 * @brief   ADC trigger source selection.
 */
typedef enum adc_trigger_source_t {
  ADC_TRIGGER_SOURCE_TM0_0             = 0, /* Timer0 channel 0 */
  ADC_TRIGGER_SOURCE_TM0_1             ,
  ADC_TRIGGER_SOURCE_TM0_2             ,
  ADC_TRIGGER_SOURCE_TM0_3             ,
  ADC_TRIGGER_SOURCE_TM1_0             ,
  ADC_TRIGGER_SOURCE_TM1_1             ,
  ADC_TRIGGER_SOURCE_TM1_2             ,
  ADC_TRIGGER_SOURCE_TM1_3             ,
  ADC_TRIGGER_SOURCE_TM2_0             ,
  ADC_TRIGGER_SOURCE_TM2_1             ,
  ADC_TRIGGER_SOURCE_TM2_2             ,
  ADC_TRIGGER_SOURCE_TM2_3             ,    /* Timer2 channel 3 */
  ADC_TRIGGER_SOURCE_EXT               ,    /* GPIO12 in SFLASH mode */
  ADC_TRIGGER_SOURCE_SW                ,
} adc_trigger_source_t;

typedef enum adc_trigger_edge_t {
  ADC_TRIGGER_EDGE_POS                 = 0,
  ADC_TRIGGER_EDGE_NEG                 ,
  ADC_TRIGGER_EDGE_DUAL                ,
  ADC_TRIGGER_EDGE_NOTUSED             ,   /* Same as EDGE_POS  */
} adc_trigger_edge_t;

/**
 * @note As to ONESHOT type of trigger targets, as many trigger events as
 *       conversion depth are expected for each adcConvert() invocation to
 *       return.
 */
typedef enum adc_trigger_target_t {
	ADC_TRIGGER_TARGET_GROUP_ONESHOT             = 0, /* CONT=0, DISCEN=0: one shot of group per event. */
	ADC_TRIGGER_TARGET_CHANNEL_ONESHOT           ,    /* CONT=0, DISCEN=1: one shot of channel per event. */
	ADC_TRIGGER_TARGET_GROUP_CONTINUOUS          ,    /* CONT=1, DISCEN=0: repeat forever once triggered. */
} adc_trigger_target_t;

typedef struct adc_trigger_t {
	adc_trigger_source_t     source; // including soft and hard
	adc_trigger_edge_t       edge;   // apply only to hard trigger source
	adc_trigger_target_t     target; // trigger group or channel.
} adc_trigger_t;

/**
 * @brief ADC calibration parameters specific to PGA gain used to compensate
 *        converted data.
 */
typedef struct adc_cal_param_t {
	int16_t vos_mod;  /* @brief voltage-offset modifier in V, in fixed-point format of Q0.11. */
	int16_t gain_mod; /* @brief PGA (Pre-Gain-Amplifier) gain modifier, in fixed-point format of UQ1.11. */
	int16_t vcm_mod;  /* @brief VCM modifier, in fixed-point format of UQ1.11. */
} adc_cal_param_t;

#if defined(BR3215)
/**
 * @brief ADC calibration parameters in floating-point format used in BR3215.
 */
typedef struct adc_cal_param_3215_t {
	float mvos_mod; /* @brief voltage-offset modifier in mV, in floating-point format. */
	float gain_mod; /* @brief PGA (Pre-Gain-Amplifier) gain modifier, in floating-point format. */
} adc_cal_param_3215_t;
#endif

/**
 * @brief ADC calibration parameter table storing all the @p adc_cal_param_t
 *        parameters.
 */
typedef struct adc_cal_table_t {
	// single-ended
	union {
		__IO uint32_t   s_vos_mod_lut0;
		struct {
			__IO uint32_t   s_vos_mod_0   : 12; /* same as adc_cal_param_t.vos_mod */
			__IO uint32_t                 :  4;
			__IO uint32_t   s_vos_mod_1   : 12;
			__IO uint32_t                 :  4;
		};
	};
	union {
		__IO uint32_t   s_vos_mod_lut1;
		struct {
			__IO uint32_t   s_vos_mod_2   : 12;
			__IO uint32_t                 :  4;
			__IO uint32_t   s_vos_mod_3   : 12;
			__IO uint32_t                 :  4;
		};
	};
	union {
		__IO uint32_t   s_gain_mod_lut0;
		struct {
			__IO uint32_t   s_gain_mod_0  : 12; /* same as adc_cal_param_t.gain_mod */
			__IO uint32_t                 :  4;
			__IO uint32_t   s_gain_mod_1  : 12;
			__IO uint32_t                 :  4;
		};
	};
	union {
		__IO uint32_t   s_gain_mod_lut1;
		struct {
			__IO uint32_t   s_gain_mod_2  : 12;
			__IO uint32_t                 :  4;
			__IO uint32_t   s_gain_mod_3  : 12;
			__IO uint32_t                 :  4;
		};
	};
	union {
		__IO uint32_t   s_vcm_mod_lut0;
		struct {
			__IO uint32_t   s_vcm_mod_0   : 12; /* same as adc_cal_param_t.vcm_mod */
			__IO uint32_t                 :  4;
			__IO uint32_t   s_vcm_mod_1   : 12;
			__IO uint32_t                 :  4;
		};
	};
	union {
		__IO uint32_t   s_vcm_mod_lut1;
		struct {
			__IO uint32_t   s_vcm_mod_2   : 12;
			__IO uint32_t                 :  4;
			__IO uint32_t   s_vcm_mod_3   : 12;
			__IO uint32_t                 :  4;
		};
	};

	// differential
	union {
		__IO uint32_t   d_vos_mod_lut0;
		struct {
			__IO uint32_t   d_vos_mod_0   : 12;
			__IO uint32_t                 :  4;
			__IO uint32_t   d_vos_mod_1   : 12;
			__IO uint32_t                 :  4;
		};
	};
	union {
		__IO uint32_t   d_vos_mod_lut1;
		struct {
			__IO uint32_t   d_vos_mod_2   : 12;
			__IO uint32_t                 :  4;
			__IO uint32_t   d_vos_mod_3   : 12;
			__IO uint32_t                 :  4;
		};
	};
	union {
		__IO uint32_t   d_gain_mod_lut0;
		struct {
			__IO uint32_t   d_gain_mod_0  : 12;
			__IO uint32_t                 :  4;
			__IO uint32_t   d_gain_mod_1  : 12;
			__IO uint32_t                 :  4;
		};
	};
	union {
		__IO uint32_t   d_gain_mod_lut1;
		struct {
			__IO uint32_t   d_gain_mod_2  : 12;
			__IO uint32_t                 :  4;
			__IO uint32_t   d_gain_mod_3  : 12;
			__IO uint32_t                 :  4;
		};
	};
} adc_cal_table_t;

/**
 * @brief   ADC timing configuration.
 *          Used for debugging only.
 */
typedef struct adc_timing_t {
  uint8_t  t1;             /* Timing 1: 0~0xf,   default: 0x6   */
  uint8_t  t2;             /* Timing 2: 0~0xf,   default: 0x6   */
  uint8_t  t3;             /* Timing 3: 0~0xf,   default: 0x1   */
  uint8_t  t4;             /* Timing 4: 0~0xf,   default: 0x4   */
  uint16_t t5;             /* Timing 5: 0~0xfff, default: 0x348 */
  uint8_t  t6;             /* Timing 6: 0~0x3f,  default: 0x18  */

  uint8_t  cic_cycle;      /* Circulating cycles: 0~0xff,  default: 0x40  */
  uint8_t  smp_cycle;      /* Sampling cycles:    0~0xf,   default: 0x1   */
  uint8_t  rst_cycle;      /* Reset cycles:       0~0xf,   default: 0x1   */
} adc_timing_t;

/**
 * @brief ADC channel parameters mapping to register @p ADC_ANA_REG0..8.
 */
typedef struct adc_channel_param_t {
	union {
		__IO uint32_t   val;                /**< @brief value for ADC_ANA_REGx */
		struct {
			__IO uint32_t en_r2r         : 1; /**< @brief Bit0: enable rail-to-rail buffer. Set it to be default enabled. */
			__IO uint32_t en_chop        : 1; /**< @brief Bit1: enable chopper. chopper is used for low frequency signal
			                                                    and must use distinct cal_params.
			                                                    Normally not used, set it to be default disabled. */
			__IO uint32_t                : 1; /**< @brief Bit2: Not used. */
			__IO uint32_t gtune          : 2; /**< @brief Bit[3..4]: PGA (Pre-Gain-Amplifier) gain tuning: 0-0.5, 1-1, 2-2, 3-4. */
			__IO uint32_t ldoctrl        : 2; /**< @brief Bit[5..6]: ADC LDO compensation control due to deviation caused by manufacture:
			                                                         0-2.3v, 1-2.4v, 2-2.5v, 3-2.6v. (Normally not used, set it to be default 2.4v.)
			                                                         Example: If LDO is 2.3v which should be 2.4v, selecting
			                                                         ldoctrl=2.3v will compensate it internally. */
			__IO uint32_t sel_fchop      : 2; /**< @brief Bit[7..8]: select the chopper frequency (effective when chopper is enabled):
			                                                         0-1/32*fs, 1-1/16*fs, 2-1/8*fs, 3-1/4*fs, fs(sampling frequency)=16MHz */
			__IO uint32_t sel_inn        : 4; /**< @brief Bit[9..12]: @p adc_channel_t, select negative input channel.
			                                                          default ADC_CHANNEL_CHIP_VCM as defined is single-ended input. */
			__IO uint32_t sel_vcm        : 4; /**< @brief Bit[13..16]: select VCM (Common_Mode_Voltage, here just a name for a internal bias voltage) voltage of VCM channel:
			                                                           0-0v, 1-0.125v, 2-0.25v, ..., 8-1.0v, ..., 14-1.75v, 15-1.875v. */
			__IO uint32_t en_count_sar   : 1; /**< @brief Bit17: enable count_sar */
			__IO uint32_t en_dem_sar     : 1; /**< @brief Bit18: enable dem_sar */
			__IO uint32_t sar_buf        : 1; /**< @brief Bit19: enable SAR (Successive Approximation Register) buffer */
			__IO uint32_t en_sar_ckdelay : 4; /**< @brief Bit[20..23]: enable SAR clock delay */

			/**
			 * Bits extended by hgz, not really exist in register.
			 */
#if defined(BR3215e)
  /**
   * ADC gpio pin selection for BR3215e:
   * gpio_sel = HS_PMU->WAKEUP_COMN_CFG[15:12].adckey_sel<3:0> (moved from HS_ANA->ANA_CFG_NEW.adckey_sel<3:0>)
   *
   *   ---------------------------------------------------------------------------------------------
   *   | gpio_sel | adckey_sel | GPIO_PIN                          | ADC_CHANNEL                   |
   *   ---------------------------------------------------------------------------------------------
   *   |       0  | 0000       | no input, default                 | none                          |
   *   |----------|------------|-----------------------------------|-------------------------------|
   *   |       1  | 0001       | pad_gpio_1<0> =GPIO<2> =GPIOA<2>  | \                             |
   *   |       2  | 0010       | pad_gpio_1<1> =GPIO<3> =GPIOA<3>  |  \                            |
   *   |       3  | 0011       | pad_gpio_1<2> =GPIO<4> =GPIOA<4>  |   => ADC_CHANNEL_EXTERN_PIN0  |
   *   |       4  | 0100       | pad_gpio_1<3> =GPIO<5> =GPIOA<5>  |  /                            |
   *   |       5  | 0101       | pad_gpio_1<4> =GPIO<9> =GPIOA<9>  | /                             |
   *   |----------|------------|-----------------------------------|-------------------------------|
   *   |       6  | 0110       | pad_gpio_2<0> =GPIO<10 =GPIOA<10> | \                             |
   *   |       7  | 0111       | pad_gpio_2<1> =GPIO<11 =GPIOA<11> |  \                            |
   *   |       8  | 1000       | pad_gpio_2<2> =GPIO<12 =GPIOA<12> |   => ADC_CHANNEL_EXTERN_PIN1  |
   *   |       9  | 1001       | pad_gpio_2<3> =GPIO<13 =GPIOA<13> |  /                            |
   *   |      10  | 1010       | pad_gpio_2<4> =GPIO<16 =GPIOB<0>  | /                             |
   *   |----------|------------|-----------------------------------|-------------------------------|
   *   |      11  | 1011       | pad_gpio_3<0> =GPIO<17 =GPIOB<1>  | \                             |
   *   |      12  | 1100       | pad_gpio_3<1> =GPIO<18 =GPIOB<2>  |  \                            |
   *   |      13  | 1101       | pad_gpio_3<2> =GPIO<19 =GPIOB<3>  |   => ADC_CHANNEL_EXTERN_PIN2  |
   *   |      14  | 1110       | pad_gpio_3<3> =GPIO<20 =GPIOB<4>  |  /                            |
   *   |      15  | 1111       | pad_gpio_3<4> =GPIO<21 =GPIOB<5>  | /                             |
   *   ---------------------------------------------------------------------------------------------
   */
#endif
			__IO uint32_t gpio_sel        : 4; /**< @brief Bit[24..27]: Positive input GPIO pin selection
			                                                            for ADC_CHANNEL_EXTERN_PINx channel for BR3215e */
			__IO uint32_t gpio_sel_inn    : 4; /**< @brief Bit[28..31]: Negative input GPIO pin selection
			                                                            for ADC_CHANNEL_EXTERN_PINx channel for BR3215e */
		};
	};
} adc_channel_param_t;

/**
 * @brief   Conversion group configuration structure.
 * @details This implementation-dependent structure describes a conversion
 *          operation.
 * @note    The use of this configuration structure requires knowledge of
 *          BR3215C ADC cell registers interface, please refer to the BR3215C
 *          reference manual for details.
 */
typedef struct ADCConversionGroup {
  /**
   * @brief   Enables the circular buffer mode for the group.
   */
  bool                      circular;
  /**
   * @brief   Number of the analog channels belonging to the conversion group.
   */
  adc_channels_num_t        num_channels;
  /**
   * @brief   Callback function associated to the group or @p NULL.
   */
  adccallback_t             end_cb;
  /**
   * @brief   Error callback or @p NULL.
   */
  adcerrorcallback_t        error_cb;
  /* End of the mandatory fields.*/

  adc_trigger_t             trigger; //
  /**
   * @brief   Bitmap of chnannels in the group.
   *          bit=1: channel enabled;
   *          bit=0: channel disabled.
   */
  uint16_t                  channel_mask;
  /**
   * @brief   For internal use, better for code simplifying and efficiency.
   */
  uint8_t                   channel[ADC_CHANNEL_NUM];
  /**
   * @brief   Array of channel configurations.
   *          Can be set to 'NULL', otherwise self-default
   */
  adc_channel_param_t       channel_param[ADC_CHANNEL_NUM];
  /**
   * @brief   Enable calibration of data.
   */
  bool                      cal_en;
} ADCConversionGroup;

/**
 * @brief   Driver configuration structure.
 */
typedef struct ADCConfig {
  /**
   * @brief Pointer to ADC timing configuration.
   */
  const adc_timing_t      *timing;      /**< @brief ADC register TIMING_CFG0 and TIMING_CFG1 */
} ADCConfig;

/**
 * @brief   Structure representing an ADC driver.
 */
struct ADCDriver {
  /**
   * @brief Driver state.
   */
  adcstate_t                state;
  /**
   * @brief Current configuration data.
   */
  const ADCConfig           *config;
  /**
   * @brief Current samples buffer pointer or @p NULL.
   */
  adcsample_t               *samples;
  /**
   * @brief Current samples buffer depth or @p 0.
   */
  size_t                    depth;
  /**
   * @brief Current conversion group pointer or @p NULL.
   */
  const ADCConversionGroup  *grpp;
#if ADC_USE_WAIT || defined(__DOXYGEN__)
  /**
   * @brief Waiting thread.
   */
  thread_reference_t        thread;
#endif
#if ADC_USE_MUTUAL_EXCLUSION || defined(__DOXYGEN__)
  /**
   * @brief Mutex protecting the peripheral.
   */
  mutex_t                   mutex;
#endif /* ADC_USE_MUTUAL_EXCLUSION */
#if defined(ADC_DRIVER_EXT_FIELDS)
  ADC_DRIVER_EXT_FIELDS
#endif
  /* End of the mandatory fields.*/
  /**
   * @brief Pointer to the ADCx registers block.
   */
  HS_ADC_Type               *adc;
  /**
	 * @brief Pointer to an array of ADC data compensation parameters.
	 *        4 elements, corresponding to PGA gain of [0.5, 1, 2, 4].
	 */
//	adc_cal_param_t           *cal_param;
	/**
	 * @brief Pointer to calibration parameters table in Flash which is
	 *        measured and fill up during CP test.
	 */
	adc_cal_table_t           *cal_table;
	/**
	 * @brief Pointer to an internal table of default calibration parameter values
	 *        for ADC calibration use.
	 */
	adc_cal_table_t           *cal_table_default;
	/**
	 * @brief Number of rows of samples completed.
	 */
	uint32_t                  current_samples;
#if (HS_HAS_DMA == TRUE) && (ADC_USE_DMA == TRUE)
  /**
   * @brief Pointer to associated DMA channel.
   */
  hs_dma_stream_t           *pdma;
   /**
   * @brief Pointer to associated DMA thread.
   */
  thread_reference_t        dmathrd;
#endif // ADC_USE_DMA
#if defined(BR3215)
  /**
   * @brief Counting of data discarded for the first round of group conversion
   *        on BR3215, due to the fact that the first single data is inaccurate.
   *
   * @note  Since the first round of group conversion data must be discarded,
   *        only ADC_TRIGGER_TARGET_GROUP_CONTINUOUS trigger target can be
   *        used on BR3215 (has been coded to it internally).
   */
	uint8_t                   discard;
#endif
};

/*===========================================================================*/
/* Driver macros.                                                            */
/*===========================================================================*/

/*===========================================================================*/
/* External declarations.                                                    */
/*===========================================================================*/

#if HS_ADC_USE_ADC0 && !defined(__DOXYGEN__)
extern ADCDriver ADCD0;
#endif

#ifdef __cplusplus
extern "C" {
#endif
  void adc_lld_init(void);
  void adc_lld_start(ADCDriver *adcp);
  void adc_lld_stop(ADCDriver *adcp);
  int adc_lld_start_conversion(ADCDriver *adcp);
  void adc_lld_stop_conversion(ADCDriver *adcp);
  void adc_lld_soft_trigger(ADCDriver *adcp);
#if (HS_HAS_DMA == TRUE) && (ADC_USE_DMA == TRUE)
  int adc_lld_start_conversionWithDMA(ADCDriver *adcp, uint8_t *pDmaBuf, uint32_t DmaLen);
  int adc_lld_dmaWaitForDone(ADCDriver *adcp, systime_t timeout);
#endif // ADC_USE_DMA
  void adc_lld_get_cal_param_from_table(adc_cal_param_t *param,
		                                  adc_cal_table_t *table,
		                                  bool is_differential,
		                                  adc_pga_gain_t gain);
  void adc_lld_build_conversion_group(ADCConversionGroup *grpp,
                                    bool circular,
                                    bool cal_en,
                                    adc_trigger_source_t trigger_source,
                                    adc_trigger_edge_t trigger_edge,
                                    adc_trigger_target_t trigger_target,
                                    adccallback_t end_cb,
                                    adcerrorcallback_t error_cb);
  void adc_lld_clear_conversion_group(ADCConversionGroup *grpp);
  uint32_t adc_gpio_sel_to_gpio_pin(uint8_t gpio_sel);
  uint32_t adc_gpio_pin_to_gpio_sel(uint8_t gpio_pin);
  int adc_lld_add_channel(ADCConversionGroup *grpp,
		                      adc_channel_t inp,
												  adc_channel_t inn,
		                      adc_vcm_t vcm,
												  adc_pga_gain_t gain,
												  uint32_t gpio_pin_inp,
												  uint32_t gpio_pin_inn);
  int adc_lld_delete_channel(ADCConversionGroup *grpp, adc_channel_t chn);
  int adc_lld_add_channel_temperature(ADCConversionGroup *grpp);
  int adc_lld_add_channel_battery(ADCConversionGroup *grpp);
  void adc_lld_set_test_data(ADCDriver *adcp, uint32_t val);
#ifdef __cplusplus
}
#endif

/**
 * Help functions.
 */
int32_t float_to_fixed(float x, int n);
float fixed_to_float(int32_t x, int m, int n);
float adc_data_q2f(adcsample_t x);
int32_t adc_data_qmul(int32_t a, int32_t b);
int32_t adc_data_qdiv(int32_t a, int32_t b);
#endif /* HAL_USE_ADC */

#endif /* _ADC_LLD_H_ */

/** @} */
