/*
    ChibiOS - Copyright (C) 2006..2015 Giovanni Di Sirio

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    HS/st_lld.c
 * @brief   ST Driver subsystem low level driver code.
 *
 * @addtogroup ST
 * @{
 */

#include "hal.h"

#if (OSAL_ST_MODE != OSAL_ST_MODE_NONE) || defined(__DOXYGEN__)

/*===========================================================================*/
/* Driver local definitions.                                                 */
/*===========================================================================*/

#if OSAL_ST_MODE == OSAL_ST_MODE_FREERUNNING && !HS_HAS_RTC_YGW

#if (OSAL_ST_RESOLUTION == 32)
#define ST_ARR_INIT                         0xFFFFFFFF
#else
#define ST_ARR_INIT                         0x0000FFFF
#endif

#if HS_ST_USE_TIM == 2
#if (OSAL_ST_RESOLUTION == 32) && !HS_TIM2_IS_32BITS
#error "TIM2 is not a 32bits timer"
#endif

#define ST_HANDLER                          TIM2_IRQHandler
#define ST_NUMBER                           TIM2_IRQn
#define ST_CLOCK_SRC                        cpm_get_clock(HS_TIM2_CLK)
#define ST_ENABLE_CLOCK()                   cpmEnableTIM2()
#define ST_ENABLE_STOP()

#elif HS_ST_USE_TIM == 1
#if (OSAL_ST_RESOLUTION == 32) && !HS_TIM1_IS_32BITS
#error "TIM1 is not a 32bits timer"
#endif

#define ST_HANDLER                          TIM1_IRQHandler
#define ST_NUMBER                           TIM1_IRQn
#define ST_CLOCK_SRC                        cpm_get_clock(HS_TIM1_CLK)
#define ST_ENABLE_CLOCK()                   cpmEnableTIM1()
#define ST_ENABLE_STOP()

#elif HS_ST_USE_TIM == 0
#if (OSAL_ST_RESOLUTION == 32) && !HS_TIM0_IS_32BITS
#error "TIM0 is not a 32bits timer"
#endif

#define ST_HANDLER                          TIM0_IRQHandler
#define ST_NUMBER                           TIM0_IRQn
#define ST_CLOCK_SRC                        cpm_get_clock(HS_TIM0_CLK)
#define ST_ENABLE_CLOCK()                   cpmEnableTIM0()
#define ST_ENABLE_STOP()

#else
#error "HS_ST_USE_TIM specifies an unsupported timer"
#endif

#endif /* OSAL_ST_MODE == OSAL_ST_MODE_FREERUNNING */

#if OSAL_ST_MODE == OSAL_ST_MODE_PERIODIC

#if HS_SYSTICK_CLOCK % OSAL_ST_FREQUENCY != 0
#error "the selected ST frequency is not obtainable because integer rounding"
#endif

#if (HS_SYSTICK_CLOCK / OSAL_ST_FREQUENCY) - 1 > 0xFFFFFF
#error "the selected ST frequency is not obtainable because SysTick timer counter limits"
#endif

#endif /* OSAL_ST_MODE == OSAL_ST_MODE_PERIODIC */

/*===========================================================================*/
/* Driver exported variables.                                                */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local types.                                                       */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local variables and types.                                         */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local functions.                                                   */
/*===========================================================================*/

/*===========================================================================*/
/* Driver interrupt handlers.                                                */
/*===========================================================================*/

#if (OSAL_ST_MODE == OSAL_ST_MODE_PERIODIC) || defined(__DOXYGEN__)
/**
 * @brief   System Timer vector.
 * @details This interrupt is used for system tick in periodic mode.
 *
 * @isr
 */
OSAL_IRQ_HANDLER(SysTick_IRQHandler) {

  OSAL_IRQ_PROLOGUE();

  osalSysLockFromISR();
  HS_SYS->SYS_TICK &= ~(1u << 24);
  HS_SYS->SYS_TICK |= 1u << 24;
  osalOsTimerHandlerI();
  osalSysUnlockFromISR();

  OSAL_IRQ_EPILOGUE();
}
#endif /* OSAL_ST_MODE == OSAL_ST_MODE_PERIODIC */

#if (OSAL_ST_MODE == OSAL_ST_MODE_FREERUNNING) || defined(__DOXYGEN__)
/**
 * @brief   Systick interrupt handler based on sleep timer or TIM.
 * @details This interrupt is used for system tick in free running mode.
 *
 * @isr
 */
#if HS_HAS_RTC_YGW
OSAL_IRQ_HANDLER(RTC_IRQHandler) {

  OSAL_IRQ_PROLOGUE();

  if ((HS_SYSTICK->INTSTAT & (1u << 1)/*alarm*/) != 0U) {
    HS_SYSTICK->INTRAWSTAT = (1u << 1); //w1c

    osalSysLockFromISR();
    osalOsTimerHandlerI();
    osalSysUnlockFromISR();
  }

  OSAL_IRQ_EPILOGUE();
}
#else
OSAL_IRQ_HANDLER(ST_HANDLER) {

  OSAL_IRQ_PROLOGUE();

  /* Note, under rare circumstances an interrupt can remain latched even if
     the timer SR register has been cleared, in those cases the interrupt
     is simply ignored.*/
  if ((HS_ST_TIM->SR & TIM_SR_CC1IF) != 0U) {
    HS_ST_TIM->SR = 0U;

    osalSysLockFromISR();
    osalOsTimerHandlerI();
    osalSysUnlockFromISR();
  }

  OSAL_IRQ_EPILOGUE();
}
#endif
#endif /* OSAL_ST_MODE == OSAL_ST_MODE_FREERUNNING */

/*===========================================================================*/
/* Driver exported functions.                                                */
/*===========================================================================*/

/**
 * @brief   Low level ST driver initialization.
 *
 * @notapi
 */
void st_lld_init(void) {

#if OSAL_ST_MODE == OSAL_ST_MODE_FREERUNNING
  /* Free running counter mode.*/

  #if HS_HAS_RTC_YGW
  _systick_lld_clr_cr(RTC_CR_ALARM_WAKEUP_EN);
  _systick_lld_clr_cr(RTC_CR_TIMER_ON);
  _systick_lld_set_cr(RTC_CR_TIMER_ON);
  HS_SYSTICK->INTMASK = 0;
  nvicEnableVector(RTC_IRQn, HS_ST_IRQ_PRIORITY);
  #else
  /* Enabling timer clock.*/
  ST_ENABLE_CLOCK();

  /* Enabling the stop mode during debug for this timer.*/
  ST_ENABLE_STOP();

  /* Initializing the counter in free running mode.*/
  HS_ST_TIM->PSC    = (ST_CLOCK_SRC / OSAL_ST_FREQUENCY) - 1;
  HS_ST_TIM->ARR    = ST_ARR_INIT;
  HS_ST_TIM->CCMR1  = 0;
  HS_ST_TIM->CCR[0] = 0;
  HS_ST_TIM->DIER   = 0;
  HS_ST_TIM->CR2    = 0;
  HS_ST_TIM->EGR    = TIM_EGR_UG;
  HS_ST_TIM->CR1    = TIM_CR1_CEN;

  /* IRQ enabled.*/
  nvicEnableVector(ST_NUMBER, HS_ST_IRQ_PRIORITY);
  #endif
#endif /* OSAL_ST_MODE == OSAL_ST_MODE_FREERUNNING */

#if OSAL_ST_MODE == OSAL_ST_MODE_PERIODIC
  /* Periodic systick mode, the BRMICRO internal systick timer is used
     in this mode.*/
  HS_SYS->SYS_TICK  = HS_SYSTICK_CLOCK / OSAL_ST_FREQUENCY - 0;
  HS_SYS->SYS_TICK |= 1u << 24;

  /* IRQ enabled.*/
  nvicEnableVector(SYSTICK_IRQn, HS_ST_IRQ_PRIORITY);
#endif /* OSAL_ST_MODE == OSAL_ST_MODE_PERIODIC */
}

/**
 * @brief   Re-initialize systick for suspend managment.
 */
void st_lld_reinit(int hz) {

#if OSAL_ST_MODE == OSAL_ST_MODE_FREERUNNING
  (void)hz;
#endif

#if OSAL_ST_MODE == OSAL_ST_MODE_PERIODIC
  nvicDisableVector(SYSTICK_IRQn);
  HS_SYS->SYS_TICK &= ~(1u << 24);
  HS_SYS->SYS_TICK  = HS_SYSTICK_CLOCK / hz - 1;
  HS_SYS->SYS_TICK |= 1u << 24;
  nvicEnableVector(SYSTICK_IRQn, HS_ST_IRQ_PRIORITY);
#endif
}

/**
 * @brief   De-initialize systick.
 */
void st_lld_deinit(void) {

#if OSAL_ST_MODE == OSAL_ST_MODE_FREERUNNING
#endif

#if OSAL_ST_MODE == OSAL_ST_MODE_PERIODIC
  HS_SYS->SYS_TICK &= ~(1u << 24);
  nvicDisableVector(SYSTICK_IRQn);
#endif
}


#endif /* OSAL_ST_MODE != OSAL_ST_MODE_NONE */

/** @} */
