/*
    ChibiOS/RT - Copyright (C) 2006-2013 Giovanni Di Sirio
                 Copyright (C) 2019 BRMICRO Technologies
                 

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    br32xx/pal_lld.c
 * @brief   BR32xx PAL low level driver code.
 *
 * @addtogroup PAL
 * @{
 */

#include "hal.h"

#if HAL_USE_PAL || defined(__DOXYGEN__)

/*===========================================================================*/
/* Driver local definitions.                                                 */
/*===========================================================================*/
static hs_gpio_isr_t m_gpio_wakeup_isr = NULL;
static hs_gpio_isr_t m_gpio_isr_table[PAL_IOPORTS_WIDTH * 2];
static void *m_gpio_isr_args[PIN_NUM];

#if defined(BR3215e)
static hs_gpio_isr_t m_vcmp_isr_table[VCMP_NUM];
static void *m_vcmp_isr_args[VCMP_NUM];
#endif

/*===========================================================================*/
/* Driver exported variables.                                                */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local variables and types.                                         */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local functions.                                                   */
/*===========================================================================*/

static void initgpio(HS_GPIO_Type *gpiop) {
  /* nTRST cannot reset GPIO */
  gpiop->INTENCLR = 0xffff;

  #if defined(BR3215e)
  /* [6:4]dn_int_en [2:0]up_int_en */
  HS_PMU->PA0_WAKEUP_CNS    &= ~((0x7<<4) | (0x7<<0));
  HS_PMU->ADCKEY_WAKEUP_CNS &= ~((0x7<<4) | (0x7<<0));
  HS_PMU->VBUS_WAKEUP_CNS   &= ~((0x7<<4) | (0x7<<0));
  /* [7:4]dn_int_en [3:0]up_int_en */
  HS_PMU->VBAT_WAKEUP_CNS   &= ~((0xf<<4) | (0xf<<0));
  #endif
}

/*===========================================================================*/
/* Driver interrupt handlers.                                                */
/*===========================================================================*/
static void gpio_serve_interrupt(void)
{
  uint32_t i, src, src0, src1;
  ioportid_t gio0 = GPIOA;
  ioportid_t gio1 = GPIOB;

  src = src0 = gio0->INTSTATUS & 0xffff;
  for(i=0; i<PAL_IOPORTS_WIDTH; i++){
    if((src & 1) && (m_gpio_isr_table[i] != NULL)){
      m_gpio_isr_table[i](m_gpio_isr_args[i]);
    }

    src >>= 1;
  }
  gio0->INTSTATUS = src0;

  src = src1 = gio1->INTSTATUS & 0xffff;
  for(i=0; i<PAL_IOPORTS_WIDTH; i++){
    if((src & 1) && (m_gpio_isr_table[PAL_IOPORTS_WIDTH+i] != NULL)){
      m_gpio_isr_table[PAL_IOPORTS_WIDTH + i](m_gpio_isr_args[PAL_IOPORTS_WIDTH + i]);
    }

    src >>= 1;
  }
  gio1->INTSTATUS = src1;

  if (NULL != m_gpio_wakeup_isr) {
    m_gpio_wakeup_isr((void *)((src1 << 16) | (src0 << 0)));
    m_gpio_wakeup_isr = NULL;
  }
}

OSAL_IRQ_HANDLER(GPIO_IRQHandler) {

  OSAL_IRQ_PROLOGUE();

  osalSysLockFromISR();
  gpio_serve_interrupt();
  osalSysUnlockFromISR();

  OSAL_IRQ_EPILOGUE();
}

#if defined(BR3215e)
static void vcmp_serve_interrupt(void)
{
  //debug("WAKEUP_isr PA0=%08lx ADKEY=%08lx VBUS=%08lx VBAT=%08lx\n", HS_PMU->PA0_WAKEUP_CNS, HS_PMU->ADCKEY_WAKEUP_CNS, HS_PMU->VBUS_WAKEUP_CNS, HS_PMU->VBAT_WAKEUP_CNS);
  if (HS_PMU->PA0_WAKEUP_CNS & (0x77<<16)) {
    /* clear interrupts: w1c */
    HS_PMU->PA0_WAKEUP_CNS |= (0x77<<8);
    m_gpio_isr_table[0](m_gpio_isr_args[0]);
  }
  if (HS_PMU->VBUS_WAKEUP_CNS & (0x77<<16)) {
    /* clear interrupts: w1c */
    HS_PMU->VBUS_WAKEUP_CNS |= (0x77<<8);
    m_vcmp_isr_table[VCMP_VBUS](m_vcmp_isr_args[VCMP_VBUS]);
  }
  if (HS_PMU->VBAT_WAKEUP_CNS & (0x77<<16)) {
    /* clear interrupts: w1c */
    HS_PMU->VBAT_WAKEUP_CNS |= (0x77<<8);
    m_vcmp_isr_table[VCMP_VBAT](m_vcmp_isr_args[VCMP_VBAT]);
  }
}

OSAL_IRQ_HANDLER(VCMP_IRQHandler) {

  OSAL_IRQ_PROLOGUE();

  osalSysLockFromISR();
  vcmp_serve_interrupt();
  osalSysUnlockFromISR();

  OSAL_IRQ_EPILOGUE();
}
#endif

/*===========================================================================*/
/* Driver exported functions.                                                */
/*===========================================================================*/

/**
 * @brief   BR32xx I/O ports configuration.
 *
 * @param[in] config    the BR32xx ports configuration
 *
 * @notapi
 */
void _pal_lld_init(const PALConfig *config) {
  int i;
  (void)config;

  /*
   * Enables the PAL related clocks.
   */
  cpmEnableGPIO();

#if defined(BR3215) || defined(BR3215c) || defined(BR3215e)
  /* reset doesn't reset dig-ana interface, but gdb expects pinmux is reset */
  #if defined(BR3215) || defined(BR3215c)
  //HS_PMU->PADC_CON[0] = 0x03; /* PA0=JTAG.TRST, input, pullup */
  //HS_PMU->PADC_CON[1] = 0x05; /* PA1=SD.DAT0  , input, pulldn */
  if (0x03 != HS_PMU->PADC_CON[2])
  HS_PMU->PADC_CON[2] = 0x03; /* PA2=JTAG.TMS , input, pullup */
  HS_PMU->PADC_CON[3] = 0x03; /* PA3          , input, pullup */
  HS_PMU->PADC_CON[4] = 0x03; /* PA4          , input, pullup */
  HS_PMU->PADC_CON[5] = 0x03; /* PA5          , input, pullup */
  HS_PMU->PADC_CON[6] = 0x01; /* PA6          , input, pullno */
  HS_PMU->PADC_CON[7] = 0x01; /* PA7          , input, pullno */
  //HS_PMU->PADC_CON[8] = 0x01; /* PA8=SD.CMD   , input, pullno */
  HS_PMU->PADC_CON[9] = 0x01; /* PA9          , input, pullno */
  //HS_PMU->PADC_CON[10]= 0x01; /* PA10=SD.CLK  , input, pullno */
  HS_PMU->PADC_CON[11]= 0x01; /* PA11         , input, pullno */
  HS_PMU->PADC_CON[12]= 0x01; /* PA12         , input, pullno */
  HS_PMU->PADC_CON[13]= 0x01; /* PA13         , input, pullno */
  //HS_PMU->PADC_CON[14]= 0x01; /* PA14=USB.D+  , input, pullno */
  HS_PMU->PADC_CON[15]= 0x01; /* PA15         , input, pullno */
  //HS_PMU->PADC_CON[16]= 0x01; /* PB0=USB.D-   , input, pullno */
  //HS_PMU->PADC_CON[17]= 0x01; /* PB1=USB.CID  , input, pullno */
  HS_PMU->PADC_CON[18]= 0x01; /* PB2          , input, pullno */
  HS_PMU->PADC_CON[19]= 0x01; /* PB3          , input, pullno */
  HS_PMU->PADC_CON[20]= 0x01; /* PB4          , input, pullno */
  //HS_PMU->PADC_CON[21]= 0x01; /* PB5          , input, pullno */
  HS_PMU->PADC_CON[22]= 0x01; /* PB6          , input, pullno */
  if (0x01 != HS_PMU->PADC_CON[23])
  HS_PMU->PADC_CON[23]= 0x01; /* PB7=JTAG.TCK , input, pullno */
  #elif defined(BR3215e)
  //HS_PMU->PADC_CON[0] = 0x01; /* PA0=PowerPin , input, pullno */
  //HS_PMU->PADC_CON[1] = 0x01; /* PA1=TEST.TMS , input, pullno */
  //HS_PMU->PADC_CON[2] = 0x03; /* PA2=JTAG.TMS , input, pullup */
  //HS_PMU->PADC_CON[3] = 0x01; /* PA3=JTAG.TCK , input, pullno */
  HS_PMU->PADC_CON[4] = 0x03; /* PA4          , input, pullup */
  HS_PMU->PADC_CON[5] = 0x03; /* PA5          , input, pullup */
  HS_PMU->PADC_CON[6] = 0x01; /* PA6=SD.DAT0  , input, pullno */
  HS_PMU->PADC_CON[7] = 0x01; /* PA7=SD.CLK   , input, pullno */
  HS_PMU->PADC_CON[8] = 0x01; /* PA8=SD.CMD   , input, pullno */
  HS_PMU->PADC_CON[9] = 0x01; /* PA9          , input, pullno */
  HS_PMU->PADC_CON[10]= 0x01; /* PA10         , input, pullno */
  HS_PMU->PADC_CON[11]= 0x01; /* PA11         , input, pullno */
  HS_PMU->PADC_CON[12]= 0x01; /* PA12         , input, pullno */
  HS_PMU->PADC_CON[13]= 0x01; /* PA13         , input, pullno */
  HS_PMU->PADC_CON[14]= 0x01; /* PA14=USB.D+  , input, pullno */
  HS_PMU->PADC_CON[15]= 0x01; /* PA15=USB.D-  , input, pullno */
  HS_PMU->PADC_CON[16]= 0x01; /* PB0=USB.CID  , input, pullno */
  HS_PMU->PADC_CON[17]= 0x01; /* PB1          , input, pullno */
  HS_PMU->PADC_CON[18]= 0x01; /* PB2          , input, pullno */
  HS_PMU->PADC_CON[19]= 0x01; /* PB3          , input, pullno */
  HS_PMU->PADC_CON[20]= 0x01; /* PB4          , input, pullno */
  HS_PMU->PADC_CON[21]= 0x01; /* PB5          , input, pullno */
  HS_PMU->PADC_CON[22]= 0x01; /* PB6          , input, pullno */
  HS_PMU->PADC_CON[23]= 0x01; /* PB7          , input, pullno */
  HS_PMU->PADC_CON_24[0]= 0x01; /* PB8        , input, pullno */
  HS_PMU->PADC_CON_24[1]= 0x01; /* PB9        , input, pullno */
  #endif

  /* reset doesn't reset TIM, but gdb expects TIM is reset */
  cpmEnableTIM0();
  HS_TIM0->CR1 = 0;
  HS_TIM0->CR2 = 0;
  HS_TIM0->SMCR = 0;
  HS_TIM0->DIER = 0;
  HS_TIM0->SR = 0;
  HS_TIM0->EGR = 0;
  HS_TIM0->CCMR1 = HS_TIM0->CCMR2 = 0;
  HS_TIM0->CCER = 0;
  HS_TIM0->CNT = 0;
  HS_TIM0->PSC = 0;
  HS_TIM0->RCR = 0;
  HS_TIM0->CCR[0] = HS_TIM0->CCR[1] = HS_TIM0->CCR[2] = HS_TIM0->CCR[3] = 0;
  HS_TIM0->BDTR = 0;
  HS_TIM0->DCR = 0;
  HS_TIM0->DMAR = 0;
  cpmEnableTIM1();
  *HS_TIM1 = *HS_TIM0;
  cpmEnableTIM2();
  *HS_TIM2 = *HS_TIM0;
  cpmDisableTIM2();
  cpmDisableTIM1();
  cpmDisableTIM0();

#if 0 // by llei
#if !defined(BR32xx_FPGA) && (defined(BR3215c) || defined(BR3215e)) && !defined(hscAudiophile)

  /*
   * pseudo program pins at PA4 PA5:
   *   program mode: both low
   *   run     mode: others
   */
  HS_GPIO0->OUTENCLR = (1 << 4u) | (1 << 5u);
  while (0 == (HS_GPIO0->DATA & ((1 << 4u) | (1 << 5u)))) {
    __NOP();
  }
#endif
#endif

#endif

  /*
   * Initial PAL setup.
   */
  initgpio(HS_GPIO0);
  initgpio(HS_GPIO1);

  for(i=0; i<PAL_IOPORTS_WIDTH * 2; i++)
    m_gpio_isr_table[i] = NULL;
}

int _pal_lld_read_pin(uint8_t pin)
{
  ioportid_t port;
  port = pin < PAL_IOPORTS_WIDTH ? GPIOA : GPIOB;
  pin = pin >= PAL_IOPORTS_WIDTH ? (pin - PAL_IOPORTS_WIDTH) : pin;
  return !!(port->DATA & (1u << pin));
}

void _pal_lld_set_pin(uint8_t pin)
{
  ioportid_t port;
  port = pin < PAL_IOPORTS_WIDTH ? GPIOA : GPIOB;
  pin = pin >= PAL_IOPORTS_WIDTH ? (pin - PAL_IOPORTS_WIDTH) : pin;
  port->DATAOUT |= (1u << pin);
}

void _pal_lld_clear_pin(uint8_t pin)
{
  ioportid_t port;
  port = pin < PAL_IOPORTS_WIDTH ? GPIOA : GPIOB;
  pin = pin >= PAL_IOPORTS_WIDTH ? (pin - PAL_IOPORTS_WIDTH) : pin;
  port->DATAOUT &= ~(1u << pin);
}

void _pal_lld_toggle_pin(uint8_t pin)
{
  ioportid_t port;
  port = pin < PAL_IOPORTS_WIDTH ? GPIOA : GPIOB;
  pin = pin >= PAL_IOPORTS_WIDTH ? (pin - PAL_IOPORTS_WIDTH) : pin;
  port->DATAOUT ^= (1u << pin);
}

#if 1
void _pal_lld_set_pin_mode(uint8_t pin, iomode_t mode)
{
  ioportid_t port;
	uint32_t pad, afrm, pupdrm, moderm, drcaprm, reg_val;

  port = pin < PAL_IOPORTS_WIDTH ? GPIOA : GPIOB;
  pad = pin >= PAL_IOPORTS_WIDTH ? (pin - PAL_IOPORTS_WIDTH) : pin;

	/* mode select */
  moderm = mode & PAL_HS_MODE_MASK;
	/* Alternate function */
  afrm = mode & PAL_HS_ALTERNATE_MASK;

	/* drive capability function */
  drcaprm = (mode & PAL_HS_DRCAP_MASK);

	/* power up or down - 300k */
  pupdrm = (mode & PAL_HS_PUDR_MASK);

  reg_val = moderm | afrm | drcaprm | pupdrm;

#if defined(BR3215) || defined(BR3215c)
	HS_PMU->PADC_CON[pin] = reg_val;

	/* if use SD function set strong pull up */
	uint32_t sd_pl_num = 6;
	switch (pin) {
		case 6:
			sd_pl_num = 0;
			break;
		case 8:
			sd_pl_num = 1;
			break;
		case 10:
			sd_pl_num = 2;
			break;
		case 11:
			sd_pl_num = 3;
			break;
		case 12:
			sd_pl_num = 4;
			break;
		case 13:
			sd_pl_num = 5;
			break;
		default:
			sd_pl_num = 6;
	}

	if (((afrm >> 5) == PAD_FUNC_SD_USB) && (sd_pl_num<6))
		HS_PMU->GPIO_PL_UP_30K |= (1<<sd_pl_num);
	else if (sd_pl_num<6)
		HS_PMU->GPIO_PL_UP_30K &= ~(1<<sd_pl_num);

	/* disable PA1 as reset if !JTAG, or enable PA1 as reset if JTAG */
	if ((pin == 1) && ((afrm >> 5) != PAD_FUNC_JTAG))
		HS_PMU->RESET_EN = 0;
	else if ((pin == 1) && ((afrm >> 5) == PAD_FUNC_JTAG))
		HS_PMU->RESET_EN = 1;
#else
	#if defined(BR3215e)
	if ((24 <= pin) && (pin <= 25)) {
		HS_PMU->PADC_CON_24[pin-24] = reg_val;
	}
	else
	#endif
	{
		HS_PMU->PADC_CON[pin] = reg_val;
	}
#endif

	/* if use gpio function  0x7 is alternate gpio */
	if ((afrm >> 5) == PAD_FUNC_GPIO) {
		uint16_t mask1 = (uint16_t)1<<pad;
		iomode_t real_mode = moderm + pupdrm;

		switch (real_mode) {
			case PAL_MODE_INPUT:
			case PAL_MODE_INPUT_PULLUP:
			case PAL_MODE_INPUT_PULLDOWN:
				port->OUTENCLR = mask1;
				break;

			/* if output is selected, uses pull as initial output value */
			case PAL_MODE_OUTPUT_PULLUP:
				port->DATAOUT |= mask1;
				port->OUTENSET = mask1;
				break;
			case PAL_MODE_OUTPUT_PULLDOWN:
				port->DATAOUT &= ~mask1;
			case PAL_MODE_OUTPUT:
				port->OUTENSET = mask1;
				break;
		}
	}
}
#else
void _pal_lld_set_pin_mode(uint8_t pin, iomode_t mode)
{
  ioportid_t port;

  port = pin < PAL_IOPORTS_WIDTH ? GPIOA : GPIOB;
  pin = pin >= PAL_IOPORTS_WIDTH ? (pin - PAL_IOPORTS_WIDTH) : pin;

  _pal_lld_setgroupmode(port, 1 << pin, mode);
}
#endif

#if defined(BR3215e)
void vcmp_lld_enable_irq(vcmp_dev_t dev)
{
  switch (dev) {
  case VCMP_PA0:
    /* setup in _pal_lld_register_is() */
    break;
  case VCMP_ADKEY:
    HS_PMU->ADCKEY_WAKEUP_CNS |= (0x77<<0);
    break;
  case VCMP_VBUS:
    HS_PMU->VBUS_WAKEUP_CNS |= (0x77<<0);
    break;
  case VCMP_VBAT:
    HS_PMU->VBAT_WAKEUP_CNS |= (0x77<<0);
    break;
  default:
    break;
  }
}
void vcmp_lld_disable_irq(vcmp_dev_t dev)
{
  switch (dev) {
  case VCMP_PA0:
    /* setup in _pal_lld_unregister_is() */
    break;
  case VCMP_ADKEY:
    HS_PMU->ADCKEY_WAKEUP_CNS &= ~(0x77<<0);
    break;
  case VCMP_VBUS:
    HS_PMU->VBUS_WAKEUP_CNS &= ~(0x77<<0);
    break;
  case VCMP_VBAT:
    HS_PMU->VBAT_WAKEUP_CNS &= ~(0x77<<0);
    break;
  default:
    break;
  }
}
void vcmp_lld_register_isr(vcmp_dev_t dev, hs_gpio_isr_t cb, void *arg)
{
  m_vcmp_isr_table[dev] = cb;
  m_vcmp_isr_args[dev]  = arg;
}
#endif

void _pal_lld_register_isr(uint8_t pin, hs_gpio_itype_t itype, hs_gpio_isr_t cb, void *arg)
{
  ioportid_t port;

  if (pin > PIN_NUM) {
    return;
  }

  if (NULL != cb) {
    m_gpio_isr_table[pin] = cb;
    m_gpio_isr_args[pin] = arg;
    nvicEnableVector(GPIO_IRQn, HS_GPIO_IRQ_PRIORITY);
  }

  port = pin < PAL_IOPORTS_WIDTH ? GPIOA : GPIOB;
  pin = pin >= PAL_IOPORTS_WIDTH ? (pin - PAL_IOPORTS_WIDTH) : pin;

  port->INTENCLR = 1u << pin ;
  port->INTTYPECLR = ((1u <<(pin+16)) | (1u << pin)); /* first clear both-edge */
  port->INTPOLCLR = 1u << pin;

  switch (itype) {
  case FALLING_EDGE:
    port->INTTYPESET |= 1u << pin;
    break;
  case RISING_EDGE:
    port->INTTYPESET |= 1u << pin;
    port->INTPOLSET |= 1u << pin;
    break;
  case BOTH_EDGE:
    port->INTTYPESET |= ((1u << pin)|(1u << (pin+16)));
    break;
  case LOW_LEVEL:
    break;
  case HIGH_LEVEL:
    port->INTPOLSET |= 1u << pin;
    break;
  default:
    return;
  }

  port->INTENSET |= 1u << pin ;

  #if defined(BR3215e)
  if (0 == pin) {
    nvicEnableVector(VCMP_IRQn, HS_GPIO_IRQ_PRIORITY);
    if ((FALLING_EDGE == itype) || (LOW_LEVEL == itype)) {
      /* key pressed: [2:0]up_int_en */
      HS_PMU->PA0_WAKEUP_CNS |= (0x7<<0);
    }
    else {
      HS_PMU->PA0_WAKEUP_CNS |= (0x7<<4);
    }
  }
  #endif
}

void _pal_lld_unregister_isr(uint8_t pin)
{
  ioportid_t port;

  if (pin > PIN_NUM) {
    return;
  }

  m_gpio_isr_table[pin] = NULL;
  m_gpio_isr_args[pin] = 0;

  port = pin < PAL_IOPORTS_WIDTH ? GPIOA : GPIOB;
  pin = pin >= PAL_IOPORTS_WIDTH ? (pin - PAL_IOPORTS_WIDTH) : pin;

  port->INTENCLR = 1u << pin ;

  #if defined(BR3215e)
  if (0 == pin) {
    /* [6:4]dn_int_en [2:0]up_int_en */
    HS_PMU->PA0_WAKEUP_CNS &= ~((0x7<<4) | (0x7<<0));
  }
  #endif
}

void _pal_lld_register_wakeup(uint32_t pin_bitmap, hs_gpio_itype_t itype, hs_gpio_isr_t cb)
{
  uint16_t bitmap_port0 = (pin_bitmap >>  0) & 0xffff;
  uint16_t bitmap_port1 = (pin_bitmap >> 16) & 0xffff;

  /* TBD: setup all pads except for wakeup pin, input, pullno, to save power */

  #if defined(BR3215c)
  /* BR3215c supports wakeup in PMU domain, even if GPIO module is off */
  HS_PMU->GPIO_MASK &= ~(pin_bitmap);
  HS_PMU->GPIO_MASK |= (pin_bitmap);   /* 0-disable wakeup; 1-enable wakeup. */
  HS_PMU->GPIO_POLAR &= ~(pin_bitmap);
  if ((RISING_EDGE == itype) || (HIGH_LEVEL == itype)) {
    HS_PMU->GPIO_POLAR &= ~(pin_bitmap); /* 0-high wakeup; 1-low wakeup. */
  }
  else {
    HS_PMU->GPIO_POLAR |= (pin_bitmap); /* 0-high wakeup; 1-low wakeup. */
  }
  HS_PMU->BASIC |= (1UL<<30);           /* update */
  #endif

  /* disable interrupt on all pins in default */
  HS_GPIO0->INTENCLR = 0xffff;
  HS_GPIO1->INTENCLR = 0xffff;

  /* setup interrupt type */
  HS_GPIO0->INTTYPECLR = 0xffff;
  HS_GPIO1->INTTYPECLR = 0xffff;
  HS_GPIO0->INTPOLCLR = 0xffff;
  HS_GPIO1->INTPOLCLR = 0xffff;
  switch (itype) {
  case FALLING_EDGE:
    /* b'10 */
    HS_GPIO0->INTTYPESET = bitmap_port0;
    HS_GPIO1->INTTYPESET = bitmap_port1;
    break;
  case RISING_EDGE:
    /* b'11 */
    HS_GPIO0->INTTYPESET = bitmap_port0;
    HS_GPIO0->INTPOLSET  = bitmap_port0;
    HS_GPIO1->INTTYPESET = bitmap_port1;
    HS_GPIO1->INTPOLSET  = bitmap_port1;
    break;
  case BOTH_EDGE:
    HS_GPIO0->INTTYPESET = (bitmap_port0 << 16) | bitmap_port0;
    HS_GPIO1->INTTYPESET = (bitmap_port1 << 16) | bitmap_port1;
    break;
  case LOW_LEVEL:
    /* b'00 */
    break;
  case HIGH_LEVEL:
    /* b'01 */
    HS_GPIO0->INTPOLSET  = bitmap_port0;
    HS_GPIO1->INTPOLSET  = bitmap_port1;
    break;
  default:
    return;
  }

  m_gpio_wakeup_isr = cb;

  /* enable interrupt on wakeup pins */
  HS_GPIO0->INTENSET = bitmap_port0;
  HS_GPIO1->INTENSET = bitmap_port1;

  nvicEnableVector(GPIO_IRQn, HS_GPIO_IRQ_PRIORITY);
}

/**
 * @brief   Pads mode setup.
 * @details This function programs a pads group belonging to the same port
 *          with the specified mode.
 * @note    @p PAL_MODE_UNCONNECTED is implemented as push pull at minimum
 *          speed.
 *
 * @param[in] port      the port identifier
 * @param[in] pad       pad number within the port
 * @param[in] mode      the mode
 *
 * @notapi
 */
#if 1
void _pal_lld_setgroupmode(ioportid_t port,
                           ioportmask_t mask,
                           iomode_t mode)
{
  int pad;
  int start = (port == GPIOA) ? 0 : PAL_IOPORTS_WIDTH;

  for (pad = 0; mask && pad < PAL_IOPORTS_WIDTH; pad++) {
  	int pin = pad + start;
  	if (mask & (1u<<pin)) {
  		_pal_lld_set_pin_mode(pin, mode);
  		mask &= ~(1u<<pad);
  	}
  }
}
#else
void _pal_lld_setgroupmode(ioportid_t port,
                           ioportmask_t mask,
                           iomode_t mode)
{
  uint32_t afrm, pupdrm, moderm, drcaprm, reg_num, reg_val;
  uint16_t pad = 0 ;

	/* mode select */
  moderm = mode & PAL_HS_MODE_MASK;
	/* Alternate function */
  afrm = mode & PAL_HS_ALTERNATE_MASK;

	/* drive capability function */
  drcaprm = (mode & PAL_HS_DRCAP_MASK);

	/* power up or down - 300k */
  pupdrm = (mode & PAL_HS_PUDR_MASK);

  reg_val = moderm | afrm | drcaprm | pupdrm;
#if defined(BR3215e)
  /* it is bi-direction if set */
  reg_val |= PAL_HS_MODE_INPUT;
#endif

  do {
    if((mask&0x1) != 0) {
      reg_num = (port == GPIOA) ? pad : (pad+16);

#if defined(BR3215) || defined(BR3215c)
      HS_PMU->PADC_CON[reg_num] = reg_val;

      /* if use SD function set strong pull up */
      uint32_t sd_pl_num = 6;
      switch (reg_num) {
        case 6:
          sd_pl_num = 0;
          break;
        case 8:
          sd_pl_num = 1;
          break;
        case 10:
          sd_pl_num = 2;
          break;
        case 11:
          sd_pl_num = 3;
          break;
        case 12:
          sd_pl_num = 4;
          break;
        case 13:
          sd_pl_num = 5;
          break;
        default:
          sd_pl_num = 6;
      }

      if (((afrm >> 5) == PAD_FUNC_SD_USB) && (sd_pl_num<6))
        HS_PMU->GPIO_PL_UP_30K |= (1<<sd_pl_num);
      else if (sd_pl_num<6)
        HS_PMU->GPIO_PL_UP_30K &= ~(1<<sd_pl_num);

      /* disable PA1 as reset if !JTAG, or enable PA1 as reset if JTAG */
      if ((reg_num == 1) && ((afrm >> 5) != PAD_FUNC_JTAG))
        HS_PMU->RESET_EN = 0;
      else if ((reg_num == 1) && ((afrm >> 5) == PAD_FUNC_JTAG))
        HS_PMU->RESET_EN = 1;
#else
      #if defined(BR3215e)
      if ((24 <= reg_num) && (reg_num <= 25)) {
        HS_PMU->PADC_CON_24[reg_num-24] = reg_val;
      }
      else
      #endif
      {
        HS_PMU->PADC_CON[reg_num] = reg_val;
      }
#endif

	    /* if use gpio function  0x7 is alternate gpio */
      if ((afrm >> 5) == PAD_FUNC_GPIO) {
        uint16_t mask1 = (uint16_t)1<<pad;
        iomode_t real_mode = moderm + pupdrm;

        switch (real_mode) {
          case PAL_MODE_INPUT:
          case PAL_MODE_INPUT_PULLUP:
          case PAL_MODE_INPUT_PULLDOWN:
            port->OUTENCLR = mask1;
            break;

          /* if output is selected, uses pull as initial output value */
          case PAL_MODE_OUTPUT_PULLUP:
            port->DATAOUT |= mask1;
            port->OUTENSET = mask1;
            break;
          case PAL_MODE_OUTPUT_PULLDOWN:
            port->DATAOUT &= ~mask1;
          case PAL_MODE_OUTPUT:
            port->OUTENSET = mask1;
            break;
        }
      }
    }

    pad += 1;
    mask >>= 1;
  } while (mask && (pad < 16));
}
#endif

#endif /* HAL_USE_PAL */

/** @} */
