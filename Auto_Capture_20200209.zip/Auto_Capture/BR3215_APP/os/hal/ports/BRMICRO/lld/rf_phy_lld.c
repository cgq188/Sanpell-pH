/*
 * max2829_lld.c
 *
 *  Created on: Apr 28, 2017
 *      Author: china
 */

#include "hal.h"

/*===========================================================================*/
/* Driver for MAX2829.                                                       */
/*===========================================================================*/

#if HAL_USE_RF || defined(__DOXYGEN__)

#define MAX2829_IF0_ENABLE 1
#define MAX2829_FPGA_AGC_ENABLE 0

//(channel index+2402)*4/3/20

#define FREQ_INT_IF0 \
0x20A0, 0x30A0, 0xA0  , 0x10A0, 0x20A0, 0x30A0, 0x10A0, 0x20A0, 0x30A0, 0x40A0, \
0x10A0, 0x20A0, 0x30A0, 0xA1  , 0x10A1, 0x20A1, 0x30A1, 0xA1  , 0x10A1, 0x20A1, \
0x30A1, 0x10A1, 0x20A1, 0x30A1, 0x40A1, 0x10A1, 0x20A1, 0x30A1, 0xA2  , 0x10A2, \
0x20A2, 0x30A2, 0xA2  , 0x10A2, 0x20A2, 0x30A2, 0x10A2, 0x20A2, 0x30A2, 0x40A2, \
0x10A2, 0x20A2, 0x30A2, 0xA3  , 0x10A3, 0x20A3, 0x30A3, 0xA3  , 0x10A3, 0x20A3, \
0x30A3, 0x10A3, 0x20A3, 0x30A3, 0x40A3, 0x10A3, 0x20A3, 0x30A3, 0xA4  , 0x10A4, \
0x20A4, 0x30A4, 0xA4  , 0x10A4, 0x20A4, 0x30A4, 0x10A4, 0x20A4, 0x30A4, 0x40A4, \
0x10A4, 0x20A4, 0x30A4, 0xA5  , 0x10A5, 0x20A5, 0x30A5, 0xA5  , 0x10A5,

#define FREQ_INT_IF750k \
0x10A0, 0x20A0, 0x30A0, 0x10A0, 0x20A0, 0x30A0, 0x40A0, 0x10A0, 0x20A0, 0x30A0, \
0xA0  , 0x10A0, 0x20A0, 0x30A0, 0xA1  , 0x10A1, 0x20A1, 0x30A1, 0x10A1, 0x20A1, \
0x30A1, 0x40A1, 0x10A1, 0x20A1, 0x30A1, 0xA1  , 0x10A1, 0x20A1, 0x30A1, 0xA2  , \
0x10A2, 0x20A2, 0x30A2, 0x10A2, 0x20A2, 0x30A2, 0x40A2, 0x10A2, 0x20A2, 0x30A2, \
0xA2  , 0x10A2, 0x20A2, 0x30A2, 0xA3  , 0x10A3, 0x20A3, 0x30A3, 0x10A3, 0x20A3, \
0x30A3, 0x40A3, 0x10A3, 0x20A3, 0x30A3, 0xA3  , 0x10A3, 0x20A3, 0x30A3, 0xA4  , \
0x10A4, 0x20A4, 0x30A4, 0x10A4, 0x20A4, 0x30A4, 0x40A4, 0x10A4, 0x20A4, 0x30A4, \
0xA4  , 0x10A4, 0x20A4, 0x30A4, 0xA5  , 0x10A5, 0x20A5, 0x30A5, 0x10A5,

#define FREQ_FRA_IF0 \
0x888 , 0xCCC , 0x1111, 0x1555, 0x1999, 0x1DDD, 0x2222, 0x2666, 0x2AAA, 0x2EEE, \
0x3333, 0x3777, 0x3BBB, 0x0   , 0x444 , 0x888 , 0xCCC , 0x1111, 0x1555, 0x1999, \
0x1DDD, 0x2222, 0x2666, 0x2AAA, 0x2EEE, 0x3333, 0x3777, 0x3BBB, 0x0   , 0x444 , \
0x888 , 0xCCC , 0x1111, 0x1555, 0x1999, 0x1DDD, 0x2222, 0x2666, 0x2AAA, 0x2EEE, \
0x3333, 0x3777, 0x3BBB, 0x0   , 0x444 , 0x888 , 0xCCC , 0x1111, 0x1555, 0x1999, \
0x1DDD, 0x2222, 0x2666, 0x2AAA, 0x2EEE, 0x3333, 0x3777, 0x3BBB, 0x0   , 0x444 , \
0x888 , 0xCCC , 0x1111, 0x1555, 0x1999, 0x1DDD, 0x2222, 0x2666, 0x2AAA, 0x2EEE, \
0x3333, 0x3777, 0x3BBB, 0x0   , 0x444 , 0x888 , 0xCCC , 0x1111, 0x1555,

#define FREQ_FRA_IF750k \
0x555 , 0x999 , 0xDDD , 0x1222, 0x1666, 0x1AAA, 0x1EEE, 0x2333, 0x2777, 0x2BBB, \
0x3000, 0x3444, 0x3888, 0x3CCC, 0x111 , 0x555 , 0x999 , 0xDDD , 0x1222, 0x1666, \
0x1AAA, 0x1EEE, 0x2333, 0x2777, 0x2BBB, 0x3000, 0x3444, 0x3888, 0x3CCC, 0x111 , \
0x555 , 0x999 , 0xDDD , 0x1222, 0x1666, 0x1AAA, 0x1EEE, 0x2333, 0x2777, 0x2BBB, \
0x3000, 0x3444, 0x3888, 0x3CCC, 0x111 , 0x555 , 0x999 , 0xDDD , 0x1222, 0x1666, \
0x1AAA, 0x1EEE, 0x2333, 0x2777, 0x2BBB, 0x3000, 0x3444, 0x3888, 0x3CCC, 0x111 , \
0x555 , 0x999 , 0xDDD , 0x1222, 0x1666, 0x1AAA, 0x1EEE, 0x2333, 0x2777, 0x2BBB, \
0x3000, 0x3444, 0x3888, 0x3CCC, 0x111 , 0x555 , 0x999 , 0xDDD , 0x1222,

const uint16_t Freq_Int_Reg_Rx[]={               /*-750K frequency offset */
         FREQ_INT_IF750k
};
const uint16_t Freq_Fra_Reg_Rx[]={               /*-750K frequency offset */
         FREQ_FRA_IF750k
};

#if MAX2829_IF0_ENABLE     /*0-IF enable*/
const uint16_t Freq_Int_Reg_Tx[]= {              /*offset 0*/
         FREQ_INT_IF0
};
const uint16_t Freq_Fra_Reg_Tx[]={               /*offset 0*/
         FREQ_FRA_IF0
};
#else  /* MAX2829_IF0_ENABLE */
const uint16_t Freq_Int_Reg_Tx[]={               /*-750K frequency offset */
         FREQ_INT_IF750k
};
const uint16_t Freq_Fra_Reg_Tx[]={               /*-750K frequency offset */
         FREQ_FRA_IF750k
};
#endif /* MAX2829_IF0_ENABLE */
/*******************************************************************************
 * The following is a define the location of GIO lines in the MAX2829
 *
 * GIO 0   used to control TXENA of MAX2829.
 * GIO 1   used to control RXENA of MAX2829.
 * GIO 2   used to control #SHDN of MAX2829.
 *
 * GIO 6   used to control TXENA in page/inquiry mode
 * GIO 7   used to control RXENA in page/inquiry mode
 *
 *******************************************************************************/
#define GIO_HIGH_TXENA                         0x40018030
#define GIO_LOW_TXENA                          0x40018048
#define GIO_OVERRIDE_MASK_TXENA                0x00008000


#define GIO_HIGH_RXENA                         0x40018030
#define GIO_LOW_RXENA                          0x40018048
#define GIO_OVERRIDE_MASK_RXENA                0x80000000

#define GIO_HIGH_SHDN                          0x40018034
#define GIO_LOW_SHDN                           0x4001804C
#define GIO_OVERRIDE_MASK_SHDN                 0x00008000

#define FREQ_2497_INT   0x30a6
#define FREQ_2497_FRA   0x1ddd

#define FREQ_2497_25_INT   0x30a6
#define FREQ_2497_25_FRA   0x1eee

#define FREQ_2498_INT   0x00a6
#define FREQ_2498_FRA   0x2222

#define WRITE_REG(n,val)       ( 0x80000000 | ((val)<<4)|(n) )
#define WRITE_REG0             WRITE_REG(0x00, 0x1140)   /*Register 0*/
#define WRITE_REG1             WRITE_REG(0x01, 0x00CA)   /*Register 1*/
#define WRITE_REG2             WRITE_REG(0x02, 0x1007)   /*standby */
#define WRITE_REG3             WRITE_REG(0x03, FREQ_2497_25_INT) /*Intger-Divider Ratio*/
#define WRITE_REG4             WRITE_REG(0x04, FREQ_2497_25_FRA) /*Fractional-Divider Ratio*/
#define WRITE_REG3_TX(index)   WRITE_REG(0x03, Freq_Int_Reg_Tx[index])   /*Intger-Divider Ratio*/
#define WRITE_REG4_TX(index)   WRITE_REG(0x04, Freq_Fra_Reg_Tx[index])   /*Fractional-Divider Ratio*/
#define WRITE_REG3_RX(index)   WRITE_REG(0x03, Freq_Int_Reg_Rx[index])   /*Intger-Divider Ratio*/
#define WRITE_REG4_RX(index)   WRITE_REG(0x04, Freq_Fra_Reg_Rx[index])   /*Fractional-Divider Ratio*/
#define WRITE_REG5             WRITE_REG(0x05, 0x1824)   /*Band select and PLL*/
#define WRITE_REG6             WRITE_REG(0x06, 0x1C00)   /*calibration*/
#define WRITE_REG7             WRITE_REG(0x07, 0x002A)   /*lowpass filter*/
#define WRITE_REG8             WRITE_REG(0x08, 0x1C25)   /*Rx control/RSSI*/
#define WRITE_REG9             WRITE_REG(0x09, 0x0603)   /*Tx linearity/baseband gain*/
#define WRITE_REGA             WRITE_REG(0x0A, 0x03C0)   /*PA bias DAC*/
#define WRITE_REGB             WRITE_REG(0x0B, 0x0015)   /*Rx Gain*/
#define WRITE_REGC             WRITE_REG(0x0C, 0x003F)   /*Tx VGA Gain*/

#define HWradio_SetOverrideLow(GIO_NAME)  do { \
    *((volatile unsigned int*)GIO_LOW_##GIO_NAME) |= GIO_OVERRIDE_MASK_##GIO_NAME; \
    *((volatile unsigned int*)GIO_HIGH_##GIO_NAME) &= ~(GIO_OVERRIDE_MASK_##GIO_NAME); \
    }while(0)

#define HWradio_SetOverrideHigh(GIO_NAME)  do { \
    *((volatile unsigned int*)GIO_HIGH_##GIO_NAME) |= GIO_OVERRIDE_MASK_##GIO_NAME; \
    *((volatile unsigned int*)GIO_LOW_##GIO_NAME) &= ~(GIO_OVERRIDE_MASK_##GIO_NAME); \
    }while(0)

#define HWradio_SetGIOLowReg(GIO_NAME, value) \
     *((volatile unsigned int*)GIO_LOW_##GIO_NAME) = value;

#define HWradio_SetGIOHighReg(GIO_NAME, value) \
     *((volatile unsigned int*)GIO_HIGH_##GIO_NAME) = value;


/*************************************************************************************
 *
 * FUNCTION NAME: _HWradio_ProgNow
 *
 * Use SPI NOW mode to prog a radio register. Due to MIPS consumptions on wait/polls
 * required in SPI NOW mode, this should be avoided where possible. Mainly suited to
 * radio initialization.
 *
 *************************************************************************************/
static void _HWradio_ProgNow(uint32_t in_val)
{
    /* must wait if SPI bus is busy */
    while((*(volatile unsigned int*)0x40016060) & 0x80000000);

    /* specify data to write */
    *(volatile unsigned int*)0x40016600 = in_val;

    /* must wait if SPI bus is busy */
    while((*(volatile unsigned int*)0x40016060) & 0x80000000);
}


#if defined(BR32xx_FPGA)

static void _HWhab_Init_RF(void)
{
  volatile uint32_t config_word = 0;

  //donot use autowake up
  *(volatile unsigned int*)0x400180A0 = 0x00000000;

  config_word = 0;
  config_word |= (18 <<5); // 14bit data plus 4 bit address
  config_word |= (1<<10);  // clk pol - 1. data clocked out on rising edge.
  config_word |= (0<<11);  // data pol - 0. data not inverted
  config_word |= (1<<12);  //serial enable -1
  config_word |= (1<<16);  // clk low - 1. number of refclk cycles for which SPI clk is low.
  config_word |= (1<<20);  // clk high -1. number of refclk cycles for which SPI clk is high.
  config_word |= (0<<23);  // clk byp.
  config_word |= (1<<24);  // sel pol - 1. active low select enable.
  config_word |= (0<<27);  // set pol - 0. normal SPI mode.

  *(volatile unsigned int*)0x40016060 = config_word;

  config_word = (1 << 23);  //enable the ESER block
  config_word |= (0 << 0);  //mask -0
  config_word |= (1 << 20); //now -1
  config_word |= (0 << 21); // seq -0

  *(volatile unsigned int*)0x40016064  = config_word;

  //GIO combines - Un combine everything 0x40018000
  *(volatile unsigned int*)0x40018060 = 0x00000000;
  *(volatile unsigned int*)0x40018064 = 0x00000000;
  *(volatile unsigned int*)0x40018068 = 0x00000000;

  /*GIOs Low*/
  HWradio_SetOverrideLow(SHDN);            //SHDN low
  HWradio_SetGIOLowReg(SHDN,0x8000);
  HWradio_SetGIOLowReg(TXENA,0x8000);
  HWradio_SetGIOLowReg(RXENA,0x8000);

  /*GIOs High*/
  HWradio_SetGIOHighReg(SHDN,0x0000);
  HWradio_SetGIOHighReg(TXENA,0x0000);
  HWradio_SetGIOHighReg(RXENA,0x0000);
}

/*
 * MAX2829 go to standby state
 */
static void _HWradio_Go_To_Idle_State(void)   //MAX2829 go to standby state
{
  /*SPI reset mode*/
  HWradio_SetOverrideLow(SHDN);
  HWradio_SetOverrideHigh(TXENA);
  HWradio_SetOverrideHigh(RXENA);

  /*standby mode*/
  HWradio_SetOverrideLow(TXENA);
  HWradio_SetOverrideLow(RXENA);
  HWradio_SetOverrideHigh(SHDN);

  //need to add test SER/ESER and RF
  /****************************
   * MAX2829 Initialize
   ****************************/
  _HWradio_ProgNow(WRITE_REG0);
  _HWradio_ProgNow(WRITE_REG1);
  _HWradio_ProgNow(WRITE_REG2);
  _HWradio_ProgNow(WRITE_REG3);
  _HWradio_ProgNow(WRITE_REG4);  //set freq 2497
  _HWradio_ProgNow(WRITE_REG5);
  _HWradio_ProgNow(WRITE_REG6);
  _HWradio_ProgNow(WRITE_REG7);
  #if MAX2829_FPGA_AGC_ENABLE
  _HWradio_ProgNow(WRITE_REG8_EXT_PIN_EN);
  #else
  _HWradio_ProgNow(WRITE_REG8);
  #endif
  _HWradio_ProgNow(WRITE_REG9);
  _HWradio_ProgNow(WRITE_REGA);
  _HWradio_ProgNow(WRITE_REGB);
  _HWradio_ProgNow(WRITE_REGC);

//  _HWradio_ProgNow(WRITE_REG(0x03, 0xa5));       //configure the channel is 2484
//  _HWradio_ProgNow(WRITE_REG(0x04, 0x8ccc>>2));
}


void MAX2829_init(void)
{
  *(volatile unsigned int*)0x40018028 = 0x360062b8;
  *(volatile unsigned int*)0x40018008 =  0x70000;
  *(volatile unsigned int*)0x40018008 = 0x170000;

  _HWhab_Init_RF();
  _HWradio_Go_To_Idle_State();
}

void MAX2829_RxMode_init(void)
{
  *(volatile unsigned int*)0x40018028 = 0x360062b8;
  *(volatile unsigned int*)0x40018008 = 0x70000;
  *(volatile unsigned int*)0x40018008 = 0x170000;

  HWradio_SetOverrideHigh(SHDN);
  osalThreadSleepS(100);
  HWradio_SetOverrideLow(TXENA);
  osalThreadSleepS(100);
  HWradio_SetOverrideHigh(RXENA);
  osalThreadSleepS(100);
}


void rf_lld_MAX2829_RX(uint8_t channel)
{
  _HWradio_ProgNow(WRITE_REG3_RX(channel-2));
  _HWradio_ProgNow(WRITE_REG4_RX(channel-2));
  HWradio_SetOverrideHigh(SHDN);
  HWradio_SetOverrideLow(TXENA);
  HWradio_SetOverrideHigh(RXENA);
}
void rf_lld_MAX2829_TX(uint8_t channel)
{
  _HWradio_ProgNow(WRITE_REG3_TX(channel-2));
  _HWradio_ProgNow(WRITE_REG4_TX(channel-2));
  HWradio_SetOverrideHigh(SHDN);
  HWradio_SetOverrideLow(RXENA);
  HWradio_SetOverrideHigh(TXENA);
}

void rf_lld_MAX2829_RX_gain(uint8_t gain)
{
  _HWradio_ProgNow(WRITE_REG(0x0B, gain));  //[0, 1f]
}

void rf_lld_MAX2829_TX_gain(uint8_t gain)
{
  _HWradio_ProgNow(WRITE_REG(0x0c, gain));  //[0, 3f]
}
#endif /* BR32xx_FPGA */

void MAC6200_CEVA_RXENA(bool rxena_on)
{
  if (rxena_on) {
      HWradio_SetOverrideHigh(RXENA);
  }
  else {
      HWradio_SetOverrideLow(RXENA);
  }
}

void MAC6200_CEVA_TXENA(bool txena_on)
{
  if (txena_on)
    HWradio_SetOverrideHigh(TXENA);
  else
    HWradio_SetOverrideLow(TXENA);
}

void MAC6200_CEVA_Set_Freq(uint8_t index)
{
  _HWradio_ProgNow(WRITE_REG3_TX(index));
  _HWradio_ProgNow(WRITE_REG4_TX(index));
}


#endif /* HAL_USE_RF */
