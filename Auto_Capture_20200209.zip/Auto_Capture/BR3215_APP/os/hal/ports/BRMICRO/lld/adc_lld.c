/*
    ChibiOS/RT - Copyright (C) 2006-2013 Giovanni Di Sirio
    Copyright (C) 2018 BRMICRO Technologies

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    templates/adc_lld.c
 * @brief   ADC Driver subsystem low level driver source template.
 *
 * @addtogroup ADC
 * @{
 */

#include "hal.h"

#if HAL_USE_ADC || defined(__DOXYGEN__)
/*===========================================================================*/
/* Driver local definitions.                                                 */
/*===========================================================================*/

#define __adc_set_bitval(val, bit, bitval)          \
do{                                                 \
  uint32_t mask;                                    \
  mask = 1u<<(bit);                                 \
  (val) = ((val)&~mask) | (((bitval)<<(bit))&mask); \
}while(0)

#define __adc_set_bitsval(val, s, e, bitval)        \
do{                                                 \
  uint32_t mask;                                    \
  mask = ((1u<<((e)-(s)+1)) - 1) << (s);            \
  (val) = ((val)&~mask) | (((bitval)<<(s))&mask);   \
}while(0)

//#define __adc_set_fifo_en(adc, val)             __adc_set_bitval((adc)->FIFO_CON, 0, (val))
//#define __adc_set_fifo_rstn(adc, val)           __adc_set_bitval((adc)->FIFO_CON, 1, (val))
//#define __adc_set_fifo_thres(adc, val)          __adc_set_bitsval((adc)->RXFIFO_TH, 0, 3, (val))
#if (HS_HAS_DMA == TRUE) && (ADC_USE_DMA == TRUE)
#define __adc_set_dma_en(adc, val)              __adc_set_bitval((adc)->DMA_CON, 0, (val))
#endif // ADC_USE_DMA

#define __is_channel_in_group(grpp, chn)          (grpp->channel_mask & (1u<<chn))

/*===========================================================================*/
/* Driver exported variables.                                                */
/*===========================================================================*/

/**
 * @brief   ADC0 driver identifier.
 */
#if HS_ADC_USE_ADC0 || defined(__DOXYGEN__)
ADCDriver ADCD0;
#endif

/*===========================================================================*/
/* Driver local variables and types.                                         */
/*===========================================================================*/
#if defined(BR3215c)
typedef enum adc_cal_compensation_t {
	ADC_CAL_COMPENSATION_NO = 0,
	ADC_CAL_COMPENSATION_DIFFERENTIAL = 1,
	ADC_CAL_COMPENSATION_SINGLE_ENDED = 2,
} adc_cal_compensation_t;
#elif defined(BR3215e)
typedef enum adc_cal_compensation_t {
	/**
	 * HS_ADC.COMPEN_CTRL
	 */
	ADC_CAL_COMPENSATION_NO = 0,
	ADC_CAL_COMPENSATION_YES = 1,
	/**
	 * HS_ADC.COMPEN_DBG:
	 * bit0 = sel_compen_mn: auto/manual set single-ended/differential mode (bit1).
   * bit15 = vcm_mn: read vcm from sel_vcm/vcm_reg(bit[31..161].
	 */
	ADC_CAL_COMPENSATION_AUTO = 0,
	ADC_CAL_COMPENSATION_MANUAL = (1<<0 | 1<<15),
} adc_cal_compensation_t;
#endif

/**
 * @brief   Data structure of ADC register @p ADC_CFG1.
 */
typedef struct adc_reg_cfg1_t {
	union {
		__IO uint32_t    whole;                  /**< @brief ADC register CFG1 */
		struct {
			__IO uint32_t  cont               : 1; /**< @brief Bit0:      enable group continuous (repeat) mode: 0-one shot, 1-forever
			                                                              Note: It is forbidden to set both bits CONT=1 and DISCEN=1.*/
			__IO uint32_t  align              : 1; /**< @brief Bit1:      data alignment: 0-right, 1-left. */
		  __IO uint32_t  trigger_mode       : 1; /**< @brief Bit2:      trigger mode: 0-software, 1-hardware. */
		  __IO uint32_t  scandir            : 1; /**< @brief Bit3:      channel scan order: 0-small first, 1-big first */
		  __IO uint32_t  hw_trigger_source  : 4; /**< @brief Bit[4..7]: @p adc_trigger_source_t, hardware trigger source:
		                                                                0~3-TM0:0~3, 4~7-TM1:0~3,8~11-TM2:0~3, 12-EXT (GPIO12 in SFLASH mode) */
		  __IO uint32_t  trigger_edge       : 2; /**< @brief Bit[8..9]: @p adc_trigger_edge_t, trigger edge: 0-positive, 1-negative, 2-dual, 3-positive
		                                                                Applies to both hard-trigger and soft-trigger. */
		  __IO uint32_t  discen             : 1; /**< @brief Bit[10]:   enable discontinuous channel conversion inside group:
		                                                                0-continuous, convert all channels in group per trigger event,
		                                                                1-discontinuous, convert one channel per trigger event. */
		  __IO uint32_t                     : 1; /**< @brief Bit[11]:   Not used. */
		  __IO uint32_t  sarq_bypass        : 1; /**< @brief Bit[12]:   enable bypassing CIC (Cascaded integrator-comb)
		                                                                filter of SAR-Q route:
		                                                                0-use CIC filter (i.e. SAR-Q data is from CIC filter), default normal use.
		                                                                1-bypass CIC filter (i.e. SAR-Q data is directly from analog input */
		  __IO uint32_t  swap_enable        : 1; /**< @brief Bit[13]:   enable positive/negative inputs swap: 0-disable, 1-enable */
		  __IO uint32_t  test_mode          : 1; /**< @brief Bit[14]:   enable test_mode: 0-from adc (normal), 1-from register */
		};
	};
} adc_reg_cfg1_t;

static const uint32_t _s_adc_cal_table_default[] =	{
		  0x00000000, /* adc_s_vos_mod_lut0  */
  		0x00000000, /* adc_s_vos_mod_lut1  */
  		0x08000800, /* adc_s_gain_mod_lut0 */
  		0x08000800, /* adc_s_gain_mod_lut1 */
  		0x08000800, /* adc_s_vcm_mod_lut0  */
  		0x08000800, /* adc_s_vcm_mod_lut1  */
  		0x00000000, /* adc_d_vos_mod_lut0  */
  		0x00000000, /* adc_d_vos_mod_lut1  */
  		0x08000800, /* adc_d_gain_mod_lut0 */
  		0x08000800  /* adc_d_gain_mod_lut1 */
		};

#if 0
static const uint32_t  s_adc_cal_param_3235_for_test[] = {
		0x40DaC000, // mvos_mod = 6mv
		0x3F7DA11A, // gain_mod = 0.991
};
#endif

/*===========================================================================*/
/* Driver local functions.                                                   */
/*===========================================================================*/

#if (HS_HAS_DMA == TRUE) && (ADC_USE_DMA == TRUE)
static void _adc_dma_timeout(void *p) {
  ADCDriver *adcp = (ADCDriver *)p;

  osalSysLockFromISR();
  if (adcp->dmathrd != NULL) 
  {
    thread_t *tp = adcp->dmathrd;
    adcp->dmathrd = NULL;
    tp->p_u.rdymsg = MSG_TIMEOUT; 
    chSchReadyI(tp);  
  }
  osalSysUnlockFromISR();
}

#define _adc_wakeup_dmareset(adcp) {                                   \
  if ((adcp)->dmathrd != NULL) {                                        \
    thread_t *tp = (adcp)->dmathrd;                                     \
    (adcp)->dmathrd = NULL;                                             \
    tp->p_u.rdymsg = MSG_RESET;                                                 \
    chSchReadyI(tp);                                                        \
  }                                                                         \
}

static void _adc_dma_complete(ADCDriver *adcp, hs_dma_cb_para_t *var)
{
  (void)var;
  if (adcp->dmathrd != NULL) 
  {
    thread_t *tp = adcp->dmathrd;
    adcp->dmathrd = NULL;
    tp->p_u.rdymsg = MSG_OK; 
    chSchReadyI(tp);  
  }
}
#endif // ADC_USE_DMA

//-------------------------------------------------------------
/**
 * @brief   Sign extension from specified bit to foremost bit of the underlying
 *          data format of int32_t.
 * @param   data       data to be sign-extended, which in fact is itself a
 *                     signed integer.
 * @param   from_bit   original position of sign bit.
 * @return  sign-extended result.
 */
static int32_t sign_extension(uint32_t data, int from_bit) {

	#define DATA_MASK(sign_bit)           ((1u << (sign_bit + 1)) - 1)
	#define FROM_SIGN_BIT_MASK(sign_bit)  (1u << sign_bit)
	#define TO_SIGN_BITS_MASK(from, to)   (((1u << (to - from)) - 1) << (from + 1))

  data &= DATA_MASK(from_bit);

  if(!(data & FROM_SIGN_BIT_MASK(from_bit)))
    return data;

  return (int32_t)(data | TO_SIGN_BITS_MASK(from_bit, 31));
}

static bool adc_is_cal_param_valid(adc_cal_param_t *param) {

	uint16_t vos_mod = param->vos_mod;
	uint16_t gain_mod = param->gain_mod;
	uint16_t vcm_mod = param->vcm_mod;

	vos_mod &= 0xF800;
	vos_mod >>= 11;
	if (!(vos_mod == 0x0000 || vos_mod == 0x001F)) // is upper 5 bits (sign bits) of param->vos_od are all the same.
		return false;

	if (gain_mod == 0) // must not be 0
		return false;
	if ((gain_mod & 0xF000) != 0x0000) // upper 4 bits should be 0.
		return false;

	if (vcm_mod == 0)
		return false;
	if ((vcm_mod & 0xF000) != 0x0000)
		return false;

	return true;
}

static bool adc_is_cal_table_valid(adc_cal_table_t *table) {

	if (table == 0)
		return false;

	adc_cal_param_t param;
	int differential;
	adc_pga_gain_t gain;
	for (differential = 0; differential < 2; differential++) {
		for (gain = 0; gain < 4; gain++) {
			adc_lld_get_cal_param_from_table(&param, table, differential, gain);
			if (!adc_is_cal_param_valid(&param))
				return false;
		}
	}

	return true;
}
#if !(HS_ADC_HAS_HARD_CAL == TRUE)
/**
 * @brief Soft-calibrate ADC conversion data using calibrated parameters.
 *
 * @note  Calibration to data here means data compensation.
 *        Formula:
 *           vout_cal = (vout - vos_mod)/gain*gain_mod + vcm*vcm_mod;
 *
 * @param data      the data to be adjusted.
 * @param gain      the same gain that applied when acquiring @p data.
 *                  @p adc_pga_gain_t
 * @param calparam  pointer to @p adc_cal_param_t object.
 *                  It should have been acquired by ADC calibration process,
 *                  or set with default values.
 *
 * @return          the adjusted value in Q4.11 format.
 */
static adcsample_t adc_lld_data_soft_cal(const adcsample_t data,
		                    const adc_pga_gain_t gain,
		                    const adc_vcm_t vcm,
												const adc_cal_param_t *calparam) {

	int32_t sdata    = sign_extension(data, ADC_Q);              // Q0.11 => Q20.11
	int32_t vos_mod  = sign_extension(calparam->vos_mod, ADC_Q); // Q0.11 => Q20.11
	int32_t gain_mod = (int32_t)calparam->gain_mod;          // Q1.11 => Q20.11

	int32_t x = adc_data_qmul(adc_data_qdiv(sdata - vos_mod, (0x0400<<gain)), gain_mod);

#if defined(BR3215e) && HS_ADC_EXTENDED_RANGE_ENABLE
	// additional gain of 1/4 after Pre-Gain-Amplifier
	x *= 4;
#endif

#if defined(BR3215)
	(void)vcm;
#else
	int32_t vcm_mod  = (int32_t)calparam->vcm_mod;           // Q1.11 => Q20.11
	x += adc_data_qmul(adc_data_qmul(vcm<<ADC_Q, 0x0800>>3), vcm_mod); // 0x0800/8 = 125mV
#endif
	return (adcsample_t)x;
}

/**
 * @brief Soft-calibrate data according to parameters in @p ADCDriver object and channel.
 *
 * @param adcp
 * @param chn
 * @param data
 * @return
 */
static adcsample_t adc_lld_data_soft_cal_channel(ADCDriver *adcp,
												const adc_channel_t chn,
												const adcsample_t data) {

	adc_pga_gain_t gain = adcp->grpp->channel_param[chn].gtune;
	adc_vcm_t vcm = adcp->grpp->channel_param[chn].sel_vcm;
	bool is_differential = adcp->grpp->channel_param[chn].sel_inn != ADC_CHANNEL_CHIP_VCM;
	adc_cal_param_t calparam;
	adc_lld_get_cal_param_from_table(&calparam, adcp->cal_table, is_differential, gain);
	return adc_lld_data_soft_cal(data, gain, vcm, &calparam);
}

#endif // #if !(HS_ADC_HAS_HARD_CAL == TRUE)

/**
 * @brief Convert voltage to temperature.
 *
 * @note  In order to accommodate temperature higher than 15 degree Celsius
 *        in the Q4.11 format, the temperature is divided by 10 and use
 *        10 degree Celsius as its unit.
 *
 *        Formula:
 *           degree_Celsius = (740 - mv) / 1.425 + 55;
 *           ten_degree_Celsius = degree_Celsius / 10;
 *
 * @param v     voltage in unit of V and format of Q4.11.
 * @retval      temperature in 10 degree Celsius.
 */
static adcsample_t adc_lld_voltage_to_temperature(adcsample_t v) {

#if 0 && defined(BR3215e)
	const int32_t mv740 = 800<<ADC_Q;
	const int32_t x1p425 = 0x0C39; // 1.528f
	const int32_t t55 = 0<<ADC_Q;
#else
	const int32_t mv740 = 740<<ADC_Q;
	const int32_t x1p425 = 0x0B66; // 1.425f
	const int32_t t55 = 55<<ADC_Q;
#endif

	int32_t mv = v*1000;
	int32_t t = adc_data_qdiv((mv740 - mv), x1p425) + t55; // (740 - mv) / 1.425 + 55;
	t = adc_data_qdiv(t, 10<<ADC_Q); // divide by 10 to accommodate it in the int16_t type.

	return (adcsample_t)t;
}

/**
 * Adjust data according to temperature/battery channel.
 */
inline static adcsample_t adc_lld_data_adjust_channel(const adc_channel_t chn,
												const adcsample_t data) {

	adcsample_t x = data;

	if (chn == ADC_CHANNEL_CHIP_TEMPERATURE) {
		/**
		 * Temperature in 10 degree Celsius.
		 */
		x = adc_lld_voltage_to_temperature(x);
	}
	else if (chn == ADC_CHANNEL_CHIP_BATTERY) {
		/**
		 * Because the battery channel has a fixed attenuation of 1/3
		 * before into ADC, multiplying 3 to compensate it.
		 */
		x *= 3;
	}
#if defined(BR3215e)
	else if (chn == ADC_CHANNEL_CHIP_1V4) {
		x *= 7;
		x /= 5;
	}
	else if (chn == ADC_CHANNEL_CHIP_3V3) {
		x *= 2;
	}
#endif

	return x;
}

static void adc_lld_set_timing(ADCDriver *adcp)
{
  HS_ADC_Type *adc = adcp->adc;
	const adc_timing_t *timing = adcp->config->timing;

  adc->TIMING_CFG0 = 0x00424166UL; // Manually-tuned value 0x00424166UL
  if (adcp->config && timing) {
		__adc_set_bitsval((adc)->TIMING_CFG0,  0,  3, (timing->t1));
		__adc_set_bitsval((adc)->TIMING_CFG0,  4,  7, (timing->t2));
		__adc_set_bitsval((adc)->TIMING_CFG0,  8, 11, (timing->t3));
		__adc_set_bitsval((adc)->TIMING_CFG0, 12, 15, (timing->t4));
		__adc_set_bitsval((adc)->TIMING_CFG0, 16, 23, (timing->cic_cycle));
		__adc_set_bitsval((adc)->TIMING_CFG1,  0, 11, (timing->t5));
		__adc_set_bitsval((adc)->TIMING_CFG1, 12, 17, (timing->t6));
		__adc_set_bitsval((adc)->TIMING_CFG1, 20, 23, (timing->smp_cycle));
		__adc_set_bitsval((adc)->TIMING_CFG1, 24, 27, (timing->rst_cycle));
  }
}

void adc_lld_set_calibration_table(ADCDriver *adcp, adc_cal_table_t *table) {

	if (table)
		adcp->cal_table = table;
	else if (adcp->cal_table == NULL)
		adcp->cal_table = adcp->cal_table_default;

#if !defined(BR3215)
	uint32_t i;
	for (i = 0; i < 10; i++) // fill in cal_compen lookup tables:
		*(&adcp->adc->S_VOS_MOD_LUT0 + i) = *(&adcp->cal_table->s_vos_mod_lut0 + i);
#endif
}

/**
 * @brief   Configure the ADC according to current conversion group settings.
 * @details Configurations extracted from conversion group settings:
 *            CONT:
 *            Discen:
 *            trigger_mode:
 *            trigger_source:
 *            trigger_edge:
 *            calibration enable:
 *          Configurations fixed to default values:
 *            Align:               ADC_DATA_ALIGN_RIGHT
 *            Scandir:             ADC_SCAN_DIR_LOW_FIRST
 *            Sarq_bypass:         ADC_INPUT_SRC_FILTER
 *            swap_enable:         false
 *            test_mode:           false
 */
static void adc_lld_config(ADCDriver *adcp, const ADCConversionGroup *grpp) {

	HS_ADC_Type *adc = adcp->adc;

  /**
   * When grpp == NULL, set timing and calibration table.
   */
	if (grpp == NULL) {
  	adc_lld_set_timing(adcp);
  	adc_lld_set_calibration_table(adcp, NULL);

#if 0 // for debug
  	adc->FLAG_FSM &= ~(3u<<10); // set sel_inn, sel_vcm to manual
  	adc->DEBUG_REG0 &= ~(0xffu<<16);
  	adc->DEBUG_REG0 |= 2u<<16 | 0u<<20; // VCM = 0mV
#endif

  	adc->CFG1 = 0;
#if HS_ADC_HAS_HARD_CAL
#if defined(BR3215c)
		adc->COMPEN_CTRL = ADC_CAL_COMPENSATION_SINGLE_ENDED;
#elif defined(BR3215e)
  	adc->COMPEN_CTRL = ADC_CAL_COMPENSATION_YES;
  	adc->COMPEN_DBG = ADC_CAL_COMPENSATION_AUTO;
#endif /* defined(BR3215c) */
#else /* HS_ADC_HAS_HARD_CAL */
#if defined(BR3215c)
	adc->COMPEN_CTRL = ADC_CAL_COMPENSATION_NO;
#elif defined(BR3215e)
	adc->COMPEN_CTRL = ADC_CAL_COMPENSATION_NO;
#if HS_ADC_EXTENDED_RANGE_ENABLE
	HS_ANA->COMMON_PACK[0] |= 1u<<31; // additional gain of 1/4 after Pre-Gain-Amplifier
#else
	HS_ANA->COMMON_PACK[0] &= ~(1u<<31); // additional gain of 1/4 after Pre-Gain-Amplifier
#endif /* HS_ADC_EXTENDED_RANGE_ENABLE */
#endif /* defined(BR3215c) */
#endif /* HS_ADC_HAS_HARD_CAL */

  	return;
	}

	adc_reg_cfg1_t adc_cfg1;
 	adc_cfg1.whole = 0;
	const adc_trigger_t *trigger = &grpp->trigger;
#if defined(BR3215)
	/* Please refer to comment on @p ADCDriver.discard. */
	switch (ADC_TRIGGER_TARGET_GROUP_CONTINUOUS) {
#else
	switch (trigger->target) {
#endif
	case ADC_TRIGGER_TARGET_GROUP_ONESHOT:
		adc_cfg1.cont = 0;
		adc_cfg1.discen = 0;
		break;
	case ADC_TRIGGER_TARGET_CHANNEL_ONESHOT:
		adc_cfg1.cont = 0;
		adc_cfg1.discen = 1;
		break;
	case ADC_TRIGGER_TARGET_GROUP_CONTINUOUS:
		adc_cfg1.cont = 1;
		adc_cfg1.discen = 0;
		break;
	}
	adc_cfg1.trigger_mode      = trigger->source != ADC_TRIGGER_SOURCE_SW;
	adc_cfg1.hw_trigger_source = trigger->source;
	adc_cfg1.trigger_edge      = trigger->edge;

//	adc_cfg1.sarq_bypass = 1;
	adc->CFG1 = adc_cfg1.whole;

#if defined(BR3215c)
	if (grpp->cal_en) {
		/**
		 * VCM value selection and single-ended/differential selection should be
		 * implemented by hardware according to channel parameter settings in
		 * future chip version.
		 */
		/**
		 * Normally VCM is parameter of channel, but as far as current chip version,
		 * a group can only contain channels that all have the same VCM selection.
		 */
		adc_vcm_t vcm = grpp->channel_param[grpp->channel[0]].sel_vcm;
		adc->COMPEN_CTRL = (vcm*0x0100u/*vcm*0.125*/)<<16 | (
				(grpp->channel_param[grpp->channel[0]].sel_inn == ADC_CHANNEL_CHIP_VCM) ?
					ADC_CAL_COMPENSATION_SINGLE_ENDED : ADC_CAL_COMPENSATION_DIFFERENTIAL);
	}
	else
		adc->COMPEN_CTRL = ADC_CAL_COMPENSATION_NO;
#elif defined(BR3215e)
	if (!grpp->cal_en)
		adc->COMPEN_CTRL = ADC_CAL_COMPENSATION_NO;
#endif
}

static void adc_lld_config_channels(ADCDriver *adcp)
{
	const ADCConversionGroup *grpp = adcp->grpp;

	adcp->adc->CHSELR = 0;

	int i;
	for (i = 0; i < grpp->num_channels; i++) {
		int chn = grpp->channel[i];
		*(&adcp->adc->ANA_REG0 + chn) = grpp->channel_param[chn].val;
	}

	adcp->adc->CHSELR = grpp->channel_mask;
}

static void adc_deal_with_errors(ADCDriver *adcp, uint16_t intr_src) {

	(void)intr_src;

  // Error handling:
  if (0/* TODO: overflow */) {
		/* ADC overflow condition, this could happen only if the Manual/DMA is unable
			 to read data fast enough.*/
		_adc_isr_error_code(adcp, ADC_ERR_OVERFLOW);
	}
	if (0/* TODO: watchdog */) {
		/* Analog watchdog error.*/
		_adc_isr_error_code(adcp, ADC_ERR_AWD);
	}
}

/**
 * @brief Manually read converted data to buffer of M*N samples matrix.
 *        Soft-cal data, and adjust data when it is from temperature/battery
 *        channels.
 *
 * @param[in] adcp      pointer to the @p ADCDriver object
 * @param[in] src       bitmap of channels of which data is to be moved
 */
static void adc_move_channel_data_to_buffer(ADCDriver *adcp, const uint16_t src) {

	const ADCConversionGroup *grpp = adcp->grpp;
	const uint16_t intr = src & grpp->channel_mask;
	if (!intr)
		return;

	adcsample_t * const samples = adcp->samples;
	const int32_t idx = adcp->current_samples*grpp->num_channels;
	uint16_t i;

	// Move data from register to buffer
	for (i = 0; i < grpp->num_channels; i++) {
		uint16_t chn = grpp->channel[i];
		if (intr & (1u<<chn)) {
#if defined(BR3215)
			if (adcp->discard < grpp->num_channels) {
				adcp->discard++;
				return;
			}
#endif
			samples[idx + i] = *(&(adcp->adc->DATA_REG0) + chn);
			if (i == grpp->num_channels - 1)
				adcp->current_samples++;
		}
	}

	// Softcal data and adjust data (temperature and battery channels)
	for (i = 0; i < grpp->num_channels; i++) {
		uint16_t chn = grpp->channel[i];
		if (intr & (1u<<chn)) {
			adcsample_t temp = samples[idx + i];
#if !(HS_ADC_HAS_HARD_CAL == TRUE)
			temp = adc_lld_data_soft_cal_channel(adcp, chn, temp);
#endif
			temp = adc_lld_data_adjust_channel(chn, temp);
			samples[idx + i] = temp;
		}
	}
}

/**
 * @brief   ISR code.
 *
 * @param[in] adcp      pointer to the @p ADCDriver object
 *
 * @notapi
 */
static void adc_serve_interrupt(ADCDriver *adcp) {

  HS_ADC_Type *adc = adcp->adc;

  adc->CFG0 = 0; // START=0

  uint16_t intr_mask = adc->INTR_MASK;
  adc->INTR_MASK = 0;

  uint16_t src = adc->INTR & 0x1fff;
  adc->INTR = src;

  adc_deal_with_errors(adcp, src);
  /* sanity check */
  if (NULL == adcp->grpp) return;

  if (src & ADC_INTR_MASK_EOS) {
  	// end of group conversion:
  	adc_move_channel_data_to_buffer(adcp, adcp->grpp->channel_mask);
  }
  else if (src & adcp->grpp->channel_mask) {
  	// end of channel conversion
  	adc_move_channel_data_to_buffer(adcp, src);
  }

  // invoke callbacks
	/* It is possible that the conversion group has already be reset by the
		 ADC error handler, in this case this interrupt is spurious.*/
	if (adcp->current_samples != 0 && adcp->current_samples == adcp->depth / 2) {
		/* Half transfer processing.*/
		_adc_isr_half_code(adcp);
	}
	else if (adcp->current_samples == adcp->depth) {
		/* Transfer complete processing.*/
		_adc_isr_full_code(adcp);
		adcp->current_samples = 0;
		if (!(adcp)->grpp->circular)
			return;
	}

	adc->INTR_MASK = intr_mask;
}

#if HS_ADC_USE_ADC0 || defined(__DOXYGEN__)
OSAL_IRQ_HANDLER(ADC_IRQHandler) {

  OSAL_IRQ_PROLOGUE();
  adc_serve_interrupt(&ADCD0);
  OSAL_IRQ_EPILOGUE();
}
#endif /* HS_ADC_USE_ADC0 */
/*===========================================================================*/
/* Driver exported functions.                                                */
/*===========================================================================*/

/**
 * @brief   Low level ADC driver initialization.
 *
 * @notapi
 */
void adc_lld_init(void) {

#if HS_ADC_USE_ADC0
  /* Driver initialization.*/
  adcObjectInit(&ADCD0);

  ADCD0.adc = HS_ADC;
  ADCD0.cal_table_default = (adc_cal_table_t*)_s_adc_cal_table_default;
  ADCD0.cal_table = ADC_CAL_TABLE; /* The table is prepared by FT test. */

#if defined(BR3215)
  /**
   * Convert ADC calibration parameters in floating-point format measured and
   * used in old BR3215 driver to Q4.11 format used in new BR3215C ADC driver.
   */
	static adc_cal_table_t cal_table_3235;
	cal_table_3215 = *ADCD0.cal_table_default;
#if 0 // for test
	adc_cal_param_3215_t *param_3215 = (adc_cal_table_t*)s_adc_cal_param_3215_for_test;
#else
	adc_cal_param_3215_t *param_3215 = (adc_cal_param_3215_t *)ADCD0.cal_table;
#endif
	cal_table_3215.s_vos_mod_0  = (int16_t)float_to_fixed(param_3215->mvos_mod/1000, ADC_Q);
	cal_table_3215.s_gain_mod_0 = (int16_t)float_to_fixed(param_3215->gain_mod, ADC_Q);
	ADCD0.cal_table = &cal_table_3215;
#endif

  if (!adc_is_cal_table_valid(ADCD0.cal_table))
  	ADCD0.cal_table = ADCD0.cal_table_default;
#endif /* HS_ADC_USE_ADC0 */
}

/**
 * @brief   Configures and activates the ADC peripheral.
 *
 * @param[in] adcp      pointer to the @p ADCDriver object
 *
 * @notapi
 */
void adc_lld_start(ADCDriver *adcp) {

	/* If in stopped state then enables the ADC and DMA clocks.*/
  if (adcp->state == ADC_STOP) {    
#if HS_ADC_USE_ADC0
    if (&ADCD0 == adcp) {
      cpmEnableADC0();   
      cpmResetADC0(); 

      /* ADC initial setup, configuring working mode and timings. */
      adc_lld_config(adcp, NULL);

      nvicEnableVector(ADC_IRQn, ANDES_PRIORITY_MASK(HS_ADC_ADC0_IRQ_PRIORITY));
      cpmDisableADC0();
    }
#endif /* HS_ADC_USE_ADC0 */
  }
}

/**
 * @brief   Deactivates the ADC peripheral.
 *
 * @param[in] adcp      pointer to the @p ADCDriver object
 *
 * @notapi
 */
void adc_lld_stop(ADCDriver *adcp) {
  
	/* If in ready state then disables the ADC clock and analog part.*/
  if (adcp->state == ADC_READY) {
    /* Resets the peripheral.*/
    
    /* Disables the peripheral.*/
#if HS_ADC_USE_ADC0
    if (&ADCD0 == adcp) {
      cpmEnableADC0();
      nvicDisableVector(ADC_IRQn);
      adc_lld_stop_conversion(adcp);
      cpmDisableADC0();
    }
#endif /* HS_ADC_USE_ADC0 */
  }
}

/**
 * @brief   Starts an ADC conversion.
 *
 * @param[in] adcp      pointer to the @p ADCDriver object
 *
 * @notapi
 */
int adc_lld_start_conversion(ADCDriver *adcp) {

	if (adcp == NULL || adcp->grpp == NULL)
		return -1;

  HS_ADC_Type *adc = adcp->adc;
  const ADCConversionGroup *grpp = adcp->grpp;

  if(grpp->channel_mask == 0)
    return -2;

  adcp->current_samples = 0;
#if defined(BR3215)
  adcp->discard = 0;
#endif

  // Configure ADC and channels of group
  adc_lld_config(adcp, adcp->grpp);
  adc_lld_config_channels(adcp);

  // Enable interrupt
  adc->INTR = 0xFFFF;
  adc->INTR_MASK = adcp->grpp->trigger.target == ADC_TRIGGER_TARGET_CHANNEL_ONESHOT ?
 			grpp->channel_mask : ADC_INTR_MASK_EOS;

  /**
   * Differ to STM32F0:
   * The first START=1 operation in BR3215C is not a START signal as in STM32F0,
   * but a real soft-trigger event that will trigger the first conversion in
   * soft-trigger mode.
   */
  return 0;
}

#if (HS_HAS_DMA == TRUE) && (ADC_USE_DMA == TRUE)
int adc_lld_start_conversionWithDMA(ADCDriver *adcp, uint8_t *pDmaBuf, uint32_t DmaLen) {
  HS_ADC_Type *adc = adcp->adc;
  uint16_t chn_mask = adcp->grpp->channel_mask;
  hs_dma_config_t cfg;

  if(adcp->grpp->channel_mask == 0)
    return -2;

  if(adcp->pdma == NULL)
  {
    DmaLen = DmaLen - DmaLen % adcp->grpp->num_channels;
    adcp->pdma = dmaStreamAllocate(HS_ADC_DMA_PRIORITY, (hs_dmaisr_t)_adc_dma_complete, (void *)adcp);
    if (adcp->pdma == NULL) 
      return -2;
    cfg.slave_id = ADC_DMA_ID;
    cfg.direction = DMA_DEV_TO_MEM;
    cfg.src_addr_width = DMA_SLAVE_BUSWIDTH_16BITS;
    cfg.dst_addr_width = DMA_SLAVE_BUSWIDTH_16BITS;
    cfg.src_burst = DMA_BURST_LEN_1UNITS;
    cfg.dst_burst = DMA_BURST_LEN_1UNITS;
    cfg.dev_flow_ctrl = FALSE;	
    cfg.lli_en = 0;
    dmaStreamSetMode(adcp->pdma, &cfg);
    
    __adc_set_fifo_en(adc, 1);
    __adc_set_fifo_rstn(adc, 0);
    __adc_set_fifo_rstn(adc, 1);
    __adc_set_dma_en(adc, 1);
    __adc_set_fifo_thres(adc, adcp->grpp->num_channels);

    dmaStreamStart(adcp->pdma, &adc->RXFIFO_DATA, pDmaBuf, DmaLen / 2);

  }
  
  adc->CHSELR = chn_mask;
  adc->INTR_MASK = ADC_INTR_MASK_EOS;

  adc_lld_soft_trigger(adcp);

  return 0;
}

int adc_lld_dmaWaitForDone(ADCDriver *adcp, systime_t timeout) {
  HS_ADC_Type *adc = adcp->adc;
  virtual_timer_t vt;

  if(adcp->grpp->channel_mask == 0)
    return 0;
  
  nds32_dcache_flush();  
  if (timeout != TIME_INFINITE)
  {
    chVTObjectInit(&vt);
    chVTSetI(&vt, timeout, _adc_dma_timeout, (void *)adcp);
  }
  
  adcp->dmathrd = currp;
  chSchGoSleepS(CH_STATE_SUSPENDED);
  if ((timeout != TIME_INFINITE) && chVTIsArmedI(&vt))
  {
    chVTResetI(&vt);
  }

  __adc_set_fifo_en(adc, 0);
  __adc_set_dma_en(adc, 0);
  if(adcp->pdma != NULL)
  {
    dmaStreamRelease(adcp->pdma);
    adcp->pdma = NULL;
  }

  return currp->p_u.rdymsg;
}
#endif

/**
 * @brief   Stops an ongoing conversion.
 *
 * @param[in] adcp      pointer to the @p ADCDriver object
 *
 * @notapi
 */
void adc_lld_stop_conversion(ADCDriver *adcp) {

	HS_ADC_Type *adc = adcp->adc;

  adcp->current_samples = 0;
#if (HS_HAS_DMA == TRUE) && (ADC_USE_DMA == TRUE)
  _adc_wakeup_dmareset(adcp);
#endif

  /**
   * To ensure reliability, there must be a delay between CFG0=ADC_STOP_BIT and
   * CFG0=0, 1/16MHz is enough.
   */
  adc->CFG0 = ADC_STOP_BIT; // Set STOP bit
  adc->INTR_MASK = 0;
  adc->CHSELR = 0;
  adc->INTR = 0xFFFF;
  //cpm_delay_us(1);       // If unreliability appears, turn this on.
  adc->CFG0 = 0;           // Clear STOP bit
  adc->CFG1 = 0;           // Switch to soft trigger source
                           // (since there's no start state for hard trigger).
                           // MUST, or it will be auto-triggered next time when
                           // the conversion is started waiting for the same
                           // hard trigger source.
}

/**
 * Issue a software trigger event.
 */
void adc_lld_soft_trigger(ADCDriver *adcp) {

	/**
	 * Software trigger event is captured by Edge - not Level - by hardware.
	 */
	if (adcp->adc->CFG0 & (ADC_STOP_BIT | ADC_START_BIT)) {
		adcp->adc->CFG0 = 0;
		cpm_delay_us(1);
	}

	adcp->adc->CFG0 = ADC_START_BIT;
}

/**
 * @brief   Build ADC conversion group with empty channels.
 *
 * @param grpp             Pointer to an @p ADCConversionGroup object.
 * @param circular         Enable the circular buffer mode for the group.
 * @param cal_en           Enable calibration compensation for the group.
 * @param trigger_source   Specify trigger source for the group.
 * @param trigger_edge     Specify hardware trigger edge for the group.
 * @param trigger_target   Specify trigger target for the group.
 * @param end_cb           Pointer to ADC notification callback function of type
 *                         @p adccallback_t. Can be NULL.
 * @param error_cb         Pointer to ADC error callback function of type
 *                         @p adcerrorcallback_t. Can be NULL.
 */
void adc_lld_build_conversion_group(ADCConversionGroup *grpp,
                                    bool circular,
                                    bool cal_en,
                                    adc_trigger_source_t trigger_source,
                                    adc_trigger_edge_t trigger_edge,
                                    adc_trigger_target_t trigger_target,
                                    adccallback_t end_cb,
                                    adcerrorcallback_t error_cb) {

	adc_lld_clear_conversion_group(grpp);

	grpp->circular       = circular;
	grpp->cal_en         = cal_en;
	grpp->trigger.source = trigger_source;
	grpp->trigger.edge   = trigger_edge;
	grpp->trigger.target = trigger_target;
	grpp->end_cb         = end_cb;
	grpp->error_cb       = error_cb;
}

void adc_lld_clear_conversion_group(ADCConversionGroup *grpp) {

	grpp->channel_mask = 0;
	grpp->num_channels = 0;
}

/**
 * Assume data in buf already sorted well ascending.
 */
static void insert_assending(uint8_t *buf, uint32_t num, uint8_t x) {

	if (buf == 0)
		return;

	if (num == 0) {
		buf[0] = x;
		return;
	}

	uint32_t i;
	for (i = 0; i < num; i++) {
		if (x == buf[i])
			return;
		else if (x < buf[i])
			break;
	}
	uint32_t j;
	for (j = num; j > i; j--) {
		buf[j] = buf[j-1];
	}
	buf[i] = x;
}

/**
 * Assume data in buf already sorted well ascending.
 */
static void delete_assending(uint8_t *buf, uint32_t num, uint8_t x) {

	if (buf == 0)
		return;

	if (num == 0) {
		return;
	}

	uint32_t i;
	for (i = 0; i < num; i++) {
		if (x == buf[i])
			break;
	}

	for (; i < num-1; i++) {
		buf[i] = buf[i+1];
	}
}

#if defined(BR3215e)
/**
 * @brief   Convert value of register HS_PMU->WAKEUP_COMN_CFG[15:12].adckey_sel<3:0>
 *          to gpio pin number.
 *          Refer to @p adc_channel_param_t.gpio_sel for more info.
 *
 * @param gpio_sel     value of register adckey_sel<3:0>.
 * @return             GPIO pin number.
 */
uint32_t adc_gpio_sel_to_gpio_pin(uint8_t gpio_sel) {

	uint32_t gpio_pin = 0;

	if (gpio_sel >= 1 && gpio_sel <= 4)
		gpio_pin = gpio_sel + 1;
	else if (gpio_sel >= 5 && gpio_sel <= 9)
		gpio_pin = gpio_sel + 4;
	else if (gpio_sel >= 10 && gpio_sel <= 15)
		gpio_pin = gpio_sel + 6;

	return gpio_pin;
}

uint32_t adc_gpio_pin_to_gpio_sel(uint8_t gpio_pin) {

	uint32_t gpio_sel = 0;

	if (gpio_pin >= 2 && gpio_pin <= 5)
		gpio_sel = gpio_pin - 1;
	else if (gpio_pin >= 9 && gpio_pin <= 13)
		gpio_sel = gpio_pin - 4;
	else if (gpio_pin >= 16 && gpio_pin <= 21)
		gpio_sel = gpio_pin - 6;

	return gpio_sel;
}
#else
uint32_t adc_gpio_sel_to_gpio_pin(uint8_t gpio_sel) {
	(void)gpio_sel;
	return 0;
}
uint32_t adc_gpio_pin_to_gpio_sel(uint8_t gpio_pin) {
	(void)gpio_pin;
	return 0;
}
#endif


/**
 * @brief Build an @p adc_channel_param_t object.
 *
 * @param param         the channel parameter struct
 * @param inn           normally select ADC_CHANNEL_CHIP_VCM
 * @param vcm           normally select ADC_VCM_SEL_000mV
 * @param gain          normally select ADC_PGA_GAIN_1
 * @param gpio_sel      Valid only when argument @p inp is ADC_CHANNEL_EXTERN_PINx.
 * @param gpio_sel_inn   Valid only when argument @p inn is ADC_CHANNEL_EXTERN_PINx.
 *                       Specify GPIO pins for ADC_CHANNEL_EXTERN_PIN0/1/2, for BR3215e only.
 *                       Refer to @p adc_channel_param_t.gpio_sel for more info.
 */
static void adc_lld_build_channel_param(adc_channel_param_t *param,
																 adc_channel_t inn,
																 adc_vcm_t vcm,
																 adc_pga_gain_t gain,
																 uint32_t gpio_sel,
																 uint32_t gpio_sel_inn) {

	param->en_r2r         = true;   // reset value = false
	param->en_chop        = false;  // reset value = false
	param->gtune          = gain;   // reset value = ADC_PGA_GAIN_1
	param->ldoctrl        = 1;      // reset value = ADC_CTRL_LDO_2P4V
	param->sel_fchop      = 0;      // reset value = ADC_CHOPPER_FREQ_500KHZ
	param->sel_inn        = inn;    // reset value = ADC_CHANNEL_CHIP_VCM;
	param->sel_vcm        = vcm;    // reset value = ADC_VCM_SEL_625mV;
	param->en_count_sar   = true;   // reset value = true
	param->en_dem_sar     = true;   // reset value = true
	param->sar_buf        = false;  // reset value = false
	param->en_sar_ckdelay = 9;      // reset value = 9

	// added for BR3215e
	param->gpio_sel       = gpio_sel;
	param->gpio_sel_inn   = gpio_sel_inn;
}

/**
 *
 * @param grpp           Pointer to object of @p ADCConversionGroup.
 * @param inp            Positive input for ADC.
 * @param inn            Negative input for ADC.
 * @param vcm            Effective only when inp/inn equals to @p ADC_CHANNEL_CHIP_VCM.
 * @param gain           Gain selection of ADC's Pre-Gain-Amplifier (PGA).
 * @param gpio_pin_inp  Specify GPIO pin num for chn_pos of ADC_CHANNEL_EXTERN_PIN0/1/2,
 * @param gpio_pin_inn  Specify GPIO pin num for chn_neg of ADC_CHANNEL_EXTERN_PIN0/1/2,
 *                      for BR3215e only.
 *                      gpio_pin = 0 stands for NONE pin.
 *                      Pin number stands for GPIOx, which x = gpio_pin.
 *                      ADC_CHANNEL_EXTERN_PIN0: GPIOx, x = 2/3/4/5/9.
 *                      ADC_CHANNEL_EXTERN_PIN1: GPIOx, x = 10/11/12/13/16.
 *                      ADC_CHANNEL_EXTERN_PIN2: GPIOx, x = 17/18/19/20/21.
 */
int adc_lld_add_channel(ADCConversionGroup *grpp,
		                    adc_channel_t inp,
												adc_channel_t inn,
		                    adc_vcm_t vcm,
												adc_pga_gain_t gain,
												uint32_t gpio_pin_inp,
												uint32_t gpio_pin_inn) {

	if (inp >= ADC_CHANNEL_NUM || inn >= ADC_CHANNEL_NUM)
		return -1;

#if !defined(BR3215e)
	/**
	 * GPIO pins are internally fixed for BR3215, BR3215c, except BR3215e.
	 */
	gpio_pin_inp = (inp >= ADC_CHANNEL_EXTERN_PIN0 && inp < ADC_CHANNEL_PEAK_DETECTOR) ? inp - 2 : 0;
	gpio_pin_inn = (inn >= ADC_CHANNEL_EXTERN_PIN0 && inn < ADC_CHANNEL_PEAK_DETECTOR) ? inn - 2 : 0;
#endif

	adc_channel_param_t *param = &grpp->channel_param[inp];
	adc_lld_build_channel_param(param, inn, vcm, gain,
			adc_gpio_pin_to_gpio_sel(gpio_pin_inp), adc_gpio_pin_to_gpio_sel(gpio_pin_inn));
	if (!__is_channel_in_group(grpp, inp)) {
		grpp->channel_mask |= (1u<<inp);
		grpp->channel[grpp->num_channels] = inp;
		insert_assending(grpp->channel, grpp->num_channels, inp);
		grpp->num_channels++;
	}
	return grpp->num_channels;
}

int adc_lld_delete_channel(ADCConversionGroup *grpp, adc_channel_t chn) {

	if (chn >= ADC_CHANNEL_NUM)
		return -1;

	if (__is_channel_in_group(grpp, chn)) {
		grpp->channel_mask &= ~(1u<<chn);
		delete_assending(grpp->channel, grpp->num_channels, chn);
		grpp->num_channels--;
	}
	return grpp->num_channels;
}

int adc_lld_add_channel_temperature(ADCConversionGroup *grpp) {

	return adc_lld_add_channel(grpp,
			                ADC_CHANNEL_CHIP_TEMPERATURE,
			                ADC_CHANNEL_CHIP_VCM,
			                ADC_VCM_SEL_000mV,
			                ADC_PGA_GAIN_1,
			                0, 0);
}

int adc_lld_add_channel_battery(ADCConversionGroup *grpp) {

	return adc_lld_add_channel(grpp,
			                ADC_CHANNEL_CHIP_BATTERY,
			                ADC_CHANNEL_CHIP_VCM,
			                ADC_VCM_SEL_000mV,
			                ADC_PGA_GAIN_0P5,
			                0, 0);
}

/**
 * @brief   Set ADC test data.
 * @param val   the value to be set.
 */
void adc_lld_set_test_data(ADCDriver *adcp, uint32_t val) {

	__adc_set_bitsval(adcp->adc->TEST_DATA, 0, 9, (val));
}

/**
 * @param x
 * @param n   fractional bits of the fixed-point format.
 */
int32_t float_to_fixed(float x, int n) {

	int32_t y = 0;
	x = x * (1<<n);
	y = (int32_t)x;
	return y;
}

/**
 * @brief   Convert fixed-point data in Qm.n format to floating-point.
 *
 * @param x    fixed-point data in Qm.n format to be converted.
 * @param m    integral bits of x.
 * @param n    fractional bits of x.
 * @retval     floating-point data.
 */
float fixed_to_float(int32_t x, int m, int n) {

	float y = (m+n == 31) ? (float)x : (float)sign_extension(x, m+n);
	y = y / (1<<n);
	return y;
}

/**
 * @brief  Convert fixed-point data in Q4.11 format to floating-point.
 *
 * @param x    fixed-point data in Q4.11 format to be converted.
 * @retval     floating-point data.
 */
float adc_data_q2f(adcsample_t x) {

	return fixed_to_float(x, sizeof(adcsample_t)*8-ADC_Q-1, ADC_Q);
}

/**
 * Fixed-point operations:
 * From www.wikipedia.org, item = Q (number format).
 *
 * Assume all int16_t numbers following are in Q4.11 format,
 * and all int32_t numbers are in Q20.11 format.
 *
 * Following operations are for 16-bit fixed-point arguments, not 32-bit arguments,
 * otherwise the result may overflow.
 */

/**
 * @brief   Multiplication of fixed-point numbers in format of Q20.11.
 *
 * @note    Argument a and b must be small enough not to cause the result to
 *          overflow.
 *
 * @param a   fixed-point data in format of Q20.11.
 * @param b   fixed-point data in format of Q20.11.
 * @retval    fixed-point data in format of Q20.11.
 */
int32_t adc_data_qmul(int32_t a, int32_t b) {

	int32_t result = (int32_t)a * (int32_t)b; // result type is operand's type
	// Rounding; mid values are rounded up
	result += (1 << (ADC_Q - 1));
	result >>= ADC_Q; //Q: fraction bits
	return result;
}

/**
 * @brief   Division of fixed-point numbers in format of Q20.11.
 *
 * @note    Argument a and b must be small enough not to cause the result to
 *          overflow.
 *
 * @param a   fixed-point data in format of Q20.11.
 * @param b   fixed-point data in format of Q20.11.
 * @retval    fixed-point data in format of Q20.11.
 */
int32_t adc_data_qdiv(int32_t a, int32_t b) {

	// pre-multiply by the base (Upscale to Q16 so that the result will be in Q8 format)
	int32_t result = (int32_t)a << ADC_Q;
	// Rounding; mid values are rounded up
	if ((result >= 0 && b >= 0) || (result < 0 && b < 0))
		// OR compare most significant bits ie. if ((result >> 31) & 1 == (result >> 15) & 1) {
		result += b / 2;   // OR shift 1 bit ie. result += (b >> 1);
	else
		result -= b / 2;   // OR shift 1 bit ie. result -= (b >> 1);
	result = result / b;

	return result;
}

// end of fixed-point operations.

/**
 * @brief Get calibration parameters from calibration table.
 *
 * @note  The calibration table is stored at a fixed position in Flash during
 *        FT test.
 *
 * @param param             Pointer to where the returned parameters is to be
 *                          stored.
 * @param table             Pointer to the calibration table.
 * @param is_differential   The parameters to get is for differential or not.
 * @param gain              The PGA gain corresponding to the parameters to be
 *                          returned.
 */
void adc_lld_get_cal_param_from_table(adc_cal_param_t *param,
		                                  adc_cal_table_t *table,
		                                  bool is_differential,
		                                  adc_pga_gain_t gain) {

#if defined(BR3215)
	is_differential = false;
	gain = ADC_PGA_GAIN_0P5;
#endif

	switch (gain) {
	case ADC_PGA_GAIN_0P5:
		param->vos_mod  = is_differential ? table->d_vos_mod_0  : table->s_vos_mod_0;
		param->gain_mod = is_differential ? table->d_gain_mod_0 : table->s_gain_mod_0;
		param->vcm_mod  = is_differential ? 0x0800              : table->s_vcm_mod_0;
		break;
	case ADC_PGA_GAIN_1:
		param->vos_mod  = is_differential ? table->d_vos_mod_1  : table->s_vos_mod_1;
		param->gain_mod = is_differential ? table->d_gain_mod_1 : table->s_gain_mod_1;
		param->vcm_mod  = is_differential ? 0x0800              : table->s_vcm_mod_1;
		break;
	case ADC_PGA_GAIN_2:
		param->vos_mod  = is_differential ? table->d_vos_mod_2  : table->s_vos_mod_2;
		param->gain_mod = is_differential ? table->d_gain_mod_2 : table->s_gain_mod_2;
		param->vcm_mod  = is_differential ? 0x0800              : table->s_vcm_mod_2;
		break;
	case ADC_PGA_GAIN_4:
		param->vos_mod  = is_differential ? table->d_vos_mod_3  : table->s_vos_mod_3;
		param->gain_mod = is_differential ? table->d_gain_mod_3 : table->s_gain_mod_3;
		param->vcm_mod  = is_differential ? 0x0800              : table->s_vcm_mod_3;
		break;
	default:
		param->vos_mod  = 0x0000;
		param->gain_mod = 0x0800;
		param->vcm_mod  = 0x0800;
		break;
	}
}

#endif /* HAL_USE_ADC */

/** @} */
