/*
    ChibiOS - Copyright (C) 2006..2017 Giovanni Di Sirio
              Copyright (C) 2015..2017 Diego Ismirlian, (dismirlian (at) google's mail)
              

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

#include "hal.h"

#if HAL_USE_USBH
#include "usbh/internal.h"
#include <string.h>

#if USBH_LLD_DEBUG_ENABLE_TRACE
#define udbgf(f, ...)  usbDbgPrintf(f, ##__VA_ARGS__)
#define udbg(f, ...)  usbDbgPuts(f, ##__VA_ARGS__)
#else
#define udbgf(f, ...)  do {} while(0)
#define udbg(f, ...)   do {} while(0)
#endif

#if USBH_LLD_DEBUG_ENABLE_INFO
#define uinfof(f, ...)  usbDbgPrintf(f, ##__VA_ARGS__)
#define uinfo(f, ...)  usbDbgPuts(f, ##__VA_ARGS__)
#else
#define uinfof(f, ...)  do {} while(0)
#define uinfo(f, ...)   do {} while(0)
#endif

#if USBH_LLD_DEBUG_ENABLE_WARNINGS
#define uwarnf(f, ...)  usbDbgPrintf(f, ##__VA_ARGS__)
#define uwarn(f, ...)  usbDbgPuts(f, ##__VA_ARGS__)
#else
#define uwarnf(f, ...)  do {} while(0)
#define uwarn(f, ...)   do {} while(0)
#endif

#if USBH_LLD_DEBUG_ENABLE_ERRORS
#define uerrf(f, ...)  usbDbgPrintf(f, ##__VA_ARGS__)
#define uerr(f, ...)   usbDbgPuts(f, ##__VA_ARGS__)
#else
#define uerrf(f, ...)  do {} while(0)
#define uerr(f, ...)   do {} while(0)
#endif

static void _transfer_completedI(usbh_ep_t *ep, usbh_urb_t *urb, usbh_urbstatus_t status);
static void _try_commit_np(USBHDriver *host);

#if HS_USB_USE_USB0
USBHDriver USBHD0;
#endif

/*===========================================================================*/
/* Little helper functions.                                                  */
/*===========================================================================*/
/**
 * @brief   Allocates a block from the FIFO RAM memory.
 *
 * @param[in] host      pointer to the @p USBHDriver object
 * @param[in] epp       pointer to the @p usbh_ep_t endpoint
 * @param[in] dpb       double packet buffering if 1
 *
 * @notapi
 */
static void _usbh_alloc_ep(USBHDriver *host, usbh_ep_t *epp, uint8_t dpb)
{
  uint16_t addr, fifo_setup;
  uint8_t epnum = epp->address;

  addr = host->ramnext;
  host->ramnext += epp->wMaxPacketSize * (dpb + 1);
  osalDbgAssert(host->ramnext <= HS_USB_FIFO_SIZE,
                "FIFO memory overflow");
  fifo_setup = USB_FIFO_SZ(epp->wMaxPacketSize) | USB_FIFO_DPB(dpb) | USB_FIFO_AD(addr);

  HS_USB->INDEX = epnum;
  if (0 == epnum) {
    HS_USB->TXFIFO = fifo_setup;
    HS_USB->RXFIFO = fifo_setup;
    HS_USB->NAKLIMIT0 = 255;
    HS_USB->INTR_RXEN = 0;
    HS_USB->INTR_TXEN = (1 << epnum);
  }
  else {
    if (epp->in) {
      HS_USB->RXFIFO = fifo_setup;
      HS_USB->RXTYPE = USB_TYPE_PROTOCOL(epp->type) | USB_TYPE_EP(epnum);
      HS_USB->RXMAXP = epp->wMaxPacketSize >> 3;
      HS_USB->RXCSR = USB_RXCSR_H_CLRDATATOG;
      if (USBH_EPTYPE_BULK == epp->type) {
        /* Netac reports RXCSR_H_NAKTIMEOUT when scsi_requestsense() if 255 is set */
        HS_USB->RXNAKLIMIT = 0;//255;
      }
      else {
        HS_USB->RXINTERVAL = epp->bInterval;
      }
      HS_USB->INTR_RXEN |= (1 << epnum);
    }
    else {
      HS_USB->TXFIFO = fifo_setup;
      HS_USB->TXTYPE = USB_TYPE_PROTOCOL(epp->type) | USB_TYPE_EP(epnum);
      HS_USB->TXMAXP = epp->wMaxPacketSize >> 3;
      HS_USB->TXCSR = USB_TXCSR_H_CLRDATATOG;
      if (USBH_EPTYPE_BULK == epp->type) {
        HS_USB->TXNAKLIMIT = 0;//255;
      }
      else {
        HS_USB->TXINTERVAL = epp->bInterval;
      }
      HS_USB->INTR_TXEN |= (1 << epnum);
    }
  }
  osalDbgAssert(epnum <= HS_USB_NUM_ENDPOINTS, "EP number overflow");
  if (epp->in) udbgf("%d: rxfifo=%x rxtype=%x rxmaxp=%x rxcsr=%x rxen=%x", epnum, HS_USB->RXFIFO, HS_USB->RXTYPE, HS_USB->RXMAXP, HS_USB->RXCSR, HS_USB->INTR_RXEN);
  else udbgf("%d: txfifo=%x txtype=%x txmaxp=%x txcsr=%x txen=%x", epnum, HS_USB->TXFIFO, HS_USB->TXTYPE, HS_USB->TXMAXP, HS_USB->TXCSR, HS_USB->INTR_TXEN);
}

static void _usbh_free_ep(USBHDriver *host, usbh_ep_t *epp)
{
  (void)host;
  uint8_t epnum = epp->address;
  if (0 == epnum) {
    HS_USB->INTR_TXEN &= ~(1 << epnum);
  }
  else {
    if (epp->in) {
      HS_USB->INTR_RXEN &= ~(1 << epnum);
    }
    else {
      HS_USB->INTR_TXEN &= ~(1 << epnum);
    }
  }
}

static size_t _usbh_write_fifo(uint8_t epnum, uint8_t *buf, size_t n)
{
  syssts_t sts;
  volatile uint32_t *txfifo = (volatile uint32_t *)&HS_USB->EPnFIFO[epnum];
  uint32_t *src = (uint32_t *)buf;
  uint16_t words = n >> 2;
  uint8_t  bytes = n;

  if (n == 0) {
    return 0;
  }

  /* Must lock for entire operation to ensure nothing changes the ENUM value */
  sts = osalSysGetStatusAndLockX();
  HS_USB->INDEX = epnum;
  if (bytes & 3) {
    volatile uint8_t *bdst = (volatile uint8_t *)txfifo;
    uint8_t *bsrc = (uint8_t *)src;
    while (bytes--) {
      *bdst = *bsrc++;
    }
  }
  else {
    while (words--) {
      *txfifo = *src++;
    }
  }

  if (0 == epnum) {
    HS_USB->CSR0 |= USB_CSR0_H_SETUPPKT | USB_CSR0_H_TXPKTRDY;
  }
  else {
    HS_USB->TXCSR |= USB_TXCSR_H_TXPKTRDY;
  }
  osalSysRestoreStatusX(sts);
  return n;
}

static size_t _usbh_read_fifo(uint8_t epnum, uint8_t *buf, size_t n)
{
  syssts_t sts;
  volatile uint32_t *rxfifo = (volatile uint32_t *)&HS_USB->EPnFIFO[epnum];
  uint32_t *dst = (uint32_t *)buf;
  uint16_t words = n >> 2;
  uint8_t  bytes = n;

  if (n == 0)
    return 0;

  /* Must lock for entire operation to ensure nothing changes the ENUM value */
  sts = osalSysGetStatusAndLockX();
  HS_USB->INDEX = epnum;
  #if 1
  if ((bytes & 3) || ((uint32_t)dst & 3)) {
    volatile uint8_t *bsrc = (volatile uint8_t *)rxfifo;
    uint8_t *bdst = (uint8_t *)dst;
    while (bytes--) {
      *bdst++ = *bsrc;
    }
  }
  else {
    while (words--) {
      *dst++ = *rxfifo;
    }
  }
  #else
  if ((uint32_t)dst & 3) {
    uint32_t data;
    while (words--) {
      data = *rxfifo;
      memcpy(dst, &data, 4);
      dst++;
    }
  }
  else {
    while (words--) {
      *dst++ = *rxfifo;
    }
  }
  bytes = n & 3;
  if (bytes) {
    uint32_t r = *rxfifo;
    uint8_t *bsrc = (uint8_t *)&r;
    uint8_t *bdst = (uint8_t *)dst;
    do {
      *bdst++ = *bsrc++;
    } while (--bytes);
  }
  #endif

  if (0 == epnum) {
    HS_USB->CSR0 &= ~USB_CSR0_H_RXPKTRDY;
  }
  else {
    HS_USB->RXCSR &= ~USB_RXCSR_H_RXPKTRDY;
  }
  osalSysRestoreStatusX(sts);

  return n;
}

static inline bool _usbh_is_connected(USBHDriver *host) {
  return host->rootport.lld_status & USBH_PORTSTATUS_C_CONNECTION ? true : false;
}

static inline void _move_to_pending_queue(usbh_ep_t *ep) {
	list_move_tail(&ep->node, ep->pending_list);
}

static inline usbh_urb_t *_active_urb(usbh_ep_t *ep) {
	return list_first_entry(&ep->urb_list, usbh_urb_t, node);
}

static inline void _save_dt_mask(usbh_ep_t *ep, uint32_t hctsiz) {
  (void)ep;
  (void)hctsiz;
  //ep->dt_mask = hctsiz & HCTSIZ_DPID_MASK;
}

/*===========================================================================*/
/* Functions called from many places.                                        */
/*===========================================================================*/
static void _transfer_completedI(usbh_ep_t *ep, usbh_urb_t *urb, usbh_urbstatus_t status) {
	osalDbgCheckClassI();

	urb->queued = FALSE;

	/* remove URB from EP's queue */
	list_del_init(&urb->node);

	/* Call the callback function now, so that if it calls usbhURBSubmitI,
	 * the list_empty check below will be false. Also, note that the
	 *   if (list_empty(&ep->node)) {
	 *     ...
	 *   }
	 * in usbh_lld_urb_submit will be false, since the endpoint is
	 * still in the active queue.
	 */
	_usbh_urb_completeI(urb, status);

	if (list_empty(&ep->urb_list)) {
		/* no more URBs to process in this EP, remove EP from the host's queue */
		list_del_init(&ep->node);
	} else {
		/* more URBs to process */
		_move_to_pending_queue(ep);
	}
}

static void _halt_channel(USBHDriver *host, hs_hc_management_t *hcm, usbh_lld_halt_reason_t reason) {
  (void)host;

  if (hcm->halt_reason != USBH_LLD_HALTREASON_NONE) {
    uwarnf("\t%s: Repeated halt (original=%d, new=%d)", hcm->ep->name, hcm->halt_reason, reason);
    return;
  }

#if CH_DBG_ENABLE_CHECKS
  if (0 != HS_USB->INDEX) {
    /* FIFOs will be flushed */
    //osalDbgCheck(0 == (HS_USB->TXCSR & USB_TXCSR_H_FIFONOTEMPTY));
  }
#endif

  hcm->halt_reason = reason;
}

static void _release_channel(USBHDriver *host, hs_hc_management_t *hcm) {
//	static const char *reason[] =  {"XFRC",	"XFRC",	"NAK", "STALL",	"ERROR", "ABORT"};
//	udbgf("\t%s: release (%s)", hcm->ep->name, reason[hcm->halt_reason]);
  hcm->halt_reason = USBH_LLD_HALTREASON_NONE;
  /* TBD: usbhEPIsPeriodic(hcm->ep) */
  list_add(&hcm->node, &host->ch_free[0]);
  hcm->ep->xfer.hcm = 0;
  hcm->ep = 0;
}

static bool _activate_ep(USBHDriver *host, usbh_ep_t *ep) {
  struct list_head *list;
  uint16_t spc;

  //if (0!=ep->address) udbgf("%s:%d type=%x in=%x address=%x", __FUNCTION__, __LINE__, ep->type, ep->in, ep->address);
  osalDbgCheck(ep->xfer.hcm == NULL);

  /* TBD: usbhEPIsPeriodic(ep) */
  list = &host->ch_free[0];
  if (USBH_EPTYPE_CTRL == ep->type) {
    /* EP0's FIFO size is always 64-byte */
    spc = 64;
  }
  else {
    spc = ep->wMaxPacketSize;
  }

  if (list_empty(list)) {
    uwarnf("\t%s: No free %s channels", ep->name, usbhEPIsPeriodic(ep) ? "P" : "NP");
    return FALSE;
  }

  /* get the first channel */
  hs_hc_management_t *hcm = list_first_entry(list, hs_hc_management_t, node);
  osalDbgCheck((hcm->halt_reason == USBH_LLD_HALTREASON_NONE) && (hcm->ep == NULL));

  usbh_urb_t *const urb = _active_urb(ep);
  //uint32_t hcintmsk = ep->hcintmsk;
  //uint32_t hcchar = ep->hcchar;
  uint16_t mps = ep->wMaxPacketSize;

  uint32_t xfer_packets;
  uint32_t xfer_len = 0;	//Initialize just to shut up a compiler warning

  osalDbgCheck(urb->status == USBH_URBSTATUS_PENDING);
  if (spc < mps) {
    uwarnf("\t%s: No space in %s Queue (spc=%d)", ep->name, usbhEPIsPeriodic(ep) ? "P" : "NP", spc);
    return FALSE;
  }

  /* check if the URB is a new one, or we must continue a previously started URB */
  //udbgf("queued=%d type=%d reqlen=%d actlen=%d\n", urb->queued, ep->type, urb->requestedLength, urb->actualLength);
  if (urb->queued == FALSE) {
    /* prepare EP for a new URB */
    if (ep->type == USBH_EPTYPE_CTRL) {
      xfer_len = 8;
      ep->xfer.buf = (uint8_t *)urb->setup_buff;
      //ep->dt_mask = HCTSIZ_DPID_SETUP;
      //luwei
      //int ii;for(ii=0; ii<8; ii++) printf("%02x ", *((uint8_t *)urb->setup_buff+ii)); printf("\n");
      _usbh_write_fifo(0, ep->xfer.buf, xfer_len);
      ep->in = FALSE;
      ep->xfer.u.ctrl_phase = USBH_LLD_CTRLPHASE_SETUP;
    } else {
      xfer_len = urb->requestedLength;
      if (xfer_len > mps) {
        xfer_len = mps;
      }
      ep->xfer.buf = urb->buff;
      if (ep->in) {
        HS_USB->INDEX = ep->address;
        HS_USB->RXCSR = USB_RXCSR_H_REQPKT;
      }
      else {
        _usbh_write_fifo(ep->address, ep->xfer.buf, xfer_len);
      }
    }
    ep->xfer.error_count = 0;
  } else {
    osalDbgCheck(urb->requestedLength >= urb->actualLength);

    if (ep->type == USBH_EPTYPE_CTRL) {
      switch (ep->xfer.u.ctrl_phase) {
      case USBH_LLD_CTRLPHASE_SETUP:
        xfer_len = 8;
        ep->xfer.buf = (uint8_t *)urb->setup_buff;
        //ep->dt_mask = HCTSIZ_DPID_SETUP;
        break;
      case USBH_LLD_CTRLPHASE_DATA:
        xfer_len = urb->requestedLength - urb->actualLength;
        ep->xfer.buf = (uint8_t *) urb->buff + urb->actualLength;
        break;
      case USBH_LLD_CTRLPHASE_STATUS:
        xfer_len = 0;
        //ep->dt_mask = HCTSIZ_DPID_DATA1;
        ep->xfer.error_count = 0;
        break;
      default:
        osalDbgCheck(0);
      }
      if (ep->in) {
        //hcintmsk |= HCINTMSK_DTERRM | HCINTMSK_BBERRM;
        //hcchar |= HCCHAR_EPDIR;
      }
    } else {
      xfer_len = urb->requestedLength - urb->actualLength;
      ep->xfer.buf = (uint8_t *) urb->buff + urb->actualLength;
    }

    //if (ep->xfer.error_count)
      //hcintmsk |= HCINTMSK_ACKM;
  }
  ep->xfer.partial = 0;

  if (ep->type == USBH_EPTYPE_ISO) {
    //ep->dt_mask = HCTSIZ_DPID_DATA0;

    /* [USB 2.0 spec, 5.6.4]: A host must not issue more than 1
     * transaction in a (micro)frame for an isochronous endpoint
     * unless the endpoint is high-speed, high-bandwidth.
     */
    if (xfer_len > mps)
      xfer_len = mps;
  } else if (xfer_len > 0x7FFFF) {
    xfer_len = 0x7FFFF - mps + 1;
  }

  /* calculate required packets */
  if (xfer_len) {
    xfer_packets = (xfer_len + mps - 1) / mps;

    if (xfer_packets > 0x3FF) {
      xfer_packets = 0x3FF;
      xfer_len = xfer_packets * mps;
    }
  } else {
    xfer_packets = 1;	/* Need 1 packet for transfer length of 0 */
  }

#if 0
  if (ep->in)
    xfer_len = xfer_packets * mps;

  /* Clear old interrupt conditions,
   * configure transfer size,
   * enable required interrupts */
  hc->HCINT = 0xffffffff;
  hc->HCTSIZ = ep->dt_mask
    | HCTSIZ_PKTCNT(xfer_packets)
    | HCTSIZ_XFRSIZ(xfer_len);
  hc->HCINTMSK = hcintmsk;

  /* Queue the transfer for the next frame (no effect for non-periodic transfers) */
  if (!(host->otg->HFNUM & 1))
    hcchar |= HCCHAR_ODDFRM;

  /* configure channel characteristics and queue a request */
  hc->HCCHAR = hcchar;
  if (ep->in && (xfer_packets > 1)) {
    /* For IN transfers, try to queue two back-to-back packets.
     * This results in a 1% performance gain for Full Speed transfers
     */
    if (--spc > STM32_USBH_MIN_QSPACE) {
      hc->HCCHAR |= HCCHAR_CHENA;
    } else {
      uwarnf("\t%s: Could not queue back-to-back packets", ep->name);
    }
  }
#endif

  if (urb->queued == FALSE) {
    urb->queued = TRUE;
    udbgf("\t%s: Start (%dB)", ep->name, urb->requestedLength);
  } else {
    udbgf("\t%s: Restart (%dB)", ep->name, xfer_len);
  }

  ep->xfer.len = xfer_len;
  ep->xfer.packets = (uint16_t)xfer_packets;

  /* remove the channel from the free list, link endpoint <-> channel and move to the active queue*/
  list_del(&hcm->node);
  ep->xfer.hcm = hcm;
  hcm->ep = ep;
  list_move_tail(&ep->node, ep->active_list);

#if 0
  /* enable this channel's interrupt and global channel interrupt */
  otg->HAINTMSK |= hcm->haintmsk;
  if (ep->in) {
    otg->GINTMSK |= GINTMSK_HCM;
  } else if (usbhEPIsPeriodic(ep)) {
    otg->GINTMSK |= GINTMSK_HCM | GINTMSK_PTXFEM;
  } else {
    //TODO: write to the FIFO now
    otg->GINTMSK |= GINTMSK_HCM | GINTMSK_NPTXFEM;
  }
#endif

  return TRUE;
}

static bool _update_urb(usbh_ep_t *ep, uint32_t len, usbh_urb_t *urb) {
  //if (ep->address) udbgf("in=%d len=%d act=%d req=%d buf=%x", ep->in, len, urb->actualLength, urb->requestedLength, urb->buff);
  if (urb->actualLength + len > urb->requestedLength) {
    uerrf("\t%s: Trimming actualLength %u -> %u", ep->name, urb->actualLength + len, urb->requestedLength);
    urb->actualLength = urb->requestedLength;
    return TRUE;
  }

  urb->actualLength += len;
  if (USBH_EPTYPE_CTRL == ep->type) {
    return TRUE;
  }
  if (urb->actualLength == urb->requestedLength) {
    return TRUE;
  }

  return FALSE;
}

static void _try_commit_np(USBHDriver *host) {
  usbh_ep_t *item, *tmp;

  list_for_each_entry_safe(item, usbh_ep_t, tmp, &host->ep_pending_lists[USBH_EPTYPE_CTRL], node) {
    if (!_activate_ep(host, item))
      return;
  }

  list_for_each_entry_safe(item, usbh_ep_t, tmp, &host->ep_pending_lists[USBH_EPTYPE_BULK], node) {
    if (!_activate_ep(host, item))
      return;
  }
}

static void _try_commit_p(USBHDriver *host, bool sof) {
	usbh_ep_t *item, *tmp;

	list_for_each_entry_safe(item, usbh_ep_t, tmp, &host->ep_pending_lists[USBH_EPTYPE_ISO], node) {
		if (!_activate_ep(host, item))
			return;
	}

	list_for_each_entry_safe(item, usbh_ep_t, tmp, &host->ep_pending_lists[USBH_EPTYPE_INT], node) {
		osalDbgCheck(item);
		/* TODO: improve this */
		if (sof && item->xfer.u.frame_counter)
			--item->xfer.u.frame_counter;

		if (item->xfer.u.frame_counter == 0) {
			if (!_activate_ep(host, item))
				return;
			item->xfer.u.frame_counter = item->bInterval;
		}
	}

	if (list_empty(&host->ep_pending_lists[USBH_EPTYPE_ISO])
		&& list_empty(&host->ep_pending_lists[USBH_EPTYPE_INT])) {
      //host->otg->GINTMSK &= ~GINTMSK_SOFM;
	} else {
      //host->otg->GINTMSK |= GINTMSK_SOFM;
	}
}

static void _purge_queue(USBHDriver *host, struct list_head *list) {
	usbh_ep_t *ep, *tmp;
	list_for_each_entry_safe(ep, usbh_ep_t, tmp, list, node) {
		usbh_urb_t *const urb = _active_urb(ep);
		hs_hc_management_t *const hcm = ep->xfer.hcm;
		uwarnf("\t%s: Abort URB, USBH_URBSTATUS_DISCONNECTED", ep->name);
		if (hcm) {
			uwarnf("\t%s: URB had channel %d assigned, halt_reason = %d", ep->name, hcm - host->channels, hcm->halt_reason);
			_release_channel(host, hcm);
			_update_urb(ep, 0, urb);
		}
		_transfer_completedI(ep, urb, USBH_URBSTATUS_DISCONNECTED);
	}
}

static void _purge_active(USBHDriver *host) {
	_purge_queue(host, &host->ep_active_lists[0]);
	_purge_queue(host, &host->ep_active_lists[1]);
	_purge_queue(host, &host->ep_active_lists[2]);
	_purge_queue(host, &host->ep_active_lists[3]);
}

static void _purge_pending(USBHDriver *host) {
	_purge_queue(host, &host->ep_pending_lists[0]);
	_purge_queue(host, &host->ep_pending_lists[1]);
	_purge_queue(host, &host->ep_pending_lists[2]);
	_purge_queue(host, &host->ep_pending_lists[3]);
}


/*===========================================================================*/
/* API.                                                                      */
/*===========================================================================*/

void usbh_lld_ep_object_init(usbh_ep_t *ep) {
/*			CTRL(IN)	CTRL(OUT)	INT(IN)		INT(OUT)	BULK(IN)	BULK(OUT)	ISO(IN)		ISO(OUT)
 * STALL		si		solo DAT/STAT	si			si			si			si			no			no		ep->type != ISO && (ep->type != CTRL || ctrlphase != SETUP)
 * ACK			si			si			si			si			si			si			no			no		ep->type != ISO
 * NAK			si			si			si			si			si			si			no			no		ep->type != ISO
 * BBERR		si			no			si			no			si			no			si			no		ep->in
 * TRERR		si			si			si			si			si			si			si			no		ep->type != ISO || ep->in
 * DTERR		si			no			si			no			si			no			no			no		ep->type != ISO && ep->in
 * FRMOR		no			no			si			si			no			no			si			si		ep->type = PERIODIC
 */
  USBHDriver *host = ep->device->host;
  //uint32_t hcintmsk = HCINTMSK_CHHM | HCINTMSK_XFRCM | HCINTMSK_AHBERRM;

  switch (ep->type) {
  case USBH_EPTYPE_ISO:
    #if 0
    hcintmsk |= HCINTMSK_FRMORM;
    if (ep->in) {
      hcintmsk |= HCINTMSK_TRERRM | HCINTMSK_BBERRM;
    }
    #endif
    break;
  case USBH_EPTYPE_INT:
    #if 0
    hcintmsk |= HCINTMSK_TRERRM | HCINTMSK_FRMORM | HCINTMSK_STALLM | HCINTMSK_NAKM;
    if (ep->in) {
      hcintmsk |= HCINTMSK_DTERRM | HCINTMSK_BBERRM;
    }
    #endif
    ep->xfer.u.frame_counter = 1;
    break;
  case USBH_EPTYPE_CTRL:
    #if 0
    hcintmsk |= HCINTMSK_TRERRM | HCINTMSK_STALLM | HCINTMSK_NAKM;
    #endif
    break;
  case USBH_EPTYPE_BULK:
    #if 0
    hcintmsk |= HCINTMSK_TRERRM | HCINTMSK_STALLM | HCINTMSK_NAKM;
    if (ep->in) {
      hcintmsk |= HCINTMSK_DTERRM | HCINTMSK_BBERRM;
    }
    #endif
    break;
  default:
    chDbgCheck(0);
  }
  ep->active_list = &host->ep_active_lists[ep->type];
  ep->pending_list = &host->ep_pending_lists[ep->type];
  INIT_LIST_HEAD(&ep->urb_list);
  INIT_LIST_HEAD(&ep->node);

  #if 0
  ep->hcintmsk = hcintmsk;
  ep->hcchar = HCCHAR_CHENA
    | HCCHAR_DAD(ep->device->address)
    | HCCHAR_MCNT(1)
    | HCCHAR_EPTYP(ep->type)
    | ((ep->device->speed == USBH_DEVSPEED_LOW) ? HCCHAR_LSDEV : 0)
    | (ep->in ? HCCHAR_EPDIR : 0)
    | HCCHAR_EPNUM(ep->address)
    | HCCHAR_MPS(ep->wMaxPacketSize);
  #endif
}

void usbh_lld_ep_open(usbh_ep_t *ep) {
  uinfof("\t%s: Open EP 0x%02x", ep->name, ep->address);
  ep->status = USBH_EPSTATUS_OPEN;
  _usbh_alloc_ep(&USBHD0, ep, 0/*dpb*/);
}

void usbh_lld_ep_close(usbh_ep_t *ep) {
  usbh_urb_t *urb, *tmp;
  uinfof("\t%s: Closing EP...", ep->name);
  list_for_each_entry_safe(urb, usbh_urb_t, tmp, &ep->urb_list, node) {
    uinfof("\t%s: Abort URB, USBH_URBSTATUS_DISCONNECTED", ep->name);
    _usbh_urb_abort_and_waitS(urb, USBH_URBSTATUS_DISCONNECTED);
  }
  uinfof("\t%s: Closed", ep->name);
  ep->status = USBH_EPSTATUS_CLOSED;
  _usbh_free_ep(&USBHD0, ep);
}

bool usbh_lld_ep_reset(usbh_ep_t *ep) {
  (void)ep;
  //ep->dt_mask = HCTSIZ_DPID_DATA0;
  return TRUE;
}

void usbh_lld_urb_submit(usbh_urb_t *urb) {
  usbh_ep_t *const ep = urb->ep;
  USBHDriver *const host = ep->device->host;

  /* don't submit URB if disconnected, otherwise usbh_lld_urb_abort() will return false, then caller will suspend for ever */
  if (!_usbh_is_connected(host)) {
    uwarnf("\t%s: Can't submit URB, port disabled", ep->name);
    _usbh_urb_completeI(urb, USBH_URBSTATUS_DISCONNECTED);
    return;
  }

  /* add the URB to the EP's queue */
  list_add_tail(&urb->node, &ep->urb_list);

  /* check if the EP wasn't in any queue (pending nor active) */
  if (list_empty(&ep->node)) {

    /* add the EP to the pending queue */
    _move_to_pending_queue(ep);

    if (usbhEPIsPeriodic(ep)) {
      //host->otg->GINTMSK |= GINTMSK_SOFM;
    } else {
      /* try to queue non-periodic transfers */
      _try_commit_np(ep->device->host);
    }
  }
}

/* usbh_lld_urb_abort may require a reschedule if called from a S-locked state */
bool usbh_lld_urb_abort(usbh_urb_t *urb, usbh_urbstatus_t status) {
	osalDbgCheck(usbhURBIsBusy(urb));

	usbh_ep_t *const ep = urb->ep;
	osalDbgCheck(ep);
	hs_hc_management_t *const hcm = ep->xfer.hcm;

	if ((hcm != NULL) && (urb == _active_urb(ep))) {
		/* This URB is active (channel assigned, top of the EP's URB list) */

		if (hcm->halt_reason == USBH_LLD_HALTREASON_NONE) {
			/* The channel is not being halted */
			uinfof("\t%s: usbh_lld_urb_abort: channel is not being halted", hcm->ep->name);
			urb->status = status;
			_halt_channel(ep->device->host, hcm, USBH_LLD_HALTREASON_ABORT);
		} else {
			/* The channel is being halted, so we can't re-halt it. The CHH interrupt will
			 * be in charge of completing the transfer, but the URB will not have the specified status.
			 */
			uinfof("\t%s: usbh_lld_urb_abort: channel is being halted", hcm->ep->name);
		}
		return FALSE;
	}

	/* This URB is inactive, we can cancel it now */
	uinfof("\t%s: usbh_lld_urb_abort: URB is not active", ep->name);
	_transfer_completedI(ep, urb, status);

	return TRUE;
}


/*===========================================================================*/
/* Channel Interrupts.                                                       */
/*===========================================================================*/

//CTRL(IN)	CTRL(OUT)	INT(IN)		INT(OUT)	BULK(IN)	BULK(OUT)	ISO(IN)		ISO(OUT)
//	si			si			si			si			si			si			no			no		ep->type != ISO && !ep->in
static inline void _ack_int(USBHDriver *host, hs_hc_management_t *hcm) {
  (void)host;
  osalDbgAssert(hcm->ep->type != USBH_EPTYPE_ISO, "ACK should not happen in ISO endpoints");
  hcm->ep->xfer.error_count = 0;
  //hc->HCINTMSK &= ~HCINTMSK_ACKM;
  udbgf("\t%s: ACK", hcm->ep->name);
}

//CTRL(IN)	CTRL(OUT)	INT(IN)		INT(OUT)	BULK(IN)	BULK(OUT)	ISO(IN)		ISO(OUT)
//	si			no			si			no			si			no			no			no		ep->type != ISO && ep->in
static inline void _dterr_int(USBHDriver *host, hs_hc_management_t *hcm) {
	(void)host;
	osalDbgAssert(hcm->ep->in && (hcm->ep->type != USBH_EPTYPE_ISO), "DTERR should not happen in OUT or ISO endpoints");
#if 0
	hc->HCINTMSK &= ~(HCINTMSK_DTERRM | HCINTMSK_ACKM);
	hcm->ep->xfer.error_count = 0;
	_halt_channel(host, hcm, USBH_LLD_HALTREASON_ERROR);
#else
	/* restart directly, no need to halt it in this case */
	hcm->ep->xfer.error_count = 0;
	//hc->HCINTMSK &= ~HCINTMSK_ACKM;
	//hc->HCCHAR |= HCCHAR_CHENA;
#endif
	uerrf("\t%s: DTERR", hcm->ep->name);
}

//CTRL(IN)	CTRL(OUT)	INT(IN)		INT(OUT)	BULK(IN)	BULK(OUT)	ISO(IN)		ISO(OUT)
//	si			no			si			no			si			no			si			no		ep->in
static inline void _babble_int(USBHDriver *host, hs_hc_management_t *hcm, uint8_t intrusb) {
  (void)intrusb;
  osalDbgAssert(hcm->ep->in, "babble should not happen in OUT endpoints");
  hcm->ep->xfer.error_count = 3;
  _halt_channel(host, hcm, USBH_LLD_HALTREASON_ERROR);
  uerrf("\t%s: babble error (intrusb=%x)", hcm->ep->name, intrusb);
}

///CTRL(IN)	CTRL(OUT)	INT(IN)		INT(OUT)	BULK(IN)	BULK(OUT)	ISO(IN)		ISO(OUT)
//	si			si			si			si			si			si			si			no		ep->type != ISO || ep->in
static inline void _error_int(USBHDriver *host, hs_hc_management_t *hcm, uint16_t csr) {
  (void)csr;
  osalDbgAssert(hcm->ep->type != USBH_EPTYPE_ISO, "Error should not happen in ISO endpoints");
  hcm->ep->xfer.error_count += 3;
  _halt_channel(host, hcm, USBH_LLD_HALTREASON_ERROR);
  uerrf("\t%s: error after 3 attempts (csr=0x%x)", hcm->ep->name, csr);
}

//CTRL(IN)	CTRL(OUT)	INT(IN)		INT(OUT)	BULK(IN)	BULK(OUT)	ISO(IN)		ISO(OUT)
//	no			no			si			si			no			no			si			si		ep->type = PERIODIC
static inline void _frmor_int(USBHDriver *host, hs_hc_management_t *hcm, uint16_t csr) {
  (void)csr;
  osalDbgAssert(usbhEPIsPeriodic(hcm->ep), "FRMOR should not happen in non-periodic endpoints");
  //hc->HCINTMSK &= ~HCINTMSK_FRMORM;
  hcm->ep->xfer.error_count = 3;
  _halt_channel(host, hcm, USBH_LLD_HALTREASON_ERROR);
  uerrf("\t%s: FRMOR (csr=0x%x)", hcm->ep->name, csr);
}

//CTRL(IN)	CTRL(OUT)	INT(IN)		INT(OUT)	BULK(IN)	BULK(OUT)	ISO(IN)		ISO(OUT)
//	si			si			si			si			si			si			no			no		ep->type != ISO
static inline void _nak_int(USBHDriver *host, hs_hc_management_t *hcm, uint16_t csr) {
  (void)csr;
  osalDbgAssert(hcm->ep->type != USBH_EPTYPE_ISO, "NAK should not happen in ISO endpoints");
  if (!hcm->ep->in || (hcm->ep->type == USBH_EPTYPE_INT)) {
    //hc->HCINTMSK &= ~HCINTMSK_NAKM;
    _halt_channel(host, hcm, USBH_LLD_HALTREASON_NAK);
  } else {
    /* restart directly, no need to halt it in this case */
    hcm->ep->xfer.error_count = 0;
    //hc->HCINTMSK &= ~HCINTMSK_ACKM;
    //hc->HCCHAR |= HCCHAR_CHENA;
  }
  uerrf("\t%s: NAK (csr=0x%x)", hcm->ep->name, csr);
}

//CTRL(IN)	CTRL(OUT)	INT(IN)		INT(OUT)	BULK(IN)	BULK(OUT)	ISO(IN)		ISO(OUT)
//	si		sólo DAT/STAT	si			si			si			si			no			no		ep->type != ISO && (ep->type != CTRL || ctrlphase != SETUP)
static inline void _stall_int(USBHDriver *host, hs_hc_management_t *hcm, uint16_t csr) {
  (void)csr;
  osalDbgAssert(hcm->ep->type != USBH_EPTYPE_ISO, "STALL should not happen in ISO endpoints");
  _halt_channel(host, hcm, USBH_LLD_HALTREASON_STALL);
  uwarnf("\t%s: STALL (csr=0x%x)", hcm->ep->name, csr);
}

static void _complete_bulk_int(USBHDriver *host, hs_hc_management_t *hcm, usbh_ep_t *ep, usbh_urb_t *urb) {

  if (urb->requestedLength - urb->actualLength > 0) {
    uint32_t bytes;
    ep->xfer.buf = (uint8_t *) urb->buff + urb->actualLength;
    if (ep->in) {
      bytes = HS_USB->RXCOUNT;
      _usbh_read_fifo(ep->address, ep->xfer.buf, bytes);
    }
    else {
      bytes = ep->xfer.len;
    }

    if (!_update_urb(ep, bytes, urb)) {
      if (ep->in) {
        HS_USB->RXCSR |= USB_RXCSR_H_REQPKT;
      }
      else {
        bytes = urb->requestedLength - urb->actualLength;
        if (bytes > ep->wMaxPacketSize) {
          bytes = ep->wMaxPacketSize;
        }
        ep->xfer.len = bytes;
        _usbh_write_fifo(ep->address, ep->xfer.buf, ep->xfer.len);
      }
      return;
    }
    udbgf("\t%s: done", ep->name);
    _release_channel(host, hcm);
    _transfer_completedI(ep, urb, USBH_URBSTATUS_OK);
  } else {
    osalDbgCheck(urb->requestedLength > 0x7FFFF);
    uwarnf("\t%s: incomplete", ep->name);
    _move_to_pending_queue(ep);
  }
}

static void _complete_control_setup(USBHDriver *host, hs_hc_management_t *hcm, usbh_ep_t *ep, usbh_urb_t *urb) {
  (void)hcm;
  ep->in = *((uint8_t *)urb->setup_buff) & 0x80 ? TRUE : FALSE;
  if (urb->requestedLength) {
    ep->xfer.u.ctrl_phase = USBH_LLD_CTRLPHASE_DATA;
    HS_USB->CSR0 |= USB_CSR0_H_REQPKT;
    udbgf("\t%s: SETUP done -> DATA", ep->name);
    ep->xfer.error_count = 0;
    return;
  } else {
    ep->xfer.u.ctrl_phase = USBH_LLD_CTRLPHASE_STATUS;
    ep->in = !ep->in;
    /* perform a status stage transaction */
    if (!ep->in) {
      /* Setup, In, Out(zlp) */
      HS_USB->CSR0 |= USB_CSR0_H_STATUSPKT | USB_CSR0_H_TXPKTRDY;
    }
    else {
      /* Setup, Out/No, In(zlp) */
      HS_USB->CSR0 |= USB_CSR0_H_STATUSPKT | USB_CSR0_H_REQPKT;
    }
    udbgf("\t%s: SETUP done -> STATUS", ep->name);
    return;
  }
  _move_to_pending_queue(ep);
  _try_commit_np(host);
}

static void _complete_control_data(USBHDriver *host, hs_hc_management_t *hcm, usbh_ep_t *ep, usbh_urb_t *urb) {
  (void)host;
  (void)hcm;
  if (urb->requestedLength - urb->actualLength > 0) {
    uint32_t bytes = HS_USB->COUNT0;
    ep->xfer.buf = (uint8_t *) urb->buff + urb->actualLength;
    _usbh_read_fifo(0, ep->xfer.buf, bytes);
    //int ii;for(ii=0; ii<8; ii++) printf("%02x ", *(ep->xfer.buf+ii)); printf("\n");
    udbgf("\t%s: DATAing in %d bytes", ep->name, bytes);
    if (!_update_urb(ep, bytes, urb)) {
      /* continue to request In packets */
      HS_USB->CSR0 |= USB_CSR0_H_REQPKT;
      return;
    }
  }

  ep->xfer.error_count = 0;
  ep->xfer.u.ctrl_phase = USBH_LLD_CTRLPHASE_STATUS;
  ep->in = !ep->in;
  /* perform a status stage transaction */
  if (!ep->in) {
    /* Setup, In, Out(zlp) */
    HS_USB->CSR0 |= USB_CSR0_H_STATUSPKT | USB_CSR0_H_TXPKTRDY;
  }
  else {
    /* Setup, Out/No, In(zlp) */
    HS_USB->CSR0 |= USB_CSR0_H_STATUSPKT | USB_CSR0_H_REQPKT;
  }
  udbgf("\t%s: DATA done -> STATUS", ep->name);
}

static void _complete_control_status(USBHDriver *host, hs_hc_management_t *hcm, usbh_ep_t *ep, usbh_urb_t *urb) {
  osalDbgCheck(ep->xfer.u.ctrl_phase != USBH_LLD_CTRLPHASE_SETUP);

  _release_channel(host, hcm);
  if (ep->xfer.u.ctrl_phase == USBH_LLD_CTRLPHASE_STATUS) {
    uint8_t *buf = (uint8_t *)urb->setup_buff;
    udbgf("\t%s: STATUS done", ep->name);
    if ((buf[0] == 0x00) && (buf[1] == USBH_REQ_SET_ADDRESS)) {
      /* USB function address */
      HS_USB->FADDR = buf[2];
    }
    _transfer_completedI(ep, urb, USBH_URBSTATUS_OK);
  }
}

static void _complete_iso(USBHDriver *host, hs_hc_management_t *hcm, usbh_ep_t *ep, usbh_urb_t *urb, uint32_t hctsiz) {
	udbgf("\t%s: done", hcm->ep->name);
	_release_channel(host, hcm);
	_update_urb(ep, hctsiz, urb);
	_transfer_completedI(ep, urb, USBH_URBSTATUS_OK);
	_try_commit_p(host, FALSE);
}

static inline void _transaction_completed_int(USBHDriver *host, hs_hc_management_t *hcm) {
  usbh_ep_t *const ep = hcm->ep;
  osalDbgCheck(ep);
  usbh_urb_t *const urb = _active_urb(ep);
  osalDbgCheck(urb);
  uint32_t hctsiz = 0;//HS_USB->RXCOUNT;

  //udbgf("type=%d ctrl_pase=%d reqlen=%d actlen=%d", ep->type, ep->xfer.u.ctrl_phase, urb->requestedLength, urb->actualLength);

  switch (ep->type) {
  case USBH_EPTYPE_CTRL:
    if (ep->xfer.u.ctrl_phase == USBH_LLD_CTRLPHASE_SETUP) {
      _complete_control_setup(host, hcm, ep, urb);
    }
    else if (ep->xfer.u.ctrl_phase == USBH_LLD_CTRLPHASE_DATA) {
      _complete_control_data(host, hcm, ep, urb);
    }
    else if (ep->xfer.u.ctrl_phase == USBH_LLD_CTRLPHASE_STATUS) {
      _complete_control_status(host, hcm, ep, urb);
    }
    else if (ep->in) {
      _halt_channel(host, hcm, USBH_LLD_HALTREASON_XFRC);
    }
    break;

  case USBH_EPTYPE_BULK:
    _complete_bulk_int(host, hcm, ep, urb);
    break;

  case USBH_EPTYPE_INT:
    if (ep->in && hctsiz) {
      _halt_channel(host, hcm, USBH_LLD_HALTREASON_XFRC);
    } else {
      _complete_bulk_int(host, hcm, ep, urb);
    }
    break;

  case USBH_EPTYPE_ISO:
    if (ep->in && hctsiz) {
      _halt_channel(host, hcm, USBH_LLD_HALTREASON_XFRC);
    } else {
      _complete_iso(host, hcm, ep, urb, hctsiz);
    }
    break;
  }
}

static inline void _chh_int(USBHDriver *host, hs_hc_management_t *hcm) {

  usbh_ep_t *const ep = hcm->ep;
  usbh_urb_t *const urb = _active_urb(ep);
  osalDbgCheck(urb);
  uint32_t hctsiz = HS_USB->RXCOUNT;
  usbh_lld_halt_reason_t reason = hcm->halt_reason;

  //osalDbgCheck(reason != USBH_LLD_HALTREASON_NONE);
  if (reason == USBH_LLD_HALTREASON_NONE) {
    uwarnf("\tCHH: ch=%d, USBH_LLD_HALTREASON_NONE", hcm - host->channels);
    return;
  }

  if (reason == USBH_LLD_HALTREASON_XFRC) {
    osalDbgCheck(ep->in);
    switch (ep->type) {
    case USBH_EPTYPE_CTRL:
      _complete_control_setup(host, hcm, ep, urb);
      break;
    case USBH_EPTYPE_BULK:
    case USBH_EPTYPE_INT:
      _complete_bulk_int(host, hcm, ep, urb);
      break;
    case USBH_EPTYPE_ISO:
      _complete_iso(host, hcm, ep, urb, hctsiz);
      break;
    }
  } else {
    _release_channel(host, hcm);
    _save_dt_mask(ep, hctsiz);
    bool done = _update_urb(ep, hctsiz, urb);

    switch (reason) {
    case USBH_LLD_HALTREASON_NAK:
      if ((ep->type == USBH_EPTYPE_INT) && ep->in) {
        _transfer_completedI(ep, urb, USBH_URBSTATUS_TIMEOUT);
      } else {
        ep->xfer.error_count = 0;
        _move_to_pending_queue(ep);
      }
      break;

    case USBH_LLD_HALTREASON_STALL:
      if (ep->type == USBH_EPTYPE_CTRL) {
        if (ep->xfer.u.ctrl_phase == USBH_LLD_CTRLPHASE_SETUP) {
          uerrf("\t%s: Faulty device: STALLed SETUP phase", ep->name);
        }
      } else {
        ep->status = USBH_EPSTATUS_HALTED;
      }
      _transfer_completedI(ep, urb, USBH_URBSTATUS_STALL);
      break;

    case USBH_LLD_HALTREASON_ERROR:
      if ((ep->type == USBH_EPTYPE_ISO) || done || (ep->xfer.error_count >= 3)) {
        _transfer_completedI(ep, urb, USBH_URBSTATUS_ERROR);
      } else {
        uerrf("\t%s: err=%d, done=%d, retry", ep->name, ep->xfer.error_count, done);
        _move_to_pending_queue(ep);
      }
      break;

    case USBH_LLD_HALTREASON_ABORT:
      uwarnf("\t%s: Abort", ep->name);
      _transfer_completedI(ep, urb, urb->status);
      break;

    default:
      osalDbgCheck(0);
      break;
    }

    if (usbhEPIsPeriodic(ep)) {
      _try_commit_p(host, FALSE);
    } else {
      _try_commit_np(host);
    }
  }
}

/*===========================================================================*/
/* Host interrupts.                                                          */
/*===========================================================================*/
static inline void _sof_int(USBHDriver *host) {

  /* this is part of the workaround to the LS bug in the OTG core */
  if (host->check_ls_activity) {
    /* 15us loop during which we check if the core generates an actual keep-alive
     * (or activity other than idle) on the DP/DM lines. After 15us, we abort
     * the loop and wait for the next SOF. If no activity is detected, the upper
     * layer will time-out waiting for the reset to happen, and the port will remain
     * enabled (though in a dumb state). This will be detected on the next port reset
     * request and the OTG core will be reset. */
    for (;;) {
      if (0 == (HS_USB->DEVCTL & USB_DEVCTL_HOST_MODE)) {
        uwarn("LS: Port disabled");
        return;
      }
      if (HS_USB->DEVCTL & USB_DEVCTL_LSDEV) {
        /* success; report that the port is enabled */
        uinfof("LS: activity detected, devctl=%d, frame=%d", HS_USB->DEVCTL,  HS_USB->FRAME);
        host->check_ls_activity = FALSE;
        host->rootport.lld_status |= USBH_PORTSTATUS_ENABLE;
        host->rootport.lld_c_status |= USBH_PORTSTATUS_C_ENABLE;
        return;
      }
	}
  }

  /* real SOF interrupt */
  udbg("SOF");
  _try_commit_p(host, TRUE);
}

static inline void _rx_int(USBHDriver *host, uint16_t ep_map) {
  uint8_t epnum;
  hs_hc_management_t *const hcm = &host->channels[0];

  for (epnum = 0; epnum < HS_USB_NUM_ENDPOINTS; epnum++) {
    if (ep_map & (1 << epnum)) {
      HS_USB->INDEX = epnum;
      uint16_t rxcsr = HS_USB->RXCSR;
      /* clear by CPU: NAKTIMEOUT, ERROR, RXSTALL */
      HS_USB->RXCSR = 0;
      if (rxcsr & USB_RXCSR_H_ERROR) {
        _error_int(host, hcm, rxcsr);
      }
      else if (rxcsr & USB_RXCSR_H_RXSTALL) {
        _stall_int(host, hcm, rxcsr);
      }
      else if (rxcsr & USB_RXCSR_H_NAKTIMEOUT) {
        _nak_int(host, hcm, rxcsr);
      }
      else {
        _transaction_completed_int(host, hcm);
      }
    }
  }
}

static inline void _tx_int(USBHDriver *host, uint16_t ep_map) {
  uint8_t epnum;
  hs_hc_management_t *const hcm = &host->channels[0];

  for (epnum = 0; epnum < HS_USB_NUM_ENDPOINTS; epnum++) {
    if (ep_map & (1 << epnum)) {
      HS_USB->INDEX = epnum;
      if (0 == epnum) {
        uint16_t csr0 = HS_USB->CSR0;
        /* clear by CPU: NAKTIMEOUT, ERROR, RXSTALL */
        HS_USB->CSR0 = 0;
        if (csr0 & USB_CSR0_H_ERROR) {
          _error_int(host, hcm, csr0);
        }
        else if (csr0 & USB_CSR0_H_RXSTALL) {
          _stall_int(host, hcm, csr0);
        }
        else if (csr0 & USB_CSR0_H_NAKTIMEOUT) {
          _nak_int(host, hcm, csr0);
        }
        else {
          _transaction_completed_int(host, hcm);
        }
      }
      else {
        uint16_t txcsr = HS_USB->TXCSR;
        /* clear by CPU: NAKTIMEOUT, ERROR, RXSTALL */
        HS_USB->TXCSR = 0;
        if (txcsr & USB_TXCSR_H_ERROR) {
          _error_int(host, hcm, txcsr);
        }
        else if (txcsr & USB_TXCSR_H_RXSTALL) {
          _stall_int(host, hcm, txcsr);
        }
        else if (txcsr & USB_TXCSR_H_NAKTIMEOUT) {
          _nak_int(host, hcm, txcsr);
        }
        else if (txcsr & USB_TXCSR_H_FIFONOTEMPTY) {
          _frmor_int(host, hcm, txcsr);
        }
        else {
          _transaction_completed_int(host, hcm);
        }
      }
    }
  }
}

static void _disable(USBHDriver *host) {
  host->rootport.lld_status &= ~(USBH_PORTSTATUS_CONNECTION | USBH_PORTSTATUS_ENABLE);
  host->rootport.lld_c_status |= USBH_PORTSTATUS_C_CONNECTION | USBH_PORTSTATUS_C_ENABLE;

  _purge_active(host);
  _purge_pending(host);

  /* Make sure the FIFOs are flushed. */
  usbdrc_flush_fifo();

  /* reset FIFO's allocation */
  host->ramnext = 0;

  //HS_USB->INTR_USBEN = 0;
  HS_USB->INTR_TXEN = 0x0000;
  HS_USB->INTR_RXEN = 0x0000;
  //usbdrc_disconnect_vbus();
  HS_USB->DEVCTL |= USB_DEVCTL_SESSION;
}

static inline void _disconnect_int(USBHDriver *host, int8_t intrusb) {
  (void)intrusb;
  uinfof("INTR_DISCONNECT: Port disconnection detected (intrusb=%x)", intrusb);
  if (0 != (host->rootport.lld_status & USBH_PORTSTATUS_CONNECTION)) {
    host->rootport.lld_status &= ~USBH_PORTSTATUS_CONNECTION;
    host->rootport.lld_c_status |= USBH_PORTSTATUS_C_CONNECTION;
  }
  _disable(host);
}

static inline void _roothub_port_int(USBHDriver *host, uint8_t intrusb) {
  if (intrusb & USB_INTR_BABBLE) {
    //uerr("\tINTR_BABBLE: Port disabled due to port babble");
    //_disable(host);
    _babble_int(host, &host->channels[0], intrusb);
    return;
  }
  if (intrusb & USB_INTR_VBUS_ERROR) {
    uerr("\tINTR_VBUS_ERROR: Overcurrent");
    host->rootport.lld_status |= USBH_PORTSTATUS_OVERCURRENT;
    return;
  }

  if (intrusb & USB_INTR_CONNECT) {
    uinfo("\tINTR_CONNECT: Port connection detected");
    cpmDisableCharger();
    /* assert Reset signaling */
    HS_USB->POWER |= USB_POWER_RESET;
    if (0 == (host->rootport.lld_status & USBH_PORTSTATUS_CONNECTION)) {
      host->rootport.lld_status |= USBH_PORTSTATUS_CONNECTION;
      host->rootport.lld_c_status |= USBH_PORTSTATUS_C_CONNECTION;
    }
  }

  if (HS_USB->DEVCTL & USB_DEVCTL_FSDEV) {
    uinfo("\tINTR_CONNECT: full speed");
    host->rootport.lld_status &= ~(USBH_PORTSTATUS_HIGH_SPEED | USBH_PORTSTATUS_LOW_SPEED);
  }

  HS_USB->FADDR = 0x00;

  /* Clear all pending HC Interrupts */
  HS_USB->INTR_TX;
  HS_USB->INTR_RX;

  /* configure speed */
  if (HS_USB->DEVCTL & USB_DEVCTL_LSDEV) {
    host->rootport.lld_status |= USBH_PORTSTATUS_LOW_SPEED;
    host->check_ls_activity = TRUE;
  } else {
    host->check_ls_activity = FALSE;
    /* enable channel and rx interrupts */
    HS_USB->INTR_TXEN = 0x0001; //EP0 out/in
    HS_USB->INTR_RXEN = 0x0000;
    host->rootport.lld_status |= USBH_PORTSTATUS_ENABLE;
    host->rootport.lld_c_status |= USBH_PORTSTATUS_C_ENABLE;
  }
}

/*===========================================================================*/
/* Interrupt handlers.                                                       */
/*===========================================================================*/

void usbh_lld_serve_interrupt(USBHDriver *host, uint8_t intrusb)
{
  osalDbgCheck(host && (host->status != USBH_STATUS_STOPPED));

  /* read to clear */
  uint16_t intrtx = HS_USB->INTR_TX;
  uint16_t intrrx = HS_USB->INTR_RX;

  //udbgf("csr0=%x intr_usb=%x tx=%x rx=%x power=%x devctl=%x", HS_USB->CSR0, intrusb, intrtx, intrrx, HS_USB->POWER, HS_USB->DEVCTL);
  if (intrusb & USB_INTR_SOF) {
    uerrf("SOF in host mode (intrusb=%x)", intrusb);
    /* don't disconnect vbus, because vbus is auto off in usbd mode */
    //usbdrc_disconnect_vbus();
    /* reset clock, otherwise USB_INTR_SOF cannot be disabled */
    usbdrc_reset_core();
    return;
  }
  if (intrusb & USB_INTR_RESET) {
    uerr("detect Reset signaling on the bus in host mode");
    return;
  }
  /* check host mode */
  if (HS_USB->DEVCTL & USB_DEVCTL_CID) {
    uerrf("CID pin: B-type (intrusb=%x)", intrusb);
    return;
  }

  #if defined(hscAudiophile)
  extern void hs_pnp_emit_usbh_status(bool bOn);
  if (intrusb & USB_INTR_CONNECT) {
    hs_pnp_emit_usbh_status(true);
  }
  if (intrusb & USB_INTR_DISCONNECT) {
    hs_pnp_emit_usbh_status(false);
  }
  #endif

  if (intrusb & USB_INTR_SOF)
    _sof_int(host);
  if (intrusb & (USB_INTR_BABBLE | USB_INTR_CONNECT | USB_INTR_SESS_REQ | USB_INTR_VBUS_ERROR))
    _roothub_port_int(host, intrusb);
  if (intrusb & USB_INTR_DISCONNECT)
    _disconnect_int(host, intrusb);

  /* don't handle transaction interrupts if disconnected */
  if (0 == (HS_USB->DEVCTL & USB_DEVCTL_HOST_MODE)) {
    uwarn("Peripheral mode");
    return;
  }
  if (!_usbh_is_connected(host)) {
    uwarn("disconnected");
    return;
  }
  if (intrtx)
    _tx_int(host, intrtx);
  if (intrrx)
    _rx_int(host, intrrx);
}

/*===========================================================================*/
/* Initialization functions.                                                 */
/*===========================================================================*/
static void _init(USBHDriver *host) {
  int i;

  usbhObjectInit(host);

  host->ramnext = 0;
  /* address starts from 2 */
  //host->address_bitmap[0] = 0x1;

  INIT_LIST_HEAD(&host->ch_free[0]);
  list_add_tail(&host->channels[0].node, &host->ch_free[0]);
  for (i = 0; i < 4; i++) {
    INIT_LIST_HEAD(&host->ep_active_lists[i]);
    INIT_LIST_HEAD(&host->ep_pending_lists[i]);
  }
}

void usbh_lld_init(void) {
#if HS_USB_USE_USB0
	_init(&USBHD0);
#endif
}

static void _usbh_start(USBHDriver *usbh) {

  /* Clock activation.*/
#if HS_USB_USE_USB0
  if (&USBHD0 == usbh) {
    #if defined(BR3215)
    /* USB: D+, D-, CID. */
    palSetPinMode(PA14, PAL_MODE_INPUT_PULLDOWN | PAL_MODE_ALTERNATE(PAD_FUNC_SD_USB) | PAL_MODE_DRIVE_CAP(3));
    palSetPinMode(PB0,  PAL_MODE_INPUT_PULLDOWN | PAL_MODE_ALTERNATE(PAD_FUNC_SD_USB) | PAL_MODE_DRIVE_CAP(3));
    palSetPinMode(PB1,  PAL_MODE_INPUT_PULLDOWN | PAL_MODE_ALTERNATE(PAD_FUNC_SD_USB) | PAL_MODE_DRIVE_CAP(3));
    #elif defined(BR3215e)
    /* USB: D+, D-, CID. */
    palSetPinMode(PA14, PAL_MODE_INPUT_PULLDOWN | PAL_MODE_ALTERNATE(PAD_FUNC_SD_USB) | PAL_MODE_DRIVE_CAP(3));
    palSetPinMode(PA15, PAL_MODE_INPUT_PULLDOWN | PAL_MODE_ALTERNATE(PAD_FUNC_SD_USB) | PAL_MODE_DRIVE_CAP(3));
    palSetPinMode(PB0,  PAL_MODE_INPUT_PULLDOWN | PAL_MODE_ALTERNATE(PAD_FUNC_SD_USB) | PAL_MODE_DRIVE_CAP(3));
    #endif
  }
#endif

  usbdrc_reset_core();

  usbh->rootport.lld_status = USBH_PORTSTATUS_POWER;
  usbh->rootport.lld_c_status = 0;

  /* Enable interrupts except for SOF. */
  HS_USB->INTR_USBEN = 0xf7;
  /* connect vbus in sw mode defaultly */
  usbdrc_connect_vbus(true/*bForce*/);
  /* Start a session as an A device */
  HS_USB->DEVCTL |= USB_DEVCTL_SESSION;
}

void usbh_lld_start(USBHDriver *usbh) {
	if (usbh->status != USBH_STATUS_STOPPED) return;
	_usbh_start(usbh);
}

/*===========================================================================*/
/* Root Hub request handler.                                                 */
/*===========================================================================*/
usbh_urbstatus_t usbh_lld_root_hub_request(USBHDriver *usbh, uint8_t bmRequestType, uint8_t bRequest,
		uint16_t wvalue, uint16_t windex, uint16_t wlength, uint8_t *buf) {

	uint16_t typereq = (bmRequestType << 8) | bRequest;

    //udbgf("req=%x wvalue=%x windex=%d wlen=%d\n", typereq, wvalue, windex, wlength);
	switch (typereq) {
	case ClearHubFeature:
		switch (wvalue) {
		case USBH_HUB_FEAT_C_HUB_LOCAL_POWER:
		case USBH_HUB_FEAT_C_HUB_OVER_CURRENT:
			break;
		default:
			osalDbgAssert(0, "invalid wvalue");
		}
		break;

	case ClearPortFeature:
		osalDbgAssert(windex == 1, "invalid windex");

		osalSysLock();
		switch (wvalue) {
		case USBH_PORT_FEAT_ENABLE:
		case USBH_PORT_FEAT_SUSPEND:
		case USBH_PORT_FEAT_POWER:
			osalDbgAssert(0, "unimplemented");	/* TODO */
			break;

		case USBH_PORT_FEAT_INDICATOR:
			osalDbgAssert(0, "unsupported");
			break;

		case USBH_PORT_FEAT_C_CONNECTION:
			usbh->rootport.lld_c_status &= ~USBH_PORTSTATUS_C_CONNECTION;
			break;

		case USBH_PORT_FEAT_C_RESET:
			usbh->rootport.lld_c_status &= ~USBH_PORTSTATUS_C_RESET;
			break;

		case USBH_PORT_FEAT_C_ENABLE:
			usbh->rootport.lld_c_status &= ~USBH_PORTSTATUS_C_ENABLE;
			break;

		case USBH_PORT_FEAT_C_SUSPEND:
			usbh->rootport.lld_c_status &= ~USBH_PORTSTATUS_C_SUSPEND;
			break;

		case USBH_PORT_FEAT_C_OVERCURRENT:
			usbh->rootport.lld_c_status &= ~USBH_PORTSTATUS_C_OVERCURRENT;
			break;

		default:
			osalDbgAssert(0, "invalid wvalue");
			break;
		}
		osalSysUnlock();
		break;

	case GetHubDescriptor:
		osalDbgAssert(0, "unsupported");
		break;

	case GetHubStatus:
		osalDbgCheck(wlength >= 4);
		*(uint32_t *)buf = 0;
		break;

	case GetPortStatus:
		osalDbgAssert(windex == 1, "invalid windex");
		osalDbgCheck(wlength >= 4);
		osalSysLock();
		*(uint32_t *)buf = usbh->rootport.lld_status | (usbh->rootport.lld_c_status << 16);
		osalSysUnlock();
        udbgf("getPortStatus: %x", *(uint32_t *)buf);
		break;

	case SetHubFeature:
		osalDbgAssert(0, "unsupported");
		break;

	case SetPortFeature:
        udbgf("setPortFeature: %x", wvalue);
		osalDbgAssert(windex == 1, "invalid windex");

		switch (wvalue) {
		case USBH_PORT_FEAT_TEST:
		case USBH_PORT_FEAT_SUSPEND:
		case USBH_PORT_FEAT_POWER:
			osalDbgAssert(0, "unimplemented");	/* TODO */
			break;

		case USBH_PORT_FEAT_RESET: {
			osalSysLock();
			if (0 == (HS_USB->DEVCTL & USB_DEVCTL_HOST_MODE)/*port enable?*/) {
				/* This can occur when the USB core doesn't generate traffic
				 * despite reporting a successful por enable. */
				uerr("Detected enabled port; resetting Dual-Role core");
				osalThreadSleepS(MS2ST(20));
				_usbh_start(usbh);				/* this effectively resets the core */
				osalThreadSleepS(MS2ST(100));	/* during this delay, the core generates connect ISR */
				uinfo("reset hosth ended");
				if (1/*port connect status: a device is attached to the port*/) {
					/* if the device is still connected, don't report a C_CONNECTION flag, which would cause
					 * the upper layer to abort enumeration */
					uinfo("Clear connection change flag");
					usbh->rootport.lld_c_status &= ~USBH_PORTSTATUS_C_CONNECTION;
				}
			}
            HS_USB->POWER |= USB_POWER_RESET;
			osalThreadSleepS(MS2ST(15));
            HS_USB->POWER &= ~USB_POWER_RESET;
			osalThreadSleepS(MS2ST(10));
			usbh->rootport.lld_c_status |= USBH_PORTSTATUS_C_RESET;
			osalSysUnlock();
		} 	break;

		case USBH_PORT_FEAT_INDICATOR:
			osalDbgAssert(0, "unsupported");
			break;

		default:
			osalDbgAssert(0, "invalid wvalue");
			break;
		}
		break;

	default:
		osalDbgAssert(0, "invalid typereq");
		break;
	}

	return USBH_URBSTATUS_OK;
}

uint8_t usbh_lld_roothub_get_statuschange_bitmap(USBHDriver *usbh) {
	return usbh->rootport.lld_c_status ? (1 << 1) : 0;
}

#endif
