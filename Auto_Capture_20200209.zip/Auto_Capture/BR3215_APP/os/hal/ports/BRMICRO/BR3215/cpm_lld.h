/*
    ChibiOS/RT - Copyright (C) 2006-2013 Giovanni Di Sirio
                 Copyright (C) 2019 BRMICRO Technologies
                 

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    br3215/cpm_lld.h
 * @brief   clock & pmu helper driver header.
 *
 * @addtogroup HAL
 * @{
 */
#ifndef _HAL_CPM_H_
#define _HAL_CPM_H_

/*===========================================================================*/
/* Driver constants.                                                         */
/*===========================================================================*/
#if defined(BR32xx_FPGA)
#define __SYSTEM_CLOCK__        4
#else
#define __SYSTEM_CLOCK__        1
#endif

#if __SYSTEM_CLOCK__ == 1
#define  CPU_DEFAULT_CLOCK      192000000
#define  AHB_DEFAULT_CLOCK      96000000
#define  RAM_DEFAULT_CLOCK      96000000
#define  APB_DEFAULT_CLOCK      96000000
#elif __SYSTEM_CLOCK__ == 2
#define  CPU_DEFAULT_CLOCK      96000000
#define  AHB_DEFAULT_CLOCK      96000000
#define  RAM_DEFAULT_CLOCK      96000000
#define  APB_DEFAULT_CLOCK      96000000
#elif __SYSTEM_CLOCK__ == 3
#define  CPU_DEFAULT_CLOCK      96000000
#define  AHB_DEFAULT_CLOCK      48000000
#define  RAM_DEFAULT_CLOCK      48000000
#define  APB_DEFAULT_CLOCK      48000000
#elif __SYSTEM_CLOCK__ == 4
#define  CPU_DEFAULT_CLOCK      48000000
#define  AHB_DEFAULT_CLOCK      48000000
#define  RAM_DEFAULT_CLOCK      48000000
#define  APB_DEFAULT_CLOCK      48000000
#endif

#define  SF_DEFAULT_CLOCK       96000000
#define  SD_DEFAULT_CLOCK       48000000
#define  TIMER_DEFAULT_CLOCK    8000000
#define  I2C_DEFAULT_CLOCK      12000000
#define  SPI1_DEFAULT_CLOCK     48000000
#define  UART_DEFAULT_CLOCK     (921600 * 4)

#define  HS_XTAL_CLOCK          16000000
#define  HS_SYSTICK_CLOCK       32000

#define  PLL_CLOCK_192M         192000000
#define  XCLK_CLOCK_16MHz       16000000
#define  XCLK_CLOCK_24MHz       24000000

#if defined(BR3215e) || defined(BR3216)
#define  BT_DEFAULT_CLOCK       24000000    /*BT clock shall be 24MHz or 32MHz*/
#endif

typedef enum {
	SF_LOC_INNER = 0x1,
	SF_LOC_OUTER,
}sf_loc_t;

typedef enum {
	SD_CLK_PHASE_0,
	SD_CLK_PHASE_180,
}sd_dev_mclk_phase_t;

typedef struct {
	sd_dev_mclk_phase_t mclk_phase;
	int8_t     smp_half_cycles;
	int8_t     drv_half_cycles;
}sd_dev_clk_t;

typedef struct {
	uint8_t  num;
	uint8_t  edge; //0-posedge,1-negedge
	bool     hold;
	uint8_t  level; //0 - active low, 1 - active high
	bool     reset_en;
	uint8_t  on_cycles;  //power on delay
    uint8_t  reset_cycles; //power off delay
}power_pin_conf_t;

typedef struct {
	uint32_t pll_clk;
	uint32_t xtal_clk;
}sys_clk_t;

typedef enum {
  HS_CPU_CLK,
  HS_AHB_CLK,
  HS_APB_CLK,
  HS_RAM_CLK,
  HS_SF_CLK,
  HS_USB_CLK,
  HS_SD_CLK,
  HS_TIM0_CLK,
  HS_TIM1_CLK,
  HS_TIM2_CLK,
  HS_UART0_CLK,
  HS_UART1_CLK,
  HS_I2C0_CLK,
  HS_LPO_CLK,
  HS_SPI0_CLK, //same with APB clock
  HS_SPI1_CLK,
  HS_CODEC_MCLK, //24MHz alway
  HS_BTBB_CLK,   //24MHz always

  HS_RTC_CLK,
  HS_WDT_CLK,
  HS_PLL_CLK,    //pll clock 96M or 128M
  HS_XTAL_CLK,   //xtal in 16M or 32M
  HS_UART2_CLK,
} hs_clk_t;

typedef bool            bool_t;

typedef struct pmu_tune_shadow_s {
  uint32_t rc_rxadc  : 4;
  uint32_t rc_auadc  : 4;
  uint32_t rc_txdac  : 4;
  uint32_t rc_rxfil  : 4;
  uint32_t rc_rxtia  : 4;
  uint32_t ldo_lobuf : 2;
  uint32_t ldo_xtal  : 2;
  uint32_t ldo_vco   : 2;
  uint32_t rsv       : 4;
  uint32_t valid_rc  : 1;
  uint32_t valid_ldo : 1;
} pmu_tune_shadow_t;

#define CPM_DIV_COEFF_Pos           8
#define CPM_DIV_COEFF_Msk           (0x1F << CPM_DIV_COEFF_Pos)

#define CPM_AHB_DIV_COEFF_Pos       16
#define CPM_AHB_DIV_COEFF_Msk       (0x1F << CPM_AHB_DIV_COEFF_Pos)

#define CPM_RAM_DIV_COEFF_Pos       24
#define CPM_RAM_DIV_COEFF_Msk       (0x1F << CPM_RAM_DIV_COEFF_Pos)

#define CPM_APB_DIV_COEFF_Pos       8
#define CPM_APB_DIV_COEFF_Msk       (0x1F << CPM_APB_DIV_COEFF_Pos)

#define CPM_SF_DIV_COEFF_Pos        8
#define CPM_SF_DIV_COEFF_Msk        (0x0F << CPM_SF_DIV_COEFF_Pos)

#define CPM_SF_DELAY_OFFSET_Pos     16
#define CPM_SF_DELAY_OFFSET_Msk     (0x07 << CPM_SF_DELAY_OFFSET_Pos)
#define CPM_SF_DELAY_BYPASS_Pos     3

#define CPM_SD_DEV_DRV_DELAY_BYPASS_Pos   1
#define CPM_SD_DEV_DRV_DELAY_OFFSET_Pos   8
#define CPM_SD_DEV_DRV_DELAY_OFFSET_Msk   (0x07 << CPM_SD_DEV_DRV_DELAY_OFFSET_Pos)
#define CPM_SD_DEV_SMP_DELAY_BYPASS_Pos   2
#define CPM_SD_DEV_SMP_DELAY_OFFSET_Pos   16
#define CPM_SD_DEV_SMP_DELAY_OFFSET_Msk   (0x07 << CPM_SD_DEV_SMP_DELAY_OFFSET_Pos)
#define CPM_SD_DEV_MCLK_INV_Pos           0

#define CPM_I2C_DIV_COEFF_Pos       8
#define CPM_I2C_DIV_COEFF_Msk       (0x3F << CPM_I2C_DIV_COEFF_Pos)

#define CPM_UART_DIV_COEFF_FRC_Pos  16
#define CPM_UART_DIV_COEFF_FRC_Msk  (0x3F << CPM_UART_DIV_COEFF_FRC_Pos)
#define CPM_UART_DIV_COEFF_FRC_Len  6
#define CPM_UART_DIV_COEFF_INT_Pos  8
#define CPM_UART_DIV_COEFF_INT_Msk  (0x3F << CPM_UART_DIV_COEFF_INT_Pos)

#define CPM_DIV_EN_Pos              0

/*
 * Bit manipulation macros
 */
#define CPM_BIT(name)				\
  (1 << CPM_##name##_Pos)
/* bit field generate */
#define CPM_BF(name,value)			\
  (((value) << CPM_##name##_Pos) & CPM_##name##_Msk)
/* bit field extract from value */
#define CPM_BFEXT(name,value)			\
  (((value) & CPM_##name##_Msk) >> CPM_##name##_Pos)
/* bit field insert value into old */
#define CPM_BFINS(name,value,old)		\
  (((old) & ~CPM_##name##_Msk) | CPM_BF(name,value))

__STATIC_INLINE bool_t CPM_DIV_EN(uint32_t value)
{
  return value & CPM_BIT(DIV_EN) ? true : false;
}

/* The difinition of clock control registers XXX_CFG */
#define CPM_MOD_RST   (1 << 4)
#define CPM_MOD_GATE  (1 << 3)
#define CPM_BUS_RST   (1 << 2)
#define CPM_BUS_GATE  (1 << 1)
#define CPM_CLK_DEN   (1 << 0)

#define RESET_STATUS_POWER_UP (1<<1)
#define RESET_STATUS_SYS      (1<<2)
#define RESET_STATUS_WDT      (1<<0)

#define PMU_POWER_ON    0x1
#define PMU_POWER_OFF   0x2

/* The difinition of scratch bits between bootflash & chibios */
#define SCRATCH_SW_ISP_MODE         (1 << 0u)
#define SCRATCH_TEST_NG_MODE        (1 << 1u)
#define SCRATCH_INVALID_BITMASK     ~(SCRATCH_TEST_NG_MODE | SCRATCH_SW_ISP_MODE)

#define SF_USE_CLK_DELAY_IN_CPM		FALSE

/*===========================================================================*/
/* Driver pre-compile time settings.                                         */
/*===========================================================================*/

/*===========================================================================*/
/* Derived constants and error checks.                                       */
/*===========================================================================*/

/*===========================================================================*/
/* Driver data structures and types.                                         */
/*===========================================================================*/

/*===========================================================================*/
/* Driver macros.                                                            */
/*===========================================================================*/
#define  pso_reg_update() \
   (HS_PSO->REG_UPD = 0x01)

#define  pmu_cpm_reg_update() \
   (HS_PMU_CPM->UPD = 0x01)

#define  pmu_reg_update() \
   (HS_PMU->BASIC |= (1u<<30))

/**
 * @brief   Generate software reset mcu chip
 *
 * @api
 */
#define cpmResetMCU() \
do { \
  HS_PMU->OPT_RESET_CON &= ~(1 << 25); \
  HS_PMU->OPT_RESET_CON |= (1 << 25); \
} while (0)

/**
 * @brief   Generate software reset cpu core
 *
 * @api
 */
#define cpmResetCPU() \
do { \
  HS_PSO->CPU_CFG &= ~(1 << 7); \
  HS_PSO->CPU_CFG |= (1 << 7); \
} while (0)


#define cpmResetAPB() \
do { \
  HS_PSO->APB_CFG &= ~(1 << 2); \
  HS_PSO->APB_CFG |= (1 << 2); \
  __NOP(); __NOP(); __NOP(); __NOP(); \
  __NOP(); __NOP(); __NOP(); __NOP(); \
} while (0)


/**
 * @brief   Generate software reset pso domain ip
 *
 * @api
 */
#define cpmResetPSO() \
do { \
  HS_PMU->OPT_RESET_CON &= ~(1 << 26); \
  HS_PMU->OPT_RESET_CON |= (1 << 26); \
} while (0)

/**
 * @name    SF peripherals specific CPM operations
 * @{
 */
/**
 * @brief   Enables the SF peripheral clock.
 *
 * @api
 */
#define cpmEnableSF() \
  do {\
    HS_PSO->SFLASH_CFG &= ~(CPM_BUS_GATE); \
    HS_PSO->SFLASH_CFG |= (CPM_CLK_DEN); \
  }while(0)

/**
 * @brief   Disables the SF peripheral clock.
 *
 * @api
 */
#define cpmDisableSF() \
  do {\
    HS_PSO->SFLASH_CFG |= (CPM_BUS_GATE); \
    HS_PSO->SFLASH_CFG &= ~(CPM_CLK_DEN); \
  }while(0)

/**
 * @brief   Resets the SF peripheral.
 *
 * @api
 */
#define cpmResetSF() \
do { \
  HS_PSO->SFLASH_CFG &= ~(CPM_BUS_RST); \
  HS_PSO->SFLASH_CFG |= (CPM_BUS_RST); \
} while (0)
/** @} */

/**
 * @name    I2S peripherals specific CPM operations
 * @{
 */
/**
 * @brief   Enables the I2S peripheral clock.
 *
 * @api
 */
#define cpmEnableI2S() HS_PSO->I2S_CFG &= ~(CPM_BUS_GATE)

/**
 * @brief   Disables the I2S peripheral clock.
 *
 * @api
 */
#define cpmDisableI2S() HS_PSO->I2S_CFG |= (CPM_BUS_GATE)

/**
 * @brief   Resets the I2S peripheral.
 *
 * @api
 */
#define cpmResetI2S() \
do { \
  HS_PSO->I2S_CFG &= ~(CPM_BUS_RST); \
  HS_PSO->I2S_CFG |= (CPM_BUS_RST); \
} while (0)
/** @} */

/**
 * @name    CODEC peripherals specific CPM operations
 * @{
 */
/**
 * @brief   Enables the CODEC peripheral clock and 24MHz,12MHz from analog
 *
 * @api
 */
#define cpmEnableCODEC() \
do { \
  HS_PSO->CODEC_CFG &= ~(CPM_BUS_GATE); \
  HS_PSO->CODEC_CFG &= ~((1<<3) | (1 <<4));    \
  HS_PMU->ANA_CON &= ~((1 << 22) | (1 << 21)); \
} while (0)

/**
 * @brief   Disables the CODEC peripheral clock and 12MHz from analog
 *
 * @api
 */
#define cpmDisableCODEC() \
do { \
  /* clocks & power */ \
  HS_PSO->CODEC_CFG |= (CPM_BUS_GATE); \
  HS_PSO->CODEC_CFG |= ((1<<3) | (1 <<4)); \
} while (0)

/**
 * @brief   Resets the CODEC peripheral.
 *
 * @api
 */
#define cpmResetCODEC() \
do { \
  HS_PSO->CODEC_CFG &= ~(CPM_BUS_RST); \
  HS_PSO->CODEC_CFG |= (CPM_BUS_RST); \
} while (0)
/** @} */

/**
 * @name    BTPHY peripherals specific CPM operations
 * @{
 */
/**
 * @brief   Enables the BTPHY peripheral clock and 48,32,24MHz from analog
 *
 * @api
 */
#if defined(BR3215) || defined(BR3215c)
#define cpmEnableBTPHY() \
do { \
  /* clocks to BTPHY:        48M, 32M, 24M */ \
  HS_PSO->BTPHY_CFG &= ~(CPM_BUS_GATE | (1 << 12) | (1 << 10) | (1 << 8)); \
  /* clocks from system PLL: 48M, 32M, 24M_dig, 24M_ana */ \
  HS_PMU->ANA_CON &= ~((1 << 24) | (1 << 23) | (1 << 22) | (1 << 21)); \
  /* FIXME: [28][12]pd_bt_ldovco_flag/reg */ \
  HS_ANA->PD_CFG[1] &= ~((1 << 28) | (1 << 12)); \
  /* flag=1=fsm: [26][10]pd_txpa [25][9]pd_txum [23][7]pd_txdac */ \
  HS_ANA->PD_CFG[1] |= ((1 << 26) | (1 << 25) | (1 << 23)); \
  /* [21]pd_rfsctgm [20]pd_dcoc by xuebaiqing; for btrx & fm by wangjianting */ \
  HS_ANA->PD_CFG[0] &= ~((1 << 21) | (1 << 20));  \
  /* [4]pd_bt_synth_vc_det_reg, no its flag by xuebaiqing */ \
  HS_ANA->PD_CFG[1] &= ~(1 << 4); \
  /* [12]pd_rxadc_dacbias  */ \
  HS_ANA->PD_CFG[0] &= ~(1 << 12);  \
  /* [15]pd_bt_mmd_fm by wangxin  */ \
  HS_ANA->PD_CFG[0] &= ~(1 << 15);  \
  /* powers: [16]pd_topldo_v1p8 [13]rfldo_v2p8 [10]pd_v2p5ldo [9-7]ldo_v1p5_rf/ana/adda */ \
  HS_PMU->ANA_CON &= ~((1 << 16) | (1 << 13) | (1 << 10) | (1 << 9) | (1 << 8) | (1 << 7)); \
  /* ?SAR:   [30][18]cali_pkdect_flag/reg b'0=no cali */                        \
  /* ?SAR:   [29]cali_rxatten b'0=no cali */                                    \
  /* ?       [27]gsel_txdect b'1=high gain, obsoleted */                        \
  /* TIA:    [25]fre_sel b'1 [23]lp_cp_sel b'1=complex filter; b'0=LPF for calibration */ \
  /* TIA:    [22]modsel_tia b'1=BT b'0=FM */                            \
  /* ?       [21]b'0 */                                                 \
  /* RFPLL:  [20]b'0 */                                                 \
  /* LNA:    [15:14]in_lna b'10= */                                     \
  /* SAR:    [11]gain_agcamp b'0=x1 */                                  \
  /* ?SAR:   [10]seliq_pkdif b'0=I */                                   \
  /* RFPLL:  [8]bt_cp_sw_lvl_en b'1 */                                  \
  /* RXADC:  [7:4]rxadc_rctune: b1000 */                                \
  HS_ANA->COMMON_CFG[0] = (0 << 30) | (0 << 29) | (1 << 25) | (1 << 23) | (1 << 22) | (2 << 14) | (1 << 8) | (8 << 4); \
  /*         [18:16]sel_ifagc: obsoleted */ \
  /* Filter: [13:12]swap_fil b'00=complex filter */ \
  /*         [9:8]gtune_fil b'000 */ \
  /*         [6:4]ctune_fil b'011 */ \
  /*         [0]modsel_fil  b'1=BT b'0=FM */ \
  HS_ANA->RX_FIL_CFG = (0 << 12) | (0 << 8) | (3 << 4) | (1 << 0); \
  /* TIA:    [18:16]cf_tune b'100 */ \
  /* GP-ADC: [8:4]ana_test_en b'00000 */ \
  /* LNA:    [1:0]rxlna_vbn b'01 */ \
  HS_ANA->COMMON_CFG[1] = (4 << 16) | (1 << 0); \
  /* sanity set in case of reset out of fm mode */ \
  HS_BTPHY->FM_MODE = 0; \
  HS_BTPHY->IF_REG = 0x300; \
  HS_BTPHY->DCNOTCH_K_SEL = 3; \
  HS_ANA->VTRACK_CFG = (0 << 4) | (0x4 << 0); \
  HS_ANA->VCO_AFC_CFG[0] &= ~(1 << 12); \
} while (0)
#elif defined(BR3215e)
#define cpmEnableBTPHY() \
do { \
  /* clocks to BTPHY:        48M, 32M, 24M */ \
  HS_PSO->BTPHY_CFG &= ~(CPM_BUS_GATE | (1 << 12) | (1 << 10) | (1 << 8)); \
  /* clocks from system PLL: 48M, 32M, 24M_dig, 24M_ana */ \
  HS_PMU->ANA_CON &= ~((1 << 24) | (1 << 23) | (1 << 22) | (1 << 21)); \
} while (0)
#else
#define cpmEnableBTPHY()
#endif

/**
 * @brief   Disables the BTPHY peripheral clock.
 *
 * @api
 */
#if defined(BR3215) || defined(BR3215c)
#define cpmDisableBTPHY() \
do { \
  HS_PMU->ANA_CON |= ((1 << 13) | (1 << 9) | (1 << 8) | (1 << 7));	      \
  /* flag=0=reg: [28][12]pd_bt_ldovco_flag/reg [26][10]pd_txpa [25][9]pd_txum [23][7]pd_txdac */ \
  HS_ANA->PD_CFG[1] &= ~((1 << 28) | (1 << 26) | (1 << 25) | (1 << 23)); \
  HS_ANA->PD_CFG[1] |=  ((1 << 12) | (1 << 10) | (1 <<  9) | (1 <<  7)); \
  /* [12]pd_rxadc_dacbias */ \
  HS_ANA->PD_CFG[0] |= (1 << 12); \
  HS_PSO->BTPHY_CFG |= (CPM_BUS_GATE | (1 << 12) | (1 << 10) | (1 << 8)); \
} while (0)
#elif defined(BR3215e)
#define cpmDisableBTPHY() \
do { \
  HS_PSO->BTPHY_CFG |= (CPM_BUS_GATE | (1 << 12) | (1 << 10) | (1 << 8)); \
}while(0)
#else
#define cpmDisableBTPHY()
#endif
/**
 * @brief   Resets the BTPHY peripheral.
 *
 * @api
 */
#define cpmResetBTPHY() \
do { \
  HS_PSO->BTPHY_CFG &= ~((CPM_BUS_RST) | (1 << 9) | (1 << 11));  \
  HS_PSO->BTPHY_CFG |= ((CPM_BUS_RST) | (1 << 9) | (1 << 11));   \
} while (0)
/** @} */

/**
 * @name    FM peripherals specific CPM operations
 * @{
 */
/**
 * @brief   Enables the FM peripheral clock and 48,32,24MHz from analog
 *
 * @api
 */
#define cpmEnableFM() \
do { \
  /* clocks to BTPHY:        48M, 32M, 24M */ \
  HS_PSO->BTPHY_CFG &= ~(CPM_BUS_GATE | (1 << 12) | (1 << 10) | (1 << 8)); \
  /* clocks from system PLL: 48M, 32M, 24M_dig, 24M_ana */ \
  HS_PMU->ANA_CON &= ~((1 << 24) | (1 << 23) | (1 << 22) | (1 << 21)); \
} while (0)

/**
 * @brief   Disables the FM peripheral clock.
 *
 * @api
 */
#define cpmDisableFM() \
do { \
} while (0)

/**
 * @brief   Resets the FM peripheral.
 *
 * @api
 */
#define cpmResetFM()
/** @} */

/**
 * @name    WDT peripherals specific CPM operations
 * @{
 */
/**
 * @brief   Enables the WDT peripheral clock.
 *
 * @api
 */
#define cpmEnableWDT() HS_PSO->WDT_CFG &= ~(CPM_BUS_GATE)

/**
 * @brief   Disables the WDT peripheral clock.
 *
 * @api
 */
#define cpmDisableWDT() HS_PSO->WDT_CFG |= (CPM_BUS_GATE)

/**
 * @brief   Resets the WDT peripheral.
 *
 * @api
 */
#define cpmResetWDT()
/** @} */

/**
 * @name    ADC peripherals specific CPM operations
 * @{
 */
/**
 * @brief   Enables the ADC0 peripheral clock.
 *
 * @api
 */
#define cpmEnableADC0()

/**
 * @brief   Disables the ADC0 peripheral clock.
 *
 * @api
 */
#define cpmDisableADC0()

/**
 * @brief   Resets the ADC0 peripheral.
 *
 * @api
 */
#define cpmResetADC0()
/** @} */

/**
 * @name    DMA peripheral specific CPM operations
 * @{
 */
/**
 * @brief   Enables the DMA peripheral clock.
 *
 * @api
 */
#define cpmEnableDMA() HS_PSO->AHB_GATE_CFG &= ~(1 << 2)

/**
 * @brief   Disables the DMA peripheral clock.
 *
 * @api
 */
#define cpmDisableDMA() HS_PSO->AHB_GATE_CFG |= (1 << 2)

/**
 * @brief   Resets the DMA peripheral.
 *
 * @api
 */
#define cpmResetDMA() \
do { \
  HS_PSO->AHB_GATE_CFG &= ~(1 <<3); \
  HS_PSO->AHB_GATE_CFG |= (1 << 3); \
} while (0)
/** @} */

/**
 * @name    GPIO peripheral specific CPM operations
 * @{
 */
/**
 * @brief   Enables the GPIO peripheral clock.
 *
 * @api
 */
#define cpmEnableGPIO() HS_PSO->AHB_GATE_CFG &= ~(1 << 0);

/**
 * @brief   Disables the GPIO peripheral clock.
 *
 * @api
 */
#define cpmDisableGPIO() HS_PSO->AHB_GATE_CFG |= (1 << 0);

/**
 * @brief   Resets the GPIO peripheral.
 *
 * @api
 */
#define cpmResetGPIO() \
do { \
  HS_PSO->AHB_GATE_CFG &= ~(1 <<1); \
  HS_PSO->AHB_GATE_CFG |= (1 << 1); \
} while (0)
/** @} */

/**
 * @name    I2C peripherals specific CPM operations
 * @{
 */
/**
 * @brief   Enables the I2C0 peripheral clock.
 *
 * @api
 */
#define cpmEnableI2C0() \
  do{\
    HS_PSO->I2C0_CFG &= ~(CPM_BUS_GATE);\
    HS_PSO->I2C0_CFG |= CPM_CLK_DEN;\
  }while(0)
  

/**
 * @brief   Disables the I2C0 peripheral clock.
 *
 * @api
 */
#define cpmDisableI2C0() \
  do {\
    HS_PSO->I2C0_CFG |= (CPM_BUS_GATE);\
    HS_PSO->I2C0_CFG &= ~(CPM_CLK_DEN);\
  }while(0)

/**
 * @brief   Resets the I2C0 peripheral.
 *
 * @api
 */
#define cpmResetI2C0() \
do { \
  HS_PSO->I2C0_CFG &= ~(CPM_MOD_RST | CPM_BUS_RST); \
  HS_PSO->I2C0_CFG |= (CPM_MOD_RST | CPM_BUS_RST); \
} while (0)
/** @} */

/**
 * @name    OTG peripherals specific CPM operations
 * @{
 */
/**
 * @brief   Enables the USB peripheral clock.
 *
 * @api
 */
#define cpmEnableUSB() \
do { \
  HS_PSO->USB_CFG &= ~(CPM_MOD_GATE | CPM_BUS_GATE); \
  /* 48MHz shared with BT */ \
  HS_PMU->ANA_CON &= ~(1 << 24); \
} while (0);

/**
 * @brief   Disables the USB peripheral clock.
 *
 * @api
 */
#define cpmDisableUSB() \
do { \
  HS_PSO->USB_CFG |= (CPM_MOD_GATE | CPM_BUS_GATE); \
} while (0);

/**
 * @brief   Resets the USB peripheral.
 *
 * @api
 */
#define cpmResetUSB() \
do { \
  HS_PSO->USB_CFG &= ~(CPM_MOD_RST | CPM_BUS_RST); \
  HS_PSO->USB_CFG |= (CPM_MOD_RST | CPM_BUS_RST); \
} while (0)
/** @} */

/**
 * @name    SDHC peripheral specific CPM operations
 * @{
 */
/**
 * @brief   Enables the SDHC peripheral clock.
 *
 * @api
 */
#define cpmEnableSDHC() \
  do {\
    HS_PSO->SD_CFG &= ~(CPM_BUS_GATE); \
    HS_PSO->SD_CFG |= (CPM_CLK_DEN); \
  }while(0)

/**
 * @brief   Disables the SDHC peripheral clock.
 *
 * @api
 */
#define cpmDisableSDHC() \
  do {\
    HS_PSO->SD_CFG |= (CPM_BUS_GATE); \
    HS_PSO->SD_CFG &= ~(CPM_CLK_DEN); \
  }while(0)
    

/**
 * @brief   Resets the SDHC peripheral.
 * @note    Not supported in this family, does nothing.
 *
 * @api
 */
#define cpmResetSDHC() \
do { \
  HS_PSO->SD_CFG &= ~(1 << 2); \
  HS_PSO->SD_CFG |= (1 << 2); \
} while (0)
/** @} */

/**
 * @name    SPI peripherals specific CPM operations
 * @{
 */
/**
 * @brief   Enables the SPI0 peripheral clock.
 *
 * @api
 */
#define cpmEnableSPI0() HS_PSO->SPI0_CFG &= ~(CPM_BUS_GATE)

/**
 * @brief   Disables the SPI0 peripheral clock.
 *
 * @api
 */
#define cpmDisableSPI0() HS_PSO->SPI0_CFG |= (CPM_BUS_GATE)

/**
 * @brief   Resets the SPI0 peripheral.
 *
 * @api
 */
#define cpmResetSPI0() \
do { \
  HS_PSO->SPI0_CFG &= ~(CPM_BUS_RST); \
  HS_PSO->SPI0_CFG |= (CPM_BUS_RST); \
} while (0)

/**
 * @brief   Enables the SPI1 peripheral clock.
 *
 * @api
 */
#define cpmEnableSPI1() HS_PSO->SPI1_CFG &= ~(CPM_BUS_GATE)

/**
 * @brief   Disables the SPI1 peripheral clock.
 *
 * @api
 */
#define cpmDisableSPI1() HS_PSO->SPI1_CFG |= (CPM_BUS_GATE)

/**
 * @brief   Resets the SPI1 peripheral.
 *
 * @api
 */
#define cpmResetSPI1() \
do { \
  HS_PSO->SPI1_CFG &= ~(CPM_BUS_RST); \
  HS_PSO->SPI1_CFG |= (CPM_BUS_RST); \
} while (0)
/** @} */

/**
 * @name    TIM peripherals specific CPM operations
 * @{
 */
/**
 * @brief   Enables the TIM0 peripheral clock.
 *
 * @api
 */
#define cpmEnableTIM0() \
  do {\
    HS_PSO->TIM0_CFG &= ~(CPM_BUS_GATE); \
    HS_PSO->TIM0_CFG |= (CPM_CLK_DEN);   \
  }while(0)

/**
 * @brief   Disables the TIM0 peripheral clock.
 *
 * @api
 */
#define cpmDisableTIM0() \
  do {\
    HS_PSO->TIM0_CFG |= (CPM_BUS_GATE);   \
    HS_PSO->TIM0_CFG &= ~(CPM_CLK_DEN);    \
  }while(0)

/**
 * @brief   Resets the TIM0 peripheral.
 *
 * @api
 */
#define cpmResetTIM0() \
do { \
  HS_PSO->TIM0_CFG &= ~(CPM_MOD_RST | CPM_BUS_RST); \
  HS_PSO->TIM0_CFG |= (CPM_MOD_RST | CPM_BUS_RST); \
} while (0)

/**
 * @brief   Enables the TIM1 peripheral clock.
 *
 * @api
 */
#define cpmEnableTIM1() \
  do {\
    HS_PSO->TIM1_CFG &= ~(CPM_BUS_GATE); \
    HS_PSO->TIM1_CFG |= (CPM_CLK_DEN);   \
  }while(0)

/**
 * @brief   Disables the TIM1 peripheral clock.
 *
 * @api
 */
#define cpmDisableTIM1() \
  do {\
    HS_PSO->TIM1_CFG |= (CPM_BUS_GATE);   \
    HS_PSO->TIM1_CFG &= ~(CPM_CLK_DEN);    \
  }while(0)

/**
 * @brief   Resets the TIM1 peripheral.
 *
 * @api
 */
#define cpmResetTIM1() \
do { \
  HS_PSO->TIM1_CFG &= ~(CPM_MOD_RST | CPM_BUS_RST); \
  HS_PSO->TIM1_CFG |= (CPM_MOD_RST | CPM_BUS_RST); \
} while (0)

/**
 * @brief   Enables the TIM2 peripheral clock.
 *
 * @api
 */
#define cpmEnableTIM2() \
  do {\
    HS_PSO->TIM2_CFG &= ~(CPM_BUS_GATE); \
    HS_PSO->TIM2_CFG |= (CPM_CLK_DEN);   \
  }while(0)

/**
 * @brief   Disables the TIM2 peripheral clock.
 *
 * @api
 */
#define cpmDisableTIM2() \
  do {\
    HS_PSO->TIM2_CFG |= (CPM_BUS_GATE);   \
    HS_PSO->TIM2_CFG &= ~(CPM_CLK_DEN);    \
  }while(0)

/**
 * @brief   Resets the TIM2 peripheral.
 *
 * @api
 */
#define cpmResetTIM2() \
do { \
  HS_PSO->TIM2_CFG &= ~(CPM_MOD_RST | CPM_BUS_RST); \
  HS_PSO->TIM2_CFG |= (CPM_MOD_RST | CPM_BUS_RST); \
} while (0)
/** @} */

/**
 * @name    UART peripherals specific CPM operations
 * @{
 */
/**
 * @brief   Enables the UART0 peripheral clock.
 *
 * @api
 */
#define cpmEnableUART0() \
  do { \
    HS_PSO->UART0_CFG &= ~(CPM_BUS_GATE);  \
    HS_PSO->UART0_CFG |= (CPM_CLK_DEN);  \
  }while(0)

/**
 * @brief   Disables the UART0 peripheral clock.
 *
 * @api
 */
#define cpmDisableUART0()  \
  do { \
    HS_PSO->UART0_CFG |= (CPM_BUS_GATE);  \
    HS_PSO->UART0_CFG &= ~(CPM_CLK_DEN);  \
  }while(0)

/**
 * @brief   Resets the UART0 peripheral.
 *
 * @api
 */
#define cpmResetUART0() \
do { \
  HS_PSO->UART0_CFG &= ~(CPM_MOD_RST | CPM_BUS_RST); \
  HS_PSO->UART0_CFG |= (CPM_MOD_RST | CPM_BUS_RST); \
} while (0)

/**
 * @brief   Enables the UART1 peripheral clock.
 *
 * @api
 */
#define cpmEnableUART1() \
  do { \
    HS_PSO->UART1_CFG &= ~(CPM_BUS_GATE);  \
    HS_PSO->UART1_CFG |= (CPM_CLK_DEN);  \
  }while(0)

/**
 * @brief   Disables the UART1 peripheral clock.
 *
 * @api
 */
#define cpmDisableUART1()  \
  do { \
    HS_PSO->UART1_CFG |= (CPM_BUS_GATE);  \
    HS_PSO->UART1_CFG &= ~(CPM_CLK_DEN);  \
  }while(0)

/**
 * @brief   Resets the UART1 peripheral.
 *
 * @api
 */
#define cpmResetUART1() \
do { \
  HS_PSO->UART1_CFG &= ~(CPM_MOD_RST | CPM_BUS_RST); \
  HS_PSO->UART1_CFG |= (CPM_MOD_RST | CPM_BUS_RST); \
} while (0)

#if defined(BR3215c)
/**
 * @brief   Enables the UART2 peripheral clock.
 *
 * @api
 */
#define cpmEnableUART2() \
  do { \
    HS_PSO->UART2_CFG &= ~(CPM_BUS_GATE);  \
    HS_PSO->UART2_CFG |= (CPM_CLK_DEN);  \
  }while(0)

/**
 * @brief   Disables the UART1 peripheral clock.
 *
 * @api
 */
#define cpmDisableUART2()  \
  do { \
    HS_PSO->UART2_CFG |= (CPM_BUS_GATE);  \
    HS_PSO->UART2_CFG &= ~(CPM_CLK_DEN);  \
  }while(0)

/**
 * @brief   Resets the UART1 peripheral.
 *
 * @api
 */
#define cpmResetUART2() \
do { \
  HS_PSO->UART2_CFG &= ~(CPM_MOD_RST | CPM_BUS_RST); \
  HS_PSO->UART2_CFG |= (CPM_MOD_RST | CPM_BUS_RST); \
} while (0)

#endif
/**
 * @brief   Enables the RAM clock Auto GATE.
 *
 * @api
 */
#define cpmEnableAutoGateRAMClock() HS_PSO->CPM_GATE_CFG |= (1 << 0)

/**
 * @brief   Disables the RAM clock Auto GATE.
 *
 * @api
 */
#define cpmDisableAutoGateRAMClock() HS_PSO->CPM_GATE_CFG &= (~(1 << 0))

/**
 * @brief   Resets the PSO_CPM peripheral.
 *
 * @api
 */
#define cpmResetPSOCPM()  \
do { \
    HS_PSO->CPM_GATE_CFG &= ~(1 << 5);		\
    HS_PSO->CPM_GATE_CFG |= (1 << 5);    \
}while (0)


/**
 * @brief   Enables RTC clock.
 * @api
 */
#define cpmEnableRTC()

/**
 * @brief   Disables RTC clock.
 * @api
 */
#define cpmDisableRTC()

/**
 * @brief   Resets the RTC peripheral.
 *
 * @api
 */
#define cpmResetRTC()  \
do { \
    HS_PMU_CPM->RTC_CFG &= (~((1<<2)|(1<<4))) ;		\
    HS_PMU_CPM->RTC_CFG |= (1<<2)|(1<<4);    \
}while (0)

/**
 * @brief   Enable 32k waveform output on pin PC0=GPIO24 or PC1=GPIO25.
 *
 * @api
 */
#define cpmEnableRc32kOutput()\
	(HS_ANA->COMMON_CFG[1] |= (1U<<20))

/**
 * @brief   Disable 32k waveform output on pin PC0=GPIO24 or PC1=GPIO25.
 *
 * @api
 */
#define cpmDisableRc32kOutput()\
	(HS_ANA->COMMON_CFG[1] &= ~(7U<<20))

/**
 * @brief    Disable pd_chg, pd_ioldo_v3p3 (normal)
 * @api
 */
#define cpmDisableMisc() HS_PMU->ANA_CON |= ((1 << 5) | (1 << 28))

/**
 * @brief    Enable pd_chg, pd_ioldo_v3p3 (normal,wakeup)
 * @api
 */
#define cpmEnableMisc() HS_PMU->ANA_CON &= ~((1 << 5) | (1 << 28) | (1 << 27))

/**
 * @brief    Disable charger
 * @api
 */
#define cpmDisableCharger() HS_PMU->ANA_CON |= (1 << 5)

/**
 * @brief    Enable charger
 * @api
 */
#define cpmEnableCharger() HS_PMU->ANA_CON &= ~(1 << 5)

/**
 * @brief    Disable voltage comparators.
 * @api
 */
#if defined(BR3215)
#define cpmDisableComparator()                  \
  do {                                          \
    /* [16]pd_vbus_det for BR3215 */            \
    HS_SYS->USB_CTRL |= (1<<16);                \
  } while (0)
#elif defined(BR3215e)
#define cpmDisableComparator()                  \
  do {                                          \
    /* [4]pd_vbus_det */                        \
    HS_PMU->ANA_CON |= (1<<4);                  \
    /* [8]pd_vbat_det */                        \
    HS_PMU->ANA_CON1 |= (1<<8);                 \
  } while (0)
#endif

/**
 * @brief    Enable voltage comparators.
 * @api
 */
#if defined(BR3215)
#define cpmEnableComparator()                   \
  do {                                          \
    /* [16]pd_vbus_det for BR3215 */            \
    HS_SYS->USB_CTRL &= ~(1<<16);               \
  } while (0)
#elif defined(BR3215e)
#define cpmEnableComparator()                   \
  do {                                          \
    /* [4]pd_vbus_det */                        \
    HS_PMU->ANA_CON &= ~(1<<4);                 \
    /* [8]pd_vbat_det */                        \
    HS_PMU->ANA_CON1 &= ~(1<<8);                \
  } while (0)
#endif


/**
 * @brief   PMU power off PSO domain to enter deep sleep; wakeup from power pin
 * @api
 */
#define pmu_poweroff_pso() \
do { \
   HS_PMU->PSO_PM_CON = ((HS_PMU->PSO_PM_CON&0xfffffffc) | PMU_POWER_OFF | (1u<<24)); \
} while (0)

/**
 * @brief   PMU power off ram domain
 * @api
 */
#if defined(BR3215c) || defined(BR3215e)
#define pmu_poweroff_ram() \
do { \
  HS_PMU->RETEN_PM_CON &= ~0x03; /* clear bit[1..0] */\
  HS_PMU->RETEN_PM_CON |= 0x02; /* set bit[1..0] = 2'b10 */\
	/* reten_wake_by_hw: RETEN_PM_CON[16]*/\
	/* Set it so SRAM can be waken up by rtc, ceva, and pa0,*/\
	/* otherwise it can only be waken up by register.*/\
	/* Hardware bug:*/\
	/* Write to this bit is valid, but read value of it always is 0.*/\
	HS_PMU->RETEN_PM_CON |= (1UL<<16);\
  pmu_reg_update(); \
} while (0)
#else
#define pmu_poweroff_ram() \
do { \
   HS_PMU->RAM_PM_CON = ((HS_PMU->RAM_PM_CON&0xfffffffc) | PMU_POWER_OFF); \
   pmu_reg_update();                  \
} while (0)
#endif
/**
 * @brief   PMU power off CEVA0 domain
 * @api
 */
#define pmu_poweroff_ceva0() \
do { \
   HS_PMU->CEVA0_PM_CON = ((HS_PMU->CEVA0_PM_CON&0xfffffffc) | PMU_POWER_OFF); \
   pmu_reg_update();                  \
} while (0)

/**
 * @brief   PMU power on CEVA0 domain
 * @api
 */
#define pmu_poweron_ceva0() \
do { \
   HS_PMU->CEVA0_PM_CON |= PMU_POWER_OFF; \
   pmu_reg_update();                  \
} while (0)

/**
 * @brief   PMU power off CEVA1  domain
 * @api
 */
#define pmu_poweroff_ceva1() \
do { \
   HS_PMU->CEVA1_PM_CON = ((HS_PMU->CEVA1_PM_CON&0xfffffffc) | PMU_POWER_OFF); \
   pmu_reg_update();                  \
} while (0)


/**
 * @brief   PMU power off PSO domain to enter deep sleep; wakeup from power pin
 * @api
 */
#define pmu_poweroff_mcu() \
do { \
  HS_PMU->BASIC |= (1<<7);               \
  pmu_reg_update();                  \
} while (0)

/**
 * Turn off gpio's main power and wake-up power.
 * 1-on, 0-off.
 * (opposite to register bit level)
 */
#define pmu_poweroff_io(main, wakeup) \
do {\
		uint32_t reg = HS_PMU->ANA_CON;\
		reg &= ~(0x03UL<<27); /* clear bit[28..27] */\
		reg |= ((((~main)&1UL)<<28) | (((~wakeup)&1UL)<<27));\
		HS_PMU->ANA_CON = reg;\
} while (0)

/* turn off v2p5 ldo */
#define pmu_poweroff_v2p5_ldo()\
	(HS_PMU->ANA_CON |= (1UL<<10))

/* turn off rf ldo */
#define pmu_poweroff_rf_ldo()\
	(HS_PMU->ANA_CON |= (1UL<<13))

/* turn off dvdd12 */
#define pmu_poweroff_dvdd12()\
	(HS_PMU->EXT |= (1UL<<9))

/* turn on dvdd12 */
#define pmu_poweron_dvdd12()\
	(HS_PMU->EXT &= ~(1UL<<9))

/**
 * @brief   Get xtal selection between 16MHz and 24MHz through pin 20.
 *          0 for 16MHz, 1 for 24MHz.
 */
#if defined(BR3215)
#define CPM_GetXtalSel()      ( (HS_PMU->GPIO_STATUS[0] >> 20  ) & 0x1u )
#else /* BR3215c/e */
#define CPM_GetXtalSel()      ( 0 ) // Permanent use of 16MHz Xtal.
#endif

/**
 * @brief   Set xtal selection to be 16MHz/24MHz.
 * @note    HS_PMU->PMU_CLOCK_MUX[31]:
 *          0 = 16MHz, 1 = 24MHz: for BR3215 and BR3215c, reset value is 0.
 *          0 = 24MHz, 1 = 16MHz: for BR3215e, reset value is 1.
 */
#if defined(BR3215)
#define CPM_SetXtalSel_16MHz() \
do {\
		HS_PMU->PMU_CLOCK_MUX &= ~(1u<<31);       /* BR3215A4 */\
		HS_ANA->SDM_CFG |= (1u<<16);              /* BR3215A3 */\
} while (0)

#define CPM_SetXtalSel_24MHz() \
do {\
		HS_PMU->PMU_CLOCK_MUX |= (1u<<31);        /* BR3215A4 */\
		HS_ANA->SDM_CFG &= ~(1u<<16);             /* BR3215A3 */\
} while (0)
#elif defined(BR3215c)
#define CPM_SetXtalSel_16MHz() \
do {\
		HS_PMU->PMU_CLOCK_MUX &= ~(1U<<31);  \
} while (0)

#define CPM_SetXtalSel_24MHz() \
do {\
		HS_PMU->PMU_CLOCK_MUX |= (1U<<31);  \
} while (0)
#elif defined(BR3215e)
#define CPM_SetXtalSel_16MHz() \
do {\
		HS_PMU->PMU_CLOCK_MUX |= (1U<<31);   \
} while (0)

#define CPM_SetXtalSel_24MHz() \
do {\
		HS_PMU->PMU_CLOCK_MUX &= ~(1U<<31);   \
} while (0)
#else
#define CPM_SetXtalSel_16MHz()
#define CPM_SetXtalSel_24MHz()
#endif

/**
 * @brief   Switch on digital clock of 192MHz from PLL.
 */
#define pmu_switch_on_digital_clock() \
do {\
	HS_PMU->EXT &= ~(1U<<2);\
} while (0)

/**
 * @brief   Switch off digital clock of 192MHz from PLL.
 */
#define pmu_switch_off_digital_clock() \
do {\
	HS_PMU->EXT |= (1U<<2);\
} while (0)


/**
 * @brief   Switch RTC clock source to internal RC OSC 32KHz (LSI)
 *          / deriving from XTAL OSC 16MHz (HSI).
 * @note    for BR3215:
 *              1 = RC 32k,   0 = XTAL 32k;
 *          for BR3215c or BR3215e:
 *              1 = XTAL 32k, 0 = RC 32k;
 */
#if defined(BR3215)
#define pmu_switch_rtc_clk_to_rc32k() \
do {\
	HS_PMU->PMU_CLOCK_MUX |= (1U<<28);\
} while (0)

#define pmu_switch_rtc_clk_to_xtal32k() \
do {\
	HS_PMU->PMU_CLOCK_MUX &= ~(1U<<28);\
} while (0)
#elif defined(BR3215c) || defined(BR3215e)
#define pmu_switch_rtc_clk_to_rc32k() \
do {\
	HS_PMU->PMU_CLOCK_MUX &= ~(1U<<28);\
} while (0)

#define pmu_switch_rtc_clk_to_xtal32k() \
do {\
	HS_PMU->PMU_CLOCK_MUX |= (1U<<28);\
} while (0)
#endif

/**
 * @brief   Calibrate the internal 32.000KHz RC oscillator.
 * @note    Not 32.768KHz. Used for RTC and BlueTooth.
 */
#if defined(BR3215c)
#define pmu_rc32k_cal() \
do {\
	HS_PMU->RC_32K_TUNE &= ~(1U<<28);         /* reset RC 32K calibration with */\
	                                          /* pose-edge in BR3215c ver A3.*/\
	HS_PMU->RC_32K_TUNE |= (1U<<28 | 1U<<16); /* start RC 32K calibration.*/\
	while (HS_PMU->RC_32K_TUNE & (1U<<16));   /* wait for calibration done*/\
} while (0)
#elif defined(BR3215e)
#define pmu_rc32k_cal() \
do {\
	HS_PMU->RC_32K_TUNE |= (1U<<16);          /* start RC 32K calibration.*/\
	while (HS_PMU->RC_32K_TUNE & (1U<<16));   /* wait for calibration done*/\
} while (0)
#endif

#if defined(BR3215c)
/**
 * @brief   BR3215C enter deep sleep mode.
 * @note    Define it in macro format to enable its use in
 *          "misc reten off" test where RAM is powered off.
 */
#define pmu_deep_sleep() \
do {\
	/* digital power LDO output voltage:*/\
	int v = 10;\
	HS_PMU->PMU_CLOCK_MUX &= ~(0x60UL);     /* clear bit[6..5] */\
	if (v == 00)\
		HS_PMU->PMU_CLOCK_MUX |= 0x00UL;    /* 00 = 1.1v */\
	else if (v == 01)\
		HS_PMU->PMU_CLOCK_MUX |= 0x20UL;    /* 01 = 1.0v */\
	else if (v == 10)\
		HS_PMU->PMU_CLOCK_MUX |= 0x40UL;    /* 10 = 1.2v */\
	else if (v == 11)\
		HS_PMU->PMU_CLOCK_MUX |= 0x60UL;    /* 11 = 1.3v */\
	\
	/* turn off io's main power, keep its wake-up power. */\
	pmu_poweroff_io(0, 1);\
	pmu_poweroff_v2p5_ldo();\
	pmu_poweroff_rf_ldo();\
	\
	/* cpm_switch_to_xtal() { */\
		HS_PMU_CPM->PLL_SRC_CFG = 0x0;\
		__WFD();\
	/* } */\
	\
	HS_PMU->PSO_PM_CON = 0x40080402;\
} while (0)
#endif

/**
 * @brief   Set the IOLDO output voltage
 * @note    PMU_CLOCK_MUX[12:11].
 *
 * @param ctrl   0: 1.8V;
 *               1: 3.3V;
 *               2: 3.2V;
 *               3: 3.1V.
 */
#if defined(BR3215c)
#define pmu_set_ioldo(ctrl) \
do {\
	HS_PMU->PMU_CLOCK_MUX &= ~(0x03<<11); \
	HS_PMU->PMU_CLOCK_MUX |=  (ctrl<<11); \
} while (0)
#endif

/**
 * @brief   Set the DVDD12, the digital core voltage.
 * @param[in]  ctrl           0: 1.1V
 *                            1: 1.0V
 *                            2: 1.2V
 *                            3: 1.3V
 */
#if defined(BR3215)
#define pmu_set_dvdd12(ctrl)                                            \
  do {                                                                  \
    /* b'01 is b'11 for BR3215A4 */                                     \
    uint8_t bits = (ctrl) ^ 0x2;                                        \
    HS_ANA->REGS.LDO_DIG_ADJ = (ctrl);                                  \
    HS_PMU->PMU_CLOCK_MUX = (HS_PMU->PMU_CLOCK_MUX & ~(0x3 << 5u)) | (bits << 5u); \
  } while (0)
#elif defined(BR3215c)
#define pmu_set_dvdd12(ctrl)                                            \
  do {                                                                  \
    HS_PMU->PMU_CLOCK_MUX = (HS_PMU->PMU_CLOCK_MUX & ~(0x3 << 5u)) | ((ctrl) << 5u); \
  } while (0)
#elif defined(BR3215e)
#define pmu_set_dvdd12(ctrl)                                            \
  do {                                                                  \
    HS_PMU->ANA_CON0 = (HS_PMU->ANA_CON0 & ~(0x3 << 5u)) | ((ctrl) << 5u); \
  } while (0)
#endif

/**
 * @brief   Set power pin debource time.
 * @note    New added since BR3215C.
 *
 * @param debource   Valid value can be [0, 1, 2, 3, 4, 5] which
 *                   correspond to [0, 14, 62, 500, 1000, 2000] ms.
 */
#define pmu_power_pin_debource(debounce)\
do {\
	HS_PMU->CHIP_PM_PIN &= ~(0x7u<<14);\
  	HS_PMU->CHIP_PM_PIN |= debounce<<14;\
  	pmu_reg_update();\
} while (0)

/**
 * @brief   Reset chip.
 * @warning Be careful not calling this function automatically and unconditionally
 *          after system starts, or the system will fall into restarting loop
 *          for ever.
 */
#define pmu_reset_chip()\
do {\
	HS_PMU->OPT_RESET_CON &= ~(1u<<25);\
} while (0)


/**
 * @brief  Start Performance counter. (PFMC0,1,2)
 * @note   Performance counter can be used as high speed counter to achieve
 *         microseconds delay.
 * n: 0, 1, 2
 */
#define cpm_start_performance_counter(n) \
do { \
  __nds32__mtsr(__nds32__mfsr(NDS32_SR_PFM_CTL) | (1u<<n), NDS32_SR_PFM_CTL); \
} while (0)

/**
 * n: 0, 1, 2
 */
#define cpm_stop_performance_counter(n) \
do { \
  __nds32__mtsr(__nds32__mfsr(NDS32_SR_PFM_CTL) & ~(1u<<n), NDS32_SR_PFM_CTL); \
} while (0)

/**
 * @brief  Enter to ISP mode.
 * @note   Reboot MCU to bootflash program.
 */
#define cpm_enter_isp_mode()                    \
  do {                                          \
    HS_PMU->SCRATCH1 |= SCRATCH_SW_ISP_MODE;    \
    cpmResetMCU();                              \
  } while (0)

/**
 * @brief  Check whether Test NG mode.
 */
#define cpm_is_test_ng_mode()                                       \
  ({                                                                \
    uint8_t ret = HS_PMU->SCRATCH1 & SCRATCH_TEST_NG_MODE ? 1 : 0;  \
    ret;                                                            \
  })

/*===========================================================================*/
/* External declarations.                                                    */
/*===========================================================================*/

#ifdef __cplusplus
extern "C" {
#endif
  /* remove later */
  void cpm_switch_to_pll(void);
  void cpm_switch_to_xtal(void);

  /**
   * @brief Get the control word of XTAL's load capacity for RF frequency drift
   */
  uint8_t cpm_get_xtal_cap(void);
  /**
   * @brief Set the control word of XTAL's load capacity for RF frequency drift
   * @param[in]   xtal_cap    the control word
   *                            16=+ 0kHz
   *                            12=+20kHz
   *                             8=+40kHz
   *                             4=+60kHz
   *                            20=-10kHz
   *                            24=-20kHz
   *                            28=-30kHz
   *                            31=-40kHz
   */
  void cpm_set_xtal_cap(uint8_t xtal_cap);

  void cpm_init_clock(void);
  uint32_t cpm_get_clock(hs_clk_t idx);
  void cpm_set_clock(hs_clk_t idx, uint32_t hz);

  /**
   * @brief   Set system main frequency, including CPU & AHB clocks
   * @param[in]  mhz          system main frequency in mhz
   *                          192,96,48,16,0(lowest@XTAL)
   */
  void cpm_set_main_freq(int mhz);

  void cpm_set_sf_clock_delay(uint8_t half_cycle);
  void cpm_set_sd_dev_clock(sd_dev_clk_t *sd_dev_clk);
  void sf_inner_select(sf_loc_t loc);

  void pmu_xclkon_insleep(int on);
  void pmu_deep_sleep_with_wakeup(
  		uint32_t gpio_bitmap,
  		uint32_t gpio_mask_bitmap,
  		uint32_t gpio_polar_bitmap
  		);

  /**
   * @brief MCU enters deep sleep.
   * @note  The systme is wokeup by a specific input.
   */
  #if defined(BR3215) || defined(BR3215e)
  void pmu_deep_sleep(void);
  #endif

  /**
   * @brief MCU power off.
   * @note  The next power cycle by the power pin.
   */
  void pmu_power_off(void);

  uint32_t pmu_ana_get(uint32_t start, uint32_t end);
  void pmu_ana_set(uint32_t start, uint32_t end, uint32_t val);
  void pmu_cali_rc(void);
  void pmu_cali_ldo(void);
  void pmu_cali_result(pmu_tune_shadow_t *p_result);

#if defined(BR3215c) || defined(BR3215e)
  void pmu_cal_rc_32k(void);
#endif

  void delay_nops(int cnt);
  void cpm_delay_us(uint32_t us);
  void cpm_enable_dcdc(uint8_t en);
#ifdef __cplusplus
}
#endif

#endif /* _HAL_CPM_H_ */

/** @} */
