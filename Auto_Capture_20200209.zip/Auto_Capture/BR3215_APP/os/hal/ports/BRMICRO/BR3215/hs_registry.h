/*
    ChibiOS - Copyright (C) 2006..2015 Giovanni Di Sirio

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    BR3215/hs_registry.h
 * @brief   BR3215 capabilities registry.
 *
 * @addtogroup HAL
 * @{
 */

#ifndef _HS_REGISTRY_H_
#define _HS_REGISTRY_H_

//#define BR3215   //audio version
//#define BR3215c  //data version
//#define BR3215e  //audio classic version


/**
 * @brief   Sub-family identifier.
 */
#if !defined(BR3215x) || defined(__DOXYGEN__)
#define BR3215x
#endif

/*===========================================================================*/
/* Platform capabilities.                                                    */
/*===========================================================================*/

/**
 * @name    BR3215x capabilities
 * @{
 */
#if defined(BR3215)
/* Andes core attributes. */
#define NDS_HAS_iCACHE                   TRUE
#define NDS_HAS_dCACHE                   TRUE
#define NDS_HAS_iLM                      FALSE
#define NDS_HAS_dLM                      FALSE

/* ADC attributes.*/
#define HS_HAS_ADC0                      TRUE
#define HS_ADC0_RX_DMA_ID                0
#define HS_ADC0_RESOLUTION               12    // bits
#define HS_ADC_HAS_HARD_CAL              FALSE // hard calibration

/* DMA attributes.*/
#define HS_ADVANCED_DMA                  TRUE
#define HS_HAS_DMA                       TRUE
#define HS_DMA_NUM_CHANNELS              3

/* GPIO attributes.*/
#define HS_HAS_GPIO0                     TRUE
#define HS_HAS_GPIO1                     TRUE

/* I2C attributes.*/
#define HS_HAS_I2C0                      TRUE
#define HS_I2C0_RX_DMA_ID                2
#define HS_I2C0_TX_DMA_ID                3
#define HS_I2C_HAS_SELF_DMA              FALSE

/* RTC attributes.*/
#define HS_HAS_RTC_STM32                 TRUE
#define HS_RTC_HAS_SUBSECONDS            TRUE
#define HS_RTC_HAS_PERIODIC_WAKEUPS      TRUE
#define HS_RTC_NUM_ALARMS                2
#define HS_RTC_HAS_INTERRUPTS            TRUE
#define HS_HAS_RTC_YGW                   FALSE

/* SDIO attributes.*/
#define HS_HAS_SDIO                      TRUE
/* MSR attributes.*/
#define HS_HAS_MSR                       FALSE

/* SPI attributes.*/
#define HS_HAS_SPI0                      TRUE
#define HS_SPI0_RX_DMA_ID                2
#define HS_SPI0_TX_DMA_ID                3

#define HS_HAS_SPI1                      TRUE
#define HS_SPI1_RX_DMA_ID                2
#define HS_SPI1_TX_DMA_ID                3

/* TIM attributes.*/
#define HS_TIM_MAX_CHANNELS              4

#define HS_HAS_TIM0                      TRUE
#define HS_TIM0_IS_32BITS                FALSE
#define HS_TIM0_CHANNELS                 4

#define HS_HAS_TIM1                      TRUE
#define HS_TIM1_IS_32BITS                FALSE
#define HS_TIM1_CHANNELS                 4

#define HS_HAS_TIM2                      TRUE
#define HS_TIM2_IS_32BITS                FALSE
#define HS_TIM2_CHANNELS                 4

/* UART attributes.*/
#define HS_HAS_UART0                     TRUE

#define HS_HAS_UART1                     TRUE
#define HS_UART1_RX_DMA_ID               2
#define HS_UART1_TX_DMA_ID               1

#define HS_HAS_UART2                     FALSE

/* USB attributes.*/
#define HS_HAS_USB                       TRUE
#define HS_USB_NUM_ENDPOINTS             3 /* in addition to EP0 */
#define HS_USB_FIFO_SIZE                 512
#define HS_USB_NUM_DMA_CHANNELS          4

#endif

#if defined(BR3215c)
/* Andes core attributes. */
#define NDS_HAS_iCACHE                   TRUE
#define NDS_HAS_dCACHE                   TRUE
#define NDS_HAS_iLM                      FALSE
#define NDS_HAS_dLM                      FALSE

/* ADC attributes.*/
#define HS_HAS_ADC0                      TRUE
#define HS_ADC0_RX_DMA_ID                0
#define HS_ADC0_RESOLUTION               12   // bits
#define HS_ADC_HAS_HARD_CAL              TRUE // hard calibration

/* DMA attributes.*/
#define HS_ADVANCED_DMA                  FALSE
#define HS_HAS_DMA                       FALSE

/* GPIO attributes.*/
#define HS_HAS_GPIO0                     TRUE
#define HS_HAS_GPIO1                     TRUE

/* I2C attributes.*/
#define HS_HAS_I2C0                      TRUE
#define HS_I2C0_RX_DMA_ID                2
#define HS_I2C0_TX_DMA_ID                3
#define HS_I2C_HAS_SELF_DMA              TRUE

/* RTC attributes.*/
#define HS_HAS_RTC_STM32                 TRUE
#define HS_RTC_HAS_SUBSECONDS            TRUE
#define HS_RTC_HAS_PERIODIC_WAKEUPS      TRUE
#define HS_RTC_NUM_ALARMS                2
#define HS_RTC_HAS_INTERRUPTS            TRUE
#define HS_HAS_RTC_YGW                   FALSE

/* SDIO attributes.*/
#define HS_HAS_SDIO                      FALSE
/* MSR attributes.*/
#define HS_HAS_MSR                       FALSE

/* SPI attributes.*/
#define HS_HAS_SPI0                      TRUE
#define HS_SPI0_RX_DMA_ID                2
#define HS_SPI0_TX_DMA_ID                3

#define HS_HAS_SPI1                      TRUE
#define HS_SPI1_RX_DMA_ID                2
#define HS_SPI1_TX_DMA_ID                3

/* TIM attributes.*/
#define HS_TIM_MAX_CHANNELS              4

#define HS_HAS_TIM0                      TRUE
#define HS_TIM0_IS_32BITS                FALSE
#define HS_TIM0_CHANNELS                 4

#define HS_HAS_TIM1                      TRUE
#define HS_TIM1_IS_32BITS                FALSE
#define HS_TIM1_CHANNELS                 4

#define HS_HAS_TIM2                      TRUE
#define HS_TIM2_IS_32BITS                FALSE
#define HS_TIM2_CHANNELS                 4

/* UART attributes.*/
#define HS_HAS_UART0                     TRUE

#define HS_HAS_UART1                     TRUE
#define HS_UART1_RX_DMA_ID               2
#define HS_UART1_TX_DMA_ID               1

#define HS_HAS_UART2                     TRUE

/* USB attributes.*/
#define HS_HAS_USB                       FALSE

#endif

#if defined(BR3215e)
/* Andes core attributes. */
#define NDS_HAS_iCACHE                   TRUE
#define NDS_HAS_dCACHE                   TRUE
#define NDS_HAS_iLM                      FALSE
#define NDS_HAS_dLM                      FALSE

/* ADC attributes.*/
#define HS_HAS_ADC0                      TRUE
#define HS_ADC0_RX_DMA_ID                0
#define HS_ADC0_RESOLUTION               12   // bits
#define HS_ADC_HAS_HARD_CAL              TRUE // hard calibration

/* DMA attributes.*/
#define HS_ADVANCED_DMA                  TRUE
#define HS_HAS_DMA                       TRUE
#define HS_DMA_NUM_CHANNELS              3

/* GPIO attributes.*/
#define HS_HAS_GPIO0                     TRUE
#define HS_HAS_GPIO1                     TRUE

/* I2C attributes.*/
#define HS_HAS_I2C0                      TRUE
#define HS_I2C0_RX_DMA_ID                2
#define HS_I2C0_TX_DMA_ID                3
#define HS_I2C_HAS_SELF_DMA              TRUE

/* RTC attributes.*/
#define HS_HAS_RTC_STM32                 FALSE
#define HS_HAS_RTC_YGW                   TRUE

/* SDIO attributes.*/
#define HS_HAS_SDIO                      TRUE
/* MSR attributes.*/
#define HS_HAS_MSR                       FALSE

/* SPI attributes.*/
#define HS_HAS_SPI0                      TRUE
#define HS_SPI0_RX_DMA_ID                2
#define HS_SPI0_TX_DMA_ID                3

#define HS_HAS_SPI1                      TRUE
#define HS_SPI1_RX_DMA_ID                2
#define HS_SPI1_TX_DMA_ID                3

/* TIM attributes.*/
#define HS_TIM_MAX_CHANNELS              4

#define HS_HAS_TIM0                      TRUE
#define HS_TIM0_IS_32BITS                FALSE
#define HS_TIM0_CHANNELS                 4

#define HS_HAS_TIM1                      TRUE
#define HS_TIM1_IS_32BITS                FALSE
#define HS_TIM1_CHANNELS                 4

#define HS_HAS_TIM2                      TRUE
#define HS_TIM2_IS_32BITS                FALSE
#define HS_TIM2_CHANNELS                 4

/* UART attributes.*/
#define HS_HAS_UART0                     TRUE

#define HS_HAS_UART1                     TRUE
#define HS_UART1_RX_DMA_ID               2
#define HS_UART1_TX_DMA_ID               1

#define HS_HAS_UART2                     FALSE

/* USB attributes.*/
#define HS_HAS_USB                       TRUE
#define HS_USB_NUM_ENDPOINTS             3 /* in addition to EP0 */
#define HS_USB_FIFO_SIZE                 512
#define HS_USB_NUM_DMA_CHANNELS          4

#endif

#if defined(BR3216)
/* Andes core attributes. */
#define NDS_HAS_iCACHE                   TRUE
#define NDS_HAS_dCACHE                   TRUE
#define NDS_HAS_iLM                      FALSE
#define NDS_HAS_dLM                      FALSE

/* ADC attributes.*/
#define HS_HAS_ADC0                      TRUE
#define HS_ADC0_RX_DMA_ID                0
#define HS_ADC0_RESOLUTION               12   // bits
#define HS_ADC_HAS_HARD_CAL              TRUE // hard calibration

/* DMA attributes.*/
#define HS_ADVANCED_DMA                  TRUE
#define HS_HAS_DMA                       TRUE
#define HS_DMA_NUM_CHANNELS              3

/* GPIO attributes.*/
#define HS_HAS_GPIO0                     TRUE
#define HS_HAS_GPIO1                     TRUE

/* I2C attributes.*/
#define HS_HAS_I2C0                      TRUE
#define HS_I2C0_RX_DMA_ID                2
#define HS_I2C0_TX_DMA_ID                3
#define HS_I2C_HAS_SELF_DMA              TRUE

/* RTC attributes.*/
#define HS_HAS_RTC_STM32                 FALSE
#define HS_HAS_RTC_YGW                   TRUE

/* SDIO attributes.*/
#define HS_HAS_SDIO                      FALSE
/* MSR attributes.*/
#define HS_HAS_MSR                       FALSE

/* SPI attributes.*/
#define HS_HAS_SPI0                      FALSE
#define HS_SPI0_RX_DMA_ID                2
#define HS_SPI0_TX_DMA_ID                3

#define HS_HAS_SPI1                      FALSE
#define HS_SPI1_RX_DMA_ID                2
#define HS_SPI1_TX_DMA_ID                3

/* TIM attributes.*/
#define HS_TIM_MAX_CHANNELS              4

#define HS_HAS_TIM0                      TRUE
#define HS_TIM0_IS_32BITS                FALSE
#define HS_TIM0_CHANNELS                 4

#define HS_HAS_TIM1                      FALSE
#define HS_TIM1_IS_32BITS                FALSE
#define HS_TIM1_CHANNELS                 4

#define HS_HAS_TIM2                      FALSE
#define HS_TIM2_IS_32BITS                FALSE
#define HS_TIM2_CHANNELS                 4

/* UART attributes.*/
#define HS_HAS_UART0                     FALSE

#define HS_HAS_UART1                     TRUE
#define HS_UART1_RX_DMA_ID               2
#define HS_UART1_TX_DMA_ID               1

#define HS_HAS_UART2                     FALSE

/* USB attributes.*/
#define HS_HAS_USB                       TRUE
#define HS_USB_NUM_ENDPOINTS             3 /* in addition to EP0 */
#define HS_USB_FIFO_SIZE                 512
#define HS_USB_NUM_DMA_CHANNELS          4

#endif
/** @} */


#undef HS_HAS_DMA
#define HS_HAS_DMA FALSE

#endif /* _HS_REGISTRY_H_ */

/** @} */
