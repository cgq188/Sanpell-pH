/*
    ChibiOS/RT - Copyright (C) 2006-2013 Giovanni Di Sirio
                 Copyright (C) 2019 BRMICRO Technologies
                 

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    br32xx/hal_lld.c
 * @brief   HAL Driver subsystem low level driver source template.
 *
 * @addtogroup HAL
 * @{
 */

#include "hal.h"

/*===========================================================================*/
/* Driver local definitions.                                                 */
/*===========================================================================*/

/*===========================================================================*/
/* Driver exported variables.                                                */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local variables and types.                                         */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local functions.                                                   */
/*===========================================================================*/

/*===========================================================================*/
/* Driver interrupt handlers.                                                */
/*===========================================================================*/

/*===========================================================================*/
/* Driver exported functions.                                                */
/*===========================================================================*/

/**
 * @brief   Low level HAL driver initialization.
 *
 * @notapi
 */
void hal_lld_init(void) {

#if 0
  /* Initialization of the vector table and priority related settings.*/
  uint32_t ivb = __nds32__mfsr(NDS32_SR_IVB);
  ivb = (ivb & 0x0000FFFF) | ANDES_VTOR_INIT;
  __nds32__mtsr(ivb, NDS32_SR_IVB);
  __nds32__mtsr(0xFFFFFFFF, NDS32_SR_INT_PRI);
  __nds32__mtsr(0xFFFFFFFF, NDS32_SR_INT_PRI2);
  __nds32__mtsr(0xFFFFFFFF, NDS32_SR_INT_PEND2);
#endif

#if (HS_HAS_DMA == TRUE)
  dmaInit();
#endif

  //cpmEnableBTPHY();

  /* Programmable voltage detector enable.*/
}

/**
 * @brief  Setup the microcontroller system
 *         Power on all RAM and misc before setup stack.
 * @note   This function should be used only after reset.
 *
 * @notapi
 */
void SystemInit(void) {
  /* power on RAM if its power status is off */
#if defined(BR3215)
  if (0 == HS_PMU->RAM_PM_CON) {
    /* wait ram power-on complete */
  }
#endif

  cpmEnableMisc();
  cpmResetBTPHY();
}

/** @} */
