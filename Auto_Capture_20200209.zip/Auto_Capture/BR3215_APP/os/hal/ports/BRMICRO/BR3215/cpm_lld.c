/*
    ChibiOS/RT - Copyright (C) 2006-2013 Giovanni Di Sirio
                 Copyright (C) 2014 BRMICRO Technologies
                 

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    br32xx/cpm_lld.c
 * @brief   clock & pmu driver source.
 *
 * @addtogroup HAL
 * @{
 */

#include "hal.h"

/*===========================================================================*/
/* Driver local definitions.                                                 */
/*===========================================================================*/

__attribute__ ((section (".setup_text"), optimize(s), noinline))
void delay_nops(int cnt)
{
  while (cnt-- > 0) __NOP();
}

static inline uint32_t get_xtal_clock(void) {
  if(CPM_GetXtalSel())
    return XCLK_CLOCK_24MHz;
  else
    return XCLK_CLOCK_16MHz;
}

static inline uint32_t get_master_clock(void) {
  /* judge xtal-clk  or pll-clk */
  if (HS_PMU_CPM->PLL_SRC_CFG&0x1)
    return PLL_CLOCK_192M;
  else
    return get_xtal_clock();
}

static inline bool cpm_is_master_clock_from_pll(void) {
	return HS_PMU_CPM->PLL_SRC_CFG;
}


/*===========================================================================*/
/* Driver exported variables.                                                */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local variables and types.                                         */
/*===========================================================================*/
static pmu_tune_shadow_t m_pmu_tune_shadow;

/*===========================================================================*/
/* Driver local functions.                                                   */
/*===========================================================================*/
/**
 * @brief   Start system PLL.
  */
void _cpm_start_pll(void)
{
  /* check whether pll is started */
  if (0 == (HS_PMU->BASIC & (1u<<0))) return;

  /* switch to XTAL */
  HS_PMU_CPM->PLL_SRC_CFG = 0x0;
  __WFD();

  //HS_PMU->EXT = 0;
  /* 1. reset pll */
  HS_PMU->BASIC &= ~(1u<<1);
  HS_PMU->BASIC |= 1u<<30;
  delay_nops(100);
  /* 2. power on pll: pd_sys_pll = 0 */
  HS_PMU->BASIC &= ~(1u<<0);
  HS_PMU->BASIC |= 1u<<30;
  /* 3. deassert reset, MUST BE delay >5us */
  delay_nops(600);
  HS_PMU->BASIC |= (1u<<1);
  HS_PMU->BASIC |= 1u<<30;

  /* donot gate system PLL output to N10 */
  HS_PMU->ANA_CON &= ~(1u<<25);
  /* after reset over MUST BE > 1us to wait */
  delay_nops(100);

  /* Start AFC to calibrate PLL */
  HS_ANA->COMMON_CFG[0] |= (1u << 9); //sys_pll_afc_en
  /* wait 1 us at least */
  delay_nops(600);
  HS_ANA->COMMON_CFG[0] &= ~(1u << 9); //sys_pll_afc_en

  /* wait 220us at lease */
  delay_nops(5000);
  /* Waiting for PLL lock signal */
  while (1) {
    if (HS_PMU->BASIC & 0x80000000u)
      break;
  }

  /* switch to system PLL */
  HS_PMU_CPM->PLL_SRC_CFG = 0x1;
  __WFD();
}

/**
 * @brief   Stop system PLL.
 */
static void _cpm_stop_pll(void)
{
  /* check whether pll is stopped */
  if (0 != (HS_PMU->BASIC & (1u<<0))) return;

  /* switch to XTAL */
  HS_PMU_CPM->PLL_SRC_CFG = 0x0;
  __WFD();

  /* clear pll lock signal? */

  /* 1. reset pll */
  HS_PMU->BASIC &= ~(1u<<1);
  HS_PMU->BASIC |= 1u<<30;
  delay_nops(32*5);

  /* 2. power down pll: pd_sys_pll = 1 */
  HS_PMU->BASIC |= (1u<<0);
  HS_PMU->BASIC |= 1u<<30;
  delay_nops(32*1);

  /* 3. deassert reset? */
  //HS_PMU->BASIC |= (1u<<1);
  //HS_PMU->BASIC |= 1u<<30;
}

#if defined(BR3215)
static uint32_t _pmu_get_powerPinStatus(void)
{
  return ((HS_PMU->PMU_CLOCK_MUX >> 1) & 1);
}
#endif

/*===========================================================================*/
/* Driver interrupt handlers.                                                */
/*===========================================================================*/

/*===========================================================================*/
/* Driver exported functions.                                                */
/*===========================================================================*/

/**
 * @brief   Platform early initialization.
 * @note    All the involved constants come from the file @p board.h.
 * @note    This function is meant to be invoked early during the system
 *          initialization, it is usually invoked from the file
 *          @p board.c.
 *
 * @special
 */
__attribute__ ((section (".setup_text"), optimize(s), noinline))
void cpm_setup_sflash(void)
{
  register uint32_t cpu_cfg;

  /* DWT cycle counter enable.*/
  //SR_SETB32(NDS32_SR_PRUSR_ACC_CTL, 1);
  __nds32__mtsr(__nds32__mfsr(NDS32_SR_PRUSR_ACC_CTL) | (1u<<1), NDS32_SR_PRUSR_ACC_CTL);
  __nds32__mtsr(0x4408007, NDS32_SR_PFM_CTL); // ins, total cycles and I$ miss

  /* hw can startup if keep dcdc enabled (pd_puck=0, the default value in hw) on both cases */
  //cpm_enable_dcdc(0);

#if defined(hscAudiophile)
  if (cpm_is_test_ng_mode()) {
    pmu_set_dvdd12(0);
  }
  else {
    pmu_set_dvdd12(3);
  }
#else
  /* set DVDD12 to 1.3V */
  pmu_set_dvdd12(3);
#endif

  //palSetPadMode(GPIOA, 13, PAL_MODE_OUTPUT_PULLUP | PAL_MODE_ALTERNATE(PAD_FUNC_GPIO) | PAL_MODE_DRIVE_CAP(3));
  //palSetPin(13);
  /* disable test mode which may be triggered by jtag */
  HS_PMU->BASIC &= ~(1u<<6); //rest_test_en
  HS_PMU->BASIC |= 1u<<30;
#if defined(BR3215)
  /* disable PA0 as Power On
     @note this action is done after the prompt of power on for BR3215e */
  __hal_set_bitsval(HS_PMU->PADC_CON[0], 5, 10, 5);
  /* disable PA1 as reset */
  HS_PMU->RESET_EN = 0;
  /* pd_ioldo_v3p3: turn it off will take impact on XTAL's ctrl word and Pad's input status */
  __hal_set_bitsval(HS_PMU->ANA_CON, 27, 28, 3);
#endif

  /* XTAL select */
  //if (CPM_GetXtalSel())
  //  CPM_SetXtalSel_24MHz();
  //else
    CPM_SetXtalSel_16MHz();

  /* always change to default dividers on system reset or watchdog reset */
  HS_PSO->CPU_CFG = 0x49e;
  HS_PSO->APB_CFG = 0x405;
  HS_PSO->SFLASH_CFG = 0x415;
  HS_PSO->REG_UPD = 0x01;
  HS_PMU_CPM->PLL_SRC_CFG = 0x0;
  __WFD();

#if !defined(BR32xx_FPGA) && (defined(BR3215c) || defined(BR3215e))
  /* Perform RC 32K calibration. */
  //pmu_cal_rc_32k();  // audio  bt
#endif

  /* perform LDO calibration for better XTAL, VCO */
  pmu_cali_ldo();

  //_cpm_start_pll();

  //HS_PMU->EXT = 0;
  /* 1. reset pll */
  HS_PMU->BASIC &= ~(1u<<1);
  HS_PMU->BASIC |= 1u<<30;
  delay_nops(100);
  /* 2. power on pll: pd_sys_pll = 0 */
  HS_PMU->BASIC &= ~(1u<<0);
  HS_PMU->BASIC |= 1u<<30;
  /* 3. deassert reset, MUST BE delay >5us */
  delay_nops(600);
  HS_PMU->BASIC |= (1u<<1);
  HS_PMU->BASIC |= 1u<<30;

  /* donot gate system PLL output to N10 */
  HS_PMU->ANA_CON &= ~(1u<<25);
  /* after reset over MUST BE > 1us to wait */
  delay_nops(100);

  /* Start AFC to calibrate PLL */
  HS_ANA->COMMON_CFG[0] |= (1u << 9); //sys_pll_afc_en
  /* wait 1 us at least */
  delay_nops(600);
  HS_ANA->COMMON_CFG[0] &= ~(1u << 9); //sys_pll_afc_en

  /* wait 220us at lease */
  delay_nops(5000);
  /* Waiting for PLL lock signal */
  while (1) {
    if (HS_PMU->BASIC & 0x80000000u)
      break;
  }

  /* switch to system PLL */
  HS_PMU_CPM->PLL_SRC_CFG = 0x1;
  __WFD();

  /* don't set divider to 1; and 0 means bypass or div2 */
  //cpu_cfg = (DIV_ROUND(PLL_CLOCK_192M,  CPU_DEFAULT_CLOCK) << 8) | (0 << 16) | (0 << 24); /*  96:96:96 Mhz */
  cpu_cfg = (0 << 8) | (0 << 16) | (0 << 24); /*  96:96:96 Mhz */
#if defined(BR3215e) || defined(BR3216)
  cpu_cfg |= (DIV_ROUND(CPU_DEFAULT_CLOCK, BT_DEFAULT_CLOCK) << 24);
#endif
  HS_PSO->CPU_CFG = cpu_cfg | (1 << 7) | (0xf << 1);
  __WFD();

  HS_SF->CONFIGURATION_0 = 4; /* internal divider is 4 */
  HS_PSO->APB_CFG = (0 << 8) | 0x5; /* APB=CPU */
#if (SF_USE_CLK_DELAY_IN_CPM == TRUE)
  HS_PSO->SFLASH_CFG = (1UL<<16) | (DIV_ROUND(PLL_CLOCK_192M, 96000000) << 8) | 0x15; // delay enable
#else
  HS_PSO->SFLASH_CFG = (DIV_ROUND(PLL_CLOCK_192M, 96000000) << 8) | 0x1d;  //delay bypass
#endif
  pso_reg_update();
  __WFD();
  //palClearPin(13);
#if defined(BR3215)
  /* pd_ioldo_v3p3: turn it on and wait stable */
  __hal_set_bitsval(HS_PMU->ANA_CON, 27, 28, 0);
  /* max tVSL is 5ms; boya is 10us */
  delay_nops(1920);
  /* enable PA1 as reset */
  //HS_PMU->RESET_EN = 1;
#endif
}

void cpm_init_clock(void) {
  uint32_t coeff_frc, coeff_int;
  sys_clk_t system_clk;
  uint32_t cpu_cfg, uart_cfg;

#if defined(BR3215)
  /* avoid invalid Test NG mode in case of no bootflash */
  if (HS_PMU->SCRATCH1 & SCRATCH_INVALID_BITMASK) {
    HS_PMU->SCRATCH1 = 0;
  }
#endif

  /* get XTAL val 16M OR 32M */
  system_clk.xtal_clk = get_xtal_clock();
  system_clk.pll_clk = PLL_CLOCK_192M;

  /* setup PLL and SFlash is moved to cpm_setup_sflash() */
  /* don't set divider to 1; and 0 means bypass or div2 */
  cpu_cfg = 0;
#if __SYSTEM_CLOCK__ != 1
  if (system_clk.pll_clk != CPU_DEFAULT_CLOCK)
    cpu_cfg |= (DIV_ROUND(system_clk.pll_clk, CPU_DEFAULT_CLOCK) << 8);
  if (CPU_DEFAULT_CLOCK != AHB_DEFAULT_CLOCK)
    cpu_cfg |= (DIV_ROUND(CPU_DEFAULT_CLOCK,  AHB_DEFAULT_CLOCK) << 16);
  #if defined(BR3215) || defined(BR3215c)
  if (CPU_DEFAULT_CLOCK != RAM_DEFAULT_CLOCK)
    cpu_cfg |= (DIV_ROUND(CPU_DEFAULT_CLOCK,  RAM_DEFAULT_CLOCK) << 24);
  #endif
#endif
#if defined(BR3215)
  cpu_cfg = 0; /* 192:96:96 MHz */
#endif
#if defined(BR32xx_FPGA)
  cpu_cfg = (DIV_ROUND(PLL_CLOCK_192M,  CPU_DEFAULT_CLOCK) << 8) | (0 << 16) | (0 << 24); /*  48:48:48 MHz */
#endif
#if defined(BR3215e) || defined(BR3216)
  cpu_cfg |= (DIV_ROUND(CPU_DEFAULT_CLOCK, BT_DEFAULT_CLOCK) << 24);
#endif
  HS_PSO->CPU_CFG = cpu_cfg | (1 << 7) | (0xf << 1);
  __WFD();

#if defined(BR3215c) || defined(BR3215e) || defined(BR3216)
  /* apb_clock = ahb_clk/(apb_div_coeff+1) */
  if (APB_DEFAULT_CLOCK != AHB_DEFAULT_CLOCK)
    HS_PSO->APB_CFG = ((DIV_ROUND(AHB_DEFAULT_CLOCK, APB_DEFAULT_CLOCK)-1) << 8u) | 0x5;
  else
    HS_PSO->APB_CFG = (0 << 8u) | 0x5;
#else
  HS_PSO->APB_CFG = (DIV_ROUND(system_clk.pll_clk, APB_DEFAULT_CLOCK)/2 << 8) | 0x5;
#endif
  __WFD();

  HS_PSO->USB_CFG =  0x14;
  HS_PMU->ANA_CON &= ~(1<<25);

  HS_PSO->SD_CFG = ((DIV_ROUND(system_clk.pll_clk, SD_DEFAULT_CLOCK)/2) << 8) | 0x06;
  HS_PSO->SD_DRV_CFG = (1<<0)|(1<<1)|(((DIV_ROUND(system_clk.pll_clk, SD_DEFAULT_CLOCK)/4)+1)<<8); //smp clock delay bypass and div clock delay 1/4 clock

  HS_PSO->TIM0_CFG = (DIV_ROUND(system_clk.xtal_clk, TIMER_DEFAULT_CLOCK) << 8) | 0x16;
  HS_PSO->TIM1_CFG = (DIV_ROUND(system_clk.xtal_clk, TIMER_DEFAULT_CLOCK) << 8) | 0x16;
  HS_PSO->TIM2_CFG = (DIV_ROUND(system_clk.xtal_clk, TIMER_DEFAULT_CLOCK) << 8) | 0x16;

#if defined(BR3215e)
  system_clk.pll_clk = PLL_CLOCK_192M/2;    //BR3215e UARTx clock is 96MHz
#endif

#if !defined(BR32xx_FPGA) && !defined(hscAudiophile)//high baudrate upto 921600bps
#undef UART_DEFAULT_CLOCK
#define  UART_DEFAULT_CLOCK     (921600 * 16)
  coeff_int = system_clk.pll_clk/UART_DEFAULT_CLOCK;
  coeff_frc = DIV_ROUND((system_clk.pll_clk-UART_DEFAULT_CLOCK*coeff_int) << CPM_UART_DIV_COEFF_FRC_Len,
                        UART_DEFAULT_CLOCK);
  uart_cfg = 0x16;
#else
  coeff_int = system_clk.xtal_clk/UART_DEFAULT_CLOCK;
  coeff_frc = DIV_ROUND((system_clk.xtal_clk-UART_DEFAULT_CLOCK*coeff_int) << CPM_UART_DIV_COEFF_FRC_Len,
                        UART_DEFAULT_CLOCK);
  uart_cfg = 0x1e;
#endif

#if defined(BR3215e)
  system_clk.pll_clk = PLL_CLOCK_192M;
#endif

#if defined(BR3215)
  if ((HS_SYS->CHIP_ID & 0xFF) < 0xA4) {
    /* don't gate uart clock for BR3215A3 */
    uart_cfg &= ~0x02;
    uart_cfg |= 0x01;
  }
#endif

  uart_cfg |= (coeff_int << 8) | (coeff_frc << 16);
  HS_PSO->UART0_CFG = uart_cfg;
  HS_PSO->UART1_CFG = uart_cfg;
  
#if HS_HAS_UART2
  HS_PSO->UART2_CFG = uart_cfg;
#endif

  HS_PSO->I2C0_CFG =   (DIV_ROUND(system_clk.pll_clk, I2C_DEFAULT_CLOCK)/2 << 8) | 0x16;
  HS_PSO->I2S_CFG =    0x06;                   //unreset
  HS_PSO->CODEC_CFG =  0x06;                   //unreset
#if defined(BR3215e) || defined(BR3216)
  HS_PSO->BTPHY_CFG =  0x2a04 | ((BT_DEFAULT_CLOCK/1000000UL) << 16);  //LPO source default from xclk divider
#else
  HS_PSO->BTPHY_CFG =  0x2a04;  //LPO source default from xclk divider
#endif
  HS_PSO->SPI0_CFG =   0x6;//0x10;                   //no divider gate_en=1
  HS_PSO->SPI1_CFG =   0x6;//(DIV_ROUND(system_clk.pll_clk, SPI1_DEFAULT_CLOCK) << 11) | 0x15; //gate_en=1
  HS_PSO->WDT_CFG =    0x00;

  HS_PSO->AHB_GATE_CFG = 0x0a;                 //dma & gpio:
  HS_PSO->CPM_GATE_CFG = 0xa0;
  HS_PSO->CPM_ANA_CFG = 0x04;

  /* XTAL@32KHz for RTC, sleep timer, bt sniff */
#if defined(BR3215e)
  HS_PMU->ANA_CON0 |= (1<<28);    //[28]rtc_32k_clock_mux  1=internal 0=pad21?
  HS_PMU_CPM->CRY_CFG |= (1<<0);  //[0]cry_div_en=1
#endif

#if defined(BR3215c)
  pmu_switch_rtc_clk_to_rc32k();
#endif

  pso_reg_update();
  pmu_reg_update();

  //pmu_cali_rc();
}

/**
 * @brief   Get the clock.
 * @param[in] idx       index to clock source
 * @return              clock in Hz
 *
 * @api
 */
uint32_t cpm_get_clock(hs_clk_t idx) {
  uint32_t cfg = 0, div = 4;
  uint32_t top_clk = get_master_clock();

  switch (idx) {
  case HS_PLL_CLK:
    return PLL_CLOCK_192M;

  case HS_CPU_CLK:
    cfg = HS_PSO->CPU_CFG;
    div = CPM_BFEXT(DIV_COEFF, cfg);
    break;

  case HS_AHB_CLK:
    cfg = HS_PSO->CPU_CFG;
    div = CPM_BFEXT(DIV_COEFF, cfg);
    if (0 == div) div = 1;
    top_clk = top_clk / div;
    div = CPM_BFEXT(AHB_DIV_COEFF, cfg);
    if (0 == div) div = 1;
    break;

  case HS_RAM_CLK:
    cfg = HS_PSO->CPU_CFG;
    div = CPM_BFEXT(DIV_COEFF, cfg);
    if (0 == div) div = 1;
    top_clk = top_clk / div;
    div = CPM_BFEXT(RAM_DIV_COEFF, cfg);
    if (0 == div) div = 1;
    break;

  case HS_APB_CLK:
  case HS_SPI0_CLK:
  case HS_SPI1_CLK:
    cfg = HS_PSO->APB_CFG;
    div = CPM_BFEXT(APB_DIV_COEFF, cfg)*2;
#if defined(BR3215c) || defined(BR3215e) || defined(BR3216)
    cfg = HS_PSO->CPU_CFG;
    div = CPM_BFEXT(DIV_COEFF, cfg);
    if (0 == div) div = 1;
    top_clk = top_clk / div; //CPU_CLK
    div = CPM_BFEXT(AHB_DIV_COEFF, cfg);
    if (0 == div) div = 1;
    top_clk = top_clk / div; //AHB_CLK

    cfg = HS_PSO->APB_CFG;
    div = CPM_BFEXT(APB_DIV_COEFF, cfg);
    if (0 == div) div = 1;
    else div += 1;
#endif
    break;

  case HS_SF_CLK:
    cfg = HS_PSO->SFLASH_CFG;
    if (CPM_DIV_EN(cfg))
      div = CPM_BFEXT(SF_DIV_COEFF, cfg);
    break;

  case HS_USB_CLK:
    /* derived from system PLL */
    if (HS_PMU_CPM->PLL_SRC_CFG & 0x1)
      return 48000000;
    else
      return 0;

  case HS_SD_CLK:
    cfg = HS_PSO->SD_CFG;
    if (CPM_DIV_EN(cfg))
      div = CPM_BFEXT(DIV_COEFF, cfg)*2;
    break;

  case HS_TIM0_CLK:
    cfg = HS_PSO->TIM0_CFG;
    if (CPM_DIV_EN(cfg))
      div = CPM_BFEXT(DIV_COEFF, cfg);
    top_clk = get_xtal_clock();
    break;

  case HS_TIM1_CLK:
    cfg = HS_PSO->TIM1_CFG;
    if (CPM_DIV_EN(cfg))
      div = CPM_BFEXT(DIV_COEFF, cfg);
    top_clk = get_xtal_clock();
    break;

  case HS_TIM2_CLK:
    cfg = HS_PSO->TIM2_CFG;
    if (CPM_DIV_EN(cfg))
      div = CPM_BFEXT(DIV_COEFF, cfg);
    top_clk = get_xtal_clock();
    break;

  case HS_XTAL_CLK:
    return get_xtal_clock();

  case HS_UART0_CLK:
  case HS_UART1_CLK:
#if HS_HAS_UART2
  case HS_UART2_CLK:
#endif
    {
      uint32_t coeff_frc, coeff_int;

      if (HS_UART0_CLK == idx)
        cfg = HS_PSO->UART0_CFG;
#if HS_HAS_UART2
      else if (HS_UART2_CLK == idx)
        cfg = HS_PSO->UART2_CFG;
#endif
      else
        cfg = HS_PSO->UART1_CFG;

#if defined(BR3215e)
      top_clk /=2;    //BR3215e UARTx clock is 96MHz
#endif
      if (0 != (cfg & (1 << 3u))) {
        top_clk = get_xtal_clock();
      }

      coeff_frc = CPM_BFEXT(UART_DIV_COEFF_FRC, cfg);
      coeff_int = CPM_BFEXT(UART_DIV_COEFF_INT, cfg);
      if (CPM_DIV_EN(cfg))
	      return ((top_clk ) / ((coeff_int << CPM_UART_DIV_COEFF_FRC_Len) + coeff_frc)) << CPM_UART_DIV_COEFF_FRC_Len;
      else
	      return (top_clk);
    }

  case HS_I2C0_CLK:
    cfg = HS_PSO->I2C0_CFG;
    if (CPM_DIV_EN(cfg))
      div = CPM_BFEXT(I2C_DIV_COEFF, cfg)*2;
    break;

  case HS_LPO_CLK:
  case HS_RTC_CLK:
  case HS_WDT_CLK:
    return 32000;

  case HS_CODEC_MCLK:
  case HS_BTBB_CLK:
    /* derived from system PLL */
    if (HS_PMU_CPM->PLL_SRC_CFG & 0x1)
      return 24000000;
    return 0;

  default:
    return 0;
  }

  if (0 == div)
    div = 1;
  return top_clk / div;
}

/**
 * @brief   Set the clock.
 * @param[in] idx index to clock source
 *            hz  clock in hz
 *
 * @api
 */
void __ONCHIP_CODE__ cpm_set_clock(hs_clk_t idx, uint32_t hz) {
    uint32_t mclk = get_master_clock();
	uint8_t div = DIV_ROUND(mclk, hz);
	switch (idx) {
	case HS_CPU_CLK:
      HS_PSO->CPU_CFG = CPM_BFINS(DIV_COEFF, div, HS_PSO->CPU_CFG) | CPM_BIT(DIV_EN);
	  break;
    case HS_RAM_CLK:
      HS_PSO->CPU_CFG = CPM_BFINS(RAM_DIV_COEFF, div, HS_PSO->CPU_CFG) | CPM_BIT(DIV_EN);
	  break;
	case HS_AHB_CLK:
      HS_PSO->CPU_CFG = CPM_BFINS(AHB_DIV_COEFF, div, HS_PSO->CPU_CFG) | CPM_BIT(DIV_EN);
      break;
	case HS_APB_CLK:
	  HS_PSO->APB_CFG = CPM_BFINS(APB_DIV_COEFF, div/2, HS_PSO->APB_CFG) | CPM_BIT(DIV_EN);
	  pso_reg_update();
      return;
    case HS_SF_CLK:
      HS_PSO->SFLASH_CFG = CPM_BFINS(SF_DIV_COEFF, div, HS_PSO->SFLASH_CFG) | CPM_BIT(DIV_EN);
	  break;
	default: return;
	}
	__WFD();
    return;
}

void cpm_set_main_freq(int mhz) {
  #if defined(BR32xx_FPGA)
  (void)mhz;
  #else
  if (16 >= mhz) {
    _cpm_stop_pll();
  }
  else {
    _cpm_start_pll();
    /* 48mhz in default */
    #if defined(BR3215e)
    HS_PSO->CPU_CFG = 0x0200049e;
    #else
    HS_PSO->CPU_CFG = 0x49e;
    #endif
    __WFD();
  }

  switch (mhz) {
  #if defined(BR3215) || defined(BR3215e)
  case 192:
    #if defined(BR3215e)
    HS_PSO->CPU_CFG = 0x0800009e;
    #else
    HS_PSO->CPU_CFG = 0x09e;
    #endif
    __WFD();
    break;
  #endif

  case 96:
    #if defined(BR3215e)
    HS_PSO->CPU_CFG = 0x0400029e;
    #else
    HS_PSO->CPU_CFG = 0x29e;
    #endif
    __WFD();
    break;

  case 16:
    /* @XTAL */
    HS_PSO->CPU_CFG = 0x09e;
    __WFD();
    break;

  case 17:
    /* switch to XTAL, and keep system PLL on */
    HS_PMU_CPM->PLL_SRC_CFG = 0x0;
    __WFD();
    HS_PSO->CPU_CFG = 0x09e;
    __WFD();
    break;

  case 0:
    /* the lowest frequency */
    HS_PSO->CPU_CFG = 0x1f1f049e;
    __WFD();
    HS_PSO->CPU_CFG = 0x1f1f1f9e;
    __WFD();
    break;

  case 48:
  default:
    break;
  }
  #endif
}

/**
 * @brief   Set master clock source from system PLL
 *
 * @api
 */
void cpm_switch_to_pll(void) {
	HS_PMU_CPM->PLL_SRC_CFG = 0x1;
	__WFD();
}

/**
 * @brief   Set master clock source from main crystal
 *
 * @api
 */
void cpm_switch_to_xtal(void) {
	HS_PMU_CPM->PLL_SRC_CFG = 0x0;
	__WFD();
}

uint8_t cpm_get_xtal_cap(void)
{
  uint8_t xtal_cap = 16;

#if defined(BR3215)
  if (HS_SYS->CHIP_ID >= 0x660500A4) {
    /* BR3215A4 */
    xtal_cap = (~(HS_PMU->PMU_CLOCK_MUX >> 21) & 0x01) * 16 +
      ((HS_PMU->PMU_CLOCK_MUX >> 16) & 0x0F);
  }
  else {
    /* BR3215A3 */
    xtal_cap = HS_ANA->REGS.CCON_XTAL;
  }
#elif defined(BR3215c) || defined(BR3215e)
  xtal_cap = ((HS_PMU->PMU_CLOCK_MUX >> 21) & 0x01) * 16 +
    ((HS_PMU->PMU_CLOCK_MUX >> 16) & 0x0F);
#endif

  return xtal_cap;
}

void cpm_set_xtal_cap(uint8_t xtal_cap)
{
#if defined(BR3215) || defined(BR3215c)
  uint32_t reg_val;
  reg_val = HS_PMU->PMU_CLOCK_MUX & 0xFFD0FFFF;     //clear bit21 bit19-bit16 
  #if defined(BR3215)
  HS_ANA->REGS.CCON_XTAL = xtal_cap; //BR3215A3
  reg_val = reg_val | ((xtal_cap & 0x10) <<17) | (((~xtal_cap) & 0x0F)<<16);  //set bit21, bit19-bit16
  #elif defined(BR3215c)
  reg_val = reg_val | ((xtal_cap & 0x10) <<17) | ((xtal_cap & 0x0F)<<16);     //set bit21, bit19-bit16
  #endif
  HS_PMU->PMU_CLOCK_MUX = reg_val;
#elif defined(BR3215e)
  uint32_t reg_val;
  reg_val = HS_PMU->ANA_CON0 & 0xFFD0FFFF;     //clear bit21 bit19-bit16 
  reg_val = reg_val | ((xtal_cap & 0x10) <<17) | (((xtal_cap) & 0x0F)<<16);  //set bit21, bit19-bit16
  HS_PMU->ANA_CON0 = reg_val;
#else
  (void)xtal_cap;
  #warning "TBD"
#endif
}

/**
 * @brief   Set sf clock delay
 * @param[in] half_cycle  = 1/2 * 1/PLL_CLK 0:bypass 1~8: n half cycle
 *           half_cycle between 0 to 8
 * @api
 */
void cpm_set_sf_clock_delay(uint8_t half_cycle) {
	uint32_t val = half_cycle;
	if (half_cycle == 0)
		HS_PSO->SFLASH_CFG |= CPM_BIT(SF_DELAY_BYPASS);
	else if (half_cycle < 9) {
		HS_PSO->SFLASH_CFG &= (~(CPM_BIT(SF_DELAY_BYPASS)));
		HS_PSO->SFLASH_CFG = CPM_BFINS(SF_DELAY_OFFSET, val-1, HS_PSO->SFLASH_CFG);
	}else{
		/* if half_cycle>8 defalt 3 */
		HS_PSO->SFLASH_CFG &= (~(CPM_BIT(SF_DELAY_BYPASS)));
		HS_PSO->SFLASH_CFG = CPM_BFINS(SF_DELAY_OFFSET, 3, HS_PSO->SFLASH_CFG);
	}
}

/**
 * @brief   Set sd sample clock and driver clock delay and mclk phase
 * @param[in]  sd_dev_clk
 *
 * @api
 */
void cpm_set_sd_dev_clock(sd_dev_clk_t *sd_dev_clk) {

	int32_t drv_val = sd_dev_clk->drv_half_cycles;
	int32_t smp_val = sd_dev_clk->smp_half_cycles;

	if (sd_dev_clk->mclk_phase == SD_CLK_PHASE_0)
		HS_PSO->SD_DRV_CFG &= (~(CPM_BIT(SD_DEV_MCLK_INV)));
	else if(sd_dev_clk->mclk_phase == SD_CLK_PHASE_180)
		HS_PSO->SD_DRV_CFG |= CPM_BIT(SD_DEV_MCLK_INV);

	if (smp_val == -1)
		HS_PSO->SD_DRV_CFG |= CPM_BIT(SD_DEV_SMP_DELAY_BYPASS);
	else if (smp_val < 8) {
		HS_PSO->SD_DRV_CFG &= (~(CPM_BIT(SD_DEV_SMP_DELAY_BYPASS)));
		HS_PSO->SD_DRV_CFG = CPM_BFINS(SD_DEV_SMP_DELAY_OFFSET, smp_val-1, HS_PSO->SD_DRV_CFG);
	}else{
		/* if half_cycle>8 defalt bypass */
		HS_PSO->SD_DRV_CFG |= CPM_BIT(SD_DEV_SMP_DELAY_BYPASS);
	}

	if (drv_val == -1)
		HS_PSO->SD_DRV_CFG |= CPM_BIT(SD_DEV_DRV_DELAY_BYPASS);
	else if (drv_val < 8) {
		HS_PSO->SD_DRV_CFG &= (~(CPM_BIT(SD_DEV_DRV_DELAY_BYPASS)));
		HS_PSO->SD_DRV_CFG = CPM_BFINS(SD_DEV_DRV_DELAY_OFFSET, drv_val-1, HS_PSO->SD_DRV_CFG);
	}else{
		/* if half_cycle>8 defalt 3 */
		HS_PSO->SD_DRV_CFG &= (~CPM_BIT(SD_DEV_DRV_DELAY_BYPASS));
		HS_PSO->SD_DRV_CFG = CPM_BFINS(SD_DEV_DRV_DELAY_OFFSET, 3, HS_PSO->SD_DRV_CFG);
	}

  pso_reg_update();
}

void cpm_delay_us(uint32_t us)
{
#if OSAL_OS_MODE_OSLESS
#if PORT_SUPPORTS_RT
	/**
	 * Use PFMC1 (Performance Counter 1) as delay_us() counter.
	 * Precise.
	 */
	/* Start PFMC1 for delay_us(). */
	cpm_start_performance_counter(1); /* Better in _late_init() or halInit()? */
  osalSysPolledDelayX(us * (CPU_DEFAULT_CLOCK / 1000000));
	/**
	 * Stop PFMC1 to save battery.
	 * Not suitable for use in ISR, because it may stop the counter which is used
	 * in non-ISR code.
	 */
  //cpm_stop_performance_counter(1);
#else
  /* 1us == 5 NOPs when CPU_DEFAULT_CLOCK is 96MHz. Precise. */
  delay_nops(us*5);
#endif
#else
  //osalSysPolledDelayX(us * (cpm_get_clock(HS_CPU_CLK) / 1000000));
  delay_nops(us * (CPU_DEFAULT_CLOCK / 1000000));
#endif
}

/**
 * @brief   Set sflash inner or outter
 * @param[in]  location
 *
 * @api
 */
void sf_inner_select(sf_loc_t loc) {
	if (loc == SF_LOC_INNER)
		HS_PMU->BASIC |= (1<<3);
	else if (loc == SF_LOC_OUTER)
		HS_PMU->BASIC &= ~(1<<3);
    pmu_reg_update();
}

void pmu_xclkon_insleep(int on){
  if(on)
    HS_PMU->BASIC &= ~(1<<2);
  else
    HS_PMU->BASIC |= (1<<2);
}

void pmu_deep_sleep_with_wakeup(uint32_t gpio_bitmap, uint32_t gpio_mask_bitmap, uint32_t gpio_polar_bitmap)
{
	pal_lld_set_wakeup(gpio_bitmap, gpio_mask_bitmap, gpio_polar_bitmap);
	pmu_deep_sleep();
}

#if defined(BR3215) || defined(BR3215e)
void pmu_deep_sleep(void)
{
  /* PA0 is always power key, and acts as wakeup pin */
  __hal_set_bitsval(HS_PMU->BASIC, 4, 5, PA0/*HS_PIN_DEEP_SLEEP_WAKEUP*/);
  pmu_reg_update();

  HS_PMU->PSO_PM_CON = 0x40080402;
}
#endif

void pmu_power_off(void)
{
  #if defined(BR3215)
  /* workaround: don't power off if PA0 is pressed */
  while (0 == _pmu_get_powerPinStatus())
    ;
  #endif

  HS_PMU->BASIC |= (1u << 7);
  HS_PMU->CHIP_PM_PIN |= (1u << 13);
  #if defined(BR3215e)
  /* [13:12]chip_power_en b'10=off */
  HS_PMU->CHIP_PM_PIN = (100/*pwr_pin_debounce ms*/<<14) | (0x2/*power off*/<<12) |
    (8/*power_off_cycle *2^cycle*/<<8) | (8/*power_on_cycle *2^cycle*/<<4) | (0/*cycle*/<<0);
  /* [1:0]power_gate_en,power_on b'01=off, but it is not functional */
  HS_PMU->PSO_PM_CON = (1/*update w1*/<<30) | (8/*pso_reset_delay*/<<16) | (4/*pso_clamp_delay*/<<8) | (0x1/*power off*/<<0);
  #endif
  pmu_reg_update();
}

uint32_t pmu_ana_get(uint32_t start, uint32_t end)
{
  volatile uint32_t *ptr = &HS_ANA->COMMON_PACK[0];
  uint32_t val, bit_len, low_len, word_width = sizeof(uint32_t) * 8;

  bit_len = end - start + 1;  
  if(bit_len > word_width)
    return 0;

  low_len = word_width - start % word_width;
  low_len = low_len > bit_len ? bit_len : low_len;
  
  ptr += start / word_width;
  val = (*ptr >> (start % word_width) ) & ((1u << low_len) - 1);
  
  if(bit_len > low_len)
  {
    ptr ++;
    val |= (*ptr & ((1 << (bit_len -  low_len)) - 1)) << low_len;
  }

  return val;
}

void pmu_ana_set(uint32_t start, uint32_t end, uint32_t val)
{
  volatile uint32_t *ptr = &HS_ANA->COMMON_PACK[0];
  uint32_t bit_len, low_offset, low_len, word_width = sizeof(uint32_t) * 8;

  bit_len = end - start + 1;  
  if(bit_len > word_width)
    return ;

  low_offset = start % word_width;
  low_len = word_width - low_offset;

  low_len = low_len > bit_len ? bit_len : low_len;
  
  ptr += start / word_width;
  __hal_set_bitsval(*ptr, low_offset, (low_offset + low_len - 1), val);

  if(bit_len > low_len)
  {
    ptr ++;
    val >>= low_len;

    __hal_set_bitsval(*ptr, 0, (bit_len - low_len), val);
  }
}

#if defined(BR3215)
static const short rxadc_rc_tab[16] = {356, 346, 335, 324, 313, 302, 292, 281, 270, 259, 248, 238, 227, 216, 205, 194}; //4b'1000
static const short auadc_rc_tab[16] = {356, 346, 335, 324, 313, 302, 292, 281, 270, 259, 248, 238, 227, 216, 205, 194}; //4b'1000
static const short txdac_rc_tab[16] = {378, 360, 342, 324, 306, 288, 270, 252, 234, 216, 198, 180, 162, 144, 126, 108}; //4b'0110
static const short rxfil_rc_tab[ 8] = {360, 330, 300, 270, 240, 210, 180, 150}; //3b'011? b'111
static const short rxtia_rc_tab[ 8] = {405, 371, 337, 303, 270, 236, 202, 168}; //        b'100

/* rc table search policy by lihongwei */
static int _search_rc_tab(short value, const short *table, int size)
{
  int i = 0;
  do{
    if(table[i] < value)
      break;
  }while(++i < size);

  if(i == size)
    return i - 1;

  if(i == 0)
    return i;

  if(table[i - 1] - value < value - table[i])
    return i - 1;

  return i;
}
#endif

/* RC calibration for rxadc, auadc, txdac, rxfil, rxtia */
void pmu_cali_rc(void)
{
#if defined(BR3215)
  if (m_pmu_tune_shadow.valid_rc == 0) {
    uint32_t saved0, saved1, saved2;
    short rc_cnt, timeout = 0;

    saved0 = HS_ANA->PD_CFG[0];
    saved1 = HS_PMU->ANA_CON;
    saved2 = HS_ANA->PD_CFG[2];

    /* over voltage protect */
    HS_ANA->REGS.RXADC_SHRT = 1;

    /* [8]pd_ldo_v1p5_ana, [7]pd_ldp_v1p5_adda */
    HS_PMU->ANA_CON &= ~((1 << 8) | (1 << 7));
    /* [20][4]pd_rxadc_i [18][2]pd_rxadc_biasgen */
    HS_ANA->PD_CFG[2] &= ~((1 << 20) | (1 << 18) | (1 << 4) | (1 << 2));
    /* [12]pd_rxadc_dacbias */
    HS_ANA->PD_CFG[0] &= ~(1 << 12);

    /* wait 20us for ldo output stability */
    delay_nops(20 * (cpm_get_clock(HS_CPU_CLK) / 1000000));

    /* start RC calibration to get rc_cnt = t1+t2 */
    HS_ANA->RC_CALIB_CNS = (1 << 0); //sw set, hw clear
    while (HS_ANA->RC_CALIB_CNS & (1 << 0)) {
      if (timeout++ > 2000) {
        break;
      }
      delay_nops(1 * (cpm_get_clock(HS_CPU_CLK) / 1000000));
    }
    rc_cnt = (HS_ANA->RC_CALIB_CNS >> 16) / 2;
    if (0 == rc_cnt) {
      rc_cnt = 290;
    }

    /* post */
    HS_ANA->REGS.RXADC_SHRT = 0;
    HS_ANA->PD_CFG[0] = saved0;
    HS_PMU->ANA_CON   = saved1;
    HS_ANA->PD_CFG[2] = saved2;

    m_pmu_tune_shadow.rc_rxadc = _search_rc_tab(rc_cnt, rxadc_rc_tab, 16);
    m_pmu_tune_shadow.rc_auadc = _search_rc_tab(rc_cnt, auadc_rc_tab, 16);
    m_pmu_tune_shadow.rc_txdac = _search_rc_tab(rc_cnt, txdac_rc_tab, 16);
    m_pmu_tune_shadow.rc_rxfil = _search_rc_tab(rc_cnt, rxfil_rc_tab, 8);
    m_pmu_tune_shadow.rc_rxtia = _search_rc_tab(rc_cnt, rxtia_rc_tab, 8);
    m_pmu_tune_shadow.valid_rc = 1;
  }

  /* [7:4]rxadc_rctune */
  __hal_set_bitsval(HS_ANA->COMMON_CFG[0], 4, 7,   m_pmu_tune_shadow.rc_rxadc);
  /* reg<16:13>RCtune         =auadc_rctune */
  HS_ANA->REGS.RC_TUNE =                           m_pmu_tune_shadow.rc_auadc;
  /* reg<142:139>txdac_bw_cal =txdac_rctune */
  HS_ANA->REGS.TXDAC_BW_CAL =                      m_pmu_tune_shadow.rc_txdac;
  /* [6:4]ctune_fil           =rxfil_rctune */
  __hal_set_bitsval(HS_ANA->RX_FIL_CFG, 4, 6,      m_pmu_tune_shadow.rc_rxfil);
  /* [18:16]cf_tune           =rxtia_rctune */
  __hal_set_bitsval(HS_ANA->COMMON_CFG[1], 16, 18, m_pmu_tune_shadow.rc_rxtia);
#endif
}

/* low noise LDO calibration for lobuf, xtal, vco */
__attribute__ ((section (".setup_text"), optimize(s), noinline))
void pmu_cali_ldo(void)
{
#if defined(BR3215)
  if (m_pmu_tune_shadow.valid_ldo == 0) {
    uint32_t saved0, saved1, saved2, ctrl;
    short timeout = 0;

    saved0 = HS_PMU->ANA_CON;
    saved1 = HS_ANA->PD_CFG[1];
    saved2 = HS_ANA->DBG_IDX;

    /* [23]sys_pll_gt_32m, required by ldo_calib_comp_ts; [8]pd_ldo_v1p5_ana by yangguang */
    HS_PMU->ANA_CON &= ~((1 << 23) | (1 << 8));

    /* [22][6]pd_ldo_v1p3_lobuf */
    /* pd_ldoxtal is on by fsm */
    /* [28][12]pd_bt_ldovco */
    HS_ANA->PD_CFG[1] &= ~((1 << 28) | (1 << 22) | (1 << 12) | (1 << 6));

    HS_ANA->REGS.PD_LDOCALI_CAMP = 0;
    HS_ANA->REGS.LDOCALI_SWAP = 0;

    /* wait 80us for ldo output stability */
    delay_nops((80+20) * (HS_XTAL_CLOCK / 1000000));

    HS_ANA->LDO_CALIB_CNS = 0 << 8; //LDO settle time =10us + counter in 32MHz
    /* enable LDO calibration to control reg<268:267> reg<257:256> reg<45:44> by fsm */
    HS_ANA->LDO_CALIB_CNS |= (1 << 0); //ldo_calib_en: 1=fsm
    /* wait 2~3 cycles in 32MHz, so hw will clear ldo_calib_done */
    delay_nops((3+2) * (HS_XTAL_CLOCK / 1000000));
    while ((HS_ANA->LDO_CALIB_CNS & (1 << 31)) == 0) { //ldo_calib_done
      if (timeout++ > 2000) {
        break;
      }
      delay_nops(1 * (HS_XTAL_CLOCK / 1000000));
    }

    /* sw delay for 10us*4step*3ldo to avoid hw bug */
    delay_nops((120+20) * (HS_XTAL_CLOCK / 1000000));

    /* duplicate the LDO calibration values from fsm to reg, in case of cali module ugly output on 32MHz reset */
    HS_ANA->DBG_IDX = 7;
    ctrl = HS_ANA->DBG_RDATA;

    /* post */
    HS_ANA->LDO_CALIB_CNS &= ~(1 << 0); //ldo_calib_en: 0=reg
    HS_ANA->REGS.PD_LDOCALI_CAMP = 1;
    HS_PMU->ANA_CON   = saved0;
    HS_ANA->PD_CFG[1] = saved1;
    HS_ANA->DBG_IDX   = saved2;

    m_pmu_tune_shadow.ldo_lobuf = (ctrl >> 4) & 0x3;
    m_pmu_tune_shadow.ldo_xtal  = (ctrl >> 2) & 0x3;
    m_pmu_tune_shadow.ldo_vco   = (ctrl >> 0) & 0x3;
    m_pmu_tune_shadow.valid_ldo = 1;
  }

  /* reg<45:44> */
  HS_ANA->REGS.LDO_LOBUF_CTRL = m_pmu_tune_shadow.ldo_lobuf;
  /* reg<257:256> */
  HS_ANA->REGS.CON_LDO_XTAL   = m_pmu_tune_shadow.ldo_xtal;
  /* reg<268:267> */
  HS_ANA->REGS.CON_LDO_VCO    = m_pmu_tune_shadow.ldo_vco;
#endif
}

void pmu_cali_result(pmu_tune_shadow_t *p_result)
{
  if (p_result)
    *p_result = m_pmu_tune_shadow;
}

/**
 * @brief   Calibrate the internal 32K RC oscillator used for RTC.
 * @note    Added since BR3215C.
 *
 * @api
 */
#if defined(BR3215c) || defined(BR3215e)
__attribute__ ((section (".setup_text"), optimize(s), noinline))
void pmu_cal_rc_32k(void) {
  /* Hardware bug in BR3215c version before A3:
   * The XTAL clock select flag of 16MHz/24MHz (HS_PMU->PMU_CLOCK_MUX[31])
	 * is connected to both PLL module and RC 32K module. The signals should
	 * be the same, but an unwanted inverter appears to exist in the
	 * connection to PLL module. It results in opposite expectations about
	 * XTAL clock select flag.
	 * According to spec, PLL's expectation of XTAL clock select is wrong.
	 *
	 * Workaround:
	 * 1. Set system clock source to XTAL other than PLL.
	 * 2. Set XTAL clock select to real clock used.
	 * 3. Perform the calibration.
	 * 4. Set XTAL clock select opposite to real clock used.
	 * 5. Restore system clock source to PLL.
   */

	/**
	 * Assume clock has been correctly set in HS_PMU->PMU_CLOCK_MUX[31] due to
	 * real XTAL clock used acquired by calling CPM_GetXtalSel().
	 */
#if defined(BR3215c)
	if (HS_SYS->CHIP_ID == 0x660300A1) // BR3215c version A3, after ECO.
		pmu_rc32k_cal();
	else {                             // BR3215c version before ECO.
		// switch system clock to XTAL.
		bool is_pll = HS_PMU_CPM->PLL_SRC_CFG;
		if (is_pll) {
			HS_PMU_CPM->PLL_SRC_CFG = 0x0;
			__WFD();
		}

		HS_PMU->PMU_CLOCK_MUX ^= (1U<<31); // switch selection of 16MHz/24MHz
		pmu_rc32k_cal();
		HS_PMU->PMU_CLOCK_MUX ^= (1U<<31); // switch back

		// restore old system clock setting.
		if (is_pll) {
			HS_PMU_CPM->PLL_SRC_CFG = 0x1;
			__WFD();
		}
	}
#elif defined(BR3215e)
	pmu_rc32k_cal();
#endif
}
#endif

void cpm_enable_dcdc(uint8_t en)
{
#if defined(BR3215c)
    if (en)
    {
        HS_PMU->ANA_CON1 &= ~(3U<<9);
    }
    else
    {
        HS_PMU->ANA_CON1 |= (3<<9);
    }
#elif defined(BR3215e)
    /* [9]pd_buck */
    if (en) {
      HS_PMU->ANA_CON1 &= ~(1<<9);
    }
    else {
      HS_PMU->ANA_CON1 |= (1<<9);
    }
#else
    (void)en;
#endif
}

/** @} */

