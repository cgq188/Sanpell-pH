/*
    ChibiOS/RT - Copyright (C) 2006,2007,2008,2009,2010,
                 2011,2012,2013 Giovanni Di Sirio.
                 Copyright (C) 2019 BRMICRO Technologies
                 
                 
                 

    This file is part of ChibiOS/RT.

    ChibiOS/RT is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    ChibiOS/RT is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

                                      ---

    A special exception to the GPL can be applied should you wish to distribute
    a combined work that includes ChibiOS/RT, without being obliged to provide
    the source code for any proprietary components. See the file exception.txt
    for full details of how and when the exception can be applied.
*/

/**
 * @file    audio.h
 * @brief   audio Driver macros and structures.
 *
 * @addtogroup AUDIO
 * @{
 */

#ifndef _AUDIO_H_
#define _AUDIO_H_

#if !defined(HAL_USE_AUDIO)
#define HAL_USE_AUDIO               FALSE
#define HAL_USE_CODEC               FALSE
#endif

#if HAL_USE_AUDIO || defined(__DOXYGEN__)

#include "ringbuffer.h"
#include "i2s_lld.h"
#include "codec_lld.h"

/*===========================================================================*/
/* Driver constants.                                                         */
/*===========================================================================*/

/*===========================================================================*/
/* Driver pre-compile time settings.                                         */
/*===========================================================================*/


/*===========================================================================*/
/* Derived constants and error checks.                                       */
/*===========================================================================*/

#if !defined(HS_AUDIO_USE_DEBUG) || defined(__DOXYGEN__)
#define HS_AUDIO_USE_DEBUG          FALSE
#endif

#if !defined(HS_AUDIO_USE_AEC) || defined(__DOXYGEN__)
#define HS_AUDIO_USE_AEC            FALSE
#endif

#if !defined(HS_AUDIO_USE_STATISTIC) || defined(__DOXYGEN__)
#define HS_AUDIO_USE_STATISTIC      TRUE
#endif

#if !defined(HS_CODEC_USE_INSIDE) || defined(__DOXYGEN__)
#define HS_CODEC_USE_INSIDE         TRUE
#endif

#if !defined(HS_CODEC_USE_WM8753) || defined(__DOXYGEN__)
#define HS_CODEC_USE_WM8753         TRUE
#endif

/*===========================================================================*/
/* Driver data structures and types.                                         */
/*===========================================================================*/

typedef enum {
  ERRNO_AUDIO_OK                  = 0,
  ERRNO_AUDIO_TRY_AGAIN           = -1,
  ERRNO_AUDIO_PAR_ERR             = -2,
  ERRNO_AUDIO_NO_DMA              = -3,
} hs_audio_errno_t;

typedef enum
{
  AUDIO_INIT                      = 0,
  AUDIO_IDLE                      ,
  AUDIO_START                     ,
  AUDIO_STOP                      ,
} hs_audio_state_t;

typedef enum
{
  AUDIO_STREAM_PLAYBACK       = 0x80,
  AUDIO_STREAM_RECORD         ,
} hs_audio_dir_t;

#if HS_AUDIO_USE_STATISTIC
typedef struct
{
  uint32_t           rw_cnt;
  uint32_t           sleep_cnt;
  uint32_t           flow_cnt;
  uint32_t           int_cnt;
  uint32_t           int_err_cnt;
  uint16_t           repair_inc_cnt;
  uint16_t           repair_dec_cnt;
}hs_audio_debug_t;
#endif

typedef struct
{
  /* hardware resource */
  hs_dma_stream_t   *dma;
  uint32_t           dma_buffer;
  uint32_t           dma_buffer_end;
  uint32_t           dma_pending;
  uint16_t           period_len;
  uint16_t           period_num;

  /* software resource */
  struct ringbuffer  rb;
  uint8_t           *ring_buffer;
  uint16_t           ring_buffer_size;
  hs_audio_state_t   state;

  /* locking & scheduling */
  thread_t          *thread;

  /* performance debug params */
  #if HS_AUDIO_USE_STATISTIC
  hs_audio_debug_t   performance;
  #endif

  /* repair algorithm */
  int8_t             repair;
} hs_audio_stream_t;

typedef struct
{
  CODECDriver       *pcodec;
  I2SDriver         *pi2s;

  hs_audio_stream_t  rec;
  hs_audio_stream_t  ply;
} hs_audio_t;

/*===========================================================================*/
/* Driver macros.                                                            */
/*===========================================================================*/
#if HS_AUDIO_USE_DEBUG
#include <stdio.h>
#define audio_dbg(fmt,args...)	printf(fmt, ##args)
#else
#define audio_dbg(fmt,args...)
#endif

#if HS_AUDIO_USE_STATISTIC && OSAL_DBG_ENABLE_TRACE
#include <stdio.h>
#define audio_stc(fmt,args...)	printf(fmt, ##args)
#else
#define audio_stc(fmt,args...)
#endif

/*===========================================================================*/
/* External declarations.                                                    */
/*===========================================================================*/

#ifdef __cplusplus
extern "C" {
#endif

  void audioInit(void);
  void audioStart(void);
  void audioStop(void);

  hs_audio_errno_t audioRecordStart(hs_audio_config_t *cfgp);
  void audioRecordStop(void);

  /*
   * @brief Start playback with the specific audio settings.
   * @note  If this API is re-started without call stop, the previous
   *        settings will be saved then be restored when call stop.
   *
   * @param[in] cfgp     audio settings for playback, such as sample format
   * @return             0 if no error; @hs_audio_errno_t
   */
  hs_audio_errno_t audioPlayStart(hs_audio_config_t *cfgp);

  /*
   * @brief  Stop playback before save the current audio settings of play.
   * @note   This is a blockable API, untill playing ring buffer become empty.
   */
  void audioPlayStop(void);

  /*
   * @brief Commit the streaming data to playing ring buffer.
   * @note  This is a blockable API, which is wakeup by audio DMA interrupt for I2S tx.
   *
   * @param[in] pData     streaming data buffer pointer
   * @param[in] size      length in byte to be written
   *
   * @return written size in byte
   *
   */
  uint32_t audioPlayWrite(uint8_t *pData, uint32_t size);

  /*
   * @brief Get the streaming data from record ring buffer.
   * @note  This is a blockable API, which is wakeup by audio DMA interupt for I2S rx.
   *        The caller thread is USBD audio or Bluetooth AEC.
   * @param[in/out] pData recording data buffer pointer
   * @param[in] size      length in byte to be read
   *
   * @return read size in byte
   *
   */
  uint32_t audioRecordRead(uint8_t *pData, uint32_t size);

  /*
   * @brief Get the streaming data from record ring buffer while put to play ring buffer.
   * @note  This is a blockable API, which is wakeup by audio DMA interupt for I2S rx.
   *        The caller thread is USBD audio or Bluetooth AEC.
   * @param[in/out] pData recording data buffer pointer
   * @param[in] size      length in byte to be read
   *
   * @return read size in byte
   *
   */
  uint32_t audioRecordPlay(uint8_t *pData, uint32_t size);

  /*
   * @brief Set the volume of play.
   * @note  The volume is the gain of DAC in digital path only.
   *        The resolution is 0.5dB in hardware.
   *
   * @param[in] ddb_left  the gain in 0.1dB of left channel
   * @param[in] ddb_right the gain in 0.1dB of right chnnel
   */
  void audioPlaySetVolume(int ddb_left, int ddb_right);

  /*
   * @brief Get the volume of play.
   *
   * @param[out] ddb_left  the pointer to the gain in 0.1dB of left channel
   * @param[out] ddb_right the pointer to the gain in 0.1dB of right chnnel
   */
  void audioPlayGetVolume(int *ddb_left, int *ddb_right);

  void audioPlayMute(bool bMute);
  hs_audio_errno_t audioPlayGetConfig(hs_audio_config_t *cfgp);
  void audioPlayRepair(int8_t req);

  /*
   * @brief Set the volume of record.
   * @note  The volume is the gain of ADC in digital path only.
   *        The resolution is 0.5dB in hardware.
   *
   * @param[in] ddb_left  the gain in 0.1dB of left channel
   * @param[in] ddb_right the gain in 0.1dB of right chnnel
   */
  void audioRecordSetVolume(int ddb_left, int ddb_right);

  /*
   * @brief Get the volume of record.
   *
   * @param[out] ddb_left  the pointer to the gain in 0.1dB of left channel
   * @param[out] ddb_right the pointer to the gain in 0.1dB of right chnnel
   */
  void audioRecordGetVolume(int *ddb_left, int *ddb_right);

  void audioRecordMute(bool bMute);

  /*
   * @brief Start the mixer during playing, for the tone indicator.
   * @note  It will stop automatically.
   *
   * @param[in] samples      the number of tone indicator voice's samples.
   */
  void audioPlayMixerStart(uint16_t samples);

#ifdef __cplusplus
}
#endif

#endif /* HAL_USE_AUDIO */

#endif /* _AUDIO_H_ */

/** @} */
