/**
***********************************************************
* Copyright (C) 2014 All rights reserved.
*
* @file    : bthc_uapi.h
* @brief   : BT Host Controller user API by BRMICRO
* @version : 1.0
* @date    : 2015/9/15 19:33:07
* @author  : chenzhiyuan
*
* @note    :
*
* @history :
*
***********************************************************
*/

#ifndef __BTHC_UAPI_H
#define __BTHC_UAPI_H

#include <stdint.h>

#if defined __cplusplus
extern "C" {
#endif

#if !defined(__PACKED)
#if defined ( __GNUC__ )
  #define __PACKED
  #define __PACKED_GCC     __attribute__ ((packed))
#endif
#endif

struct bufferSize_s {
  uint16_t aclDataPacketLength;
  uint16_t scoDataPacketLength;
  uint16_t numAclDataPackets;
  uint16_t numScoDataPackets;
};

typedef enum
{
    BT_LOW_POWER_ENTER_SNIFF_MODE                      =0x00,       /*exit sniff transition mode*/
    BT_LOW_POWER_EXIT_SNIFF_MODE                            ,       /*enter sniff transition mode*/
}bt_low_power_t;

__PACKED struct bt_hc_sys_config_s {
  uint8_t  bd_addr[6];              //@0x00
  uint16_t HCI_revision;            //@0x06
  uint16_t comp_id;
  uint16_t lmp_subversion;
  uint8_t  lmp_version;             //@0x0c
  uint8_t  HCI_version;

  /* static buffers or allocated buffers in OS */
  uint8_t max_active_devices;
  uint8_t max_active_devices_in_piconet;
  struct bufferSize_s hc_buffer_size;      //@0x10
  struct bufferSize_s hc_buffer_size_in;   //@0x18

  /* debug */
  uint64_t local_device_syncword;   //@0x20
  uint32_t rand_seed;               //@0x28
  uint32_t win_ext;                 //@0x2C
  uint8_t  erroneous_data_reporting;//@0x30
  uint8_t  hs_cap;
#define HS_CAP_DIS_BQB_WA  (1 << 2)
  uint8_t  plc;
  uint8_t  xtal_cap;

  /* get/set via tc interface for CBT */
  uint8_t  clock_jitter_us;         //@0x34
  uint8_t  clock_drift_ppm;
  uint8_t  data_whitening_enable;
  uint8_t  hopping_mode;
  uint32_t tx_freq;                 //@0x38
  uint32_t rx_freq;                 //@0x3C

  /* pre-compile time settings. */
  uint8_t feature_set[16];          //@0x40
  uint8_t hci_command_set[64];      //@0x50
} __PACKED_GCC;

__PACKED struct bt_hc_phy_config_s {
  uint8_t phy_type;
  uint8_t debug_mode;
#define RADIO_DEBUG_RXENA_GIO  (0 << 0)
#define RADIO_DEBUG_RXENA_SPI  (1 << 0)
  uint16_t debug_mon_id;
  uint32_t hw_hab_phy_cfg_word;
  uint32_t ser_eser_cfg_word;

  uint16_t jal_le_ser_eser_tx_time;
  uint16_t jal_le_ser_eser_rx_time;

  /* initialize PHY delays in ms */
  uint8_t osc_startup_time;
  uint8_t phy_startup_delay1;
  uint8_t phy_startup_delay2;
  uint8_t phy_startup_delay3;

  /* radio timing in us */
  uint8_t hw_radio_pll_time;  //T1: PLL for TX and RX
  uint8_t hw_radio_ldo_time;  //T2: LDO, DAC, Up-Mixer for TX; LDO, LNA, Filter, CTSDM for RX
  uint8_t hw_radio_pa_time;   //T3: PA for TX
  uint8_t hw_radio_ramp_time; //T4, T5: Ramp up or Ramp down for TX (1~2us)

  /* input 0, calculate the times above */
  uint8_t hw_radio_tx_setup_time;     //T1+T2+T3+T4
  uint8_t hw_radio_tx_hold_time;      //T5
  uint8_t hw_radio_rx_setup_time;     //T1+T2
  uint8_t hw_radio_rx_hold_time;      //0

  /* input for le timing */
  uint8_t hw_radio_le_tx_setup_time;
  uint8_t hw_radio_le_tx_hold_time;
  uint8_t hw_radio_le_rx_setup_time;
  uint8_t hw_radio_le_rx_hold_time;

  uint8_t hw_radio_tx_tab_delay;
  uint8_t hw_radio_rx_tab_delay;      //including BRMICRO's digital delay
  uint8_t hw_radio_tx_phy_delay;
  uint8_t hw_radio_rx_phy_delay;

  uint8_t edr_tx_edr_delay;
  uint8_t edr_rx_edr_delay;
  uint8_t le_tifs_delay;
  uint8_t le_search_win_delay;

  uint8_t cor;
  uint8_t le_cor;
  uint8_t win_ext;
  uint8_t le_win_ext;

  int8_t  rx_golden_rssi_min;
  int8_t  rx_golden_rssi_max;
  int8_t  rssi_adjust;
  uint8_t rssi_mode;

  uint8_t low_power;
  uint8_t rsv4;
  uint8_t epc_max_tx_power_difference;
  uint8_t epc_max_tx_power_threshold;

  int8_t  tx_power_level_min;
  int8_t  tx_power_level_max;
  uint8_t tx_power_level_units; //Class 1: 25 levels, Class 2: 17 levels, Class 3: 15 levels
  uint8_t tx_power_level_step;  //min: 2dB, max: 8dB

  uint8_t power_ctrl_tab[32];
  int8_t  power_ctrl_tab_dBm[32];

  /* AFH */
  uint8_t afh_channel_bit_vector[10];
  uint8_t rsv5;
  uint8_t afh_n_min_used_channels;

  /* scan */
  uint16_t inq_scan_interval;  /* scan interval */
  uint16_t inq_scan_window;    /* scan activity window */
  uint16_t page_scan_interval; /* scan interval */
  uint16_t page_scan_window;   /* scan activity window */

  /*RF calibration parameter*/
  uint16_t tx_loft_sample_times;
  uint16_t tx_gain_sample_times;
  uint16_t tx_phase_sample_times;
  uint16_t rx_phase_sample_times;
  uint16_t agc_calibration_wait_time;

  /*low power - halt system parameter*/
  uint8_t cpu_low_power_divider;
  uint8_t apb_low_power_divider;
  uint16_t cpu_core_vol_reg;

#define HALT_SYSTEM_CPM_USB      (1<<0)
#define HALT_SYSTEM_CPM_SDHC     (1<<1)
#define HALT_SYSTEM_CPM_TIM0     (1<<2)
#define HALT_SYSTEM_CPM_TIM1     (1<<3)
#define HALT_SYSTEM_CPM_TIM2     (1<<4)
#define HALT_SYSTEM_CPM_UART0    (1<<5)
#define HALT_SYSTEM_CPM_UART1    (1<<6)
#define HALT_SYSTEM_CPM_SPI0     (1<<7)
#define HALT_SYSTEM_CPM_SPI1     (1<<8)
#define HALT_SYSTEM_CPM_I2S      (1<<9)
#define HALT_SYSTEM_CPM_DMA      (1<<10)

  uint16_t halt_system_cpm_dis_xxx;    //halt system gate xxx clock.
  uint16_t halt_system_cpm_en_xxx;

  uint16_t rsv6[79*4 - 12/2 - 4 - 9];

  /* RC calibration parameter */
  uint16_t rc_counter;     //total RC calibration counters
  uint16_t rx_adc_t1_t2[16];    // rc value of rxadc. from max to min,and the corresponding tune from min->max
  uint16_t tx_dac_t1_t2[16];    // rc value of txdac
  uint16_t rx_filter_t1_t2[8];  // rc value of rx filter
};

typedef struct bt_hc_sys_config_s bt_hc_sys_config_t;
typedef struct bt_hc_phy_config_s bt_hc_phy_config_t;


/*
 * @brief  Get major system and RF configuration structure in the Host Controller Stack.
 *
 * @param[out] pp_sys_cfg: pointer to the pointer of g_sys_config
 * @param[out] pp_phy_cfg: pointer to the pointer of g_sys_rf_cfg
 *
 * @return void
 */
void vhci_hc_get_config(bt_hc_sys_config_t **pp_sys_cfg, bt_hc_phy_config_t **pp_phy_cfg);

/**
 * @brief   vhci_hc_init with br3215c's hso
 * @details Used to initialise the virutal transport in the Host Controller Stack.
 *
 * @note to save ram size, the following dynamic queue depth in hc is not enabled.
 * @param[in] num_in_acl_packets   queue depth for incoming ACL data (packets). =8
 * @param[in] num_out_acl_packets  queue depth for outgoing ACL data (packets). =8
 * @param[in] num_in_sco_packets   queue depth for incoming SCO data (packets). =0
 * @param[in] num_out_acl_packets  queue depth for outgoing SCO data (packets). =0
 *
 * @return    0   initialisation completed successfully
 *            1   transport system already active
 */
int vhci_hc_init(uint16_t num_in_acl_packets,
                 uint16_t num_out_acl_packets,
                 uint16_t num_in_sco_packets,
                 uint16_t num_out_sco_packets);
/**
 * @brief   vhci_hc_init with br3215's hsc
 * @details Used to initialise the virutal transport in the Host Controller Stack.
 *
 * @note dynamic queue depth in hc is allocated with alloc_fn.
 */
int vhci_hc_init_queue(void *(alloc_fn)(size_t), void (free_fn)(void *));

/**
 * @brief   vhci_hc_register_os_event
 * @details Used to register HC pend/post event handlers.
 *
 * @param[in] hc_post     post the event mask.
 * @param[in] hc_pend     wait with the specified event mask, and proces the pending events.
 * @param[in] hc_timeout  the timeout in pend operation
 */
void vhci_hc_register_os_event(void (*hc_post)(uint32_t),
                               uint32_t (*hc_pend)(uint32_t, uint16_t),
                               uint16_t hc_timeout);

/**
 * @brief   vhci_hc_exit
 * @details Used to exit the virtual transport in the Host Controller Stack.
 *
 * @return  0   if exit completed successfully
 *          1   if transport system not active
 */
int vhci_hc_exit(void);

/**
 * @brief   vhci_hc_get_rx_buf
 * @details Gets a buffer from the queuing system in the Host Controller. 
 *          Once the host has written the pdu into this buffer it should commit it
 *          using "vhci_hc_commit_rx_buf"
 *
 * @param[in] buf_type   HCI_COMMAND | HCI_ACLDATA | HCI_SCODATA
 * @param[in] buf_len    Length of command, or of acl data, or of sco data:
 *                       Length of the overall command INCLUDING the bytes for the header; or
 *                       Length of the data section of the packet. Equivalent to the "data total length".
 * @param[in] hci_header Header of HCI packet:
 *                       A pointer to 3 Bytes containing the Command Opcode and the total length of the command parameters; or
 *                       A pointer to 2 Bytes containing the ACL Handle, PB_Flags & BC Flags.
 *
 * @return    a buffer pointer into which the HCI Command parameters or Data bytes are to be written;
 */
uint8_t* vhci_hc_get_rx_buf(uint8_t buf_type, int buf_len, uint8_t *hci_header);

/**
 * @brief   vhci_hc_commit_rx_buf
 * @details Commits a buffer allocated by vhci_hc_get_rx_buf to the queueing system.
 *
 * @param[in] buf_type  HCI_COMMAND | HCI_ACLDATA | HCI_SCODATA
 *                      HCI_COMMAND 0x01
 *                      HCI_ACLDATA 0x02
 *                      HCI_SCODATA 0x03
 */
void vhci_hc_commit_rx_buf(uint8_t buf_type);

/**
 * @brief   vhci_hc_register_callback_tx
 * @details Registers the function to be called back to dispatch Events or Incoming data
 *          to the Host.
 *
 * @param[in] callback  the function to be called back on incoming events or data
 *
 * @note Parameters of the Callback Function
 *-------------------------------------
 * data     - The data payload of the packet to be delivered to the host
 * pdu_len  - The length of the payload section being delivered to the host.
 * header   - The header associated with the packet.
 * head_len - The length of the header associated with the packet.
 */
void vhci_hc_register_callback_tx(void (*callback)(uint8_t *data, uint32_t pdu_len, uint8_t *header, uint8_t head_len));

/**
 * @brief   vhci_hc_ack_tx_completed
 * @detials
 * Acknowledge the completion of tranmission - this allows the next item
 * on the queue to be transmitted.
 * This function should be called once a PDU has been successfully delivered to
 * the Host. Always occurs as a result of the invokation of the host callback function
 * registered in "vhci_hc_register_callback_tx"
 *
 * @param[in] buf_type    Identifies the type of the packet being acknowledged.
 *                        HCI_ACLDATA - 0x02
 *                        HCI_EVENT   - 0x04
 * @param[in] buf_len     The length of the buffer being acknowledged.
 */
void vhci_hc_ack_tx_completed(uint8_t buf_type, uint32_t buf_len);

/**
 * @brief   vhci_hc_register_callback_exit_hc
 * @detials
 * This function is for the registration of the function to be called back
 * when there is no event/activity in the HC stack in order for the CPU process
 * to leave from the HC scheduler. The HC scheduler and the Host scheduler are
 * mapped by RTOS (Real Time Operating System) respectively so that this function
 * allows the CPU process to switch to the Host task. This function can avoid
 * that the HC scheduler consumes all of the CPU bandwidth in case of system idle.
 * This function helps the Host maintain and control the state of the processor
 * power after CPU process switches to the Host task. Thus the function registered
 * to this API may be the RTOS service call.
 *
 * @param[in] callback    the function to be called back on exit Host Controller.
 */
void vhci_hc_register_callback_exit_hc(void (*callback)(void));


/**
 * @brief   vhci_hc_check_event
 * @details
 * This function allows the Host to check for events/activities in the HC
 * from the Host side. If the Host recognizes that the HC has no event/activity
 * by using this API for checking and there is no event/activity in the Host
 * itself, the Host can make the processor sleep.
 *
 * @return  0   if there are events/activities in the Host Controller.
 *          1   if there is no event/activity in the Host Controller.
 */
uint8_t vhci_hc_check_event(void);

/**
 * @brief   vhci_hc_check_sniff
 * @details
 * This function allows the Host to check whether the system halt is available or
 * not in the HC. If the Host has no hardware event or host activity to process and
 * this API reports sniff/hold/park state, the Host can make the system halt.
 *
 * @return  0   if the Host Controller does not allow to halt system.
 *          1   if system halt is avalable in the Host Controller.
 */
uint8_t vhci_hc_check_sniff(void);

uint8_t* hci_generic_rx_done(uint8_t *packet, uint32_t size, uint8_t packet_type);

/**
 * @brief   bluetooth interrupt handler
 * @details combined version of hc + host
 */
void bt_isr(void);

/**
 * @brief   bluetooth stack main entry
 * @details combined version of hc + host
 */
void bt_main(void);

/**
 * @brief   bluetooth stack scheduler
 * @details combined version of hc + host
 */
int bt_schedule(void);

/**
 * @brief   bluetooth is sleep.
 * @note    system may execute WFI if true.
 * @return  true: sleep allowed, false otherwise
 * @details combined version of hc + host
 */
bool bt_sleep(void);

/**
 * @brief   bluetooth is halted.
 * @note    system may switch to LPO if true.
 * @return  true: halted allowed, false otherwise
 * @details combined version of hc + host
 */
bool bt_halted(void);

#if defined __cplusplus
}
#endif

#endif
