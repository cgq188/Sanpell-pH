/*
    ChibiOS - Copyright (C) 2006..2015 Giovanni Di Sirio

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    adc.h
 * @brief   ADC Driver macros and structures.
 *
 * @addtogroup ADC
 * @{
 */

/**
 * ADC User Guide:
 * 0. Note:
 *    1) Input range:
 *       [----, 0.0v): forbidden.
 *       [0.0v, 0.1v): inaccurate.
 *       [0.1v, 1.8v]: best input range. (BR3215 valid only in this range)
 *       (1.8v, 2.2v): valid input range, VCM used.
 *       [2.2v, 2.7v): measured value will slowly decrease.
 *       [2.7v, 3.3v): measured value will sharply decrease.
 *       [3.3v, ----): forbidden, input impedance will sharply decrease.
 *
 *       It is recommended that input signal be adjusted into the [0.1v, 1.8v]
 *       range for best result.
 *       Both singe-ended and differential signals should be within the
 *       valid range.
 *
 *    2) Temperature data unit:
 *       Temperature data of @p adcsample_t type is in 10 degree Celsius unit,
 *       in order to accommodate it in the underlying int16_t data type.
 *
 *    3) ADC_CAL_TABLE:
 *       User should define this macro to point to their calibrated parameter
 *       table, which is measured and stored in Flash during FT test.
 *       In case of BR3215, it should point to an @p adc_cal_param_3235_t object.
 *       In case of BR3215c, it should point to an @p adc_cal_table_t object.
 *
 *
 * 1. User guide:
 *    0) ADC initialization:
 *    // Normally this is not needed since it is already initialized
 *    // during system start-up.
 *    adcInit();
 *    adcObjectInit(adcp);
 *
 *    1) Build conversion group and add channels
 *    // You can configure circular/linear buffer mode, trigger source/edge/target,
 *    // and notification/error callback functions.
 *    ADCConversionGroup group;
 *    adcBuildConversionGroup(&group, ...);
 *    // Add single-ended/differential channels with specified signal characters.
 *    // Note that by now each group can only include the same type of channels.
 *    adcAddChannelSingleEnded(&group, ...) or adcAddChannelDifferential(&group, ...);
 *    ...
 *    adcAddChannelSingleEnded(&group, ...) or adcAddChannelDifferential(&group, ...);
 *
 *    // If the on-chip temperature or battery channel is going to be used, you
 *    // can simply call the following functions:
 *    // Note they can only be added to single-ended groups.
 *    adcAddChannelTemperature(&group) or adcAddChannelBattery(&group);
 *
 *    2) Configure external channel pins and timer/external trigger source when necessary.
 *    adcConfigExternalChannelPins(&group);
 *    // adcConfigHardTriggerSource(&group);
 *    adcConfigExternalTriggerPin() or adcConfigTimerTriggerChannel();
 *
 *    3) Allocate buffer for conversion results:
 *    // The buffer is organized as a matrix of M*N elements where M is the
 *    // channels number configured into the conversion group and N is the
 *    // buffer depth. The samples are sequentially written into the buffer
 *    // with no gaps.
 *    // In the following statements, M=num_channels, N=depth.
 *    adcsample_t *buffer =
 *      (adcsample_t*)osalHeapAlloc(NULL, num_channels*depth*sizeof(adcsample_t));
 *
 *    4) ADC conversion
 *    adcAcquireBus(adcp);
 *    adcStart(adcp, NULL);
 *    adcConvert(adcp, &group, buffer, depth, TIME_INFINITE); // synchronous conversion
 *    adcStopConversion(adcp);
 *    adcStop(adcp);
 *    adcReleaseBus(adcp);
 *
 *    5) Restore external channel pins to their default settings.
 *    adcRestoreExternalChannelPins(&group);
 *
 *    6) Data processing
 *    // The converted results above are fixed-point data in Q4.11 format,
 *    // you can convert them into floating-point format using the following function.
 *    float *fdata =
 *      (float*)osalHeapAlloc(NULL, num_channels*depth*sizeof(float));
 *    adcDataFixedToFloat(fdata, buffer, num_channels*depth);
 *
 *    // Temperature data should be multiplied by 10:
 *    float t = t_float_from_4q11*10;
 *
 *    // Then do whatever you want with the data.
 */

#ifndef _ADC_H_
#define _ADC_H_

#if (HAL_USE_ADC == TRUE) || defined(__DOXYGEN__)
#include "br32xxconf.h"
/*===========================================================================*/
/* Driver constants.                                                         */
/*===========================================================================*/
#define ADC_ERROR_NULLPTR          -10
#define ADC_ERROR_STATE            -11
/*===========================================================================*/
/* Driver pre-compile time settings.                                         */
/*===========================================================================*/

/**
 * @name    ADC configuration options
 * @{
 */
/**
 * @brief   Enables synchronous APIs.
 * @note    Disabling this option saves both code and data space.
 */
#if !defined(ADC_USE_WAIT) || defined(__DOXYGEN__)
#define ADC_USE_WAIT                TRUE
#endif

/**
 * @brief   Enables the @p adcAcquireBus() and @p adcReleaseBus() APIs.
 * @note    Disabling this option saves both code and data space.
 */
#if !defined(ADC_USE_MUTUAL_EXCLUSION) || defined(__DOXYGEN__)
#define ADC_USE_MUTUAL_EXCLUSION    TRUE
#endif
/** @} */

/*===========================================================================*/
/* Derived constants and error checks.                                       */
/*===========================================================================*/

/*===========================================================================*/
/* Driver data structures and types.                                         */
/*===========================================================================*/

/**
 * CP/FT test commands for ADC calibration.
 *
 * When PA1 is used as external reference input:
 * 1. The voltage on the pin must be higher than 2.0V when the pin is in RESET
 *    pin mode.
 * 2. Before calibration, ADC_CAL_CMD_BEGIN must be firstly issued to switch
 *    pin configurations between RESET pin mode and GPIO mode.
 * 3. In each of the calibration test, ATE should already be giving out voltages
 *    to PIN0 and PIN1 accordingly before issuing out each of the test commands.
 * 4. After all calibrations, ADC_CAL_CMD_END should be issued to restore the
 *    pin configurations.
 */
typedef enum adc_cal_cmd_t {
	ADC_CAL_CMD_SINGLE_ENDED_0 = 0,    // [PIN0, PIN1] = [1.4, 2.1 or X]V
	ADC_CAL_CMD_SINGLE_ENDED_1,        // [PIN0, PIN1] = [0.8, X]V
	ADC_CAL_CMD_SINGLE_ENDED_2,        // [PIN0, PIN1] = [0.4, X]V
	ADC_CAL_CMD_SINGLE_ENDED_3,        // [PIN0, PIN1] = [0.2, X]V

	ADC_CAL_CMD_DIFFERENTIAL_0,        // [PIN0, PIN1] = [1+0.7, 1-0.7]V
	ADC_CAL_CMD_DIFFERENTIAL_1,        // [PIN0, PIN1] = [1+0.4, 1-0.4]V
	ADC_CAL_CMD_DIFFERENTIAL_2,        // [PIN0, PIN1] = [1+0.2, 1-0.2]V
	ADC_CAL_CMD_DIFFERENTIAL_3,        // [PIN0, PIN1] = [1+0.1, 1-0.1]V

	ADC_CAL_CMD_BEGIN,                 // [PIN0, PIN1] = [2.1, 2.1]V, configure external pins
	ADC_CAL_CMD_END,                   // [PIN0, PIN1] = [2.1, 2.1]V, restore external pins
} adc_cal_cmd_t;

/**
 * @brief   Driver state machine possible states.
 */
typedef enum {
  ADC_UNINIT = 0,                           /**< Not initialized.           */
  ADC_STOP = 1,                             /**< Stopped.                   */
  ADC_READY = 2,                            /**< Ready.                     */
  ADC_ACTIVE = 3,                           /**< Converting.                */
  ADC_COMPLETE = 4,                         /**< Conversion complete.       */
  ADC_ERROR = 5,                             /**< Conversion complete.       */
#if (HS_HAS_DMA == TRUE) && (ADC_USE_DMA == TRUE)
  ADC_DMAACTIVE = 6,                        /**< DMA Conversion .           */
#endif
} adcstate_t;

#include "adc_lld.h"

/*===========================================================================*/
/* Driver macros.                                                            */
/*===========================================================================*/

#define adcSetTestData(val)       adc_lld_set_test_data(val)

/**
 * @name    Low level driver helper macros
 * @{
 */
#if (ADC_USE_WAIT == TRUE) || defined(__DOXYGEN__)
/**
 * @brief   Resumes a thread waiting for a conversion completion.
 *
 * @param[in] adcp      pointer to the @p ADCDriver object
 *
 * @notapi
 */
#define _adc_reset_i(adcp)                                                  \
  osalThreadResumeI(&(adcp)->thread, MSG_RESET)

/**
 * @brief   Resumes a thread waiting for a conversion completion.
 *
 * @param[in] adcp      pointer to the @p ADCDriver object
 *
 * @notapi
 */
#define _adc_reset_s(adcp)                                                  \
  osalThreadResumeS(&(adcp)->thread, MSG_RESET)

/**
 * @brief   Wakes up the waiting thread.
 *
 * @param[in] adcp      pointer to the @p ADCDriver object
 *
 * @notapi
 */
#define _adc_wakeup_isr(adcp) {                                             \
  osalSysLockFromISR();                                                     \
  osalThreadResumeI(&(adcp)->thread, MSG_OK);                               \
  osalSysUnlockFromISR();                                                   \
}

/**
 * @brief   Wakes up the waiting thread with a timeout message.
 *
 * @param[in] adcp      pointer to the @p ADCDriver object
 *
 * @notapi
 */
#define _adc_timeout_isr(adcp) {                                            \
  osalSysLockFromISR();                                                     \
  osalThreadResumeI(&(adcp)->thread, MSG_TIMEOUT);                          \
  osalSysUnlockFromISR();                                                   \
}

#else /* !ADC_USE_WAIT */
#define _adc_reset_i(adcp)
#define _adc_reset_s(adcp)
#define _adc_wakeup_isr(adcp)
#define _adc_timeout_isr(adcp)
#endif /* !ADC_USE_WAIT */

/**
 * @brief   Common ISR code, half buffer event.
 * @details This code handles the portable part of the ISR code:
 *          - Callback invocation.
 *          .
 * @note    This macro is meant to be used in the low level drivers
 *          implementation only.
 *
 * @param[in] adcp      pointer to the @p ADCDriver object
 *
 * @notapi
 */
#define _adc_isr_half_code(adcp) {                                          \
  if ((adcp)->grpp->end_cb != NULL) {                                       \
    (adcp)->grpp->end_cb(adcp, (adcp)->samples, (adcp)->depth / 2);         \
  }                                                                         \
}

/**
 * @brief   Common ISR code, full buffer event.
 * @details This code handles the portable part of the ISR code:
 *          - Callback invocation.
 *          - Waiting thread wakeup, if any.
 *          - Driver state transitions.
 *          .
 * @note    This macro is meant to be used in the low level drivers
 *          implementation only.
 *
 * @param[in] adcp      pointer to the @p ADCDriver object
 *
 * @notapi
 */
#define _adc_isr_full_code(adcp) {                                          \
  if ((adcp)->grpp->circular && ((adcp)->thread==NULL)) {                   \
    /* Callback handling.*/                                                 \
    if ((adcp)->grpp->end_cb != NULL) {                                     \
      if ((adcp)->depth > 1) {                                              \
        /* Invokes the callback passing the 2nd half of the buffer.*/       \
        size_t half = (adcp)->depth / 2;                                    \
        size_t half_index = half * (adcp)->grpp->num_channels;              \
        (adcp)->grpp->end_cb(adcp, (adcp)->samples + half_index, half);     \
      }                                                                     \
      else {                                                                \
        /* Invokes the callback passing the whole buffer.*/                 \
        (adcp)->grpp->end_cb(adcp, (adcp)->samples, (adcp)->depth);         \
      }                                                                     \
    }                                                                       \
  }                                                                         \
  else {                                                                    \
    /* End conversion.*/                                                    \
    adc_lld_stop_conversion(adcp);                                          \
    if ((adcp)->grpp->end_cb != NULL) {                                     \
      (adcp)->state = ADC_COMPLETE;                                         \
      /* Invoke the callback passing the whole buffer.*/                    \
      (adcp)->grpp->end_cb(adcp, (adcp)->samples, (adcp)->depth);           \
      if ((adcp)->state == ADC_COMPLETE) {                                  \
        (adcp)->state = ADC_READY;                                          \
        (adcp)->grpp = NULL;                                                \
      }                                                                     \
    }                                                                       \
    else {                                                                  \
      (adcp)->state = ADC_READY;                                            \
      (adcp)->grpp = NULL;                                                  \
    }                                                                       \
    _adc_wakeup_isr(adcp);                                                  \
  }                                                                         \
}

/**
 * @brief   Common ISR code, error event.
 * @details This code handles the portable part of the ISR code:
 *          - Callback invocation.
 *          - Waiting thread timeout signaling, if any.
 *          - Driver state transitions.
 *          .
 * @note    This macro is meant to be used in the low level drivers
 *          implementation only.
 *
 * @param[in] adcp      pointer to the @p ADCDriver object
 * @param[in] err       platform dependent error code
 *
 * @notapi
 */
#define _adc_isr_error_code(adcp, err) {                                    \
  adc_lld_stop_conversion(adcp);                                            \
  if ((adcp)->grpp->error_cb != NULL) {                                     \
    (adcp)->state = ADC_ERROR;                                              \
    (adcp)->grpp->error_cb(adcp, err);                                      \
    if ((adcp)->state == ADC_ERROR)                                         \
      (adcp)->state = ADC_READY;                                            \
  }                                                                         \
  (adcp)->grpp = NULL;                                                      \
  _adc_timeout_isr(adcp);                                                   \
}
/** @} */

/*===========================================================================*/
/* External declarations.                                                    */
/*===========================================================================*/

#ifdef __cplusplus
extern "C" {
#endif
  void adcInit(void);
  void adcObjectInit(ADCDriver *adcp);
  msg_t adcStart(ADCDriver *adcp, const ADCConfig *config);
  void adcStop(ADCDriver *adcp);

  int adcStartConversion(ADCDriver *adcp,
                          const ADCConversionGroup *grpp,
                          adcsample_t *samples,
                          size_t depth);

  int adcStartConversionI(ADCDriver *adcp,
                           const ADCConversionGroup *grpp,
                           adcsample_t *samples,
                           size_t depth);

#if (HS_HAS_DMA == TRUE) && (ADC_USE_DMA == TRUE)
  int adcStartConversionWithDMA(ADCDriver *adcp, uint8_t *pDmaBuf, uint32_t DmaLen);
  int adcDmaWaitForDone(ADCDriver *adcp, systime_t timeout);
#endif
  
  void adcStopConversion(ADCDriver *adcp);
  void adcStopConversionI(ADCDriver *adcp);

#if ADC_USE_WAIT == TRUE
  msg_t adcConvert(ADCDriver *adcp,
                   const ADCConversionGroup *grpp,
                   adcsample_t *samples,
                   size_t depth,
                   systime_t timeout);
#endif

#if ADC_USE_MUTUAL_EXCLUSION == TRUE
  void adcAcquireBus(ADCDriver *adcp);
  void adcReleaseBus(ADCDriver *adcp);
#else
#define adcAcquireBus(adcp)
#define adcReleaseBus(adcp)
#endif

 /**
  * APIs for ADC Conversion Group building.
  */
  void adcBuildConversionGroup(ADCConversionGroup *grpp,
                             bool circular,
                             bool cal_en,
                             adc_trigger_source_t trigger_source,
                             adc_trigger_edge_t trigger_edge,
                             adc_trigger_target_t trigger_target,
                             adccallback_t end_cb,
                             adcerrorcallback_t error_cb);
  int adcAddChannelSingleEnded(ADCConversionGroup *grpp,
		                         adc_channel_t chn,
		                         int max_mv,
		                         int min_mv,
		                         uint32_t gpio_pin);
  int adcAddChannelDifferential(ADCConversionGroup *grpp,
                              adc_channel_t chn_pos,
                              adc_channel_t chn_neg,
                              int max_abs_vpn_mv,
                              uint32_t gpio_pin_inp,
                              uint32_t gpio_pin_inn);

  int adcAddChannelTemperature(ADCConversionGroup *grpp);
  int adcAddChannelBattery(ADCConversionGroup *grpp);
#if defined(BR3215e)
  int adcAddChannel1V4(ADCConversionGroup *grpp);
  int adcAddChannel3V3(ADCConversionGroup *grpp);
#endif
  void adcDataFixedToFloat(float *fdata, adcsample_t *samples, uint32_t num);
  void adcConfigExternalChannelPins(ADCConversionGroup *grpp);
  void adcRestoreExternalChannelPins(ADCConversionGroup *grpp);
  void adcConfigExternalTriggerPin(void);
#define adcDeleteChannel(grpp, chn)\
	adc_lld_delete_channel(grpp, chn)
/**
 * APIs for ADC Calibration.
 */
  void adcCalibrate(ADCDriver *adcp,
  		              adc_cal_table_t *cal_table,
  		              adc_cal_cmd_t cmd,
  		              adc_channel_t ch0,
  		              adc_channel_t ch1);

// End of APIs of ADC adjustment

#ifdef __cplusplus
}
#endif

#endif /* HAL_USE_ADC == TRUE */

#endif /* _ADC_H_ */

/** @} */
