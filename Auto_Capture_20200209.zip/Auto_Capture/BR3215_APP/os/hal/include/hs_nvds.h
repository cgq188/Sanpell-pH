/**
 ****************************************************************************************
 *
 * @file hs_nvds.h
 *
 * @brief Non Volatile Data Storage (NVDS) driver
 *
 * Copyright (C) RivieraWaves 2009-2012
 * Copyright (C) luwei 2017
 *
 * $Rev: 12776 $
 *
 ****************************************************************************************
 */
#ifndef _HS_NVDS_H_
#define _HS_NVDS_H_

/**
 ****************************************************************************************
 * @addtogroup NVDS
 * @ingroup COMMON
 * @brief Non Volatile Data Storage (NVDS)
 *
 * @{
 ****************************************************************************************
 */

/*
 * INCLUDE FILES
 ****************************************************************************************
 */
#include <stdbool.h>           // boolean definition
#include <stdint.h>            // integer definition

/*
 * DEFINES
 ****************************************************************************************
 */

typedef uint8_t  nvds_tag_t;
typedef uint8_t  nvds_blk_t;

/// Type of the tag length (16 bits)
typedef uint16_t nvds_tag_len_t;


/*
 * ENUMERATION DEFINITIONS
 ****************************************************************************************
 */

/// Possible Returned Status
enum NVDS_STATUS
{
  /// NVDS status OK
  NVDS_OK,
  /// generic NVDS status KO
  NVDS_FAIL,
  /// NVDS TAG unrecognized
  NVDS_TAG_NOT_DEFINED,
  /// No space for NVDS
  NVDS_NO_SPACE_AVAILABLE,
  /// Length violation
  NVDS_LENGTH_OUT_OF_RANGE,
  /// NVDS parameter locked
  NVDS_PARAM_LOCKED,
  /// NVDS corrupted
  NVDS_CORRUPT
};

/// List of NVDS TAG identifiers
enum NVDS_TAG
{
  NVDS_TAG_BT_PAIR_COUNT              = 0x00,
  NVDS_TAG_BT_PAIR_ENTRY_1            = 0x01,
  NVDS_TAG_BT_PAIR_ENTRY_2,
  NVDS_TAG_BT_PAIR_ENTRY_3,
  NVDS_TAG_BT_PAIR_ENTRY_4,
  NVDS_TAG_BT_PAIR_ENTRY_5,
  NVDS_TAG_BT_PAIR_ENTRY_6,
  NVDS_TAG_BT_PAIR_ENTRY_HID,

  NVDS_TAG_AUDIO_VOLUME               = 0x10,
  NVDS_TAG_AUDIO_EQ_INDEX,

  NVDS_TAG_APP_MUSIC_MODE             = 0x20,
  NVDS_TAG_APP_MUSIC_CONTEXT,
  NVDS_TAG_APP_FM_FREQ                = 0x28,
  NVDS_TAG_APP_FM_TBL_AVAIL,
  NVDS_TAG_APP_FM_TBL_FREQ,
  NVDS_TAG_APP_FM_TBL_CTX,

  NVDS_TAG_NUM,

  /// this is the TAG used to be the marker of the last TAG in NVDS (= 0xFF because when
  /// FLASH are erased, they are set to = 0xFF)
  NVDS_END_MARKER_TAG                 = 0xFF,
};

/// List of NVDS Tag lengths
enum NVDS_LEN
{
  NVDS_LEN_BT_PAIR_COUNT              = 1,
  NVDS_LEN_BT_PAIR_ENTRY_1            = 23,
  NVDS_LEN_BT_PAIR_ENTRY_2            = 23,
  NVDS_LEN_BT_PAIR_ENTRY_3            = 23,
  NVDS_LEN_BT_PAIR_ENTRY_4            = 23,
  NVDS_LEN_BT_PAIR_ENTRY_5            = 23,
  NVDS_LEN_BT_PAIR_ENTRY_6            = 23,
  NVDS_LEN_BT_PAIR_ENTRY_HID          = 23,

  NVDS_LEN_AUDIO_VOLUME               = 6,
  NVDS_LEN_AUDIO_EQ_INDEX             = 1,

  NVDS_LEN_APP_MUSIC_MODE             = 1,
  NVDS_LEN_APP_MUSIC_CONTEXT          = 16+20,
  NVDS_LEN_APP_FM_FREQ                = 4,
  NVDS_LEN_APP_FM_TBL_AVAIL           = 1,
  NVDS_LEN_APP_FM_TBL_FREQ            = 32*4,
  NVDS_LEN_APP_FM_TBL_CTX             = 32*4,
};

/// NVDS parameter data maximum length
#define NVDS_PARAMETER_MAX_LENGTH   (NVDS_LEN_APP_FM_TBL_FREQ + 8)


/*
 * FUNCTION DECLARATIONS
 ****************************************************************************************
 */

/**
 ****************************************************************************************
 * @brief Initialize NVDS.
 * @return NVDS_OK
 ****************************************************************************************
 */
uint8_t hs_nvds_init(nvds_tag_t nTags, nvds_blk_t nBlocks, uint32_t BlockSize, uint8_t *workSpace, uint16_t workLen);

/**
 ****************************************************************************************
 * @brief Uninitialize NVDS.
 * @return NVDS_OK
 ****************************************************************************************
 */
uint8_t hs_nvds_exit(void);

/**
 ****************************************************************************************
 * @brief Set debug level.
 * @return NVDS_OK
 ****************************************************************************************
 */
uint8_t hs_nvds_debug(uint8_t level);

/**
 ****************************************************************************************
 * @brief Reclaim NVDS at background or forground.
 * @return NVDS_OK
 ****************************************************************************************
 */
uint8_t hs_nvds_reclaim(void);

/**
 ****************************************************************************************
 * @brief Look for a specific tag and return, if found and matching (in length), the
 *        DATA part of the TAG.
 *
 * If the length does not match, the TAG header structure is still filled, in order for
 * the caller to be able to check the actual length of the TAG.
 *
 * @param[in]  tag     TAG to look for whose DATA is to be retrieved
 * @param[in]  length  Expected length of the TAG
 * @param[out] buf     A pointer to the buffer allocated by the caller to be filled with
 *                     the DATA part of the TAG
 *
 * @return  NVDS_OK                  The read operation was performed
 *          NVDS_LENGTH_OUT_OF_RANGE The length passed in parameter is different than the TAG's
 ****************************************************************************************
 */
uint8_t hs_nvds_get(nvds_tag_t tag, nvds_tag_len_t * lengthPtr, uint8_t *buf);

/**
 ****************************************************************************************
 * @brief This function adds a specific TAG to the NVDS.
 *
 * Steps:
 * 1) parse all the TAGs to:
 * 1.1) calculate the total size of all the valid TAGs
 * 1.2) erase the existing TAGs that have the same ID
 * 1.3) check if we can use the same TAG area in case of an EEPROM
 * 1.4) check that the TAG is not locked
 * 2) if we have to add the new TAG at the end fo the NVDS (cant use same area):
 * 2.1) allocate the appropriate amount of memory
 * 2.2) purge the NVDS
 * 2.3) free the memory allocated
 * 2.4) check that there is now enough room for the new TAG or return
 *      NO_SPACE_AVAILABLE
 * 3) add the new TAG
 *
 * @param[in]  tag     TAG to look for whose DATA is to be retrieved
 * @param[in]  length  Expected length of the TAG
 * @param[in]  buf     Pointer to the buffer containing the DATA part of the TAG to add to
 *                     the NVDS
 *
 * @return NVDS_OK                  New TAG correctly written to the NVDS
 *         NVDS_PARAM_LOCKED        New TAG is trying to overwrite a TAG that is locked
 *         NO_SPACE_AVAILABLE       New TAG can not fit in the available space in the NVDS
 ****************************************************************************************
 */
uint8_t hs_nvds_put(nvds_tag_t tag, nvds_tag_len_t length, uint8_t *buf);

/// @} NVDS

#endif // _HS_NVDS_H_
