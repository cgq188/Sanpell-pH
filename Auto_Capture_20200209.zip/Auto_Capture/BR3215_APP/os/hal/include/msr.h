/*
    ChibiOS - Copyright (C) 2019 BRMICRO Technologies
              

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    msr.h
 * @brief   MSR (Magnetic Strip Reader) Driver macros and structures.
 *
 * @addtogroup MSR
 * @{
 */

#ifndef _MSR_H_
#define _MSR_H_

#if (HAL_USE_MSR == TRUE) || defined(__DOXYGEN__)

/*===========================================================================*/
/* Driver constants.                                                         */
/*===========================================================================*/

/**
 * @name    MSR error conditions
 */
#define MSR_NO_ERROR                    0U
#define MSR_BUS_ERROR                   1U
#define MSR_OVERRUN_ERROR               2U
#define MSR_TIMEOUT_ERROR               4U
#define MSR_UNHANDLED_ERROR             0xFFFFFFFFU

#define MSR_TRACK1_CHARS                79
#define MSR_TRACK2_CHARS                40
#define MSR_TRACK3_CHARS                107

/*===========================================================================*/
/* Driver pre-compile time settings.                                         */
/*===========================================================================*/


/*===========================================================================*/
/* Derived constants and error checks.                                       */
/*===========================================================================*/

/*===========================================================================*/
/* Driver data structures and types.                                         */
/*===========================================================================*/

/**
 * @brief Driver state machine possible states.
 */
typedef enum {
  MSR_UNINIT = 0,                   /**< Not initialized.                   */
  MSR_STOP = 1,                     /**< Stopped.                           */
  MSR_ACTIVE = 2                    /**< Started.                            */
} msr_state_t;

#include "msr_lld.h"

/*===========================================================================*/
/* Driver macros.                                                            */
/*===========================================================================*/

/**
 * @brief   Set the user buffer to MSR peripheral for all magnetic tracks.
 *
 * @param[in] msrp      pointer to the @p MSRDriver object
 * @param[in] buf       pointer to the @p capture buffer allocated by user
 * @return              None
 *
 * @api
 */
#define msrSetBuffer(msrp, buf) ((msrp)->f2f_buf[0] = buf)

/**
 * @brief   Set the decoder thread to MSR driver.
 *
 * @param[in] msrp      pointer to the @p MSRDriver object
 * @param[in] thd       pointer to the @p decoder thread created by user
 * @return              None
 *
 * @api
 */
#define msrSetThread(msrp, thd) ((msrp)->f2f_thd = thd)


/*===========================================================================*/
/* External declarations.                                                    */
/*===========================================================================*/

#ifdef __cplusplus
extern "C" {
#endif
  void msrInit(void);
  void msrObjectInit(MSRDriver *msrp);
  void msrStart(MSRDriver *msrp, const MSRConfig *config);
  void msrStop(MSRDriver *msrp);
  bool msrDecode(MSRDriver *msrp);
  int msrDecodeTest(MSRDriver *msrp, int index, int track);
#ifdef __cplusplus
}
#endif

#endif /* HAL_USE_MSR == TRUE */

#endif /* _MSR_H_ */

/** @} */
