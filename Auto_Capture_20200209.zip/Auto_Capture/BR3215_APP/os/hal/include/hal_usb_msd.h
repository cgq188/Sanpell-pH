/*
    ChibiOS/HAL - Copyright (C) 2016 Uladzimir Pylinsky aka barthess

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    hal_usb_msd.h
 * @brief   USM mass storage device driver macros and structures.
 *
 * @addtogroup usb_msd
 * @{
 */

#ifndef HAL_USB_MSD_H
#define HAL_USB_MSD_H

#if (HAL_USE_USB_MSD == TRUE) || defined(__DOXYGEN__)

#include "lib_scsi.h"
/**
 * @brief   Type of stack and memory alignment enforcement.
 * @note    In this architecture the stack alignment is enforced to 64 bits,
 *          32 bits alignment is supported by hardware but deprecated by ARM,
 *          the implementation choice is to not offer the option.
 */
typedef uint64_t stkalign_t;
typedef uint32_t regarm_t;

#define PORT_INT_REQUIRED_STACK         256//64
/**
 * @brief   Computes the thread working area global size.
 * @note    There is no need to perform alignments in this macro.
 */
struct port_extctx {
  regarm_t      ipc;
  regarm_t      ipsw;
#if defined(__NDS32_EXT_IFC__) && !defined(CONFIG_NO_NDS32_EXT_IFC)
  regarm_t      ifc_lp;
  regarm_t      dummy; //keep stack pointer 8-byte aligned
#endif

  regarm_t      r15;
  regarm_t      r16;
  regarm_t      r17;
  regarm_t      r18;
  regarm_t      r19;
  regarm_t      r20;
  regarm_t      r21;
  regarm_t      r22;
  regarm_t      r23;
  regarm_t      r24;
  regarm_t      r25;
  regarm_t      r26;
  regarm_t      r27;
  regarm_t      fp;   //r28;
  regarm_t      gp;   //r29;
  regarm_t      lp;   //r30;

  regarm_t      r0;
  regarm_t      r1;
  regarm_t      r2;
  regarm_t      r3;
  regarm_t      r4;
  regarm_t      r5;
};

struct port_intctx {
  /* smw.adm $r6, [$sp], $r14, #0xa */
  /* lmw.bim $r6, [$sp], $r14, #0xa */
  regarm_t      r6;
  regarm_t      r7;
  regarm_t      r8;
  regarm_t      r9;
  regarm_t      r10;
  regarm_t      r11;
  regarm_t      r12;
  regarm_t      r13;
  regarm_t      r14;
  regarm_t      fp;   //r27
  regarm_t      lp;   //r30;
};

#define PORT_WA_SIZE(n) (sizeof(struct port_intctx) +                       \
                         sizeof(struct port_extctx) +                       \
                         ((size_t)(n)) + ((size_t)(PORT_INT_REQUIRED_STACK)))

/**
 * @name    Working Areas and Alignment
 */
/**
 * @brief   Enforces a correct alignment for a stack area size value.
 *
 * @param[in] n         the stack size to be aligned to the next stack
 *                      alignment boundary
 * @return              The aligned stack size.
 *
 * @api
 */
#define THD_ALIGN_STACK_SIZE(n)                                             \
  ((((n) - 1U) | (sizeof(stkalign_t) - 1U)) + 1U)

/**
 * @brief   Calculates the total Working Area size.
 *
 * @param[in] n         the stack size to be assigned to the thread
 * @return              The total used memory in bytes.
 *
 * @api
 */
#define THD_WORKING_AREA_SIZE(n)                                            \
  THD_ALIGN_STACK_SIZE(PORT_WA_SIZE(n))
/**
 * @brief   Static working area allocation.
 * @details This macro is used to allocate a static thread working area
 *          aligned as both position and size.
 *
 * @param[in] s         the name to be assigned to the stack array
 * @param[in] n         the stack size to be assigned to the thread
 *
 * @api
 */
#define THD_WORKING_AREA(s, n)                                              \
  stkalign_t s[THD_WORKING_AREA_SIZE(n) / sizeof(stkalign_t)]

/*===========================================================================*/
/* Driver constants.                                                         */
/*===========================================================================*/

#define USB_MSD_DATA_EP                 0x01

/*===========================================================================*/
/* Driver pre-compile time settings.                                         */
/*===========================================================================*/

/*===========================================================================*/
/* Derived constants and error checks.                                       */
/*===========================================================================*/

#if !HAL_USE_USB
#error "Mass storage Driver requires HAL_USE_USB"
#endif

#if !USB_USE_WAIT
#error "Mass storage Driver requires USB_USE_WAIT"
#endif

/*===========================================================================*/
/* Driver data structures and types.                                         */
/*===========================================================================*/

/**
 * @brief   Type of a structure representing an USB mass storage driver.
 */
typedef struct USBMassStorageDriver USBMassStorageDriver;

/**
 * @brief   Type of a driver state machine possible states.
 */
typedef enum {
  USB_MSD_UNINIT = 0,
  USB_MSD_STOP,
  USB_MSD_READY,
} usbmsdstate_t;

/**
 * @brief   Represents command block wrapper structure.
 * @details See USB Mass Storage Class Specification.
 */
typedef struct PACKED_VAR {
  uint32_t  signature;
  uint32_t  tag;
  uint32_t  data_len;
  uint8_t   flags;
  uint8_t   lun;
  uint8_t   cmd_len;
  uint8_t   cmd_data[16];
} msd_cbw_t;

/**
 * @brief   Represents command status wrapper structure.
 * @details See USB Mass Storage Class Specification.
 */
typedef struct PACKED_VAR {
  uint32_t  signature;
  uint32_t  tag;
  uint32_t  data_residue;
  uint8_t   status;
} msd_csw_t;

/**
 * @brief   Transport handler passed to SCSI layer.
 */
typedef struct {
  /**
   * @brief   Pointer to the @p USBDriver object.
   */
  USBDriver *usbp;
  /**
   * @brief   USB endpoint number.
   */
  usbep_t   ep;
} usb_scsi_transport_handler_t;


/**
 * @brief   Structure representing an USB mass storage driver.
 */
struct USBMassStorageDriver {
  /**
   * @brief   Pointer to the @p USBDriver object.
   */
  USBDriver                     *usbp;
  /**
   * @brief   Driver state.
   */
  usbmsdstate_t                 state;
  /**
   * @brief   CBW structure.
   */
  msd_cbw_t                     cbw;
  /**
   * @brief   CSW structure.
   */
  msd_csw_t                     csw;
  /**
   * @brief   Thread working area.
   */
  //THD_WORKING_AREA(             waMSDWorker, 512);
  /**
   * @brief   Worker thread handler.
   */
  thread_reference_t            worker;
  /**
   * @brief   SCSI target driver structure.
   */
  SCSITarget                    scsi_target;
  /**
   * @brief   SCSI target configuration structure.
   */
  SCSITargetConfig              scsi_config;
  /**
   * @brief   SCSI transport structure.
   */
  SCSITransport                 scsi_transport;
  /**
   * @brief   SCSI over USB transport handler structure.
   */
  usb_scsi_transport_handler_t  usb_scsi_transport_handler;

  int host_ctrl_started;
  int last_scsi_cmd_time;
};


/*===========================================================================*/
/* Driver macros.                                                            */
/*===========================================================================*/

/*===========================================================================*/
/* External declarations.                                                    */
/*===========================================================================*/

extern USBMassStorageDriver USBMSD1;

#ifdef __cplusplus
extern "C" {
#endif
  extern USBMassStorageDriver *gusbhandle;
  void msdObjectInit(USBMassStorageDriver *msdp);
  void msdStart(USBMassStorageDriver *msdp, USBDriver *usbp,
                BaseBlockDevice *blkdev, uint8_t *blkbuf,
                const scsi_inquiry_response_t *scsi_inquiry_response,
                const scsi_unit_serial_number_inquiry_response_t *serialInquiry);
  void msdStop(USBMassStorageDriver *msdp);
  bool msd_request_hook(USBDriver *usbp);
  int usb_msd_worker (USBMassStorageDriver *msdp);
#ifdef __cplusplus
}
#endif

#endif /* HAL_USE_USB_MSD */

#endif /* HAL_USB_MSD_H */

/** @} */









