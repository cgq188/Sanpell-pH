/*
 * hal_rf.h
 *
 *  Created on: Jul 7, 2018
 *      Author: china
 */

#ifndef HAL_RF_H_
#define HAL_RF_H_

#if (HAL_USE_RF == TRUE) || defined(__DOXYGEN__)
#include "rf.h"

void rf62_setup_guard(bool en);
void rf62_setup_rate(int rate);
void rf62_setup_code(uint8_t code);
void rf62_setup_crc(uint8_t crc);
void rf62_setup_txgain(uint8_t lvl);
void rf62_power_up(bool rx_en);
void rf62_power_down(void);
void rf62_setup_freq(int freq);
void BR3215_BT_ON(uint8_t tx);
void rf_2p4G_init(uint8_t *rx_addr, int rx_addr_len, int datarate, int freq_MHz);
void HS6200rf_test(void);
void FCC_TEST(void);

#endif /* HAL_USE_RF */

#endif /* HAL_RF_H_ */
