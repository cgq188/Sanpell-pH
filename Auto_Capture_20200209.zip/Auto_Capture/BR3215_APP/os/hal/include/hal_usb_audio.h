/*
  ChibiOS/HAL - Copyright (C) 2019 BRMICRO Technologies
  pengjiang, 20140714
  luwei, 20180710

  Licensed under the Apache License, Version 2.0 (the "License");
  you may not use this file except in compliance with the License.
  You may obtain a copy of the License at

  http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
*/

#ifndef HAL_USB_AUDIO_H_
#define HAL_USB_AUDIO_H_

#if !defined(HAL_USE_USB_AUDIO)
#define HAL_USE_USB_AUDIO           FALSE
#endif

#if ((HAL_USE_USB_AUDIO == TRUE) && defined(hscAudiophile)) || defined(__DOXYGEN__)

#include "usbd.h"

/*===========================================================================*/
/* Driver local definitions.                                                 */
/*===========================================================================*/

#define USB_PLY_BUF_NUM             2
#define USB_REC_BUF_NUM             1

#if 0//defined(BR3215)
#define USB_PLY_BUF_SIZ             (EP_SIZ_ASI_OUT * 1)
#define USB_REC_BUF_SIZ             (EP_SIZ_ASI_IN  * 1)
#else
#define USB_PLY_BUF_SIZ             (EP_SIZ_ASI_OUT * 3)
#define USB_REC_BUF_SIZ             (EP_SIZ_ASI_IN  * 3)
#endif

#define IDX_PLY                     0
#define IDX_REC                     1

#define USB_AUDIO_STATE_STOP        0
#define USB_AUDIO_STATE_START       1

#define UA_SIGNAL_PLY_START             (1 << 0)
#define UA_SIGNAL_PLY_STOP              (1 << 1)
#define UA_SIGNAL_REC_START             (1 << 2)
#define UA_SIGNAL_REC_STOP              (1 << 3)
#define UA_SIGNAL_PLY_SET_VOL           (1 << 4)
#define UA_SIGNAL_PLY_SET_MUTE          (1 << 5)
#define UA_SIGNAL_PLY_SET_SR            (1 << 6)
#define UA_SIGNAL_REC_SET_VOL           (1 << 7)
#define UA_SIGNAL_REC_SET_MUTE          (1 << 8)
#define UA_SIGNAL_REC_SET_SR            (1 << 9)

/*===========================================================================*/
/* Driver constants.                                                         */
/*===========================================================================*/

//USB Audio class definition 1.0 macros
//Reference USB Device Class Definition for Audio Devices Release 1.0 SPEC p.99
//Audio Device Class Codes
//A.1 Audio Interface Class Code
#define AUDIO_CLASS_CODE                    (0x01)

//A.2 Audio Interface Subclass Codes
#define SUBCLASS_UNDEFINED                  (0x00)
#define AUDIO_CONTROL                       (0x01)
#define AUDIO_STREAMING                     (0x02)
#define MIDI_STREAMING                      (0x03)

//A.3 Audio Interface Protocol Codes
#define PR_PROTOCOL_UNDEFINED               (0x00)

//A.4 Audio Class-Specific Descriptor Types
#define CS_UNDEFINED                        (0x20)
#define CS_DEVICE                           (0x21)
#define CS_CONFIGURATION                    (0x22)
#define CS_STRING                           (0x23)
#define CS_INTERFACE                        (0x24)
#define CS_ENDPOINT                         (0x25)

//A.5 Audio Class-Specific AC Interface Descriptor Subtypes
#define AC_DESCRIPTOR_UNDEFINED             (0x00)
#define HEADER                              (0x01)
#define INPUT_TERMINAL                      (0x02)
#define OUTPUT_TERMINAL                     (0x03)
#define MIXER_UNIT                          (0x04)
#define SELECTOR_UNIT                       (0x05)
#define FEATURE_UNIT                        (0x06)
#define PROCESSING_UNIT                     (0x07)
#define EXTENSION_UNIT                      (0x08)

//A.6 Audio CLass-Specific AS Interface Descriptor Subtypes
#define AS_DESCRIPTOR_UNDEFINED             (0x00)
#define AS_GENERAL                          (0x01)
#define FORMAT_TYPE                         (0x02)
#define FORMAT_SPECIFIC                     (0x03)

//A.7 Processing Unit Process Types
#define PROCESS_UNDEFINED                   (0x00)
#define UP_DOWNMIX_PROCESS                  (0x01)
#define DOLBY_PROLOGIC_PROCESS              (0x02)
#define THREE_D_STEREO_EXTENDER_PROCESS     (0x03)
#define REVERBERATION_PROCESS               (0x04)
#define CHORUS_PROCESS                      (0x05)
#define DYN_RANGE_COMP_PROCESS              (0x06)

//A.8 Audio Class-Specific Endpoint Descriptor Subtypes
#define DESCRIPTOR_UNDEFINED                (0x00)
#define EP_GENERAL                          (0x01)

//A.9 Audio Class-Specific Request Codes
#define REQUEST_CODE_UNDEFINED              (0x00)
#define SET_CUR                             (0x01)
#define SET_MIN                             (0x02)
#define SET_MAX                             (0x03)
#define SET_RES                             (0x04)
#define SET_MEM                             (0x05)
#define GET_CUR                             (0x81)
#define GET_MIN                             (0x82)
#define GET_MAX                             (0x83)
#define GET_RES                             (0x84)
#define GET_MEM                             (0x85)
#define GET_STAT                            (0xFF)

//A10.1 Terminal Control Selectors
#define TE_CONTROL_UNDEFINED                (0x00)
#define COPY_PROTECT_CONTROL                (0x01)

//A10.2 Feature Unit Control Selectors
#define FU_CONTROL_UNDEFINED                (0x00)
#define MUTE_CONTROL                        (0x01)
#define VOLUME_CONTROL                      (0x02)
#define BASS_CONTROL                        (0x03)
#define MID_CONTROL                         (0x04)
#define TREBLE_CONTROL                      (0x05)
#define GRAPHIC_EQUALIZER_CONTROL           (0x06)
#define AGC_CONTROL                         (0x07)
#define DELAY_CONTROL                       (0x08)
#define BASS_BOOST_CONTROL                  (0x09)
#define LOUDNESS_CONTROL                    (0x0A)

//A10.3.1 Up/Down-mix Processing Unit Control Selectors
#define UD_CONTROL_UNDEFINED                (0x00)
#define UD_ENABLE_CONTROL                   (0x01)
#define UD_MODE_SELECT_CONTROL              (0x02)

//A10.3.2 Dolby Prologic Processing Unit Control Selectors
#define DP_CONTROL_UNDEFINED                (0x00)
#define DP_ENABLE_CONTROL                   (0x01)
#define DP_MODE_SELECT_CONTROL              (0x02)

//A10.3.3 3D Stereo Extender Processing Unit Control Selectors
#define THREE_D_CONTROL_UNDEFINED           (0x00)
#define THREE_D_ENABLE_CONTROL              (0x01)
#define SPACIOUSNESS_CONTROL                (0x03)

//A10.3.4 Reverberation Process Unit Control Selectors
#define RV_CONTROL_UNDEFINED                (0x00)
#define RV_ENABLE_CONTROL                   (0x01)
#define REVERB_LEVEL_CONTROL                (0x02)
#define REVERB_TIME_CONTROL                 (0x03)
#define REVERB_FEEDBACK_CONTROL             (0x04)

//A10.3.5 Chorus Process Unit Control Selectors
#define CH_CONTROL_UNDEFINED                (0x00)
#define CH_ENABLE_CONTROL                   (0x01)
#define CHORUS_LEVEL_CONTROL                (0x02)
#define CHORUS_RATE_CONTROL                 (0x03)
#define CHORUS_DEPTH_CONTROL                (0x04)

//A10.3.6 Dynamic Range Comopressor Processing Unit Control Selectors
#define DR_CONTROL_UNDEFINED                (0x00)
#define DR_ENABLE_CONTROL                   (0x01)
#define COMPRESSION_RATE_CONTROL            (0x02)
#define MAXAMPL_CONTROL                     (0x03)
#define THRESHOLD_CONTROL                   (0x04)
#define ATTACK_TIME                         (0x05)
#define RELEASE_TIME                        (0x06)

//A10.4 Extension Unit Control Selectors
#define XU_CONTROL_UNDEFINED                (0x00)
#define XU_ENABLE_CONTROL                   (0x01)

//A10.5 Endpoint Control Selectors
#define EP_CONTROL_UNDEFINED                (0x00)
#define SAMPLING_FREQ_CONTROL               (0x01)
#define PITCH_CONTROL                       (0x02)

//table 2-1 in terminal type spec
// usb streaming: 0x0101
#define TERM_TYPE_USBSTREAMING_LOW     (0x01)
#define TERM_TYPE_USBSTREAMING_HIGH    (0x01)
// microphone: 0x0201
#define TERM_TYPE_MICROPHONE_LOW        (0x01)
#define TERM_TYPE_MICROPHONE_HIGH       (0x02)
// micarray: 0x0205
#define TERM_TYPE_MICARRAY_LOW          (0x05)
#define TERM_TYPE_MICARRAY_HIGH         (0x02)
// speaker: 0x0301
#define TERM_TYPE_SPEAKER_LOW           (0x01)
#define TERM_TYPE_SPEAKER_HIGH          (0x03)
// digital output (spdif): 0x0602,
// peng, 010, 20081110, change from 0605 to 0602
#define TERM_TYPE_SPDIF_LOW             (0x02)
#define TERM_TYPE_SPDIF_HIGH            (0x06)

#define FORMAT_PCM_LOW             (0x01)
#define FORMAT_PCM_HIGH            (0x00)

#define FORMAT_TYPE_I              (0x01)

// bitmap for feature unit control
#define FU_CONTROL_UNDEFINED_BITMAP                (0x00)
#define MUTE_CONTROL_BITMAP                        (0x01)
#define VOLUME_CONTROL_BITMAP                      (0x02)
#define BASS_CONTROL_BITMAP                        (0x04)
#define MID_CONTROL_BITMAP                         (0x08)
#define TREBLE_CONTROL_BITMAP                      (0x10)
#define GRAPHIC_EQUALIZER_CONTROL_BITMAP           (0x20)
#define AGC_CONTROL_BITMAP                         (0x40)
#define DELAY_CONTROL_BITMAP                       (0x80)

#define UNITID_INPUTL_USB_OUT              (0x01)
#define UNITID_INPUT_MIC_IN                (0x02)
#define UNITID_OUTPUT_LINE_OUT             (0x03)
#define UNITID_OUTPUT_USB_IN               (0x04)

#define UNITID_DAC                      (0x09)
#define UNITID_ADC                      (0x0A)

/*===========================================================================*/
/* Driver data structures and types.                                         */
/*===========================================================================*/

typedef struct
{
  uint8_t bmute;
  int16_t wvol[2];//left & right channels
} vol_ctrl_t;

typedef struct
{
  uint16_t min;
  uint16_t max;
  uint16_t res;
} vol_range_t;

typedef uint32_t (*audio_stream_ops_t)(uint8_t *data, size_t len);
typedef uint32_t (*audio_control_ops_t)(uint32_t cmd, void *arg);

typedef struct
{
  vol_range_t vol_range[2];//0 for ply, 1 for rec
  /**
   * @brief   Audio control hook
   */
  audio_control_ops_t      audio_ctl;
  /**
   * @brief   Audio stream hook for play
   */
  audio_stream_ops_t       ply_stream;
  /**
   * @brief   Audio stream hook for record
   */
  audio_stream_ops_t       rec_stream;
} USBAudioConfig;

/**
 * @brief   USB audio Driver configuration structure.
 * @details An instance of this structure must be passed to @p usbaudStart()
 *          in order to configure and start the driver operations.
 */
typedef struct {
  /**
   * @brief   USB driver to use.
   */
  USBDriver *usbp;
  const USBAudioConfig *config;

  uint8_t state;
  vol_ctrl_t vol_ctl[2];//0 for ply, 1 for rec

  uint8_t *ply_buf;
  uint8_t *rec_buf;
  uint8_t ply_idx;
  uint8_t rec_idx;
} USBAudioDriver;

#ifdef __cplusplus
extern "C" {
#endif
  void usbaudObjectInit(USBAudioDriver *usbaudp);
  void usbaudStart(USBAudioDriver *usbaudp, USBDriver *usbp,
                   const USBAudioConfig *config,
                   uint8_t *ply_buf, uint8_t *rec_buf);
  void usbaudStop(USBAudioDriver *usbaudp);
  bool usbaudRequestsHook(USBDriver *usbp);
  void usbaudDataTransmitted(USBDriver *usbp, usbep_t ep);
  void usbaudDataReceived(USBDriver *usbp, usbep_t ep);
#ifdef __cplusplus
}
#endif

#endif /* HAL_USE_USB_AUDIO */

#endif /* HAL_USB_AUDIO_H_ */
