/*
 * hal_delay.h
 *
 *  Created on: Jul 7, 2018
 *      Author: china
 */

#ifndef HAL_DELAY_H_
#define HAL_DELAY_H_

#include "osal.h"

void delay_nops(int cnt);
#define delay_us(us)    osalThreadSleepMicroseconds(us)
#define delay_ms(ms)    osalThreadSleepMilliseconds(ms)

#define _delay_us(us)    delay_us(us)
#define _delay_ms(ms)    delay_ms(ms)


#endif /* HAL_DELAY_H_ */
