/*
    ChibiOS - Copyright (C) 2006..2015 Giovanni Di Sirio

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    ledc.h
 * @brief   LEDC Driver macros and structures.
 *
 * @addtogroup LEDC
 * @{
 */

#ifndef _LEDC_H_
#define _LEDC_H_

#if !defined(HAL_USE_LEDC)
#define HAL_USE_LEDC                FALSE
#endif

#if (HAL_USE_LEDC == TRUE) || defined(__DOXYGEN__)

/*===========================================================================*/
/* Driver constants.                                                         */
/*===========================================================================*/

/*===========================================================================*/
/* Driver pre-compile time settings.                                         */
/*===========================================================================*/

/*===========================================================================*/
/* Derived constants and error checks.                                       */
/*===========================================================================*/

/*===========================================================================*/
/* Driver data structures and types.                                         */
/*===========================================================================*/

/**
 * @brief   Driver state machine possible states.
 */
typedef enum {
  LEDC_UNINIT = 0,                   /**< Not initialized.                   */
  LEDC_STOP = 1,                     /**< Stopped.                           */
  LEDC_READY = 2                     /**< Ready.                             */
} ledcstate_t;

#if defined(hscAudiophile)
/* hs_config.h */
#define DISPLAY_LED_SSD_PIN_NUM     7
#define DISPLAY_LED_SEGMENT_NUM     7
#define DISPLAY_LED_DIGIT_NUM       4
#define DISPLAY_LED_ICON_NUM        16
#endif

typedef enum {
#if 0//defined(hscAudiophile)
  LEDC_MODE_NUM    = DISPLAY_LED_ICON_NUM,
  #else
  LEDC_MODE_AUX    = (1<<0),
  LEDC_MODE_USB    = (1<<1),
  LEDC_MODE_SD     = (1<<2),
  LEDC_MODE_DOT2   = (1<<3),
  LEDC_MODE_DOT    = (1<<4),
  LEDC_MODE_PLY    = (1<<5),
  LEDC_MODE_PSE    = (1<<6),
  LEDC_MODE_MHZ    = (1<<7),
  LEDC_MODE_FM     = (1<<8),
  LEDC_MODE_MP3    = (1<<9),

  LEDC_MODE_NUM    = 10,
  #endif
  LEDC_MODE_ALL    = 0xFFFF,
}ledc_mode_t;

typedef enum
{
  LEDC_OFF = 0,
  LEDC_ON  = 1,
}ledc_on_t;

#include "ledc_lld.h"

/*===========================================================================*/
/* Driver macros.                                                            */
/*===========================================================================*/


/*===========================================================================*/
/* External declarations.                                                    */
/*===========================================================================*/

#ifdef __cplusplus
extern "C" {
#endif
  void ledcInit(void);
  void ledcStart(LEDCDriver *ledcp, const LEDCConfig * config);
  void ledcDispDig(LEDCDriver *ledcp, const uint32_t data, uint32_t dig_index);
  void ledcClearDig(LEDCDriver *ledcp, uint32_t dig_index);
  void ledcDispStr(LEDCDriver *ledcp, const char* str);
  void ledcDispInt(LEDCDriver *ledcp, const uint32_t data);
  void ledcDispMode(LEDCDriver *ledcp, ledc_mode_t mode, ledc_on_t on);
  void ledcClear(LEDCDriver *ledcp);
  void ledcStop(LEDCDriver *ledcp);
#ifdef __cplusplus
}
#endif

#endif /* HAL_USE_LEDC == TRUE */

#endif /* _LEDC_H_ */

/** @} */
