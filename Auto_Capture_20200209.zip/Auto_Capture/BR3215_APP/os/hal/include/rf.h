/*
    ChibiOS/RT - Copyright (C) 2006,2007,2008,2009,2010,
                 2011,2012,2013 Giovanni Di Sirio.
                 Copyright (C) 2019 BRMICRO Technologies
                 
    This file is part of ChibiOS/RT.

    ChibiOS/RT is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    ChibiOS/RT is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

                                      ---

    A special exception to the GPL can be applied should you wish to distribute
    a combined work that includes ChibiOS/RT, without being obliged to provide
    the source code for any proprietary components. See the file exception.txt
    for full details of how and when the exception can be applied.
*/
/*
   Concepts and parts of this file have been contributed by Uladzimir Pylinsky
   aka barthess.
 */

/**
 * @file    rf.h
 * @brief   RF Driver macros and structures.
 *
 * @addtogroup RF
 * @{
 */

#ifndef _RF_H_
#define _RF_H_

#if HAL_USE_RF || defined(__DOXYGEN__)

#include "rf_lld.h"

/*===========================================================================*/
/* Driver constants.                                                         */
/*===========================================================================*/

typedef struct Rf24gDriver Rf24gDriver;

/**
 * @brief   Select MAC6200 as RF PHY.
 *
 * @notapi
 */
#define MAC6200_PHY_Enable rf_lld_Select_MAC6200

/**
 * @brief   change MAC6200 RF's SPI CSN to high.
 *
 * @param[in]  NONE
 *
 * @iclass
 */
#define MAC6200_CSN_High rf_lld_CSN_High

/**
 * @brief   change MAC6200 RF's CE to high.
 *
 * @param[in]  NONE
 *
 * @iclass
 */
#define MAC6200_CE_High rf_lld_CE_High

/**
 * @brief   change MAC6200 RF's SPI CSN to low.
 *
 * @param[in]  NONE
 *
 * @iclass
 */
#define MAC6200_CSN_Low rf_lld_CSN_Low

/**
 * @brief   change MAC6200 RF's CE to low.
 *
 * @param[in]  NONE
 *
 * @iclass
 */
#define MAC6200_CE_Low  rf_lld_CE_Low

/**
 * @brief  Configure MAX2829 to RX mode
 *
 * @param[in]  NONE
 *
 * @iclass
 */
#define Config_MAX2829_RX rf_lld_MAX2829_RX

/**
 * @brief  Configure MAX2829 to TX mode
 *
 * @param[in]  NONE
 *
 * @iclass
 */
#define Config_MAX2829_TX  rf_lld_MAX2829_TX

/**
 * @brief   MAC6200 Write register.
 *
 * @param[in] Reg   register which will write to
 * @param[in] Reg_Val   pointer to the value which will be write
 * @param[in] len    the length of value
 *
 * @iclass
 */
#define MAC6200_Write_Reg(Reg, Reg_Val, len) \
   rf_lld_Wr_Reg(Reg, Reg_Val, len)

/**
 * @brief   MAC6200 read register.
 *
 * @param[in] Reg   register which will be read
 * @param[in] Reg_Val   pointer to read buffer
 * @param[in] len    the length of value which will be read
 *
 * @iclass
 */
#define MAC6200_Read_Reg(Reg, Reg_Val, len) \
   rf_lld_Rd_Reg(Reg, Reg_Val, len)

/**
 * @brief   MAC6200 Flush Tx FiFo.
 *
 * @param[in]  NONE
 *
 * @iclass
 */
#define MAC6200_Flush_Tx_Fifo() rf_lld_Flush_Tx_Fifo()


/**
 * @brief   MAC6200 Flush Rx FiFo.
 *
 * @param[in]  NONE
 *
 * @iclass
 */
#define MAC6200_Flush_Rx_Fifo() rf_lld_Flush_Rx_Fifo()


/**
 * @brief   switch MAC6200's bank to Bank0
 *
 * @param[in]  NONE
 *
 * @iclass
 */
#define MAC6200_Bank0_Activate() rf_lld_Bank0_Activate()

/**
 * @brief   switch MAC6200's bank to Bank1
 *
 * @param[in]  NONE
 *
 * @iclass
 */
#define MAC6200_Bank1_Activate() rf_lld_Bank1_Activate()

/**
 * @brief   Read receive payload's length at the dynamic payload length mode
 *
 * @param[in]  NONE
 *
 * @iclass
 */
#define MAC6200_Read_Rx_Payload_Width() rf_lld_Read_Rx_Payload_Width()

/**
 * @brief   Read receive payload's length at the static payload length mode
 *
 * @param[in]  Pipe_num   pipe index. vaild value is 0-5
 *
 * @iclass
 */
#define MAC6200_Read_Rx_Pipe_Static_Payload_Width(Pipe_Num)    \
      rf_lld_Read_Rx_Pipe_Static_Payload_Width(Pipe_Num)

/**
 * @brief   Read received payload.
 *
 * @param[in] pBuf:  received payload, and maximum payload length is 32 Bytes.
 * @param[in] bytes: paylaod length which ready to read, valid length is 1-32 bytes.
 *
 * @iclass
 */
#define MAC6200_Read_Rx_Payload(pBuf, bytes)  rf_lld_Read_Rx_Payload(pBuf, bytes)

/**
 * @brief  Write Tx paylaod use the comand of W_TX_PAYLOAD, 
           it may be need ackpayload after send the payload. 
 *
 * @param[in] pBuf:  ready to send paylaod value
 * @param[in] bytes: ready to seng payload length, and valid value is 1-32 bytes
 *
 * @iclass
 */
#define MAC6200_Write_Tx_Payload(pBuf, bytes)  rf_lld_Write_Tx_Payload(pBuf, bytes)

/**
 * @brief   Write Tx paylaod use the comand of W_TX_PAYLOAD_NOACK, 
            it does not need ackpayload after send the payload.
 *
 * @param[in] pBuf:  ready to send paylaod value
 * @param[in] bytes: ready to seng payload length, and valid value is 1-32 bytes
 *
 * @iclass
 */
#define MAC6200_Write_Tx_Payload_No_Ack(pBuf, bytes) \
     rf_lld_Write_Tx_Payload_No_Ack(pBuf, bytes)

/**
 * @brief   Write Acknowledge payload
 * @param[in] PipeNum : pipe index to write to ACk paylaod
 * @param[in] pBuf:  ready to send paylaod value
 * @param[in] bytes: ready to seng payload length, and valid value is 1-32 bytes
 *
 * @iclass
 */
#define MAC6200_Write_Ack_Payload(PipeNum, pBuf, bytes) \
     rf_lld_Write_Ack_Payload(PipeNum, pBuf, bytes)

/**
 * @brief  set MAC6200 Pipe address 
 * @param[in] Px_Addr_Reg:   pipe  address register
 * @param[in] pPipeAddr:  point of pipe address 
 * @param[in] Addr_Width: length of address
 *
 * @iclass
 */
#define MAC6200_Write_Pipe_Addr(Px_Addr_Reg, pPipeAddr, Addr_Width) \
     rf_lld_Write_Pipe_Addr(Px_Addr_Reg, pPipeAddr, Addr_Width)

/**
 * @brief  set MAC6200 Pipe address 
* @param[in]  RFConfig:  configure of  RF 
 *
 * @iclass
 */
#define MAC6200_Init(RFConfig) rf_lld_Init(RFConfig)


#define RF24G_BUFFERS_SIZE     256//512//256

/**
 * @name    Serial status flags
 * @{
 */
#define RF24G_PARITY_ERROR         (eventflags_t)32    /**< @brief Parity.     */
#define RF24G_FRAMING_ERROR        (eventflags_t)64    /**< @brief Framing.    */
#define RF24G_OVERRUN_ERROR        (eventflags_t)128   /**< @brief Overflow.   */
#define RF24G_NOISE_ERROR          (eventflags_t)256   /**< @brief Line noise. */
#define RF24G_BREAK_DETECTED       (eventflags_t)512   /**< @brief LIN Break.  */

/**
 * @brief   @p Rf24gDriver specific methods.
 */
#define _rf24g_driver_methods                                              \
  _base_asynchronous_channel_methods

/**
 * @extends BaseAsynchronousChannelVMT
 *
 * @brief   @p Rf24gDriver virtual methods table.
 */
struct Rf24gDriverVMT {
  _rf24g_driver_methods
};


/*===========================================================================*/
/* Driver macros.                                                            */
/*===========================================================================*/

/**
 * @name    Macro Functions
 * @{
 */
/**
 * @brief   Direct output check on a @p Rf24gDriver.
 * @note    This function bypasses the indirect access to the channel and
 *          checks directly the output queue. This is faster but cannot
 *          be used to check different channels implementations.
 *
 * @deprecated
 *
 * @api
 */
#define rf24gPutWouldBlock(rf24gp) oqIsFullI(&(rf24gp)->oqueue)

/**
 * @brief   Direct input check on a @p Rf24gDriver.
 * @note    This function bypasses the indirect access to the channel and
 *          checks directly the input queue. This is faster but cannot
 *          be used to check different channels implementations.
 *
 * @deprecated
 *
 * @api
 */
#define rf24gGetWouldBlock(rf24gp) iqIsEmptyI(&(rf24gp)->iqueue)

/**
 * @brief   Direct write to a @p Rf24gDriver.
 * @note    This function bypasses the indirect access to the channel and
 *          writes directly on the output queue. This is faster but cannot
 *          be used to write to different channels implementations.
 *
 * @see     chnPutTimeout()
 *
 * @api
 */
#define rf24gPut(rf24gp, b) oqPut(&(rf24gp)->oqueue, b)

/**
 * @brief   Direct write to a @p Rf24gDriver with timeout specification.
 * @note    This function bypasses the indirect access to the channel and
 *          writes directly on the output queue. This is faster but cannot
 *          be used to write to different channels implementations.
 *
 * @see     chnPutTimeout()
 *
 * @api
 */
#define rf24gPutTimeout(rf24gp, b, t) oqPutTimeout(&(rf24gp)->oqueue, b, t)

/**
 * @brief   Direct read from a @p Rf24gDriver.
 * @note    This function bypasses the indirect access to the channel and
 *          reads directly from the input queue. This is faster but cannot
 *          be used to read from different channels implementations.
 *
 * @see     chnGetTimeout()
 *
 * @api
 */
#define rf24gGet(rf24gp) iqGet(&(rf24gp)->iqueue)

/**
 * @brief   Direct read from a @p Rf24gDriver with timeout specification.
 * @note    This function bypasses the indirect access to the channel and
 *          reads directly from the input queue. This is faster but cannot
 *          be used to read from different channels implementations.
 *
 * @see     chnGetTimeout()
 *
 * @api
 */
#define rf24gGetTimeout(rf24gp, t) iqGetTimeout(&(rf24gp)->iqueue, t)

/**
 * @brief   Direct blocking write to a @p Rf24gDriver.
 * @note    This function bypasses the indirect access to the channel and
 *          writes directly to the output queue. This is faster but cannot
 *          be used to write from different channels implementations.
 *
 * @see     chnWrite()
 *
 * @api
 */
#define rf24gWrite(rf24gp, b, n)                                                  \
  oqWriteTimeout(&(rf24gp)->oqueue, b, n, TIME_INFINITE)

/**
 * @brief   Direct blocking write to a @p Rf24gDriver with timeout
 *          specification.
 * @note    This function bypasses the indirect access to the channel and
 *          writes directly to the output queue. This is faster but cannot
 *          be used to write to different channels implementations.
 *
 * @see     chnWriteTimeout()
 *
 * @api
 */
#define rf24gWriteTimeout(rf24gp, b, n, t)                                        \
  oqWriteTimeout(&(rf24gp)->oqueue, b, n, t)

/**
 * @brief   Direct non-blocking write to a @p Rf24gDriver.
 * @note    This function bypasses the indirect access to the channel and
 *          writes directly to the output queue. This is faster but cannot
 *          be used to write to different channels implementations.
 *
 * @see     chnWriteTimeout()
 *
 * @api
 */
#define rf24gAsynchronousWrite(rf24gp, b, n)                                      \
  oqWriteTimeout(&(rf24gp)->oqueue, b, n, TIME_IMMEDIATE)

/**
 * @brief   Direct blocking read from a @p Rf24gDriver.
 * @note    This function bypasses the indirect access to the channel and
 *          reads directly from the input queue. This is faster but cannot
 *          be used to read from different channels implementations.
 *
 * @see     chnRead()
 *
 * @api
 */
#define rf24gRead(rf24gp, b, n)                                                   \
  iqReadTimeout(&(rf24gp)->iqueue, b, n, TIME_INFINITE)

/**
 * @brief   Direct blocking read from a @p Rf24gDriver with timeout
 *          specification.
 * @note    This function bypasses the indirect access to the channel and
 *          reads directly from the input queue. This is faster but cannot
 *          be used to read from different channels implementations.
 *
 * @see     chnReadTimeout()
 *
 * @api
 */
#define rf24gReadTimeout(rf24gp, b, n, t)                                         \
  iqReadTimeout(&(rf24gp)->iqueue, b, n, t)

/**
 * @brief   Direct non-blocking read from a @p Rf24gDriver.
 * @note    This function bypasses the indirect access to the channel and
 *          reads directly from the input queue. This is faster but cannot
 *          be used to read from different channels implementations.
 *
 * @see     chnReadTimeout()
 *
 * @api
 */
#define rf24gAsynchronousRead(rf24gp, b, n)                                       \
  iqReadTimeout(&(rf24gp)->iqueue, b, n, TIME_IMMEDIATE)
/** @} */

/*===========================================================================*/
/* External declarations.                                                    */
/*===========================================================================*/

#ifdef __cplusplus
extern "C" {
#endif
  extern  Rf24gDriver RF24GD;
  void rf24gInit(void);
  void rf24gObjectInit(Rf24gDriver *rf24gp, qnotify_t inotify, qnotify_t onotify);
  void rf24gStart(Rf24gDriver *rf24gp, RFConfig *config);
  void rf24gStop(Rf24gDriver *rf24gp);
  void rf24gIncomingDataI(Rf24gDriver *rf24gp, uint8_t b);
  msg_t rf24gRequestDataI(Rf24gDriver *rf24gp);
  void rf24gStartReceiveI(void);
void MAC6200_dump_RF_register(BaseSequentialStream *chp);

#ifdef __cplusplus
}
#endif

#endif  /* HAL_USE_RF */
#endif  /* _RF_H_ */


