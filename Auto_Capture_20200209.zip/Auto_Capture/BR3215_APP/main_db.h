#ifndef _MAIN_DB_H_
#define _MAIN_DB_H_

#define FLASH_CHECKSUM_SIGN		0x20191228	//$LICENSING
#define FW_VERSION				0x20191228

#define FP_MAX_USERS			20

#define FW_MAX_SIZE				0x45050					//272K
#define APPDATA_MAP0			(0x00000000 + FW_MAX_SIZE)

typedef struct
{
	DWORD dwCheckSum;
	int nPrevLockOpened;
} DBLICENSE;

#define dbLicenseR				(*(DBLICENSE*) APPDATA_MAP0)

#define FP_FLASH_INDEX			(APPDATA_MAP0 + 1024)
#define gFpIndex				((char*)FP_FLASH_INDEX)

void DbLicenseWrite(DBLICENSE* pModuleInfo);
void DbLicenseRead(void);
void DbLicenseSetPrevLockOpened(int v);

//////////////////////////////////////////////////////////////////////////
void sb_add(int pos);
void sb_delete(int pos);
void sb_delete_all(void);
int sb_enroll_count(void);
int sb_next_enroll_pos(void);
BOOL sb_check_pos(int pos);

#endif /* _MAIN_DB_H_ */
