/*
    ChibiOS - Copyright (C) 2006..2016 Giovanni Di Sirio

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

#include <string.h>
#include "hal.h"
#include "usbd.h"

#if ((HAL_USE_USB == TRUE) && (HAL_USE_USB_MSD == TRUE) && (HAL_USE_USB_HID == TRUE)) || defined(__DOXYGEN__)

/*
 * USB Composite Device with muti-interface.
 */
#define IF_NUM_MSD                      0x00
#define IF_NUM_ACI                      0x01
#define IF_NUM_ASI_OUT                  0x02
#define IF_NUM_ASI_IN                   0x03
#define IF_NUM_HID                      0x04
#define IF_NUM_MAX                      5

static uint8_t m_combo_inf_altset[IF_NUM_MAX];

/*
 * USB Device Descriptor.
 */
static const uint8_t combo_device_descriptor_data[18] = {
  USB_DESC_DEVICE       (0x0200,        /* bcdUSB (2.0).                    */
                         0x00,          /* bDeviceClass (composite).        */
                         0x00,          /* bDeviceSubClass.                 */
                         0x00,          /* bDeviceProtocol.                 */
                         0x40,          /* bMaxPacketSize.                  */
                         USB_VID_HS,    /* idVendor.                        */
                         USB_PID_HS_COMBO,/* idProduct.                     */
                         0x0200,        /* bcdDevice.                       */
                         1,             /* iManufacturer.                   */
                         2,             /* iProduct.                        */
                         3,             /* iSerialNumber.                   */
                         1)             /* bNumConfigurations.              */
};

/*
 * Device Descriptor wrapper.
 */
static const USBDescriptor combo_device_descriptor = {
  sizeof combo_device_descriptor_data,
  combo_device_descriptor_data
};

/*
 * HID Report Descriptor
 *
 * This is the description of the format and the content of the
 * different IN or/and OUT reports that your application can
 * receive/send
 *
 * See "Device Class Definition for Human Interface Devices (HID)"
 * (http://www.usb.org/developers/hidpage/HID1_11.pdf) for the
 * detailed description of all the fields
 */
static const uint8_t hid_report_descriptor_data[] = {
  HID_USAGE_PAGE_B(HID_USAGE_PAGE_CONSUMER),
  HID_USAGE_B(HID_USAGE_CONSUMER_CONTROL),
  HID_COLLECTION_B(HID_COLLECTION_APPLICATION),
    HID_LOGICAL_MINIMUM_B(0),
    HID_LOGICAL_MAXIMUM_B(1),
    HID_REPORT_SIZE_B(1),
    HID_REPORT_COUNT_B(8),
    HID_USAGE_B(0xE9),  //Volume up at bit0
    HID_USAGE_B(0xEA),  //Volume Down
    HID_USAGE_B(0xCD),  //Play/Pause
    HID_USAGE_B(0xB5),  //Scan Next Track
    HID_USAGE_B(0xB6),  //Scan Previous Track
    HID_USAGE_B(0xB3),  //Fast Forward
    HID_USAGE_B(0xB4),  //Rewind
    HID_USAGE_W(0x0150),//Balance Right
    HID_INPUT_B(0x42),
  HID_END_COLLECTION,
};

/* Configuration Descriptor tree for an usb composite device.*/
static const uint8_t combo_configuration_descriptor_data[9+ /*msd*/9+7+7+ /*auctl*/9+10+12+10+9+12+9+9+ /*auout*/9+ 9+7+11+9+7+ /*auin*/9+ 9+7+11+9+7+ /*hid*/9+9+7] = {
    /* Configuration Descriptor.*/
    USB_DESC_CONFIGURATION(0x00F1,        /* wTotalLength.                    */
                           IF_NUM_MAX,    /* bNumInterfaces.                  */
                           0x01,          /* bConfigurationValue.             */
                           0,             /* iConfiguration.                  */
                           0xC0,          /* bmAttributes (self powered).     */
                           0x32),         /* bMaxPower (100mA).               */
    /* Interface Descriptor.*/
    USB_DESC_INTERFACE    (IF_NUM_MSD,    /* bInterfaceNumber.                */
                           0x00,          /* bAlternateSetting.               */
                           0x02,          /* bNumEndpoints.                   */
                           0x08,          /* bInterfaceClass (Mass Storage)   */
                           0x06,          /* bInterfaceSubClass (SCSI
                                             Transparent storage class)       */
                           0x50,          /* bInterfaceProtocol (Bulk Only)   */
                           0),            /* iInterface. (none)               */
    /* Mass Storage Data In Endpoint Descriptor.*/
    USB_DESC_ENDPOINT     (EP_NUM_MSD_IN|0x80, /* bEndpointAddress.                */
                           0x02,          /* bmAttributes (Bulk).             */
                           EP_SIZ_MSD,    /* wMaxPacketSize.                  */
                           0x00),         /* bInterval.                       */
    /* Mass Storage Data Out Endpoint Descriptor.*/
    USB_DESC_ENDPOINT     (EP_NUM_MSD_OUT,/* bEndpointAddress.                */
                           0x02,          /* bmAttributes (Bulk).             */
                           EP_SIZ_MSD,    /* wMaxPacketSize.                  */
                           0x00),         /* bInterval.                       */
    /* Interface Descriptor.*/
    USB_DESC_INTERFACE    (IF_NUM_ACI,    /* bInterfaceNumber.                */
                           0x00,          /* bAlternateSetting.               */
                           0x00,          /* bNumEndpoints.                   */
                           0x01,          /* bInterfaceClass (Audio)          */
                           0x01,          /* bInterfaceSubClass (Audio
                                             Control)                         */
                           0x00,          /* bInterfaceProtocol               */
                           0),            /* iInterface. (none)               */
    /* Audio Control Interface Header Descriptor.*/
    USB_DESC_BYTE         (10),           /* bLength.                         */
    USB_DESC_BYTE         (0x24),         /* bDescriptorType (AU_INTERFACE).  */
    USB_DESC_BYTE         (0x01),         /* bDescriptorSubtype (Header)      */
    USB_DESC_BCD          (0x0100),       /* bcdADC.                          */
    USB_DESC_WORD         (0x0047),       /* wTotalLength                     */
    USB_DESC_BYTE         (0x02),         /* bInCollection                    */
    USB_DESC_BYTE         (0x02),         /* baInterfaceNr[1]                 */
    USB_DESC_BYTE         (0x03),         /* baInterfaceNr[2]                 */
    /* Audio Control Input Terminal Descriptor.*/
    USB_DESC_BYTE         (12),           /* bLength.                         */
    USB_DESC_BYTE         (0x24),         /* bDescriptorType (AU_INTERFACE).  */
    USB_DESC_BYTE         (0x02),         /* bDescriptorSubtype (I Terminal)  */
    USB_DESC_BYTE         (0x01),         /* bTerminalID                      */
    USB_DESC_WORD         (0x0101),       /* wTerminalType (USB streaming)    */
    USB_DESC_BYTE         (0x00),         /* bAssocTerminal                   */
    USB_DESC_BYTE         (0x02),         /* bNrChannels                      */
    USB_DESC_WORD         (0x0003),       /* wChannelConfig                   */
    USB_DESC_BYTE         (0x00),         /* iChannelNames                    */
    USB_DESC_BYTE         (0x00),         /* iTerminal                        */
    /* Audio Control Feature Unit Descriptor.*/
    USB_DESC_BYTE         (10),           /* bLength.                         */
    USB_DESC_BYTE         (0x24),         /* bDescriptorType (AU_INTERFACE).  */
    USB_DESC_BYTE         (0x06),         /* bDescriptorSubtype (Feature Unit)*/
    USB_DESC_BYTE         (UNITID_DAC),   /* bUnitID                          */
    USB_DESC_BYTE         (0x01),         /* bSourceID                        */
    USB_DESC_BYTE         (0x01),         /* bControlSize (1 byte per control)*/
    USB_DESC_BYTE         (0x01),         /* bmaControls[0] (Mute)            */
    USB_DESC_BYTE         (0x02),         /* bmaControls[1] (Volume)          */
    USB_DESC_BYTE         (0x02),         /* bmaControls[2] (Volume)          */
    USB_DESC_BYTE         (0x00),         /* iFeature                         */
    /* Audio Control Output Terminal Descriptor.*/
    USB_DESC_BYTE         (9),            /* bLength.                         */
    USB_DESC_BYTE         (0x24),         /* bDescriptorType (AU_INTERFACE).  */
    USB_DESC_BYTE         (0x03),         /* bDescriptorSubtype (O Terminal)  */
    USB_DESC_BYTE         (0x03),         /* bTerminalID                      */
    USB_DESC_WORD         (0x0301),       /* wTerminalType (Speaker)          */
    USB_DESC_BYTE         (0x00),         /* bAssocTerminal                   */
    USB_DESC_BYTE         (0x09),         /* bSourceID                        */
    USB_DESC_BYTE         (0x00),         /* iTerminal                        */
    /* Audio Control Input Terminal Descriptor.*/
    USB_DESC_BYTE         (12),           /* bLength.                         */
    USB_DESC_BYTE         (0x24),         /* bDescriptorType (AU_INTERFACE).  */
    USB_DESC_BYTE         (0x02),         /* bDescriptorSubtype (I Terminal)  */
    USB_DESC_BYTE         (0x02),         /* bTerminalID                      */
    USB_DESC_WORD         (0x0201),       /* wTerminalType (Microphone)       */
    USB_DESC_BYTE         (0x00),         /* bAssocTerminal                   */
    USB_DESC_BYTE         (0x01),         /* bNrChannels                      */
    USB_DESC_WORD         (0x0001),       /* wChannelConfig                   */
    USB_DESC_BYTE         (0x00),         /* iChannelNames                    */
    USB_DESC_BYTE         (0x00),         /* iTerminal                        */
    /* Audio Control Feature Unit Descriptor.*/
    USB_DESC_BYTE         (9),            /* bLength.                         */
    USB_DESC_BYTE         (0x24),         /* bDescriptorType (AU_INTERFACE).  */
    USB_DESC_BYTE         (0x06),         /* bDescriptorSubtype (Feature Unit)*/
    USB_DESC_BYTE         (UNITID_ADC),   /* bUnitID                          */
    USB_DESC_BYTE         (0x02),         /* bSourceID                        */
    USB_DESC_BYTE         (0x01),         /* bControlSize (1 byte per control)*/
    USB_DESC_BYTE         (0x03),         /* bmaControls[0] (Volume,Mute)     */
    USB_DESC_BYTE         (0x00),         /* bmaControls[1]                   */
    USB_DESC_BYTE         (0x00),         /* iFeature                         */
    /* Audio Control Output Terminal Descriptor.*/
    USB_DESC_BYTE         (9),            /* bLength.                         */
    USB_DESC_BYTE         (0x24),         /* bDescriptorType (AU_INTERFACE).  */
    USB_DESC_BYTE         (0x03),         /* bDescriptorSubtype (O Terminal)  */
    USB_DESC_BYTE         (0x04),         /* bTerminalID                      */
    USB_DESC_WORD         (0x0101),       /* wTerminalType (USB streaming)    */
    USB_DESC_BYTE         (0x00),         /* bAssocTerminal                   */
    USB_DESC_BYTE         (0x0A),         /* bSourceID                        */
    USB_DESC_BYTE         (0x00),         /* iTerminal                        */
    /* Interface Descriptor.*/
    USB_DESC_INTERFACE    (IF_NUM_ASI_OUT,/* bInterfaceNumber.                */
                           0x00,          /* bAlternateSetting.               */
                           0x00,          /* bNumEndpoints.                   */
                           0x01,          /* bInterfaceClass (Audio)          */
                           0x02,          /* bInterfaceSubClass (Audio
                                             Streaming)                       */
                           0x00,          /* bInterfaceProtocol               */
                           0),            /* iInterface. (none)               */
    /* Interface Descriptor.*/
    USB_DESC_INTERFACE    (IF_NUM_ASI_OUT,/* bInterfaceNumber.                */
                           0x01,          /* bAlternateSetting.               */
                           0x01,          /* bNumEndpoints.                   */
                           0x01,          /* bInterfaceClass (Audio)          */
                           0x02,          /* bInterfaceSubClass (Audio
                                             Streaming)                       */
                           0x00,          /* bInterfaceProtocol               */
                           0),            /* iInterface. (none)               */
    /* Audio Streaming Interface Descriptor.*/
    USB_DESC_BYTE         (7),            /* bLength.                         */
    USB_DESC_BYTE         (0x24),         /* bDescriptorType (AU_INTERFACE).  */
    USB_DESC_BYTE         (0x01),         /* bDescriptorSubtype               */
    USB_DESC_BYTE         (0x01),         /* bTerminalLink                    */
    USB_DESC_BYTE         (0x01),         /* bDelay                           */
    USB_DESC_WORD         (0x0001),       /* wFormatTag (PCM)                 */
    /* Audio Streaming Format Type Descriptor.*/
    USB_DESC_BYTE         (11),           /* bLength.                         */
    USB_DESC_BYTE         (0x24),         /* bDescriptorType (AU_INTERFACE).  */
    USB_DESC_BYTE         (0x02),         /* bDescriptorSubtype (Format Type) */
    USB_DESC_BYTE         (0x01),         /* bFormatType                      */
    USB_DESC_BYTE         (0x02),         /* bNrChannels (2 channels)         */
    USB_DESC_BYTE         (0x02),         /* bSubframeSize (2B per subframe)  */
    USB_DESC_BYTE         (0x10),         /* bBitResolution (16b per sample)  */
    USB_DESC_BYTE         (0x01),         /* bSamFreqType (1 sample frequence)*/
    USB_DESC_BYTE         (0x80),         /* tSamFreq[1] (48000 Hz)           */
    USB_DESC_BYTE         (0xBB),
    USB_DESC_BYTE         (0x00),
    /* Audio Out Endpoint Descriptor.*/
    USB_DESC_BYTE         (9),            /* bLength.                         */
    USB_DESC_BYTE         (0x05),         /* bDescriptorType (Endpoint).      */
    USB_DESC_BYTE        (EP_NUM_ASI_OUT),/* bEndpointAddress.                */
    USB_DESC_BYTE         (0x09),         /* bmAttributes (Iso Adptive Data). */
    USB_DESC_WORD        (EP_SIZ_ASI_OUT),/* wMaxPacketSize.                  */
    USB_DESC_BYTE         (0x01),         /* bInterval. 1ms                   */
    USB_DESC_BYTE         (0x00),         /* bRefresh                         */
    USB_DESC_BYTE         (0x00),         /* bSynchAddress                    */
    /* Audio Data Endpoint Descriptor.*/
    USB_DESC_BYTE         (7),            /* bLength.                         */
    USB_DESC_BYTE         (0x25),         /* bDescriptorType (AU_ENDPOINT).   */
    USB_DESC_BYTE         (0x01),         /* bDescriptorSubtype (General)     */
    USB_DESC_BYTE         (0x00),         /* bmAttributes                     */
    USB_DESC_BYTE         (0x00),         /* bLockDelayUnits                  */
    USB_DESC_WORD         (0x0000),       /* wLockDelay                       */
    /* Interface Descriptor.*/
    USB_DESC_INTERFACE    (IF_NUM_ASI_IN, /* bInterfaceNumber.                */
                           0x00,          /* bAlternateSetting.               */
                           0x00,          /* bNumEndpoints.                   */
                           0x01,          /* bInterfaceClass (Audio)          */
                           0x02,          /* bInterfaceSubClass (Audio
                                             Streaming)                       */
                           0x00,          /* bInterfaceProtocol               */
                           0),            /* iInterface. (none)               */
    /* Interface Descriptor.*/
    USB_DESC_INTERFACE    (IF_NUM_ASI_IN, /* bInterfaceNumber.                */
                           0x01,          /* bAlternateSetting.               */
                           0x01,          /* bNumEndpoints.                   */
                           0x01,          /* bInterfaceClass (Audio)          */
                           0x02,          /* bInterfaceSubClass (Audio
                                             Streaming)                       */
                           0x00,          /* bInterfaceProtocol               */
                           0),            /* iInterface. (none)               */
    /* Audio Streaming Interface Descriptor.*/
    USB_DESC_BYTE         (7),            /* bLength.                         */
    USB_DESC_BYTE         (0x24),         /* bDescriptorType (AU_INTERFACE).  */
    USB_DESC_BYTE         (0x01),         /* bDescriptorSubtype               */
    USB_DESC_BYTE         (0x04),         /* bTerminalLink                    */
    USB_DESC_BYTE         (0x01),         /* bDelay                           */
    USB_DESC_WORD         (0x0001),       /* wFormatTag (PCM)                 */
    /* Audio Streaming Format Type Descriptor.*/
    USB_DESC_BYTE         (11),           /* bLength.                         */
    USB_DESC_BYTE         (0x24),         /* bDescriptorType (AU_INTERFACE).  */
    USB_DESC_BYTE         (0x02),         /* bDescriptorSubtype (Format Type) */
    USB_DESC_BYTE         (0x01),         /* bFormatType                      */
    USB_DESC_BYTE         (0x02),         /* bNrChannels (2 channels)         */
    USB_DESC_BYTE         (0x02),         /* bSubframeSize (2B per subframe)  */
    USB_DESC_BYTE         (0x10),         /* bBitResolution (16b per sample)  */
    USB_DESC_BYTE         (0x01),         /* bSamFreqType (1 sample frequence)*/
    USB_DESC_BYTE         (0x80),         /* tSamFreq[1] (16000 Hz)           */
    USB_DESC_BYTE         (0x3E),
    USB_DESC_BYTE         (0x00),
    /* Audio In Endpoint Descriptor.*/
    USB_DESC_BYTE         (9),            /* bLength.                         */
    USB_DESC_BYTE         (0x05),         /* bDescriptorType (Endpoint).      */
    USB_DESC_BYTE         (EP_NUM_ASI_IN|0x80),/* bEndpointAddress.                */
    USB_DESC_BYTE         (0x09),         /* bmAttributes (Iso Adptive Data). */
    USB_DESC_WORD         (EP_SIZ_ASI_IN),/* wMaxPacketSize.                  */
    USB_DESC_BYTE         (0x01),         /* bInterval. 1ms                   */
    USB_DESC_BYTE         (0x00),         /* bRefresh                         */
    USB_DESC_BYTE         (0x00),         /* bSynchAddress                    */
    /* Audio Data Endpoint Descriptor.*/
    USB_DESC_BYTE         (7),            /* bLength.                         */
    USB_DESC_BYTE         (0x25),         /* bDescriptorType (AU_ENDPOINT).   */
    USB_DESC_BYTE         (0x01),         /* bDescriptorSubtype (General)     */
    USB_DESC_BYTE         (0x00),         /* bmAttributes                     */
    USB_DESC_BYTE         (0x00),         /* bLockDelayUnits                  */
    USB_DESC_WORD         (0x0000),       /* wLockDelay                       */
    /* Interface Descriptor.*/
    USB_DESC_INTERFACE    (IF_NUM_HID,    /* bInterfaceNumber.                */
                           0x00,          /* bAlternateSetting.               */
                           0x01,          /* bNumEndpoints.                   */
                           0x03,          /* bInterfaceClass (HID)            */
                           0x00,          /* bInterfaceSubClass               */
                           0x00,          /* bInterfaceProtocol               */
                           0),            /* iInterface. (none)               */
    /* HID Descriptor.*/
    USB_DESC_HID          (0x0201,        /* bcdHID. (HID version 2.01)       */
                           0x00,          /* bCountryCode.                    */
                           0x01,          /* bNumDescriptors.                 */
                           0x22,          /* bDescriptorType (Report
                                             Descriptor).                     */
                           sizeof(hid_report_descriptor_data)),           /* wDescriptorLength.               */
    /* HID In Endpoint Descriptor.*/
    USB_DESC_ENDPOINT     (EP_NUM_HID_IN|0x80, /* bEndpointAddress.                */
                           0x03,          /* bmAttributes (Interrupt).        */
                           EP_SIZ_HID_IN, /* wMaxPacketSize.                  */
                           0x01)          /* bInterval (1ms).                 */
};

/*
 * Configuration Descriptor wrapper.
 */
static const USBDescriptor combo_configuration_descriptor = {
  sizeof combo_configuration_descriptor_data,
  combo_configuration_descriptor_data
};

/*
 * HID Descriptor wrapper.
 */
static const USBDescriptor hid_descriptor = {
  USB_DESC_HID_SIZE,
  &combo_configuration_descriptor_data[sizeof(combo_configuration_descriptor_data) - (9+7)]
};

/*
 * HID Report Descriptor wrapper
 */
static const USBDescriptor hid_report_descriptor = {
  sizeof hid_report_descriptor_data,
  hid_report_descriptor_data
};

/*
 * U.S. English language identifier.
 */
static const uint8_t combo_string0[] = {
  USB_DESC_BYTE(4),                     /* bLength.                         */
  USB_DESC_BYTE(USB_DESCRIPTOR_STRING), /* bDescriptorType.                 */
  USB_DESC_WORD(0x0409)                 /* wLANGID (U.S. English).          */
};

/*
 * Vendor string.
 */
static const uint8_t combo_string1[] = {
  USB_DESC_BYTE(2+9*2),                 /* bLength.                         */
  USB_DESC_BYTE(USB_DESCRIPTOR_STRING), /* bDescriptorType.                 */
  'H', 0, 'u', 0, 'n', 0, 't', 0, 'e', 0, 'r', 0, 'S', 0, 'u', 0,
  'n', 0
};

/*
 * Device Description string.
 */
static const uint8_t combo_string2[] = {
  USB_DESC_BYTE(2+17*2),                 /* bLength.                         */
  USB_DESC_BYTE(USB_DESCRIPTOR_STRING), /* bDescriptorType.                 */
  'H', 0, 'S', 0, '6', 0, '6', 0, 'x', 0, 'x', 0, ' ', 0,
  'U', 0, 'S', 0, 'B', 0, ' ', 0,
  'A', 0, 'u', 0, 'd', 0, 'i', 0, 'o', 0, ' ', 0,
};

/*
 * Serial Number string.
 */
static const uint8_t combo_string3[] = {
  USB_DESC_BYTE(2+3*2),                   /* bLength.                       */
  USB_DESC_BYTE(USB_DESCRIPTOR_STRING),   /* bDescriptorType.               */
  '0' + CH_KERNEL_MAJOR, 0,
  '0' + CH_KERNEL_MINOR, 0,
  '0' + CH_KERNEL_PATCH, 0
};

/*
 * Strings wrappers array.
 */
static const USBDescriptor combo_strings[] = {
  {sizeof combo_string0, combo_string0},
  {sizeof combo_string1, combo_string1},
  {sizeof combo_string2, combo_string2},
  {sizeof combo_string3, combo_string3},
};

static uint16_t get_hword(uint8_t *p) {
  uint16_t hw;

  hw  = (uint16_t)*p++;
  hw |= (uint16_t)*p << 8U;
  return hw;
}

/*
 * Handles the GET_DESCRIPTOR callback. All required descriptors must be
 * handled here.
 */
static const USBDescriptor *get_descriptor(USBDriver *usbp,
                                           uint8_t dtype,
                                           uint8_t dindex,
                                           uint16_t lang) {

  (void)usbp;
  (void)lang;
  switch (dtype) {
  case USB_DESCRIPTOR_DEVICE:
    return &combo_device_descriptor;
  case USB_DESCRIPTOR_CONFIGURATION:
    return &combo_configuration_descriptor;
  case USB_DESCRIPTOR_STRING:
    if (dindex < 4)
      return &combo_strings[dindex];
    break;
  case USB_DESCRIPTOR_HID:
    return &hid_descriptor;
  case HID_REPORT:
    return &hid_report_descriptor;
  default:
    break;
  }
  return NULL;
}

static bool combo_request_hook(USBDriver *usbp) {
  /* USB Composite Device with multi-interface as a class device */
  if (((usbp->setup[0] & USB_RTYPE_TYPE_MASK) == USB_RTYPE_TYPE_STD) &&
      ((usbp->setup[0] & USB_RTYPE_RECIPIENT_MASK) == USB_RTYPE_RECIPIENT_INTERFACE)) {
    /* act depending on bRequest = setup[1] */
    switch(usbp->setup[1]) {
    case USB_REQ_GET_INTERFACE:
      usbSetupTransfer(usbp, &m_combo_inf_altset[usbp->setup[4]], 1, NULL);
      return true;
    case USB_REQ_SET_INTERFACE:
      /* bmRequestType + bRequest + wValue=AlternateSettings + wIndex=Interface */
      m_combo_inf_altset[usbp->setup[4]] = usbp->setup[2];
      if ((IF_NUM_ASI_OUT == usbp->setup[4]) ||
          (IF_NUM_ASI_IN  == usbp->setup[4])) {
        /* stop/start audio stream in the specific format (altset) */
        uint8_t altset = usbp->setup[2];
        if (altset > 1/*max bAlternateSetting*/) return false;
        usbaudRequestsHook(usbp);
        /* fall through */
      }
      usbSetupTransfer(usbp, NULL, 0, NULL);
      return true;
    default:
      break;
    }
  }

  /* GET_DESCRIPTOR from interface not handled by default so handle it here */
  if (((usbp->setup[0] & USB_RTYPE_DIR_MASK) == USB_RTYPE_DIR_DEV2HOST) &&
      ((usbp->setup[0] & USB_RTYPE_RECIPIENT_MASK) == USB_RTYPE_RECIPIENT_INTERFACE)) {
    const USBDescriptor *dp;
    switch (usbp->setup[1]) {
    case USB_REQ_GET_DESCRIPTOR:
      dp = usbp->config->get_descriptor_cb(usbp, usbp->setup[3], usbp->setup[2],
                                           get_hword(&usbp->setup[4]));
      if (dp == NULL)
        return false;

      usbSetupTransfer(usbp, (uint8_t *)dp->ud_string, dp->ud_size, NULL);
      return true;
    }
  }

  if ((usbp->setup[0] & USB_RTYPE_TYPE_MASK) == USB_RTYPE_TYPE_CLASS) {
    bool ret = msd_request_hook(usbp);
    if (ret == false) {
      ret = usbaudRequestsHook(usbp);
      if (ret == false) {
        /* a dummy usb hid driver to save code size */
        //ret = hidRequestsHook(usbp);
      }
    }
    return ret;
  }

  /* usb.c:default_handler() */
  return false;
}

/**
 * @brief   IN EP1 state.
 */
static USBInEndpointState ep1instate;

/**
 * @brief   OUT EP1 state.
 */
static USBOutEndpointState ep1outstate;

/**
 * @brief   EP1 initialization structure (both IN and OUT).
 */
static const USBEndpointConfig ep1config = {
  USB_EP_MODE_TYPE_BULK,
  USB_EP_MODE_TYPE_BULK,
  NULL,
  NULL,
  NULL,
  EP_SIZ_MSD,
  EP_SIZ_MSD,
  &ep1instate,
  &ep1outstate,
  0, //dma channel for in,  dma mode 1
  1, //dma channel for out, dma mode 0
  0, //1:double-packet buffering
};

/**
 * @brief   IN EP2 state.
 */
static USBInEndpointState ep2instate;

/**
 * @brief   OUT EP2 state.
 */
static USBOutEndpointState ep2outstate;

/**
 * @brief   EP2 initialization structure (both IN and OUT).
 */
static const USBEndpointConfig ep2config = {
  USB_EP_MODE_TYPE_INTR, /* INTR for in; ISOC for out */
  USB_EP_MODE_TYPE_ISOC,
  NULL,
  NULL,//hidDataTransmitted,
  usbaudDataReceived,
  EP_SIZ_HID_IN,
  EP_SIZ_ASI_OUT,
  &ep2instate,
  &ep2outstate,
  7, //dma channel for in,  dma mode 1
  2, //dma channel for out, dma mode 0
  0, //1:double-packet buffering
};

/**
 * @brief   IN EP3 state.
 */
static USBInEndpointState ep3instate;

/**
 * @brief   EP3 initialization structure (IN only).
 */
static const USBEndpointConfig ep3config = {
  USB_EP_MODE_TYPE_ISOC,
  USB_EP_MODE_TYPE_INTR,
  NULL,
  NULL,
  NULL,
  EP_SIZ_ASI_IN,
  0,
  &ep3instate,
  NULL,
  3, //dma channel for in,  dma mode 1
  7, //dma channel for out, dma mode 0
  0, //1:double-packet buffering
};

/*
 * Handles the USB driver global events.
 */
static void usb_event(USBDriver *usbp, usbevent_t event) {

  switch (event) {
  case USB_EVENT_RESET:
    return;
  case USB_EVENT_ADDRESS:
    return;
  case USB_EVENT_CONFIGURED:
    chSysLockFromISR();
    /* Enables the endpoints specified into the configuration.
       Note, this callback is invoked from an ISR so I-Class functions
       must be used.*/
    usbInitEndpointI(usbp, 1, &ep1config);
    usbInitEndpointI(usbp, 2, &ep2config);
    usbInitEndpointI(usbp, 3, &ep3config);
    chSysUnlockFromISR();
    return;
  case USB_EVENT_UNCONFIGURED:
    return;
  case USB_EVENT_SUSPEND:
    return;
  case USB_EVENT_WAKEUP:
    return;
  case USB_EVENT_STALLED:
    return;
  }
  return;
}

/*
 * USB driver configuration.
 */
static const USBConfig usbcfg = {
  usb_event,
  get_descriptor,
  combo_request_hook,
  NULL
};

void usbdComboStart(void)
{
  /* connect vbus in sw mode defaultly */
  usbStart(&USBD0, &usbcfg);
}

#endif
