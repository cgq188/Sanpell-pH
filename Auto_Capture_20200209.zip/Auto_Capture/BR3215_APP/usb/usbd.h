/*
    ChibiOS/RT - Copyright (C) 2006-2013 Giovanni Di Sirio
                 Copyright (C) 2017 HunterSun Technologies
                 wei.lu@huntersun.com.cn

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    usbd.h
 * @brief   USB Device Header
 *
 * @addtogroup usbd
 * @{
 */

#ifndef _USBD_H_
#define _USBD_H_

#if (HAL_USE_USB == TRUE) || defined(__DOXYGEN__)

//#include "serial_usb.h"
//#include "hal_usb_hid.h"
#include "hal_usb_msd.h"

/*===========================================================================*/
/* Driver constants.                                                         */
/*===========================================================================*/

/**
 * @name    Huntersun specific USB IDs.
 * @{
 */
#define USB_VID_HS              0xF012

#define USB_PID_HS_CDC          0x0001
#define USB_PID_HS_MSC_AUD      0x0004
#define USB_PID_HS_HID          0x0005
#define USB_PID_HS_HID_CDC      0x6600
#define USB_PID_HS_COMBO        0x6601
/** @} */

/*
 * Endpoints to be used for USB Composite Device.
 */
#define EP_NUM_MSD_OUT                  1
#define EP_NUM_MSD_IN                   1
#define EP_NUM_ASI_OUT                  2
#define EP_NUM_ASI_IN                   3
#define EP_NUM_HID_IN                   2

/*
 * Endpoints size for USB Composite Device.
 */
#define EP_SIZ_MSD                      64U
#define EP_SIZ_ASI_OUT                  192U
#define EP_SIZ_ASI_IN                   64U
#define EP_SIZ_HID_IN                   8U


#ifdef __cplusplus
extern "C" {
#endif

#if HAL_USE_SERIAL_USB
  SerialUSBDriver *usbdSerialStart(void);
  void usbdSerialStop(void);
  bool usbdSerialIsActive(void);
  SerialUSBDriver *usbdSerialGetDriver(void);
#endif

#if HAL_USE_USB_HID
  USBHIDDriver *usbdHidStart(void);
  bool usbdHidIsActive(void);
  size_t hidGetReport(uint8_t id, uint8_t *bp, size_t n);
  msg_t hidSetReport(uint8_t id, uint8_t *bp, size_t n);
#endif

#if HAL_USE_USB_MSD
  USBMassStorageDriver *usbdMsdStart(void);
#endif
#if HAL_USE_USB_MSD && HAL_USE_USB_AUDIO
  void usbdComboStart(void);
#endif

#ifdef __cplusplus
}
#endif

#endif

#endif /* _USBD_H_ */
