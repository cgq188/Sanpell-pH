/*
    ChibiOS/RT - Copyright (C) 2006-2013 Giovanni Di Sirio
    PengJiang, 20140710
    luwei, 201704

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    usb_lld.c
 * @brief   USB device subsystem low level driver source.
 *
 * @addtogroup USB
 * @{
 */

#include <stddef.h> //size_t
#include <stdbool.h>
#include "hs_registry.h"
#include "br32xx.h"

/*===========================================================================*/
/* Driver local definitions.                                                 */
/*===========================================================================*/

/*===========================================================================*/
/* Driver exported variables.                                                */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local variables and types.                                         */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local functions.                                                   */
/*===========================================================================*/

static void _usb_rxfifo_flush(void) {
  uint8_t epnum;
  for (epnum = 1; epnum <= HS_USB_NUM_ENDPOINTS; ++epnum) {
    HS_USB->INDEX = epnum;
    HS_USB->RXCSR |= USB_RXCSR_H_FLUSHFIFO | USB_RXCSR_H_CLRDATATOG;
    while ((HS_USB->RXCSR & USB_RXCSR_H_FLUSHFIFO) != 0)
      ;
    /* if the FIFO is double-buffered, FlushFIFO may need
       to be set twice to completely clear the FIFO. */
    HS_USB->RXCSR |= USB_RXCSR_H_FLUSHFIFO;
    while ((HS_USB->RXCSR & USB_RXCSR_H_FLUSHFIFO) != 0)
      ;
  }
  /* Wait for 3 PHY Clocks.*/
  //osalSysPolledDelayX(24);
}

static void _usb_txfifo_flush_one(uint8_t ep) {
  HS_USB->INDEX = ep;
  if (0 == ep) {
    HS_USB->CSR0 |= USB_CSR0_FLUSHFIFO;
    while ((HS_USB->CSR0 & USB_CSR0_FLUSHFIFO) != 0)
      ;
  }
  else {
    HS_USB->TXCSR |= USB_TXCSR_H_FLUSHFIFO | USB_TXCSR_H_CLRDATATOG;
    while ((HS_USB->TXCSR & USB_TXCSR_H_FLUSHFIFO) != 0)
      ;
    /* if the FIFO is double-buffered, FlushFIFO may need
       to be set twice to completely clear the FIFO. */
    HS_USB->TXCSR |= USB_TXCSR_H_FLUSHFIFO;
    while ((HS_USB->TXCSR & USB_TXCSR_H_FLUSHFIFO) != 0)
      ;
  }
  /* Wait for 3 PHY Clocks.*/
  //osalSysPolledDelayX(18);
}

static void _usb_txfifo_flush(void) {
  uint8_t epnum;
  for (epnum = 0; epnum <= HS_USB_NUM_ENDPOINTS; ++epnum) {
    _usb_txfifo_flush_one(epnum);
  }
}

/*===========================================================================*/
/* Driver interrupt handlers and threads.                                    */
/*===========================================================================*/

/*===========================================================================*/
/* Driver exported functions.                                                */
/*===========================================================================*/

bool usbdrc_get_vbus(void)
{
  return true;//
  //return (((HS_SYS->USB_CTRL >> 20) & 0x7) == 7 ) ? true : false;
}

/**
 * @brief   Connects the VBUS.
 *
 * @api
 */
void usbdrc_connect_vbus(bool bForce)
{
  //HS_SYS->USB_CTRL
  //bit0 -- 1: test mode, 0: normal mode
  //bit4 -- 1: vbus_valid
  //bit5 -- 1: vbus_session
  //bit6 -- 1: vbus_lo
  //bit7 -- 1: reg control; 0: HW control
  //bit16 -- 1, turn off usb vbus detect, 0, turn on

  HS_SYS->USB_CTRL &= ~(1u << 16); //[16]pd_vbus_det=0, turn on vbus detector
  HS_SYS->USB_CTRL &= ~(1u << 0); //disable test mode
  if (bForce) {
    /* assert VBUS sessions via sw reg */
    HS_SYS->USB_CTRL |= (1u<<4)|(1u<<5)|(1u<<6)|(1u<<7); //vbus_valid/session/lo/reg
  }
  else {
    /* assert VBUS sessions via hw */
    HS_SYS->USB_CTRL &= ~(1u << 7);
  }
}

/**
 * @brief   Disconnect the VBUS.
 *
 * @api
 */
void usbdrc_disconnect_vbus(void)
{
  uint32_t ctrl = HS_SYS->USB_CTRL;
  ctrl &= ~((1u<<4)|(1u<<5)|(1u<<6));
  ctrl |= (1u << 7);
  HS_SYS->USB_CTRL = ctrl;
}

void usbdrc_flush_fifo(void)
{
  _usb_rxfifo_flush();
  _usb_txfifo_flush();
  HS_USB->INDEX = 0;
}

void usbdrc_setup_dma_in(uint8_t ch, uint8_t ep, uint16_t mps, const uint8_t *txbuf, size_t txsize)
{
  /* Disable the TX complete (Transmitter Ready) interrupt in DMA mode */
  HS_USB->INTR_TXEN &= ~(1 << ep);
  HS_USB->DMA_CH[ch].ADDR  = (uint32_t)txbuf;
  HS_USB->DMA_CH[ch].COUNT = txsize;
  HS_USB->DMA_CH[ch].CTRL  = ((mps>>3) << 8) | (ep << 4) |
    (1/*intr*/ << 3) | (1/*DMA Mode*/ << 2) | (1/*dir*/ << 1) | (1/*en*/ << 0);
  HS_USB->TXCSR |= USB_TXCSR_AUTOSET | USB_TXCSR_DMAENAB | USB_TXCSR_DMAMODE;
}

void usbdrc_setup_dma_out(uint8_t ch, uint8_t ep, uint16_t mps, uint8_t *rxbuf, size_t rxsize)
{
  /* Disable the Received OUT data interrupt in DMA mode */
  //HS_USB->INTR_RXEN &= ~(1 << ep);
  HS_USB->DMA_CH[ch].ADDR  = (uint32_t)rxbuf;
  HS_USB->DMA_CH[ch].COUNT = rxsize;
  if (rxsize % mps) {
    HS_USB->DMA_CH[ch].CTRL  = ((mps>>3) << 8) | (ep << 4) |
      (1/*intr*/ << 3) | (0/*DMA Mode*/ << 2) | (0/*dir*/ << 1) | (1/*en*/ << 0);
    HS_USB->RXCSR |= USB_RXCSR_DMAENAB;
  }
  else {
    HS_USB->DMA_CH[ch].CTRL  = ((mps>>3) << 8) | (ep << 4) |
      (1/*intr*/ << 3) | (1/*DMA Mode*/ << 2) | (0/*dir*/ << 1) | (1/*en*/ << 0);
    HS_USB->RXCSR |= USB_RXCSR_AUTOCLEAR | USB_RXCSR_DMAENAB | USB_RXCSR_DMAMODE;
  }
}

void usbdrc_handle_dma_in(uint8_t ch)
{
  uint16_t csr = HS_USB->TXCSR;
  if (0 == (csr & USB_TXCSR_DMAMODE)) {
    /* DMA mode 0 */
    csr &= ~(USB_TXCSR_AUTOSET | USB_TXCSR_DMAENAB);
    csr |= USB_TXCSR_P_TXPKTRDY;
  }
  else {
    /* DMA mode 1 */
    csr &= ~(USB_TXCSR_AUTOSET | USB_TXCSR_DMAENAB/* | USB_TXCSR_DMAMODE*/);
    HS_USB->DMA_CH[ch].CTRL = 0;
  }
  HS_USB->TXCSR = csr;
}

void usbdrc_handle_dma_out(uint8_t ch)
{
  uint16_t csr = HS_USB->RXCSR;
  if (0 == (csr & USB_RXCSR_DMAMODE)) {
    /* DMA mode 0 */
    csr &= ~(USB_RXCSR_AUTOCLEAR | USB_RXCSR_DMAENAB);
    csr &= ~USB_RXCSR_P_RXPKTRDY;
  }
  else {
    /* DMA mode 1 */
    csr &= ~(USB_RXCSR_AUTOCLEAR | USB_RXCSR_DMAENAB/* | USB_RXCSR_DMAMODE*/);
    HS_USB->DMA_CH[ch].CTRL = 0;
  }
  HS_USB->RXCSR = csr;
}
