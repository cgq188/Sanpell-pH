// br32xxconf.h

#ifndef _BR32xxCON_H_
#define _BR32xxCON_H_

#ifndef BR3215e
#define BR3215e
#endif

#endif /* _BR32xxCON_H_ */
