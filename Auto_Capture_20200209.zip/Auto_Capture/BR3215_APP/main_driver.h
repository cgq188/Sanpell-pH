#ifndef _MAIN_DRIVER_H_
#define _MAIN_DRIVER_H_

extern USBMassStorageDriver* gusbhandle;

void chip_id(void);
void uart_send_data(const void* data, int len);
void USBDoWithPackage(void);
BOOL CommandProcMain(void);
int dev_init(void);
void pow_off(void);
BOOL get_touch(void);

typedef void (*pocallback_t)(void);
typedef struct _tag_periodic_obj
{
	volatile unsigned int count;
	volatile unsigned int flag;
	volatile unsigned int interval;
	volatile unsigned int prevtime;
	pocallback_t on_locked, off_locked;
	pocallback_t on, off;
} periodic_obj;

extern periodic_obj buz;
extern periodic_obj rled;
extern periodic_obj gled;
extern periodic_obj bled;
extern periodic_obj mf;
extern periodic_obj mr;

void start_periodic_obj(periodic_obj* po, int nCount, int nInterval);

void monitor_power(BOOL bFirst, BOOL force);

#endif /* _MAIN_DRIVER_H_ */
