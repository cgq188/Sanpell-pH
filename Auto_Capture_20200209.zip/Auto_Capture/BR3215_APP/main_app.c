#include "main.h"

static BYTE Get_Max_From_Byte_Array(BYTE* pArray, int size, int step) {
	int i, mx = 0;
	for (i = 0; i < size; i += step) {
		if (pArray[i] > mx) mx = pArray[i];
	}
	return mx;
}

static BOOL app_check_fp_pressed_by_image(void)
{
	BYTE temp[16 * 16 * 2];
	bs201_capture_block_image(temp, 32, 48);
	bs201_capture_block_image(temp + 16 * 16, 48, 48);

	BYTE mx = Get_Max_From_Byte_Array(temp, 16 * 16 * 2, 2);
	return mx > 128;
}

int pressed_time = 0;
BOOL app_check_fp_pressed(void)
{
	static BOOL prev_pressed = FALSE;
	//static int prev_pressed_time = 0;

	BOOL current_pressed = app_check_fp_pressed_by_image();
	if (current_pressed)
	{
		pressed_time = GetMainTickCount();
	}

	if (prev_pressed != current_pressed
		//&& GetMainTickCount() - prev_pressed_time > 100
		)
	{
		//dUart_Printf(current_pressed ? "pressed %d\r\n" : "no pressed %d\r\n", get_touch());
		prev_pressed = current_pressed;
		//prev_pressed_time = GetMainTickCount();
	}

	return prev_pressed;
}

BOOL app_is_idle(void)
{
	if (GetMainTickCount() - pressed_time > 1000)
	{
		return TRUE;
	}
	return FALSE;
}

BOOL app_capture(void)
{
	const int timeout = 300;

	int st = GetMainTickCount();
	while (GetMainTickCount() - st < timeout)
	{
		if (!app_check_fp_pressed())
		{
			return FALSE;
		}
	}

	return TRUE;
}

BOOL app_verify(void)
{
	_delay_ms(500);
	if (GetMainTickCount() % 2)
	{
		return TRUE;
	}
	return FALSE;
}

BOOL app_verify_manager(void)
{
	return app_verify();
}

BOOL app_enroll_nth(int nth)
{
	(void)nth;
	_delay_ms(500);
	if (GetMainTickCount() % 2)
	{
		return TRUE;
	}
	return FALSE;
}

void app_power_off(void)
{
	//POWOFF//
	//_delay_ms(500);
// 	rled.on();
	pow_off();
// 	while (1)
//		;
	//POWOFF//
}

void app_delete(void)
{
	if (sb_enroll_count())
	{
		start_periodic_obj(&rled, -1, 100);

		BOOL manager_verified = FALSE;

		const int timeout = 3000;

		int st = GetMainTickCount();
		while (GetMainTickCount() - st < timeout)
		{
			if (app_capture())
			{
				if (app_verify_manager())
				{
					start_periodic_obj(&rled, 0, 0);
					manager_verified = TRUE;
					break;
				}
				else
				{
					start_periodic_obj(&rled, 0, 0);
					const int verify_fail_time = 200;
					start_periodic_obj(&rled, 1, verify_fail_time);
					_delay_ms(verify_fail_time);
					start_periodic_obj(&rled, -1, 100);
				}
			}
		}
		if (!manager_verified)
		{
			start_periodic_obj(&rled, 0, 0);
			return;
		}
	}

	sb_delete_all();
	const int del_time = 500;
	start_periodic_obj(&gled, 1, del_time);
	_delay_ms(del_time);
}

void app_delete_prepare(void)
{
	start_periodic_obj(&rled, -1, 100);

	const int timeout = 3000;

	int st = GetMainTickCount();
	while (GetMainTickCount() - st < timeout)
	{
		if (!app_check_fp_pressed())
		{
			start_periodic_obj(&rled, 0, 0);
			return;
		}
	}

	start_periodic_obj(&rled, 0, 0);
	app_delete();
}

void app_enroll(void)
{
	if (sb_enroll_count() == FP_MAX_USERS)
	{
		const int overflow_time = 200;
		start_periodic_obj(&rled, 1, overflow_time);
		_delay_ms(overflow_time);
		return;
	}

	if (sb_enroll_count())
	{
		start_periodic_obj(&bled, -1, 100);
	
		BOOL manager_verified = FALSE;
	
		const int timeout = 3000;

		int st = GetMainTickCount();
		while (GetMainTickCount() - st < timeout)
		{
			if (app_capture())
			{
				if (app_verify_manager())
				{
					start_periodic_obj(&bled, 0, 0);
					manager_verified = TRUE;
					break;
				}
				else
				{
					start_periodic_obj(&bled, 0, 0);
					const int verify_fail_time = 200;
					start_periodic_obj(&rled, 1, verify_fail_time);
					_delay_ms(verify_fail_time);
					start_periodic_obj(&bled, -1, 100);
				}
			}
		}
		if (!manager_verified)
		{
			start_periodic_obj(&bled, 0, 0);
			return;
		}
	}

	int nth = 0;
	while (nth < 5)
	{
		bled.on();
	
		const int timeout = 3000;

		BOOL captured = FALSE;

		int st = GetMainTickCount();
		while (GetMainTickCount() - st < timeout)
		{
			if (app_capture())
			{
				captured = TRUE;
				break;
			}
		}
		bled.off();
		if (!captured)
		{
			return;
		}

		if (app_enroll_nth(nth))
		{
			nth++;

			const int enroll_nth_ok_time = 200;
			start_periodic_obj(&gled, 1, enroll_nth_ok_time);
			_delay_ms(enroll_nth_ok_time);
		}
		else
		{
			const int enroll_nth_fail_time = 200;
			start_periodic_obj(&rled, 1, enroll_nth_fail_time);
			_delay_ms(enroll_nth_fail_time);
		}
	}

	{
		int empty_pos = sb_next_enroll_pos();
		if (empty_pos < FP_MAX_USERS)
		{
			sb_add(empty_pos);
		}
		const int enroll_ok_time = 500;
		start_periodic_obj(&gled, 1, enroll_ok_time);
		_delay_ms(enroll_ok_time);
	}
}

void app_enroll_prepare(void)
{
	start_periodic_obj(&bled, -1, 100);

	const int timeout = 3000;

	int st = GetMainTickCount();
	while (GetMainTickCount() - st < timeout)
	{
		if (!app_check_fp_pressed())
		{
			start_periodic_obj(&bled, 0, 0);
			app_enroll();
			return;
		}
	}

	start_periodic_obj(&bled, 0, 0);
	app_delete_prepare();
}

BOOL need_wait_for_take_off;

void wait_for_take_off1(void)
{
	const int timeout = 3000;

	int st = GetMainTickCount();
	while (GetMainTickCount() - st < timeout)
	{
		if (!app_check_fp_pressed())
		{
			return;
		}
	}

	app_enroll_prepare();
}

void wait_for_take_off2(void)
{
	while (app_check_fp_pressed())
		;
}

BOOL verify_success_open(void)
{
	const int mf_time = 230;
	start_periodic_obj(&gled, 1, mf_time);
	start_periodic_obj(&mf, 1, mf_time);
	_delay_ms(mf_time);

	return TRUE;
}

BOOL verify_success_close(void)
{
	const int gled_time = 1000;

	gled.on();

	int st = GetMainTickCount();
	while (GetMainTickCount() - st < gled_time)
	{
		if (!app_check_fp_pressed())
		{
			gled.off();
			return FALSE;
		}
	}
	gled.off();

	const int mr_time = 230;
	start_periodic_obj(&bled, 1, mr_time);
	start_periodic_obj(&mr, 1, mr_time);
	_delay_ms(mr_time);

	return TRUE;
}

void app_toggle_lock(BOOL verified)
{
	if (verified)
	{
		need_wait_for_take_off = TRUE;
		if (!dbLicenseR.nPrevLockOpened)
		{
			if (verify_success_open())
				DbLicenseSetPrevLockOpened(1);
		}
		else
		{
			if (verify_success_close())
				DbLicenseSetPrevLockOpened(0);
		}
	}

	if (need_wait_for_take_off)
	{
		wait_for_take_off1();
		wait_for_take_off2();
		need_wait_for_take_off = FALSE;
	}
}
BOOL app_poll_empty_db(void)
{
	BOOL pressed = app_check_fp_pressed();
	app_toggle_lock(pressed);
	return pressed;
}

BOOL app_poll_not_empty_db(void)
{
	if (app_capture())
	{
		if (app_verify())
		{
			app_toggle_lock(TRUE);
		}
		else
		{
			const int verify_fail_time = 200;
			start_periodic_obj(&rled, 1, verify_fail_time);
			_delay_ms(verify_fail_time);

			wait_for_take_off1();
			wait_for_take_off2();
			need_wait_for_take_off = FALSE;
		}

		return TRUE;
	}

	return FALSE;
}

BOOL app_poll(void)
{
	BOOL pressed = FALSE;
	if (sb_enroll_count())
	{
		pressed = app_poll_not_empty_db();
	}
	else
	{
		pressed = app_poll_empty_db();
	}
	return pressed;
}
