/*
    ChibiOS - Copyright (C) 2006..2015 Giovanni Di Sirio

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    templates/mcuconf.h
 */

#ifndef _MCUCONF_H_
#define _MCUCONF_H_

/*
 * BR3215x drivers configuration.
 * The following settings override the default settings present in
 * the various device driver implementation headers.
 * Note that the settings for each driver only have effect if the whole
 * driver is enabled in halconf.h.
 *
 * IRQ priorities:
 * 3...0        Lowest...Highest.
 *
 * DMA priorities:
 * 0...3        Lowest...Highest.
 */

#define BR3215c_MCUCONF

/*
 * HAL driver system settings.
 */
#define HS_GPIO_IRQ_PRIORITY             3

/*
 * ADC driver system settings.
 */
#define HS_ADC_USE_ADC0                  TRUE
#define HS_ADC_ADC0_DMA_STREAM           HS_DMA_STREAM_ID(2, 4)
#define HS_ADC_ADC0_DMA_PRIORITY         2
#define HS_ADC_IRQ_PRIORITY              3

/*
 * GPT driver system settings.
 */
#define HS_GPT_USE_TIM0                  FALSE
#define HS_GPT_USE_TIM1                  FALSE
#define HS_GPT_USE_TIM2                  FALSE
#define HS_GPT_TIM0_IRQ_PRIORITY         3
#define HS_GPT_TIM1_IRQ_PRIORITY         3
#define HS_GPT_TIM2_IRQ_PRIORITY         3

/*
 * ICU driver system settings.  input capture unit
 */
#define HS_ICU_USE_TIM0                  FALSE
#define HS_ICU_USE_TIM1                  FALSE
#define HS_ICU_USE_TIM2                  FALSE
#define HS_ICU_TIM0_IRQ_PRIORITY         3
#define HS_ICU_TIM1_IRQ_PRIORITY         3
#define HS_ICU_TIM2_IRQ_PRIORITY         3

/*
 * PWM driver system settings.
 */
#define HS_PWM_USE_TIM0                  TRUE
#define HS_PWM_USE_TIM1                  TRUE
#define HS_PWM_USE_TIM2                  TRUE
#define HS_PWM_TIM0_IRQ_PRIORITY         3
#define HS_PWM_TIM1_IRQ_PRIORITY         3
#define HS_PWM_TIM2_IRQ_PRIORITY         3

/*
 * I2C driver system settings.
 */
#define HS_I2C_USE_I2C1                  FALSE
#define HS_I2C_BUSY_TIMEOUT              50
#define HS_I2C_I2C1_RX_DMA_STREAM        HS_DMA_STREAM_ID(1, 0)
#define HS_I2C_I2C1_TX_DMA_STREAM        HS_DMA_STREAM_ID(1, 6)
#define HS_I2C_I2C1_IRQ_PRIORITY         3
#define HS_I2C_DMA_ERROR_HOOK(i2cp)      osalSysHalt("DMA failure")

/*
 * SERIAL driver system settings.
 */
#define HS_SERIAL_USE_UART0              TRUE
#define HS_SERIAL_USE_UART1              TRUE
#define HS_SERIAL_USE_UART2              FALSE
#define HS_SERIAL_UART0_IRQ_PRIORITY     3
#define HS_SERIAL_UART1_IRQ_PRIORITY     3
#define HS_SERIAL_UART2_IRQ_PRIORITY     3

/*
 * UART driver system settings.
 */
#define HS_UART_USE_UART0                TRUE
#define HS_UART_USE_UART1                FALSE
#define HS_UART_USE_UART2                FALSE
#define HS_UART_UART0_IRQ_PRIORITY       3
#define HS_UART_UART1_IRQ_PRIORITY       3
#define HS_UART_UART2_IRQ_PRIORITY       3


/*
 * SF driver system settings.
 */
#define HS_SF_IRQ_PRIORITY               3

/*
 * SPI driver system settings.
 */
#define HS_SPI_USE_SPI0                  TRUE
#define HS_SPI_USE_SPI1                  FALSE
#define HS_SPI_SPI1_RX_DMA_STREAM        HS_DMA_STREAM_ID(2, 0)
#define HS_SPI_SPI1_TX_DMA_STREAM        HS_DMA_STREAM_ID(2, 3)
#define HS_SPI_SPI1_DMA_PRIORITY         1
#define HS_SPI_SPI1_IRQ_PRIORITY         3
#define HS_SPI_DMA_ERROR_HOOK(spip)      osalSysHalt("DMA failure")

/*
 * ST driver system settings.
 */
#define HS_ST_IRQ_PRIORITY               2
#define HS_ST_USE_TIMER                  2

/*
 * MSR driver system settings.
 */
#define HS_MSR_IRQ_PRIORITY              3

/*
 * USB driver system settings.
 */
#define HS_USB_USE_USB0                  TRUE
#define HS_USB_USB0_IRQ_PRIORITY         3
#define HS_USB_USB0_DMA_IRQ_PRIORITY     2

/*
 * Radio PHY driver settings.
 */
#define HS_BT_IRQ_PRIORITY               1

#endif /* _MCUCONF_H_ */
