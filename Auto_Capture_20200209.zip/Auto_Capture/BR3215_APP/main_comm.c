#include "main.h"

/************************************************************************/
/*                                                                      */
/************************************************************************/
typedef enum
{
	COMM_MODE_NONE = -1,
	COMM_MODE_SERIAL,
	COMM_MODE_USB,
}T_COMM_MODE;

extern int comm_mode;

/************************************************************************/
/*                                                                      */
/************************************************************************/
int MySCSICmd_len = 0;
void* MySCSICmd_buf = 0;

#define USB_BLOCK_SIZE 65536

int vbUSBCmd = 0;
int		nUsbCmdStatus = 0;
UINT8	U_RdBuf[SB_OEM_PKT_SIZE];

extern int UsbBulkSendPublic(void* context, void* data, int len);
extern int UsbBulkReceivePublic(void* context, void* data, int len);

void USB_INT_DISABLE(void)
{
// 	osalSysLock();
// 	NVIC_DisableIRQ(USB_IRQn);
// 	NVIC_DisableIRQ(USB_DMA_IRQn);
// 	osalSysUnlock();
}
void USB_INT_ENABLE(void) 
{ 
// 	osalSysLock();
// 	NVIC_EnableIRQ(USB_IRQn);
// 	NVIC_EnableIRQ(USB_DMA_IRQn);
// 	osalSysUnlock();
}

void usbDoTranceive(void* context, int bReceive, int nTransferLen)
{
	if (bReceive)	//receive
	{
		if (vbUSBCmd) // receive data
		{
			if (nUsbCmdStatus == 1 && MySCSICmd_len > 0 && nTransferLen == MySCSICmd_len)
				MySCSICmd_len = UsbBulkReceivePublic(context, MySCSICmd_buf, MySCSICmd_len) ? 0 : -1;
			else
			{
			}//	UsbBulkReceivePublic(context, NULL, nTransferLen);
		}
		else // waiting CMD state
		{
			if (nTransferLen == SB_OEM_PKT_SIZE)
			{
				if (UsbBulkReceivePublic(context, U_RdBuf, SB_OEM_PKT_SIZE))
				{
					USB_INT_DISABLE();
					vbUSBCmd = 1;
				}
			}
			else
			{
			}//	UsbBulkReceivePublic(context, NULL, nTransferLen);
		}
	}
	else	//send
	{
		if (vbUSBCmd && nUsbCmdStatus == 2 && MySCSICmd_len > 0)
			MySCSICmd_len = UsbBulkSendPublic(context, MySCSICmd_buf, MySCSICmd_len) ? 0 : -1;
		else
		{
		}//	UsbBulkSendPublic(context, NULL, nTransferLen);
	}
}

int usbOperation(void* pData, int nSize, int bWait, int nMode)
{
	BOOL bBreaked = FALSE;
	BYTE* pDataTemp = (BYTE*)pData;
	int nSizeTemp = nSize, nSizeReal;

	DWORD dwStartTime;
	nUsbCmdStatus = nMode;

	while (!bBreaked && nSizeTemp)
	{
		nSizeReal = nSizeTemp;
		if (nSizeReal > USB_BLOCK_SIZE)
			nSizeReal = USB_BLOCK_SIZE;

		MySCSICmd_len = nSizeReal;
		MySCSICmd_buf = pDataTemp;

		dwStartTime = GetMainTickCount();
		while (1)
		{
			// here do USB package using inquiry mode
			//if(gUsbMode!=USB_INTTERRUPT_MODE)
			USBDoWithPackage();

			if (MySCSICmd_len == 0)
			{
				pDataTemp += nSizeReal;
				nSizeTemp -= nSizeReal;
				break;
			}
			if (MySCSICmd_len < 0) {
				bBreaked = TRUE;
				break;
			}

			if (!bWait || GetMainTickCount() - dwStartTime >= 5000)
			{
				bBreaked = TRUE;
				break;
			}
		}

		MySCSICmd_len = 0;
	}

	MySCSICmd_len = 0;
	MySCSICmd_buf = 0;
	nUsbCmdStatus = 0;

	if (nSizeTemp == 0)
		return nSize;
	return 0;
}

int usbRead(void* pData, int nSize, int bWait)
{
	return usbOperation(pData, nSize, bWait, 1);
}

int usbWrite(void* pData, int nSize, int bWait)
{
	return usbOperation(pData, nSize, bWait, 2);
}

/************************************************************************/
/*                                                                      */
/************************************************************************/
int comm_mode = COMM_MODE_NONE;

BOOL comm_send(void* pbuf, int nsize)
{
	BOOL bRet;

	switch (comm_mode)
	{
	case COMM_MODE_SERIAL:
		uart_send_data(pbuf, nsize);
		bRet = TRUE;
		break;

	case COMM_MODE_USB:
		bRet = (usbWrite(pbuf, nsize, 1) == nsize);
		break;

	default:
		bRet = FALSE;
		break;
	}

	return bRet;
}

BOOL comm_recv(void* pbuf, int nsize)
{
	BOOL bRet;

	switch (comm_mode)
	{
	case COMM_MODE_SERIAL:
		bRet = iqReadTimeout(&CMDQ, pbuf, nsize, 5000) == (size_t)nsize;
		break;

	case COMM_MODE_USB:
		bRet = (usbRead(pbuf, nsize, 1) == nsize);
		break;

	default:
		bRet = FALSE;
		break;
	}

	return bRet;
}

/************************************************************************/
/*                                                                      */
/************************************************************************/
//////////////////////////////////////////////////////////////////////////
BOOL oem_get_cmd(SB_OEM_PKT* pCmdPkt)
{
	if (iqPeek(&CMDQ, (uint8_t*)pCmdPkt, SB_OEM_PKT_SIZE) && oemp_CheckCmdAckPkt(DEVID, pCmdPkt) == 0)
	{
		comm_mode = COMM_MODE_SERIAL;
		comm_recv(pCmdPkt, SB_OEM_PKT_SIZE);
		return TRUE;
	}
	return FALSE;
}

BOOL comm_usb_get_cmd(SB_OEM_PKT* pCmdPkt)
{
	if (vbUSBCmd)
	{
		memcpy(pCmdPkt, U_RdBuf, SB_OEM_PKT_SIZE);

		if (oemp_CheckCmdAckPkt(DEVID, pCmdPkt))
		{
			vbUSBCmd = 0;
			USB_INT_ENABLE();
			return FALSE;
		}
		comm_mode = COMM_MODE_USB;
		return TRUE;
	}

	return FALSE;
}

extern void engine_poll(void);
//////////////////////////////////////////////////////////////////////////
BOOL CommandProcMain(void)
{
	BOOL bRet = FALSE; //FALSE-first, no cmd
	DWORD dwStartTime;

	SB_OEM_PKT CmdPkt;

	if (oem_get_cmd(&CmdPkt))
	{
		USB_INT_DISABLE();
		oem_command_proc(&CmdPkt);
		USB_INT_ENABLE();
	}

	/************  USB   ********************************************/
	dwStartTime = GetMainTickCount();
	while (GetMainTickCount() - dwStartTime < 1000)
	{
		engine_poll();
		USBDoWithPackage();
		if (comm_usb_get_cmd(&CmdPkt))
		{
			oem_command_proc(&CmdPkt);
			vbUSBCmd = 0;
			USB_INT_ENABLE();
			dwStartTime = GetMainTickCount();
		}
		else if (!bRet)
			break;

		bRet = TRUE; //TRUE-no first, cmd
	}

	comm_mode = COMM_MODE_NONE;

	return TRUE;
}

USBMassStorageDriver *gusbhandle;
void USBDoWithPackage(void)
{
	usb_msd_worker(gusbhandle);
}
