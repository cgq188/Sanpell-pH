#include "main.h"

void dUart_Printf(char* fmt, ...)		// for debug
{
	va_list ap;
	char szTemp[256];

	va_start(ap, fmt);
	vsprintf(szTemp, fmt, ap);
	uart_send_data(szTemp, strlen(szTemp));
	va_end(ap);
}

void hexdump(const void* pData, int len)
{
	BYTE c, str[17];
	int j, n = 0;
	BYTE* buff = (BYTE*)pData;

	while (n < len)
	{
		dUart_Printf("  %04x:", n);
		for (j = 0; j < 16; j++)
		{
			dUart_Printf("%c", j == 8 ? '-' : ' ');
			if (n++ >= len)
			{
				dUart_Printf("  ");
				str[j] = 0;
			}
			else
			{
				dUart_Printf("%02X", c = *buff++);
				str[j] = c >= ' ' && c <= '~' ? c : '.';
			}
		}
		str[j] = 0;
		dUart_Printf("  %s\r\n", str);
	}
}

int GetMainTickCount(void)
{
	return osalOsGetSystemTimeX();
}

/************************************************************************/
/*                                                                      */
/************************************************************************/
//gpio pins
#define LED_R_GRP		GPIOB
#define LED_R_PIN		2
#define LED_G_GRP		GPIOA
#define LED_G_PIN		4
#define LED_B_GRP		GPIOA
#define LED_B_PIN		5
#define BEEP_GRP		GPIOA
#define BEEP_PIN		8
#define POWEN_GRP		GPIOA
#define POWEN_PIN		1
#define MFIN_GRP		GPIOA
#define MFIN_PIN		3
#define MRIN_GRP		GPIOA
#define MRIN_PIN		2
#define TOUCH_GRP		GPIOB
#define TOUCH_PIN		6
#define CHG_GRP			GPIOA
#define CHG_PIN			6

#define LED_R_OFF()		{GPIO_WriteBit(LED_R_GRP,LED_R_PIN,1); GPIO_Init(LED_R_GRP,LED_R_PIN,GPIO_INPUT);}
#define LED_R_ON()		{GPIO_WriteBit(LED_R_GRP,LED_R_PIN,0); GPIO_Init(LED_R_GRP,LED_R_PIN,GPIO_OUTPUT);}
#define LED_G_OFF()		{GPIO_WriteBit(LED_G_GRP,LED_G_PIN,1); GPIO_Init(LED_G_GRP,LED_G_PIN,GPIO_INPUT);}
#define LED_G_ON()		{GPIO_WriteBit(LED_G_GRP,LED_G_PIN,0); GPIO_Init(LED_G_GRP,LED_G_PIN,GPIO_OUTPUT);}
#define LED_B_OFF()		{GPIO_WriteBit(LED_B_GRP,LED_B_PIN,1); GPIO_Init(LED_B_GRP,LED_B_PIN,GPIO_INPUT);}
#define LED_B_ON()		{GPIO_WriteBit(LED_B_GRP,LED_B_PIN,0); GPIO_Init(LED_B_GRP,LED_B_PIN,GPIO_OUTPUT);}
void rled_on_locked(void) { LED_R_ON(); }
void rled_off_locked(void) { LED_R_OFF(); }
void gled_on_locked(void) { LED_G_ON(); }
void gled_off_locked(void) { LED_G_OFF(); }
void bled_on_locked(void) { LED_B_ON(); }
void bled_off_locked(void) { LED_B_OFF(); }
void rled_on(void) {__disable_irq(); LED_R_ON(); __enable_irq();}
void rled_off(void) {__disable_irq(); LED_R_OFF();  __enable_irq();}
void gled_on(void) {__disable_irq(); LED_G_ON();  __enable_irq();}
void gled_off(void) {__disable_irq(); LED_G_OFF();  __enable_irq();}
void bled_on(void) {__disable_irq(); LED_B_ON();  __enable_irq();}
void bled_off(void) {__disable_irq(); LED_B_OFF();  __enable_irq();}
#define LED_ALL_OFF()	{__disable_irq(); LED_R_OFF() LED_G_OFF() LED_B_OFF()  __enable_irq();}

#define POWEN_OUTPUT() GPIO_Init(POWEN_GRP,POWEN_PIN,GPIO_OUTPUT)
#define POWEN_HIGH()   GPIO_WriteBit(POWEN_GRP,POWEN_PIN,1)
#define POWEN_LOW()    GPIO_WriteBit(POWEN_GRP,POWEN_PIN,0)
#define MFIN_OUTPUT() GPIO_Init(MFIN_GRP,MFIN_PIN,GPIO_OUTPUT)
#define MFIN_HIGH()   GPIO_WriteBit(MFIN_GRP,MFIN_PIN,1)
#define MFIN_LOW()    GPIO_WriteBit(MFIN_GRP,MFIN_PIN,0)
#define MRIN_OUTPUT() GPIO_Init(MRIN_GRP,MRIN_PIN,GPIO_OUTPUT)
#define MRIN_HIGH()   GPIO_WriteBit(MRIN_GRP,MRIN_PIN,1)
#define MRIN_LOW()    GPIO_WriteBit(MRIN_GRP,MRIN_PIN,0)
#define MOFF()		{MFIN_LOW(); MRIN_LOW();}
#define MF()		{MFIN_HIGH(); MRIN_LOW();}
#define MR()		{MFIN_LOW(); MRIN_HIGH();}
void m_off_locked(void) { MOFF(); }
void mf_on_locked(void) { MF(); }
void mr_on_locked(void) { MR(); }
void m_off(void) {__disable_irq(); MOFF(); __enable_irq();}
void mf_on(void) {__disable_irq(); MF(); __enable_irq();}
void mr_on(void) {__disable_irq(); MR(); __enable_irq();}

#define TOUCH_INPUT() GPIO_Init(TOUCH_GRP,TOUCH_PIN,GPIO_INPUT)
#define TOUCH_GET()   GPIO_ReadBit(TOUCH_GRP,TOUCH_PIN)
#define CHG_INPUT() GPIO_Init(CHG_GRP,CHG_PIN,GPIO_INPUT)
#define CHG_GET()   GPIO_ReadBit(CHG_GRP,CHG_PIN)

void gpio_pins_init(void)
{
	POWEN_HIGH();
	POWEN_OUTPUT();
	//POWEN_HIGH();

	LED_ALL_OFF();

	MOFF();
	MFIN_OUTPUT();
	MRIN_OUTPUT();
	//MOFF();

	TOUCH_INPUT();
	CHG_INPUT();
}

void pow_off(void)
{
	__disable_irq();
	POWEN_LOW();
	__enable_irq();
}

BOOL get_touch(void)
{
	return TOUCH_GET() ? TRUE : FALSE;
}

BOOL get_chg(void)
{
	return CHG_GET() ? TRUE : FALSE;
}

#define beep_pwmperiod 4
const PWMConfig beep_pwmconfig = {
		  8000,                                    /* 0==8MkHz PWM clock frequency.   */
		  beep_pwmperiod,                                    /* Initial PWM period 1/8us.       */
		  NULL,
		  {
		   {PWM_OUTPUT_ACTIVE_HIGH, NULL, NULL},
		   {PWM_OUTPUT_ACTIVE_HIGH, NULL, NULL},
		   {PWM_OUTPUT_ACTIVE_HIGH, NULL, NULL},
		   {PWM_OUTPUT_ACTIVE_HIGH, NULL, NULL},
		  },
		  0,
		  0,
		  0
		#if PWM_USE_DMA
		  ,
		  FALSE,
		  NULL
		#endif
};

void beep_on_locked(void)
{
	//pwmEnableChannel(&PWMD1, 0, beep_pwmperiod / 2);
	pwmEnableChannelI(&PWMD1, 0, beep_pwmperiod / 2);
}
void beep_off_locked(void)
{
	//pwmDisableChannel(&PWMD1, 0);
	pwmDisableChannelI(&PWMD1, 0);
}
void beep_on(void)
{
	__disable_irq();
	beep_on_locked();
	__enable_irq();
}
void beep_off(void)
{
	__disable_irq();
	beep_off_locked();
	__enable_irq();
}

void beep_init(void)
{
	palSetPadMode(BEEP_GRP, BEEP_PIN, PAL_MODE_OUTPUT | PAL_MODE_ALTERNATE(PAD_FUNC_TIMER1_TOGGLE0) | PAL_MODE_DRIVE_CAP(3));
	pwmStart(&PWMD1, &beep_pwmconfig);
	beep_off();
}

void poll_periodic_obj(periodic_obj* po, unsigned int cur_time)
{
	if (po->count && cur_time - po->prevtime > po->interval)
	{
		po->prevtime = cur_time;

		if (po->count != -1UL) po->count--;

		if (po->count)
		{
			if (po->flag)
			{
				po->flag = 0;
				po->off_locked();
			}
			else
			{
				po->flag = 1;
				po->on_locked();
			}
		}
		else
		{
			po->off_locked();
		}
	}
}

void start_periodic_obj(periodic_obj* po, int nCount, int nInterval)
{
	__disable_irq();
	po->count = 0;
	__enable_irq();

	po->off();

	po->flag = 0;
	po->interval = nInterval;
	po->prevtime = GetMainTickCount();

	if (nCount)
	{
		po->on();
		po->flag = 1;
	}

	po->count = nCount;
}

periodic_obj buz = { 0,0,0,0, beep_on_locked, beep_off_locked, beep_on, beep_off };
periodic_obj rled = { 0,0,0,0, rled_on_locked, rled_off_locked, rled_on, rled_off };
periodic_obj gled = { 0,0,0,0, gled_on_locked, gled_off_locked, gled_on, gled_off };
periodic_obj bled = { 0,0,0,0, bled_on_locked, bled_off_locked, bled_on, bled_off };
periodic_obj mf = { 0,0,0,0, mf_on_locked, m_off_locked, mf_on, m_off };
periodic_obj mr = { 0,0,0,0, mr_on_locked, m_off_locked, mr_on, m_off };

void _poll_periodic_objs(unsigned int cur_time)
{
	wdgResetI(&WDGD0);

	poll_periodic_obj(&buz, cur_time);
	poll_periodic_obj(&rled, cur_time);
	poll_periodic_obj(&gled, cur_time);
	poll_periodic_obj(&bled, cur_time);
	poll_periodic_obj(&mf, cur_time);
	poll_periodic_obj(&mr, cur_time);
}

static const SFConfig m_sfConfig =
{
//  .speed = 48000000,
  .speed = 64000000,
  .cs = 0,
};

ADCConversionGroup group;
void adc_init(void)
{
	adcBuildConversionGroup(&group, false, true, ADC_TRIGGER_SOURCE_SW,
		ADC_TRIGGER_EDGE_POS, ADC_TRIGGER_TARGET_GROUP_CONTINUOUS, NULL, NULL);

	adcAddChannelSingleEnded(&group, ADC_CHANNEL_EXTERN_PIN1, 4200, 0, 13);  //GPIOB4Ϊ����

	// Configure external channel pins
	adcConfigExternalChannelPins(&group);
}
void adc_deinit(void)
{
	// Restore external channel pins to their default settings.
	adcRestoreExternalChannelPins(&group);
}

int dev_init(void)
{
	halInit();

	WDGConfig wdtconfig;
	wdtconfig.timeout_ms = 1000;
	wdgStart(&WDGD0, (const WDGConfig*)&wdtconfig);

	gpio_pins_init();
	beep_init();

	FP_CommInit(115200);

	sfStart(&SFD, &m_sfConfig);
	if (sfProbe(&SFD, TIME_INFINITE) < 0)
		return RT_FAIL;
	Flash_Init(2, 2);

	chip_id();

#if defined(BS510_8MM)
	BS510_Init();
#else
	bs201_Init();
#endif
	adc_init();

	DbLicenseRead();

	//POWOFF//
	//start_periodic_obj(&bled, 1, 100);
	//POWOFF//
	gusbhandle = usbdMsdStart();
	gusbhandle->host_ctrl_started = 0;
	gusbhandle->last_scsi_cmd_time = 0;

	return RT_OK;
}

BOOL adc_test(void) {

#define DEPTH     10
	adcsample_t buf[DEPTH];

	// Start conversion
	adcAcquireBus(&ADCD0);
	adcStart(&ADCD0, NULL);
	adcConvert(&ADCD0, &group, buf, DEPTH, TIME_INFINITE);
	adcStopConversion(&ADCD0);
	adcStop(&ADCD0);
	adcReleaseBus(&ADCD0);

	// Data processing
	{
		int32_t avg = 0;
		float favg = 0.0f;
		int j;
		for (j = 0; j < DEPTH; j++)
			avg += buf[j];
		avg /= DEPTH;
		adcDataFixedToFloat(&favg, (adcsample_t*)&avg, 1);
		//dUart_Printf("avg = %04X(%4.3f)\r\n", (adcsample_t)avg, favg);
		
		if (favg > 1.5f)
			return TRUE;
	}

	return FALSE;
}

void monitor_power(BOOL bFirst, BOOL force)
{
	static BOOL low_powered = FALSE;
	static BOOL prev_chg = TRUE; //full or no charging
	//static BOOL ever_charged = FALSE;
	(void)bFirst;

	BOOL cur_chg = get_chg();
	if (force || prev_chg != cur_chg)
	{
		if (cur_chg) //full or no charging
		{
			rled.off();
			//if (ever_charged)
			//	gled.on();
			//else
			//	gled.off();
		}
		else //charging
		{
			//if (bFirst)
			//	ever_charged = TRUE;

			rled.on();
			//gled.off();
		}

		prev_chg = cur_chg;
	}

	if (!low_powered && !adc_test())
	{
		start_periodic_obj(&buz, 3, 200);
		low_powered = TRUE;
	}
	if (cur_chg && app_is_idle()) //full or no charging
	{
		app_power_off();
	}
}
