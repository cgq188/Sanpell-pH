
#ifndef _FP_TYPE_H_
#define _FP_TYPE_H_

#include <stdint.h>
#include <stdbool.h>

typedef unsigned char UINT8;
typedef unsigned short 	UINT16;
typedef unsigned long  UINT32;
typedef char  INT8;
typedef short INT16;
typedef long  INT32;
typedef volatile unsigned char  VUINT8;
typedef volatile unsigned short VUINT16;
typedef volatile unsigned long  VUINT32;

typedef UINT8   BOOL;
typedef UINT32  DWORD;
typedef UINT16  WORD;
typedef UINT8   BYTE;

#ifndef NULL
#define NULL   (void *)0
#endif

#if !defined(FALSE)
#define FALSE   0
#define false 	0
#endif

#if !defined(TRUE)
#define TRUE    1
#define true  	1
#endif

#if !defined(RT_OK)
#define RT_OK            0x00 //success
#define RT_FAIL          0x01  //fail
#define RT_COMMAND_ERR   0x02  //command error
#define RT_PARAM_ERR     0x03  //param error
#define RT_OVERTIME      0x04  //over time
#define RT_ECC_ERR       0x05  //ecc error
#define RT_WRITE_ERR     0x06  //write flash err
#define RT_READ_ERR      0x07  //read flash err
#endif

#define MIN(x1,x2)			(((x1)<(x2))? (x1):(x2))
#define MAX(x1,x2)			(((x1)>(x2))? (x1):(x2))
#define LOWORD(l)           ((WORD)(l))
#define HIWORD(l)           ((WORD)(((DWORD)(l) >> 16) & 0xFFFF))
#define LOBYTE(w)           ((BYTE)(w))
#define HIBYTE(w)           ((BYTE)(((WORD)(w) >> 8) & 0xFF))
#define MAKEWORD(a, b)      ((WORD)(((BYTE)(a)) | ((WORD)((BYTE)(b))) << 8))
#define MAKELONG(a, b)      ((DWORD)(((WORD)(a)) | ((DWORD)((WORD)(b))) << 16))

#define BE_DWORD(dw)		(((dw & 0xFF) << 24) | ((dw & 0xFF00) << 8) | ((dw & 0xFF0000) >> 8) | (dw >> 24))
#define BE_WORD(w)			(((w & 0xFF) << 8) | (w >> 8))

#define MAKE_BIG_END_WORD(lw)	MAKEWORD(HIBYTE(lw), LOBYTE(lw))
#define MAKE_BIG_END_LONG(ll)	MAKELONG(MAKE_BIG_END_WORD(HIWORD(ll)), MAKE_BIG_END_WORD(LOWORD(ll)))

#define EMPTY_DATA (-1UL)

#endif /* _FP_DEFINE_H_ */
