

#include "hal.h"
#include "timer.h"
#include "wdg.h"

/*******************************************************************************************************
** ��������:  TIM_Init
** ��������:  ��ʼ��ָ���Ķ�ʱ��
**
** ��        ��:  TIM_TypeDef _TIMx[IN]       ;��ʱ����;
**           UINT32 _Limit[IN]           ;��ʱ�жϻ��߼���������ֵ;
**           UINT8 _Prescale[IN]         ;�Զ�ʱ��ʱ�ӵķ�Ƶϵ��;
**           TIM_Mode _TIM_Mode[IN]      ;��ʱ����ʼ����ģʽ;
** ��	 ��:  FALSE ����  TRUE
**
** ����  ��:  BR MICRO
** �ա�  ��:
**
********************************************************************************************************/

UINT32 timestamp[3];

static WDGConfig wdtconfig;
#if HS_GPT_USE_TIM0
static GPTConfig tim0confg;
static gptcnt_t tim0interval;
static void tim0callback(GPTDriver *gptp);
#endif
#if HS_GPT_USE_TIM1
static GPTConfig tim1confg;
static gptcnt_t tim1interval;
static void tim1callback(GPTDriver *gptp);
#endif
#if HS_GPT_USE_TIM2
static GPTConfig tim2confg;
static gptcnt_t tim2interval;
static void tim2callback(GPTDriver *gptp);
#endif

BOOL TIM_Init(TIM_TypeDef _TIMx, UINT32 _Limit, UINT16 _Prescale, TIM_Mode _TIM_Mode)
{
	if (_TIM_Mode == TIM_WDT)
	{
		(void)_Prescale;
		wdtconfig.timeout_ms = _Limit;
		wdgStart(&WDGD0,(const WDGConfig *)&wdtconfig);
		while(1)
		{
			__NOP();
		}
		return TRUE;
	}
	else if((_TIM_Mode&TIMSMASK) == TIMSMASK)
	{
		timestamp[TIMSNUM(_TIMx)] = ((int)(osalOsGetSystemTimeX()));
		return TRUE;
	}
	else
	{
		if(_TIMx == TIM0)
		{
#if HS_GPT_USE_TIM0
			tim0confg.callback = _TIM_Mode == TIM_CNT ? NULL : tim0callback;
			tim0confg.cr2 = 0;
			tim0confg.dier = 0;
			tim0confg.frequency = (cpm_get_clock(HS_TIM0_CLK)/(_Prescale+1));
			gptStart(_TIMx,( const GPTConfig *)&tim0confg);
			tim0interval = _Limit;
#else
			return FALSE;
#endif
		}
		else if(_TIMx == TIM1)
		{
#if HS_GPT_USE_TIM1
			tim1confg.callback = _TIM_Mode == TIM_CNT ? NULL : tim1callback;
			tim1confg.cr2 = 0;
			tim1confg.dier = 0;
			tim1confg.frequency = (cpm_get_clock(HS_TIM1_CLK)/(_Prescale+1));
			gptStart(_TIMx,( const GPTConfig *)&tim1confg);
			tim1interval = _Limit;
#else
			return FALSE;
#endif
		}
		else if(_TIMx == TIM2)
		{
#if HS_GPT_USE_TIM2
			tim2confg.callback = _TIM_Mode == TIM_CNT ? NULL : tim2callback;
			tim2confg.cr2 = 0;
			tim2confg.dier = 0;
			tim2confg.frequency = (cpm_get_clock(HS_TIM2_CLK)/(_Prescale+1));
			gptStart(_TIMx,( const GPTConfig *)&tim2confg);
			tim2interval = _Limit;
#else
			return FALSE;
#endif
		}
		else
		{
			return FALSE;
		}

		return TRUE;
	}
}

/*******************************************************************************************************
** ��������:  TIM_Start
** ��������:  ������ʱ��
**
** ��        ��:  TIM_TypeDef _TIMx[IN]       ;��ʱ����;
** ��	 ��:  FALSE ����  TRUE
**
** ����  ��:  BR MICRO
** �ա�  ��:
**
********************************************************************************************************/
BOOL TIM_Start(TIM_TypeDef _TIMx)
{
	if (_TIMx == TIMWGT)
	{
		return FALSE;
	}
	else if((((UINT32)_TIMx)&TIMSMASK) == TIMSMASK)
	{
		timestamp[TIMSNUM(_TIMx)] = (UINT32)(osalOsGetSystemTimeX());
		return TRUE;
	}
	else if(_TIMx == TIM0)
	{
#if HS_GPT_USE_TIM0
		gptStartContinuous(_TIMx, tim0interval);
#else
		return FALSE;
#endif
	}
	else if(_TIMx == TIM1)
	{
#if HS_GPT_USE_TIM1
		gptStartContinuous(_TIMx, tim1interval);
#else
		return FALSE;
#endif
	}
	else if(_TIMx == TIM2)
	{
#if HS_GPT_USE_TIM2
		gptStartContinuous(_TIMx, tim2interval);
#else
		return FALSE;
#endif
	}
	else
		return FALSE;
	return TRUE;
}

/*******************************************************************************************************
** ��������:  TIM_Stop
** ��������:  ֹͣ��ʱ��
**
** ��        ��:  TIM_TypeDef _TIMx[IN]       ;��ʱ����;
** ��	 ��:  FALSE ����  TRUE
**
** ����  ��:  BR MICRO
** �ա�  ��:
**
********************************************************************************************************/
BOOL TIM_Stop(TIM_TypeDef _TIMx)
{
	if (_TIMx == TIMWGT)
	{
		return FALSE;
	}
	else if((((UINT32)_TIMx)&TIMSMASK) == TIMSMASK)
	{
		return TRUE;
	}
	else if(_TIMx == TIM0)
	{
#if HS_GPT_USE_TIM0
		gptStopTimer(_TIMx);
#else
		return FALSE;
#endif
	}
	else if(_TIMx == TIM1)
	{
#if HS_GPT_USE_TIM1
		gptStopTimer(_TIMx);
#else
		return FALSE;
#endif
	}
	else if(_TIMx == TIM2)
	{
#if HS_GPT_USE_TIM2
		gptStopTimer(_TIMx);
#else
		return FALSE;
#endif
	}
	else
		return FALSE;
	return TRUE;
}

/*******************************************************************************************************
** ��������:  TIM_ClearValue
** ��������:  ��0��ʱ��ֵ
**
** ��        ��:  TIM_TypeDef _TIMx[IN]       ;��ʱ����
** ��	 ��:  FALSE ����  TRUE
**
** ����  ��:  BR MICRO
** �ա�  ��:
**
********************************************************************************************************/
BOOL TIM_ClearValue(TIM_TypeDef _TIMx)
{

	if (_TIMx == TIMWGT)
	{
		return FALSE;
	}
	else if((((UINT32)_TIMx)&TIMSMASK) == TIMSMASK)
	{
		timestamp[TIMSNUM(_TIMx)] = (UINT32)(osalOsGetSystemTimeX());
		return TRUE;
	}
	else if(_TIMx == TIM0)
	{
#if HS_GPT_USE_TIM0
		_TIMx->tim->CNT = 0;
#else
		return FALSE;
#endif
	}
	else if(_TIMx == TIM1)
	{
#if HS_GPT_USE_TIM1
		_TIMx->tim->CNT = 0;
#else
		return FALSE;
#endif
	}
	else if(_TIMx == TIM2)
	{
#if HS_GPT_USE_TIM2
		_TIMx->tim->CNT = 0;
#else
		return FALSE;
#endif
	}
	else
		return FALSE;
	return TRUE;
}

/*******************************************************************************************************
** ��������:  TIM_ClearValue
** ��������:  ��ȡ��ʱ��ֵ
**
** ��        ��:  TIM_TypeDef _TIMx[IN]       ;��ʱ����
** ��	 ��:  ��ʱ��ֵ
**
** ����  ��:  BR MICRO
** �ա�  ��:
**
********************************************************************************************************/
UINT32 TIM_GetValue(TIM_TypeDef _TIMx)
{
	if (_TIMx == TIMWGT)
	{
		return 0;
	}
	else if((((UINT32)_TIMx)&TIMSMASK) == TIMSMASK)
	{
		return (((UINT32)(osalOsGetSystemTimeX())) - timestamp[TIMSNUM(_TIMx)]);
	}
	else
	{
#if TIMXENABLE
		return _TIMx->tim->CNT;
#else
		return 0;
#endif
	}
}

#if HS_GPT_USE_TIM0
static void tim0callback(GPTDriver *gptp)
{

}
#endif

#if HS_GPT_USE_TIM1
static void tim1callback(GPTDriver *gptp)
{

}
#endif

#if HS_GPT_USE_TIM0
static void tim2callback(GPTDriver *gptp)
{

}
#endif
