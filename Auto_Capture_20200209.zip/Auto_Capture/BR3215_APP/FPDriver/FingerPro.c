/*******************************************************************************
**                                                                            **
**      ///////  ///////  ////     //// //////  ////// ///////    /////       **
**      //    // //    // ////    // //   //   //      //    // //     //     **
**      //    // //    // // //  //  //   //   //      //    // //     //     **
**      ///////  ///////  //  ////   //   //   //      ///////  //     //     **
**      //    // //    // //   //    //   //   //      //    // //     //     **
**      //    // //    // //         //   //   //      //    // //     //     **
**      ///////  //    // //         // //////  ////// //    //   /////       **
**                                                                            **
**                       @ Copyright 2012 - 2018                              **
**                          www.brmicro.com.cn                                **
**                                                                            **
*******************************************************************************/


#include <stdint.h>
#include <string.h>
#include "type.h"
#include "FingerPro.h"
#include "SerialFlash.h"
#include "bs201_sensor.h"
#include <bs201/sensor/bs201_bep_fun.h>
#include "BS500.h"
#include "BS510.h"

UINT8  g_abyImageBuf[TOTAL_USE_RAM * 1024 + 8];
UINT8* AlgBuf = NULL;

// int short_off = 0;
// int long_off = 0;
#if !defined(BS510_8MM)
BOOL RawImageGet(UINT8 *_pAlgBuf, unsigned int param)
{
	bs201_tune_param(param);
	if (1)
	{
		if (bs201_capture_whole_image(_pAlgBuf) == 0)
			return TRUE;
	}
	else
	{
		/*
			int i;
			memset(_pAlgBuf, 255, IMAGE_WIDTH * IMAGE_HEIGHT);
			memset(_pAlgBuf, 0, IMAGE_WIDTH);
			memset(_pAlgBuf + (IMAGE_HEIGHT-1)* IMAGE_WIDTH, 0, IMAGE_WIDTH);
			for (i=0; i<IMAGE_HEIGHT; i++)
			{
				_pAlgBuf[IMAGE_WIDTH * i] = 0;
				_pAlgBuf[IMAGE_WIDTH * i + IMAGE_WIDTH - 1] = 0;
			}
			UINT8* blk_buf = _pAlgBuf + IMAGE_WIDTH * IMAGE_HEIGHT;
			if (bs201_capture_block_image(blk_buf, short_off, long_off) == 0)
			{
				for (i=0; i<16; i++)
				{
					memcpy(_pAlgBuf + (short_off + i) * IMAGE_WIDTH + long_off, blk_buf + i * 16, 16);
				}
				long_off += 8;
				if (long_off > IMAGE_WIDTH - 16)
				{
					long_off = 0;
					short_off += 8;
					if (short_off > IMAGE_HEIGHT - 16)
					{
						short_off = 0;
					}
				}
				return TRUE;
			}
			return FALSE;
		*/
		int i, j, k;
		memset(_pAlgBuf, 0, IMAGE_WIDTH * IMAGE_HEIGHT);
		UINT8* blk_buf = _pAlgBuf + IMAGE_WIDTH * IMAGE_HEIGHT;

		for (i = 0; i < IMAGE_HEIGHT / 16; i++)
		{
			for (j = 0; j < IMAGE_WIDTH / 16; j++)
			{
				int short_off = i * 16;
				int long_off = j * 16;
				if (bs201_capture_block_image(blk_buf, short_off, long_off) == 0)
				{
					for (k = 0; k < 16; k++)
					{
						memcpy(_pAlgBuf + (short_off + k) * IMAGE_WIDTH + long_off, blk_buf + k * 16, 16);
					}
				}
			}
		}
		return TRUE;
	}

	return FALSE;
}
#endif

UINT32 BlockVar16x16ForBS510(UINT8 * pBlock, UINT32 vImgRawWidth, UINT16* black_block, UINT16* white_block, UINT32 GrayBuffer[256])
{
	UINT32 i, j,n=0;
	INT32 t0, t1;
    UINT32 AverVal = 0;
    UINT32 VarVal= 0;
	for (i = 0; i < 16; i++) {
		for (j = 0; j < 16; j++) {
			AverVal += pBlock[i * vImgRawWidth + j];
			t1 = pBlock[i * vImgRawWidth + j];
			GrayBuffer[t1]++;
		}
	}


	AverVal /= 16 * 16;
	t0 = AverVal;
//	test_print2("AverVal=%d\n",AverVal);
	if(AverVal<120)
    {
		VarVal = 0;
		n++;
		for (i = 0; i < 16; i++) {
			for (j = 0; j < 16; j++) {
				t1 = pBlock[i * vImgRawWidth + j];
			}
		}

    	for (i = 0; i < 16; i++) {
    		for (j = 0; j < 16; j++) {
    			t1 = pBlock[i * vImgRawWidth + j];
    			if(t1 > t0)
    			{
    	 			t1 = (t1 - t0) * (t1 - t0);
    			}
    			else
    			{
    	 			t1 = (t0 - t1) * (t0 - t1);
    			}
//     			t1 = (t1 - t0) * (t1 - t0);
    			VarVal += t1;
    		}
    	}
    	VarVal /= 16 * 16;
//    	test_print2("VarVal=%d ^^AverVal=%d\n",VarVal,AverVal);
    	if(VarVal<1700)
    	{
    		(*black_block)++;
    	}
//    	else
//    	{
//    		n++;
//    	}

    }
	else
	{
    	VarVal = 0;
    	for (i = 0; i < 16; i++) {
    		for (j = 0; j < 16; j++) {
    			t1 = pBlock[i * vImgRawWidth + j];
    			if(t1 > t0)
    			{
    	 			t1 = (t1 - t0) * (t1 - t0);
    			}
    			else
    			{
    	 			t1 = (t0 - t1) * (t0 - t1);
    			}
    			VarVal += t1;
    		}
    	}
    	VarVal /= 16 * 16;
//    	test_print2("22222VarVal=%d ^^AverVal=%d\n",VarVal,AverVal);
    	if(VarVal > 20) {
//        	test_print("VarVal=%d ^^AverVal=%d\n",VarVal,AverVal);
    		n++;
    		if(AverVal > 240)
    			(*white_block)++;
//    		for (i = 0; i < 16; i++) {
//    			for (j = 0; j < 16; j++) {
//    				t1 = pBlock[i * vImgRawWidth + j];
//    			}
//    	    }
    	}
    	if(VarVal <60 && AverVal < 180)
    	{
//    		test_print("VarVal = %d_____AverVal = %d\n", VarVal, AverVal);
    		(*black_block)++;
    	}
    }
return n;
}

UINT8 DetectFingerForBS510(UINT8 *_pAlgBuf, UINT32 vImgRawWidth, UINT32 vImgRawHeight,UINT8 *pAdjustLevel)
{
	UINT32 n=0;
	UINT16 TmpWhiteBlock = 0;
	UINT16 TmpBlackBlock = 0;
	UINT32 i, j;
	UINT16 black_block;
	UINT16 white_block;
	UINT32 GrayBuffer[256] = { 0 };

	memset(GrayBuffer,0,256*4);
	//print("***********************************\n");
	for (i = 0; i < vImgRawHeight; i += 16) {
		for (j = 0; j < vImgRawWidth; j += 16) {
			n +=BlockVar16x16ForBS510(_pAlgBuf + i * vImgRawWidth + j, vImgRawWidth, &black_block, &white_block, GrayBuffer);
		}
	}

	//test_print("n = %d\n", n);
	//test_print("black_block = %d\n", black_block);
	//test_print("white_block = %d\n", white_block);

	TmpBlackBlock =	black_block;
	TmpWhiteBlock = white_block;
	black_block = 0;
	white_block = 0;

	*pAdjustLevel = 0;

//	return	NORMAL_FINGER;
//	return WET_FINGER;
//	if(n < NORMAL_FNGR_THRESHOLE && (TmpWhiteBlock <= DRY_BLOCK_THRESHOLD &&  TmpBlackBlock <= WET_BLOCK_THRESHOLD))
//		return NO_FINGER;

	if(n < NORMAL_FNGR_THRESHOLE && (TmpWhiteBlock <= DRY_BLOCK_THRESHOLD))
		return NO_FINGER;

//	if(n < NORMAL_FNGR_THRESHOLE )
//		return NO_FINGER;

	if(TmpBlackBlock > WET_BLOCK_THRESHOLD)
	{
		*pAdjustLevel = TmpBlackBlock/(WET_BLOCK_THRESHOLD*2);
		return WET_FINGER;
	}
//
//
	if(TmpWhiteBlock > DRY_BLOCK_THRESHOLD && n < (NORMAL_FNGR_THRESHOLE+15))
	{
		*pAdjustLevel = TmpWhiteBlock/(DRY_BLOCK_THRESHOLD*2);
		return DRY_FINGER;
	}


//	if(TmpWhiteBlock > DRY_BLOCK_THRESHOLD)
//		return DRY_FINGER;


	return	NORMAL_FINGER;


}

#define WET_CHARGE_INIT_VALUE	0x40 //ע�⣺min:0x40,
#define DRY_CHARGE_INIT_VALUE	0x80 //ע�⣺min:0x80,
#define	CHARGE_INIT_VALUE	DRY_CHARGE_INIT_VALUE  //ע�⣺min:0x40, 0x80     84 02 02
#define OFFSET_INIT_VALUE	0x07
#define WET_GAIN_INIT_VALUE		0x04//�ڶ������
#define DRY_GAIN_INIT_VALUE		0x04//�ڶ������
//#define WET_GAIN_INIT_VALUE		0x01//��һ�����
//#define DRY_GAIN_INIT_VALUE		0x01//��һ�����

#define CHARGE_INTERVAL_VALUE	0x02

#define INITPARA_ARR_NORMAL_ELE	3 //ͼ����������������Ӧ��Ĭ�ϲ�����CHARGE_INIT_VALUE����Ԫ��λ��


AnalogPara_t gInitParaArr[7] = {
		{DRY_CHARGE_INIT_VALUE + CHARGE_INTERVAL_VALUE * 3,  OFFSET_INIT_VALUE, DRY_GAIN_INIT_VALUE},
		{DRY_CHARGE_INIT_VALUE + CHARGE_INTERVAL_VALUE * 2,  OFFSET_INIT_VALUE, DRY_GAIN_INIT_VALUE},
		{DRY_CHARGE_INIT_VALUE + CHARGE_INTERVAL_VALUE * 1,  OFFSET_INIT_VALUE, DRY_GAIN_INIT_VALUE},
		{CHARGE_INIT_VALUE,  OFFSET_INIT_VALUE, DRY_GAIN_INIT_VALUE},
		//		{DRY_CHARGE_INIT_VALUE-CHARGE_INTERVAL_VALUE*1,  OFFSET_INIT_VALUE, DRY_GAIN_INIT_VALUE},
		//		{DRY_CHARGE_INIT_VALUE-CHARGE_INTERVAL_VALUE*2,  OFFSET_INIT_VALUE, DRY_GAIN_INIT_VALUE},
				{WET_CHARGE_INIT_VALUE + CHARGE_INTERVAL_VALUE * 1,  OFFSET_INIT_VALUE, WET_GAIN_INIT_VALUE},
				{WET_CHARGE_INIT_VALUE + CHARGE_INTERVAL_VALUE * 2 + 1,  OFFSET_INIT_VALUE, WET_GAIN_INIT_VALUE},
				{WET_CHARGE_INIT_VALUE + CHARGE_INTERVAL_VALUE * 4,  OFFSET_INIT_VALUE, WET_GAIN_INIT_VALUE},
};

#define BS510_IMGX  160
#define BS510_IMGY  160
#define BS510_ADJUST_TIME	2
BOOL GetFingerFromBS510(UINT8* _pAlgBuf)
{
	UINT8 rt = 0;
	UINT8 i = 0;
	UINT8 j = 0;
	BOOL nRet = FALSE;
	AnalogPara_t TmpInitPara;
	UINT8 TmpAdjustlevel = 0;

	j = INITPARA_ARR_NORMAL_ELE;

	for (i = 0; i < BS510_ADJUST_TIME; i++)
	{
		memcpy(&TmpInitPara, &gInitParaArr[j], sizeof(AnalogPara_t));
		//test_print("i= %d, CapCharge = %x\n", i, TmpInitPara.CapCharge);
		SetCapPara(TmpInitPara);
		nRet = BS510ReadImage(_pAlgBuf, 1, BS510_SLEEP_DIS);
		//	    BS510ReadImage(_pAlgBuf,1,BS510_SLEEP_DIS);
		rt = DetectFingerForBS510(_pAlgBuf, BS510_IMGX, BS510_IMGY, &TmpAdjustlevel);

		if (rt == NO_FINGER)
		{
			nRet = FALSE;
			break;
		}

		if (rt == WET_FINGER)
		{
			if (TmpAdjustlevel > BS510_ADJUST_TIME)
				TmpAdjustlevel = BS510_ADJUST_TIME;
			j += TmpAdjustlevel;
		}
		else if (rt == DRY_FINGER)
		{
			if (TmpAdjustlevel > BS510_ADJUST_TIME)
				TmpAdjustlevel = BS510_ADJUST_TIME;
			j -= TmpAdjustlevel;
		}
		else
		{
			nRet = TRUE;
			break;
		}

	}

	return nRet;
}

BOOL GetFingerFromBS510_0(UINT8* _pAlgBuf)
{
	AnalogPara_t TmpInitPara;

	memcpy(&TmpInitPara, &gInitParaArr[5], sizeof(AnalogPara_t));
	SetCapPara(TmpInitPara);
	return BS510ReadImage(_pAlgBuf, 1, BS510_SLEEP_DIS);
}

#if defined(BS510_8MM)
BOOL RawImageGet(UINT8* _pAlgBuf, unsigned int param)
{
	(void)param;
	return GetFingerFromBS510(_pAlgBuf);
}
#endif
