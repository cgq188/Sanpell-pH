
#include "BS500.h"
#include "GPIO.h"
#include "global.h"
#include "fpspi.h"
#include "BS510.h"
#include "dbgtrace.h"

#define SPI_NUM 			 	1
#define BS510_SPI_FREQ		 	10000000
#define DELAY_TIME()  			_delay_us(20)

/* Reset sensor by MCU GPIO PB1 low voltage */
void ExtRESET(void)
{
	SPI_RST_LOW();
	_delay_us(100);
	SPI_CS_HIGH();
	_delay_us(100);
	SPI_RST_LOW();
}

/* Reset sensor by MCU GPIO PB1 low voltage */
BOOL IDCheck(void)
{
    BOOL RoState = TRUE;
    UINT8 RegLen;
    UINT8 TxData[BS510_REG_MAX_SIZE]={0};
    UINT8 RxData[BS510_REG_MAX_SIZE]={0};
    UINT8 i;

    RegLen = BS510_REG_SIZE(BS510_REG_CHIP_ID);
    
    BS510AccReg(BS510_REG_CHIP_ID,TxData, RxData, RegLen);//

    for(i=0;i<3;i++)
    {
    	//test_print("RxData = %x ", RxData[i]);
    }
    //test_print("RxData=\n",RxData);
    if((RxData[0]!=0xCC)||(RxData[1]!=0x16)||(RxData[2]!=0x01))
    {
        RoState =  FALSE;
    }

    return RoState;
}



UINT8 IrqClr(void)
{   
    UINT8 RegLen;
    UINT8 TxData[BS510_REG_MAX_SIZE]={0};
    UINT8 RxData[BS510_REG_MAX_SIZE]={0};

    RegLen = BS510_REG_SIZE(BS510_REG_RD_INT_CLR);
    
    BS510AccReg(BS510_REG_RD_INT_CLR,TxData, RxData, RegLen);//
    _delay_us(2);
    return RxData[0];
}


void BS510AccReg(UINT8 Addr,UINT8 *Txd, UINT8 *Rxd, UINT8 Len)
{
    UINT8 i=0;
	UINT8 Tmp=0;
    
	SPI_CS_LOW();
	SPI_ReadWriteByte(Addr);
    for(i=0;i<Len;i++)
    {
				Tmp = SPI_ReadWriteByte(*(Txd + i));
			  *(Rxd + i)  = Tmp;
    }
    SPI_CS_HIGH();
    _delay_us(2);
}

void BS510Cmd(BS510_cmd_t cmd)
{
	SPI_CS_LOW();
	SPI_ReadWriteByte(cmd);
	SPI_ReadWriteByte(0x0);
    SPI_CS_HIGH();
}
void BS510ReadBuf(UINT8 *_pBuf)
{
//     UINT8 i = 32;
//     UINT8 tmpData = 0;
    SPI_CS_LOW();
    SPI_ReadWriteByte(BS510_CMD_READ_IMAGE);
    SPI_ReadWriteByte(0x0);
    Fp_SpiRcvByteN(_pBuf, 32);
//     while(i)
//     {
//         tmpData =   SPI_ReadWriteByte(0x00);
//         *(_pBuf++) = tmpData;
//         i--;
//     }
    SPI_CS_HIGH();
}

UINT8 SPI_SendWriteByte(UINT8 byte);
UINT8 SPIWriteByte(UINT8 byte)
{
	UINT8 Data = 0;
    __disable_irq();
	Data = SPI_SendWriteByte(byte);
    __enable_irq();
	return Data;
}


int SPI_ReadWriteByte(UINT8 Data)
{
	UINT8 g_SpiRxData;
    g_SpiRxData = SPIWriteByte(Data);

 	return g_SpiRxData;
}


//UINT8 SPIWriteByte(UINT8 byte)
//{
////    /*!< Loop while DR register in not emplty */
////    while (spi_i2s_flag_get(SPI0, SPI_FLAG_TBE) == RESET)
////        ;
////
////    /*!< Send byte through the SPI0 peripheral */
////    spi_i2s_data_transmit(SPI0, byte);
////
////    /*!< Wait to receive a byte */
////    while (spi_i2s_flag_get(SPI0, SPI_FLAG_RBNE) == RESET)
////    {
////        ;
////    }
////
////    /*!< Return the byte read from the SPI bus */
////    return spi_i2s_data_receive(SPI0);
//
//	UINT8 TmpData = byte;
//
//	Fp_SpiSendByte(&TmpData);
////    SPI_Transceive(&SPID0, &TmpData);
//    return TmpData;
//
//}

void LowClkOpen(lowclk_freq_t LowClk_Sel )
{
    UINT8 RegLen;
    UINT8 TxData[BS510_REG_MAX_SIZE]={0};
    UINT8 RxData[BS510_REG_MAX_SIZE]={0};

    RegLen = BS510_REG_SIZE(BS510_REG_CLK_CTRL);
    TxData[0] = (LowClk_Sel<<5) ;

    BS510AccReg(BS510_REG_CLK_CTRL,TxData, RxData, RegLen);//
    TxData[0] = (0x1<<4)  | (LowClk_Sel<<5);
    BS510AccReg(BS510_REG_CLK_CTRL,TxData, RxData, RegLen);//
    _delay_us(200);
}


void LowClkClose(void)
{
    UINT8 RegLen;
    UINT8 TxData[BS510_REG_MAX_SIZE]={0};
    UINT8 RxData[BS510_REG_MAX_SIZE]={0};

    RegLen = BS510_REG_SIZE(BS510_REG_CLK_CTRL);
    TxData[0] = 0 ;
    BS510AccReg(BS510_REG_CLK_CTRL,TxData, RxData, RegLen);//
    _delay_us(100);
}




void SysClkOpen(lowclk_freq_t LowClk_Sel ,sysclk_freq_t SysClk_Sel)
{
    UINT8 RegLen;
    UINT8 TxData[BS510_REG_MAX_SIZE]={0};
    UINT8 RxData[BS510_REG_MAX_SIZE]={0};

    RegLen = BS510_REG_SIZE(BS510_REG_CLK_CTRL);
    TxData[0] = (0x1<<4)  | (LowClk_Sel<<5);
    BS510AccReg(BS510_REG_CLK_CTRL,TxData, RxData, RegLen);//

    TxData[0] = TxData[0]  | SysClk_Sel | (0x1<<2)  ;
    BS510AccReg(BS510_REG_CLK_CTRL,TxData, RxData, RegLen);//
    _delay_us(30);
}

void SysClkClose(lowclk_freq_t LowClk_Sel, sysclk_freq_t SysClk_Sel)
{
    UINT8 RegLen;
    UINT8 TxData[BS510_REG_MAX_SIZE]={0};
    UINT8 RxData[BS510_REG_MAX_SIZE]={0};

    RegLen = BS510_REG_SIZE(BS510_REG_CLK_CTRL);
    TxData[0] = (0x1 << 4)  | (LowClk_Sel << 5) |SysClk_Sel;

    BS510AccReg(BS510_REG_CLK_CTRL,TxData, RxData, RegLen);//
    _delay_us(10);
}



void AnalogPowerOpen(void)
{
    UINT8 RegLen;
    UINT8 TxData[BS510_REG_MAX_SIZE]={0};
    UINT8 RxData[BS510_REG_MAX_SIZE]={0};

    RegLen = BS510_REG_SIZE(BS510_REG_POWER_CTRL);

    TxData[0] = 0x1;
    BS510AccReg(BS510_REG_POWER_CTRL,TxData, RxData, RegLen);//
    _delay_us(300);
}

void AnalogPowerClose(void)
{
    UINT8 RegLen;
    UINT8 TxData[BS510_REG_MAX_SIZE]={0};
    UINT8 RxData[BS510_REG_MAX_SIZE]={0};

    RegLen = BS510_REG_SIZE(BS510_REG_POWER_CTRL);

    TxData[0] = 0x0;
    BS510AccReg(BS510_REG_POWER_CTRL,TxData, RxData, RegLen);//
    //DelayUs(20);
}

BOOL SetCapWindow(CaptureSize_t capsize)
{
    UINT8 RegLen;
    UINT8 TxData[BS510_REG_MAX_SIZE]={0};
    UINT8 RxData[BS510_REG_MAX_SIZE]={0};

    RegLen = BS510_REG_SIZE(BS510_REG_CAP_COL_SIZE);

    TxData[0] = capsize.StartCol;
    TxData[1] = capsize.StopCol;
    BS510AccReg(BS510_REG_CAP_COL_SIZE,TxData, RxData, RegLen);//
//    test_print("00Len_0 = %d, len_1 = %d\n", RxData[0], RxData[1]);


    RegLen = BS510_REG_SIZE(BS510_REG_CAP_ROW_SIZE);

    TxData[0] = capsize.StartRow;
    TxData[1] = capsize.StopRow;
    BS510AccReg(BS510_REG_CAP_ROW_SIZE,TxData, RxData, RegLen);//


//    TxData[0] = 0;
//    TxData[1] = 0;
//    BS510AccReg(BS510_REG_CAP_COL_SIZE,TxData, RxData, RegLen);//
//    test_print("0Len_0 = %d, len_1 = %d\n", RxData[0], RxData[1]);

//    TxData[0] = 0;
//    TxData[1] = 0;
//    BS510AccReg(BS510_REG_CAP_ROW_SIZE,TxData, RxData, RegLen);//
//    test_print("2Len_0 = %d, len_1 = %d\n", RxData[0], RxData[1]);


    return TRUE;
}


BOOL SetCapPara(AnalogPara_t para)
{
    UINT8 RegLen;
    UINT8 TxData[BS510_REG_MAX_SIZE]={0};
    UINT8 RxData[BS510_REG_MAX_SIZE]={0};

    RegLen = BS510_REG_SIZE(BS510_REG_ANA_PARA2);

    TxData[0] = para.CapCharge;
    TxData[1] = para.CapOffset;
    TxData[2] = para.CapGain  ;
    BS510AccReg(BS510_REG_ANA_PARA2,TxData, RxData, RegLen);//

    return TRUE;
}


BOOL SetCapTiming(TimingPara_t para)
{
    UINT8 RegLen;
    UINT8 TxData[BS510_REG_MAX_SIZE]={0};
    UINT8 RxData[BS510_REG_MAX_SIZE]={0};

    RegLen = BS510_REG_SIZE(BS510_REG_CAP_TIMING);

    TxData[0] = para.CapResetWidth;
    TxData[1] = para.CapChargeWidth;
    TxData[2] = para.CapPeriodWidth;
    BS510AccReg(BS510_REG_CAP_TIMING,TxData, RxData, RegLen);//

    return TRUE;
}

BOOL SetCapParaBack(void)
{
    UINT8 RegLen;
    UINT8 TxData[BS510_REG_MAX_SIZE]={0};
    UINT8 RxData[BS510_REG_MAX_SIZE]={0};

    RegLen = BS510_REG_SIZE(BS510_REG_ANA_PARA3);

    BS510AccReg(BS510_REG_ANA_PARA3,TxData, RxData, RegLen);//

    return TRUE;
}

BOOL SetWaitTime(WaitTime_t para)
{
    UINT8 RegLen;
    UINT8 TxData[BS510_REG_MAX_SIZE] = {0};
    UINT8 RxData[BS510_REG_MAX_SIZE] = {0};

    RegLen = BS510_REG_SIZE(BS510_REG_WAIT_CNTR);

    TxData[0] = para.FingerWaitTime;
    TxData[1] = para.CapWaitTime;
    BS510AccReg(BS510_REG_WAIT_CNTR, TxData, RxData, RegLen); //
    return TRUE;
}


BOOL ReadSensorState(UINT8      *state)
{
    UINT8 RegLen;
    UINT8 TxData[BS510_REG_MAX_SIZE]={0};
    UINT8 RxData[BS510_REG_MAX_SIZE]={0};

    RegLen = BS510_REG_SIZE(BS510_REG_SENSOR_ST);

    BS510AccReg(BS510_REG_SENSOR_ST,TxData, RxData, RegLen);//
    *state = RxData[0];
    *(state+1)=RxData[1];
    return TRUE;
}

UINT8 ReadBufferState(void)
{
    UINT8 RegLen;
    UINT8 TxData[BS510_REG_MAX_SIZE]={0};
    UINT8 RxData[BS510_REG_MAX_SIZE]={0};

    RegLen = BS510_REG_SIZE(BS510_REG_BUFFER_ST);

    BS510AccReg(BS510_REG_BUFFER_ST,TxData, RxData, RegLen);//
 
    return RxData[0];
}

UINT8 ReadFingerState(void)
{
    UINT8 RegLen;
    UINT8 TxData[BS510_REG_MAX_SIZE] = {0};
    UINT8 RxData[BS510_REG_MAX_SIZE] = {0};

    RegLen = BS510_REG_SIZE(BS510_REG_FINGER_ST);

    BS510AccReg(BS510_REG_FINGER_ST, TxData, RxData, RegLen);

    return RxData[0] & 0x1 ;
}

void SensorTest(UINT8      Txd)
{
    UINT8 RegLen;
    UINT8 TxData[BS510_REG_MAX_SIZE]={0};
    UINT8 RxData[BS510_REG_MAX_SIZE]={0};

    RegLen = BS510_REG_SIZE(BS510_REG_DIG_TST1);
    TxData[0] = Txd;
    BS510AccReg(BS510_REG_DIG_TST1,TxData, RxData, RegLen);//
    
    
}

void SensorBezel(void)
{
    UINT8 RegLen;
    UINT8 TxData[BS510_REG_MAX_SIZE] = {0};
    UINT8 RxData[BS510_REG_MAX_SIZE] = {0};

    RegLen = BS510_REG_SIZE(BS510_REG_DIG_TST);
    TxData[0] = 0x2;
    BS510AccReg(BS510_REG_DIG_TST, TxData, RxData, RegLen); //

    RegLen = BS510_REG_SIZE(BS510_REG_ANA_PARA1);
    TxData[0] = 0xB;//'b1011
//    TxData[0] = 0xF;//'b1111
    BS510AccReg(BS510_REG_ANA_PARA1, TxData, RxData, RegLen); //

    RegLen = BS510_REG_SIZE(BS510_REG_FING_SUM_TH);
    TxData[0] = 0x0;
    TxData[1] = 0x50;
    BS510AccReg(BS510_REG_FING_SUM_TH, TxData, RxData, RegLen); //


    RegLen = BS510_REG_SIZE(BS510_REG_FING_MODE_SEL);
    TxData[0] = 0x11;
    BS510AccReg(BS510_REG_FING_MODE_SEL, TxData, RxData, RegLen); //

}

static void BS510_IO_Init(void)
{
	SPI_CS_OUTPUT();

	SPI_CS_HIGH();
	Fp_Spi_Init();
//	SPI_Init(SPI_NUM,MASTER,SPI_MODE0,SPI_MSB,0x08,BS510_SPI_FREQ);
	SPI_RST_OUTPUT();
	SPI_RST_LOW();
//	_delay_us(100);
//	RST_DATA_1();
//	_delay_us(100);
//	RST_DATA_0();
//	_delay_us(100);
}

UINT8 BS510_calibrate_OK = 0;
extern UINT8 *AlgBuf;
BOOL BS510_Init(void)
{
	BOOL ASFSensorInitOK = FALSE;
	UINT8 FingerON=0;
//	UINT8 Img[160 * 160] = {0};  //use the maximum X/Y in all sensors

	BS510_IO_Init();
	ASFSensorInitOK = BS510SensorInit(&FingerON);
	//test_print("ASFSensorInitOK = %d\n",ASFSensorInitOK);
    if(TRUE==ASFSensorInitOK)
    {

        if(FingerON)
        {
        	BS510ReadImage(AlgBuf,1,BS510_SLEEP_DIS);
        }
        else
        {
        	BS510InitCfg(BS510_SLEEP_DIS);
        }
//        else
//        {
//
//        	if(BS510InitCfg(BS510_SLEEP_DIS) == FALSE)
//        	{
//        		BS_RD_Flash(&BS510_calibrate_OK, BS510_CALUBRATE_FLAG_OFFSET, sizeof(char));
//        		if(BS510_calibrate_OK == (UINT8)(~CALIBARTE_FLASH_FLAG))
//        		{
//        			return FALSE;
//        		}
//        		else
//        		{
//        			BS510_calibrate_OK = (UINT8)(~CALIBARTE_FLASH_FLAG);
//        			BS_WR_Flash(&BS510_calibrate_OK, BS510_CALUBRATE_FLAG_OFFSET, sizeof(char));
//        			return FALSE;
//        		}
//        	}
//        }
    }
	else
	{
		return FALSE;
	}

	return TRUE;
}

BOOL BS510SensorInit(UINT8 *FingerStatus)
{
    BOOL RoState;
    UINT8 IntStatus;

    //Check The ID
    RoState = IDCheck();
    //test_print("RoState = %d\n",RoState);
    if (RoState == FALSE)
    {
        return FALSE;
    }
    //Read The Finger Status
    *FingerStatus = ReadFingerState();

    IntStatus = IrqClr();
    (void)IntStatus;
    _delay_us(100);
    return RoState;
}

BOOL BS510InitCfg(Sleep_Ctrl_t SLEEP)
{
    UINT8 IntStatus;
    UINT8 SensorState[2] = {0};

    _delay_us(100);
    IntStatus = IrqClr();
    ExtRESET();
    _delay_us(100);
    IntStatus = IrqClr();
	(void)IntStatus;

    //Open The Low Clock
    LowClkOpen(BS510_LOWCLK_8K);
    SysClkOpen(BS510_LOWCLK_8K, BS510_SYSCLK_16M);

    //
    //Check the sensor in PAUSE Mode
    //

    ReadSensorState(SensorState);

    SensorTest(3);
    SensorBezel();

    BS510PowerOn(SLEEP);
    SysClkClose(BS510_LOWCLK_8K,BS510_SYSCLK_16M);
    return TRUE;
}

/* config sensor parameters */
void BS510PowerOn(Sleep_Ctrl_t SLEEP)
{
    UINT8 RegLen;
    UINT8 TxData[BS510_REG_MAX_SIZE] = {0};
    UINT8 RxData[BS510_REG_MAX_SIZE] = {0};

    AnalogPara_t InitPara;
    
    //
    //���ݺ��Ԥ���趨��ֵ Ϊ�����������ȣ�����Ҫ��Gain �Ŵ�һ�㡣
    //
    InitPara.CapCharge = INICHARGEVAL;
    InitPara.CapOffset = INIOFFSETVAL;
    InitPara.CapGain   = INIGAINVAL;
    //Write the Data;
    SetCapPara(InitPara);
    //for Test
    //SetCapParaBack();


    TimingPara_t InitTiming;
    InitTiming.CapResetWidth  = 0x0C;
    InitTiming.CapChargeWidth = 0x0E;
    InitTiming.CapPeriodWidth = 0x15;

//    InitTiming.CapResetWidth  = 0x09;
//    InitTiming.CapChargeWidth = 0x0B;
//    InitTiming.CapPeriodWidth = 0x0F;
//freqency(sys_clk)/(pireod+1)
    SetCapTiming(InitTiming);
    
    WaitTime_t InitWait;

    InitWait.FingerWaitTime = 30;//50*5.16ms
    InitWait.CapWaitTime    = 5 ;//Capture wait time����������õ�31
    SetWaitTime(InitWait);


    if (SLEEP == BS510_SLEEP_EN)
    {

        //Set the Finger Detect Mode Select Registers
        RegLen = BS510_REG_SIZE(BS510_REG_FING_MODE_SEL);
        TxData[0] = 0x11;
        BS510AccReg(BS510_REG_FING_MODE_SEL, TxData, RxData, RegLen); //
        BS510SleepCmd();
    }

    _delay_us(100);
}

void BS510SleepCmd(void)
{

    //Set The Capture Size
    CaptureSize_t Capsize;
    Capsize.StartCol  = 72;
    Capsize.StartRow  = 72;
    Capsize.StopCol   = 79;
    Capsize.StopRow   = 79;
    SetCapWindow(Capsize);

    AnalogPara_t InitPara;

    
    //
    //���ݺ��Ԥ���趨��ֵ Ϊ�����������ȣ�����Ҫ��Gain �Ŵ�һ�㡣
    //
    InitPara.CapCharge = 0x41;
    InitPara.CapOffset = 0x07;
    InitPara.CapGain   = 0x06;
    //Write the Data;
    SetCapPara(InitPara);
    //Set the Sleep Command
    BS510Cmd(BS510_CMD_SLEEP);
}
/*
BOOL BS510SleepCapture(UINT8 *ImgBuff)
{
    BOOL RoState = FALSE;
    UINT8 SensorState[2] = {0};

    //
    //Sleep Mode To Pause Mode Cmd
    BS510Cmd(BS510_CMD_SLEEP2PAUSE);

    //
    //Check the sensor in PAUSE Mode
//    test_print("4321\n");
    ReadSensorState(SensorState);
    test_print("SensorState[1] = %x \n",SensorState[1]);
    while ((SensorState[1] & 0x8) != 0x8)
    {
        _delay_ms(1);
        ReadSensorState(SensorState);
    }
//    test_print("aaa\n");
    RoState= BS510ParaAdjust();
    test_print("RoState_Adjust=%d\n",RoState);

    //Now Can Capture The Picture
    RoState = BS510ReadImage(ImgBuff);

    //Set the Sleep Command
    BS510SleepCmd();
    return RoState;

}
*/
BOOL CapBlkImage(uint8_t *ImgBuff, CaptureSize_t Size, AnalogPara_t Para, uint8_t *result, uint8_t adjust)
{
    BOOL RoState = FALSE;


    uint8_t  colsize = (Size.StopCol - Size.StartCol + 1);
    uint8_t  rowsize = (Size.StopRow - Size.StartRow + 1);
    uint16_t imgBuffSize = colsize * rowsize;

    uint16_t i;
    SetCapWindow(Size);
    SetCapPara(Para);

    RoState = CaptureImage(ImgBuff, imgBuffSize);

    if (RoState == FALSE)
    {
        return RoState;
    }

    //
    uint32_t sum_val_used = 0;
    //uint8_t  avg_val = 0;
    for (i = 0; i < imgBuffSize; i++)
    {
        sum_val_used += ImgBuff[i];
    }

    uint8_t    AvgVal = 0;
    AvgVal = sum_val_used >> BLK_BIT_SIZE;
    if (adjust == 1)
    {

        if (AvgVal < 0x30)
        {
            Para.CapGain--;
            Para.CapCharge = Para.CapCharge + 1;
        }
        else if ((AvgVal >= 0x30) && (AvgVal < 0x40))
        {
            Para.CapCharge = Para.CapCharge + 2;
        }
        else if ((AvgVal >= 0x40) && (AvgVal < 0x60))
        {
            Para.CapCharge = Para.CapCharge + 1;
        }
        else if ((AvgVal >= 0x60) && (AvgVal < 0x70))
        {
            Para.CapCharge = Para.CapCharge ;
        }
        else if ((AvgVal >= 0x70) && (AvgVal < 0xA0))
        {
            Para.CapCharge = Para.CapCharge;
        }
        else if ((AvgVal >= 0xA0) && (AvgVal < 0xC0))
        {
            Para.CapCharge = Para.CapCharge - 1;
        }
        else
        {
            Para.CapGain++;
            Para.CapCharge = Para.CapCharge - 1;
        }
        SetCapPara(Para);
    }
    *result = AvgVal;
    return RoState;
}
#if 0
BOOL CaptureImageNoData(void)
{
    //uint8_t BufferState = 0;
    uint8_t SensorState[2] = {0};
    //WORD i = 0, k = 0;
    WORD ReadCnt = 0;

    uint8_t RegLen;
    uint8_t TxData[BS510_REG_MAX_SIZE] = {0};
    uint8_t RxData[BS510_REG_MAX_SIZE] = {0};

    RegLen = BS510_REG_SIZE(BS510_REG_DIG_TST);
    TxData[0] = 0x2 | 0x0c;
    BS510AccReg(BS510_REG_DIG_TST, TxData, RxData, RegLen); //



    //
    //If the Sensor is in Sleep Mode(Finger detect mode)
    //Sensor need go to Pause state




    ReadSensorState(SensorState);
    if ((SensorState[1] & 0x1) != 0x1)
    {
        //Sleep Mode To Pause Mode Cmd
        BS510Cmd(BS510_CMD_SLEEP2PAUSE);
        ReadSensorState(SensorState);
        //Check the sensor in PAUSE Mode
        while ((SensorState[1] & 0x8) != 0x8)
        {
            DelayMs(1, FALSE);
            ReadSensorState(SensorState);
        }
    }

    BS510Cmd(BS510_CMD_CAPTURE_IMAGE);
    DelayUs(500);
    //SensorTest(21);
    //BufferState = ReadBufferState();
    //ReadSensorState(SensorState);
    /*
    ReadCnt = BufSize / 32;
    i = 0;
    while (i < ReadCnt)
    {
        BufferState = ReadBufferState();
        while (((BufferState & 0x1) == 0x0) && ((BufferState & 0x4) == 0x0))
        {
            DelayUs(1);
            BufferState = ReadBufferState();
        }
        BS510ReadBuf(&ImgBuff[i * 32]);
        if (i < 3)
        {
            DelayUs(200);
        }
        i++;

    }

    //
    BufferState = ReadBufferState();
    if (((BufferState & 0x2) == 0x0) || ((BufferState & 0x8) == 0x0))
    {
        return FALSE;
    }
    */
    ReadCnt = 0;
    //check the Sensor States
    ReadSensorState(SensorState);
    while ((SensorState[0] & 0x1) != 0x1)
    {
        DelayUs(500);
        ReadCnt++;
        ReadSensorState(SensorState);
        return FALSE;
        if (ReadCnt >= 200)
        {
            return FALSE;
        }
    }



    RegLen = BS510_REG_SIZE(BS510_REG_DIG_TST);
    TxData[0] = 0x2 ;
    BS510AccReg(BS510_REG_DIG_TST, TxData, RxData, RegLen); //

    //
    //uint32_t sum_val_used = 0;
    //uint8_t  avg_val = 0;
    /*
    for (i = 0; i < BufSize; i++)
    {
        sum_val_used += ImgBuff[i];
    }
    *sum_val = sum_val_used;*/
    return TRUE;
}

#endif

BOOL BS510ParaAdjust(uint8_t *ImgBuff)
{
    BOOL RoState = FALSE;

    uint8_t  LoopCnt = 0;

    CaptureSize_t CapZone;
    AnalogPara_t    InitPara;

    uint8_t    AvgVal = 0;
    //
    //���ݺ��Ԥ���趨��ֵ
    //
    InitPara.CapCharge = INICHARGEVAL;
    InitPara.CapOffset = INIOFFSETVAL;
    InitPara.CapGain   = INIGAINVAL;
    /*
    CapZone.StartCol = 48  ;
    CapZone.StopCol  = 63  ;
    CapZone.StartRow = 48  ;
    CapZone.StopRow  = 63  ;
    CapBlkImage(ImgBuff, CapZone, InitPara, &BlkVal[0]);

    CapZone.StartCol = 96  ;
    CapZone.StopCol  = 111 ;
    CapZone.StartRow = 48  ;
    CapZone.StopRow  = 63  ;
    CapBlkImage(ImgBuff, CapZone, InitPara, &BlkVal[1]);

    CapZone.StartCol = 48  ;
    CapZone.StopCol  = 63  ;
    CapZone.StartRow = 96  ;
    CapZone.StopRow  = 111 ;
    CapBlkImage(ImgBuff, CapZone, InitPara, &BlkVal[2]);

    CapZone.StartCol = 96  ;
    CapZone.StopCol  = 111 ;
    CapZone.StartRow = 96  ;
    CapZone.StopRow  = 111 ;
    CapBlkImage(ImgBuff, CapZone, InitPara, &BlkVal[3]);
     */
    CapZone.StartCol = (80 - (BLK_X_WIDTH / 2));
    CapZone.StopCol  = (80 + (BLK_X_WIDTH / 2) - 1);
    CapZone.StartRow = (80 - (BLK_Y_WIDTH / 2));
    CapZone.StopRow  = (80 + (BLK_Y_WIDTH / 2) - 1);
    /*
    SetCapWindow(CapZone);
    SetCapPara(InitPara);
    RoState = CaptureImageNoData();
    DelayUs(500);
    */
    while ((LoopCnt++) <= 5)
    {
        CapBlkImage(ImgBuff, CapZone, InitPara, &AvgVal, 1);
        _delay_us(20);
        if ((AvgVal >= 0x70) && (AvgVal < 0x90))
            break;
    }
    /*
    CapBlkImage(ImgBuff, CapZone, InitPara, &SumVal,1);
    if ((SumVal <= 0x20) || (SumVal >= 0xD8))
    {
        CapBlkImage(ImgBuff, CapZone, InitPara, &SumVal,1);
    }*/

#if 0
    //Valid Pix Average

    for (i = 0; i < 4; i++)
    {
        vldblksum = 0;
        if (BlkVal[i].BlkValidPixNum > 100)
        {
            vldblkcnt ++ ;
            vldblksum += BlkVal[i].BlkAllPixMean;
        }
    }
    vldblkmean = vldblksum / vldblkcnt;

    if (vldblkcnt >= 2)
    {
        RoState = TRUE;
        if (vldblkmean < 0x20)
        {
            //InitPara.CapGain--;
            InitPara.CapCharge = InitPara.CapCharge  + 3;
        }
        else if (vldblkmean < 0x40)
        {
            InitPara.CapCharge = InitPara.CapCharge  + 2;
        }
        else if (vldblkmean < 0x60)
        {
            InitPara.CapCharge = InitPara.CapCharge  + 1;
        }
        else if (vldblkmean < 0xA0)
        {
            InitPara.CapCharge = InitPara.CapCharge ;
        }
        else if (vldblkmean < 0xC0)
        {
            InitPara.CapCharge = InitPara.CapCharge - 1;
        }
        else if (vldblkmean < 0xE0)
        {
            InitPara.CapCharge = InitPara.CapCharge - 2;
        }
        SetCapPara(InitPara);
    }
#endif

    return RoState;
}

BOOL CaptureImage(UINT8 *ImgBuff, WORD BufSize)
{
    UINT8 BufferState = 0;
    UINT8 SensorState[2]={0};
    WORD i = 0;
    WORD ReadCnt;

    if ((0 == BufSize) || (NULL == ImgBuff))
    {
        return FALSE;
    }
    //SensorTest(15);
    memset(ImgBuff, 0, BufSize);
    //ReadSensorState(SensorState);
    //BufferState = ReadBufferState();

    //
    //If the Sensor is in Sleep Mode(Finger detect mode)
    //Sensor need go to Pause state

    ReadSensorState(SensorState);
    if ((SensorState[1] & 0x1) != 0x1)
    {
        //Sleep Mode To Pause Mode Cmd
        BS510Cmd(BS510_CMD_SLEEP2PAUSE);
        ReadSensorState(SensorState);
        //Check the sensor in PAUSE Mode
        while ((SensorState[1] & 0x8) != 0x8)
        {
        	_delay_ms(1);
            ReadSensorState(SensorState);
        }
    }

    BS510Cmd(BS510_CMD_CAPTURE_IMAGE);
    _delay_ms(2);
    //SensorTest(21);
    //BufferState = ReadBufferState();
    //ReadSensorState(SensorState);

    ReadCnt = BufSize / 32;
//    test_print("ReadCnt =%d\n",ReadCnt);
    i = 0;
//    test_print("SensorState[0] = %x, SensorState[1] = %x \n",SensorState[0], SensorState[1]);
    while (i<ReadCnt)
    {
    	BufferState = ReadBufferState();
//        test_print("BufferState = %d\n",BufferState);
    	  while( ((BufferState & 0x1)==0x0) &&  ((BufferState & 0x4)==0x0))
    	  {
//        	test_print("BufferState1 = %d\n",BufferState);
    	      _delay_us(1);
    	      BufferState = ReadBufferState();
    	  }
    	  BS510ReadBuf(&ImgBuff[i*32]);
    	  if(i<3)
    	  {
    	      _delay_us(400);
    	  }
        i++;
    }

    BufferState = ReadBufferState();
//    test_print("1SensorState[0] = %x, 1SensorState[1] = %x \n",SensorState[0], SensorState[1]);
    if( ((BufferState & 0x2)==0x0) ||  ((BufferState & 0x8)==0x0))
    {
        return FALSE;
    }

    //check the Sensor States
    ReadSensorState(SensorState);
    if ((SensorState[0] & 0x1) != 0x1)
    {
        return FALSE;
    }

    return TRUE;
}


BOOL BS510ReadImage(UINT8 *ImgBuff, UINT8 g_RawMode, Sleep_Ctrl_t SLEEP)
{
    BOOL RoState = FALSE;

    //AnalogPara_t    InitPara;

    WORD imgBuffSize = 160 * 160;

    //Open the analog Power
    AnalogPowerOpen();
    //Open the System Clock
    SysClkOpen(BS510_LOWCLK_8K, BS510_SYSCLK_16M);


    //Now Can finger Detect

    if (!g_RawMode)
    {
        BS510ParaAdjust(ImgBuff);
    }
    else
    {
        //
        //���ݺ��Ԥ���趨ֵ
        //
//        InitPara.CapCharge = INICHARGEVAL;
//        InitPara.CapOffset = INIOFFSETVAL;
//        InitPara.CapGain   = INIGAINVAL;
//
//        SetCapPara(InitPara);
    }

    //
    CaptureSize_t Capsize;
    Capsize.StartCol  =0;
    Capsize.StartRow  =0;
    Capsize.StopCol   =159;
    Capsize.StopRow   =159;
    SetCapWindow(Capsize);

    RoState = CaptureImage(ImgBuff, imgBuffSize);

    if (SLEEP == BS510_SLEEP_EN)
    {

        BS510SleepCmd();
    }

    AnalogPowerClose();

    SysClkClose(BS510_LOWCLK_8K,BS510_SYSCLK_16M);
    return RoState;
}





