
#ifndef __BS510_H__
#define __BS510_H__
//#include "main.h"
#include "stdio.h"
#include "stdint.h"
//#include "gd32f30x.h"
//#include "gd32f30x_spi.h"
#include <string.h>
#include "type.h"


//#define AUTO_OFFSET
///* Exported macro ------------------------------------------------------------*/
///* Select Sensnor: Chip Select pin low */
//#define SPI_CS_LOW() gpio_bit_reset(GPIOA, GPIO_PIN_2)
///* Deselect Sensnor: Chip Select pin high */
//#define SPI_CS_HIGH() gpio_bit_set(GPIOA, GPIO_PIN_2)
///* Exported functions ------------------------------------------------------- */


#define FINGER_DETECT_TEST
#ifdef FINGER_DETECT_TEST
#define TEST_MODE  1
#else
#define TEST_MODE   0
#endif


//------------------------------------------------------------------------------
//Charge Offset Gain
#define INICHARGEVAL 0x46
#define INIOFFSETVAL 0x07
#define INIGAINVAL   0x04

//16x16 Block
#define BLK_X_WIDTH  16
#define BLK_Y_WIDTH  16
#define BLK_BIT_SIZE 8


//------------------------------------------------------------------------------
typedef enum
{
    /* --- registers --- */

    BS510_REG_CAP_TIMING     = 0x08,     /*RW  3Bytes*/
    BS510_REG_CHIP_ID        = 0x0C,     /*RO  3Bytes*/
    BS510_REG_ANA_PARA0      = 0x10,     /*RW  3Bytes*/
    BS510_REG_ANA_PARA1      = 0x14,     /*RW  1Byte */
    BS510_REG_ANA_PARA2      = 0x18,     /*RW  3Bytes*/
    BS510_REG_ANA_PARA3      = 0x1C,     /*RW  3Bytes*/


    BS510_REG_POWER_CTRL     = 0x20,     /*RW  1Byte */
    BS510_REG_CLK_CTRL       = 0x24,     /*RW  1Byte */
    BS510_REG_DIG_TST1       = 0x28,     /*RW  1Byte */
    BS510_REG_DIG_TST        = 0x2C,     /*RW  1Byte */
    BS510_REG_CAP_COL_SIZE   = 0x30,     /*RW  2Bytes*/
    BS510_REG_CAP_ROW_SIZE   = 0x34,     /*RW  2Bytes*/

    BS510_REG_HIST_CTRL      = 0x40,     /*RW  2Bytes*/
    BS510_REG_HIST_RDOUT     = 0x48,     /*RO  2Bytes*/
    BS510_REG_SUM_RDOUT      = 0x4C,     /*RO  2Bytes*/

    BS510_REG_WAIT_CNTR      = 0x50,     /*RW  2Bytes*/
    BS510_REG_TIMEOUT_CNTR   = 0x54,     /*RW  2Bytes*/
    BS510_REG_FING_SUM_TH    = 0x58,     /*RW  2Bytes*/
    BS510_REG_FING_MODE_SEL  = 0x5C,     /*RW  1Byte */

    BS510_REG_FINGER_ST      = 0x60,     /*RO  1Byte */
    BS510_REG_SENSOR_ST      = 0x68,     /*RO  2Bytes*/
    BS510_REG_BUFFER_ST      = 0x6C,     /*RO  1Byte */

    BS510_REG_RD_INT_CLR	    = 0x70 	    /*RO, 1Byte	*/
} BS510_reg_t;


typedef enum
{
    BS510_CMD_READ_IMAGE     = 0x78,	    /*RO, 1Byte Dummy + 32Bytes	*/
    BS510_CMD_READ_HIST      = 0x7C,	    /*RO, 1Byte Dummy + 32Bytes	*/
    BS510_CMD_CAPTURE_IMAGE	= 0x80,	    /*RO, 1Byte	Dummy*/
    BS510_CMD_SLEEP	        = 0x88,	    /*RO, 1Byte	Dummy*/
    BS510_CMD_SLEEP2PAUSE    = 0x90,	    /*RO, 1Byte	Dummy*/
    BS510_CMD_SLEEP2IDLE	    = 0x98 	    /*RO, 1Byte	Dummy*/
} BS510_cmd_t;


#define BS510_REG_MAX_SIZE	3

#define REG_SIZE_BS510_REG_CAP_TIMING 3
#define REG_SIZE_BS510_REG_CHIP_ID 3
#define REG_SIZE_BS510_REG_ANA_PARA0 3
#define REG_SIZE_BS510_REG_ANA_PARA1 1
#define REG_SIZE_BS510_REG_ANA_PARA2 3
#define REG_SIZE_BS510_REG_ANA_PARA3 3

#define REG_SIZE_BS510_REG_POWER_CTRL 1
#define REG_SIZE_BS510_REG_CLK_CTRL 1
#define REG_SIZE_BS510_REG_DIG_TST1 1
#define REG_SIZE_BS510_REG_DIG_TST 1
#define REG_SIZE_BS510_REG_CAP_COL_SIZE 2
#define REG_SIZE_BS510_REG_CAP_ROW_SIZE 2

#define REG_SIZE_BS510_REG_HIST_CTRL 2
#define REG_SIZE_BS510_REG_HIST_RDOUT 2
#define REG_SIZE_BS510_REG_SUM_RDOUT 2

#define REG_SIZE_BS510_REG_WAIT_CNTR 2
#define REG_SIZE_BS510_REG_TIMEOUT_CNTR 2
#define REG_SIZE_BS510_REG_FING_SUM_TH 2
#define REG_SIZE_BS510_REG_FING_MODE_SEL 1

#define REG_SIZE_BS510_REG_FINGER_ST 1
#define REG_SIZE_BS510_REG_SENSOR_ST 2
#define REG_SIZE_BS510_REG_BUFFER_ST 1

#define REG_SIZE_BS510_REG_RD_INT_CLR 1

#define BS510_REG_SIZE(reg) REG_SIZE_##reg

/* -------------------------------------------------------------------- */
/*  	BS510 Sensor Status Register Bit                             */
/* -------------------------------------------------------------------- */

typedef enum {
	BS510_SENSOR_ST_REG_BIT_LOW_IDLE		    = 1 << 0,
    BS510_SENSOR_ST_REG_BIT_SLEEP_WAIT       = 1 << 1,
    BS510_SENSOR_ST_REG_BIT_SLEEP_FINGDET    = 1 << 2,
    BS510_SENSOR_ST_REG_BIT_SLEEP_PAUSE      = 1 << 3,

    BS510_SENSOR_ST_REG_BIT_HIGH_IDLE	    = 1 << 8,
    BS510_SENSOR_ST_REG_BIT_CAP_WAIT         = 1 << 9,
    BS510_SENSOR_ST_REG_BIT_CAP              = 1 << 10,
    BS510_SENSOR_ST_REG_BIT_DET_WAIT         = 1 << 11,
    BS510_SENSOR_ST_REG_BIT_DET              = 1 << 12
} BS510_sensor_st_reg_t;



/* -------------------------------------------------------------------- */
/*  	BS510 Finger Status Register Bit                             */
/* -------------------------------------------------------------------- */

typedef enum {
	BS510_FINGER_ST_REG_BIT_FINGER_FLAG      = 1 << 0, /*  Hist ��ָ���ϱ�־      */
    BS510_FINGER_ST_REG_BIT_SUM_FLAG         = 1 << 4, /*  Sum  ��ָ���ϱ�־      */
    BS510_FINGER_ST_REG_BIT_HIST_FLAG        = 1 << 5  /*  ��ָ���ϱ�־      */
} BS510_finger_st_reg_t;





/* -------------------------------------------------------------------- */
/*  	BS510 Buffer Status Register Bit                             */
/* -------------------------------------------------------------------- */

typedef enum {
	BS510_BUFFER_ST_REG_BIT_BUF0_FULL        = 1 << 0,
	BS510_BUFFER_ST_REG_BIT_BUF0_EMPTY       = 1 << 1,
    BS510_BUFFER_ST_REG_BIT_BUF1_FULL        = 1 << 2,
    BS510_BUFFER_ST_REG_BIT_BUF1_EMPTY       = 1 << 3
} BS510_buffer_st_reg_t;



/* -------------------------------------------------------------------- */
/*  	BS510 Interrupt Register Bit                                 */
/* -------------------------------------------------------------------- */

typedef enum {
	BS510_INT_ST_REG_BIT_RESET_FLAG        = 1 << 0
} BS510_int_st_reg_t;



typedef enum {
	    BS510_SYSCLK_8M        ,
        BS510_SYSCLK_12M       ,
        BS510_SYSCLK_16M       ,
        BS510_SYSCLK_20M
}sysclk_freq_t; 

typedef enum {
	    BS510_LOWCLK_1K        =0 ,
        BS510_LOWCLK_8K        =1
}lowclk_freq_t; 

typedef enum {
	    BS510_SLEEP_DIS        =0 ,
        BS510_SLEEP_EN         =1
}Sleep_Ctrl_t; 


typedef  struct {
        
        uint8_t CapCharge;
        uint8_t CapOffset;
        uint8_t CapGain  ;
}AnalogPara_t; 

typedef  struct {
        
        uint8_t CapResetWidth;
        uint8_t CapChargeWidth;
        uint8_t CapPeriodWidth;
}TimingPara_t; 


typedef  struct {
        
        uint8_t StartCol;
        uint8_t StopCol;
        uint8_t StartRow  ;
        uint8_t StopRow  ;
}CaptureSize_t; 

typedef  struct {
        
        uint8_t FingerWaitTime;
        uint8_t CapWaitTime   ;
}WaitTime_t;

typedef  struct {
        
        uint16_t BlkValidPixNum;
        uint8_t  BlkValidPixMean;
        uint8_t  BlkAllPixMean;
        uint32_t BlkAllPixVar;
}BlkResult_t;

void ExtRESET(void);
BOOL IDCheck(void);
uint8_t IrqClr(void);

void BS510AccReg(uint8_t Addr,uint8_t *Txd, uint8_t *Rxd, uint8_t Len);
void BS510Cmd(BS510_cmd_t cmd);
void BS510ReadBuf(uint8_t *_pBuf);


//uint8_t SPIWriteByte(uint8_t byte);

void LowClkOpen(lowclk_freq_t LowClk_Sel );
void LowClkClose(void);
void SysClkOpen(lowclk_freq_t LowClk_Sel, sysclk_freq_t SysClk_Sel);
void SysClkClose(lowclk_freq_t LowClk_Sel, sysclk_freq_t SysClk_Sel);
void AnalogPowerOpen(void);
void AnalogPowerClose(void);


BOOL SetCapWindow(CaptureSize_t capsize);

BOOL SetCapPara(AnalogPara_t para);

uint8_t ReadFingerState(void);

BOOL ReadSensorState(uint8_t      *state);
uint8_t ReadBufferState(void);

void SensorTest(uint8_t     Txd);



BOOL BS510SensorInit(uint8_t *FingerStatus);

BOOL BS510InitCfg(Sleep_Ctrl_t SLEEP);

void BS510PowerOn(Sleep_Ctrl_t SLEEP);

void BS510SleepCmd(void);

//BOOL BS510SleepCapture(uint8_t *ImgBuff);

BOOL BS510ParaAdjust(uint8_t *ImgBuff);

BOOL BS510_Init(void);

BOOL CapBlkImage(uint8_t *ImgBuff, CaptureSize_t Size, AnalogPara_t Para, uint8_t *result, uint8_t adjust);


BOOL CaptureImage(uint8_t *ImgBuff, WORD BufSize);

BOOL BS510ReadImage(uint8_t *ImgBuff,uint8_t g_RawMode,Sleep_Ctrl_t SLEEP);

UINT8 SPIWriteByte(UINT8 byte);
int SPI_ReadWriteByte(uint8_t Data);
int SPI_RecvByte(uint8_t *pData);
//BOOL BS510_SpiSendByte(UINT8 Data);
//
//BOOL BS510_SpiRcvByte(UINT8 *pData);
//
//UINT8 SPISendByte(UINT8 byte);
//UINT8 SPIWriteByte(UINT8 CMD);
#endif /* __BS510_REGS_H */

