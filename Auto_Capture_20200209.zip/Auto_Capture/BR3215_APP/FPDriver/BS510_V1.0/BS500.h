/*
 * BS500.h
 *
 *  Created on: 2017-5-10
 *      Author: Tao
 */

#ifndef BS500_H_
#define BS500_H_


#include "global.h"
//#include "BS600_drv.h"
#include "cType.h"

#define  DUMMY_BYTE		0x66

//#define  PX1  96
//#define  PX2  112

#define  PX1  160
#define  PX2  160
//typedef enum {BUSY = 0, READY = !BUSY} Status;


#define REG_STOP_COLUMN  0x0a
#define REG_STOP_LINE    0x0f


#define REG_MCR		0x00
#define REG_ACTR	0x03
#define REG_ANAR	0x14


//-----------------------------------------------------
#define  CMD_NULL            0
//#define  CMD_SPI_TEST        1
//#define  CMD_RESET           2
//#define  CMD_DETECT          3
//#define  CMD_WORK            4
//#define  CMD_POWDOWN         5
#define  CMD_GET_IMAGE       6
#define  CMD_CAPTURE         1
#define  CMD_DETECT          2
#define  CMD_WRITEREGS       3
#define  CMD_READREGS        4
#define  CMD_RESET           5

//#define  LineNum   96
//#define  RowNum    112
#define  LineNum   160
#define  RowNum    160
//#define  RowNum    96

//#define  WORK       			0x18
//#define  S_RESET      	  0x0C
//#define  DETECT      	    0x14
//#define  POWDOWN    		  0x00

//#define  WORK_H       			0x43
//#define  WORK_L       			0x04
#define  S_RESET      	  0x0C
#define  DETECT      	    0x14
#define  POWDOWN    		  0x00

#define  CAPTURE_START		0xC0
#define  CAPTURE_CONTIN		0x90
#define  SET_CAP_TIMING		0x21
#define  SET_TEST_PARA		0x28
#define  RD_STATUS				0x2D
#define  RD_LINE_DATA		  0x71

#define  D_BYTE	 0x66

#define  PARA1   0x05  //f5
#define  PARA2   0x00
#define  PARA3   0xE6  //e6
#define  PARA4   0x70

#define  TPARA   0x80


typedef struct _GRAYREG{
	UINT8 Charge;
	UINT8 Offset;
	UINT8 Gain;
}GrayReg;

typedef enum{
	Black,
	Grey,
	White,
	Normal
}GrayFlag;

typedef struct _GRAYTESTREG{
	GrayFlag TestGrayFlag;
	GrayReg TestGrayReg;
}GrayTestReg;

#define CALIBRATE_FLASH_FLAG_OFFSET        ( (BS_NVM_PAGE*FLASH_PAGE_SIZE))
#define BS600_CALUBRATE_FLAG_OFFSET			(CALIBRATE_FLASH_FLAG_OFFSET)
#define BS5xx_CALUBRATE_FLAG_OFFSET			(BS600_CALUBRATE_FLAG_OFFSET+1)
#define BTL_CALUBRATE_FLAG_OFFSET			(BS5xx_CALUBRATE_FLAG_OFFSET+1)
#define BS510_CALUBRATE_FLAG_OFFSET         (BTL_CALUBRATE_FLAG_OFFSET+1)
#define SENSOR_GRAY_FLAG_OFFSET             (CALIBRATE_FLASH_FLAG_OFFSET + 20)    //need about 40 Bytes
#define CALIBRATE_FLASH_BADLINE_OFFSET     (SENSOR_GRAY_FLAG_OFFSET + 40)
#define CALIBARTE_FLASH_FLAG                0x55



#define MAX_BADLINE    			20
#define DELTA_OF_WHITENODE    	235
#define DELTA_OF_BLACKNODE    	61
#define DELTA_OF_NEIBOURLINE    40
#define NOT_ALONE_BADLINE_NODE  80
#define DELTA_OF_AVERVAL  		22
#define OFFSET_OF_WHITENODE  	5
#define OFFSET_OF_BLACKNODE  	20

typedef struct badlinedetectioin{
	GrayFlag TestGrayFlag;
	UINT8 ThresholdValue;
}BadLineDet;



typedef struct BadLine_Type{
	UINT8 BadLine[MAX_BADLINE];
	UINT8 Badline_num;
}BadlineType;



typedef enum{
	Area_None = 0,
	Area_160_160,
	Area_112_96,
}BS5xxArea;

//BS5xxArea BS5xxType = Area_160_160;

typedef struct _IMGAREA{
	UINT16 ImgX;
	UINT16 ImgY;
}BS5xxImgXY;

typedef struct _BS5xxGRAYREG{
	UINT8 prec;			// Charge
	UINT8 vref;			// Offset
	UINT8 ccsv;			// Gain
}BS5xxGrayReg;

//typedef enum{
//	Black,
//	Grey,
//	White,
//	Normal
//}BS5xxGrayFlag;

//typedef struct _GRAYTESTREG{
//	BS5xxGrayFlag TestGrayFlag;
//	BS5xxGrayReg TestGrayReg;
//}BS5xxGrayTestReg;


typedef struct _BS5xxINFO{
	BS5xxArea		 BS5xxType;
	BS5xxImgXY	 	 BS5xxImgXYType;
//	BS5xxGrayReg     BS5xxGrayRegValue;
//	BS5xxGrayTestReg BS5xxGrayTestRegValue[4];
	GrayTestReg		 BS5xxGrayTestRegValue[4];
}BS5xxInfo;


#define MAX_OFFSET_VALUE  		0x3f
#define MAX_CHARGE_VALUE  		0x3f

#define NO_FINGER       0
#define NORMAL_FINGER   1
#define WET_FINGER      2
#define DRY_FINGER      3

//#define NORMAL_FNGR_THRESHOLE   75
#define NORMAL_FNGR_THRESHOLE   80
#define WET_BLOCK_THRESHOLD  15
#define DRY_BLOCK_THRESHOLD  13

//#define IMGX_UP         256
//#define IMGY_UP         288

/********************BS800 Sensor width and height******************************/
#define BS800_WIDTH         192   ///< BS800  sensor width
#define BS800_HEIGHT        256   ///< BS800  sensor height

//#define IMGX            BS800_WIDTH
//#define IMGY            BS800_HEIGHT

#define  BS600_IMGX  176
#define  BS600_IMGY  176
#define IMGX            BS600_IMGX
#define IMGY            BS600_IMGY

#define IMGYOFFSET      0
#define IMGX_UP         256
#define IMGY_UP         288



#define SENSOR_WIDTH      BS600_IMGX
#define SENSOR_HEIGHT	 BS600_IMGY

#define IMGX_UP         256
#define IMGY_UP         288


#define TEST_UPLOAD_IMGX  176
#define TEST_UPLOAD_IMGY  176


#define BS500_DRY_INTERVAL_OFFSET  6
#define BS500_WET_INTERVAL_OFFSET 6
#define BS500_ADJUST_TIME         3

extern BS5xxInfo BS5xxInfoTypeN[];

UINT8 SPI_SendRxByte(UINT8 byte);
UINT8 Spi_ReadByte(UINT8 CMD);

BOOL BS500_Init(void);
BS5xxArea BS5xx_Init(void);
BOOL Sensor_capture(UINT8* imagepixal, BS5xxArea _BS5xxType);
UINT32 BS5xx_Calibrate(UINT8 *_pAlgBuf);
UINT8 DetectFinger(UINT8 *_pAlgBuf, UINT32 vImgRawWidth, UINT32 vImgRawHeight);
int BS_RD_Flash(UINT8 *dest, UINT32 offset, UINT32 length);
int BS_WR_Flash(UINT8 *src, UINT32 offset, UINT32 length);

#endif /* BS500_H_ */
