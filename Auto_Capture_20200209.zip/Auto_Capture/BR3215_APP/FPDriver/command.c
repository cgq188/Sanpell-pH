#include <string.h>
#include <stdio.h>
#include <string.h>
#include "hal.h"
#include "fpdefine.h"
#include "protocol.h"
#include "command.h"
#include "protocol.h"
#include "FingerPro.h"
#include "global.h"
#include "dbgtrace.h"
#include "main.h"

#include "Need_For_Lib/FpRecognitionLibrary.h"
#include "Need_For_Lib/GlobalVar.h"
#include "Need_For_Lib/Flash_Control.h"

extern void Control_Param(int vArea, int vMax);
extern int Capture_Once_Block(BYTE* membuf, int Time_Limit, int Upload_Image_Flag);
extern int Capture_Once_Full(BYTE* membuf, int Time_Limit, int Upload_Image_Flag);
extern int Belong_Finger(BYTE* iimage);
extern int Capture_Finger(BYTE* oimg);
extern void Init_Capture_Engine_Full(BYTE* membuf);

#ifndef CAPTURE_ONCE_FULL
#define CAPTURE_ONCE_FULL 1
#endif

#define SEND_DELTA_BYTE 100

/************************************************************************/
/*                                                                      */
/************************************************************************/
#define BK100_USB_DEVICE_MARK 0x55

void read_uid(BYTE* uid_address){
	memcpy(uid_address, SFD.uid, 16);
}

int gEnrolled_Count=0;
BYTE gEnrolled_Flag[FP_MAX_USERS];

void get_enrolled_info(void){
	int i;

	FpLib_Get_Enrolled_State(gEnrolled_Flag);

	gEnrolled_Count = 0;
	for(i=0; i<FP_MAX_USERS; i++){
		if(gEnrolled_Flag[i]==1){
			gEnrolled_Count++;
		}
	}
}

extern int Licence_Error;
extern int g_bug_temp[10];
void oem_open(BOOL bExtraInfo)
{
	Mem_Seg_Initialize(AlgBuf);
	FpLib_Initialize();

	oemp_SendCmdOrAck(DEVID, ACK_OK, 0);
	if (bExtraInfo)
	{
		devinfo* di = (devinfo*)g_ImageBuffer;
		di->FirmwareVersion = FW_VERSION;
		memcpy(di->DeviceSerialNumber, SFD.uid, 16);

		oemp_SendData(DEVID, (BYTE*)di, sizeof(devinfo));
	}
}

/*
const char* engine_main_get_version(void);

extern int boot_time;
*/

void oem_close(void)
{
	oemp_SendCmdOrAck(DEVID, ACK_OK, 0);
}

void oem_usb_internal_check(void) {
	oemp_SendCmdOrAck(DEVID, ACK_OK, BK100_USB_DEVICE_MARK);
}

void oem_enroll_count(void)
{
	get_enrolled_info();

	oemp_SendCmdOrAck( DEVID, ACK_OK, gEnrolled_Count);
}

void oem_check_enrolled(int nPos)
{
	get_enrolled_info();

	if ( nPos<0 || nPos>=FP_MAX_USERS )
	{
		oemp_SendCmdOrAck( DEVID, NACK_INFO, NACK_INVALID_POS );
		return;
	}

	if ( !gEnrolled_Flag[nPos] )
	{
		oemp_SendCmdOrAck( DEVID, NACK_INFO, NACK_IS_NOT_USED );
		return;
	}

	oemp_SendCmdOrAck( DEVID, ACK_OK, 0 );
}

extern int gLast_Push_State;
int gnEnrollPos = -1;
void oem_enroll_start( int nPos )
{
	get_enrolled_info();

	if(gEnrolled_Count == FP_MAX_USERS)
	{
		oemp_SendCmdOrAck( DEVID, NACK_INFO, NACK_DB_IS_FULL );
		return;
	}

	if ( nPos<0 || nPos>=FP_MAX_USERS )
	{
		oemp_SendCmdOrAck( DEVID, NACK_INFO, NACK_INVALID_POS );
		return;
	}

	if ( gEnrolled_Flag[nPos] )
	{
		oemp_SendCmdOrAck( DEVID, NACK_INFO, NACK_IS_ALREADY_USED );
		return;
	}

	gLast_Push_State = -1;
	gnEnrollPos = nPos;
	oemp_SendCmdOrAck( DEVID, ACK_OK, 0 );
}

void oem_enroll_nth(void)
{
	int nRet, Enrolled_ID, Enrolled_Percent;

	nRet = FpLib_Enroll(g_ImageBuffer, gnEnrollPos, &Enrolled_ID, &Enrolled_Percent);

	if(nRet == FPLIB_BAD_IMGAGE)
	{
	 	oemp_SendCmdOrAck( DEVID, NACK_INFO, NACK_BAD_FINGER );
		return;
	}
	if(nRet == FPLIB_FAILED)
	{
	 	oemp_SendCmdOrAck( DEVID, NACK_INFO, NACK_ENROLL_FAILED );
		return;
	}

	oemp_SendCmdOrAck( DEVID, ACK_OK, Enrolled_Percent );
}

void oem_is_press_finger(void) {
	Capture_Finger(g_ImageBuffer);
	if (Belong_Finger(g_ImageBuffer)==1)
		oemp_SendCmdOrAck(DEVID, ACK_OK, 0);
	else
		oemp_SendCmdOrAck(DEVID, NACK_INFO, NACK_FINGER_IS_NOT_PRESSED);
}

void oem_enroll_finish(void){
	//gnEnrollPos = -1;
	if(gnEnrollPos<0){
		oemp_SendCmdOrAck( DEVID, NACK_INFO, NACK_INVALID_POS );
	}else{
		FpLib_Set_Enroll_Finish(gnEnrollPos);
		gLast_Push_State = -1;
		oemp_SendCmdOrAck(DEVID, ACK_OK, 0);
	}
}

void oem_delete(int nPos)
{
	if ( nPos<0 || nPos>=FP_MAX_USERS )
	{
		oemp_SendCmdOrAck( DEVID, NACK_INFO, NACK_INVALID_POS );
		return;
	}

	FpLib_Delete(nPos);
	oemp_SendCmdOrAck( DEVID, ACK_OK, 0 );
}

void oem_delete_all(void)
{
	get_enrolled_info();
	if(gEnrolled_Count == 0)
	{
		oemp_SendCmdOrAck( DEVID, NACK_INFO, NACK_DB_IS_EMPTY );
		return;
	}
	FpLib_Resest();
	oemp_SendCmdOrAck( DEVID, ACK_OK, 0 );
}

void oem_verify(int nPos)
{
	int Enrolled_ID, Study_Flag;

	get_enrolled_info();
	if ( nPos<0 || nPos>=FP_MAX_USERS )
	{
		oemp_SendCmdOrAck( DEVID, NACK_INFO, NACK_INVALID_POS );
		return;
	}

	if ( !gEnrolled_Flag[nPos] )
	{
		oemp_SendCmdOrAck( DEVID, NACK_INFO, NACK_IS_NOT_USED );
		return;
	}
	if( FpLib_Verify(g_ImageBuffer, nPos, &Enrolled_ID, &Study_Flag) == FPLIB_SUCCESS){
		g_MatchedPersonID = nPos;
		g_StudyFlag = Study_Flag;
		oemp_SendCmdOrAck( DEVID, ACK_OK, 0 );
	}else{
		oemp_SendCmdOrAck( DEVID, NACK_INFO, NACK_VERIFY_FAILED );
	}
}

void oem_identify(void)
{
	get_enrolled_info();

	int nID, eID, ret;

	if(gEnrolled_Count == 0)
	{
		oemp_SendCmdOrAck( DEVID, NACK_INFO, NACK_DB_IS_EMPTY );
		return;
	}

	ret = FpLib_Identify(g_ImageBuffer, &nID, &eID, &g_StudyFlag);
	if(ret!=FPLIB_SUCCESS){
		oemp_SendCmdOrAck( DEVID, NACK_INFO, NACK_IDENTIFY_FAILED );
		return;
	}
	if(g_StudyFlag) g_MatchedPersonID = nID;

	if( nID < 0 )
		oemp_SendCmdOrAck( DEVID, NACK_INFO, NACK_IDENTIFY_FAILED );
	else
		oemp_SendCmdOrAck( DEVID, ACK_OK, nID );
}

void oem_verify_template(int nPos)
{
	(void)nPos;
}

void oem_identify_template(void)
{
}

int oem_capture(int Time_Limit)
{

	oemp_SendCmdOrAck(DEVID, ACK_OK, 0);

	int ret;
#if CAPTURE_ONCE_FULL
	ret = Capture_Once_Full(g_ImageBuffer, Time_Limit, FALSE);
#else
	ret = Capture_Once_Block(g_ImageBuffer, Time_Limit, FALSE);
#endif

	if(ret){
		oemp_SendData(DEVID, g_ImageBuffer, RAWIMG_CX * RAWIMG_CY + SEND_DELTA_BYTE);
	}

	return ret;
}

void oem_make_template(void)
{
}

void oem_get_image(unsigned int param)
{
	oemp_SendCmdOrAck( DEVID, ACK_OK, 0 );

	int ret;
#if CAPTURE_ONCE_FULL
	ret = Capture_Once_Full(g_ImageBuffer, 5000, param);
#else
	ret = Capture_Once_Block(g_ImageBuffer, 5000, param);
#endif

	if(ret){
		oemp_SendData(DEVID, g_ImageBuffer, RAWIMG_CX * RAWIMG_CY + SEND_DELTA_BYTE);
	}
}

void oem_senddata(BYTE* buf, int size){
	oemp_SendData( DEVID, buf, size);
}

void oem_get_rawimage(unsigned int param)
{
	if (!RawImageGet(g_ImageBuffer, param))
	{
		oemp_SendCmdOrAck(DEVID, NACK_INFO, NACK_FINGER_IS_NOT_PRESSED);
		return;
	}
	oemp_SendCmdOrAck(DEVID, ACK_OK, 0);

	oemp_SendData(DEVID, g_ImageBuffer, RAWIMG_CX * RAWIMG_CY + SEND_DELTA_BYTE);
}

void oem_download_image(void){
	oemp_SendCmdOrAck(DEVID, ACK_OK, 0);
	oemp_ReceiveData(DEVID, g_ImageBuffer, RAWIMG_CX * RAWIMG_CY  + SEND_DELTA_BYTE);
}

void oem_get_template(int nPos)
{
	(void)nPos;
}

void oem_add_template(int nPos)
{
	(void)nPos;
}

void oem_fw_upgrade(int nLen)
{
#define	BOOT_FLASH_ADDR	0x10000
#define WDT_US_NUM (1)  //1000ms
	oemp_SendCmdOrAck(DEVID, ACK_OK, 0);
	_delay_ms(500);

	if (!nLen)
	{
		UINT32 PrgFlag;
		UINT32 i;
		UINT32 nRet;
		__disable_irq();
		for (i = 0; i < 10; i++)
		{
			PrgFlag = 0xffffffff;
			nRet = Flash_WriteInfo((UINT8*)&PrgFlag, BOOT_FLASH_ADDR, 4);
			if (nRet != RT_OK) //clear the Flash flag for has encoded, then we can download the code again.
			{
				continue;
			}
			PrgFlag = 0x12345678;
			Flash_ReadInfo((UINT8*)&PrgFlag, BOOT_FLASH_ADDR, 4);
			if (PrgFlag == 0xffffffff)
			{
				break;
			}
		}
	}
	else
	{
		__disable_irq();
	}
	//__enable_irq(); //wait for watchdog restart

	//TIM_Init(TIM0, WDT_US_NUM, 32 - 1, TIM_WDT);//���Ź���ʼ������ǰʵ��32M
}

extern void FpLib_Write_License(unsigned char* license_data);
extern unsigned char LICENCE[2048];

int star_ReceiveData(BYTE* receive_data, int receive_size, int receive_step){
	int cou = receive_size / receive_step;
	int pos = 0;
	int i;
	for (i = 0; i < cou; i++){
		oemp_ReceiveData(DEVID, g_ImageBuffer, receive_step);

		//dUart_Printf("receive %d\r\n", i);

		memcpy(receive_data + pos, g_ImageBuffer, receive_step);
		pos += receive_step;
	}
	int rem = receive_size - receive_step * cou;
	if (rem > 0){
		oemp_ReceiveData(DEVID, g_ImageBuffer, rem);
		memcpy(receive_data + pos, g_ImageBuffer, rem);
	}
	return 0;
}

void Write_License(void){
	int ret = 0;

	oemp_SendCmdOrAck(DEVID, ACK_OK, 0);

	oemp_ReceiveData(DEVID, g_ImageBuffer, 2056);

	FpLib_Write_License(g_ImageBuffer);

//	Read_Flash_Data_For_Lib(0, 2*1024, g_ImageBuffer + 2*1024);
//	ret = memcmp(g_ImageBuffer, g_ImageBuffer + 2*1024, 2*1024);

	oemp_SendCmdOrAck(DEVID, ACK_OK, ret);
}

extern void FpLib_Get_Imei_Info(unsigned char* imei_membuf);
void Read_Imei_Info(void){

	oemp_SendCmdOrAck(DEVID, ACK_OK, 0);

	BYTE stmembuf[30];
	BYTE* uid_membuf = stmembuf + 4;
	read_uid(uid_membuf);

	FpLib_Get_Imei_Info(uid_membuf);

	oemp_SendData(DEVID, uid_membuf, 16);

	oemp_SendCmdOrAck(DEVID, ACK_OK, 0);
}

void oem_default(void)
{
	oemp_SendCmdOrAck(DEVID, NACK_INFO, NACK_IS_NOT_SUPPORTED);
}

#define OEM_PRECHECK_DEVICE() 	if (0) {oemp_SendCmdOrAck( DEVID, NACK_INFO, NACK_DEV_ERR );return;}

void oem_command_proc(SB_OEM_PKT* pCmdPkt)
{
	switch (pCmdPkt->wCmd)
	{
	case CMD_OPEN:
		oem_open(pCmdPkt->nParam);
		break;
	case CMD_CLOSE:
		oem_close();
		break;
	case CMD_USB_INTERNAL_CHECK:// for only usb.
		oem_usb_internal_check();
		break;
	case CMD_CHANGE_BAUDRATE:

/*
		{
			int nBaudrate = pCmdPkt->nParam;

			if (nBaudrate > 115200 ||
				nBaudrate < 9600)
			{
				oemp_SendCmdOrAck( DEVID, NACK_INFO, NACK_INVALID_PARAM );
				break;
			}
			oemp_SendCmdOrAck( DEVID, ACK_OK, 0 );
			_delay_ms(5);

			Uart_Init(nBaudrate);
		}
*/

		break;

	case CMD_ENROLL_COUNT:
		oem_enroll_count();
		break;
	case CMD_CHECK_ENROLLED:
		oem_check_enrolled(pCmdPkt->nParam);
		break;
	case CMD_ENROLL_START:
		OEM_PRECHECK_DEVICE();
		oem_enroll_start(pCmdPkt->nParam);
		break;
	case CMD_ENROLL1:
	case CMD_ENROLL2:
	case CMD_ENROLL3:
		OEM_PRECHECK_DEVICE();
		oem_enroll_nth();
		break;
	case CMD_IS_PRESS_FINGER:
		OEM_PRECHECK_DEVICE();
		oem_is_press_finger();
		break;
	case CMD_ENROLL_FINISH:
		oem_enroll_finish();
		break;

	case CMD_DELETE:
		oem_delete(pCmdPkt->nParam);
		break;
	case CMD_DELETE_ALL:
		oem_delete_all();
		break;

	case CMD_VERIFY:
		OEM_PRECHECK_DEVICE();
		oem_verify(pCmdPkt->nParam);
		break;
	case CMD_IDENTIFY:
		OEM_PRECHECK_DEVICE();
		oem_identify();
		break;
	case CMD_VERIFY_TEMPLATE:
		OEM_PRECHECK_DEVICE();
		oem_verify_template(pCmdPkt->nParam);
		break;
	case CMD_IDENTIFY_TEMPLATE:
		OEM_PRECHECK_DEVICE();
		oem_identify_template();
		break;

	case CMD_CAPTURE:
		OEM_PRECHECK_DEVICE();
		oem_capture(pCmdPkt->nParam);
		break;
	case CMD_MAKE_TEMPLATE:
		OEM_PRECHECK_DEVICE();
		oem_make_template();
		break;
	case CMD_GET_IMAGE:
		OEM_PRECHECK_DEVICE();
		oem_get_image((unsigned int)pCmdPkt->nParam);
		break;
	case CMD_GET_RAWIMAGE:
		OEM_PRECHECK_DEVICE();
		oem_get_rawimage((unsigned int)pCmdPkt->nParam);
		break;
	case CMD_DOWNLOAD_IMAGE:
		OEM_PRECHECK_DEVICE();
		oem_download_image();
		break;


	case CMD_GET_TEMPLATE:
		oem_get_template(pCmdPkt->nParam);
		break;
	case CMD_ADD_TEMPLATE:
		OEM_PRECHECK_DEVICE();
		oem_add_template(pCmdPkt->nParam);
		break;

	case CMD_FW_UPDATE:
		oem_fw_upgrade(pCmdPkt->nParam);
		break;

	case CMD_WRITE_LICENSE:
		Write_License();
		break;

	case CMD_READ_IMEI_INFO:
		Read_Imei_Info();
		break;

	default:
		oem_default();
		break;
	}
}
