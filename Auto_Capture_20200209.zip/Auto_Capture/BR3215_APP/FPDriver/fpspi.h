#ifndef __SPI_H_
#define __SPI_H_

#include "br32xx.h"
#include "Type.h"
#include "fpdefine.h"
#include "spi.h"


#define SPI_MISO_GRP GPIOA
#define SPI_MISO_PIN 10 //9
//#define SPI_MISO_PIN 9 //9

#define SPI_MOSI_GRP GPIOA
#define SPI_MOSI_PIN 12 //10
//#define SPI_MOSI_PIN 10 //10

//#define SPI_CLK_GRP GPIOA
//#define SPI_CLK_PIN 13 //11
////#define SPI_CLK_PIN 11 //11

#define SPI_CLK_GRP GPIOB
#define SPI_CLK_PIN 5 //11

#define SPI_CSN_GRP GPIOB
#define SPI_CSN_PIN 1 //0
//#define SPI_CSN_PIN 0 //0
#define SPI_CS_OUTPUT() GPIO_Init(SPI_CSN_GRP,SPI_CSN_PIN,GPIO_OUTPUT)
#define SPI_CS_HIGH()   GPIO_WriteBit(SPI_CSN_GRP,SPI_CSN_PIN,1)
#define SPI_CS_LOW()    GPIO_WriteBit(SPI_CSN_GRP,SPI_CSN_PIN,0)

//#define SensorRest_GRP GPIOB
//#define SensorRest_PIN 0 //1
#define SensorRest_GRP GPIOA
#define SensorRest_PIN 7 //1

//#define SensorRest_PIN 1 //1
#define SensorRest_PAD
#define SPI_RST_OUTPUT() GPIO_Init(SensorRest_GRP,SensorRest_PIN,GPIO_OUTPUT)
#define SPI_RST_HIGH()   GPIO_WriteBit(SensorRest_GRP,SensorRest_PIN,1)
#define SPI_RST_LOW()    GPIO_WriteBit(SensorRest_GRP,SensorRest_PIN,0)

#define  NOP()   __NOP()

extern void Fp_Spi_Init(void);
extern BOOL Fp_SpiSendByte(UINT8 Data);
extern BOOL Fp_SpiRcvByte(UINT8 *pData);
extern BOOL Fp_SpiRcvByteN(UINT8* pData, int n);

#endif /*GPIO_H_*/
