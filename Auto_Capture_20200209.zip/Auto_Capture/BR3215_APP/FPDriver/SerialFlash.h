
#ifndef _SQI_H_
#define _SQI_H_

#include "osal.h"

#define    SF_FLASH_PAGE_SIZE  256
#define    SF_FLASH_BLOCK_SIZE 4096

#undef __ONCHIP_CODE__
#define __ONCHIP_CODE__ __attribute__ ((section (".ramtext"), optimize(s), noinline))

/*function */
UINT8  Flash_Init(UINT8 _ClkDiv,UINT8 _Mode);
int  Flash_WriteInfo(const void* buf, unsigned int addr, int len) __ONCHIP_CODE__;
int  Flash_ReadInfo(void* buf, unsigned int addr, int len) __ONCHIP_CODE__;
int  LockFlashErase(int block) __ONCHIP_CODE__;
int  LockFlashWriteBlock(const void* buf, unsigned int block, int offset, int len) __ONCHIP_CODE__;
void FlashPageProgram(unsigned int addr, const void* buf, int len) __ONCHIP_CODE__;

#endif   /*SQI.H*/
