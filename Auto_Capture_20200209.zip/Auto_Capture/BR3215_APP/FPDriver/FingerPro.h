/*******************************************************************************
**                                                                            **
**      ///////  ///////  ////     //// //////  ////// ///////    /////       **
**      //    // //    // ////    // //   //   //      //    // //     //     **
**      //    // //    // // //  //  //   //   //      //    // //     //     **
**      ///////  ///////  //  ////   //   //   //      ///////  //     //     **
**      //    // //    // //   //    //   //   //      //    // //     //     **
**      //    // //    // //         //   //   //      //    // //     //     **
**      ///////  //    // //         // //////  ////// //    //   /////       **
**                                                                            **
**                       @ Copyright 2012 - 2018                              **
**                          www.brmicro.com.cn                                **
**                                                                            **
*******************************************************************************/


#ifndef _FINGERPRO_H_
#define _FINGERPRO_H_
#include <stdint.h>
#include "Type.h"
#include <nds32_intrinsic.h>

#define TOTAL_USE_RAM 50

extern UINT8  g_abyImageBuf[TOTAL_USE_RAM * 1024 + 8];
extern UINT8* AlgBuf;

BOOL RawImageGet(UINT8 *_pAlgBuf, unsigned int param);

#endif
