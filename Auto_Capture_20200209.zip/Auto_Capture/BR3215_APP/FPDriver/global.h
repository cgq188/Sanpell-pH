
#ifndef _FP_BOARD_H_
#define _FP_BOARD_H_


#include "hal.h"
#include "Type.h"
#include "fpdefine.h"
#include "command.h"
#include "Timer.h"
#include "SerialFlash.h"
#include "Gpio.h"
#include "fpspi.h"

#define UART_COMM 	1


#endif /* _FP_DEFINE_H_ */
