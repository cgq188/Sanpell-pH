
/*-----------------------------------------------------------------------------
�汾��V1.0.0
sensor�ͺţ�192*192  
�汾��1.1.0.20171123
�޸�DACP
�汾��1.1.1.20180106
1. �޸�DACP: 81192-DK4M100   
�汾��1.2.0.20180226
1. ���жϷ�ʽ��ͼ�޸�Ϊ��ѯ��ʽ��ͼ
�汾��1.2.1.20180321
1. �޸�gParamĬ�ϲ���   
------------------------------------------------------------------------------*/
/* Includes ------------------------------------------------------------------*/

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>   
#include "bs201_bep_fun.h"
#include "xz_sensor.h"
#include <stdbool.h>  
#include <bs201/bs201_api.h>
#include "bs201_bep_spi.h"
////
#include "global.h"
#include "string.h"
#include "fpspi.h"


bs201_TUNABLE_PARAM gParam = { 96, 0x25,0xc8,	0,	0xb0 };

//bs201_TUNABLE_PARAM gParam = { 0x8d, 0x5e,0x48,	0,	0xb0 }; //default by zff
//bs201_TUNABLE_PARAM gParam = {0x87, 0x64,0x48,	0,	0xb0}; // 100����
//bs201_TUNABLE_PARAM gParam = {0x80, 0x4F,0x33,	0x75,	0xff}; // DK4coating

//bs201_TUNABLE_PARAM gParam = {0x75, 0x4F,0x33,	0,	0xb0}; //
//bs201_TUNABLE_PARAM gParam = {0x8d, 0x57,0x33,	0,	0xb0}; //
/*
bs201_TUNABLE_PARAM gParam = {
	0x80, //�����������ȵ��ڣ�ֵԽС��ͼ��Խ�ڣ���ָ���Խ����
	0x4F, //�Աȶȵ���֮һ�� ֵԽ��Աȶ�Խǿ����ѡֵ��0x4f, 0x57, 0x5f
	0x33, //�Աȶȵ��ڶ���һ�㲻�޸ģ�
	0x75, //��С�������Ʒ�ֵ�����������޸ģ�
	0xff //����������Ʒ�ֵ�����������޸ģ�
};
*/
	 


/****************************************************

*****************************************************/   
//define CS signal for BS

#define SPI_CS_CFG_OUTPUT()		(SPI_CS_OUTPUT())
#define	SPI_CS_DATA_1()			(SPI_CS_HIGH())
#define	SPI_CS_DATA_0()      	(SPI_CS_LOW())
//define RST signal for BS

#define RST_CFG_OUTPUT()   		(SPI_RST_OUTPUT())
#define	RST_DATA_1()      		(SPI_RST_HIGH())
#define	RST_DATA_0()       		(SPI_RST_LOW())

void SpiCSSet(UINT8 LEVEL)
{
	__disable_irq();
	if(LEVEL == 0)
	{
		SPI_CS_DATA_0();
	}
	else
	{
		SPI_CS_DATA_1();
	}
	__enable_irq();
}


void RstnSet(UINT8 LEVEL)
{
	if(LEVEL == 0)
	{
		RST_DATA_0();
	}
	else
	{
		RST_DATA_1();
	}
}

UINT8 bs201SpiSendByte(UINT8 byte)
{
	 Fp_SpiSendByte(byte);
	 return 0;
}

UINT8 bs201SpiRevByte(UINT8* pBuffer, UINT32 Num)
{
	while (Num--)
	{
		//SPI_Transceive(SPI_NUM, pBuffer);
		Fp_SpiRcvByte(pBuffer);
		pBuffer++;
	}
	return 0;
}

static void bs201_IO_Init(void)
{
	SPI_CS_CFG_OUTPUT();
	RST_CFG_OUTPUT();
	SpiCSSet(0);

	//SPI_Init(SPI_NUM,MASTER,SPI_MODE0,SPI_MSB,0x08,bs201_SPI_FREQ);
	Fp_Spi_Init();

	RstnSet(1);
	_delay_us(1000);
	RstnSet(0);
	_delay_ms(5); //_delay_us(1000);
	RstnSet(1);
	_delay_ms(5); //_delay_us(1000);
}

BOOL bs201_Init(void)
{
	bs201_IO_Init();

	if(bs201SensorInit() != 0)
	{
		return FALSE;
	}
	bs201SetSensorROIto16x16(); //initial mode
	bs201SensorMode(MODE_IDLE);
	bs201SensorSoftReset();

	return TRUE;
}
