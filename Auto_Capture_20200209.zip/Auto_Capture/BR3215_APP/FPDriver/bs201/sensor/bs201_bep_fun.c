
/* Includes ------------------------------------------------------------------*/
#include <bs201/sensor/bs201_bep_fun.h>
#include <bs201/sensor/bs201_bep_spi.h>
#include <bs201/sensor/xz_sensor.h>

#include "bs201_api.h"
#include "cpm_lld.h"
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
//#include <stdio.h>   
	    
volatile bs201_SENSOR_STATUS g_bs201Sensor = { 0 };
extern bs201_TUNABLE_PARAM gParam;

int bs201SensorInit(void)
{
	int nRet = 0;
	
	// 1 sensor id
	nRet = bs201SensorGetChipId();
	if (nRet != 0) 	
	{
		return -1;
	}

	// 2 init sensor config
	switch (g_bs201Sensor.nChipID)
	{  
	case VENDOR_ID:
	default: 
		bs201_WriteSingleCmd(0x12,0x06);
		bs201_WriteSingleCmd(0x11,0x00);
		bs201_WriteSingleCmd(0x0a,0x00);
		bs201_WriteSingleCmd(0x0b,0x05); //05 0a
		bs201_WriteSingleCmd(0x02,0x11);
		bs201_WriteSingleCmd(0x17,0x2c);
		bs201_WriteSingleCmd(0x0d,0x1b);
		bs201_WriteSingleCmd(0x17,0xac);
		bs201_WriteSingleCmd(0x2d,0xf0);
		bs201_WriteSingleCmd(0x3d,0x75);
		bs201_WriteSingleCmd(0x33,0x92);
		bs201_WriteSingleCmd(0x35,0x52);
		bs201_WriteSingleCmd(0x1d,0xff);
		bs201_WriteSingleCmd(0x1e,0xff);
		bs201_WriteSingleCmd(0x1f,0xff);
		bs201_WriteSingleCmd(0x20,0xff);
		bs201_WriteSingleCmd(0x21,0xff);
		bs201_WriteSingleCmd(0x22,0xff);
		bs201_WriteSingleCmd(0x23,0xff);
		bs201_WriteSingleCmd(0x24,0xff);
		bs201_WriteSingleCmd(0x25,0xff);
		bs201_WriteSingleCmd(0x26,0xff);
		bs201_WriteSingleCmd(0x27,0xff);
		bs201_WriteSingleCmd(0x28,0xff);
		bs201_WriteSingleCmd(0x31,gParam.reg31_val);  //5c
		bs201_WriteSingleCmd(0x32,gParam.reg32_val); //48
		bs201_WriteSingleCmd(0x1b,gParam.dacp_val); 	 //6f
		
		break;
	} 	
	return nRet;
}

int bs201SensorSoftReset(void)
{	
	bs201_WriteSingleCmd(REGA_HOST_CMD, 0x40);
	bs201_WriteSingleCmd(REGA_HOST_CMD, 0x00);
	return 0;
}
int bs201SensorMode(int nMode)
{
	bs201_WriteSingleCmd(REGA_HOST_CMD, nMode);
	g_bs201Sensor.nWorkMode = nMode;
	return 0;
}

int bs201_capture_whole_image(void* pImg)
{
	int nRet = -1;

	if (g_bs201Sensor.nWorkMode != MODE_FG_DT)
	{
		bs201SensorMode(MODE_IDLE);
		bs201SensorSoftReset();
		bs201SensorMode(MODE_FG_DT);
	}
	bs201SetSensorROIto112x96();
	if (0 == bs201CaptureImageEx((uint8_t*)pImg, IMAGE_WIDTH, IMAGE_HEIGHT))
		nRet = 0;
	return nRet;
}

int bs201_capture_block_image(void* pImg, int short_offset, int long_offset)
{
	int nRet = -1;

	if (g_bs201Sensor.nWorkMode != MODE_FG_DT)
	{
		bs201SensorMode(MODE_IDLE);
		bs201SensorSoftReset();
		bs201SensorMode(MODE_FG_DT);
	}
	bs201SetSensorROIto16x16_at_point(short_offset, long_offset);
	if (0 == bs201CaptureImageEx((uint8_t*)pImg, 16, 16))
		nRet = 0;
	return nRet;
}

// [ret] if driver is -1, means no driver ic.
int bs201SensorGetChipId(void)
{
	uint8_t arrOut[8] = { 0 };     
// 1 read sensor id
		bs201_WriteSingleCmd(REGA_VERSION_RD_EN, 0x80);
		bs201_ReadSingleCmd(REGA_RC_THRESHOLD_HIGH, &arrOut[0]);
		bs201_ReadSingleCmd(REGA_FINGER_TD_THRED_LOW, &arrOut[1]);
		bs201_ReadSingleCmd(REGA_FINGER_TD_THRED_HIGH, &arrOut[2]);
		// restore enable register
		bs201_WriteSingleCmd(REGA_VERSION_RD_EN, 0x00);
		g_bs201Sensor.nChipID = (arrOut[1] << 8) | arrOut[0];
		//print("CHIP_IDֵΪ     %x\n",g_bs201Sensor.nChipID);
	if(g_bs201Sensor.nChipID != VENDOR_ID)
	{
		return -1;
	} 
	return 0;
}

/*
�ɼ��ֲ���������÷���
[in] nStartRow: start from 1
[in] nStartCol: start from 1, every 8 column as a group.  
*/
static bool SetSensorROI(uint16_t nStartRow, uint16_t nStartCol, uint16_t nRowLen, uint16_t nColLen)
{
	uint8_t nColVal;
	
	bs201_WriteSingleCmd(0x14, (uint8_t)nStartRow);
	bs201_WriteSingleCmd(0x15, (uint8_t)nRowLen);

	//bit[0:3] start column, bit[4:7] col len
	nColVal = (((nColLen >> 3) & 0x0F) << 4) | (((nStartCol >> 3) + 1) & 0x0F);
	bs201_WriteSingleCmd(0x16, nColVal);

	return 0;
}

int bs201_wait_detect(void)
{
	int nTryCount, Sensor_FD_CAP_int_flag = 0;

	nTryCount = 5000;
	do
	{
		//_delay_ms(1);
		_delay_us(600);
		unsigned char temp;
		bs201_ReadSingleCmd(REGA_INTR_STATUS, &temp);
		if (temp & (1 << 1))
		{
			Sensor_FD_CAP_int_flag = 1;
			break;
		}
		nTryCount--;
		if (nTryCount <= 0)
		{
			break;
		}
	} while (0 == Sensor_FD_CAP_int_flag);

	return Sensor_FD_CAP_int_flag;
}

int bs201CaptureImageEx(uint8_t* pData, uint16_t nWidth, uint16_t nHeight /*, uint16_t* pReadSize*/)
{
	int nResult = -1;

	bs201SensorMode(MODE_IDLE);
	bs201SensorSoftReset();
	bs201SensorMode(MODE_FG_CAP);

	if (bs201_wait_detect())
	{
		bs201SensorMode(MODE_FG_PRINT);
		if (0 == BEP_ReadPixelData(REGA_FINGER_CAP, pData, nWidth * nHeight))
			nResult = 0;
	}

	bs201SensorMode(MODE_IDLE);
	bs201SensorSoftReset(); // ÿ�β���ͼ����λһ��
	return nResult;
}
  
void bs201SetSensorROIto16x16(void)
{
	//SetSensorROI(25,33,48,48); // 48x48
	SetSensorROI(41, 49, 16, 16); //(96-48)/2+1,(112-48)/2+1	 16x16
	bs201_WriteSingleCmd(0x17, 0x2c);
	bs201_WriteSingleCmd(0x0d, 0x03);
	bs201_WriteSingleCmd(0x17, 0xac);
}

void bs201SetSensorROIto16x16_at_point(int short_offset, int long_offset)
{
	SetSensorROI(short_offset + 1, long_offset + 1, 16, 16);
	bs201_WriteSingleCmd(0x17, 0x2c);
	bs201_WriteSingleCmd(0x0d, 0x03);
	bs201_WriteSingleCmd(0x17, 0xac);
}

void bs201SetSensorROIto112x96(void)
{ 
	SetSensorROI(1,1,96,112); //(96-96)/2+1,(112-112)/2+1
	bs201_WriteSingleCmd(0x17,0x2c);
	bs201_WriteSingleCmd(0x0d,0x1b);
	bs201_WriteSingleCmd(0x17,0xac);
}


void bs201_tune_param(unsigned int param)
{
	if (param != 0)
	{
		gParam.dacp_val = (unsigned char)(param >> 0);
		gParam.reg31_val = (unsigned char)(param >> 8);
		gParam.reg32_val = (unsigned char)(param >> 16);

		bs201_WriteSingleCmd(0x31, gParam.reg31_val);
		bs201_WriteSingleCmd(0x32, gParam.reg32_val);
		bs201_WriteSingleCmd(0x1b, gParam.dacp_val);
	}
}
