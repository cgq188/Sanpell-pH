
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __BL_SPI_H
#define __BL_SPI_H

/* Includes ------------------------------------------------------------------*/
#include <stdint.h>
//#define CHIP_XZ5183
//#define DUMMY_BYTE		0x00
                      
//{ stub for all chips
int bs201_WriteSingleCmd(uint8_t nRegID, uint8_t nCmdID);
int bs201_ReadSingleCmd(uint8_t nRegID, uint8_t *pData);
int BEP_ReadPixelData(const unsigned char addr, unsigned char* buffer, const unsigned int num);

#endif

/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/
