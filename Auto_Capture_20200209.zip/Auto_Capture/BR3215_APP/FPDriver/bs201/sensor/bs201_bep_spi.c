
#include <bs201/sensor/bs201_bep_spi.h>
#include <bs201/sensor/xz_sensor.h>

#include "bs201_api.h"
#include "fpspi.h"

 
int bs201_WriteSingleCmd(uint8_t nRegID, uint8_t nCmdID)
{
	int nResult = -1;

  SpiCSSet(0); 
	nResult = bs201SpiSendByte((nRegID << 1) | 0x80);
	if (nResult != 0) 
	{
		return nResult;
	}  
	
	nResult = bs201SpiSendByte(nCmdID);
	if (nResult != 0) 
	{ 	
		return nResult;
	} 
  SpiCSSet(1);
	return 0;
}


int bs201_ReadSingleCmd(uint8_t nRegID, uint8_t *pData)
{
	int nResult = -1;

  SpiCSSet(0);
	// 1 write addr, 
	nResult = bs201SpiSendByte((nRegID << 1) & 0x7f);
	if (nResult != 0) return nResult;
	
	// 2 write dummy and recv valid data
	nResult = bs201SpiRevByte(pData, 1);
	if (nResult != 0) return nResult;

	SpiCSSet(1);
	return 0;
}  

int BEP_ReadPixelData(const unsigned char addr, unsigned char *buffer, const unsigned int num)
{
	int nResult = -1;
	
	SpiCSSet(0); 
	bs201SpiSendByte((addr << 1) & 0x7f);
	bs201SpiSendByte(DUMMY_BYTE);
	nResult = Fp_SpiRcvByteN(buffer, num) ? 0 : -1;
	//nResult = bs201SpiRevByte(buffer, num);
	SpiCSSet(1);	
	return  nResult;
}
 
