 
 /* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __BL_FUN_H
#define __BL_FUN_H
#include <stdint.h>
#include "bs201_sensor.h"

typedef struct BL_SENSOR_STATUS_tag
{
	uint8_t nWorkMode;
	uint32_t nChipID;	
} bs201_SENSOR_STATUS;

extern volatile bs201_SENSOR_STATUS g_bs201Sensor;
#define IMAGE_WIDTH		112
#define IMAGE_HEIGHT	96

int bs201SensorInit(void);
int bs201SensorSoftReset(void);
int bs201SensorMode(int nMode);
int bs201SensorGetChipId(void);
void bs201SetSensorROIto16x16(void);
void bs201SetSensorROIto16x16_at_point(int short_offset, int long_offset);
void bs201SetSensorROIto112x96(void);//wy@20170609
int bs201CaptureImageEx(uint8_t* pData, uint16_t nWidth, uint16_t nHeight);//wy@20170609
int bs201_capture_whole_image(void* pImg);
int bs201_capture_block_image(void* pImg, int short_offset, int long_offset);
int bs201_wait_detect(void);
void bs201_tune_param(unsigned int param);

#endif /* __BL_FUN_H */

/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/
