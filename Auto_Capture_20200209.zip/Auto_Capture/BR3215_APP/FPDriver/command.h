/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __COMMEND_H
#define __COMMEND_H
/* Includes ------------------------------------------------------------------*/
#include "Type.h"
#include "protocol.h"

/************************************************************************/
/*                                                                      */
/************************************************************************/

enum
{
	CMD_NONE = 0x00,
	CMD_OPEN = 0x01,
	CMD_CLOSE = 0x02,
	CMD_USB_INTERNAL_CHECK = 0x03,
	CMD_CHANGE_BAUDRATE = 0x04,

	CMD_ENROLL_COUNT = 0x20,
	CMD_CHECK_ENROLLED = 0x21,
	CMD_ENROLL_START = 0x22,
	CMD_ENROLL1 = 0x23,
	CMD_ENROLL2 = 0x24,
	CMD_ENROLL3 = 0x25,
	CMD_IS_PRESS_FINGER = 0x26,
	CMD_ENROLL_FINISH = 0x27,

	CMD_DELETE = 0x40,
	CMD_DELETE_ALL = 0x41,

	CMD_VERIFY = 0x50,
	CMD_IDENTIFY = 0x51,
	CMD_VERIFY_TEMPLATE = 0x52,
	CMD_IDENTIFY_TEMPLATE = 0x53,

	CMD_CAPTURE = 0x60,
	CMD_MAKE_TEMPLATE = 0x61,
	CMD_GET_IMAGE = 0x62,
	CMD_GET_RAWIMAGE = 0x63,
	CMD_DOWNLOAD_IMAGE = 0x64,

	CMD_GET_TEMPLATE = 0x70,
	CMD_ADD_TEMPLATE = 0x71,

	CMD_FW_UPDATE = 0x80,

	CMD_WRITE_LICENSE = 0x90,
	CMD_READ_IMEI_INFO = 0x91,

	ACK_OK = 0x30,
	NACK_INFO = 0x31,
};

enum
{
	NACK_NONE = 0x1000,
	NACK_TIMEOUT,
	NACK_INVALID_BAUDRATE,
	NACK_INVALID_POS,
	NACK_IS_NOT_USED,
	NACK_IS_ALREADY_USED,
	NACK_COMM_ERR,
	NACK_VERIFY_FAILED,
	NACK_IDENTIFY_FAILED,
	NACK_DB_IS_FULL,
	NACK_DB_IS_EMPTY,
	NACK_TURN_ERR,
	NACK_BAD_FINGER,
	NACK_ENROLL_FAILED,
	NACK_IS_NOT_SUPPORTED,
	NACK_DEV_ERR,
	NACK_CAPTURE_CANCELED,
	NACK_INVALID_PARAM,
	NACK_FINGER_IS_NOT_PRESSED,
};

typedef struct _devinfo
{
	DWORD FirmwareVersion;
	BYTE DeviceSerialNumber[16];
} devinfo;
void oem_command_proc(SB_OEM_PKT* pCmdPkt);
extern void oem_senddata(BYTE* buf, int size);

#define DEVID					(0x1)
#define g_ImageBuffer			AlgBuf

#if defined(BS510_8MM)
#  define RAWIMG_CX	160
#  define RAWIMG_CY	160
#else
#  define RAWIMG_CX	96
#  define RAWIMG_CY	112
#endif

#define g_ImageBuffer_2			(AlgBuf + RAWIMG_CX*RAWIMG_CY)

#endif /*__COMMEND_H */
