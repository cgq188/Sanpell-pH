
#include "global.h"


#define Fp_SimulateSpi	1 //�Ƿ�ģ���SPI�ӿ�

#if !Fp_SimulateSpi

const SPIConfig Debug_Master_Config = {
	NULL ,//�ص�����
	NULL,//�ӻ��ص�����
	NULL,//??
	6000000,//ͨѶ����
	0,//mode //CPLO = 0,CPHA = 1;
	0,//CSʹ�ܹܽ�
	8,//?????????????????
	SPI_MASTER_MODE,//����
};

#endif

#if Fp_SimulateSpi

#define SPI_FLASH_MISO()						    (!!(SPI_MISO_GRP->DATA & (1u << SPI_MISO_PIN)) )	   // GpioBitIn (GPIOA,  11)
#define SPI_FLASH_SCK_L()							( SPI_CLK_GRP->DATAOUT &= ~(1u << SPI_CLK_PIN))	   // GpioBitOut(GPIOA,  10,0)
#define SPI_FLASH_SCK_H()							(SPI_CLK_GRP->DATAOUT |= (1u << SPI_CLK_PIN))     // GpioBitOut(GPIOA,  10,1)
#define SPI_FLASH_MOSI_L()							( SPI_MOSI_GRP->DATAOUT &= ~(1u << SPI_MOSI_PIN))	   // GpioBitOut(GPIOA,  12,0)
#define SPI_FLASH_MOSI_H()							( SPI_MOSI_GRP->DATAOUT |= (1u << SPI_MOSI_PIN)  )	   // GpioBitOut(GPIOA,  12,1)


/******************************************************************
 - ����������IOģ��SPI��SPI�ӿڳ�ʼ��
 - ����ģ�飺
 - �������ԣ��ڲ�
 - ����˵������
 - ����˵�����޷���
 - //ע��
 ******************************************************************/
void SPI_INIT(void)
{
	// SPI_FLASH_SCK   A10
	GPIO_Init(SPI_CLK_GRP, SPI_CLK_PIN, GPIO_OUTPUT);
	// SPI_FLASH_MOSI  A12
	GPIO_Init(SPI_MOSI_GRP, SPI_MOSI_PIN, GPIO_OUTPUT);
//	// SPI_FLASH_NSS   E2
//	GPIO_Init(GPIOE, 2, GPIO_OUTPUT);
	// SPI_FLASH_MISO  A11
	GPIO_Init(SPI_MISO_GRP, SPI_MISO_PIN, GPIO_INPUT);

//	SPI_CS_OUTPUT();
//	SPI_RST_OUTPUT();
}

UINT8 SPI_SendWriteByte(UINT8 byte)
{
    unsigned char i;
    SPI_FLASH_SCK_L();
////    NOP(); NOP(); NOP(); NOP();
//    NOP();
   for(i=0; i<8; i++)
   {
       if(byte & 0x80)//((byte & 0x80)== 0x80)
       {
       	SPI_FLASH_MOSI_H();
       }
       else
       {
       	SPI_FLASH_MOSI_L();
       }
           SPI_FLASH_SCK_H();     //toggle clock high
           byte <<= 1;

           // __NOP();__NOP();__NOP();__NOP();
           //_delay_us(4);

           if(SPI_FLASH_MISO())
                   {
                       byte |= 1;	//Wait SDO to go Hi
                   }
    //       NOP();
////            NOP(); NOP(); NOP(); NOP(); NOP();
           SPI_FLASH_SCK_L();
   }
   return byte;
}


UINT8 SPI_RcvByte(void)
{
    UINT8 byte;
    UINT8 i;
    byte=0;
    SPI_FLASH_SCK_L();
//    NOP(); NOP(); NOP(); NOP();
 //   NOP();
    for (i=0; i<8; i++)
    {
        byte <<= 1;
        SPI_FLASH_SCK_H();
//        NOP(); NOP();
//        NOP(); NOP();
 //       NOP();
        if(SPI_FLASH_MISO())
        {
            byte |= 1;	//Wait SDO to go Hi
        }
//        NOP(); NOP(); NOP(); NOP();
//        NOP(); NOP(); NOP(); NOP();
  //      NOP();
        SPI_FLASH_SCK_L();
    }

    return byte;
}

#endif

void SPI_Init(void)
{
	palSetPadMode(SPI_MISO_GRP,   SPI_MISO_PIN,   PAL_MODE_INPUT  | PAL_MODE_ALTERNATE(PAD_FUNC_SPI0_MISO) | PAL_MODE_DRIVE_CAP(0));
	palSetPadMode(SPI_MOSI_GRP,   SPI_MOSI_PIN,   PAL_MODE_OUTPUT | PAL_MODE_ALTERNATE(PAD_FUNC_SPI0_MOSI) | PAL_MODE_DRIVE_CAP(3));
	palSetPadMode(SPI_CLK_GRP,    SPI_CLK_PIN,    PAL_MODE_OUTPUT | PAL_MODE_ALTERNATE(PAD_FUNC_SPI0_SCK)  | PAL_MODE_DRIVE_CAP(3));
	palSetPadMode(SPI_CSN_GRP,    SPI_CSN_PIN,    PAL_MODE_OUTPUT | PAL_MODE_ALTERNATE(PAD_FUNC_GPIO)      | PAL_MODE_DRIVE_CAP(3));
	palSetPadMode(SensorRest_GRP, SensorRest_PIN, PAL_MODE_OUTPUT | PAL_MODE_ALTERNATE(PAD_FUNC_GPIO)      | PAL_MODE_DRIVE_CAP(3));
#if !Fp_SimulateSpi
	spiStart(&SPID0, &Debug_Master_Config);
#endif
}

#if !Fp_SimulateSpi
void SPI_Transceive(SPIDriver *spip,  void *txrxbuf)
{

	//	 spiExchange(&SPID0,1,(const void *)&byte,&RX_Data);
	spiExchange(spip, 1, (const void *)txrxbuf,txrxbuf);
}
#endif



void Fp_Spi_Init(void)
{
#if Fp_SimulateSpi
	SPI_INIT();
#else
    SPI_Init();
#endif

}

BOOL Fp_SpiSendByte(UINT8 Data)
{
	UINT8 TmpData = Data;
#if Fp_SimulateSpi
    __disable_irq();
	SPI_SendWriteByte(TmpData);
    __enable_irq();
#else
	SPI_Transceive(&SPID0, &TmpData);
#endif
	return TRUE;
}

BOOL Fp_SpiRcvByte(UINT8 *pData)
{
#if Fp_SimulateSpi
	__disable_irq();
	*pData = SPI_RcvByte();
	__enable_irq();
#else
	SPI_Transceive(&SPID0, pData);
#endif
	return TRUE;
}

BOOL Fp_SpiRcvByteN(UINT8* pData, int n)
{
    int i;
    for (i=0; i<n; i++)
    {
		__disable_irq();
		UINT32 clkd = SPI_CLK_GRP->DATAOUT;
		UINT32 clk0 = clkd & ~(1u << SPI_CLK_PIN);
		UINT32 clk1 = clkd | (1u << SPI_CLK_PIN);

#define CLK_L() NOP(); NOP(); NOP(); SPI_CLK_GRP->DATAOUT = clk0; NOP(); NOP(); NOP()
#define CLK_H() NOP(); NOP(); NOP(); SPI_CLK_GRP->DATAOUT = clk1; NOP(); NOP(); NOP()

		UINT8 byte = 0;
        CLK_L();
        CLK_H();
        byte |= ((SPI_MISO_GRP->DATA & (1u << SPI_MISO_PIN)) >> 3);
        CLK_L();
        CLK_H();
        byte |= ((SPI_MISO_GRP->DATA & (1u << SPI_MISO_PIN)) >> 4);
        CLK_L();
        CLK_H();
		byte |= ((SPI_MISO_GRP->DATA & (1u << SPI_MISO_PIN)) >> 5);
        CLK_L();
        CLK_H();
		byte |= ((SPI_MISO_GRP->DATA & (1u << SPI_MISO_PIN)) >> 6);
        CLK_L();
        CLK_H();
		byte |= ((SPI_MISO_GRP->DATA & (1u << SPI_MISO_PIN)) >> 7);
        CLK_L();
        CLK_H();
		byte |= ((SPI_MISO_GRP->DATA & (1u << SPI_MISO_PIN)) >> 8);
        CLK_L();
        CLK_H();
		byte |= ((SPI_MISO_GRP->DATA & (1u << SPI_MISO_PIN)) >> 9);
        CLK_L();
        CLK_H();
		byte |= ((SPI_MISO_GRP->DATA & (1u << SPI_MISO_PIN)) >> 10);
        __enable_irq();

        *pData++ = byte;
	}
	__disable_irq();
	SPI_CLK_GRP->DATAOUT &= ~(1u << SPI_CLK_PIN);
	__enable_irq();

	return TRUE;
}

