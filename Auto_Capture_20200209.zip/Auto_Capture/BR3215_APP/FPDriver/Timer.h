
#ifndef TIMER_H_
#define TIMER_H_
#include"Type.h"
#include "gpt.h"
//-----------------------------------------------------------------------------------
typedef enum
{
TIM_CNT      = 	0x01,
TIM_INT,
TIM_WDT
}TIM_Mode;
#if (HAL_USE_GPT == TRUE) || defined(__DOXYGEN__)
#define TIMXENABLE 1
#else
#define TIMXENABLE 0
#endif

#if (TIMXENABLE)
typedef GPTDriver * TIM_TypeDef;
#if HS_GPT_USE_TIM0
#define TIM0 (&GPTD0)
#else
#define TIM0 ((TIM_TypeDef)(0xAAAAf001))
#endif
#if HS_GPT_USE_TIM1
#define TIM1 (&GPTD1)
#else
#define TIM1 ((TIM_TypeDef)(0xAAAAf002))
#endif
#if HS_GPT_USE_TIM2
#define TIM2 (&GPTD2)
#else
#define TIM2 ((TIM_TypeDef)(0xAAAAf003))
#endif
#else
typedef void * TIM_TypeDef;
//#define TIM0 ((TIM_TypeDef)(0xAAAAf001))
//#define TIM1 ((TIM_TypeDef)(0xAAAAf002))
//#define TIM2 ((TIM_TypeDef)(0xAAAAf003))


#define TIMS0 ((TIM_TypeDef)(0xffffA501))
#define TIMS1 ((TIM_TypeDef)(0xffffA502))
#define TIMS2 ((TIM_TypeDef)(0xffffA503))
#define TIMWGT ((TIM_TypeDef)(NULL))

#define TIM0 (TIMS0)
#define TIM1 (TIMS1)
#define TIM2 (TIMS2)


#endif



#define TIMSMASK (0xffffA500)
#define TIMSNUM(TIM) (((UINT32)TIM)&(!TIMSMASK))


BOOL TIM_Init(TIM_TypeDef _TIMx, UINT32 _Limit, UINT16 _Prescale, TIM_Mode _TIM_Mode);
BOOL TIM_Start(TIM_TypeDef _TIMx);
BOOL TIM_Stop(TIM_TypeDef _TIMx);
BOOL TIM_ClearValue(TIM_TypeDef _TIMx);
UINT32 TIM_GetValue(TIM_TypeDef _TIMx);


#endif /*TIMER_H_*/

