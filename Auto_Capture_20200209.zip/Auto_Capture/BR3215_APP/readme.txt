*****************************************************************************
** ChibiOS/HAL OS-less Demo for BR3215cEVB.                                **
*****************************************************************************

** TARGET **

The demo runs on a HS BR3215cEVB board.

** The Demo **

The demo is an example of HAL use without underlying operating system, it uses
a bare-metal OSAL implementation for AndesCore.



 