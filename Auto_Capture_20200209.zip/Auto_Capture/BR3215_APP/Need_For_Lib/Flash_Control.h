#define SUCCESS 1
#define FAILED 0
//---------------------------------------------------------------------------------------------------//
// Purpose   : Read Data From Flash
// Function  : Read_Flash_Data
// Arguments :
//			(In) : int Data_Position : Relative Start Position of data
//			(In) : int Byte_Len : Data Length; It can large than 4KB.
//			(In) : int Block_Type : FLASH_BANK1 -> 2KB Block, FLASH_BANK2 -> 4KB Block
//	(In/Out) : BYTE* dst : Destination Memory Address.
// Return    : int
//			   return SUCCESS or FAILED.
//---------------------------------------------------------------------------------------------------//
extern int Read_Flash_Data_For_Lib(int Data_Position, int Byte_Len, unsigned char* dst);
//---------------------------------------------------------------------------------------------------//
// Purpose   : Write_Flash_Data
//							This fucntion always finish with call Update_Block_Data.
//							This function divides data into serveral blocks.
// Function  : Write_Flash_Data
// Arguments :
//			(In) : BYTE* src : Data Memory Address to be Write
//			(In) : int Data_Positoin : Relative Start Position of data
//			(In) : int Byte_Len : Data Length; It can large than 4KB.
// Return    : int
//			   return SUCCESS or FAILED.
//---------------------------------------------------------------------------------------------------//
extern int Write_Flash_Data_For_Lib(unsigned char* src, int Data_Position, int Byte_Len);

extern void Mem_Seg_Initialize(BYTE* membuf);

extern void read_uid_For_Lib(BYTE* uid_address);
