
#ifndef	_GLOBALINC_H_
#define _GLOBALINC_H_

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "Type.h"

#include "FpRecognitionLibrary.h"
#include "GlobalVar.h"
#include "Flash_Control.h"

#endif //_GLOBALINC_H_
