#ifndef __FPRECOGNITIONLIBRARY_H
#define __FPRECOGNITIONLIBRARY_H

#ifdef __cplusplus
extern "C" {
#endif

#ifndef FOR_DSP
#define FOR_DSP
#endif

/********** Return Codes ***********/
#define FPLIB_SUCCESS 					(1)
#define FPLIB_FAILED					(FPLIB_SUCCESS-1)
#define FPLIB_BAD_IMGAGE				(FPLIB_FAILED-1)
#define FPLIB_ALREADY_ENROLLED			(FPLIB_BAD_IMGAGE-1)
#define LICENCE_ERROR -1

/********** Variables ***********/
extern unsigned char* Free_Memory;

/********** Functions ***********/

int Get_Person_Limit(void);
int Check_Memory(void);
//---------------------------------------------------------------------------------------------------//
// Purpose   : This function initializes Fingerprint Algorithm Library and loads Enrolled Fingerprint Characters
// Function  : FpLib_Start
// Arguments :
// Return    : int
//			   If sucessful, return FPLIB_SUCCESS, else error code;
//             error code :
//                  FPLIB_FAILED :
//---------------------------------------------------------------------------------------------------//
extern int FpLib_Initialize(void);
//---------------------------------------------------------------------------------------------------//
// Purpose   : This function extracts fingerprint characters from image and stores into RAM
// Function  : FpLib_Enroll
// Arguments :
//		(In) : unsigned char *image : raw format
//		(In) : int Person_ID : Person ID
//  (In/Out) : int *Enrolled_ID : if Enroll is successful, return Enrolled_ID of Person_ID's fingerprint else return -1
//  (In/Out) : int *Enrolled_Percent : if Enroll is successful, return Enrolled_Percent of Person_ID's fingerprint else return -1
// Return    : int
//			   If sucessful, return FPLIB_SUCCESS, else error code;
//             error code :
//                  FPLIB_BAD_IMGAGE :
//                  FPLIB_FAILED :
//---------------------------------------------------------------------------------------------------//
extern int FpLib_Enroll(unsigned char *image, int Person_ID, int *Enrolled_ID, int *Enrolled_Percent);
//---------------------------------------------------------------------------------------------------//
// Purpose   : This function extracts fingerprint characters from image and stores into RAM
// Function  : FpLib_Study
// Arguments :
//		(In) : int Person_ID : Person ID
//  (In/Out) : int *Enrolled_ID : if Study is successful, return Enrolled_ID of Person_ID's fingerprint else return -1
// Return    : int
//			   If sucessful, return FPLIB_SUCCESS, else error code;
//             error code :
//                  FPLIB_BAD_IMGAGE :
//                  FPLIB_FAILED :
//---------------------------------------------------------------------------------------------------//
extern int FpLib_Study(int Person_ID, int *Enrolled_ID);
//---------------------------------------------------------------------------------------------------//
// Purpose   : This function generates fingerprint characters from image and
//										matches against with appointed person in DB
// Function  : FpLib_Verify
// Arguments :
//		(In) : unsigned char *image : raw format
//		(In) : int Person_ID : ID of Person to be matched
//  (In/Out) : int *Enrolled_ID : if Verify is successful, return Enrolled_ID of Person_ID's fingerprint else return -1
// Return    : int
//			   If sucessful, return FPLIB_SUCCESS, else error code;
//             error code :
//                  FPLIB_BAD_IMGAGE :
//                  FPLIB_FAILED :
//---------------------------------------------------------------------------------------------------//
extern int FpLib_Verify(unsigned char *image, int Person_ID, int *Enrolled_ID, int *Study_Flag);
//---------------------------------------------------------------------------------------------------//
// Purpose   : This function generates fingerprint characters from image and
//										searches against with DB
// Function  : FpLib_Identify
// Arguments :
//		(In) : unsigned char *image : raw format
//	(In/Out) : int *Person_ID : if searching is successful, return Person_ID, else return -1
//  (In/Out) : int *Enrolled_ID : if searching is successful, return Enrolled_ID of Person_ID's fingerprint else return -1
// Return    : int
//			   If successful, return FPLIB_SUCCESS, else error code;
//             error code :
//                  FPLIB_BAD_IMGAGE :
//                  FPLIB_FAILED :
//---------------------------------------------------------------------------------------------------//
extern int FpLib_Identify(unsigned char *image, int *Person_ID, int *Enrolled_ID, int *Study_Flag);
//---------------------------------------------------------------------------------------------------//
// Purpose   : This function delete a person's fingerprint database
// Function  : FpLib_Delete
// Arguments :
// Return    : int
//			   return FPLIB_SUCCESS or FPLIB_FAILED
//---------------------------------------------------------------------------------------------------//
extern int FpLib_Delete(int Person_ID);
//---------------------------------------------------------------------------------------------------//
// Purpose   : This function clears fingerprint database
// Function  : FpLib_Reset
// Arguments :
// Return    : int
//			   return FPLIB_SUCCESS or FPLIB_FAILED;
//---------------------------------------------------------------------------------------------------//
extern int FpLib_Resest(void);
//---------------------------------------------------------------------------------------------------//
// Purpose   : This function get Version Information
// Function  : FpLib_Get_Information
// Arguments :
//	(In/Out) : unsigned char* Info :
//							0 -> Person_Limit
//							1 -> Major_Version
//							2,3 -> Minor Version
// Return    : int
//			   return FPLIB_SUCCESS
//---------------------------------------------------------------------------------------------------//
extern int FpLib_Get_Information(unsigned char* Info);
//---------------------------------------------------------------------------------------------------//
// Purpose   : This function get Enrolled Information
// Function  : FpLib_Get_Enrolled_State
// Arguments :
//	(In/Out) : BYTE* Enroll_State : Size must be Person_Limit+1
//								0 -> Enrolled Count
//								1 ~ Enrolled_Count -> Enrolled_ID List
// Return    : int
//			   return FPLIB_SUCCESS
//---------------------------------------------------------------------------------------------------//
extern int FpLib_Get_Enrolled_State(unsigned char* Enroll_State);
extern int FpLib_Set_Enroll_Finish(int Person_ID);

extern void FpLib_Get_Imei_Info(unsigned char* uid_membuf);
extern void FpLib_Write_License(unsigned char* license_data);

#ifdef __cplusplus
}
#endif

#endif
