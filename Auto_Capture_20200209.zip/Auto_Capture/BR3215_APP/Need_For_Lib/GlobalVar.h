#ifndef _GLOBALVAR_H_
#define _GLOBALVAR_H_

#include "Type.h"

// Add By Star 190326
extern int Mem_Seg_Count;
extern int Mem_Seg_Pos[10];
extern int Mem_Seg_Length[10];
extern int Mem_Seg_Page_Size[10];
extern int Mem_Seg_Type[10];
// =============

extern BYTE*					SHARED_MEM_BUF;

extern WORD 					FP_IMG_XSIZE;
extern WORD 					FP_IMG_YSIZE;

extern int 						g_MatchedPersonID;
extern int 						g_StudyFlag;
extern int						g_Mx_Score;
extern int						g_Mx_Start_Time;

extern const int				Manager_Count;
extern const int				Safty_Level;

void engine_poll(void);

#endif	//_GLOBALVAR_H_
