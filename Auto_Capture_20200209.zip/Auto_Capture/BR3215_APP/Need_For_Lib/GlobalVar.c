#include "GlobalVar.h"

// Add By Star 190326
int Mem_Seg_Count;
int Mem_Seg_Pos[10];
int Mem_Seg_Length[10];
int Mem_Seg_Page_Size[10];
int Mem_Seg_Type[10];
// =============

BYTE*						SHARED_MEM_BUF; /// 37KB

WORD 						FP_IMG_XSIZE = 96;
WORD 						FP_IMG_YSIZE = 112;

int 						g_MatchedPersonID = -1;
int 						g_StudyFlag = 0;
int							g_Mx_Score = 0;
int							g_Mx_Start_Time = -1;

const int					Manager_Count = 2;
const int					Safety_Level = 10;

extern int FpLib_Study(int Person_ID, int *Enrolled_ID);
void engine_poll(void)
{
	if (g_StudyFlag == 1) {
		int Enrolled_ID;
		FpLib_Study(g_MatchedPersonID, &Enrolled_ID);
		g_StudyFlag = 0;
	}
}
