#include "global_for_lib.h"
#include "SerialFlash.h"
#include "command.h"
#include "main.h"

#define ALL_FLASH_LENGTH 0x100000
#define BOOT_FLASH_LENGTH 0x10000
#define SYS_FLASH_LENGTH 0x1000

#define FIRM_WARE_LENGTH FW_MAX_SIZE
#define FLASH_START_ADDRESS 0

//---------------------------------------------------------------------------------------------------//
// Purpose   : Initialize Memory Segments
//				There may be serveral segments.
//				We reset all Start Position and Length of Segment to multiple of Page Size of that segment
// Function  : Mem_Seg_Initialize
// Arguments :
//				Mem_Seg_Count		: the Count of Memory Segment
//				Mem_Seg_Pos			: the Physical Address of start of Memory Segment
//				Mem_Seg_Page_Size	: the Page Size of Device onwhich Memory Segment take place.
//										Every Memory Segment can be long but It's page size must be one type.
//				Mem_Seg_Type		: Now we devide 2 type. Bacause upper level code is different.
// Return    :
//---------------------------------------------------------------------------------------------------//
void Mem_Seg_Initialize(BYTE* membuf){
	Mem_Seg_Count = 1;
	Mem_Seg_Pos[0] = FLASH_START_ADDRESS + BOOT_FLASH_LENGTH + FIRM_WARE_LENGTH;
	Mem_Seg_Length[0] = ALL_FLASH_LENGTH - BOOT_FLASH_LENGTH - SYS_FLASH_LENGTH - FIRM_WARE_LENGTH;

	Mem_Seg_Pos[5] = Mem_Seg_Pos[0] + Mem_Seg_Length[0] - 2222;

	Mem_Seg_Page_Size[0] = 4 * 1024;
	Mem_Seg_Type[0] = 1;

	SHARED_MEM_BUF = membuf;
}

void UID_Initialize(void){

}

//---------------------------------------------------------------------------------------------------//
// Purpose   : Read Data From Flash
//				This function devide to memory segments and then always call Data_Block_Read.
// Function  : Read_Flash_Data_For_Lib
// Arguments :
//			(In) : int Data_Position : Relative Start Position of Data.
//			(In) : int Byte_Len : Data Length; It can be long.
//		(In/Out) : BYTE* dst : Destination Memory Address on RAM.
// Return    : int
//			   return SUCCESS or FAILED.
//---------------------------------------------------------------------------------------------------//
int Read_Flash_Data_For_Lib(int Data_Position, int Byte_Len, BYTE* dst){
	//dUart_Printf("%s: %x, %d\r\n", __func__, Data_Position, Byte_Len);
	//Flash_ReadInfo(dst, FIRM_WARE_LENGTH + Data_Position, Byte_Len);
	memcpy(dst, (void*)(Mem_Seg_Pos[0] + Data_Position), Byte_Len);
	return SUCCESS;
}

//---------------------------------------------------------------------------------------------------//
// Purpose   : Write_Flash_Data
//				This function divides data into serveral Memory Segments and then always call Update_Flash_Data.
// Function  : Write_Flash_Data_For_Lib
// Arguments :
//			(In) : BYTE* src : Data Memory Address on RAM to be Write
//			(In) : int Data_Positoin : Relative Start Position of data
//			(In) : int Byte_Len : Data Length; It can be long.
// Return    : int
//			   return SUCCESS or FAILED.
//---------------------------------------------------------------------------------------------------//
int Write_Flash_Data_For_Lib(BYTE* src, int Data_Position, int Byte_Len){
	//dUart_Printf("%s: %x, %d\r\n", __func__, Data_Position, Byte_Len);
	Flash_WriteInfo(src, Mem_Seg_Pos[0] + Data_Position, Byte_Len);
	return SUCCESS;
}

extern void read_uid(BYTE* uid_address);
void read_uid_For_Lib(BYTE* uid_address){
	read_uid(uid_address);
}
