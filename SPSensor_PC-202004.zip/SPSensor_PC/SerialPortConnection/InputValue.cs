﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PHPCTool
{
    partial class InputValue : Form
    {
        public float Value { get; set; }
        public DialogResult result { get; set; }
        
        public InputValue()
        {
            InitializeComponent();
        }

        public InputValue(String _msg, float _value)
        {
            InitializeComponent();
            this.lblMessage.Text = _msg;
            this.txtValue.Text = _value.ToString();
            Value = _value;
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            try
            {
                Value = float.Parse(this.txtValue.Text);
                result = DialogResult.OK;
                this.Dispose();
            }
            catch
            {
                lblErrMsg.Text = "Please insert correct value.";
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            result = DialogResult.Cancel;
            this.Dispose();
        }
    }
}
