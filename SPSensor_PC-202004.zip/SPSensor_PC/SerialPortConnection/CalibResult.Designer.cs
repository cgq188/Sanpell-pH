﻿namespace PHPCTool
{
    partial class CalibResult
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblCalibType = new System.Windows.Forms.Label();
            this.lblSlope2 = new System.Windows.Forms.Label();
            this.lblSlope1 = new System.Windows.Forms.Label();
            this.lblZeroPoint = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.lblCalibTime = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(43, 41);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 17);
            this.label1.TabIndex = 31;
            this.label1.Text = "Calib Time";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(42, 214);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(71, 17);
            this.label8.TabIndex = 29;
            this.label8.Text = "CalibType";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(42, 171);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(52, 17);
            this.label7.TabIndex = 28;
            this.label7.Text = "Slope2";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(42, 128);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 17);
            this.label6.TabIndex = 27;
            this.label6.Text = "Slope1";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(43, 84);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(74, 17);
            this.label5.TabIndex = 26;
            this.label5.Text = "Zero Point";
            // 
            // lblCalibType
            // 
            this.lblCalibType.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCalibType.Location = new System.Drawing.Point(121, 209);
            this.lblCalibType.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCalibType.Name = "lblCalibType";
            this.lblCalibType.Size = new System.Drawing.Size(223, 25);
            this.lblCalibType.TabIndex = 25;
            this.lblCalibType.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblSlope2
            // 
            this.lblSlope2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSlope2.Location = new System.Drawing.Point(121, 166);
            this.lblSlope2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSlope2.Name = "lblSlope2";
            this.lblSlope2.Size = new System.Drawing.Size(223, 25);
            this.lblSlope2.TabIndex = 24;
            this.lblSlope2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblSlope1
            // 
            this.lblSlope1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSlope1.Location = new System.Drawing.Point(121, 123);
            this.lblSlope1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSlope1.Name = "lblSlope1";
            this.lblSlope1.Size = new System.Drawing.Size(223, 25);
            this.lblSlope1.TabIndex = 23;
            this.lblSlope1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblZeroPoint
            // 
            this.lblZeroPoint.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblZeroPoint.Location = new System.Drawing.Point(121, 80);
            this.lblZeroPoint.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblZeroPoint.Name = "lblZeroPoint";
            this.lblZeroPoint.Size = new System.Drawing.Size(224, 25);
            this.lblZeroPoint.TabIndex = 22;
            this.lblZeroPoint.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button1
            // 
            this.button1.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.button1.Location = new System.Drawing.Point(171, 262);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(105, 37);
            this.button1.TabIndex = 32;
            this.button1.Text = "OK";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // lblCalibTime
            // 
            this.lblCalibTime.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCalibTime.Location = new System.Drawing.Point(120, 37);
            this.lblCalibTime.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCalibTime.Name = "lblCalibTime";
            this.lblCalibTime.Size = new System.Drawing.Size(224, 25);
            this.lblCalibTime.TabIndex = 33;
            this.lblCalibTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CalibResult
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(400, 324);
            this.ControlBox = false;
            this.Controls.Add(this.lblCalibTime);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lblCalibType);
            this.Controls.Add(this.lblSlope2);
            this.Controls.Add(this.lblSlope1);
            this.Controls.Add(this.lblZeroPoint);
            this.MaximumSize = new System.Drawing.Size(418, 371);
            this.MinimumSize = new System.Drawing.Size(418, 371);
            this.Name = "CalibResult";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "CalibResult";
            this.Load += new System.EventHandler(this.CalibResult_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblCalibType;
        private System.Windows.Forms.Label lblSlope2;
        private System.Windows.Forms.Label lblSlope1;
        private System.Windows.Forms.Label lblZeroPoint;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lblCalibTime;
    }
}