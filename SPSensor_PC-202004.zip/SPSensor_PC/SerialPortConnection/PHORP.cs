﻿using System;
using System.IO.Ports;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using INIFILE;
using System.Text.RegularExpressions;
using System.Drawing.Text;
using System.Globalization;
using PHPCTool;

namespace SerialPortConnection
{
    public partial class PHORP : Form
    {

        private static readonly byte[] ADDRESS_CODE = { 1, 2, 10, 20, 30, 40, 50};
        private static readonly byte[] DATA_LENGTH = { 1, 1, 10, 10, 10, 10, 1};

        private int setting_command_index = 0;
        private int device_command_index = 2;
        private List<byte> receive_buffer_arr = new List<byte>();
        enum CommandState 
        {
            INIT_STATE = 1, 
            READ_DEVICE_ID, READ_BAUD_RATE, READ_HW_VERSION, READ_FW_VERSION, READ_SN_NUMBER, READ_MF_NUMBER, READ_RPODUCT_NUMBER, READ_DATE_TIME,
            WRITE_DEVICE_ID, WRITE_BAUD_RATE, WRITE_HW_VERSION, WRITE_FW_VERSION, WRITE_SN_NUMBER, WRITE_MF_NUMBER, WRITE_RPODUCT_NUMBER, WRITE_DATE_TIME,
            MONITOR_PH, MONITOR_TEMP, MONITOR_ORP, READ_LATEST_PH_CALIB, READ_LATEST_ORP_CALIB, WRITE_PH_CALIB_TIME, WRITE_PH_FIRST_BUFFER, WRITE_PH_SECOND_BUFFER, WRITE_PH_THIRD_BUFFER, 
            WRITE_ACTION_CODE, READ_RESULT_CODE, WRITE_ORP_CALIB_TIME, WRITE_ORP_POINT1, WRITE_ORP_POINT2, WRITE_ORP_POINT3,
            WRITE_PH_MANUAL_CALIB_TIME, WRITE_PH_MANUAL_ZERO_POINT, WRITE_PH_MANUAL_ACID_SLOPE, WRITE_PH_MANUAL_BASIC_SLOPE, WRITE_PH_MANUAL_ACTION_CODE,
            READ_SENSOR_NAME, READ_SENSOR_MANUFACTURER, READ_SENSOR_SERIAL_NUMBER, READ_SOFTWARE_VERSION, READ_SENSOR_MEASURE_TYPE,
            WRITE_SENSOR_NAME, WRITE_SENSOR_MANUFACTURER, WRITE_SENSOR_SERIAL_NUMBER, WRITE_SOFTWARE_VERSION, WRITE_SENSOR_MEASURE_TYPE,
            READ_LATEST_TEMP_CALIB, WRITE_TEMP_CALIB_TIME, WRITE_TEMP_RES_POINT1, WRITE_TEMP_RES_POINT2, READ_RESULT_CODE_TEMP,
            READ_PH_RESULT_CODE, READ_ORP_RESULT_CODE, READ_MANUAL_RESULT_CODE, READ_TEMP_RESULT_CODE,
            READ_MTC_TEMPERATURE, READ_TEMPER_STATUS, WRITE_MTC_TEMPERATURE,
            WRITE_TEMPERATURE_MODE, WRITE_TEMP_BIAS, READ_TEMP_BIAS, WRITE_ORP_BIAS, READ_ORP_BIAS,
            PH_CALIB_READ_PROBE, PH_CALIB_WRITE_TIME, PH_CALIB_RUN, PH_CALIB_READ_RESULT, PH_CALIB_READ_LATEST,
            ORP_CALIB_READ_PROBE, ORP_CALIB_WRITE_TIME, ORP_CALIB_RUN, ORP_CALIB_READ_RESULT, ORP_CALIB_READ_LATEST,
            TEMP_CALIB_READ_RES1, TEMP_CALIB_READ_RES2, TEMP_CALIB_WRITE_TIME, TEMP_CALIB_RUN, TEMP_CALIB_READ_RESULT, TEMP_CALIB_READ_LATEST
        };

        enum CalibrationStep
        {
            PH_CALIB_START, PH_CALIB_FIRST, PH_CALIB_SECOND, PH_CALIB_THIRD
        };
        enum ORPCalibrationStep
        {
            ORP_CALIB_START, ORP_CALIB_FIRST, ORP_CALIB_SECOND, ORP_CALIB_THIRD
        };
        CalibrationStep calibrationStep = CalibrationStep.PH_CALIB_START;
        ORPCalibrationStep orpCalibStep = ORPCalibrationStep.ORP_CALIB_START;

        CommandState commandState = CommandState.INIT_STATE;
        
        SerialPort mSerialPort = new SerialPort();
        List<Button> _readButtons = new List<Button>();
        List<Button> _writeButtons = new List<Button>();

        private int ph_tmeperature_flag = 1;
        private string log_str = "";

        byte device_id = 0x01;
        int device_baud_rate;

        private PHCalibValue pHCalibValue;
        private ORPCalibValue orpCalibValue;
        private TempCalibValue tempCalibValue;

        public PHORP()
        {
            InitializeComponent();
            BindButtons();
            //dateTimePicker.Format = DateTimePickerFormat.Custom;
            //dateTimePicker.CustomFormat = "yyyy/MM/dd hh:mm:ss";
            pHCalibValue = new PHCalibValue();
            orpCalibValue = new ORPCalibValue();
            tempCalibValue = new TempCalibValue();
        }

        private void BindButtons()
        {
            _readButtons.Add(buttonRead1);
            _readButtons.Add(buttonRead2);
            _readButtons.Add(buttonRead3);
            _readButtons.Add(buttonRead4);
            _readButtons.Add(buttonRead5);
            _readButtons.Add(buttonRead6);
            _readButtons.Add(buttonRead7);

            _writeButtons.Add(buttonWrite1);
            _writeButtons.Add(buttonWrite2);
            _writeButtons.Add(buttonWrite3);
            _writeButtons.Add(buttonWrite4);
            _writeButtons.Add(buttonWrite5);
            _writeButtons.Add(buttonWrite6);
            _writeButtons.Add(buttonWrite7);

            for (int i = 0; i < _readButtons.Count; i++)
            {
                //it's important to have this; closing over the loop variable would be bad
                int index = i;
                _readButtons[i].Click += (sender, args) => ReadButtonClick(_readButtons[index], index);
                _writeButtons[i].Click += (sender, args) => WriteButtonClick(_writeButtons[index], index);
            }
        }

        private object WriteButtonClick(Button button, int index)
        {
            SaveParams();
            if (mSerialPort.IsOpen)
            {
                
                DateTime dt = DateTime.Now;
                string cur_log = dt.ToString("yyyy/MM/dd hh:mm:ss.fff");
                List<short> data = new List<short>();
                switch (index)
                {
                    case 0:
                        commandState = CommandState.WRITE_DEVICE_ID;
                        cur_log += "    Send DeviceID packet --> \t\t\t";
                        int send_device_id = byte.Parse(textSlaveID.Text);
                        data.Add(Convert.ToInt16(send_device_id));
                        //cur_log += "    <-- Received Device ID packet \t\t" + strRcv + "\r\n";
                        break;
                    case 1:
                        commandState = CommandState.WRITE_BAUD_RATE;
                        cur_log += "    Send BaueRate packet --> \t\t\t";
                        device_baud_rate = int.Parse(textBaudRate.Text);
                        short baud_int_val = 0;
                        switch(device_baud_rate)
                        {
                            case 1200:
                                baud_int_val = 0;
                                break;
                            case 2400:
                                baud_int_val = 1;
                                break;
                            case 4800:
                                baud_int_val = 2;
                                break;
                            case 9600:
                                baud_int_val = 3;
                                break;
                            case 19200:
                                baud_int_val = 4;
                                break;
                            case 38400:
                                baud_int_val = 5;
                                break;
                            case 57600:
                                baud_int_val = 6;
                                break;
                            case 115200:
                                baud_int_val = 7;
                                break;
                        }
                        data.Add(baud_int_val);
                        break;
                    case 2:
                        commandState = CommandState.WRITE_SENSOR_NAME;
                        cur_log += "    Send WRITE_SENSOR_NAME packet --> \t\t\t";
                        string sensor_name = textHWVersion.Text;
                        while (sensor_name.Length < 20)
                        {
                            sensor_name += " ";
                        }
                        byte[] hw_buffer = System.Text.Encoding.ASCII.GetBytes(sensor_name);
                        for (int i = 0; i < 20; i+=2)
                        {
                            data.Add(BitConverter.ToInt16(hw_buffer, i));
                        }                        
                        break;
                    case 3:
                        commandState = CommandState.WRITE_SENSOR_MANUFACTURER;
                        cur_log += "    Send WRITE_SENSOR_MANUFACTURER packet --> \t\t\t";
                        string sensor_manu = textFWVersion.Text;
                        while (sensor_manu.Length < 20)
                        {
                            sensor_manu += " ";
                        }
                        byte[] fw_buffer = System.Text.Encoding.ASCII.GetBytes(sensor_manu);
                        for (int i = 0; i < 20; i += 2)
                        {
                            data.Add(BitConverter.ToInt16(fw_buffer, i));
                        }
                        break;
                    case 4:
                        commandState = CommandState.WRITE_SENSOR_SERIAL_NUMBER;
                        cur_log += "    Send WRITE_SENSOR_SERIAL_NUMBER packet --> \t\t\t";
                        string sn = textSerialNumber.Text;
                        while (sn.Length < 20)
                        {
                            sn += " ";
                        }
                        byte[] sn_buffer = System.Text.Encoding.ASCII.GetBytes(sn);
                        for (int i = 0; i < 20; i += 2)
                        {
                            data.Add(BitConverter.ToInt16(sn_buffer, i));
                        }
                        break;
                    case 5:
                        commandState = CommandState.WRITE_SOFTWARE_VERSION;
                        cur_log += "    Send WRITE_SOFTWARE_VERSION packet --> \t\t\t";
                        string mf = textManufactureNumber.Text;
                        while (mf.Length < 20)
                        {
                            mf += " ";
                        }
                        byte[] mf_buffer = System.Text.Encoding.ASCII.GetBytes(mf);
                        for (int i = 0; i < 20; i += 2)
                        {
                            data.Add(BitConverter.ToInt16(mf_buffer, i));
                        }
                        break;
                    case 6:
                        commandState = CommandState.WRITE_SENSOR_MEASURE_TYPE;
                        cur_log += "    Send WRITE_SENSOR_MEASURE_TYPE packet --> \t\t";
                        short pn = short.Parse(textProductNumber.Text);
                        
                        data.Add(pn);
                        break;
                }

                List<byte> command = Command.makeWriteCommand(device_id, ADDRESS_CODE[index], DATA_LENGTH[index], data);
                mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);

                string strSend = null;
                for (int i = 0; i < command.ToArray().Length; i++) //窗体显示
                {
                    strSend += " " + command.ToArray()[i].ToString("X2");  //16进制显示
                }
                cur_log += strSend + "\r\n";
                log_str = cur_log + log_str;
                ShowLog();
            }
            else
            {
                MessageBox.Show("Serial port is closed.");
            }
            return new object();
        }

        private object ReadButtonClick(Button button, int index)
        {
            
            if (!mSerialPort.IsOpen)
            {
                MessageBox.Show("Serial port is closed.");
                return new object();
            }

            DateTime dt = DateTime.Now;
            string cur_log = dt.ToString("yyyy/MM/dd hh:mm:ss.fff");

            switch (index)
            {
                case 0:
                    commandState = CommandState.READ_DEVICE_ID;
                    cur_log += "    Send Read DeviceID commnad --> \t\t";
                    break;
                case 1:
                    commandState = CommandState.READ_BAUD_RATE;
                    cur_log += "    Send Read Baudrate commnad --> \t\t";
                    break;
                case 2:
                    commandState = CommandState.READ_SENSOR_NAME;
                    cur_log += "    Send Read Sensor Name commnad --> \t\t";
                    break;
                case 3:
                    commandState = CommandState.READ_SENSOR_MANUFACTURER;
                    cur_log += "    Send Read SENSOR_MANUFACTURER commnad --> \t\t";
                    break;
                case 4:
                    commandState = CommandState.READ_SENSOR_SERIAL_NUMBER;
                    cur_log += "    Send Read SENSOR_SERIAL_NUMBER commnad --> \t\t";
                    break;
                case 5:
                    commandState = CommandState.READ_SOFTWARE_VERSION;
                    cur_log += "    Send Read SOFTWARE_VERSION commnad --> \t\t";
                    break;
                case 6:
                    commandState = CommandState.READ_SENSOR_MEASURE_TYPE;
                    cur_log += "    Send Read SENSOR_MEASURE_TYPE commnad --> \t";
                    break;
                case 7:
                    commandState = CommandState.READ_DATE_TIME;
                    cur_log += "    Send Read date/time commnad --> \t\t";
                    break;
            }


            List<byte> command = Command.makeReadCommand(device_id, ADDRESS_CODE[index], DATA_LENGTH[index]);
           
            mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);

            string strSend = null;
            for (int i = 0; i < command.ToArray().Length; i++) //窗体显示
            {
                strSend += " " + command.ToArray()[i].ToString("X2");  //16进制显示
            }
            cur_log += strSend + "\r\n";
            log_str = cur_log + log_str;
            ShowLog();

            return new object();
        }

        private void showWriteLog(string str, List<byte> command)
        {
            DateTime dt = DateTime.Now;
            string cur_log = dt.ToString("yyyy/MM/dd hh:mm:ss.fff");
            cur_log += str;
            string strSend = null;
            for (int i = 0; i < command.ToArray().Length; i++) //窗体显示
            {
                strSend += " " + command.ToArray()[i].ToString("X2");  //16进制显示
            }
            cur_log += strSend + "\r\n";
            log_str = cur_log + log_str;
            ShowLog();
        }

        private void SaveParams()
        {
            PHPCTool.Properties.Settings.Default.SensorName = textHWVersion.Text;
            PHPCTool.Properties.Settings.Default.SensorManufacturer = textFWVersion.Text;
            PHPCTool.Properties.Settings.Default.SensorSerialNumber = textSerialNumber.Text;
            PHPCTool.Properties.Settings.Default.SensorSoftwareVersion = textManufactureNumber.Text;
            PHPCTool.Properties.Settings.Default.MeasuredValueType = textProductNumber.Text;
            PHPCTool.Properties.Settings.Default.Save();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            /*
            PrivateFontCollection pfc = new PrivateFontCollection();
            pfc.AddFontFile(Application.StartupPath + @"\digital_display_tfb.ttf");
            textPH.Font = new Font(pfc.Families[0], 30, FontStyle.Regular);
            textTemperature.Font = new Font(pfc.Families[0], 30, FontStyle.Regular);*/
            groupBoxSettingWindow.Enabled = false;
            textHWVersion.Text = PHPCTool.Properties.Settings.Default.SensorName;
            textFWVersion.Text = PHPCTool.Properties.Settings.Default.SensorManufacturer;
            textSerialNumber.Text = PHPCTool.Properties.Settings.Default.SensorSerialNumber;
            textManufactureNumber.Text = PHPCTool.Properties.Settings.Default.SensorSoftwareVersion;
            textProductNumber.Text = PHPCTool.Properties.Settings.Default.MeasuredValueType;

            comboSelectLanguage.SelectedIndex = 0;
            comboSelectLanguage.Enabled = false;
            cbBaudRate.SelectedIndex = 6;
            textBaudRate.SelectedIndex = 6;

            //检查是否含有串口
            string[] str = SerialPort.GetPortNames();
            if (str == null)
            {
                MessageBox.Show("本机没有串口！", "Error");
                return;
            }

            //添加串口项目
            foreach (string s in System.IO.Ports.SerialPort.GetPortNames())
            {//获取有多少个COM口
                //System.Diagnostics.Debug.WriteLine(s);
                comboPort.Items.Add(s);
            }
            comboPort.SelectedIndex = 0;
            
            mSerialPort.BaudRate = 9600;

            Control.CheckForIllegalCrossThreadCalls = false;    //这个类中我们不检查跨线程的调用是否合法(因为.net 2.0以后加强了安全机制,，不允许在winform中直接跨线程访问控件的属性)
            mSerialPort.DataReceived += new SerialDataReceivedEventHandler(mSerialPort_DataReceived);


            //准备就绪              
            mSerialPort.DtrEnable = true;
            mSerialPort.RtsEnable = true;
            //设置数据读取超时为1秒
            mSerialPort.ReadTimeout = 1000;

            mSerialPort.Close();

            btnPHCalibBack.Enabled = false;
            btnPHCalibContinue.Enabled = false;
            btnPHCalibFinish.Enabled = false;
        }

        Byte[] receivedData;
        void mSerialPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            if (mSerialPort.IsOpen)     //此处可能没有必要判断是否打开串口，但为了严谨性，我还是加上了
            {
                //输出当前时间
                DateTime dt = DateTime.Now;
                string cur_log = dt.ToString("yyyy/MM/dd hh:mm:ss.fff");

                try
                {
                    Byte[] receivedbuf = new Byte[mSerialPort.BytesToRead];        //创建接收字节数组
                    mSerialPort.Read(receivedbuf, 0, receivedbuf.Length);         //读取数据
                    
                    //mSerialPort.DiscardInBuffer();                                  //清空SerialPort控件的Buffer
                    for(int i = 0; i < receivedbuf.Length; i++)
                    {
                        receive_buffer_arr.Add(receivedbuf[i]);
                    }

                    
                    bool result = SelectPacket(receive_buffer_arr);
                    if (!result)
                        return;

                    string strRcv = null;
                    
                    for (int i = 0; i < receivedData.Length; i++) //窗体显示
                    {
                        strRcv += " " + receivedData[i].ToString("X2");  //16进制显示
                    }


                    List<byte> data = new List<byte>();
                    switch (commandState)
                    {
                        case CommandState.READ_DEVICE_ID:
                            cur_log += "    <-- Received Device ID packet \t\t\t" + strRcv + "\r\n";
                            device_id = receivedData[4];
                            textSlaveID.Text = device_id.ToString();
                            break;
                        case CommandState.READ_BAUD_RATE:
                            cur_log += "    <-- Received BaudRate packet \t\t\t" + strRcv + "\r\n";
                            //data.Clear();
                            //data.Add(receivedData[6]);
                            //data.Add(receivedData[5]);
                            //int baud_val = System.BitConverter.ToInt16(data.ToArray(), 0);
                            switch (receivedData[4])
                            {
                                case 0:
                                    device_baud_rate = 1200;
                                    break;
                                case 1:
                                    device_baud_rate = 2400;
                                    break;
                                case 2:
                                    device_baud_rate = 4800;
                                    break;
                                case 3:
                                    device_baud_rate = 9600;
                                    break;
                                case 4:
                                    device_baud_rate = 19200;
                                    break;
                                case 5:
                                    device_baud_rate = 38400;
                                    break;
                                case 6:
                                    device_baud_rate = 57600;
                                    break;
                                case 7:
                                    device_baud_rate = 115200;
                                    break;
                            }
                            textBaudRate.Text = device_baud_rate.ToString();
                            break;
                        case CommandState.READ_SENSOR_NAME:
                            cur_log += "    <-- Received Sensor name packet \t\t" + strRcv + "\r\n";
                            byte[] hw_buf = new byte[20];
                            for (int i = 0; i < 20; i+=2)
                            {
                                hw_buf[i] = receivedData[i + 4];
                                hw_buf[i + 1] = receivedData[i + 3];
                            }
                            string hw_version = System.Text.Encoding.Default.GetString(hw_buf);
                            textHWVersion.Text = hw_version.TrimEnd();
                            break;
                        case CommandState.READ_SENSOR_MANUFACTURER:
                            cur_log += "    <-- Received READ_SENSOR_MANUFACTURER packet \t\t" + strRcv + "\r\n";
                            byte[] fw_buf = new byte[20];
                            for (int i = 0; i < 20; i += 2)
                            {
                                fw_buf[i] = receivedData[i + 4];
                                fw_buf[i + 1] = receivedData[i + 3];
                            }
                            string fw_version = System.Text.Encoding.Default.GetString(fw_buf);
                            textFWVersion.Text = fw_version.TrimEnd();
                            break;
                        case CommandState.READ_SENSOR_SERIAL_NUMBER:
                            cur_log += "    <-- Received Serial number packet \t\t" + strRcv + "\r\n";
                            byte[] sn_buf = new byte[20];
                            for (int i = 0; i < 20; i += 2)
                            {
                                sn_buf[i] = receivedData[i + 4];
                                sn_buf[i + 1] = receivedData[i + 3];
                            }
                            string sn_number = System.Text.Encoding.Default.GetString(sn_buf);
                            textSerialNumber.Text = sn_number.TrimEnd();
                            break;
                        case CommandState.READ_SOFTWARE_VERSION:
                            cur_log += "    <-- Received Software version packet \t\t" + strRcv + "\r\n";
                            byte[] mf_buf = new byte[20];
                            for (int i = 0; i < 20; i += 2)
                            {
                                mf_buf[i] = receivedData[i + 4];
                                mf_buf[i + 1] = receivedData[i + 3];
                            }
                            string mf_number = System.Text.Encoding.Default.GetString(mf_buf);
                            textManufactureNumber.Text = mf_number.TrimEnd();
                            break;
                        case CommandState.READ_SENSOR_MEASURE_TYPE:
                            cur_log += "    <-- Received measure type packet \t\t" + strRcv + "\r\n";
                            byte[] p_buf = new byte[2];
                            p_buf[0] = receivedData[4];
                            p_buf[1] = receivedData[3];
                            short m_type = BitConverter.ToInt16(p_buf, 0);
                            textProductNumber.Text = m_type.ToString();
                            break;
                        case CommandState.MONITOR_PH:
                            cur_log += "    <-- Received pH packet \t\t\t\t" + strRcv + "\r\n";
                            data.Clear();
                            data.Add(receivedData[4]);
                            data.Add(receivedData[3]);
                            data.Add(receivedData[6]);
                            data.Add(receivedData[5]);
                            float phValue = System.BitConverter.ToSingle(data.ToArray(), 0);
                            textPH.Text = phValue.ToString("F2");
                            break;
                        case CommandState.MONITOR_TEMP:
                            cur_log += "    <-- Received Temperature packet \t\t\t" + strRcv + "\r\n";
                            data.Clear();
                            data.Add(receivedData[4]);
                            data.Add(receivedData[3]);
                            data.Add(receivedData[6]);
                            data.Add(receivedData[5]);
                            float tempValue = System.BitConverter.ToSingle(data.ToArray(), 0);
                            textTemperature.Text = tempValue.ToString("F2");
                            break;
                        case CommandState.MONITOR_ORP:
                            cur_log += "    <-- Received ORP packet \t\t\t\t" + strRcv + "\r\n";
                            data.Clear();
                            data.Add(receivedData[4]);
                            data.Add(receivedData[3]);
                            data.Add(receivedData[6]);
                            data.Add(receivedData[5]);
                            float orpValue = System.BitConverter.ToSingle(data.ToArray(), 0);
                            textORP.Text = orpValue.ToString("F1");
                            break;
                        case CommandState.WRITE_DEVICE_ID:
                            cur_log += "    <-- Received DeviceID Write success \t\t" + strRcv + "\r\n";
                            textDeviceID.Text = textSlaveID.Text;
                            break;
                        case CommandState.WRITE_BAUD_RATE:
                            cur_log += "    <-- Received Baudrate Write success \t\t" + strRcv + "\r\n";
                            if (mSerialPort.IsOpen)
                                mSerialPort.Close();
                            Int32 iBaudRate = Convert.ToInt32(textBaudRate.Text);
                            mSerialPort.BaudRate = iBaudRate;       //波特率
                            mSerialPort.Open();
                            cbBaudRate.Text = textBaudRate.Text;
                            //MessageBox.Show("Write BaudRate Success.");
                            break;
                        case CommandState.WRITE_SENSOR_NAME:
                            cur_log += "    <-- Received WRITE_SENSOR_NAME Write success \t" + strRcv + "\r\n";
                            break;
                        case CommandState.WRITE_SENSOR_MANUFACTURER:
                            cur_log += "    <-- Received WRITE_SENSOR_MANUFACTURER Write success \t" + strRcv + "\r\n";
                            break;
                        case CommandState.WRITE_SENSOR_SERIAL_NUMBER:
                            cur_log += "    <-- Received WRITE_SENSOR_SERIAL_NUMBER Write success \t" + strRcv + "\r\n";
                            break;
                        case CommandState.WRITE_SOFTWARE_VERSION:
                            cur_log += "    <-- Received WRITE_SOFTWARE_VERSION Write success \t" + strRcv + "\r\n";
                            break;
                        case CommandState.WRITE_SENSOR_MEASURE_TYPE:
                            cur_log += "    <-- Received WRITE_SENSOR_MEASURE_TYPE Write success \t" + strRcv + "\r\n";
                            break;
                        case CommandState.READ_LATEST_PH_CALIB:
                            cur_log += "    <-- Received Latest pH Callibration \t" + strRcv + "\r\n";

                            data.Clear();
                            data.Add(receivedData[4]);
                            data.Add(receivedData[3]);
                            data.Add(receivedData[6]);
                            data.Add(receivedData[5]);
                            UInt32 tempint32 = System.BitConverter.ToUInt32(data.ToArray(), 0);
                            DateTime calib_date = Command.getDateFromTimeStamp(tempint32);
                            lblCalibTime.Text = calib_date.ToString("yyyy-MM-dd hh:mm:ss");

                            data.Clear();
                            data.Add(receivedData[8]);
                            data.Add(receivedData[7]);
                            data.Add(receivedData[10]);
                            data.Add(receivedData[9]);
                            float tempfloat = System.BitConverter.ToSingle(data.ToArray(), 0);
                            lblZeroPoint.Text = tempfloat.ToString("F2");

                            data.Clear();
                            data.Add(receivedData[12]);
                            data.Add(receivedData[11]);
                            data.Add(receivedData[14]);
                            data.Add(receivedData[13]);
                            tempfloat = System.BitConverter.ToSingle(data.ToArray(), 0);
                            lblSlope1.Text = tempfloat.ToString("F2");

                            data.Clear();
                            data.Add(receivedData[16]);
                            data.Add(receivedData[15]);
                            data.Add(receivedData[18]);
                            data.Add(receivedData[17]);
                            tempfloat = System.BitConverter.ToSingle(data.ToArray(), 0);
                            lblSlope2.Text = tempfloat.ToString("F2");

                            data.Clear();
                            data.Add(receivedData[20]);
                            data.Add(receivedData[19]);
                            int tempint = System.BitConverter.ToInt16(data.ToArray(), 0);
                            lblCalibType.Text = tempint.ToString();

                            break;
                        case CommandState.READ_LATEST_ORP_CALIB:
                            cur_log += "    <-- Received Latest ORP Callibration \t" + strRcv + "\r\n";

                            data.Clear();
                            data.Add(receivedData[4]);
                            data.Add(receivedData[3]);
                            data.Add(receivedData[6]);
                            data.Add(receivedData[5]);
                            tempint32 = System.BitConverter.ToUInt32(data.ToArray(), 0);
                            calib_date = Command.getDateFromTimeStamp(tempint32);
                            lblCalibTime.Text = calib_date.ToString("yyyy-MM-dd hh:mm:ss");

                            data.Clear();
                            data.Add(receivedData[8]);
                            data.Add(receivedData[7]);
                            data.Add(receivedData[10]);
                            data.Add(receivedData[9]);
                            tempfloat = System.BitConverter.ToSingle(data.ToArray(), 0);
                            lblZeroPoint.Text = tempfloat.ToString("F2");

                            data.Clear();
                            data.Add(receivedData[12]);
                            data.Add(receivedData[11]);
                            data.Add(receivedData[14]);
                            data.Add(receivedData[13]);
                            tempfloat = System.BitConverter.ToSingle(data.ToArray(), 0);
                            lblSlope1.Text = tempfloat.ToString("F2");

                            data.Clear();
                            data.Add(receivedData[16]);
                            data.Add(receivedData[15]);
                            data.Add(receivedData[18]);
                            data.Add(receivedData[17]);
                            tempfloat = System.BitConverter.ToSingle(data.ToArray(), 0);
                            lblSlope2.Text = tempfloat.ToString("F2");

                            data.Clear();
                            data.Add(receivedData[20]);
                            data.Add(receivedData[19]);
                            tempint = System.BitConverter.ToInt16(data.ToArray(), 0);
                            lblCalibType.Text = tempint.ToString();
                            break;

                        case CommandState.WRITE_PH_CALIB_TIME:
                            cur_log += "    <-- Received Write pH Calib Time success \t" + strRcv + "\r\n";
                            break;

                        case CommandState.WRITE_PH_FIRST_BUFFER:
                            cur_log += "    <-- Received Write pH 1st buffer success \t" + strRcv + "\r\n";
                            break;
                        case CommandState.WRITE_PH_SECOND_BUFFER:
                            cur_log += "    <-- Received Write pH 2nd buffer success \t" + strRcv + "\r\n";
                            break;
                        case CommandState.WRITE_PH_THIRD_BUFFER:
                            cur_log += "    <-- Received Write pH 3rd buffer success \t" + strRcv + "\r\n";
                            break;
                        case CommandState.WRITE_ACTION_CODE:
                            cur_log += "    <-- Received Write Action Code success \t" + strRcv + "\r\n";
                            break;
                        case CommandState.READ_RESULT_CODE:
                            cur_log += "    <-- Received Calib Result Code success \t" + strRcv + "\r\n";
                            break;
                        case CommandState.WRITE_ORP_CALIB_TIME:
                            cur_log += "    <-- Received Write ORP Calib Time success \t" + strRcv + "\r\n";
                            break;
                        case CommandState.WRITE_ORP_POINT1:
                            cur_log += "    <-- Received Write ORP Point1 success \t" + strRcv + "\r\n";
                            break;
                        case CommandState.WRITE_ORP_POINT2:
                            cur_log += "    <-- Received Write ORP Point2 success \t" + strRcv + "\r\n";
                            break;
                        case CommandState.WRITE_ORP_POINT3:
                            cur_log += "    <-- Received Write ORP Point3 success \t" + strRcv + "\r\n";
                            break;
                        case CommandState.WRITE_PH_MANUAL_CALIB_TIME:
                            cur_log += "    <-- Received Write Data entry calib time success \t" + strRcv + "\r\n";
                            break;
                        case CommandState.WRITE_PH_MANUAL_ZERO_POINT:
                            cur_log += "    <-- Received Write WRITE_PH_MANUAL_ZERO_POINT success \t" + strRcv + "\r\n";
                            break;
                        case CommandState.WRITE_PH_MANUAL_ACID_SLOPE:
                            cur_log += "    <-- Received Write WRITE_PH_MANUAL_ACID_SLOPE success \t" + strRcv + "\r\n";
                            break;
                        case CommandState.WRITE_PH_MANUAL_BASIC_SLOPE:
                            cur_log += "    <-- Received Write WRITE_PH_MANUAL_BASIC_SLOPE success \t" + strRcv + "\r\n";
                            break;
                        case CommandState.READ_LATEST_TEMP_CALIB:
                            cur_log += "    <-- Received Latest Temp Calib success \t" + strRcv + "\r\n";

                            data.Clear();
                            data.Add(receivedData[4]);
                            data.Add(receivedData[3]);
                            data.Add(receivedData[6]);
                            data.Add(receivedData[5]);
                            tempint32 = System.BitConverter.ToUInt32(data.ToArray(), 0);
                            calib_date = Command.getDateFromTimeStamp(tempint32);
                            txtTempCalibTime.Text = calib_date.ToString("yyyy-MM-dd hh:mm:ss");

                            data.Clear();
                            data.Add(receivedData[8]);
                            data.Add(receivedData[7]);
                            data.Add(receivedData[10]);
                            data.Add(receivedData[9]);
                            tempfloat = System.BitConverter.ToSingle(data.ToArray(), 0);
                            txtTempSlope.Text = tempfloat.ToString("F2");

                            data.Clear();
                            data.Add(receivedData[12]);
                            data.Add(receivedData[11]);
                            data.Add(receivedData[14]);
                            data.Add(receivedData[13]);
                            tempfloat = System.BitConverter.ToSingle(data.ToArray(), 0);
                            txtTempOffset.Text = tempfloat.ToString("F2");
                            break;
                        case CommandState.WRITE_TEMP_CALIB_TIME:
                            cur_log += "    <-- Received Write WRITE_TEMP_CALIB_TIME success \t" + strRcv + "\r\n";
                            break;
                        case CommandState.READ_PH_RESULT_CODE:
                            cur_log += "    <-- Received READ_PH_RESULT_CODE packet \t\t" + strRcv + "\r\n";
                            data.Clear();
                            data.Add(receivedData[4]);
                            data.Add(receivedData[3]);
                            tempint = System.BitConverter.ToInt16(data.ToArray(), 0);
                            txtPHResult.Text = tempint.ToString();
                            break;
                        case CommandState.READ_ORP_RESULT_CODE:
                            cur_log += "    <-- Received READ_ORP_RESULT_CODE packet \t\t" + strRcv + "\r\n";
                            data.Clear();
                            data.Add(receivedData[4]);
                            data.Add(receivedData[3]);
                            tempint = System.BitConverter.ToInt16(data.ToArray(), 0);
                            txtORPResult.Text = tempint.ToString();
                            break;
                        case CommandState.READ_MANUAL_RESULT_CODE:
                            cur_log += "    <-- Received READ_MANUAL_RESULT_CODE packet \t\t" + strRcv + "\r\n";
                            data.Clear();
                            data.Add(receivedData[4]);
                            data.Add(receivedData[3]);
                            tempint = System.BitConverter.ToInt16(data.ToArray(), 0);
                            txtCalibManualResult.Text = tempint.ToString();
                            break;
                        case CommandState.READ_TEMP_RESULT_CODE:
                            cur_log += "    <-- Received READ_TEMP_RESULT_CODE packet \t\t" + strRcv + "\r\n";
                            data.Clear();
                            data.Add(receivedData[4]);
                            data.Add(receivedData[3]);
                            tempint = System.BitConverter.ToInt16(data.ToArray(), 0);
                            txtTempCalibResult.Text = tempint.ToString();
                            break;
                        case CommandState.READ_MTC_TEMPERATURE:
                            cur_log += "    <-- Received READ_MTC_TEMPERATURE packet \t\t" + strRcv + "\r\n";
                            data.Clear();
                            data.Add(receivedData[4]);
                            data.Add(receivedData[3]);
                            data.Add(receivedData[6]);
                            data.Add(receivedData[5]);
                            tempValue = System.BitConverter.ToSingle(data.ToArray(), 0);
                            txtReadMTC.Text = tempValue.ToString("F1");
                            break;
                        case CommandState.READ_TEMPER_STATUS:
                            cur_log += "    <-- Received READ_MTC_STATUS packet \t\t" + strRcv + "\r\n";
                            data.Clear();
                            data.Add(receivedData[4]);
                            data.Add(receivedData[3]);
                            tempint = System.BitConverter.ToInt16(data.ToArray(), 0);
                            if(tempint == 0)
                            {
                                txtMTCStatus.Text = "ATC";
                            }
                            else
                            {
                                txtMTCStatus.Text = "MTC";
                            }
                            txtTempCalibResult.Text = tempint.ToString();
                            break;
                        case CommandState.WRITE_MTC_TEMPERATURE:
                            cur_log += "    <-- Received WRITE_MTC_TEMPERATURE packet \t\t" + strRcv + "\r\n";
                            break;
                        case CommandState.WRITE_TEMPERATURE_MODE:
                            cur_log += "    <-- Received WRITE_TEMPERATURE_MODE packet \t\t" + strRcv + "\r\n";
                            break;
                        case CommandState.WRITE_TEMP_BIAS:
                            cur_log += "    <-- Received WRITE_TEMP_BIAS packet \t\t" + strRcv + "\r\n";
                            break;
                        case CommandState.READ_TEMP_BIAS:
                            cur_log += "    <-- Received READ_TEMP_BIAS packet \t\t" + strRcv + "\r\n";
                            data.Clear();
                            data.Add(receivedData[4]);
                            data.Add(receivedData[3]);
                            data.Add(receivedData[6]);
                            data.Add(receivedData[5]);
                            tempValue = System.BitConverter.ToSingle(data.ToArray(), 0);
                            txtReadTempBias.Text = tempValue.ToString("F1");
                            break;
                        case CommandState.WRITE_ORP_BIAS:
                            cur_log += "    <-- Received WRITE_ORP_BIAS packet \t\t" + strRcv + "\r\n";
                            break;
                        case CommandState.READ_ORP_BIAS:
                            cur_log += "    <-- Received READ_ORP_BIAS packet \t\t" + strRcv + "\r\n";
                            data.Clear();
                            data.Add(receivedData[4]);
                            data.Add(receivedData[3]);
                            data.Add(receivedData[6]);
                            data.Add(receivedData[5]);
                            tempValue = System.BitConverter.ToSingle(data.ToArray(), 0);
                            txtReadOrpBias.Text = tempValue.ToString("F1");
                            break;
                        case CommandState.PH_CALIB_READ_PROBE:
                            {
                                cur_log += "    <-- Received PH_CALIB_READ_PROBE packet \t\t" + strRcv + "\r\n";
                                data.Clear();
                                data.Add(receivedData[8]);
                                data.Add(receivedData[7]);
                                data.Add(receivedData[10]);
                                data.Add(receivedData[9]);
                                pHCalibValue.temperature[pHCalibValue.read_count % 10] = System.BitConverter.ToSingle(data.ToArray(), 0);
                                txtPHCalibTemp.Text = pHCalibValue.temperature[pHCalibValue.read_count % 10].ToString("F2");

                                data.Clear();
                                data.Add(receivedData[12]);
                                data.Add(receivedData[11]);
                                data.Add(receivedData[14]);
                                data.Add(receivedData[13]);
                                pHCalibValue.ph_voltage[pHCalibValue.read_count % 10] = System.BitConverter.ToSingle(data.ToArray(), 0);
                                txtPHVoltage.Text = pHCalibValue.ph_voltage[pHCalibValue.read_count % 10].ToString("F2");

                                double time = (DateTime.Now - pHCalibValue.StartTime).TotalSeconds;
                                txtPHCalibTime.Text = time.ToString("F2");

                                if (pHCalibValue.read_count > 4)
                                {
                                    switch(calibrationStep)
                                    {
                                        case CalibrationStep.PH_CALIB_START:
                                            if(comboCalibType.SelectedIndex == 0)
                                            {
                                                pHCalibValue.Buffer1 = pHCalibValue.select_nist_standard_ph(pHCalibValue.ph_voltage[pHCalibValue.read_count % 10]);
                                                txtPHOfBuffer.Text = pHCalibValue.Buffer1.ToString();
                                            }
                                            else if(comboCalibType.SelectedIndex == 1)
                                            {
                                                pHCalibValue.Buffer1 = pHCalibValue.select_nist_tech_ph(pHCalibValue.ph_voltage[pHCalibValue.read_count % 10]);
                                                txtPHOfBuffer.Text = pHCalibValue.Buffer1.ToString();
                                            }
                                            else
                                            {
                                                txtPHOfBuffer.Text = pHCalibValue.Buffer1.ToString();
                                            }
                                            break;
                                        case CalibrationStep.PH_CALIB_FIRST:
                                            if (comboCalibType.SelectedIndex == 0)
                                            {
                                                pHCalibValue.Buffer2 = pHCalibValue.select_nist_standard_ph(pHCalibValue.ph_voltage[pHCalibValue.read_count % 10]);
                                                txtPHOfBuffer.Text = pHCalibValue.Buffer2.ToString();
                                            }
                                            else if (comboCalibType.SelectedIndex == 1)
                                            {
                                                pHCalibValue.Buffer2 = pHCalibValue.select_nist_tech_ph(pHCalibValue.ph_voltage[pHCalibValue.read_count % 10]);
                                                txtPHOfBuffer.Text = pHCalibValue.Buffer2.ToString();
                                            }
                                            else
                                            {
                                                txtPHOfBuffer.Text = pHCalibValue.Buffer2.ToString();
                                            }
                                            break;
                                        case CalibrationStep.PH_CALIB_SECOND:
                                            if (comboCalibType.SelectedIndex == 0)
                                            {
                                                pHCalibValue.Buffer3 = pHCalibValue.select_nist_standard_ph(pHCalibValue.ph_voltage[pHCalibValue.read_count % 10]);
                                                txtPHOfBuffer.Text = pHCalibValue.Buffer3.ToString();
                                            }
                                            else if (comboCalibType.SelectedIndex == 1)
                                            {
                                                pHCalibValue.Buffer3 = pHCalibValue.select_nist_tech_ph(pHCalibValue.ph_voltage[pHCalibValue.read_count % 10]);
                                                txtPHOfBuffer.Text = pHCalibValue.Buffer3.ToString();
                                            }
                                            else
                                            {
                                                txtPHOfBuffer.Text = pHCalibValue.Buffer3.ToString();
                                            }
                                            break;
                                    }
                                    
                                }

                                if (pHCalibValue.read_count > 10)
                                {
                                    if(pHCalibValue.CheckValid())
                                    {
                                        switch (calibrationStep)
                                        {
                                            case CalibrationStep.PH_CALIB_START:
                                                commandState = CommandState.WRITE_PH_FIRST_BUFFER;
                                                txtPHOfBuffer1.Text = pHCalibValue.Buffer1.ToString();
                                                break;
                                            case CalibrationStep.PH_CALIB_FIRST:
                                                commandState = CommandState.WRITE_PH_SECOND_BUFFER;
                                                txtPHOfBuffer2.Text = pHCalibValue.Buffer2.ToString();
                                                break;
                                            case CalibrationStep.PH_CALIB_SECOND:
                                                commandState = CommandState.WRITE_PH_THIRD_BUFFER;
                                                txtPHOfBuffer3.Text = pHCalibValue.Buffer3.ToString();
                                                break;
                                        }
                                       
                                    }
                                }

                                pHCalibValue.read_count++;                                                                
                                break;
                            }
                        case CommandState.PH_CALIB_WRITE_TIME:
                            cur_log += "    <-- Received PH_CALIB_WRITE_TIME packet \t\t" + strRcv + "\r\n";
                            commandState = CommandState.PH_CALIB_RUN;
                            break;
                        case CommandState.PH_CALIB_RUN:
                            cur_log += "    <-- Received PH_CALIB_RUN packet \t\t" + strRcv + "\r\n";
                            commandState = CommandState.PH_CALIB_READ_RESULT;
                            break;
                        case CommandState.PH_CALIB_READ_RESULT:
                            cur_log += "    <-- Received PH_CALIB_READ_RESULT packet \t\t" + strRcv + "\r\n";
                            data.Clear();
                            data.Add(receivedData[4]);
                            data.Add(receivedData[3]);
                            tempint = System.BitConverter.ToInt16(data.ToArray(), 0);
                            if(tempint == 1)
                            {
                                commandState = CommandState.PH_CALIB_READ_LATEST;
                            }
                            else
                            {
                                timerCalib.Enabled = false;
                                MessageBox.Show(this, "Calibration Error!, Error Code: " + tempint);                                
                                SetToCalibStart();
                            }
                            break;
                        case CommandState.PH_CALIB_READ_LATEST:
                            cur_log += "    <-- Received PH_CALIB_READ_RESULT packet \t\t" + strRcv + "\r\n";
                            data.Clear();
                            data.Add(receivedData[4]);
                            data.Add(receivedData[3]);
                            data.Add(receivedData[6]);
                            data.Add(receivedData[5]);
                            tempint32 = System.BitConverter.ToUInt32(data.ToArray(), 0);
                            calib_date = Command.getDateFromTimeStamp(tempint32);

                            data.Clear();
                            data.Add(receivedData[8]);
                            data.Add(receivedData[7]);
                            data.Add(receivedData[10]);
                            data.Add(receivedData[9]);
                            float zero_point = System.BitConverter.ToSingle(data.ToArray(), 0);

                            data.Clear();
                            data.Add(receivedData[12]);
                            data.Add(receivedData[11]);
                            data.Add(receivedData[14]);
                            data.Add(receivedData[13]);
                            float slope1 = System.BitConverter.ToSingle(data.ToArray(), 0);

                            data.Clear();
                            data.Add(receivedData[16]);
                            data.Add(receivedData[15]);
                            data.Add(receivedData[18]);
                            data.Add(receivedData[17]);
                            float slope2 = System.BitConverter.ToSingle(data.ToArray(), 0);

                            data.Clear();
                            data.Add(receivedData[20]);
                            data.Add(receivedData[19]);
                            int calib_type = System.BitConverter.ToInt16(data.ToArray(), 0);

                            timerCalib.Enabled = false;

                            CalibResult calibResult = new CalibResult(
                                calib_date.ToString("yyyy-MM-dd hh:mm:ss"),
                                zero_point,
                                slope1,
                                slope2,
                                calib_type.ToString());
                            calibResult.ShowDialog(this);
                            SetToCalibStart();
                            break;
                        case CommandState.ORP_CALIB_READ_PROBE:
                            cur_log += "    <-- Received ORP_CALIB_READ_PROBE packet \t\t" + strRcv + "\r\n";
                            data.Clear();
                            data.Add(receivedData[4]);
                            data.Add(receivedData[3]);
                            data.Add(receivedData[6]);
                            data.Add(receivedData[5]);
                            orpCalibValue.measure_vals[orpCalibValue.read_count % 10] = System.BitConverter.ToSingle(data.ToArray(), 0);

                            if(orpCalibStep == ORPCalibrationStep.ORP_CALIB_START)
                            {
                                txtORPMeasure1.Text = orpCalibValue.measure_vals[orpCalibValue.read_count % 10].ToString("F2");
                                if (orpCalibValue.read_count % 2 == 0)
                                    txtORPMeasure1.ForeColor = Color.Red;
                                else
                                    txtORPMeasure1.ForeColor = Color.Black;
                            }
                            else if (orpCalibStep == ORPCalibrationStep.ORP_CALIB_FIRST)
                            {
                                txtORPMeasure2.Text = orpCalibValue.measure_vals[orpCalibValue.read_count % 10].ToString("F2");
                                if (orpCalibValue.read_count % 2 == 0)
                                    txtORPMeasure2.ForeColor = Color.Red;
                                else
                                    txtORPMeasure2.ForeColor = Color.Black;
                            }
                            else if (orpCalibStep == ORPCalibrationStep.ORP_CALIB_SECOND)
                            {
                                txtORPMeasure3.Text = orpCalibValue.measure_vals[orpCalibValue.read_count % 10].ToString("F2");
                                if (orpCalibValue.read_count % 2 == 0)
                                    txtORPMeasure3.ForeColor = Color.Red;
                                else
                                    txtORPMeasure3.ForeColor = Color.Black;
                            }

                            if (orpCalibValue.read_count > 10)
                            {
                                if (orpCalibValue.CheckValid())
                                {
                                    switch (orpCalibStep)
                                    {
                                        case ORPCalibrationStep.ORP_CALIB_START:
                                            commandState = CommandState.WRITE_ORP_POINT1;
                                            txtORPMeasure1.ForeColor = Color.Red;
                                            break;
                                        case ORPCalibrationStep.ORP_CALIB_FIRST:
                                            commandState = CommandState.WRITE_ORP_POINT2;
                                            txtORPMeasure2.ForeColor = Color.Red;
                                            break;
                                        case ORPCalibrationStep.ORP_CALIB_SECOND:
                                            commandState = CommandState.WRITE_ORP_POINT3;
                                            txtORPMeasure3.ForeColor = Color.Red;
                                            break;
                                    }

                                }
                            }

                            orpCalibValue.read_count++;
                            break;
                        case CommandState.ORP_CALIB_WRITE_TIME:
                            cur_log += "    <-- Received ORP_CALIB_WRITE_TIME packet \t\t" + strRcv + "\r\n";
                            commandState = CommandState.ORP_CALIB_RUN;
                            break;
                        case CommandState.ORP_CALIB_RUN:
                            cur_log += "    <-- Received ORP_CALIB_RUN packet \t\t" + strRcv + "\r\n";
                            commandState = CommandState.ORP_CALIB_READ_RESULT;
                            break;
                        case CommandState.ORP_CALIB_READ_RESULT:
                            cur_log += "    <-- Received ORP_CALIB_READ_RESULT packet \t\t" + strRcv + "\r\n";
                            data.Clear();
                            data.Add(receivedData[4]);
                            data.Add(receivedData[3]);
                            tempint = System.BitConverter.ToInt16(data.ToArray(), 0);
                            if (tempint == 1)
                            {
                                commandState = CommandState.ORP_CALIB_READ_LATEST;
                            }
                            else
                            {
                                timerCalib.Enabled = false;
                                MessageBox.Show(this, "Calibration Error!, Error Code: " + tempint);
                                SetToORPCalibStart();
                            }                            
                            break;
                        case CommandState.ORP_CALIB_READ_LATEST:
                            cur_log += "    <-- Received ORP_CALIB_READ_LATEST packet \t\t" + strRcv + "\r\n";
                            data.Clear();
                            data.Add(receivedData[4]);
                            data.Add(receivedData[3]);
                            data.Add(receivedData[6]);
                            data.Add(receivedData[5]);
                            tempint32 = System.BitConverter.ToUInt32(data.ToArray(), 0);
                            calib_date = Command.getDateFromTimeStamp(tempint32);

                            data.Clear();
                            data.Add(receivedData[8]);
                            data.Add(receivedData[7]);
                            data.Add(receivedData[10]);
                            data.Add(receivedData[9]);
                            zero_point = System.BitConverter.ToSingle(data.ToArray(), 0);

                            data.Clear();
                            data.Add(receivedData[12]);
                            data.Add(receivedData[11]);
                            data.Add(receivedData[14]);
                            data.Add(receivedData[13]);
                            slope1 = System.BitConverter.ToSingle(data.ToArray(), 0);

                            data.Clear();
                            data.Add(receivedData[16]);
                            data.Add(receivedData[15]);
                            data.Add(receivedData[18]);
                            data.Add(receivedData[17]);
                            slope2 = System.BitConverter.ToSingle(data.ToArray(), 0);

                            data.Clear();
                            data.Add(receivedData[20]);
                            data.Add(receivedData[19]);
                            calib_type = System.BitConverter.ToInt16(data.ToArray(), 0);

                            timerCalib.Enabled = false;

                            calibResult = new CalibResult(
                                calib_date.ToString("yyyy-MM-dd hh:mm:ss"),
                                zero_point,
                                slope1,
                                slope2,
                                calib_type.ToString());
                            calibResult.ShowDialog(this);
                            SetToORPCalibStart();
                            break;
                        case CommandState.WRITE_TEMP_RES_POINT1:
                            cur_log += "    <-- Received WRITE_TEMP_RES_POINT1 packet \t\t" + strRcv + "\r\n";
                            break;
                        case CommandState.WRITE_TEMP_RES_POINT2:
                            cur_log += "    <-- Received WRITE_TEMP_RES_POINT2 packet \t\t" + strRcv + "\r\n";
                            break;
                        case CommandState.TEMP_CALIB_READ_RES1:
                            cur_log += "    <-- Received TEMP_CALIB_READ_RES1 packet \t\t" + strRcv + "\r\n";
                            data.Clear();
                            data.Add(receivedData[4]);
                            data.Add(receivedData[3]);
                            data.Add(receivedData[6]);
                            data.Add(receivedData[5]);
                            tempCalibValue.measure_vals[tempCalibValue.read_count % 10] = System.BitConverter.ToSingle(data.ToArray(), 0);
                            txtTempCalibResMea1.Text = tempCalibValue.measure_vals[tempCalibValue.read_count % 10].ToString("F2");
                            if (tempCalibValue.read_count % 2 == 0)
                                txtTempCalibResMea1.ForeColor = Color.Red;
                            else
                                txtTempCalibResMea1.ForeColor = Color.Black;
                            if (tempCalibValue.read_count > 10)
                            {
                                if(tempCalibValue.CheckValid())
                                {
                                    commandState = CommandState.WRITE_TEMP_RES_POINT1;
                                }
                            }
                            tempCalibValue.read_count++;
                            break;
                        case CommandState.TEMP_CALIB_READ_RES2:
                            cur_log += "    <-- Received TEMP_CALIB_READ_RES2 packet \t\t" + strRcv + "\r\n";
                            data.Clear();
                            data.Add(receivedData[4]);
                            data.Add(receivedData[3]);
                            data.Add(receivedData[6]);
                            data.Add(receivedData[5]);
                            tempCalibValue.measure_vals[tempCalibValue.read_count % 10] = System.BitConverter.ToSingle(data.ToArray(), 0);
                            txtTempCalibResMea2.Text = tempCalibValue.measure_vals[tempCalibValue.read_count % 10].ToString("F2");
                            if (tempCalibValue.read_count % 2 == 0)
                                txtTempCalibResMea2.ForeColor = Color.Red;
                            else
                                txtTempCalibResMea2.ForeColor = Color.Black;
                            if (tempCalibValue.read_count > 10)
                            {
                                if (tempCalibValue.CheckValid())
                                {
                                    commandState = CommandState.WRITE_TEMP_RES_POINT2;
                                }
                            }
                            tempCalibValue.read_count++;
                            break;
                        case CommandState.TEMP_CALIB_WRITE_TIME:
                            cur_log += "    <-- Received TEMP_CALIB_WRITE_TIME packet \t\t" + strRcv + "\r\n";
                            commandState = CommandState.TEMP_CALIB_RUN;
                            break;
                        case CommandState.TEMP_CALIB_RUN:
                            cur_log += "    <-- Received TEMP_CALIB_RUN packet \t\t" + strRcv + "\r\n";
                            commandState = CommandState.TEMP_CALIB_READ_RESULT;
                            break;
                        case CommandState.TEMP_CALIB_READ_RESULT:
                            cur_log += "    <-- Received TEMP_CALIB_READ_RESULT packet \t\t" + strRcv + "\r\n";
                            data.Clear();
                            data.Add(receivedData[4]);
                            data.Add(receivedData[3]);
                            tempint = System.BitConverter.ToInt16(data.ToArray(), 0);
                            if (tempint == 1)
                            {
                                commandState = CommandState.TEMP_CALIB_READ_LATEST;
                            }
                            else
                            {
                                timerCalib.Enabled = false;
                                MessageBox.Show(this, "Calibration Error!, Error Code: " + tempint);
                                SetToTempCalibStart();
                            }                            
                            break;
                        case CommandState.TEMP_CALIB_READ_LATEST:
                            cur_log += "    <-- Received TEMP_CALIB_READ_LATEST packet \t\t" + strRcv + "\r\n";
                            MessageBox.Show(this, "Calibration Success!");
                            break;
                    }
                   
                    log_str = cur_log + log_str;
                    ShowLog();

                }
                catch (System.Exception ex)
                {
                    //MessageBox.Show(ex.Message, "出错提示");
                    Console.WriteLine(ex.Message);
                }
            }
            else
            {
                MessageBox.Show("请打开某个串口", "错误提示");
            }
        }

        private void SetToCalibStart()
        {
            calibrationStep = CalibrationStep.PH_CALIB_START;
            pHCalibValue.clear_data();
            btnPHCalibStart.Enabled = true;
            btnPHCalibFinish.Enabled = false;
            btnPHCalibContinue.Enabled = false;
            btnPHCalibBack.Enabled = false;
            comboCalibType.Enabled = true;
            if (comboCalibType.SelectedIndex != 2)
            {
                txtPHOfBuffer1.Text = "";
                txtPHOfBuffer2.Text = "";
                txtPHOfBuffer3.Text = "";
            }
            txtPHVoltage.Text = "";
            txtPHCalibTemp.Text = "";
            txtPHCalibTime.Text = "";
            txtPHOfBuffer.Text = "";
            picPHCalibProcess.Image = PHPCTool.Properties.Resources.start;
        }
        private void SetToORPCalibStart()
        {
            orpCalibStep = ORPCalibrationStep.ORP_CALIB_START;
            orpCalibValue.clear_data();
            btnORPCalibStart.Enabled = true;
            btnORPCalibFinish.Enabled = false;
            btnORPCalibContinue.Enabled = false;
            btnORPCalibBack.Enabled = false;
            txtORPMeasure1.Text = "";
            txtORPMeasure2.Text = "";
            txtORPMeasure3.Text = "";
            picORPCalibProgress.Image = PHPCTool.Properties.Resources.start;
        }

        private void SetToTempCalibStart()
        {
            tempCalibValue.clear_data();
            btnTempCalibRunP1.Enabled = true;
            btnTempCalibRunP2.Enabled = false;
            btnTempCalibRunCalib.Enabled = false;
            txtTempCalibResMea1.Text = "";
            txtTempCalibResMea2.Text = "";
        }
        private void ShowLog()
        {
            if (log_str.Length > 4000)
                log_str = log_str.Substring(0, 4000);
            txtReceive.Text = log_str;
        }

        private bool SelectPacket(List<byte> buffer)
        {
            int pos = -1;
            for (int i = 0; i < buffer.Count - 2; i++ )
            {
                if (buffer[i] == device_id && (buffer[i + 1] == Command.COMMAND03 || buffer[i + 1] == Command.COMMAND16))
                {
                    pos = i;
                }
            }
            if (pos == -1)
                return false;
            if(pos > 0)
                buffer.RemoveRange(0, pos);

            int packet_length = 0;
            if (buffer.Count > 3)
            {
                if (buffer[1] == Command.COMMAND03)
                    packet_length = buffer[2] + 5;
                else
                    packet_length = 8;
            }                
            else
                return false;

            if (buffer.Count >= packet_length)
            {
                receivedData = new byte[packet_length];
                for(int i = 0; i < packet_length; i++)
                {
                    receivedData[i] = buffer[i];
                }
                buffer.RemoveRange(0, packet_length);
                return true;
            }
            
            return false;
        }

        
        //开关按钮
        private void btnSwitch_Click(object sender, EventArgs e)
        {
            //serialPort1.IsOpen
            if (!mSerialPort.IsOpen)
            {
                try
                {
                    //设置串口号
                    string serialName = comboPort.SelectedItem.ToString();
                    mSerialPort.PortName = serialName;

                    //设置各“串口设置”
                    string strBaudRate = cbBaudRate.Text;
                    
                    Int32 iBaudRate = Convert.ToInt32(strBaudRate);

                    mSerialPort.BaudRate = iBaudRate;       //波特率
                    mSerialPort.DataBits = 8;               //数据位
                    mSerialPort.StopBits = StopBits.One;
                    mSerialPort.Parity = Parity.None;
                    
                    if (mSerialPort.IsOpen == true)//如果打开状态，则先关闭一下
                    {
                        mSerialPort.Close();
                    }
                    //状态栏设置
                    tsSpNum.Text = "串口号：" + mSerialPort.PortName + "|";
                    tsBaudRate.Text = "波特率：" + mSerialPort.BaudRate + "|";
                    tsDataBits.Text = "数据位：" + mSerialPort.DataBits + "|";
                    tsStopBits.Text = "停止位：" + mSerialPort.StopBits + "|";
                    tsParity.Text = "校验位：" + mSerialPort.Parity + "|";

                    //设置必要控件不可用
                    comboPort.Enabled = false;
                    cbBaudRate.Enabled = false;
                    

                    mSerialPort.Open();     //打开串口
                    if (comboSelectLanguage.SelectedIndex == 0)
                        buttonOpen.Text = ChineseString.BTN_CLOSE_EN;
                    else
                        buttonOpen.Text = ChineseString.BTN_CLOSE_CN;

                    //if (mSerialPort.IsOpen)
                        //groupBoxSettingWindow.Enabled = true;
                }
                catch (System.Exception ex)
                {
                    MessageBox.Show("Error:" + ex.Message, "Error");
                    return;
                }
            }
            else
            {
                //状态栏设置
                tsSpNum.Text = "串口号：未指定|";
                tsBaudRate.Text = "波特率：未指定|";
                tsDataBits.Text = "数据位：未指定|";
                tsStopBits.Text = "停止位：未指定|";
                tsParity.Text = "校验位：未指定|";
                //恢复控件功能
                //设置必要控件不可用
                comboPort.Enabled = true;
                cbBaudRate.Enabled = true;
                

                mSerialPort.Close();                    //关闭串口
                if (comboSelectLanguage.SelectedIndex == 0)
                    buttonOpen.Text = ChineseString.BTN_OPEN_EN;
                else
                    buttonOpen.Text = ChineseString.BTN_OPEN_CN;

                //if (!mSerialPort.IsOpen)
                    //groupBoxSettingWindow.Enabled = false;
            }
            if (mSerialPort.IsOpen)
            {
                groupBoxSettingWindow.Enabled = true;
            }
            else
            {
                groupBoxSettingWindow.Enabled = false;
            }
        }


        //关闭时事件
        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            mSerialPort.Close();
        }

        


        private void comboSelectLanguage_SelectedIndexChanged(object sender, EventArgs e)
        {
            //changeUILanguage(comboSelectLanguage.SelectedIndex);
        }

        private void changeUILanguage(int index)
        {
            switch (index)
            {
                case 0:

                    /************ Title ***************/
                    this.Text = ChineseString.SETTING_TOOLS_EN;

                    /************ Port Setting Group ***************/
                    groupBoxPortSetting.Text = ChineseString.PORT_SETTING_EN;
                    labelSerialPort.Text = ChineseString.SERIAL_PORT_EN;
                    labelBaud.Text = ChineseString.BAUD_RATE_EN;
                    buttonRefresh.Text = ChineseString.BTN_REFREASH_EN;
                    if(mSerialPort.IsOpen)
                    {
                        buttonOpen.Text = ChineseString.BTN_CLOSE_EN;
                    }
                    else
                    {
                        buttonOpen.Text = ChineseString.BTN_OPEN_EN;
                    }
                    labelLanguage.Text = ChineseString.LABEL_LANGUAGE_EN;

                    /************ Log Window ***************/
                    groupLogWindow.Text = ChineseString.LOG_WINDOW_EN;

                    /************ Setting Window ***************/
                    groupBoxSettingWindow.Text = ChineseString.SETTING_WINDOW_EN;
                    tabControl.TabPages[0].Text = ChineseString.TAB_TRANSMMITION_SETTING_EN;
                    tabControl.TabPages[1].Text = ChineseString.TAB_DEVICE_INFOMATION_EN;
                    tabControl.TabPages[2].Text = ChineseString.TAB_MONITORING_EN;

                    labelSlaveID.Text = ChineseString.SLAVE_ID_EN1;
                    labelDeviceID.Text = ChineseString.SLAVE_ID_EN1;
                    labelBaudRate.Text = ChineseString.BAUD_RATE_EN;
                    labelHardwareVersion.Text = ChineseString.HARDWARE_VERSION_EN;
                    labelFirmwareVersion.Text = ChineseString.FIRMWARE_VERSION_EN;
                    labelSerialNumber.Text = ChineseString.SERIAL_NUMBER_EN;
                    labelManufactureNumber.Text = ChineseString.MANUFACTURER_NUMBER_EN;
                    labelProductNumber.Text = ChineseString.PRODUCT_NUMBER_EN;

                    for (int i = 0; i < 7; i++)
                    {
                        _readButtons[i].Text = ChineseString.BUTTON_READ_EN;
                        _writeButtons[i].Text = ChineseString.BUTTON_WRITE_EN;
                    }

                    buttonSettingReadAll.Text = ChineseString.BUTTON_READ_ALL_EN;
                    buttonSettingWriteAll.Text = ChineseString.BUTTON_WRITE_ALL_EN;
                    buttonDeviceReadAll.Text = ChineseString.BUTTON_READ_ALL_EN;
                    buttonDeviceWriteAll.Text = ChineseString.BUTTON_WRITE_ALL_EN;
                    buttonMoitorStart.Text = ChineseString.BUTTON_START_EN;
                    buttonMoitorStop.Text = ChineseString.BUTTON_STOP_EN;

                    break;
                case 1:

                    /************ Title ***************/
                    this.Text = ChineseString.SETTING_TOOLS_CN;

                    /************ Port Setting Group ***************/
                    groupBoxPortSetting.Text = ChineseString.PORT_SETTING_CN;
                    labelSerialPort.Text = ChineseString.SERIAL_PORT_CN;
                    labelBaud.Text = ChineseString.BAUD_RATE_CN;
                    buttonRefresh.Text = ChineseString.BTN_REFREASH_CN;
                    if (mSerialPort.IsOpen)
                    {
                        buttonOpen.Text = ChineseString.BTN_CLOSE_CN;
                    }
                    else
                    {
                        buttonOpen.Text = ChineseString.BTN_OPEN_CN;
                    }
                    labelLanguage.Text = ChineseString.LABEL_LANGUAGE_CN;

                    /************ Log Window ***************/
                    groupLogWindow.Text = ChineseString.LOG_WINDOW_CN;

                    /************ Setting Window ***************/
                    groupBoxSettingWindow.Text = ChineseString.SETTING_WINDOW_CN;
                    tabControl.TabPages[0].Text = ChineseString.TAB_TRANSMMITION_SETTING_CN;
                    tabControl.TabPages[1].Text = ChineseString.TAB_DEVICE_INFOMATION_CN;
                    tabControl.TabPages[2].Text = ChineseString.TAB_MONITORING_CN;

                    labelSlaveID.Text = ChineseString.SLAVE_ID_CN1;
                    labelDeviceID.Text = ChineseString.SLAVE_ID_CN1;
                    labelBaudRate.Text = ChineseString.BAUD_RATE_CN;
                    labelHardwareVersion.Text = ChineseString.HARDWARE_VERSION_CN;
                    labelFirmwareVersion.Text = ChineseString.FIRMWARE_VERSION_CN;
                    labelSerialNumber.Text = ChineseString.SERIAL_NUMBER_CN;
                    labelManufactureNumber.Text = ChineseString.MANUFACTURER_NUMBER_CN;
                    labelProductNumber.Text = ChineseString.PRODUCT_NUMBER_CN;

                    for (int i = 0; i < 8; i++)
                    {
                        _readButtons[i].Text = ChineseString.BUTTON_READ_CN;
                        _writeButtons[i].Text = ChineseString.BUTTON_WRITE_CN;
                    }

                    buttonSettingReadAll.Text = ChineseString.BUTTON_READ_ALL_CN;
                    buttonSettingWriteAll.Text = ChineseString.BUTTON_WRITE_ALL_CN;
                    buttonDeviceReadAll.Text = ChineseString.BUTTON_READ_ALL_CN;
                    buttonDeviceWriteAll.Text = ChineseString.BUTTON_WRITE_ALL_CN;
                    buttonMoitorStart.Text = ChineseString.BUTTON_START_CN;
                    buttonMoitorStop.Text = ChineseString.BUTTON_STOP_CN;

                    break;
            }
        }

        private void buttonMoitorStart_Click(object sender, EventArgs e)
        {
            if (!mSerialPort.IsOpen)
            {
                timerReadSetting.Enabled = false;
                MessageBox.Show("Serial port is closed.");
                this.Enabled = true;
                return;
            }
            timerMornitor.Enabled = true;
            buttonMoitorStart.Enabled = false;
            buttonMoitorStop.Enabled = true;
        }

        private void buttonMoitorStop_Click(object sender, EventArgs e)
        {
            timerMornitor.Enabled = false;
            buttonMoitorStart.Enabled = true;
            buttonMoitorStop.Enabled = false;
        }

        private void timerMornitor_Tick(object sender, EventArgs e)
        {
            if (!mSerialPort.IsOpen)
                return;

            receive_buffer_arr.Clear();
            if(ph_tmeperature_flag == 0)
            {
                List<byte> command = Command.makeReadCommand(device_id, 53, 0x02);
                mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
                commandState = CommandState.MONITOR_PH;
                showWriteLog("    Send Read pH commnad --> \t\t\t\t", command);
            }
            else if(ph_tmeperature_flag == 1)
            {
                List<byte> command = Command.makeReadCommand(device_id, 55, 0x02);
                mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
                commandState = CommandState.MONITOR_TEMP;
                showWriteLog("    Send Read Temperature commnad --> \t\t\t", command);
            }
            else
            {
                List<byte> command = Command.makeReadCommand(device_id, 57, 0x02);
                mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
                commandState = CommandState.MONITOR_ORP;
                showWriteLog("    Send Read ORP commnad --> \t\t\t\t", command);
            }
            ph_tmeperature_flag++;
            ph_tmeperature_flag %= 3;
        }

        private void buttonRefresh_Click(object sender, EventArgs e)
        {
            comboPort.Items.Clear();
            string[] str = SerialPort.GetPortNames();
            if (str == null)
            {
                MessageBox.Show("本机没有串口！", "Error");
            }

            //添加串口项目
            foreach (string s in System.IO.Ports.SerialPort.GetPortNames())
            {//获取有多少个COM口
                //System.Diagnostics.Debug.WriteLine(s);
                comboPort.Items.Add(s);
            }
            if (comboPort.Items.Count > 0)
                comboPort.SelectedIndex = 0;
        }

        private void textSlaveID_TextChanged(object sender, EventArgs e)
        {
            device_id = byte.Parse(textDeviceID.Text);
        }

        private void InitCommandIndex()
        {
            setting_command_index = 0;
            device_command_index = 2;
        }

        private void buttonSettingReadAll_Click(object sender, EventArgs e)
        {
            InitCommandIndex();
            timerReadSetting.Enabled = true;
            this.Enabled = false;
        }

        private void buttonSettingWriteAll_Click(object sender, EventArgs e)
        {
            InitCommandIndex();
            timerWriteSetting.Enabled = true;
            this.Enabled = false;
        }

        private void buttonDeviceReadAll_Click(object sender, EventArgs e)
        {
            InitCommandIndex();
            timerReadDeviceInfo.Enabled = true;
            this.Enabled = false;
        }

        private void buttonDeviceWriteAll_Click(object sender, EventArgs e)
        {
            InitCommandIndex();
            timerWriteDeviceInfo.Enabled = true;
            this.Enabled = false;
        }

        private void timerReadSetting_Tick(object sender, EventArgs e)
        {
            if(!mSerialPort.IsOpen)
            {
                timerReadSetting.Enabled = false;
                MessageBox.Show("Serial port is closed.");
                this.Enabled = true;
                return;
            }

            if (setting_command_index > 1)
            {
                setting_command_index = 0;
                timerReadSetting.Enabled = false;
                this.Enabled = true;
                return;
            }
            ReadButtonClick(null, setting_command_index);
            setting_command_index++;
        }

        private void timerWriteSetting_Tick(object sender, EventArgs e)
        {
            if (!mSerialPort.IsOpen)
            {
                timerWriteSetting.Enabled = false;
                MessageBox.Show("Serial port is closed.");
                this.Enabled = true;
                return;
            }

            if (setting_command_index > 1)
            {
                setting_command_index = 0;
                timerWriteSetting.Enabled = false;
                this.Enabled = true;
                return;
            }
            WriteButtonClick(null, setting_command_index);
            setting_command_index++;
        }

        private void timerReadDeviceInfo_Tick(object sender, EventArgs e)
        {
            if (!mSerialPort.IsOpen)
            {
                timerReadDeviceInfo.Enabled = false;
                MessageBox.Show("Serial port is closed.");
                this.Enabled = true;
                return;
            }

            if (device_command_index > 6)
            {
                device_command_index = 2;
                timerReadDeviceInfo.Enabled = false;
                this.Enabled = true;
                return;
            }
            ReadButtonClick(null, device_command_index);
            device_command_index++;
        }

        private void timerWriteDeviceInfo_Tick(object sender, EventArgs e)
        {
            if (!mSerialPort.IsOpen)
            {
                timerWriteDeviceInfo.Enabled = false;
                MessageBox.Show("Serial port is closed.");
                this.Enabled = true;
                return;
            }

            if (device_command_index > 6)
            {
                device_command_index = 2;
                timerWriteDeviceInfo.Enabled = false;
                this.Enabled = true;
                return;
            }
            WriteButtonClick(null, device_command_index);
            device_command_index++;
        }

        private void btnReadLatestPHCalib_Click_1(object sender, EventArgs e)
        {
            if (!mSerialPort.IsOpen)
            {
                MessageBox.Show("Please Open Serial port!");
                return;
            }

            List<byte> command = Command.makeReadCommand(device_id, 90, 10);
            mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
            commandState = CommandState.READ_LATEST_PH_CALIB;
            showWriteLog("    Send READ_LATEST_PH_CALIB commnad --> \t\t", command);
        }

        private void btnReadLatestORPCalib_Click_1(object sender, EventArgs e)
        {
            if (!mSerialPort.IsOpen)
            {
                MessageBox.Show("Please Open Serial port!");
                return;
            }

            List<byte> command = Command.makeReadCommand(device_id, 100, 10);
            mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
            commandState = CommandState.READ_LATEST_ORP_CALIB;
            showWriteLog("    Send READ_LATEST_ORP_CALIB commnad --> \t\t", command);
        }

        private void btnPHCalibTime_Click(object sender, EventArgs e)
        {
            if (!mSerialPort.IsOpen)
            {
                MessageBox.Show("Please Open Serial port!");
                return;
            }
            UInt32 timestamp = Command.getCurrentTimeStamp();
            List<short> data = new List<short>();
            data.Add(BitConverter.ToInt16(BitConverter.GetBytes(timestamp), 0));
            data.Add(BitConverter.ToInt16(BitConverter.GetBytes(timestamp), 2));
            List<byte> command = Command.makeWriteCommand(device_id, 110, 2, data);
            mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
            commandState = CommandState.WRITE_PH_CALIB_TIME;
            showWriteLog("    Send WRITE_PH_CALIB_TIME commnad --> \t\t", command);
        }

        private void btnWrite1stPH_Click(object sender, EventArgs e)
        {
            if (!mSerialPort.IsOpen)
            {
                MessageBox.Show("Please Open Serial port!");
                return;
            }
            float buffer;
            try
            {
                buffer = float.Parse(txtpH1stBuffer.Text);
                List<byte> command = Command.makeWriteFloatCommand(device_id, 112, buffer);
                mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
                commandState = CommandState.WRITE_PH_FIRST_BUFFER;
                showWriteLog("    Send WRITE_PH_FIRST_BUFFER commnad --> \t\t", command);
            }
            catch
            {
                MessageBox.Show("Please insert correct number!");
            }
            
        }

        private void btnWrite2ndPH_Click(object sender, EventArgs e)
        {
            if (!mSerialPort.IsOpen)
            {
                MessageBox.Show("Please Open Serial port!");
                return;
            }
            float buffer;
            try
            {
                buffer = float.Parse(txtpH2ndBuffer.Text);
                List<byte> command = Command.makeWriteFloatCommand(device_id, 118, buffer);
                mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
                commandState = CommandState.WRITE_PH_SECOND_BUFFER;
                showWriteLog("    Send WRITE_PH_SECOND_BUFFER commnad --> \t\t", command);
            }
            catch
            {
                MessageBox.Show("Please insert correct number!");
            }
            
        }

        private void btnWrite3rdPH_Click(object sender, EventArgs e)
        {
            if (!mSerialPort.IsOpen)
            {
                MessageBox.Show("Please Open Serial port!");
                return;
            }
            float buffer;
            try
            {
                buffer = float.Parse(txtpH3rdBuffer.Text);
                List<byte> command = Command.makeWriteFloatCommand(device_id, 124, buffer);
                mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
                commandState = CommandState.WRITE_PH_THIRD_BUFFER;
                showWriteLog("    Send WRITE_PH_THIRD_BUFFER commnad --> \t\t", command);
            }
            catch
            {
                MessageBox.Show("Please insert correct number!");
            }
            
        }

        private void btnRunPHCalib_Click(object sender, EventArgs e)
        {
            if (!mSerialPort.IsOpen)
            {
                MessageBox.Show("Please Open Serial port!");
                return;
            }
                
            int cmd_code = int.Parse(cbxPHActionCode.Text);
            if(cmd_code == 1)
            {
                List<short> data = new List<short>();
                data.Add(2001);
                List<byte> command = Command.makeWriteCommand(device_id, 160, 1, data);
                mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
                commandState = CommandState.WRITE_ACTION_CODE;
                showWriteLog("    Send WRITE_ACTION_CODE commnad --> \t\t", command);

            }
            else if(cmd_code == 2)
            {
                List<short> data = new List<short>();
                data.Add(2002);
                List<byte> command = Command.makeWriteCommand(device_id, 160, 1, data);
                mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
                commandState = CommandState.WRITE_ACTION_CODE;
                showWriteLog("    Send WRITE_ACTION_CODE commnad --> \t\t", command);
            }
            else if(cmd_code == 3)
            {
                List<short> data = new List<short>();
                data.Add(2003);
                List<byte> command = Command.makeWriteCommand(device_id, 160, 1, data);
                mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
                commandState = CommandState.WRITE_ACTION_CODE;
                showWriteLog("    Send WRITE_ACTION_CODE commnad --> \t\t", command);
            }
            else
            {
                MessageBox.Show("Please insert correct number!");
            }

        }

        private void btnPHReadResult_Click(object sender, EventArgs e)
        {
            if (!mSerialPort.IsOpen)
            {
                MessageBox.Show("Please Open Serial port!");
                return;
            }

            List<byte> command = Command.makeReadCommand(device_id, 162, 1);
            mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
            commandState = CommandState.READ_PH_RESULT_CODE;
            showWriteLog("    Send READ_PH_RESULT_CODE commnad --> \t\t", command);
        }

        private void btnWriteORPCalibTime_Click(object sender, EventArgs e)
        {
            if (!mSerialPort.IsOpen)
            {
                MessageBox.Show("Please Open Serial port!");
                return;
            }
            UInt32 timestamp = Command.getCurrentTimeStamp();
            List<short> data = new List<short>();
            data.Add(BitConverter.ToInt16(BitConverter.GetBytes(timestamp), 0));
            data.Add(BitConverter.ToInt16(BitConverter.GetBytes(timestamp), 2));
            List<byte> command = Command.makeWriteCommand(device_id, 132, 2, data);
            mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
            commandState = CommandState.WRITE_ORP_CALIB_TIME;
            showWriteLog("    Send WRITE_ORP_CALIB_TIME commnad --> \t\t", command);
        }

        private void btnWriteORPPoint1_Click(object sender, EventArgs e)
        {
            if (!mSerialPort.IsOpen)
            {
                MessageBox.Show("Please Open Serial port!");
                return;
            }
            float buffer;
            try
            {
                buffer = float.Parse(txtORPPoint1.Text);
                List<byte> command = Command.makeWriteFloatCommand(device_id, 134, buffer);
                mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
                commandState = CommandState.WRITE_ORP_POINT1;
                showWriteLog("    Send WRITE_ORP_POINT1 commnad --> \t\t", command);
            }
            catch
            {
                MessageBox.Show("Please insert correct number!");
            }
        }

        private void btnWriteORPPoint2_Click(object sender, EventArgs e)
        {
            if (!mSerialPort.IsOpen)
            {
                MessageBox.Show("Please Open Serial port!");
                return;
            }
            float buffer;
            try
            {
                buffer = float.Parse(txtORPPoint2.Text);
                List<byte> command = Command.makeWriteFloatCommand(device_id, 138, buffer);
                mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
                commandState = CommandState.WRITE_ORP_POINT2;
                showWriteLog("    Send WRITE_ORP_POINT2 commnad --> \t\t", command);
            }
            catch
            {
                MessageBox.Show("Please insert correct number!");
            }
        }

        private void btnWriteORPPoint3_Click(object sender, EventArgs e)
        {
            if (!mSerialPort.IsOpen)
            {
                MessageBox.Show("Please Open Serial port!");
                return;
            }
            float buffer;
            try
            {
                buffer = float.Parse(txtORPPoint3.Text);
                List<byte> command = Command.makeWriteFloatCommand(device_id, 142, buffer);
                mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
                commandState = CommandState.WRITE_ORP_POINT3;
                showWriteLog("    Send WRITE_ORP_POINT3 commnad --> \t\t", command);
            }
            catch
            {
                MessageBox.Show("Please insert correct number!");
            }
        }

        private void btnWriteORPActionCode_Click(object sender, EventArgs e)
        {
            if (!mSerialPort.IsOpen)
            {
                MessageBox.Show("Please Open Serial port!");
                return;
            }

            int cmd_code = int.Parse(cbxORPActionCode.Text);
            if (cmd_code == 1)
            {
                List<short> data = new List<short>();
                data.Add(2005);
                List<byte> command = Command.makeWriteCommand(device_id, 160, 1, data);
                mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
                commandState = CommandState.WRITE_ACTION_CODE;
                showWriteLog("    Send WRITE_ACTION_CODE commnad --> \t\t", command);
            }
            else if (cmd_code == 2)
            {
                List<short> data = new List<short>();
                data.Add(2006);
                List<byte> command = Command.makeWriteCommand(device_id, 160, 1, data);
                mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
                commandState = CommandState.WRITE_ACTION_CODE;
                showWriteLog("    Send WRITE_ACTION_CODE commnad --> \t\t", command);
            }
            else if (cmd_code == 3)
            {
                List<short> data = new List<short>();
                data.Add(2007);
                List<byte> command = Command.makeWriteCommand(device_id, 160, 1, data);
                mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
                commandState = CommandState.WRITE_ACTION_CODE;
                showWriteLog("    Send WRITE_ACTION_CODE commnad --> \t\t", command);
            }
            else
            {
                MessageBox.Show("Please insert correct number!");
            }
        }

        private void btnORPCalibResultCode_Click(object sender, EventArgs e)
        {
            if (!mSerialPort.IsOpen)
            {
                MessageBox.Show("Please Open Serial port!");
                return;
            }

            List<byte> command = Command.makeReadCommand(device_id, 162, 1);
            mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
            commandState = CommandState.READ_ORP_RESULT_CODE;
            showWriteLog("    Send READ_ORP_RESULT_CODE commnad --> \t\t", command);
        }

        private void btnWriteCalibManualTime_Click(object sender, EventArgs e)
        {
            if (!mSerialPort.IsOpen)
            {
                MessageBox.Show("Please Open Serial port!");
                return;
            }
            UInt32 timestamp = Command.getCurrentTimeStamp();
            List<short> data = new List<short>();
            data.Add(BitConverter.ToInt16(BitConverter.GetBytes(timestamp), 0));
            data.Add(BitConverter.ToInt16(BitConverter.GetBytes(timestamp), 2));
            List<byte> command = Command.makeWriteCommand(device_id, 148, 2, data);
            mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
            commandState = CommandState.WRITE_PH_MANUAL_CALIB_TIME;
            showWriteLog("    Send WRITE_PH_MANUAL_CALIB_TIME commnad --> \t\t", command);
        }

        private void btnWriteZeroPoint_Click(object sender, EventArgs e)
        {
            if (!mSerialPort.IsOpen)
            {
                MessageBox.Show("Please Open Serial port!");
                return;
            }
            float buffer;
            try
            {
                buffer = float.Parse(txtZeroPoint.Text);
                List<byte> command = Command.makeWriteFloatCommand(device_id, 150, buffer);
                mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
                commandState = CommandState.WRITE_PH_MANUAL_ZERO_POINT;
                showWriteLog("    Send WRITE_PH_MANUAL_ZERO_POINT commnad --> \t\t", command);
            }
            catch
            {
                MessageBox.Show("Please insert correct number!");
            }
        }

        private void btnWriteAcidSlope_Click(object sender, EventArgs e)
        {
            if (!mSerialPort.IsOpen)
            {
                MessageBox.Show("Please Open Serial port!");
                return;
            }
            float buffer;
            try
            {
                buffer = float.Parse(txtAcidSlope.Text);
                List<byte> command = Command.makeWriteFloatCommand(device_id, 152, buffer);
                mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
                commandState = CommandState.WRITE_PH_MANUAL_ACID_SLOPE;
                showWriteLog("    Send WRITE_PH_MANUAL_ACID_SLOPE commnad --> \t\t", command);
            }
            catch
            {
                MessageBox.Show("Please insert correct number!");
            }
        }

        private void btnWriteBasicSlope_Click(object sender, EventArgs e)
        {
            if (!mSerialPort.IsOpen)
            {
                MessageBox.Show("Please Open Serial port!");
                return;
            }
            float buffer;
            try
            {
                buffer = float.Parse(txtBasicSlope.Text);
                List<byte> command = Command.makeWriteFloatCommand(device_id, 154, buffer);
                mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
                commandState = CommandState.WRITE_PH_MANUAL_BASIC_SLOPE;
                showWriteLog("    Send WRITE_PH_MANUAL_BASIC_SLOPE commnad --> \t\t", command);
            }
            catch
            {
                MessageBox.Show("Please insert correct number!");
            }
        }

        private void btnWriteCalibManualAction_Click(object sender, EventArgs e)
        {
            if (!mSerialPort.IsOpen)
            {
                MessageBox.Show("Please Open Serial port!");
                return;
            }

            List<short> data = new List<short>();
            data.Add(2000);
            List<byte> command = Command.makeWriteCommand(device_id, 160, 1, data);
            mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
            commandState = CommandState.WRITE_ACTION_CODE;
            showWriteLog("    Send WRITE_ACTION_CODE commnad --> \t\t", command);
        }

        private void btnCalibManualReadResult_Click(object sender, EventArgs e)
        {
            if (!mSerialPort.IsOpen)
            {
                MessageBox.Show("Please Open Serial port!");
                return;
            }

            List<byte> command = Command.makeReadCommand(device_id, 162, 1);
            mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
            commandState = CommandState.READ_MANUAL_RESULT_CODE;
            showWriteLog("    Send READ_MANUAL_RESULT_CODE commnad --> \t\t", command);
        }

        private void btnLatestTempCalibration_Click(object sender, EventArgs e)
        {
            if (!mSerialPort.IsOpen)
            {
                MessageBox.Show("Please Open Serial port!");
                return;
            }

            List<byte> command = Command.makeReadCommand(device_id, 4, 6);
            mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
            commandState = CommandState.READ_LATEST_TEMP_CALIB;
            showWriteLog("    Send READ_LATEST_TEMP_CALIB commnad --> \t\t", command);
        }

        private void btnWriteTempCalibTime_Click(object sender, EventArgs e)
        {
            if (!mSerialPort.IsOpen)
            {
                MessageBox.Show("Please Open Serial port!");
                return;
            }
            UInt32 timestamp = Command.getCurrentTimeStamp();
            List<short> data = new List<short>();
            data.Add(BitConverter.ToInt16(BitConverter.GetBytes(timestamp), 0));
            data.Add(BitConverter.ToInt16(BitConverter.GetBytes(timestamp), 2));
            List<byte> command = Command.makeWriteCommand(device_id, 170, 2, data);
            mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
            commandState = CommandState.WRITE_TEMP_CALIB_TIME;
            showWriteLog("    Send WRITE_TEMP_CALIB_TIME commnad --> \t\t", command);
        }

        private void btnWriteResOfPoint1_Click(object sender, EventArgs e)
        {
            if (!mSerialPort.IsOpen)
            {
                MessageBox.Show("Please Open Serial port!");
                return;
            }
            float buffer;
            try
            {
                buffer = float.Parse(txtResOfPoint1.Text);
                List<byte> command = Command.makeWriteFloatCommand(device_id, 172, buffer);
                mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
                commandState = CommandState.WRITE_TEMP_RES_POINT1;
                showWriteLog("    Send WRITE_TEMP_RES_POINT1 commnad --> \t\t", command);
            }
            catch
            {
                MessageBox.Show("Please insert correct number!");
            }
        }

        private void btnWriteResOfPoint2_Click(object sender, EventArgs e)
        {
            if (!mSerialPort.IsOpen)
            {
                MessageBox.Show("Please Open Serial port!");
                return;
            }
            float buffer;
            try
            {
                buffer = float.Parse(txtResOfPoint2.Text);
                List<byte> command = Command.makeWriteFloatCommand(device_id, 176, buffer);
                mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
                commandState = CommandState.WRITE_TEMP_RES_POINT2;
                showWriteLog("    Send WRITE_TEMP_RES_POINT2 commnad --> \t\t", command);
            }
            catch
            {
                MessageBox.Show("Please insert correct number!");
            }
        }

        private void btnRunTempCalib_Click(object sender, EventArgs e)
        {
            if (!mSerialPort.IsOpen)
            {
                MessageBox.Show("Please Open Serial port!");
                return;
            }

            List<short> data = new List<short>();
            data.Add(1001);
            List<byte> command = Command.makeWriteCommand(device_id, 160, 1, data);
            mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
            commandState = CommandState.WRITE_ACTION_CODE;
            showWriteLog("    Send WRITE_ACTION_CODE commnad --> \t\t", command);
        }

        private void btnFactoryResetSetting_Click(object sender, EventArgs e)
        {
            if (!mSerialPort.IsOpen)
            {
                MessageBox.Show("Please Open Serial port!");
                return;
            }

            List<short> data = new List<short>();
            data.Add(2010);
            List<byte> command = Command.makeWriteCommand(device_id, 160, 1, data);
            mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
            commandState = CommandState.WRITE_ACTION_CODE;
            showWriteLog("    Send WRITE_ACTION_CODE commnad --> \t\t", command);
        }

        private void btnFactoryResetCalib_Click(object sender, EventArgs e)
        {
            if (!mSerialPort.IsOpen)
            {
                MessageBox.Show("Please Open Serial port!");
                return;
            }

            List<short> data = new List<short>();
            data.Add(2011);
            List<byte> command = Command.makeWriteCommand(device_id, 160, 1, data);
            mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
            commandState = CommandState.WRITE_ACTION_CODE;
            showWriteLog("    Send WRITE_ACTION_CODE commnad --> \t\t", command);
        }

        private void btnReadTempCalibResult_Click(object sender, EventArgs e)
        {
            if (!mSerialPort.IsOpen)
            {
                MessageBox.Show("Please Open Serial port!");
                return;
            }

            List<byte> command = Command.makeReadCommand(device_id, 162, 1);
            mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
            commandState = CommandState.READ_TEMP_RESULT_CODE;
            showWriteLog("    Send READ_TEMP_RESULT_CODE commnad --> \t\t", command);
        }

        private void btnReadManualTemp_Click(object sender, EventArgs e)
        {
            if (!mSerialPort.IsOpen)
            {
                MessageBox.Show("Please Open Serial port!");
                return;
            }

            List<byte> command = Command.makeReadCommand(device_id, 70, 2);
            mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
            commandState = CommandState.READ_MTC_TEMPERATURE;
            showWriteLog("    Send READ_MTC_TEMPERATURE commnad --> \t\t", command);
        }

        private void btnWriteManualTemp_Click(object sender, EventArgs e)
        {
            if (!mSerialPort.IsOpen)
            {
                MessageBox.Show("Please Open Serial port!");
                return;
            }
            float buffer;
            try
            {
                buffer = float.Parse(txtWriteMTC.Text);
                List<byte> command = Command.makeWriteFloatCommand(device_id, 70, buffer);
                mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
                commandState = CommandState.WRITE_MTC_TEMPERATURE;
                showWriteLog("    Send WRITE_MTC_TEMPERATURE commnad --> \t\t", command);
            }
            catch
            {
                MessageBox.Show("Please insert correct number!");
            }
        }

        private void btnWriteTempMode_Click(object sender, EventArgs e)
        {
            if (!mSerialPort.IsOpen)
            {
                MessageBox.Show("Please Open Serial port!");
                return;
            }
            short atc_mtc_mode = 0;
            if (cbxTempMode.Text == "ATC")
            {
                atc_mtc_mode = 0;
            }
            else
            {
                atc_mtc_mode = 1;
            }
            List<short> data = new List<short>();
            data.Add(atc_mtc_mode);
            List<byte> command = Command.makeWriteCommand(device_id, 59, 1, data);  //75, repaired by kjh at 20200131
            mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
            commandState = CommandState.WRITE_TEMPERATURE_MODE;
            showWriteLog("    Send WRITE_TEMPERATURE_MODE commnad --> \t\t", command);
        }

        private void btnReadMTCStatus_Click(object sender, EventArgs e)
        {
            if (!mSerialPort.IsOpen)
            {
                MessageBox.Show("Please Open Serial port!");
                return;
            }

            List<byte> command = Command.makeReadCommand(device_id, 59, 1); //75
            mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
            commandState = CommandState.READ_TEMPER_STATUS;
            showWriteLog("    Send READ_TEMPER_STATUS commnad --> \t\t", command);
        }

        private void btnWriteTempBias_Click(object sender, EventArgs e)
        {
            if (!mSerialPort.IsOpen)
            {
                MessageBox.Show("Please Open Serial port!");
                return;
            }
            float buffer;
            try
            {
                buffer = float.Parse(txtTempBias.Text);
                List<byte> command = Command.makeWriteFloatCommand(device_id, 73, buffer);
                mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
                commandState = CommandState.WRITE_TEMP_BIAS;
                showWriteLog("    Send WRITE_TEMP_BIAS commnad --> \t\t", command);
            }
            catch
            {
                MessageBox.Show("Please insert correct number!");
            }
        }        

        private void btnReadTempBias_Click(object sender, EventArgs e)
        {
            if (!mSerialPort.IsOpen)
            {
                MessageBox.Show("Please Open Serial port!");
                return;
            }

            List<byte> command = Command.makeReadCommand(device_id, 73, 2);
            mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
            commandState = CommandState.READ_TEMP_BIAS;
            showWriteLog("    Send READ_TEMP_BIAS commnad --> \t\t", command);
        }

        private void btnWriteOrpBias_Click(object sender, EventArgs e)
        {
            if (!mSerialPort.IsOpen)
            {
                MessageBox.Show("Please Open Serial port!");
                return;
            }
            float buffer;
            try
            {
                buffer = float.Parse(txtOrpBias.Text);
                List<byte> command = Command.makeWriteFloatCommand(device_id, 76, buffer);
                mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
                commandState = CommandState.WRITE_ORP_BIAS;
                showWriteLog("    Send WRITE_ORP_BIAS commnad --> \t\t", command);
            }
            catch
            {
                MessageBox.Show("Please insert correct number!");
            }
        }

        private void btnReadOrpBias_Click(object sender, EventArgs e)
        {
            if (!mSerialPort.IsOpen)
            {
                MessageBox.Show("Please Open Serial port!");
                return;
            }

            List<byte> command = Command.makeReadCommand(device_id, 76, 2);
            mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
            commandState = CommandState.READ_ORP_BIAS;
            showWriteLog("    Send READ_ORP_BIAS commnad --> \t\t", command);
        }

        private void tabControl_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            groupPHCalib.Enabled = radioButton1.Checked;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            groupORPCalib.Enabled = radioButton2.Checked;
        }

        private void comboCalibType_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch(comboCalibType.SelectedIndex)
            {
                case 0:
                    txtPHOfBuffer1.Text = "";
                    txtPHOfBuffer2.Text = "";
                    txtPHOfBuffer3.Text = "";
                    break;
                case 1:
                    txtPHOfBuffer1.Text = "";
                    txtPHOfBuffer2.Text = "";
                    txtPHOfBuffer3.Text = "";
                    break;
                case 2:
                    txtPHOfBuffer1.Text = pHCalibValue.Buffer1.ToString();
                    txtPHOfBuffer2.Text = pHCalibValue.Buffer2.ToString();
                    txtPHOfBuffer3.Text = pHCalibValue.Buffer3.ToString();
                    break;
                default:
                    break;
            }
        }

        private void txtPHOfBuffer1_Click(object sender, EventArgs e)
        {
            if(comboCalibType.SelectedIndex == 2)
            {
                InputValue inputDlg = new InputValue("Please input pH value of first buffer.", float.Parse(txtPHOfBuffer1.Text));
                inputDlg.ShowDialog();
                if(inputDlg.result == DialogResult.OK)
                {
                    txtPHOfBuffer1.Text = inputDlg.Value.ToString();
                    pHCalibValue.Buffer1 = inputDlg.Value;
                }
            }
        }

        private void txtPHOfBuffer2_Click(object sender, EventArgs e)
        {
            if (comboCalibType.SelectedIndex == 2)
            {
                InputValue inputDlg = new InputValue("Please input pH value of second buffer.", float.Parse(txtPHOfBuffer2.Text));
                inputDlg.ShowDialog();
                if (inputDlg.result == DialogResult.OK)
                {
                    txtPHOfBuffer2.Text = inputDlg.Value.ToString();
                    pHCalibValue.Buffer2 = inputDlg.Value;
                }
            }
        }

        private void txtPHOfBuffer3_Click(object sender, EventArgs e)
        {
            if (comboCalibType.SelectedIndex == 2)
            {
                InputValue inputDlg = new InputValue("Please input pH value of third buffer.", float.Parse(txtPHOfBuffer3.Text));
                inputDlg.ShowDialog();
                if (inputDlg.result == DialogResult.OK)
                {
                    txtPHOfBuffer3.Text = inputDlg.Value.ToString();
                    pHCalibValue.Buffer3 = inputDlg.Value;
                }
            }
        }

        private void btnPHCalibStart_Click(object sender, EventArgs e)
        {
            commandState = CommandState.PH_CALIB_READ_PROBE;
            pHCalibValue.clear_data();
            pHCalibValue.StartTime = DateTime.Now;
            btnPHCalibStart.Enabled = false;
            timerCalib.Enabled = true;
            comboCalibType.Enabled = false;
        }

        private void timerCalib_Tick(object sender, EventArgs e)
        {
                       
            switch (commandState)
            {
                case CommandState.PH_CALIB_READ_PROBE:
                    List<byte> command = Command.makeReadCommand(device_id, 53, 0x06);
                    mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
                    showWriteLog("    Send Read Probe Data --> \t\t\t\t", command);
                    break;
                case CommandState.WRITE_PH_FIRST_BUFFER:
                    btnPHCalibBack.Enabled = true;
                    btnPHCalibContinue.Enabled = true;
                    btnPHCalibFinish.Enabled = true;
                    timerCalib.Enabled = false;
                    picPHCalibProcess.Image = PHPCTool.Properties.Resources.first;
                    command = Command.makeWriteFloatCommand(device_id, 112, pHCalibValue.Buffer1);
                    mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
                    showWriteLog("    Send WRITE_PH_FIRST_BUFFER commnad --> \t\t", command);
                    calibrationStep = CalibrationStep.PH_CALIB_FIRST;
                    break;
                case CommandState.WRITE_PH_SECOND_BUFFER:
                    btnPHCalibBack.Enabled = true;
                    btnPHCalibContinue.Enabled = true;
                    btnPHCalibFinish.Enabled = true;
                    timerCalib.Enabled = false;
                    picPHCalibProcess.Image = PHPCTool.Properties.Resources.second;
                    command = Command.makeWriteFloatCommand(device_id, 118, pHCalibValue.Buffer2);
                    mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
                    showWriteLog("    Send WRITE_PH_SECOND_BUFFER commnad --> \t\t", command);
                    calibrationStep = CalibrationStep.PH_CALIB_SECOND;
                    break;
                case CommandState.WRITE_PH_THIRD_BUFFER:
                    btnPHCalibBack.Enabled = true;
                    btnPHCalibContinue.Enabled = false;
                    btnPHCalibFinish.Enabled = true;
                    timerCalib.Enabled = false;
                    picPHCalibProcess.Image = PHPCTool.Properties.Resources.third;
                    command = Command.makeWriteFloatCommand(device_id, 124, pHCalibValue.Buffer3);
                    mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
                    showWriteLog("    Send WRITE_PH_THIRD_BUFFER commnad --> \t\t", command);
                    calibrationStep = CalibrationStep.PH_CALIB_THIRD;
                    break;
                case CommandState.PH_CALIB_WRITE_TIME:
                    UInt32 timestamp = Command.getCurrentTimeStamp();
                    List<short> data = new List<short>();
                    data.Add(BitConverter.ToInt16(BitConverter.GetBytes(timestamp), 0));
                    data.Add(BitConverter.ToInt16(BitConverter.GetBytes(timestamp), 2));
                    command = Command.makeWriteCommand(device_id, 110, 2, data);
                    mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);                    
                    showWriteLog("    Send PH_CALIB_WRITE_TIME commnad --> \t\t", command);
                    break;
                case CommandState.PH_CALIB_RUN:
                    switch (calibrationStep)
                    {
                        case CalibrationStep.PH_CALIB_FIRST:
                            data = new List<short>();
                            data.Add(2001);
                            command = Command.makeWriteCommand(device_id, 160, 1, data);
                            mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
                            showWriteLog("    Send PH_CALIB_RUN commnad --> \t\t", command);
                            break;
                        case CalibrationStep.PH_CALIB_SECOND:
                            data = new List<short>();
                            data.Add(2002);
                            command = Command.makeWriteCommand(device_id, 160, 1, data);
                            mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
                            showWriteLog("    Send PH_CALIB_RUN commnad --> \t\t", command);
                            break;
                        case CalibrationStep.PH_CALIB_THIRD:
                            data = new List<short>();
                            data.Add(2003);
                            command = Command.makeWriteCommand(device_id, 160, 1, data);
                            mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
                            showWriteLog("    Send PH_CALIB_RUN commnad --> \t\t", command);
                            break;
                    }
                    break;
                case CommandState.PH_CALIB_READ_RESULT:
                    command = Command.makeReadCommand(device_id, 162, 1);
                    mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
                    showWriteLog("    Send PH_CALIB_READ_RESULT commnad --> \t\t", command);
                    break;
                case CommandState.PH_CALIB_READ_LATEST:
                    command = Command.makeReadCommand(device_id, 90, 10);
                    mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
                    showWriteLog("    Send PH_CALIB_READ_LATEST commnad --> \t\t", command);
                    timerCalib.Enabled = false;
                    break;
                case CommandState.ORP_CALIB_READ_PROBE:
                    command = Command.makeReadCommand(device_id, 65, 0x02);
                    mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
                    showWriteLog("    Send ORP_CALIB_READ_PROBE --> \t\t\t\t", command);
                    break;
                case CommandState.WRITE_ORP_POINT1:
                    btnORPCalibBack.Enabled = true;
                    btnORPCalibContinue.Enabled = true;
                    btnORPCalibFinish.Enabled = true;
                    timerCalib.Enabled = false;
                    picORPCalibProgress.Image = PHPCTool.Properties.Resources.first;
                    command = Command.makeWriteFloatCommand(device_id, 134, orpCalibValue.Buffer1);
                    mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
                    showWriteLog("    Send WRITE_ORP_POINT1 commnad --> \t\t", command);
                    orpCalibStep = ORPCalibrationStep.ORP_CALIB_FIRST;
                    break;
                case CommandState.WRITE_ORP_POINT2:
                    btnORPCalibBack.Enabled = true;
                    btnORPCalibContinue.Enabled = true;
                    btnORPCalibFinish.Enabled = true;
                    timerCalib.Enabled = false;
                    picORPCalibProgress.Image = PHPCTool.Properties.Resources.second;
                    command = Command.makeWriteFloatCommand(device_id, 138, orpCalibValue.Buffer2);
                    mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
                    showWriteLog("    Send WRITE_ORP_POINT2 commnad --> \t\t", command);
                    orpCalibStep = ORPCalibrationStep.ORP_CALIB_SECOND;
                    break;
                case CommandState.WRITE_ORP_POINT3:
                    btnORPCalibBack.Enabled = true;
                    btnORPCalibContinue.Enabled = false;
                    btnORPCalibFinish.Enabled = true;
                    timerCalib.Enabled = false;
                    picORPCalibProgress.Image = PHPCTool.Properties.Resources.third;
                    command = Command.makeWriteFloatCommand(device_id, 142, orpCalibValue.Buffer3);
                    mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
                    showWriteLog("    Send WRITE_ORP_POINT3 commnad --> \t\t", command);
                    orpCalibStep = ORPCalibrationStep.ORP_CALIB_THIRD;
                    break;
                case CommandState.ORP_CALIB_WRITE_TIME:
                    timestamp = Command.getCurrentTimeStamp();
                    data = new List<short>();
                    data.Add(BitConverter.ToInt16(BitConverter.GetBytes(timestamp), 0));
                    data.Add(BitConverter.ToInt16(BitConverter.GetBytes(timestamp), 2));
                    command = Command.makeWriteCommand(device_id, 132, 2, data);
                    mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
                    showWriteLog("    Send ORP_CALIB_WRITE_TIME commnad --> \t\t", command);
                    break;
                case CommandState.ORP_CALIB_RUN:
                    switch (orpCalibStep)
                    {
                        case ORPCalibrationStep.ORP_CALIB_FIRST:
                            data = new List<short>();
                            data.Add(2005);
                            command = Command.makeWriteCommand(device_id, 160, 1, data);
                            mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
                            showWriteLog("    Send ORP_CALIB_RUN commnad --> \t\t", command);
                            break;
                        case ORPCalibrationStep.ORP_CALIB_SECOND:
                            data = new List<short>();
                            data.Add(2006);
                            command = Command.makeWriteCommand(device_id, 160, 1, data);
                            mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
                            showWriteLog("    Send ORP_CALIB_RUN commnad --> \t\t", command);
                            break;
                        case ORPCalibrationStep.ORP_CALIB_THIRD:
                            data = new List<short>();
                            data.Add(2007);
                            command = Command.makeWriteCommand(device_id, 160, 1, data);
                            mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
                            showWriteLog("    Send ORP_CALIB_RUN commnad --> \t\t", command);
                            break;
                    }
                    break;
                case CommandState.ORP_CALIB_READ_RESULT:
                    command = Command.makeReadCommand(device_id, 162, 1);
                    mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
                    showWriteLog("    Send ORP_CALIB_READ_RESULT commnad --> \t\t", command);
                    break;
                case CommandState.ORP_CALIB_READ_LATEST:
                    command = Command.makeReadCommand(device_id, 100, 10);
                    mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
                    showWriteLog("    Send ORP_CALIB_READ_LATEST commnad --> \t\t", command);
                    timerCalib.Enabled = false;
                    break;
                case CommandState.TEMP_CALIB_READ_RES1:
                    command = Command.makeReadCommand(device_id, 63, 0x02);
                    mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
                    showWriteLog("    Send TEMP_CALIB_READ_RES1 --> \t\t\t\t", command);
                    break;
                case CommandState.WRITE_TEMP_RES_POINT1:
                    command = Command.makeWriteFloatCommand(device_id, 172, tempCalibValue.Buffer1);
                    mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
                    showWriteLog("    Send WRITE_TEMP_RES_POINT1 commnad --> \t\t", command);
                    btnTempCalibRunP1.Enabled = true;
                    btnTempCalibRunP2.Enabled = true;
                    btnTempCalibRunCalib.Enabled = true;
                    timerCalib.Enabled = false;
                    txtTempCalibResMea1.ForeColor = Color.Red;
                    break;
                case CommandState.TEMP_CALIB_READ_RES2:
                    command = Command.makeReadCommand(device_id, 63, 0x02);
                    mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
                    showWriteLog("    Send TEMP_CALIB_READ_RES2 --> \t\t\t\t", command);
                    break;
                case CommandState.WRITE_TEMP_RES_POINT2:
                    command = Command.makeWriteFloatCommand(device_id, 172, tempCalibValue.Buffer2);
                    mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
                    showWriteLog("    Send WRITE_TEMP_RES_POINT2 commnad --> \t\t", command);
                    btnTempCalibRunP1.Enabled = true;
                    btnTempCalibRunP2.Enabled = true;
                    btnTempCalibRunCalib.Enabled = true;
                    timerCalib.Enabled = false;
                    txtTempCalibResMea2.ForeColor = Color.Red;
                    break;
                case CommandState.TEMP_CALIB_WRITE_TIME:
                    timestamp = Command.getCurrentTimeStamp();
                    data = new List<short>();
                    data.Add(BitConverter.ToInt16(BitConverter.GetBytes(timestamp), 0));
                    data.Add(BitConverter.ToInt16(BitConverter.GetBytes(timestamp), 2));
                    command = Command.makeWriteCommand(device_id, 170, 2, data);
                    mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
                    showWriteLog("    Send TEMP_CALIB_WRITE_TIME commnad --> \t\t", command);
                    break;
                case CommandState.TEMP_CALIB_RUN:
                    data = new List<short>();
                    data.Add(1001);
                    command = Command.makeWriteCommand(device_id, 160, 1, data);
                    mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
                    showWriteLog("    Send TEMP_CALIB_RUN commnad --> \t\t", command);
                    break;
                case CommandState.TEMP_CALIB_READ_RESULT:
                    command = Command.makeReadCommand(device_id, 162, 1);
                    mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
                    showWriteLog("    Send ORP_CALIB_READ_RESULT commnad --> \t\t", command);
                    break;
                case CommandState.TEMP_CALIB_READ_LATEST:
                    command = Command.makeReadCommand(device_id, 4, 6);
                    mSerialPort.Write(command.ToArray(), 0, command.ToArray().Length);
                    showWriteLog("    Send TEMP_CALIB_READ_LATEST commnad --> \t\t", command);
                    timerCalib.Enabled = false;
                    break;
                default:
                    break;
            }
        }

        private void btnPHCalibBack_Click(object sender, EventArgs e)
        {
            switch(calibrationStep)
            {
                case CalibrationStep.PH_CALIB_FIRST:
                    calibrationStep = CalibrationStep.PH_CALIB_START;
                    btnPHCalibBack.Enabled = false;
                    btnPHCalibContinue.Enabled = false;
                    btnPHCalibFinish.Enabled = false;
                    btnPHCalibStart.Enabled = true;
                    if(comboCalibType.SelectedIndex != 2)
                        txtPHOfBuffer1.Text = "";
                    comboCalibType.Enabled = true;
                    picPHCalibProcess.Image = PHPCTool.Properties.Resources.start;
                    break;
                case CalibrationStep.PH_CALIB_SECOND:
                    calibrationStep = CalibrationStep.PH_CALIB_FIRST;
                    if (comboCalibType.SelectedIndex != 2)
                        txtPHOfBuffer2.Text = "";
                    picPHCalibProcess.Image = PHPCTool.Properties.Resources.first;
                    break;
                case CalibrationStep.PH_CALIB_THIRD:
                    calibrationStep = CalibrationStep.PH_CALIB_SECOND;
                    btnPHCalibContinue.Enabled = true;
                    if (comboCalibType.SelectedIndex != 2)
                        txtPHOfBuffer3.Text = "";
                    picPHCalibProcess.Image = PHPCTool.Properties.Resources.second;
                    break;
            }
            
            txtPHVoltage.Text = "";
            txtPHCalibTemp.Text = "";
            txtPHCalibTime.Text = "";
            txtPHOfBuffer.Text = "";
        }

        private void btnPHCalibContinue_Click(object sender, EventArgs e)
        {
            switch (calibrationStep)
            {
                case CalibrationStep.PH_CALIB_FIRST:
                    commandState = CommandState.PH_CALIB_READ_PROBE;
                    pHCalibValue.clear_data();
                    pHCalibValue.StartTime = DateTime.Now;
                    btnPHCalibBack.Enabled = false;
                    btnPHCalibContinue.Enabled = false;
                    btnPHCalibFinish.Enabled = false;
                    timerCalib.Enabled = true;
                    break;
                case CalibrationStep.PH_CALIB_SECOND:
                    commandState = CommandState.PH_CALIB_READ_PROBE;
                    pHCalibValue.clear_data();
                    pHCalibValue.StartTime = DateTime.Now;
                    btnPHCalibBack.Enabled = false;
                    btnPHCalibContinue.Enabled = false;
                    btnPHCalibFinish.Enabled = false;
                    timerCalib.Enabled = true;
                    break;
            }
        }

        private void btnPHCalibFinish_Click(object sender, EventArgs e)
        {
            commandState = CommandState.PH_CALIB_WRITE_TIME;
            btnPHCalibBack.Enabled = false;
            btnPHCalibContinue.Enabled = false;
            btnPHCalibFinish.Enabled = false;
            switch (calibrationStep)
            {
                case CalibrationStep.PH_CALIB_FIRST:
                    picPHCalibProcess.Image = PHPCTool.Properties.Resources.first_finish;
                    break;
                case CalibrationStep.PH_CALIB_SECOND:
                    picPHCalibProcess.Image = PHPCTool.Properties.Resources.second_finish;
                    break;
                case CalibrationStep.PH_CALIB_THIRD:
                    picPHCalibProcess.Image = PHPCTool.Properties.Resources.third_finish;
                    break;
            }
            timerCalib.Enabled = true;
        }

        private void txtORPBuffer1_Click(object sender, EventArgs e)
        {
            InputValue inputDlg = new InputValue("Please input ORP value of first buffer.", float.Parse(txtORPBuffer1.Text));
            inputDlg.ShowDialog();
            if (inputDlg.result == DialogResult.OK)
            {
                txtORPBuffer1.Text = inputDlg.Value.ToString();
                orpCalibValue.Buffer1 = inputDlg.Value;
            }
        }

        private void txtORPBuffer2_Click(object sender, EventArgs e)
        {
            InputValue inputDlg = new InputValue("Please input ORP value of second buffer.", float.Parse(txtORPBuffer2.Text));
            inputDlg.ShowDialog();
            if (inputDlg.result == DialogResult.OK)
            {
                txtORPBuffer2.Text = inputDlg.Value.ToString();
                orpCalibValue.Buffer2 = inputDlg.Value;
            }
        }

        private void txtORPBuffer3_Click(object sender, EventArgs e)
        {
            InputValue inputDlg = new InputValue("Please input ORP value of third buffer.", float.Parse(txtORPBuffer3.Text));
            inputDlg.ShowDialog();
            if (inputDlg.result == DialogResult.OK)
            {
                txtORPBuffer3.Text = inputDlg.Value.ToString();
                orpCalibValue.Buffer3 = inputDlg.Value;
            }
        }

        private void btnORPCalibStart_Click(object sender, EventArgs e)
        {
            commandState = CommandState.ORP_CALIB_READ_PROBE;
            orpCalibValue.clear_data();
            btnORPCalibStart.Enabled = false;
            timerCalib.Enabled = true;
        }

        private void btnORPCalibBack_Click(object sender, EventArgs e)
        {
            switch (orpCalibStep)
            {
                case ORPCalibrationStep.ORP_CALIB_FIRST:
                    orpCalibStep = ORPCalibrationStep.ORP_CALIB_START;
                    btnORPCalibBack.Enabled = false;
                    btnORPCalibContinue.Enabled = false;
                    btnORPCalibFinish.Enabled = false;
                    btnORPCalibStart.Enabled = true;
                    txtORPMeasure1.Text = "";
                    picORPCalibProgress.Image = PHPCTool.Properties.Resources.start;
                    break;
                case ORPCalibrationStep.ORP_CALIB_SECOND:
                    orpCalibStep = ORPCalibrationStep.ORP_CALIB_FIRST;
                    txtORPMeasure2.Text = "";
                    picORPCalibProgress.Image = PHPCTool.Properties.Resources.first;
                    break;
                case ORPCalibrationStep.ORP_CALIB_THIRD:
                    orpCalibStep = ORPCalibrationStep.ORP_CALIB_SECOND;
                    btnORPCalibContinue.Enabled = true;
                    txtORPMeasure3.Text = "";
                    picORPCalibProgress.Image = PHPCTool.Properties.Resources.second;
                    break;
            }
        }

        private void btnORPCalibContinue_Click(object sender, EventArgs e)
        {
            switch (orpCalibStep)
            {
                case ORPCalibrationStep.ORP_CALIB_FIRST:
                    commandState = CommandState.ORP_CALIB_READ_PROBE;
                    orpCalibValue.clear_data();
                    btnORPCalibBack.Enabled = false;
                    btnORPCalibContinue.Enabled = false;
                    btnORPCalibFinish.Enabled = false;
                    timerCalib.Enabled = true;
                    break;
                case ORPCalibrationStep.ORP_CALIB_SECOND:
                    commandState = CommandState.ORP_CALIB_READ_PROBE;
                    orpCalibValue.clear_data();
                    btnORPCalibBack.Enabled = false;
                    btnORPCalibContinue.Enabled = false;
                    btnORPCalibFinish.Enabled = false;
                    timerCalib.Enabled = true;
                    break;
            }
        }

        private void btnORPCalibFinish_Click(object sender, EventArgs e)
        {
            commandState = CommandState.ORP_CALIB_WRITE_TIME;
            btnORPCalibBack.Enabled = false;
            btnORPCalibContinue.Enabled = false;
            btnORPCalibFinish.Enabled = false;
            switch (orpCalibStep)
            {
                case ORPCalibrationStep.ORP_CALIB_FIRST:
                    picORPCalibProgress.Image = PHPCTool.Properties.Resources.first_finish;
                    break;
                case ORPCalibrationStep.ORP_CALIB_SECOND:
                    picORPCalibProgress.Image = PHPCTool.Properties.Resources.second_finish;
                    break;
                case ORPCalibrationStep.ORP_CALIB_THIRD:
                    picORPCalibProgress.Image = PHPCTool.Properties.Resources.third_finish;
                    break;
            }
            timerCalib.Enabled = true;
        }

        private void txtTempCalibRes1_Click(object sender, EventArgs e)
        {
            InputValue inputDlg = new InputValue("Please input Resistance of first point.", float.Parse(txtTempCalibRes1.Text));
            inputDlg.ShowDialog();
            if (inputDlg.result == DialogResult.OK)
            {
                txtTempCalibRes1.Text = inputDlg.Value.ToString();
                tempCalibValue.Buffer1 = inputDlg.Value;
            }
        }

        private void txtTempCalibRes2_Click(object sender, EventArgs e)
        {
            InputValue inputDlg = new InputValue("Please input Resistance of first point.", float.Parse(txtTempCalibRes2.Text));
            inputDlg.ShowDialog();
            if (inputDlg.result == DialogResult.OK)
            {
                txtTempCalibRes2.Text = inputDlg.Value.ToString();
                tempCalibValue.Buffer2 = inputDlg.Value;
            }
        }

        private void btnTempCalibRunP1_Click(object sender, EventArgs e)
        {
            commandState = CommandState.TEMP_CALIB_READ_RES1;
            tempCalibValue.clear_data();
            btnTempCalibRunP1.Enabled = false;
            btnTempCalibRunP2.Enabled = false;
            btnTempCalibRunCalib.Enabled = false;
            timerCalib.Enabled = true;
        }

        private void btnTempCalibRunP2_Click(object sender, EventArgs e)
        {
            commandState = CommandState.TEMP_CALIB_READ_RES2;
            tempCalibValue.clear_data();
            btnTempCalibRunP1.Enabled = false;
            btnTempCalibRunP2.Enabled = false;
            btnTempCalibRunCalib.Enabled = false;
            timerCalib.Enabled = true;
        }

        private void btnTempCalibRunCalib_Click(object sender, EventArgs e)
        {
            commandState = CommandState.TEMP_CALIB_WRITE_TIME;
            btnTempCalibRunP1.Enabled = false;
            btnTempCalibRunP2.Enabled = false;
            btnTempCalibRunCalib.Enabled = false;
            timerCalib.Enabled = true;
        }
    }
}
