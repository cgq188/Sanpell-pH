﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PHPCTool
{
    public partial class CalibResult : Form
    {
        string strTime;
        float zero_point;
        float slope1, slope2;
        string calib_type;

        public CalibResult()
        {
            InitializeComponent();
        }

        private void CalibResult_Load(object sender, EventArgs e)
        {
            lblCalibTime.Text = strTime;
            lblZeroPoint.Text = zero_point.ToString("F2");
            lblSlope1.Text = slope1.ToString("F2");
            lblSlope2.Text = slope2.ToString("F2");
            lblCalibType.Text = calib_type;
        }

        public CalibResult(string _strTime, float _zero_point, float _slope1, float _slope2, string _calib_type)
        {
            InitializeComponent();
            strTime = _strTime;
            zero_point = _zero_point;
            slope1 = _slope1;
            slope2 = _slope2;
            calib_type = _calib_type;
        }


    }
}
