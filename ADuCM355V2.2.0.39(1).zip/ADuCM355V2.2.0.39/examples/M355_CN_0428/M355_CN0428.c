/**
 *****************************************************************************
 * @addtogroup EC sensor
 * @{
 * @file     M355_CN0428.c
 * @brief    CN0428 Main Program Water Quality
 * @par Revision History:
 * @version  V0.1
 * @author   ADI
 * @date     June 2018
 * @par Revision History:
 * - V0.1, June 2018: Initial version
 * Decription:
 *   Set up terminal to send and recieve commands via a command line interface
 *   -- Default I2C (see config file) EVAL-CN0428-EBZ used with EVAL-ADICUP3029.
 *        Baud rate for ADICUP3029: 115200, 8 data bits, 1 stop bit, no parity
 *        See CN0428 user guide for more details
 *   -- UART mode (see config file) can be used with the EVAL-ADuCM355 **AS LONG
 *        AS THE EVAL-CN0428-EBZ SCHEMATIC IS REPLICATED ON EVAL-ADuCM355**.
 *        The extra calibration resistors can be plugged into P5 and an SOIC
 *        op amp such as AD8606 fits into the provided footprint(config file)
 *        UART mode baud rate is 57600, 8 data bit, 1 stop bit
 *   -- EIS test sweeps from 0.15 Hz to 180 kHz, autoranging and connecting
 *        necessary gain resistors. Comment/change EISRESULT array to change
 *        which frequencies are measured
 *   -- pH sensor, conductivity, or ORP connects to ch 0, between RE and SE.
 *        Temp sensor is ch 1
 *   -- DEBUG can be set to 1 to show debugging dialogs with information and
 *        intermediate values or 0 to suppress them
 *   -- See M355WqConfig.h for more configuration settings.
 *
All files for ADuCM355 provided by ADI, including this file, are
provided  as is without warranty of any kind, either expressed or implied.
The user assumes any and all risk from the use of this code.
It is the responsibility of the person integrating this code into an application
to ensure that the resulting application performs as required and is safe.
 *
**/
#include "M355WqConfig.h"
#include "M355WqEcTests.h"
#include "M355WqCmd.h"
#include "M355_CN0428.h"

#include "mb.h"
#include "intrinsics.h"

#include "hal_mem.h"
int modbus_rtu_init( void );
int modbus_rtu_poll  ( void );

/*
   user can modify frequency of impedance measurement
*/
ImpResult_t EISResult[] = {
	//low frequency measurement takes longer because of big period
	{0.2,{0,0,0,0},0,0},		//0.15Hz = 11s
	{0.4,{0,0,0,0},0,0},		//0.4Hz = 5.5s
	{0.8,{0,0,0,0},0,0},		//0.75Hz = 3.6s
	{1,{0,0,0,0},0,0},		//1Hz = 3.6s
	{2,{0,0,0,0},0,0},		//2Hz = 1.8s
	{5,{0,0,0,0},0,0},
	{10,{0,0,0,0},0,0},
	{20,{0,0,0,0},0,0},
	{50,{0,0,0,0},0,0},
	{95,{0,0,0,0},0,0},
	{255,{0,0,0,0},0,0},
	{500,{0,0,0,0},0,0},
	{1000,{0,0,0,0},{0},0,0},
	{2000,{0,0,0,0},{0},0,0},
	{5000,{0,0,0,0},{0},0,0},
	{10000,{0,0,0,0},{0},0,0},
	{20000,{0,0,0,0},{0},0,0},
	{50000,{0,0,0,0},{0},0,0},
	{80000,{0,0,0,0},{0},0,0},
	{100000,{0,0,0,0},{0},0,0},
	{120000,{0,0,0,0},{0},0,0},
	{150000,{0,0,0,0},{0},0,0},
	{180000,{0,0,0,0},{0},0,0},
	//user can add frequency options here
};

size_t EISResultArrSize = sizeof(EISResult)/sizeof(ImpResult_t);


int mModbusRtuPoll_Cnt = 0;

void PendSV_Handler()
{
	mModbusRtuPoll_Cnt =  modbus_rtu_poll();
	if(mModbusRtuPoll_Cnt )
	{
		mModbusRtuPoll_Cnt--;

		//trigger penscv
		( * ( ( volatile uint32_t * ) 0xe000ed04 ) ) = ( 1UL << 28UL );
		__DSB();
		__ISB();
	}
}

uint16_t mPreDevType;
uint16_t mPreHizMode;

/*=========================== main - program entry point ====================*/
void main(void)
{
	AfeWdtGo(false);
	GPIOInit();
	ClockInit();
	//Ensure appropriate communication interface is set up in M355WqCmd.h file.
#ifdef UARTcomms
#if DEBUG
	UartInit();
#endif
#endif /*UARTcomms*/
#ifdef I2Ccomms
	I2CInit(ADI_CFG_I2C_DEFAULT_ADDR); //If using i2C, address will be set based on site using P0.3 GPIO
#endif /*I2Ccomms*/
	/***Initialize channels***/
	pSnsCfg0 = getSnsCfg(CHAN0);
	pSnsCfg1 = getSnsCfg(CHAN1);

	cfgInfo_init();

	cfgInfo_t cfgInfo;
	cfgInfo_get(&cfgInfo);

	mPreDevType = cfgInfo.devType;
	mPreHizMode = cfgInfo.hizMode;

	flagHiZMode = cfgInfo.hizMode;

	if(cfgInfo.devType == DEV_TYPE_COND )
	{
		pSnsCfg0->Sensor_Type = Conductivity;
	}
	else if(cfgInfo.devType == DEV_TYPE_ORP )
	{
		pSnsCfg0->Sensor_Type = ORP;
	}
	else if(cfgInfo.devType == DEV_TYPE_PH )
	{
		pSnsCfg0->Sensor_Type = pH ;
	}

	if(cfgInfo.tempSensorType == TEMP_SENSOR_TYPE_PT100)//pt100
	{
		myTempSensor. R1 = 100;			/* NTC: nominal resistance. RTD: resistance at T1. */
		myTempSensor. T1 = 0;			/* NTC: temperature at nominal resistance. RTD: temperature for R1. */
		myTempSensor. R2 = 138.5;	    /* RTD point 2 resistance */
		myTempSensor. T2 = 100;			/* RTD point 2 temperature */
	}
	else if(cfgInfo.tempSensorType == TEMP_SENSOR_TYPE_PT1000)//pt1000
	{
		myTempSensor. R1 = 1000;			/* NTC: nominal resistance. RTD: resistance at T1. */
		myTempSensor. T1 = 0;			/* NTC: temperature at nominal resistance. RTD: temperature for R1. */
		myTempSensor. R2 = 1385;	    /* RTD point 2 resistance */
		myTempSensor. T2 = 100;			/* RTD point 2 temperature */
	}
	else if(cfgInfo.tempSensorType == TEMP_SENSOR_TYPE_NTC30K)//NTC30K
	{
		myTempSensor. R1 = 30000;			/* NTC: nominal resistance. RTD: resistance at T1. */
		myTempSensor. T1 = 25;			/* NTC: temperature at nominal resistance. RTD: temperature for R1. */
	}

	if((pSnsCfg0->Enable == SENSOR_CHANNEL_ENABLE)) {
		printf("%s Sensor Initializing...", pSnsCfg0->SensorName);
		SnsInit(pSnsCfg0);
		delay_10us(10000);
		printf("Finish. "EOL);
		printf("Sensor Type: %s   Temperature: %s" EOL, szSnsType[DEFAULT_SENSOR],
		       szTempSnsType[TEMPSENSORTYPE*(uint8_t)((bool)TEMP_SENSOR_INCLUDED)]);
		if(flagHiZMode) {
			printf("Hi-Z Mode Enabled! Ensure S2 is set to HiZ!" EOL);
		} else {
			printf("Hi-Z Mode Disabled. Ensure S2 is set to Int!" EOL);
		}
	}
	if((pSnsCfg1->Enable == SENSOR_CHANNEL_ENABLE)) {
		printf("%s Sensor Initializing...", pSnsCfg1->SensorName);
		SnsInit(pSnsCfg1);
		delay_10us(10000);
		printf("Finish" EOL);
	}
	printf("Calibrating ADC...");
	CalibrateAdc();
	delay_10us(200000);
#if DEBUG
	printf("ADCOFFSETGN1 = 0x%X, ", pADI_AFE->ADCOFFSETGN1);
	printf("ADCGAINGN1 = 0x%X...", pADI_AFE->ADCGAINGN1);
#endif /*DEBUG*/
	printf("Finish" EOL);
	/***Display Command Prompt***/
#if DEBUG
	printf("ATE_REV 0x%x", ATE_REV);
#endif /*DEBUG*/
	Wq_CmdPrompt();

#if !DEBUG
	modbus_rtu_init();
#else
	DioSetPin(pADI_GPIO0,PIN0);			//make RS485 in TX status
#endif

	/***Run Command Line Interface***/
	while(1) {
		//Wait for command
//		delay_10us(10000);
		if (ucPacketReceived ==1) { //Enter has been pressed
			ucPacketReceived = 0;
			Wq_CmdProcess();
#ifndef UARTcomms
			printf("~");
#endif /* UARTcomms */
		}

		Wq_CmdTemp(0);
		MeasureParameter(0);

		//update cfg info
		cfgInfo_get(&cfgInfo);

		if(mPreDevType != cfgInfo.devType)
		{
			ChangeDevType(  cfgInfo.devType );
		}
		mPreDevType = cfgInfo.devType;


		if(mPreHizMode != cfgInfo.hizMode)
		{
			HiZModeSet(cfgInfo.hizMode);
		}
		mPreHizMode = cfgInfo.hizMode;


		if(cfgInfo.tempSensorType == TEMP_SENSOR_TYPE_PT100)//pt100
		{
			myTempSensor. R1 = 100;			/* NTC: nominal resistance. RTD: resistance at T1. */
			myTempSensor. T1 = 0;			/* NTC: temperature at nominal resistance. RTD: temperature for R1. */
			myTempSensor. R2 = 138.5;	    /* RTD point 2 resistance */
			myTempSensor. T2 = 100;			/* RTD point 2 temperature */
		}
		else if(cfgInfo.tempSensorType == TEMP_SENSOR_TYPE_PT1000)//pt1000
		{
			myTempSensor. R1 = 1000;			/* NTC: nominal resistance. RTD: resistance at T1. */
			myTempSensor. T1 = 0;			/* NTC: temperature at nominal resistance. RTD: temperature for R1. */
			myTempSensor. R2 = 1385;	    /* RTD point 2 resistance */
			myTempSensor. T2 = 100;			/* RTD point 2 temperature */
		}
		else if(cfgInfo.tempSensorType == TEMP_SENSOR_TYPE_NTC30K)//NTC30K
		{
			myTempSensor. R1 = 30000;			/* NTC: nominal resistance. RTD: resistance at T1. */
			myTempSensor. T1 = 25;			/* NTC: temperature at nominal resistance. RTD: temperature for R1. */
		}
	}
}

/*===================== Initialization and communications ====================*/

void GPIOInit(void)
{
	/*SPI_/CS0 configuration as GPIO - Read with GP0IN register*/
	DioCfgPin(pADI_GPIO0,PIN3,0); //confige as gpio
	DioIenPin(pADI_GPIO0,PIN3,1); //enable input
	DioPulPin(pADI_GPIO0,PIN3,1);  //enable pull-up
	/*S2 configuration*/
	DioCfgPin(pADI_GPIO1,PIN0,0); //confige as gpio
	DioIenPin(pADI_GPIO1,PIN0,1); //enable input
	DioPulPin(pADI_GPIO1,PIN0,1);  //enable pull-up
	// Set polarity of P1.0 interrupt to low-high transition
	DioIntPolPin(pADI_GPIO1,PIN0,1);
	// Enable External interrupt A on P1.0
	DioIntPin(pADI_GPIO1,PIN0,INTA,1);
	// Enable GPIO_INTA interrupt source in NVIC
	NVIC_EnableIRQ(SYS_GPIO_INTA_IRQn);
}


//rewrite putchar to support printf in IAR
int putchar(int c)
{
#ifdef UARTcomms
#if DEBUG
	UrtTx(pADI_UART0,c);
	while(!(pADI_UART0->COMLSR&BITM_UART_COMLSR_TEMT));
#endif
#endif /*UARTcomms*/

#ifdef I2Ccomms
	while(((pTxSend - pTxWrite) == 3)
	      || ((BUF_SIZE + (pTxSend - pTxWrite)) == 3)) {
		//Buffer is full. Wait for master read.
		delay_10us(100); //wait for master to read
	}
	*pTxWrite++ = (unsigned char) c;
	if((pTxWrite - szTemp) >= BUF_SIZE) pTxWrite = szTemp; //overflow
#endif /*I2Ccomms*/

	return c;
}

void ClockInit(void)
{
	DigClkSel(DIGCLK_SOURCE_HFOSC);
	ClkDivCfg(1,1);
	AfeClkSel(AFECLK_SOURCE_HFOSC);
	AfeSysClkDiv(AFE_SYSCLKDIV_1);
}

void UartInit(void)
{
	DioCfgPin(pADI_GPIO0,PIN0,0);		// Setup P0.0 as RS485 DE & RE#
	DioClrPin(pADI_GPIO0,PIN0);			//make RS485 in RX status
	DioOenPin(pADI_GPIO0,PIN0,1);
//	DioSetPin(pADI_GPIO0,PIN0);
#ifdef UARTcomms
	DioCfgPin(pADI_GPIO0,PIN10,1);		// Setup P0.10 as UART pin
	DioCfgPin(pADI_GPIO0,PIN11,1);		// Setup P0.11 as UART pin
	// Set PCLk oversampling rate 32. (PCLK to UART baudrate generator is /32)
	pADI_UART0->COMLCR2 = 0x3;
	// Configure UART for 57600 baud rate
	UrtCfg(pADI_UART0,B9600,(BITM_UART_COMLCR_WLS|3),0);
	// Configure the UART FIFOs for 14 bytes deep
	UrtFifoCfg(pADI_UART0, RX_FIFO_14BYTE, BITM_UART_COMFCR_FIFOEN);
	// Clear the Rx/TX FIFOs
	UrtFifoClr(pADI_UART0, BITM_UART_COMFCR_RFCLR|BITM_UART_COMFCR_TFCLR);
	pADI_UART0->COMFCR |=0x2; // test to clear the RX FIFO
	// Enable Rx, Tx and Rx buffer full Interrupts
	UrtIntCfg(pADI_UART0,BITM_UART_COMIEN_ERBFI |
		  BITM_UART_COMIEN_ETBEI | BITM_UART_COMIEN_ELSI);
	// Enable UART interrupt source in NVIC
	NVIC_EnableIRQ(UART_EVT_IRQn);
#endif
}

void I2CInit(uint8_t address)
{
#ifdef I2Ccomms
	DioCfgPin(pADI_GPIO0,PIN4,1);		// Setup P0.4 as I2C SCL pin
	DioCfgPin(pADI_GPIO0,PIN5,1);		// Setup P0.5 as I2C SDA pin
	/* Increase drive strength for more reliable I2C comms */
	DioDsPin(pADI_GPIO0,PIN4|PIN5,1);
	I2cAutoStretch(pADI_I2C0, SLAVE, STRETCH_EN, 0xF);
	I2C0SIDCfg(address << 1, ADI_CFG_I2C_DEFAULT_ADDR_SHIFTED,
		   ADI_CFG_I2C_DEFAULT_ADDR_SHIFTED,
		   ADI_CFG_I2C_DEFAULT_ADDR_SHIFTED);	// Shift the address to fill in the ID registers
	I2cFifoFlush(pADI_I2C0,SLAVE,ENABLE);	// Enable flush of Slave FIFOs
	I2cFifoFlush(pADI_I2C0,SLAVE,DISABLE);
	I2cSCfg(pADI_I2C0,0,			// I2C  - no DMA
		// Enable repeated Start detect interrupt
		BITM_I2C_SCTL_IENREPST |
		BITM_I2C_SCTL_IENSTOP |		// enable Stop detect interrupt
		BITM_I2C_SCTL_IENSTX |		// enable transmit interrupt
		BITM_I2C_SCTL_IENSRX,		// enable receive interrupt
		// enable early transmit request to support higher baud rates
		BITM_I2C_SCTL_EARLYTXR |
		BITM_I2C_SCTL_SLVEN);		// Enable I2C Slave
	// Enable automatic clock stretching
	I2cAutoStretch(pADI_I2C0, SLAVE,STRETCH_EN,0x8);
	// Enable I2C interrupt source in NVIC
	NVIC_EnableIRQ(I2C_SLV_EVT_IRQn);
#endif
}

/*=========================== Interrupt Handlers ====================*/
/*Note: Communications interrupts are handled in M355WqCmd.c         */

void AfeAdc_Int_Handler()
{
	uint32_t sta;
	sta = pADI_AFE->ADCINTSTA;
	/*DFT Interrupt*/
	if(sta&BITM_AFE_ADCINTSTA_DFTRDY) {
		pADI_AFE->ADCINTSTA = BITM_AFE_ADCINTSTA_DFTRDY;	//clear interrupt
		dftRdy = 1;
		pADI_AFE->AFECON &= (~(BITM_AFE_AFECON_DFTEN|
				       BITM_AFE_AFECON_ADCCONVEN|
				       BITM_AFE_AFECON_ADCEN));  //stop conversion
	}
	/*SINC3 Data Ready Interrupt*/
	if(sta&BITM_AFE_ADCINTSTA_ADCRDY) {
		pADI_AFE->ADCINTSTA = BITM_AFE_ADCINTSTA_ADCRDY;	//clear interrupt
		adcRdy = 1;
	}
	/*SINC2 Data Ready Interrupt*/
	if(sta&BITM_AFE_ADCINTSTA_SINC2RDY) {
		pADI_AFE->ADCINTSTA = BITM_AFE_ADCINTSTA_SINC2RDY;	//clear interrupt
		sinc2Rdy = 1;
	}
	/*Max threshold interrupt for gain autoranging*/
	if(sta&BITM_AFE_ADCINTSTA_ADCMAXERR) {
		pADI_AFE->ADCINTSTA = BITM_AFE_ADCINTSTA_ADCMAXERR;	//clear interrupt
		adcSat = 1;	//Signal that adc is saturated
		if (uiGnPgaIndex > 0) //reduce PGA gain first
			uiMaxPgaGainIndex = uiGnPgaIndex - 1;
		else if (uiHpRtiaSeIndex > 0) //reduce TIA gain second
			uiMaxGainRangeIndex = uiHpRtiaSeIndex - 1;
	}
	/*Min threshold interrupt for gain autoranging*/
	if(sta&BITM_AFE_ADCINTSTA_ADCMINERR) {
		pADI_AFE->ADCINTSTA = BITM_AFE_ADCINTSTA_ADCMINERR;	//clear interrupt
		adcSat = 1;	//Signal that adc is saturated
		if (uiGnPgaIndex > 0) //reduce PGA gain first
			uiMaxPgaGainIndex = uiGnPgaIndex - 1;
		else if (uiHpRtiaSeIndex > 0) //reduce TIA gain second
			uiMaxGainRangeIndex = uiHpRtiaSeIndex - 1;
	}
}

void GPIO_A_Int_Handler()
{
	unsigned int uiIntSta = 0;

	uiIntSta = DioIntSta(pADI_GPIO1);
	if ((uiIntSta & 0x0001) ==0x0001) {
		DioIntClrPin(pADI_GPIO1,PIN0);
		ucButtonPress = 1;
	}
}

