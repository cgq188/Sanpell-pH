/**
 *****************************************************************************
   @addtogroup EC sensor
   @{
   @file     M355WqConfig.h
   @brief    Config file for Water Quality Demo
   @par Revision History:
   @version  V0.1
   @author   ADI
   @date
   @par Revision History:
   - V0.1, June 2018: initial version
   Decription:
     Configuration file including communication and calibration settings. Store
	 calibration coefficients here, choose comms interface.

All files for ADuCM355 provided by ADI, including this file, are
provided  as is without warranty of any kind, either expressed or implied.
The user assumes any and all risk from the use of this code.
It is the responsibility of the person integrating this code into an application
to ensure that the resulting application performs as required and is safe.

**/

#ifndef M355WQCONFIG_H_
#define M355WQCONFIG_H_


#ifdef __cplusplus
extern "C" {
#endif

/*************************** Configuration Settings ***************************/

#define DEBUG 0		/*Set DEBUG to 1 to print debug text, 0 to suppress*/

#define NICE_EIS_FREQ_RANGE 1		/*1 limits EIS range according to defined values
					  0 sets range to full no matter what*/

/*========================= Communication Settings =============================
Uncomment one of the following to define the type of communication that should
be set up for the board. Ensure hardware is set up to match this setting.
	I2C: Default communication interface. (CN0428) Ensure I2C/UART switch on
		interposer is in I2C position. I2C address is automatically set
		 to master-dictated site-specific address in SetI2CAddr().
	SPI: Alternate communication interface. ***TO BE IMPLEMENTED***
	UART: Not typically used. Made available to accomodate direct USB-UART
		bridges like on EVAL-ADuCM355QSPZ and debugging. Supports one
		daughter card only. Note that ADuCM3029 (host micro) only has
		one UART, so if that is taken up by a USB-UART bridge, it cannot
		also be used to talk to the M355.
==============================================================================*/

//========DEFINE ONE OF THE FOLLOWING TO SET COMMUNICATION METHOD===========
//#define I2Ccomms
#define UARTcomms
//#define SPIcomms
//==========================================================================

/************List of Suggested I2C Addresses for Host to call*******************
	For Site 1: #define ADI_CFG_I2C_SENSOR1_ADDR (0x0Au)
		Host sets site 1 P0.3 (/CS0) low and calls SetI2CAddr(0x0Au) by sending command 0x80 + data 0x0A to default addr 0x4C.
		Host queries status (command 0x02) at address 0x0A to verify if it worked.
	For Site 2: #define ADI_CFG_I2C_SENSOR2_ADDR (0x0Bu)
		Follow same procedure as site 1 with appropriate /CS and address parameters.
	For Site 3: #define ADI_CFG_I2C_SENSOR3_ADDR (0x0Cu)
		Follow same procedure as site 1 with appropriate /CS and address parameters.
	For Site 4: #define ADI_CFG_I2C_SENSOR4_ADDR (0x0Du)
		Follow same procedure as site 1 with appropriate /CS and address parameters.
*******************************************************************************/

// Size of I2C and SPI communications buffer to hold characters before sending to host
#define BUF_SIZE			4096u

/*========================= Calibration Settings ===============================
Use this space to store calibration coefficients in flash memory so they are
correct when the board turns on
	Sensor Calibration (define one or define all if different probes will be
	plugged into this board)
		pH: 1 point or 2 point, typically calibrated 2 points with pH 7
			buffer and pH 4 or 10 buffer
		conductivity: 1 point calibration, use COMPRANGES for better
			accuracy
		ORP: Most manufacturers do not recommend calibration for ORP
			electrode. Zobell checking solutions are used.

	Temperature: RTD or NTC thermistor
		NTC: Typically use simplified B model in calculation.
			Steinhart-Hart available too.
		RTD: Linear approximation based on RMIN, RMAX, TMIN, TMAX

	Resistance or impedance measurement calibration
		With debug set to 1, the program prints out which range was used
		for a measurement. Measure impedance of known resistors using a
		BNC-to-mini-clip cable and the conductivity measurement routine.
		Record the value and the range measured. Measure the actual
		resistance value with a DMM and record that as well. Using at
		least 2 points in each range, find the slope and offset and
		record below. If COMPRANGES is set to 1, these range calibration
		coefficients will be used tocompensate impedance, resistance,
		and conductivity measurement values.
==============================================================================*/
/********Default Sensor Type**********/
typedef enum {
	pH = 0u,		/*pH sensor*/
	Conductivity,		/*conductivity probe*/
	ORP,			/*Oxidation-Reduction Potential*/
	ISE,			/*TO BE IMPLEMENTED: Ion Selective Electrode*/
	DO			/*TO BE IMPLEMENTED: Dissolved oxygen probe (Clarke-type)*/
} SnsType;


#define  SENSOR_CHANNEL_ENABLE	(0xAAAA5555u) /* This is a constant */

/********START-UP DEFAULT SETTINGS********/
#define  DEFAULT_SENSOR		pH	/* What type of sensor to use at start-up, see list above */
#define  TEMP_SENSOR_INCLUDED	SENSOR_CHANNEL_ENABLE	/* 0 or SENSOR_CHANNEL_ENABLE. Whether to enable the temperature channel at start-up */
#define  HI_Z_MODE		1	/* Corresponding to switch S2, set to 1 to use Hi-Z TIA (LTC6078), set to 0 to use internal resistors and autoranging */

/*********pH probe*********/
//===============================pH Settings====================================
#define  USE_PH_CALIBRATION 1		//Set to 1 to use below stored calibration information
					//otherwise set to 0 to use nernst equation
#define  ATC 1				//Automatic temperature compensation (1: on, 0: off). Requires temp sensor
#define  USE_BUFFER_LOOKUP 0		//if 1, actual pH is read from pH buffer table (See below)
//To save storage space, buffer lookup is only available here, not at runtime
//===========================Last Calibration Value=============================
//Calibration information - Stored here to ensure it is loaded in flash memory
//Sensor can be recalibrated, but variables need to be written here manually to load correctly at startup
#if USE_PH_CALIBRATION
#define  PH_CAL_POINTS 2		//1 or 2 point cal
#endif /* USE_PH_CALIBRATION */
#define  PH_CAL_V1 0.177		//measured voltage point 1
#define  PH_CAL_V2 0			//measured voltage point 2
#define  PH_CAL_T1 25			//Temperature during point 1 measurement
#define  PH_CAL_T2 25			//Temperature during point 2 measurement
#if USE_BUFFER_LOOKUP /*Fill in these values if using buffer table lookup*/
/**
 * @brief Calibration solutions enum
 */
enum {
	ACETATE,
	BORATE,
	CAOH2,
	CARBONATE,
	CITRATE,
	HCL,
	OXALATE,
	PHOSPHATE0,
	PHOSPHATE1,
	PHOSPHATE2,
	PHTHALATE,
	TARTRATE,
	TRIS,
	CUSTOM //fill table below with custom values
};
#define  PH_BUFFER_TYPE_1 PHTHALATE		//Buffer used for point 1. Only need to fill these if using buffer lookup
#define  PH_BUFFER_TYPE_2 PHOSPHATE1		//Buffer used for point 2.
#endif /*USE_BUFFER_LOOKUP*/
#define  PH_CAL_PH1 4 				//known ph point 1 (only set if not using buffer lookup)
#define  PH_CAL_PH2 7				//known ph point 2 (only set if not using buffer lookup)
//#endif /*USE_PH_CALIBRATION*/
//==============================================================================
//used for nernst calculations (no calibration)
#define  PH_ISO 7.0
#define  TOLERANCE 0 /* Set a tolerance value for pH calculation */

/*********conductivity probe*********/
//=================================Settings=====================================
#define  USE_COND_CALIBRATION 1 //Set to 1 to use below stored calibration information
#define  COND_CELL_CONST 1	//Cell constant
#define  COND_DEFAULT_FREQ 300	//Default measurement frequency (Hz)
//==========================Last Calibration Value==============================
//Calibration information - Stored here to ensure it is loaded in flash memory
//Sensor can be recalibrated, but variables need to be written here manually to load correctly at startup
#define  COND_CAL_MEAS 0.0001		//measured conductivity point (S/cm)
#define  COND_CAL_ACT 0.0001		//known conductivity point (S/cm)
//==============================================================================

/*********Temperature Sensor Defaults*********/
#define  NTC 1
#define  RTD 2
//========UNCOMMENT ONE TO DEFINE TEMP SENSOR TYPE========
#define  TEMPSENSORTYPE RTD
//#define  TEMPSENSORTYPE RTD
//==================Thermistor options====================
#define  B			1
#define  STEINHARTHART		2
#define  NTC_COMP_TYPE		B		/* Options: B, STEINHARTHART */

//Linearization types
//	"B": Simplified B model: 1/T = (1/B)*ln(R/Ro) + 1/To
//	"STEINHARTHART": Steinhart-Hart equation: 1/T = a + b(Ln R) + c(Ln R)^3,  T in degrees Kelvin
#if TEMPSENSORTYPE==NTC
#define  R_POINT1		30000		/* Nominal NTC resistance */
#define  T_POINT1		25		/* Nominal NTC temperature */
#endif
#if NTC_COMP_TYPE==B
#define  NTC_B_DEFAULT		3950		/* Default B value for simplified thermistor equation */
#elif NTC_COMP_TYPE==STEINHARTHART
#define  NTC_A_STEINHART	0.00156	/* Insert steinhart-hart coefficients */
#define  NTC_B_STEINHART	0.000249
#define  NTC_C_STEINHART	0.0000002
#endif

//=====================RTD options========================
//Note: Linear approximation error for liquid water temperature range is <0.1'C. CN0381 and CN0398 code can be used if linearization is desired.
#if TEMPSENSORTYPE==RTD
#define  R_POINT1		1000	/* Minimum value for RTD resistance */
#define  T_POINT1		0	/* Minimum value for RTD temperature */
#endif
#define  R_POINT2		1385	/* Maximum value for RTD resistance */
#define  T_POINT2		100	 /* Maximum value for RTD temperature */

/*********Impedance Measurement Calibration*********/
/* RANGE COMPENSATION:
Measure known resistor values connected to BNC connector. It is suggested to use
DEBUG mode, set sensortype to conductivity, and run measuresensor. Record
magnitude values and Rtia gain range. This requires at least two measurements
per range. For each range, plot the measured values (y-axis) against the known
resistor value on x-axis (as measured with a precision DMM or similar).
Calculate a best-fit line and record gain and offset in M355WqConfig.h */

/*COMPRANGES 1 allows you to compensate for a linear fit of known measured resistances*/
#define COMPRANGES 1

/*Linear fit offset and gain for 200 ohm Rcal range*/
#define COMPGAIN200 		1
#define COMPOFFSET200	 	0

/*Linear fit offset and gain for 1k ohm Rcal range*/
#define COMPGAIN1K 			1
#define COMPOFFSET1K 		0


/*Linear fit offset and gain for 5k ohm Rcal range*/
#define COMPGAIN5K 			1
#define COMPOFFSET5K 		0

/*Linear fit offset and gain for 10k ohm Rcal range*/
#define COMPGAIN10K 		1
#define COMPOFFSET10K 		0


/*Linear fit offset and gain for 20k ohm Rcal range*/
#define COMPGAIN20K 		1
#define COMPOFFSET20K 		0



///*Linear fit offset and gain for 40k ohm Rcal range*/
//#define COMPGAIN40K 		0.96853785 //1.03248410//0.9804
//#define COMPOFFSET40K 		906.48718503 //935.93347091//980.4
//
///*Linear fit offset and gain for 80k ohm Rcal range*/
//#define COMPGAIN80K 		0.96828500 //1.03275288
//#define COMPOFFSET80K 		908.64400000 //938.39772741
//
///*Linear fit offset and gain for 160k ohm Rcal range*/
//#define COMPGAIN160K 		1.01080902//1.0028
//#define COMPOFFSET160K 		858.98691575 //993.82976022 //1012.1
//
///*Linear fit offset and gain for 1Meg ohm Rcal range*/
//#define COMPGAIN1MEG 		0.98930656 //0.99940877 //1.00059158
//#define COMPOFFSET1MEG 		983.20230212 //859.49507547 //1013.9


/*Linear fit offset and gain for 40k ohm Rcal range*/
#define COMPGAIN40K 		1.03248410//0.9804
#define COMPOFFSET40K 		-935.93347091//980.4

/*Linear fit offset and gain for 80k ohm Rcal range*/
#define COMPGAIN80K 		1.03275288
#define COMPOFFSET80K 		-938.39772741

/*Linear fit offset and gain for 160k ohm Rcal range*/
#define COMPGAIN160K 		1.0028
#define COMPOFFSET160K 		-993.82976022 //1012.1

/*Linear fit offset and gain for 1Meg ohm Rcal range*/
#define COMPGAIN1MEG 		0.99940877 //1.00059158
#define COMPOFFSET1MEG 		-859.49507547 //1013.9



/*Adjust phase in HiZ Mode Radians (necessary, no calibration available)*/
#define COMPPHASEHIZ 1.679

/******************pH Buffer Arrays*****************/
#if  USE_BUFFER_LOOKUP
#define NUMBER_OF_TEMPERATURE_ENTRIES 31

const char ph_temperatures[NUMBER_OF_TEMPERATURE_ENTRIES] = {
	0,	5,	10,	15,	18,	19,	20,	21,	22,	23,	24,	25,
	26,	27,	28,	29,	30,	35,	37,	40,	45,	50,	55,	60,
	65,	70,	75,	80,	85,	90,	95
};

/**
 * @brief Calibration solutions temperature to ph look-up tables
 */
const float ph_temp_lut_1[NUMBER_OF_TEMPERATURE_ENTRIES] = {
#if PH_BUFFER_TYPE_1==ACETATE
	/* ACETATE    */ 4.667, 4.66, 4.655, 4.652, 4.651, 4.651, 4.65, 4.65, 4.65, 4.65, 4.65, 4.65, 4.65, 4.651, 4.651, 4.651, 4.652, 4.655, 4.656, 4.659, 4.666, 4.673, 4.683, 4.694, 4.706, 4.72, 4.736, 4.753, 4.772, 4.793, 4.815
#elif PH_BUFFER_TYPE_1==BORATE
	/* BORATE     */ 9.464, 9.395, 9.332, 9.276, 9.245, 9.235, 9.225, 9.216, 9.207, 9.197, 9.189, 9.18, 9.171, 9.163, 9.155, 9.147, 9.139, 9.102, 9.088, 9.068, 9.038, 9.01, 8.985, 8.962, 8.941, 8.921, 8.902, 8.884, 8.867, 8.85, 8.833
#elif PH_BUFFER_TYPE_1==CAOH2
	/* CAOH2      */ 13.424, 13.207, 13.003, 12.81, 12.699, 12.663, 12.627, 12.592, 12.557, 12.522, 12.488, 12.454, 12.42, 12.387, 12.354, 12.322, 12.289, 12.133, 12.072, 11.984, 11.841, 11.705, 11.574, 11.449
#elif PH_BUFFER_TYPE_1==CARBONATE
	/* CARBONATE  */ 10.317, 10.245, 10.179, 10.118, 10.084, 10.073, 10.062, 10.052, 10.042, 10.032, 10.022, 10.012, 10.002, 9.993, 9.984, 9.975, 9.966, 9.925, 9.91, 9.889, 9.857, 9.828
#elif PH_BUFFER_TYPE_1==CITRATE
	/* CITRATE    */ 3.863, 3.84, 3.82, 3.803, 3.793, 3.791, 3.788, 3.785, 3.783, 3.78, 3.778, 3.776, 3.774, 3.772, 3.77, 3.768, 3.766, 3.759, 3.756, 3.754, 3.75, 3.749
#elif PH_BUFFER_TYPE_1==HCL
	/* HCL        */ 1.082, 1.085, 1.087, 1.089, 1.09, 1.091, 1.091, 1.092, 1.092, 1.093, 1.093, 1.094, 1.094, 1.094, 1.095, 1.095, 1.096, 1.098, 1.099, 1.101, 1.103, 1.106, 1.108, 1.111, 1.113, 1.116, 1.119, 1.121, 1.124, 1.127, 1.13
#elif PH_BUFFER_TYPE_1==OXALATE
	/* OXALATE    */ 1.666, 1.668, 1.67, 1.672, 1.674, 1.675, 1.675, 1.676, 1.677, 1.678, 1.678, 1.679, 1.68, 1.681, 1.681, 1.682, 1.683, 1.688, 1.69, 1.694, 1.7, 1.707, 1.715, 1.723, 1.732, 1.743, 1.754, 1.765, 1.778, 1.792, 1.806
#elif PH_BUFFER_TYPE_1==PHOSPHATE0
	/* PHOSPHATE0 */ 6.984, 6.951, 6.923, 6.9, 6.888, 6.884, 6.881, 6.877, 6.874, 6.871, 6.868, 6.865, 6.862, 6.86, 6.857, 6.855, 6.853, 6.844, 6.841, 6.838, 6.834, 6.833, 6.833, 6.836, 6.84, 6.845, 6.852, 6.859, 6.867, 6.876, 6.886
#elif PH_BUFFER_TYPE_1==PHOSPHATE1
	/* PHOSPHATE1 */ 7.118, 7.087, 7.059, 7.036, 7.024, 7.02, 7.016, 7.013, 7.009, 7.006, 7.003, 7, 6.997, 6.994, 6.992, 6.989, 6.987, 6.977, 6.974, 6.97, 6.965, 6.964, 6.965, 6.968, 6.974, 6.982, 6.992, 7.004, 7.018, 7.034, 7.052
#elif PH_BUFFER_TYPE_1==PHOSPHATE2
	/* PHOSPHATE2 */ 7.534, 7.5, 7.472, 7.448, 7.436, 7.432, 7.429, 7.425, 7.422, 7.419, 7.416, 7.413, 7.41, 7.407, 7.405, 7.402, 7.4, 7.389, 7.386, 7.38, 7.373, 7.367
#elif PH_BUFFER_TYPE_1==PHTHALATE
	/* PHTHALATE  */ 4, 3.998, 3.997, 3.998, 3.999, 4, 4.001, 4.001, 4.002, 4.003, 4.004, 4.005, 4.006, 4.007, 4.008, 4.009, 4.011, 4.018, 4.022, 4.027, 4.038, 4.05, 4.064, 4.08, 4.097, 4.116, 4.137, 4.159, 4.183, 4.208, 4.235
#elif PH_BUFFER_TYPE_1==TARTRATE
	/* TARTRATE   */ 3.557, 3.557, 3.557, 3.557, 3.557, 3.557, 3.557, 3.557, 3.557, 3.557, 3.557, 3.557, 3.556, 3.555, 3.554, 3.553, 3.552, 3.549, 3.548, 3.547, 3.547, 3.549, 3.554, 3.56, 3.569, 3.58, 3.593, 3.61, 3.628, 3.65, 3.675
#elif PH_BUFFER_TYPE_1==TRIS
	/* TRIS       */ 8.471, 8.303, 8.142, 7.988, 7.899, 7.869, 7.84, 7.812, 7.783, 7.755, 7.727, 7.699, 7.671, 7.644, 7.617, 7.59, 7.563, 7.433, 7.382, 7.307, 7.186, 7.07
#elif PH_BUFFER_TYPE_1==CUSTOM
//Fill in table for your buffer. If all these temperature points aren't listed, use linear interpolation.
//TEMPERATURES	0	5	10	15	18	19	20	21	22	23	24	25	26	27	28	29	30	35	37	40	45	50	55	60	65	70	75	80	85	90	95
/* CUSTOM  */	7,	7,	7, 	7,	7,	7,	7,	7,	7,	7,	7,	7,	7,	7,	7,	7,	7,	7,	7,	7,	7,	7,	7,	7,	7,	7,	7,	7,	7,	7,	7
#else
/* NOT FOUND  */0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
#endif /* PH_BUFFER_TYPE_1 */
};

#if PH_CAL_POINTS==2
const float ph_temp_lut_2[NUMBER_OF_TEMPERATURE_ENTRIES] = {
#if PH_BUFFER_TYPE_2==ACETATE
	/* ACETATE    */ 4.667, 4.66, 4.655, 4.652, 4.651, 4.651, 4.65, 4.65, 4.65, 4.65, 4.65, 4.65, 4.65, 4.651, 4.651, 4.651, 4.652, 4.655, 4.656, 4.659, 4.666, 4.673, 4.683, 4.694, 4.706, 4.72, 4.736, 4.753, 4.772, 4.793, 4.815
#elif PH_BUFFER_TYPE_2==BORATE
	/* BORATE     */ 9.464, 9.395, 9.332, 9.276, 9.245, 9.235, 9.225, 9.216, 9.207, 9.197, 9.189, 9.18, 9.171, 9.163, 9.155, 9.147, 9.139, 9.102, 9.088, 9.068, 9.038, 9.01, 8.985, 8.962, 8.941, 8.921, 8.902, 8.884, 8.867, 8.85, 8.833
#elif PH_BUFFER_TYPE_2==CAOH2
	/* CAOH2      */ 13.424, 13.207, 13.003, 12.81, 12.699, 12.663, 12.627, 12.592, 12.557, 12.522, 12.488, 12.454, 12.42, 12.387, 12.354, 12.322, 12.289, 12.133, 12.072, 11.984, 11.841, 11.705, 11.574, 11.449
#elif PH_BUFFER_TYPE_2==CARBONATE
	/* CARBONATE  */ 10.317, 10.245, 10.179, 10.118, 10.084, 10.073, 10.062, 10.052, 10.042, 10.032, 10.022, 10.012, 10.002, 9.993, 9.984, 9.975, 9.966, 9.925, 9.91, 9.889, 9.857, 9.828
#elif PH_BUFFER_TYPE_2==CITRATE
	/* CITRATE    */ 3.863, 3.84, 3.82, 3.803, 3.793, 3.791, 3.788, 3.785, 3.783, 3.78, 3.778, 3.776, 3.774, 3.772, 3.77, 3.768, 3.766, 3.759, 3.756, 3.754, 3.75, 3.749
#elif PH_BUFFER_TYPE_2==HCL
	/* HCL        */ 1.082, 1.085, 1.087, 1.089, 1.09, 1.091, 1.091, 1.092, 1.092, 1.093, 1.093, 1.094, 1.094, 1.094, 1.095, 1.095, 1.096, 1.098, 1.099, 1.101, 1.103, 1.106, 1.108, 1.111, 1.113, 1.116, 1.119, 1.121, 1.124, 1.127, 1.13
#elif PH_BUFFER_TYPE_2==OXALATE
	/* OXALATE    */ 1.666, 1.668, 1.67, 1.672, 1.674, 1.675, 1.675, 1.676, 1.677, 1.678, 1.678, 1.679, 1.68, 1.681, 1.681, 1.682, 1.683, 1.688, 1.69, 1.694, 1.7, 1.707, 1.715, 1.723, 1.732, 1.743, 1.754, 1.765, 1.778, 1.792, 1.806
#elif PH_BUFFER_TYPE_2==PHOSPHATE0
	/* PHOSPHATE0 */ 6.984, 6.951, 6.923, 6.9, 6.888, 6.884, 6.881, 6.877, 6.874, 6.871, 6.868, 6.865, 6.862, 6.86, 6.857, 6.855, 6.853, 6.844, 6.841, 6.838, 6.834, 6.833, 6.833, 6.836, 6.84, 6.845, 6.852, 6.859, 6.867, 6.876, 6.886
#elif PH_BUFFER_TYPE_2==PHOSPHATE1
	/* PHOSPHATE1 */ 7.118, 7.087, 7.059, 7.036, 7.024, 7.02, 7.016, 7.013, 7.009, 7.006, 7.003, 7, 6.997, 6.994, 6.992, 6.989, 6.987, 6.977, 6.974, 6.97, 6.965, 6.964, 6.965, 6.968, 6.974, 6.982, 6.992, 7.004, 7.018, 7.034, 7.052
#elif PH_BUFFER_TYPE_2==PHOSPHATE2
	/* PHOSPHATE2 */ 7.534, 7.5, 7.472, 7.448, 7.436, 7.432, 7.429, 7.425, 7.422, 7.419, 7.416, 7.413, 7.41, 7.407, 7.405, 7.402, 7.4, 7.389, 7.386, 7.38, 7.373, 7.367
#elif PH_BUFFER_TYPE_2==PHTHALATE
	/* PHTHALATE  */ 4, 3.998, 3.997, 3.998, 3.999, 4, 4.001, 4.001, 4.002, 4.003, 4.004, 4.005, 4.006, 4.007, 4.008, 4.009, 4.011, 4.018, 4.022, 4.027, 4.038, 4.05, 4.064, 4.08, 4.097, 4.116, 4.137, 4.159, 4.183, 4.208, 4.235
#elif PH_BUFFER_TYPE_2==TARTRATE
	/* TARTRATE   */ 3.557, 3.557, 3.557, 3.557, 3.557, 3.557, 3.557, 3.557, 3.557, 3.557, 3.557, 3.557, 3.556, 3.555, 3.554, 3.553, 3.552, 3.549, 3.548, 3.547, 3.547, 3.549, 3.554, 3.56, 3.569, 3.58, 3.593, 3.61, 3.628, 3.65, 3.675
#elif PH_BUFFER_TYPE_2==TRIS
	/* TRIS       */ 8.471, 8.303, 8.142, 7.988, 7.899, 7.869, 7.84, 7.812, 7.783, 7.755, 7.727, 7.699, 7.671, 7.644, 7.617, 7.59, 7.563, 7.433, 7.382, 7.307, 7.186, 7.07
#elif PH_BUFFER_TYPE_1==CUSTOM
//Fill in table for your buffer. If all these temperature points aren't listed, use linear interpolation.
//TEMPERATURES	0	5	10	15	18	19	20	21	22	23	24	25	26	27	28	29	30	35	37	40	45	50	55	60	65	70	75	80	85	90	95
/* CUSTOM */	7,	7, 	7, 	7, 	7,	7,	7,	7,	7,	7,	7,	7,	7,	7,	7,	7,	7,	7,	7,	7,	7,	7,	7,	7,	7,	7,	7,	7,	7,	7,	7
#else
	/* NOT FOUND  */ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
#endif /* PH_BUFFER_TYPE_2 */
};
#endif /* PH_CAL_POINTS==2 */

#endif /* USE_BUFFER_LOOKUP */

#ifdef __cplusplus
}
#endif

#endif /* M355WQCONFIG_H_ */
