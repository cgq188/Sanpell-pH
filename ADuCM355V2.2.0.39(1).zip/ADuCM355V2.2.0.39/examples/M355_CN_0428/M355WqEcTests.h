/**
 *****************************************************************************
   @addtogroup EC sensor
   @{
   @file     M355WqEcTests.h
   @brief    Set of Electrochemical sensor functions.
   @version  V0.1
   @author   ADI
   @date     June 2018
   @par Revision History:
   - V0.1, June 2018: initial version.


All files provided by ADI, including this file, are
provided  as is without warranty of any kind, either expressed or implied.
The user assumes any and all risk from the use of this code.
It is the responsibility of the person integrating this code into an application
to ensure that the resulting application performs as required and is safe.

**/

#ifndef M355WQECTESTS_H_
#define M355WQECTESTS_H_

#ifdef __cplusplus
extern "C" {
#endif



/*==============  Typedefine and Macros  ============*/
/*Sensor configuration*/

//#define WAKEUP_PERIOD   RTC1_PRESCALE_1       // 60/(32768Hz/1) = 1.831mS
//#define WAKEUP_PERIOD   RTC1_PRESCALE_2       // 60/(32768Hz/2) = 3.662mS
//#define WAKEUP_PERIOD   RTC1_PRESCALE_4       // 60/(32768Hz/4) = 7.324mS
//#define WAKEUP_PERIOD   RTC1_PRESCALE_8       // 60/(32768Hz/8) = 14.65mS
//#define WAKEUP_PERIOD   RTC1_PRESCALE_16      // 60/(32768Hz/16) = 29.30mS
//#define WAKEUP_PERIOD   RTC1_PRESCALE_32      // 60/(32768Hz/32) = 58.59mS
//#define WAKEUP_PERIOD   RTC1_PRESCALE_64      // 60/(32768Hz/64) = 117.2mS
//#define WAKEUP_PERIOD   RTC1_PRESCALE_128     // 60/(32768Hz/128) = 234.4mS
//#define WAKEUP_PERIOD   RTC1_PRESCALE_256     // 60/(32768Hz/256) = 468.8mS
#define WAKEUP_PERIOD   RTC1_PRESCALE_512     // 60/(32768Hz/512) = 937.5mS
//#define WAKEUP_PERIOD   RTC1_PRESCALE_1024    // 60/(32768Hz/1024) = 1.875S
//#define WAKEUP_PERIOD   RTC1_PRESCALE_2048    // 60/(32768Hz/2048) = 3.75S
//#define WAKEUP_PERIOD   RTC1_PRESCALE_4096    // 60/(32768Hz/4096) = 7.5S
//#define WAKEUP_PERIOD   RTC1_PRESCALE_8192    // 60/(32768Hz/8192) = 15S
//#define WAKEUP_PERIOD   RTC1_PRESCALE_16384   // 60/(32768Hz/16384) = 30S
//#define WAKEUP_PERIOD   RTC1_PRESCALE_32768   // 60/(32768Hz/32768) = 60S


#include "ADuCM355_Peri.h"
#include <stdio.h>
#include <string.h>


#define ATE_REV 	(*(volatile unsigned short *) 0x4074C)  // read ADI ATE production test revision


#include <math.h>
#define PI  3.14159265f


/*AC test Macros*/
/*
   High power DAC update rate
   controlled by HSDACCON[8:1], rate = 16MHz/HSDACCON[8:1]
   these bits need to be configured depending on the AC excitaion signal frequency.
   higher frequency excitation signal requires higher update rate, results in better performance but higher power consumption
*/
//#define HPDAC_UPDATE_RATE   2283u  /*2.283MHz*/
#define HPDAC_UPDATE_RATE   320u  /*320KHz*/
#define HPDAC_RATE_REG ((uint8_t)(16000/HPDAC_UPDATE_RATE))  /*AFE system clock = 16MHz*/
/*
   Excitation sine wave frequency
   controlled by WGFCW[23:0], frequency = WGFCW[23:0]*16000000/2^30 Hz;
*/
#define SINE_FREQ  30000u /*30k Hz*/
#define SINE_FREQ_REG   (uint32_t)(((uint64_t)SINE_FREQ<<30)/16000000.0+0.5)
/*
   Excitaion sine wave amplitude, this value could be applied on calibration resistor or unknown sensor
   Controlled by WGAMPLITUDE[10:0], HSDACCON[0] and HSDACCON[12]
   ----------------------------------------------------------------------------------
     Gain   |  DAC attenuator(HSDACCON[0])  |  Excitaion Amplifier Gain(HSDACCON[12])   |
   ---------|-----------------------------|-----------------------------------------|
       2    |           1(0)              |                  2(0)                   |
   ---------|-----------------------------|-----------------------------------------|
      1/5   |           1(0)              |                  1/5(1)                 |
   ---------|-----------------------------|-----------------------------------------|
      1/4   |           1/4(1)            |                  2(0)                   |
   ---------|-----------------------------|-----------------------------------------|
      1/20  |           1/4(1)            |                  1/5(1)                 |
   ----------------------------------------------------------------------------------
   AC amplitude = WGAMPLITUDE[10:0]*HPDAC_LSB*Gain
   HPDAC_LSB = 800mV/(2^12-1)
*/
#define SINE_AMPLITUDE   15u //15mV
#define SINE_AMPLITUDE_REG (uint16_t)(SINE_AMPLITUDE*20/HPDAC_LSB+0.5)  //assuming Gain = 1/20
/*
   Excitation sine wave phase and DC offset
*/
#define SINE_PHASE 0 /*0 degree*/
/*
   Excitation sine wave phase and DC offset
*/
#define SINE_OFFSET 0 /*0 dc offset*/
#define SINE_OFFSET_REG (uint16_t)(SINE_OFFSET/HPDAC_LSB+0.5)

/*
   Define default min and max EIS frequencies for various sensors
*/
#define MIN_PH_HZ_FREQ 0.1
#define MAX_PH_HZ_FREQ 1001
#define MIN_PH_INT_FREQ 0.9
#define MAX_PH_INT_FREQ 10001
#define MIN_COND_HZ_FREQ 0.1
#define MAX_COND_HZ_FREQ 1001
#define MIN_COND_INT_FREQ 0.9
#define MAX_COND_INT_FREQ 10001
#define MIN_FREQ_DEFAULT 0.9
#define MAX_FREQ_DEFAULT 10001

#define YES	1
#define NO	2

#define G1	0			// PGA Gain setting of 1
#define G1p5	1			// PGA Gain setting of 1.5
#define G2	2			// PGA Gain setting of 2
#define G4	3			// PGA Gain setting of 4
#define G9	4			// PGA Gain setting of 9

extern const char
*szSnsStatus[]; // { "Normal", "Broken/short", "Dry/Clogged", "Dirty", "Unknown" };
extern const char *szSnsType[]; // { "pH", "Conductivity", "ORP", "ISE", "DO" };
extern const char *szTempSnsType[]; // { "None", "NTC Thermistor", "RTD" };

typedef enum {
	Normal = 0u, 	/* Impedance is within the normal range for this electrode */
	Broken,		/* Very low impedance indicates broken or cracked glass membrane */
	Dry,		/* off the chart impedance indicates low conductivity, hydrated layer dry or reference plugged*/
	Dirty,		/* higher than usual impedance/poor repeatability indicates dirt/grime on electrode */
	Unknown		/* uninitialized. Make an EIS measurement */
} iSnsStatus;

//hprtiase
//const char *szValHpRtiaSe[] = { "200", "1k", "5k", "10k", "20k", "40k", "80k", "160k", "Open"};
extern const HPTIASE_RTIA_Type uiHpRtiaSe[];// = {HPTIASE_RTIA_200,HPTIASE_RTIA_1K,HPTIASE_RTIA_5K,HPTIASE_RTIA_10K,HPTIASE_RTIA_20K, \
                     HPTIASE_RTIA_40K,HPTIASE_RTIA_80K,HPTIASE_RTIA_160K,HPTIASE_RTIA_OPEN};//register values for HSRTIACON:RTIACON

extern const uint32_t uiValRcal[]; // { 200, 2000, 25500, 200000, 1000000 };
//const char *szValRcal[]; // { "200", "2k", "25.5k", "200k", "1Meg" };
/*RCal Options
	200 ohms: between Rcal0 and Rcal1 pins. Standard sw setup
		Good < 10k ohms RTIA, G=1 PGA  (Assuming 15mV excitation)
	2k ohms: between DE0 and AIN3. Use HPTIASE and connect D4|P4|NL|T6|T9
		Good < 100k ohms RTIA, G=1 PGA
	25.5k ohms: between AIN0 and AIN1. connect D2|P2|N1|T1|T9
		Good < 1.275Meg ohms RTIA, G=1 PGA
	200k ohms: between DE0 and AIN2. connect PL|P8|N3|T3|T9
		Good < 10Meg RTIA, G=1 PGA or <1.1Meg RTIA, G=9 PGA
	1Meg ohms: between DE1 and AIN2. Use HPTIASE and connect D3|P3|NL|T8|T9  (older versions P10|PL|N3|T3|T9 because T8 was not available)
		Good < 50Meg ohms RTIA, can't use 1Meg as both RTIA and RCal at the same time.

	Also: Temperature: between RE1 and SE1. connect PL|P6|N7|T7|T9
*/

/*DFT data
 * DFT_result[0] - real part of Rload+Sensor
 * DFT_result[1] - img part of Rload+Sensor
 * DFT_result[2] - real part of Rload
 * DFT_result[3] - img part of Rload
 * DFT_result[4] - real part of Rcal
 * DFT_result[5] - img part of Rcal
 */
typedef struct ImpResult_t {
	float freq;
	float DFT_result[6];//保存3组实部和虚部的数据
	float DFT_Mag[4];
	float Mag;
	float Phase;
	bool Cal_result;
	bool Load_result;
	uint8_t iRcal;
	uint8_t iRtia;
	uint8_t iGpga;
	bool result_valid;
} ImpResult_t;

typedef enum {
	RSnsLoad = 0u,	/* Measure Rsensor + Rload */
	RLoad,		/* Measure Rload */
	RCal		/* Measure Rcal */
} RMeasType;

/* Note: SnsType enum:
 *	pH
 *	Conductivity
 *	Thermistor
 *	ORP
 *	ISE
 *	DO
 */


typedef struct {
	uint32_t Enable;
	uint32_t channel;
	uint32_t Vzero;
	uint32_t Vbias;
	LPTIA_RLOAD_Type Rload;
	LPTIA_RGAIN_Type Rtia;
	LPTIA_RF_Type Rfilter;
	SnsType Sensor_Type;
	iSnsStatus Sensor_Status;
	uint8_t StartingHpRtiaSeIndex;
	uint8_t StartingGnPgaIndex;//自适应量程的PGA增益索引
	float minFreq;
	float maxFreq;
	char SensorName[16];
} SNS_CFG_Type;


typedef struct {
	float pH_iso;			/*isometric point/internal pH inside probe, usually 7*/
	uint8_t ph_ATC;			/*Use automatic temperature compensation? 0: No, 1: Yes (doesn't affect Nernst calculations, only calibrated)*/
	uint8_t cal_points;		/*0: use the Nernst equation to calculate pH. 1: Nernst equation with offset adjustment 2: 2 point calibratioin using values in config file (buffer look-up and ATC possible)*/
	float cal_V1;			/*measured voltages of calibration buffers, e.g, 0.177V, 0V, -0.177V*/
	float cal_pH1;			/*known pH values of buffers used for calibration, e.g., 4.0, 7.0, 10.0*/
	float cal_T1;			/*temperature recorded during pt 1 cal measurement*/
	float cal_V2;			/*measured voltages of calibration buffers, e.g, 0.177V, 0V, -0.177V*/
	float cal_pH2;			/*known pH values of buffers used for calibration, e.g., 4.0, 7.0, 10.0*/
	float cal_T2;			/*temperature recorded during pt 2 cal measurement*/
} pH_probe_t;

typedef struct {
	uint8_t temp_sensor_type; 	/* NTC, RTD */
	float R1;			/* NTC: nominal resistance. RTD: resistance at T1. */
	float T1;			/* NTC: temperature at nominal resistance. RTD: temperature for R1. */
	float R2;			/* RTD point 2 resistance */
	float T2;			/* RTD point 2 temperature */
	float B_value; 			/* Only used in NTC */
	float A_steinhart;		/* Steinhart-Hart coefficient */
	float B_steinhart;		/* Steinhart-Hart coefficient */
	float C_steinhart;		/* Steinhart-Hart coefficient */
} Temp_sensor_t;

typedef struct {
	float cell_constant;		/*cell constant in cm^-1. E.g., 0.1 cm-1, 10cm-1*/
	float cal_cond_measured;	/*calibration point measured value*/
	float cal_cond_actual;		/*calibration point actual value*/
	float cond_meas_freq;		/*conductivity measurement frequency*/
} Conductivity_probe_t;

/* Note: SENSOR_CHANNEL_ENABLE is #defined as 0xAAAA5555u */

/*=========================== Function declarations ====================*/
uint32_t RtiaGet();
float MagRawGet();

void SensorInit();
void SesorDCTest();
SNS_CFG_Type * getSnsCfg(uint32_t channel);
uint8_t SnsInit(SNS_CFG_Type *pSnsCfg);
uint8_t SnsMeasure(uint8_t channel, uint32_t *pResult, uint16_t iNumber);
void RtcPeriodicallyWakeUpInit();
void DC_measure(uint32_t cycles);
uint8_t SnsACInit(uint8_t channel);
uint8_t SnsACSigChainCfg(float *freq);
uint8_t SnsACTest(uint8_t channel, ImpResult_t *ImpResult,
		  size_t ImpResultArrSize);
uint8_t SnsMagPhaseCal(ImpResult_t *ImpResult, size_t ImpResultArrSize);
float DFTtoCurrent (int32_t DFTres, uint8_t channel);
uint8_t MeasureImpedance(RMeasType MType, uint8_t i, uint8_t channel,
			 ImpResult_t *ImpResult);
uint8_t ConnectSensor(RMeasType MType, uint8_t i, uint8_t channel,
		      ImpResult_t *ImpResult);
uint8_t CalibrateAdc();
int CalculateGainAdjust(int uiExpectedADCCode, int iVGainCal);

/**************************** Variables for use in other functions ********************/
extern SNS_CFG_Type * pSnsCfg0;
extern SNS_CFG_Type * pSnsCfg1;
extern volatile uint32_t ucButtonPress;
extern volatile uint8_t dftRdy;
extern volatile uint8_t adcRdy;
extern volatile uint8_t sinc2Rdy;
/* Max gain ind set to 8 at the beginning of measureimpedance, decrease if ADCMAX/ADCMIN interrupt */
extern volatile uint8_t uiMaxGainRangeIndex;
/* Max pga gain ind set to 4 at the beginning of measureimpedance, decrease if ADCMAX/ADCMIN interrupt */
extern volatile uint8_t uiMaxPgaGainIndex;
/* uiHpRtiaSeIndex refers to values in hprtiase_ohm, *szValHpRtiaSe, and uiHpRtiaSe */
extern uint8_t uiHpRtiaSeIndex;
/* uiGnPgaIndex refers to values in uiValGnPga_x2, *szValGnPga, and uiGnPga */
extern uint8_t uiGnPgaIndex;
extern uint8_t disableTiaAutorange;
extern uint8_t disablePgaAutorange;
extern pH_probe_t myPhProbe;
extern Conductivity_probe_t myEcProbe;
extern Temp_sensor_t myTempSensor;
extern float calX[];
extern float calY[];
extern float calT[];
extern ImpResult_t TempResult[];
extern size_t TempResultArrSize;
extern ImpResult_t CondResult[];
extern size_t CondResultArrSize;
extern uint8_t flagHiZMode;
extern volatile uint8_t adcSat;

#ifdef __cplusplus
}
#endif

#endif /* M355WQECTESTS_H_ */
