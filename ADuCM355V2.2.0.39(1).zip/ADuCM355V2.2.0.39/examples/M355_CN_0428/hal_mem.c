/*
 * 文件名:hal_mem.c
 *
 * 作者: jay lau
 * 描述:
 */




#include <string.h>
#include "stdbool.h"
#include "hal_mem.h"
#include "stdio.h"
#include "FeeLib.h"

#pragma location = CFGINFO_START_ADDR

 




#define   TEMP_SENSOR_TYPE_DEFAULT     TEMP_SENSOR_TYPE_MANUAL

#define   DEV_TYPE_DEFAULT     DEV_TYPE_PH
#define   COND_HIZMODE_DEFAULT     1

#if 0
__ro_placement __root __no_init static  const  volatile FLAMem_t m_FLAMem  ;
#else
__ro_placement __root static  const  volatile FLAMem_t m_FLAMem = {

		.cfgActive.conductivity     = 0,
		.cfgActive.resistivity      = 0,
		.cfgActive.temperature      = 0,
		.cfgActive.tempSensorRes    = 1000,

		.cfgActive.condSetupTime    = 20,
		.cfgActive.condHoldTime     = 20,
		.cfgActive.condTempCoef     = 0,
		.cfgActive.condCellConstant = 1,
		.cfgActive.condExcitVolt    = 0,
		.cfgActive.condExcitFreq    = 10,
		.cfgActive.condResOffset    = -0.000048,

		.cfgActive.baudRate         = 9600,
		.cfgActive.rs485Addr        = 1,
		.cfgActive.fwVersion        = 1,
		.cfgActive.tempSensorType   = TEMP_SENSOR_TYPE_DEFAULT,
		.cfgActive.dummy_12         = 0,

		.cfgActive.tempReviseCoef   = 1,
		.cfgActive.tempManualVal    = 25,
		.cfgActive.tempOffset       = 0,


		.cfgActive.orpOffset  		= 0,







		.cfgActive.phCalMode 	= 2,
		.cfgActive.phNistMode   = 1,

		.cfgActive.ph_val1    	= 7,
		.cfgActive.ph_volt1  	= 0,
		.cfgActive.ph_temp1     = 25,

		.cfgActive.ph_val2    	= 4.01,
		.cfgActive.ph_volt2  	= 177,
		.cfgActive.ph_temp2     = 25,

		.cfgActive.ph_val3    	= 10.01,
		.cfgActive.ph_volt3  	= -177,
		.cfgActive.ph_temp3     = 25,

		.cfgActive.phOffset 	= 0,


		.cfgActive.compGain40K  	= 1.03248410     ,
		.cfgActive.compOffset40K  	= -935.93347091  ,

		.cfgActive.compGain80K  	= 1.03275288     ,
		.cfgActive.compOffset80K 	= -938.39772741  ,

		.cfgActive.compGain160K 	= 1.0028         ,
		.cfgActive.compOffset160K 	= -993.82976022  ,

		.cfgActive.compGain1M   	= 0.99940877     ,
		.cfgActive.compOffset1M   	= -859.49507547  ,





		.cfgActive.devType      = DEV_TYPE_DEFAULT,
		.cfgActive.hizMode          = COND_HIZMODE_DEFAULT,
		.cfgActive.devSN            = 0x123456,
		.cfgActive.cs               = 0x29  ,









		/////////////////
		.cfgCopy.conductivity       = 0,
		.cfgCopy.resistivity        = 0,
		.cfgCopy.temperature        = 0,
		.cfgCopy.tempSensorRes      = 1000,

		.cfgCopy.condSetupTime    = 20,
		.cfgCopy.condHoldTime     = 20,
		.cfgCopy.condTempCoef     = 0,
		.cfgCopy.condCellConstant = 1,
		.cfgCopy.condExcitVolt    = 0,
		.cfgCopy.condExcitFreq    = 10,
		.cfgCopy.condResOffset    = -0.000048,

		.cfgCopy.baudRate           = 9600,
		.cfgCopy.rs485Addr          = 1,
		.cfgCopy.fwVersion          = 1,
		.cfgCopy.tempSensorType     = TEMP_SENSOR_TYPE_DEFAULT,
		.cfgCopy.dummy_12           = 0,

		.cfgCopy.tempReviseCoef     = 1,
		.cfgCopy.tempManualVal      = 25,
		.cfgCopy.tempOffset         = 0,



		.cfgCopy.orpOffset  		= 0,



		.cfgCopy.phCalMode = 2,
		.cfgCopy.phNistMode = 1,



		.cfgCopy.ph_val1    = 7,
		.cfgCopy.ph_volt1  	= 0,
		.cfgCopy.ph_temp1   = 25,

		.cfgCopy.ph_val2    = 4.01,
		.cfgCopy.ph_volt2  	= 177,
		.cfgCopy.ph_temp2   = 25,

		.cfgCopy.ph_val3    = 10.01,
		.cfgCopy.ph_volt3  	= -177,
		.cfgCopy.ph_temp3   = 25,

		.cfgCopy.phOffset 	= 0,



		.cfgCopy.compGain40K  	= 1.03248410     ,
		.cfgCopy.compOffset40K  = -935.93347091  ,

		.cfgCopy.compGain80K  	= 1.03275288     ,
		.cfgCopy.compOffset80K 	= -938.39772741  ,

		.cfgCopy.compGain160K 	= 1.0028         ,
		.cfgCopy.compOffset160K = -993.82976022  ,

		.cfgCopy.compGain1M   	= 0.99940877     ,
		.cfgCopy.compOffset1M   = -859.49507547  ,



		.cfgCopy.devType        = DEV_TYPE_DEFAULT,
		.cfgCopy.hizMode            = COND_HIZMODE_DEFAULT,
		.cfgCopy.devSN              = 0x123456,
		.cfgCopy.cs                 = 0x29  ,

};
#endif


uint8_t calculate_sum(uint8_t* data,uint16_t length)
{
	uint8_t ret = 0x00;

	for (uint16_t i = 0; i < length; i++) {
		ret += data[i];
	}

	return ret;
}

uint32_t HAL_MEM_CurrIdxAddr_Get  (   )
{
	return (uint32_t)&m_FLAMem.cfgActive;
}

uint32_t HAL_MEM_CopyIdxAddr_Get  (   )
{
	return (uint32_t)&m_FLAMem.cfgCopy;
}

void HAL_MEM_Init()
{
//	CfgInfo_t idx = {
//			. wr_idx = 0,
//			. wr_num = 0,
//			. dummy  = {0,0,0},
//			. cs     = 0,
//	};
//	uint32_t been_used = 0xA55AA55A;
//
//	//如果eeprom没有被初始化，那么进行初始化
//	if( m_DataMem.eep_been_init != 0xA55AA55A )
//	{
//		HAL_MEM_WriteEEP((uint32_t)&m_EEPMem.curr_idx,(uint8_t*)&idx,sizeof(CfgInfo_t));
//		HAL_MEM_WriteEEP((uint32_t)&m_EEPMem.copy_idx,(uint8_t*)&idx,sizeof(CfgInfo_t));
//
//		HAL_MEM_WriteFLA((uint32_t)&m_DataMem.eep_been_init,(uint8_t*)&been_used,4);
//	}
}





bool HAL_MEM_WriteEEP(uint32_t addr,uint8_t* data,uint16_t length)
{
	uint64_t udData;

	__disable_irq();
	FeePErs(  addr);
	for(int i=0;i<length;i+=8)
	{
		udData  =  *((uint64_t*) &data[i]);
		FeeWr(  addr + i,   udData);
	}
	__enable_irq();

	return true;
}



/**
 *
 */
__root  static     cfgInfo_t* p_cfg_active ;
__root  static     cfgInfo_t* p_cfg_copy ;

bool cfgInfo_reset()
{
	cfgInfo_t idx;

	memset(&idx,0x00,sizeof(cfgInfo_t));
	idx.cs = calculate_sum((uint8_t *) & idx, sizeof(cfgInfo_t)-1);

	HAL_MEM_WriteEEP(  (uint32_t)p_cfg_copy,   (uint8_t*)&idx,  sizeof(cfgInfo_t));
	if(memcmp(p_cfg_copy,(uint8_t*)&idx,sizeof(cfgInfo_t)) != 0)
	{
		return false;
	}

	HAL_MEM_WriteEEP(  (uint32_t)p_cfg_active,   (uint8_t*)&idx,  sizeof(cfgInfo_t));
	if(memcmp(p_cfg_active,(uint8_t*)&idx,sizeof(cfgInfo_t)) != 0)
	{
		return false;
	}

	return true;
}

bool cfgInfo_init()
{
	p_cfg_active = (cfgInfo_t*)HAL_MEM_CurrIdxAddr_Get  (   );
	p_cfg_copy = (cfgInfo_t*)HAL_MEM_CopyIdxAddr_Get  (   );

	uint8_t cs_curr = calculate_sum((uint8_t*) p_cfg_active,sizeof(cfgInfo_t)-4);
	uint8_t cs_copy = calculate_sum((uint8_t*) p_cfg_copy,sizeof(cfgInfo_t)-4);

//	if( p_cfg_active->cs == cs_curr )
//	{
//		//do nothing
//	}
//	else if(p_cfg_copy->cs == cs_copy )
//	{
//		HAL_MEM_WriteEEP(  (uint32_t)p_cfg_active,   (uint8_t*)p_cfg_copy,  sizeof(cfgInfo_t));
//		if( memcmp((uint8_t*) p_cfg_active,(uint8_t*) p_cfg_copy,sizeof(cfgInfo_t)) != 0 )
//		{
//			return false;
//		}
//	}
//	else
//	{
//		cfgInfo_reset();
//	}

	return true;
}



bool cfgInfo_get(cfgInfo_t *cfg)
{
	memcpy( cfg, p_cfg_active , sizeof(cfgInfo_t));

	return true;
}

bool cfgInfo_write(cfgInfo_t * idx)
{
	idx->cs = calculate_sum((uint8_t*) idx,sizeof(cfgInfo_t)-1);

	HAL_MEM_WriteEEP(  (uint32_t)p_cfg_copy,   (uint8_t*)idx,  sizeof(cfgInfo_t));
	if( memcmp((uint8_t*) p_cfg_copy,(uint8_t*) idx,sizeof(cfgInfo_t)) != 0 )
	{
		return false;
	}
	HAL_MEM_WriteEEP(  (uint32_t)p_cfg_active,   (uint8_t*)idx,  sizeof(cfgInfo_t));
	if( memcmp((uint8_t*) p_cfg_active,(uint8_t*) idx,sizeof(cfgInfo_t)) != 0 )
	{
		return false;
	}

	return true;
}


















