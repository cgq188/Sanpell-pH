/*
 * FreeModbus Libary: MSP430 Port
 * Copyright (C) 2006 Christian Walter <wolti@sil.at>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * File: $Id: portserial.c,v 1.3 2006/11/19 03:57:49 wolti Exp $
 */

/* ----------------------- Platform includes --------------------------------*/
#include "mb.h"
#include "mbport.h"
#include <UrtLib.h>
#include <DioLib.h>
#include "port.h"

#include <ADuCM355.h>
#include "stdbool.h"
#include "M355WqConfig.h"
/* ----------------------- Defines ------------------------------------------*/
#define U0_CHAR                 ( 0x10 )        /* Data 0:7-bits / 1:8-bits */

#define DEBUG_PERFORMANCE       ( 0 )

#if DEBUG_PERFORMANCE == 1
#define DEBUG_PIN_RX            ( 0 )
#define DEBUG_PIN_TX            ( 1 )
#define DEBUG_PORT_DIR          ( P1DIR )
#define DEBUG_PORT_OUT          ( P1OUT )
#define DEBUG_INIT( )           \
  do \
  { \
    DEBUG_PORT_DIR |= ( 1 << DEBUG_PIN_RX ) | ( 1 << DEBUG_PIN_TX ); \
    DEBUG_PORT_OUT &= ~( ( 1 << DEBUG_PIN_RX ) | ( 1 << DEBUG_PIN_TX ) ); \
  } while( 0 ); 
#define DEBUG_TOGGLE_RX( ) DEBUG_PORT_OUT ^= ( 1 << DEBUG_PIN_RX )
#define DEBUG_TOGGLE_TX( ) DEBUG_PORT_OUT ^= ( 1 << DEBUG_PIN_TX )

#else

#define DEBUG_INIT( )
#define DEBUG_TOGGLE_RX( )
#define DEBUG_TOGGLE_TX( )
#endif

/* ----------------------- Static variables ---------------------------------*/
UCHAR           ucGIEWasEnabled = FALSE;
UCHAR           ucCriticalNesting = 0x00;



/* ----------------------- Variables ----------------------------------------*/
static ULONG    ulNesting;
static uint32_t xOldState;

/* ----------------------- Start implementation -----------------------------*/
void EnterCriticalSection( void )
{
	uint32_t      xCurState;
	xCurState = __get_PRIMASK();
	__disable_irq();;//	__set_PRIMASK(1);
	if( ulNesting == 0 )
	{
		xOldState = xCurState;
	}
	ulNesting++;
}

void ExitCriticalSection( void )
{
    ulNesting--;
    if( 0 == ulNesting )
    {
    	__set_PRIMASK(xOldState);
    }
}


/* ----------------------- Start implementation -----------------------------*/
void vMBPortSerialEnable( BOOL xRxEnable, BOOL xTxEnable )
{
	EnterCriticalSection (  );
	if( xRxEnable )
	{
		pADI_UART0->COMIEN |= BITM_UART_COMIEN_ERBFI;
	}
	else
	{
		pADI_UART0->COMIEN &= (~BITM_UART_COMIEN_ERBFI);
	}
	if( xTxEnable )
	{
		pADI_UART0->COMIEN |= BITM_UART_COMIEN_ETBEI;
		DioSetPin(pADI_GPIO0,PIN0);			//make RS485 in TX status
	}
	else
	{
		pADI_UART0->COMIEN &= (~BITM_UART_COMIEN_ETBEI);
//		DioClrPin(pADI_GPIO0,PIN0);			//make RS485 in RX status

//		//TODO:不能直接关闭，如果移位寄存器还有数据，因此采用post机制循环操作，直到移位寄存器为空才关闭485 OE引脚
//		app msg;
//		msg.argc = 0;
//		msg.fun = tx_empty;
//		ts_post_message(msg);
	}
	ExitCriticalSection (  );
}

BOOL xMBPortSerialInit( UCHAR ucPort, ULONG ulBaudRate, UCHAR ucDataBits, eMBParity eParity )
{
	BOOL bInitialized = true;

	DioCfgPin(pADI_GPIO0,PIN0,0);		// Setup P0.0 as RS485 DE & RE#
	DioClrPin(pADI_GPIO0,PIN0);			//make RS485 in RX status
	DioOenPin(pADI_GPIO0,PIN0,1);

	DioCfgPin(pADI_GPIO0,PIN10,1);		// Setup P0.10 as UART pin
	DioCfgPin(pADI_GPIO0,PIN11,1);		// Setup P0.11 as UART pin
	// Set PCLk oversampling rate 32. (PCLK to UART baudrate generator is /32)
	pADI_UART0->COMLCR2 = 0x3;
	// Configure UART for 57600 baud rate
	UrtCfg(pADI_UART0,B9600,(BITM_UART_COMLCR_WLS|3),0);
	// Configure the UART FIFOs for 14 bytes deep
	UrtFifoCfg(pADI_UART0, RX_FIFO_14BYTE, BITM_UART_COMFCR_FIFOEN);
	// Clear the Rx/TX FIFOs
	UrtFifoClr(pADI_UART0, BITM_UART_COMFCR_RFCLR|BITM_UART_COMFCR_TFCLR);
	pADI_UART0->COMFCR |=0x2; // test to clear the RX FIFO
	// Enable Rx, Tx and Rx buffer full Interrupts
	UrtIntCfg(pADI_UART0,BITM_UART_COMIEN_ERBFI |
		  BITM_UART_COMIEN_ETBEI | BITM_UART_COMIEN_ELSI);
	// Enable UART interrupt source in NVIC
	NVIC_EnableIRQ(UART_EVT_IRQn);

	return bInitialized;
}

BOOL xMBPortSerialPutByte( CHAR ucByte )
{
	//    TXBUF0 = ucByte;
	//tx_fifo[tx_fifo_front];
	UrtTx(pADI_UART0 , ucByte);
	return TRUE;
}

BOOL xMBPortSerialGetByte( CHAR * pucByte )
{
	//    *pucByte = RXBUF0;
	*pucByte = UrtRx(pADI_UART0);
	return TRUE;
}

/**
 * @brief RS485使能发送引脚的处理:在发送完成后设置为接收状态
 */
BOOL xMBPortSerialTxEnPoll()
{
	if(UrtLinSta(pADI_UART0) & BITM_UART_COMLSR_TEMT)	//只有在发送移位寄存器为空的时候RS485 disable TX
	{
		DioClrPin(pADI_GPIO0,PIN0);			//make RS485 in RX status
		return FALSE;
	}
	return TRUE;
}


//==============================================================================
//                          Communications Int Handlers
//==============================================================================
/*Derived from M355_UART.c*/
#if (!DEBUG)
void UART_Int_Handler()
{
	int i = 0;
	int ucCOMSTA0;

	int ucCOMIID0 = UrtIntSta(pADI_UART0);
	if ((ucCOMIID0 & 0xE) == 0x2)          // Transmit buffer empty
	{
		pxMBFrameCBTransmitterEmpty(  );
	}

	if ((ucCOMIID0 & 0xE) == 0x4) {	          // Receive byte

		int cnt = pADI_UART0->COMRFC;    // read the Num of bytes in FIFO
		for (i=0; i<cnt; i++) {
			pxMBFrameCBByteReceived(  );
		}
	}

	if ((ucCOMIID0 & 0xE) == 0x6) {	          // Receive line status interrupt. Read COMLSR to clear.
		ucCOMSTA0 = UrtLinSta(pADI_UART0);		// Read COMLSR to clear.
		if(ucCOMSTA0 & BITM_UART_COMLSR_TEMT)	//只有在发送移位寄存器为空的时候RS485 disable TX
		{
			DioClrPin(pADI_GPIO0,PIN0);			//make RS485 in RX status
		}
	}

	if ((ucCOMIID0 & 0xE) == 0xC) {	          // UART Time-out condition
		int cnt = pADI_UART0->COMRFC;    // read the Num of bytes in FIFO
		for (i=0; i<cnt; i++) {
			pxMBFrameCBByteReceived(  );
		}
	}
}
#endif





