

/* ----------------------- Platform includes --------------------------------*/
#include <ADuCM355.h>

#include <cmsis_iccarm.h>



#include "mb.h"
#include "mbport.h"


#include "port.h"
#include "stdbool.h"
#include "hal_mem.h"


/* ----------------------- Defines ------------------------------------------*/
#include <float.h>
#include <math.h>
#include <string.h>

#include "../../../M355WqCmd.h"

#define REG_INPUT_START   1000
#define REG_INPUT_NREGS   4
#define REG_HOLDING_START 0			//保持寄存器起始地址
#define REG_HOLDING_NREGS 108		//保持寄存器数量

/* ----------------------- Static variables ---------------------------------*/
static USHORT   usRegInputStart = REG_INPUT_START;
static USHORT   usRegInputBuf[REG_INPUT_NREGS];
static USHORT   usRegHoldingStart = REG_HOLDING_START;
static USHORT   usRegHoldingBuf[REG_HOLDING_NREGS] = {1,2,3,4,5,6,7,8,9,10,11,12};		//保持寄存器


typedef struct{
	float temp;
	float conductivity;
}RegHoldingBuf_t;

uint32_t RtiaGet();
float MagRawGet();

//void on_modbus_rtu_uart_cfg_param_upd()
//{
//	int baud_rate = 9600;
//	int rs485_address = 30;
//	float voltage = 1.f;
//	float frequency = 100.f;
//	float temp_coef = 2.f;
//	float cell_const = 1.f;
//	float setup = 10.f;
//	float hold = 1.f;
//	int lcd_uc1601s_br = 3;
//	int lcd_uc1601s_pm = 104;
//	int lcd_uc1601s_tc = 2;
//}
//void on_modbus_rtu_upd_conductivity  ( )
//{
//	adc_file adc;
//
//	decltype(flash_file::cell_const) k;
//	decltype(flash_file::temp_coef) conf;
//
//	rewind(p_adc);
//	fread(&adc, sizeof(adc_file), 1, p_adc);
//
//	float temperature = adc.temp;
//	int rtd_wire = adc.wire_mode;
//	int rtd_type = adc.rtd_type;
//
//	float conductivity = (k * (adc.p_curt - adc.n_curt) / (adc.p_volt - adc.n_volt))
//	    		* (100 / (100 + conf * (temperature - 25)));
//
//	if (rtd_wire == -1)
//	{
//		beep(10);
//	}
//}
//void on_modbus_rtu_upd_temprature( )
//{
//	adc_file adc;
//
//	rewind(p_adc);
//	fread(&adc, sizeof(adc_file), 1, p_adc);
//
//	RegHoldingBuf.temp = adc.temp;
//}

uint32_t f2u32(float f)
{
	return (*(uint32_t*)&f);
}

float u162f(uint16_t msb, uint16_t lsb)
{
	uint32_t  tt =
			(((uint32_t)msb )<<16) |
			(((uint32_t)lsb )<<0)     ;

	return *(float *) &tt;
}

uint32_t u162u32(uint16_t msb, uint16_t lsb)
{
	uint32_t  tt =
			(((uint32_t)msb )<<16) |
			(((uint32_t)lsb )<<0)     ;

	return *(uint32_t *) &tt;
}

const static float m_fw_ver = 1.00;
static void reg_hold_upd(void)
{
	float conductivity;
	float resistivity;
	float temperature;
	float temp_sensor_res;
//	float setup_time  ;
//	float hold_time;
//	float voltage    = 1.f;
//	float frequency  = 100.f;
//	float temp_coef  = 2.f;
//	float cell_const = 1.f;
//	int baud_rate = 9600;
//	int rs485_address = 4;
//	uint16_t temp_sensor_type;
//	float temp_coef_k;
//	float temp_manual  ;
//	uint32_t sn = 0x1234;

	cfgInfo_t cfg;
	cfgInfo_get(&cfg);

//	conductivity =  p_dialog->GetConductivity() * 1000000;
	conductivity = Wq_CondGet();
 	temperature  = Wq_TempGet();
 	resistivity  = Wq_Resistivity();
//	resistivity  =  (1000000/conductivity )/1000000    ;// μS/cm
	temp_sensor_res = Wq_TempResGet();

	usRegHoldingBuf[1] = (*(uint32_t*)&conductivity) >> 16;
	usRegHoldingBuf[2] = (*(uint32_t*)&conductivity) >> 0;

	usRegHoldingBuf[3] = (*(uint32_t*)&resistivity) >> 16;
	usRegHoldingBuf[4] = (*(uint32_t*)&resistivity) >> 0;

	usRegHoldingBuf[5] = (*(uint32_t*)&temperature) >> 16;
	usRegHoldingBuf[6] = (*(uint32_t*)&temperature) >> 0;

	usRegHoldingBuf[7] = (*(uint32_t*)& temp_sensor_res  ) >> 16;
	usRegHoldingBuf[8] = (*(uint32_t*)& temp_sensor_res  ) >> 0;

	usRegHoldingBuf[9] = (*(uint32_t*)&cfg.condSetupTime  ) >> 16;
	usRegHoldingBuf[10] = (*(uint32_t*)&cfg.condSetupTime) >> 0;

	usRegHoldingBuf[11] = (*(uint32_t*)&cfg.condHoldTime) >> 16;
	usRegHoldingBuf[12] = (*(uint32_t*)&cfg.condHoldTime) >> 0;

	usRegHoldingBuf[13] = (*(uint32_t*)&cfg.condTempCoef) >> 16;
	usRegHoldingBuf[14] = (*(uint32_t*)&cfg.condTempCoef) >> 0;

	usRegHoldingBuf[15] = (*(uint32_t*)&cfg.condCellConstant) >> 16;
	usRegHoldingBuf[16] = (*(uint32_t*)&cfg.condCellConstant) >> 0;

	usRegHoldingBuf[17] = (*(uint32_t*)&cfg.condExcitVolt  ) >> 16;
	usRegHoldingBuf[18] = (*(uint32_t*)&cfg.condExcitVolt  ) >> 0;

	usRegHoldingBuf[19] = (*(uint32_t*)&cfg.condExcitFreq  ) >> 16;
	usRegHoldingBuf[20] = (*(uint32_t*)&cfg.condExcitFreq  ) >> 0;

	usRegHoldingBuf[21] = (*(uint32_t*)&cfg.baudRate) >> 16;
	usRegHoldingBuf[22] = (*(uint32_t*)&cfg.baudRate) >> 0;

	usRegHoldingBuf[23] = (*(uint32_t*)&cfg.rs485Addr  ) >> 16;
	usRegHoldingBuf[24] = (*(uint32_t*)&cfg.rs485Addr  ) >> 0;


	usRegHoldingBuf[25] = (*(uint32_t*)&m_fw_ver) >> 16;
	usRegHoldingBuf[26] = (*(uint32_t*)&m_fw_ver) >> 0;

	usRegHoldingBuf[27] = cfg.tempSensorType;
	usRegHoldingBuf[28] = 0;

	usRegHoldingBuf[29] = (*(uint32_t*)&cfg.tempReviseCoef  ) >> 16;
	usRegHoldingBuf[30] = (*(uint32_t*)&cfg.tempReviseCoef  ) >> 0;

	usRegHoldingBuf[31] = (*(uint32_t*)&cfg.tempManualVal  ) >> 16;
	usRegHoldingBuf[32] = (*(uint32_t*)&cfg.tempManualVal  ) >> 0;

	usRegHoldingBuf[33] = (*(uint32_t*)&cfg.tempOffset 	) >> 16;
	usRegHoldingBuf[34] = (*(uint32_t*)&cfg.tempOffset  ) >> 0;

	usRegHoldingBuf[35] = (f2u32(Wq_ORPGet()) ) >> 16;
	usRegHoldingBuf[36] = (f2u32(Wq_ORPGet()) ) >> 0;

	usRegHoldingBuf[37] = (*(uint32_t*)&cfg.orpOffset ) >> 16;
	usRegHoldingBuf[38] = (*(uint32_t*)&cfg.orpOffset ) >> 0;

	usRegHoldingBuf[39] = f2u32(cfg.condResOffset) >> 16;
	usRegHoldingBuf[40] = f2u32(cfg.condResOffset) >> 16;

	usRegHoldingBuf[41] = 0;//(*(uint32_t*)&cfg.orp_volt1 ) >> 16;
	usRegHoldingBuf[42] = 0;//(*(uint32_t*)&cfg.orp_volt1 ) >> 0;

	usRegHoldingBuf[43] = 0;//(*(uint32_t*)&cfg.orp_val2 ) >> 16;
	usRegHoldingBuf[44] = 0;//(*(uint32_t*)&cfg.orp_val2 ) >> 0;

	usRegHoldingBuf[45] = 0;//(*(uint32_t*)&cfg.orp_volt2 ) >> 16;
	usRegHoldingBuf[46] = 0;//(*(uint32_t*)&cfg.orp_volt2 ) >> 0;

	usRegHoldingBuf[47] = 0;//(*(uint32_t*)&cfg.orp_val3 ) >> 16;
	usRegHoldingBuf[48] = 0;//(*(uint32_t*)&cfg.orp_val3 ) >> 0;

	usRegHoldingBuf[49] = 0;//(*(uint32_t*)&cfg.orp_volt3 ) >> 16;
	usRegHoldingBuf[50] = 0;//(*(uint32_t*)&cfg.orp_volt3 ) >> 0;


	usRegHoldingBuf[51] = cfg.devType;
	usRegHoldingBuf[52] = cfg.hizMode;

	usRegHoldingBuf[53] = (*(uint32_t*)&cfg.devSN) >> 16;
	usRegHoldingBuf[54] = (*(uint32_t*)&cfg.devSN) >> 0;

	usRegHoldingBuf[61] = (f2u32(Wq_PHGet()) ) >> 16;
	usRegHoldingBuf[62] = (f2u32(Wq_PHGet()) ) >> 0;

	usRegHoldingBuf[63] = (f2u32(Wq_PHVoltGet()) ) >> 16;
	usRegHoldingBuf[64] = (f2u32(Wq_PHVoltGet()) ) >> 0;

	usRegHoldingBuf[65] = cfg.phCalMode;
	usRegHoldingBuf[66] = cfg.phNistMode;

	usRegHoldingBuf[67] = (*(uint32_t*)&cfg.ph_val1) >> 16;
	usRegHoldingBuf[68] = (*(uint32_t*)&cfg.ph_val1) >> 0;

	usRegHoldingBuf[69] = (*(uint32_t*)&cfg.ph_volt1) >> 16;
	usRegHoldingBuf[70] = (*(uint32_t*)&cfg.ph_volt1) >> 0;

	////
	usRegHoldingBuf[71] = (*(uint32_t*)&cfg.ph_temp1) >> 16;
	usRegHoldingBuf[72] = (*(uint32_t*)&cfg.ph_temp1) >> 0;

	usRegHoldingBuf[73] = (*(uint32_t*)&cfg.ph_val2) >> 16;
	usRegHoldingBuf[74] = (*(uint32_t*)&cfg.ph_val2) >> 0;

	usRegHoldingBuf[75] = (*(uint32_t*)&cfg.ph_volt2) >> 16;
	usRegHoldingBuf[76] = (*(uint32_t*)&cfg.ph_volt2) >> 0;

	usRegHoldingBuf[77] = (*(uint32_t*)&cfg.ph_temp2) >> 16;
	usRegHoldingBuf[78] = (*(uint32_t*)&cfg.ph_temp2) >> 0;

	usRegHoldingBuf[79] = (*(uint32_t*)&cfg.ph_val3) >> 16;
	usRegHoldingBuf[80] = (*(uint32_t*)&cfg.ph_val3) >> 0;

	usRegHoldingBuf[81] = (*(uint32_t*)&cfg.ph_volt3) >> 16;
	usRegHoldingBuf[82] = (*(uint32_t*)&cfg.ph_volt3) >> 0;

	usRegHoldingBuf[83] = (*(uint32_t*)&cfg.ph_temp3) >> 16;
	usRegHoldingBuf[84] = (*(uint32_t*)&cfg.ph_temp3) >> 0;




	usRegHoldingBuf[85] = (*(uint32_t*)&cfg.phOffset) >> 16;
	usRegHoldingBuf[86] = (*(uint32_t*)&cfg.phOffset) >> 0;

	usRegHoldingBuf[87] =   RtiaGet() >> 16;
	usRegHoldingBuf[88] =   RtiaGet() >> 0;

	usRegHoldingBuf[89] =   (f2u32(MagRawGet()) ) >> 16;
	usRegHoldingBuf[90] =   (f2u32(MagRawGet()) ) >> 0;

	usRegHoldingBuf[91] = (*(uint32_t*)&cfg.compGain40K) >> 16;
	usRegHoldingBuf[92] = (*(uint32_t*)&cfg.compGain40K) >> 0;

	usRegHoldingBuf[93] = (*(uint32_t*)&cfg.compOffset40K) >> 16;
	usRegHoldingBuf[94] = (*(uint32_t*)&cfg.compOffset40K) >> 0;

	usRegHoldingBuf[95] = (*(uint32_t*)&cfg.compGain80K) >> 16;
	usRegHoldingBuf[96] = (*(uint32_t*)&cfg.compGain80K) >> 0;

	usRegHoldingBuf[97] = (*(uint32_t*)&cfg.compOffset80K) >> 16;
	usRegHoldingBuf[98] = (*(uint32_t*)&cfg.compOffset80K) >> 0;

	usRegHoldingBuf[99] = (*(uint32_t*)&cfg.compGain160K) >> 16;
	usRegHoldingBuf[100] = (*(uint32_t*)&cfg.compGain160K) >> 0;

	usRegHoldingBuf[101] = (*(uint32_t*)&cfg.compOffset160K) >> 16;
	usRegHoldingBuf[102] = (*(uint32_t*)&cfg.compOffset160K) >> 0;

	usRegHoldingBuf[103] = (*(uint32_t*)&cfg.compGain1M) >> 16;
	usRegHoldingBuf[104] = (*(uint32_t*)&cfg.compGain1M) >> 0;

	usRegHoldingBuf[105] = (*(uint32_t*)&cfg.compOffset1M) >> 16;
	usRegHoldingBuf[106] = (*(uint32_t*)&cfg.compOffset1M) >> 0;

}

int modbus_rtu_init( void )
{
	 

	cfgInfo_t cfg;
	cfgInfo_get(&cfg);

	/* Initialize Protocol Stack. */
	if( (   eMBInit( MB_RTU, cfg.rs485Addr, 0, cfg.baudRate, MB_PAR_NONE ) ) != MB_ENOERR )
	{
	}
	/* Enable the Modbus Protocol Stack. */
	else if( (  eMBEnable(  ) ) != MB_ENOERR )
	{
	}

	reg_hold_upd();

	return 1;
}


int modbus_rtu_poll  ( void )
{
//	vMBPortSerialEnable(FALSE,TRUE);
//	while(1)
//	{
//		xMBPortSerialPutByte( 0xA6);
//		for(volatile int i=0;i<10000;i++);
//	}

	int ret = 0;

	xMBPortSerialTxEnPoll();

	eMBPoll();

	if( xMBPortEventIsInQueue() )
	{
		ret = 1;
	}

	return ret;
}


eMBErrorCode
eMBRegInputCB( UCHAR * pucRegBuffer, USHORT usAddress, USHORT usNRegs )
{
	eMBErrorCode    eStatus = MB_ENOERR;
	int             iRegIndex;

	if( ( usAddress >= REG_INPUT_START )
			&& ( usAddress + usNRegs <= REG_INPUT_START + REG_INPUT_NREGS ) )
	{
		iRegIndex = ( int )( usAddress - usRegInputStart );
		while( usNRegs > 0 )
		{
			*pucRegBuffer++ = ( unsigned char )( usRegInputBuf[iRegIndex] >> 8 );
			*pucRegBuffer++ = ( unsigned char )( usRegInputBuf[iRegIndex] & 0xFF );
			iRegIndex++;
			usNRegs--;
		}
	}
	else
	{
		eStatus = MB_ENOREG;
	}

	return eStatus;
}


bool IsAlmostEqual(float f1,float f2)
{
	return fabs(f1 - f2) <=  FLT_EPSILON  ;// AlmostEqualsAbs()
}



static void reg_hold_wr_upd(void)
{
	cfgInfo_t p_cfg_rd;
	cfgInfo_t  cfg_wr;

	cfgInfo_get(&p_cfg_rd);
	memcpy(&cfg_wr,&p_cfg_rd,sizeof(cfgInfo_t));


	cfg_wr.condSetupTime = u162f(
			usRegHoldingBuf[9]   ,
			usRegHoldingBuf[10]    ) ;

	cfg_wr.condHoldTime = u162f(
			usRegHoldingBuf[11]  ,
			usRegHoldingBuf[12]  ) ;


	cfg_wr.condTempCoef = u162f(
			usRegHoldingBuf[13]   ,
			usRegHoldingBuf[14]   )  ;

	cfg_wr.condCellConstant   = u162f(
			usRegHoldingBuf[15] ,
			usRegHoldingBuf[16]  );

	cfg_wr.condExcitVolt     = u162f(
			usRegHoldingBuf[17]   ,
			usRegHoldingBuf[18]   );

	cfg_wr.condExcitFreq  = u162f(
			usRegHoldingBuf[19]  ,
			usRegHoldingBuf[20]  ) ;

	cfg_wr.baudRate = u162u32(
			usRegHoldingBuf[21]  ,
			usRegHoldingBuf[22]  ) ;

	cfg_wr.rs485Addr = u162u32(
			usRegHoldingBuf[23]  ,
			usRegHoldingBuf[24]  );

	cfg_wr.tempSensorType = usRegHoldingBuf[27]    ;

	cfg_wr.tempReviseCoef    = u162f(
			usRegHoldingBuf[29]  ,
			usRegHoldingBuf[30]  ) ;

	cfg_wr.tempManualVal      = u162f(
			usRegHoldingBuf[31] ,
			usRegHoldingBuf[32] ) ;

	cfg_wr.tempOffset        = u162f(
			usRegHoldingBuf[33] ,
			usRegHoldingBuf[34] ) ;




	cfg_wr.orpOffset        = u162f(
			usRegHoldingBuf[37] ,
			usRegHoldingBuf[38] ) ;

	cfg_wr.condResOffset    = u162f(
			usRegHoldingBuf[39] ,
			usRegHoldingBuf[40] ) ;




	cfg_wr.devType =  usRegHoldingBuf[51] ;

	cfg_wr.hizMode =  usRegHoldingBuf[52] ;


	cfg_wr.devSN = u162u32 (
			usRegHoldingBuf[53] ,
			usRegHoldingBuf[54]) ;


	cfg_wr.phCalMode = usRegHoldingBuf[65]   ;
	cfg_wr.phNistMode = usRegHoldingBuf[66];
	cfg_wr.ph_val1 = u162f(
			usRegHoldingBuf[67]   ,
			usRegHoldingBuf[68]    ) ;
	cfg_wr.ph_volt1   = u162f(
			usRegHoldingBuf[69]   ,
			usRegHoldingBuf[70]    ) ;
	cfg_wr.ph_temp1     = u162f(
			usRegHoldingBuf[71]   ,
			usRegHoldingBuf[72]    ) ;

	cfg_wr.ph_val2 = u162f(
			usRegHoldingBuf[73]   ,
			usRegHoldingBuf[74]    ) ;
	cfg_wr.ph_volt2   = u162f(
			usRegHoldingBuf[75]   ,
			usRegHoldingBuf[76]    ) ;
	cfg_wr.ph_temp2     = u162f(
			usRegHoldingBuf[77]   ,
			usRegHoldingBuf[78]    ) ;

	cfg_wr.ph_val3 = u162f(
			usRegHoldingBuf[79]   ,
			usRegHoldingBuf[80]    ) ;
	cfg_wr.ph_volt3   = u162f(
			usRegHoldingBuf[81]   ,
			usRegHoldingBuf[82]  ) ;
	cfg_wr.ph_temp3     = u162f(
			usRegHoldingBuf[83]   ,
			usRegHoldingBuf[84]    ) ;


	cfg_wr.phOffset     = u162f(
			usRegHoldingBuf[85]   ,
			usRegHoldingBuf[86]  ) ;

//	usRegHoldingBuf[87] =   RtiaGet() >> 16;
//	usRegHoldingBuf[88] =   RtiaGet() >> 0;
//
//	usRegHoldingBuf[89] =   (f2u32(MagRawGet()) ) >> 16;
//	usRegHoldingBuf[90] =   (f2u32(MagRawGet()) ) >> 0;
//

	cfg_wr.compGain40K     = u162f(
			usRegHoldingBuf[91] ,
			usRegHoldingBuf[92]  ) ;

	cfg_wr.compOffset40K     = u162f(
			usRegHoldingBuf[93] ,
			usRegHoldingBuf[94] ) ;

	cfg_wr.compGain80K     = u162f(
			usRegHoldingBuf[95] ,
			usRegHoldingBuf[96] ) ;

	cfg_wr.compOffset80K     = u162f(
			usRegHoldingBuf[97] ,
			usRegHoldingBuf[98] ) ;

	cfg_wr.compGain160K     = u162f(
			usRegHoldingBuf[99],
			usRegHoldingBuf[100] ) ;

	cfg_wr.compOffset160K     = u162f(
			usRegHoldingBuf[101] ,
			usRegHoldingBuf[102]) ;

	cfg_wr.compGain1M     = u162f(
			usRegHoldingBuf[103] ,
			usRegHoldingBuf[104] ) ;

	cfg_wr.compOffset1M     = u162f(
			usRegHoldingBuf[105] ,
			usRegHoldingBuf[106] ) ;


	cfg_wr.cs = calculate_sum((uint8_t*)&cfg_wr,sizeof(cfgInfo_t)-4);

	if(memcmp( &cfg_wr ,&p_cfg_rd , sizeof(cfgInfo_t)) != 0)
	{
		cfgInfo_write(&cfg_wr);
	}

}


eMBErrorCode eMBRegHoldingCB( UCHAR * pucRegBuffer, USHORT usAddress, USHORT usNRegs, eMBRegisterMode eMode )
{
	eMBErrorCode    eStatus = MB_ENOERR;
	int             iRegIndex;

	if( ( usAddress >= REG_HOLDING_START ) &&
			( usAddress + usNRegs <= REG_HOLDING_START + REG_HOLDING_NREGS ) )
	{
		iRegIndex = ( int )( usAddress - usRegHoldingStart );
		switch ( eMode )
		{
		/* Pass current register values to the protocol stack. */
		case MB_REG_READ:

			reg_hold_upd();

			while( usNRegs > 0 )
			{
				*pucRegBuffer++ = ( unsigned char )( usRegHoldingBuf[iRegIndex] >> 8 );
				*pucRegBuffer++ = ( unsigned char )( usRegHoldingBuf[iRegIndex] & 0xFF );
				iRegIndex++;
				usNRegs--;
			}
			break;

			/* Update current register values with new values from the
			 * protocol stack. */
		case MB_REG_WRITE:
			while( usNRegs > 0 )
			{
				usRegHoldingBuf[iRegIndex] = *pucRegBuffer++ << 8;
				usRegHoldingBuf[iRegIndex] |= *pucRegBuffer++;
				iRegIndex++;
				usNRegs--;
			}

			//更新寄存器列表
			reg_hold_wr_upd();


		}
	}
	else
	{
		eStatus = MB_ENOREG;
	}
	return eStatus;
}

eMBErrorCode
eMBRegCoilsCB( UCHAR * pucRegBuffer, USHORT usAddress, USHORT usNCoils, eMBRegisterMode eMode )
{
	return MB_ENOREG;
}

eMBErrorCode
eMBRegDiscreteCB( UCHAR * pucRegBuffer, USHORT usAddress, USHORT usNDiscrete )
{
	return MB_ENOREG;
}
