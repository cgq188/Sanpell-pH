/**
 *****************************************************************************
   @addtogroup EC sensor
   @{
   @file     M355WqCmd.c
   @brief    Command Line Interface for Water Quality Demo
   @par Revision History:
   @version  V0.1
   @author   ADI
   @date     June 2018
   @par Revision History:
   - V0.1, June 2018: initial version
   Decription:
     Interpret commands received via terminal and Run meas/config routines
	 Handle communications interrupts (I2C/SPI/UART based on config files)

All files for ADuCM355 provided by ADI, including this file, are
provided  as is without warranty of any kind, either expressed or implied.
The user assumes any and all risk from the use of this code.
It is the responsibility of the person integrating this code into an application
to ensure that the resulting application performs as required and is safe.

**/

/***************************** Include Files **********************************/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "M355WqConfig.h"
#include "M355WqCmd.h"
#include "hal_mem.h"
#include "M355WqEcTests.h"

/************************** Variable Definitions ******************************/
/* Available commands */
char *CmdCommands[] = {
	"dummyfn",
	"help",
	"sensortype",
	"measuretemp",
	"measuresensor",
	"measureeis",
	"printhealth",
	"printtemp",
	"printconfig",
	"printserialnumber",
	"setmineisfreq",
	"setmaxeisfreq",
	"enabletemp",
	"enablehizmode",
	"renamesensor",
	""
};

/* Functions for available commands */
cmdFunc CmdFun[] = {
	DoNothing,
	Wq_CmdHelp,
	ChangeSnsType,
	Wq_CmdTemp,
	MeasureParameter,
	MeasureEIS,
	PrintSnsHealth,
	PrintTemp,
	PrintConfig,
	PrintSerialNum,
	SetMinEISFreq,
	SetMaxEISFreq,
	EnableTemp,
	EnableHiZMode,
	RenameSns,
	NULL
};

/*Communication Variables*/
volatile unsigned char ucCOMSTA0 = 0;	// store status register
volatile unsigned char ucCOMIID0 = 0;	// store interrupt status register
volatile unsigned char ucComRx = 0;	// holds Rx buffer contents
unsigned char ucTxBufferEmpty  = 0;	// Is Tx buffer empty
unsigned char szTemp[BUF_SIZE] = "";	// Used to build string before printing
unsigned char ucPrevBytesArr[2] = "";	// Stores bytes leftover in Tx FIFO
unsigned char szInSring[64] = "";	// Holds incoming string
volatile unsigned char szbuffer[16];	// Buffer to test Rx FIFO
unsigned char ucPacketReceived = 0;	// Flag to indicate command received
unsigned char ucRxCnt = 0;		// Number of incoming bytes received
unsigned char ucTxCnt = 0;		// Number of bytes to transmit in szTemp
volatile unsigned char* pTxSend = szTemp;	// next character to send
volatile unsigned char* pTxWrite = szTemp;	// next write location
unsigned char ucNumRxIrqs = 0;		// number of Rx interrupts
unsigned char ucNumToIrqs = 0;		// number of Time-out interrupts
int iNumBytesInFifo = 0;		// bytes in the FIFO
unsigned char* mastercmd = szInSring;	// command from master

#ifndef UARTcomms
unsigned char* pRx = &szInSring[1];
#else
unsigned char* pRx = &szInSring[0];
#endif /* UARTcomms */

uint8_t tempbyte = 0;
uint8_t uiPrevBytes = 0;
int nbytes = 0;
float temp;	//store last temperature measurement
volatile float mTemperature;	//store last temperature measurement
volatile float mConductivity;
volatile float mResistivity  ;
volatile float mTempRes  ;
volatile float mPH    ;
volatile float mPHVolt;
volatile float mORP;
volatile float mOrpVolt;

extern ImpResult_t EISResult[];		//get access to EISresult defined in main
extern size_t EISResultArrSize;		//sizeof can't be used with extern array
extern void I2CInit(uint8_t address);	//Needed in order to rewrite I2C address

/****************************** Global functions ******************************/

//#pragma GCC diagnostic push
//#pragma GCC diagnostic ignored "-Wunused-parameter"

/**
   @brief Display info for <help> command

   @param args - pointer to the arguments on the command line.

   @return none
**/
void Wq_CmdHelp(uint8_t *args)
{
	printf(EOL);
	printf("Available commands:"EOL);
	printf(" help                   - Display available commands"EOL);
	printf(" sensortype <type>      - Change the type of sensor that is connected (default:pH)."EOL);
	printf("                          <type> = ph, conductivity, orp"EOL);
	printf(" measuretemp            - Measure and print current temperature value"EOL);
	printf(" measuresensor          - Make sensor measurement for configured sensor (pH, conductivity, orp)"EOL);
	printf(" measureeis             - Perform EIS sweep on sensor and estimate sensor health"EOL);
	printf("                          add optional argument bode to print bode instead of nyquist plot"EOL);
	printf(" printhealth            - Print sensor health value from last EIS measurement"EOL);
	printf(" printtemp              - Print temperature without updating (i.e., temp of last sensor meas)"EOL);
	printf(" printconfig            - Print configuration (sensortype, hizmode, temperature enabled)"EOL);
	printf(" printserialnumber      - Print ADuCM355 unique ID (can be used to store calibrations)"EOL);
	printf(" enabletemp <en>        - Enable/disable temperature sensor channel."EOL);
	printf("                          <en> = 1 to <en> = 0 to disable"EOL);
	printf(" enablehizmode <en>     - Enable/disable high-impedance TIA. Ensure S2 matches this setting"EOL);
	printf("                          <en> = 1 to <en> = 0 to disable"EOL);
	printf(" setmineisfreq <freq>   - Set minimum frequency for eis measurement"EOL);
	printf(" setmaxeisfreq <freq>   - Set minimum frequency for eis measurement"EOL);
	printf("                          <freq> = 0.1 to 200000 or full to set to full range"EOL);
	printf(" renamesensor <name>    - Rename the sensor."EOL);
	printf("                          <name> = new name (<16 characters)"EOL);
#ifdef I2Ccomms
	printf(" switchsensor <site>    - Switch to sensor board at <site>."EOL);
	printf("                          <site> = 1, 2, 3, 4. Channel num of the sensor board to switch to"EOL);
#endif /* I2Ccomms */
#ifdef SPIcomms
	printf(" switchsensor <site>    - Switch to sensor board at <site>"EOL);
	printf("                          <site> = 1, 2, 3, 4. Channel num of the sensor board to switch to"EOL);
#endif /* SPIComms */
}

/**
   @brief Display info for <temp> command

   @param args - pointer to the arguments on the command line.

   @return none
**/
void Wq_CmdTemp(uint8_t *args)
{
	temp = Wq_CalculateTemp();
	printf("Temperature: %.3f[˚C]"EOL, temp);
	mTemperature = temp;
}

float Wq_TempGet()
{
	return mTemperature;
}

float Wq_TempResGet()
{
	return mTempRes;
}

float Wq_CondGet()
{
	return mConductivity;
}

float Wq_PHGet()
{
	return mPH;
}


float Wq_ORPGet()
{
	return mORP;
}

float Wq_ORPVoltGet()
{
	return mOrpVolt;
}

float Wq_PHVoltGet()
{
	return mPHVolt;
}

float Wq_Resistivity  ()
{
	return mResistivity;
}

/**
   @brief Finds the next command line argument

   @param args - pointer to the arguments on the command line.

   @return pointer to the next argument.

**/
uint8_t *Wq_FindArgv(uint8_t *args)
{
	uint8_t *p = args;
	int     fl = 0;

	while (*p != 0) {
		if ((*p == _SPC))
			fl = 1;
		else if (fl)
			break;
		p++;
	}

	return p;
}

/**
   @brief Separates a command line argument

   @param dst - pointer to a buffer where the argument will be copied
   @param args - pointer to the current position of the command line .

   @return none

**/
void Wq_GetArgv(char *dst, uint8_t *args)
{
	uint8_t  *s = args;
	char     *d = dst;

	while (*s) {
		if (*s == _SPC)
			break;
		*d++ = *s++;
	}

	*d = '\0';
}

/**
   @brief Command line process function

   @return none
**/
void Wq_CmdProcess(void)
{
	cmdFunc   func;

	/* <ENTER> key was pressed */
	/* Find needed function based on typed command */
	func = Wq_FindCommand((char *)pRx);

	/* Check if there is a valid command */
	if (func) {
		/* Call the desired function */
		(*func)(&pRx[2]);

		/* Check if there is no match for typed command */
	} else if (strlen((const char *)pRx) != 0) {
		/* Display a message for unknown command */
		printf("Unknown command!"EOL);
	}
	/* Prepare for next <ENTER> */
	Wq_CmdPrompt();
}

/**
   @brief Command line prompt. Caller must verify that only the enabled board can run this.

   @return int - UART status: UART_SUCCESS or error status
**/
void Wq_CmdPrompt(void)
{
//	int res;
	static uint8_t count = 0;

	printf(EOL);

	/* Check first <ENTER> is pressed after reset */
	if(count == 0) {
		printf("Welcome to Water Quality Demo!"EOL);
		printf("  Type <help> to see available commands..."EOL);
		printf(EOL);
#ifndef UARTcomms
		printf("~");
#endif /* UARTcomms */
		count++;
	}

}

/**
   @brief Find available commands

   @param cmd - command to search

   @return cmdFunc - return the specific function for available command or NULL
					 for invalid command
**/
cmdFunc Wq_FindCommand(char *cmd)
{
	cmdFunc func = NULL;
	char *p = cmd;
	int i = 0;
	int f1 = 0;
	int cmdlength = 0;

	while(*p != 0) {
		if (*p == _SPC)
			f1 = 1;
		else if (!f1)
			cmdlength++;
		p++;
	}

	while (CmdFun[i] != NULL) {
		if(strncmp(cmd, CmdCommands[i], cmdlength) == 0) {
			func = CmdFun[i];
			break;
		}
		i++;
	}

	return func;
}

void DoNothing(uint8_t *args)
{
	// nothing to do here
	// this is to avoid help printing each time enter is pressed
}

/**
   @brief Calculate temperature value

   @return float - temperature value
**/
float Wq_CalculateTemp(void)
{
	float res;
	res = 30000;
	temp = 25.0;

	cfgInfo_t cfgInfo;
	cfgInfo_get(&cfgInfo);

	if(pSnsCfg1->Enable == SENSOR_CHANNEL_ENABLE) {
		/* Measure resistance of Temp Sensor */
		SnsACInit(CHAN1);
		SnsACTest(CHAN1, TempResult, TempResultArrSize);
		SnsMagPhaseCal(TempResult, TempResultArrSize);   //calculate impedance
		
		/* Adjust defaults */
		pSnsCfg1->StartingHpRtiaSeIndex = TempResult[TempResultArrSize-1].iRtia;
		pSnsCfg1->StartingGnPgaIndex = TempResult[TempResultArrSize-1].iGpga;

		res = fabs(TempResult[0].Mag);

		mTempRes = res;

#if DEBUG
		printf("Temp sensor: %.2f ohms"EOL,res);/*TESTING*/
#endif /*DEBUG*/

#if 0
		//	/* Calculate temperature value */
		if(myTempSensor.temp_sensor_type == NTC) {
			if(NTC_COMP_TYPE == B)
				//	1/T = (1/B)*ln(R/Ro) + 1/To	(simplified beta version).
				temp = 1/(((1/myTempSensor.B_value)*log(res/myTempSensor.R1))+(1/
						(myTempSensor.T1 + K_DEGREES))) - K_DEGREES;
			else if(NTC_COMP_TYPE == STEINHARTHART)
				//	Steinhart-Hart equation: 1/T = a + b(Ln R) + c(Ln R)^3,  T in degrees Kelvin
				temp = 1/(myTempSensor.A_steinhart + myTempSensor.B_steinhart*log(
						  res) + myTempSensor.C_steinhart*(pow(log(res),3))) - K_DEGREES;
		} else {
			//RTD: Use linear approximation. Linearity in liquid water range is <0.1'C
			temp = myTempSensor.T1 + (res - myTempSensor.R1)*((myTempSensor.T2 -
					myTempSensor.T1)/(myTempSensor.R2 - myTempSensor.R1));
		}
#endif

		//	/* Calculate temperature value */
		if((cfgInfo.tempSensorType == TEMP_SENSOR_TYPE_NTC30K)  ) {
			myTempSensor. R1 = 30000;			/* NTC: nominal resistance. RTD: resistance at T1. */
			myTempSensor. T1 = 25;			/* NTC: temperature at nominal resistance. RTD: temperature for R1. */

			if(NTC_COMP_TYPE == B)
			{
				//	1/T = (1/B)*ln(R/Ro) + 1/To	(simplified beta version).
				temp = 1/(((1/myTempSensor.B_value)*log(res/myTempSensor.R1))+(1/
						(myTempSensor.T1 + K_DEGREES))) - K_DEGREES;
			}
			else if(NTC_COMP_TYPE == STEINHARTHART)
			{
				//	Steinhart-Hart equation: 1/T = a + b(Ln R) + c(Ln R)^3,  T in degrees Kelvin
				temp = 1/(myTempSensor.A_steinhart + myTempSensor.B_steinhart*log(
						res) + myTempSensor.C_steinhart*(pow(log(res),3))) - K_DEGREES;
			}

			temp = temp*cfgInfo.tempReviseCoef + cfgInfo.tempOffset  ;

		} else if(cfgInfo.tempSensorType == TEMP_SENSOR_TYPE_PT1000)
		{
			myTempSensor. R1 = 1000;			/* NTC: nominal resistance. RTD: resistance at T1. */
			myTempSensor. T1 = 0;			/* NTC: temperature at nominal resistance. RTD: temperature for R1. */
			myTempSensor. R2 = 1385;	    /* RTD point 2 resistance */
			myTempSensor. T2 = 100;			/* RTD point 2 temperature */

			//RTD: Use linear approximation. Linearity in liquid water range is <0.1'C
			temp = myTempSensor.T1 + (res - myTempSensor.R1)*((myTempSensor.T2 -
					myTempSensor.T1)/(myTempSensor.R2 - myTempSensor.R1));

			temp = temp*cfgInfo.tempReviseCoef + cfgInfo.tempOffset  ;
		}
		else if (cfgInfo.tempSensorType == TEMP_SENSOR_TYPE_PT100)
		{
			myTempSensor. R1 = 100;			/* NTC: nominal resistance. RTD: resistance at T1. */
			myTempSensor. T1 = 0;			/* NTC: temperature at nominal resistance. RTD: temperature for R1. */
			myTempSensor. R2 = 138.5;	    /* RTD point 2 resistance */
			myTempSensor. T2 = 100;			/* RTD point 2 temperature */

			//RTD: Use linear approximation. Linearity in liquid water range is <0.1'C
			temp = myTempSensor.T1 + (res - myTempSensor.R1)*((myTempSensor.T2 -
					myTempSensor.T1)/(myTempSensor.R2 - myTempSensor.R1));

			temp = temp*cfgInfo.tempReviseCoef + cfgInfo.tempOffset  ;
		}
		else
		{
			temp = cfgInfo.tempManualVal;
		}
	}

	return temp;
}


typedef struct {
	float val;
	float volt;
	float temp;
}PH_Cal_t;


/**
 * @brief
 */
void bubble_sort(PH_Cal_t* array,uint16_t num)
{
	PH_Cal_t temp;
	for (int i = num - 1; 0 < i; i--)
	{
		for (uint16_t j = 0; j < i; j++)
		{
			if (array[j].volt > array[j + 1].volt)
			{
				temp = array[j];
				array[j] = array[j + 1];
				array[j + 1] = temp;
			}
		}
	}
}

float select_real_ph_tech(float ph, float temp)
{
	float calc_ph = 0.0f;
	float temper_comp_table1[][5]=
	{
		{1.668f,4.00f,	6.98f,	9.46f,	13.423f},//0
		{1.668f,4.004f,	6.950f,	9.392f,	13.207f},//5
		{1.670f,4.001f,	6.922f,	9.331f,	13.003f},//10
		{1.672f,4.001f,	6.900f,	9.277f,	12.810f},//15
		{1.676f,4.003f,	6.880f,	9.228f,	12.627f},//20
		{1.680f,4.008f,	6.865f,	9.184f,	12.454f},//25
		{1.685f,4.015f,	6.853f,	9.144f,	12.289f},//30
		{1.694f,4.028f,	6.841f,	9.095f,	12.133f},//37
		{1.697f,4.036f,	6.837f,	9.076f,	11.984f},//40
		{1.704f,4.049f,	6.834f,	9.046f,	11.841f},//45
		{1.712f,4.064f,	6.833f,	9.018f,	11.705f},//50
		{1.715f,4.075f,	6.834f,	8.985f,	11.574f},//55
		{1.723f,4.091f, 6.836f, 8.962f,	11.449f},//60
		{1.73f,	4.11f,	6.84f,	8.94f,	11.330f},//65
		{1.743f,4.126f, 6.845f,	8.921f,	11.210f},//70
		{1.75f,	4.14f,	6.85f,	8.90f,	11.100f},//75
		{1.766f,4.164f,	6.859f,	8.885f,	10.990f},//80
		{1.78f,	4.19f,	6.87f,	8.87f,	10.890f},//85
		{1.792f,4.205f,	6.877f, 8.850f,	10.790f},//90
		{1.806f,4.227f,	6.886f, 8.833f,	10.690f}//95
	};

	float temp_std[] = {1.680f,4.008f,	6.865f,	9.184f,	12.454f};
	int i, idx = 0, idy = 0;

	float min_diff = (temp_std[0] - ph) * (temp_std[0] - ph);

	for(i = 1; i < 5; i++)
	{
		if((temp_std[i] - ph) * (temp_std[i] - ph) < min_diff)
		{
			min_diff = (temp_std[i] - ph) * (temp_std[i] - ph);
			idx = i;
		}
	}

	for(i = 5; i < 100; i+=5)
	{
		if(temp >= (float)(i - 5) && temp < (float)i)
		{
			idy = i / 5 - 1;
			break;
		}
	}

	if(temp < 0.0f)
	{
		calc_ph = temper_comp_table1[0][idx];
	}
	else if(temp >= 95.0f)		//repaired at 20200707
	{
		calc_ph = temper_comp_table1[19][idx];
	}
	else
	{
		calc_ph = temper_comp_table1[idy][idx] + (temper_comp_table1[idy + 1][idx] - temper_comp_table1[idy][idx]) * (temp - idy * 5.0f) / 5.0f;
	}
	return calc_ph;
}

float select_real_ph_nist(float ph, float temp)
{
	float calc_ph = 0.0f;
	float temper_comp_table1[][5]=
	{
		{1.67f,	4.00f,	7.115f,	10.32f,	13.42f},//0
		{1.67f,	4.00f,	7.085f,	10.25f,	13.21f},//5
		{1.67f,	4.00f,	7.06f,	10.18f,	13.01f},//10
		{1.67f,	4.00f,	7.04f,	10.12f,	12.80f},//15
		{1.675f,4.00f,	7.015f,	10.06f,	12.64f},//20
		{1.68f,	4.005f,	7.00f,	10.01f,	12.46f},//25
		{1.68f,	4.015f,	6.985f,	9.97f,	12.30f},//30
		{1.69f,	4.025f,	6.98f,	9.93f,	12.13f},//35
		{1.69f,	4.03f,	6.975f,	9.89f,	11.99f},//40
		{1.70f,	4.045f,	6.975f,	9.86f,	11.84f},//45
		{1.705f,4.06f,	6.97f,	9.83f,	11.71f},//50
		{1.715f,4.075f,	6.97f,	9.83f,	11.57f},//55
		{1.72f,	4.085f, 6.97f, 	9.83f,	11.45f},//60
		{1.73f,	4.10f, 	6.98f, 	9.83f,	11.45f},//65
		{1.74f, 4.13f, 	6.99f,	9.83f,	11.45f},//70
		{1.75f, 4.14f, 	7.01f,	9.83f,	11.45f},//75
		{1.765f,4.16f, 	7.03f,	9.83f,	11.45f},//80
		{1.78f, 4.18f, 	7.05f,	9.83f,	11.45f},//85
		{1.79f,	4.21f, 	7.08f, 	9.83f,	11.45f},//90
		{1.805f,4.23f, 	7.11f, 	9.83f,	11.45f} //95
	};

	float temp_std[] = {1.68f,	4.005f,	7.00f,	10.01f,	12.46f};

	int i, idx = 0, idy = 0;

	float min_diff = (temp_std[0] - ph) * (temp_std[0] - ph);

	for(i = 1; i < 5; i++)
	{
		if((temp_std[i] - ph) * (temp_std[i] - ph) < min_diff)
		{
			min_diff = (temp_std[i] - ph) * (temp_std[i] - ph);
			idx = i;
		}
	}

	for(i = 5; i < 100; i+=5)
	{
		if(temp >= (float)(i - 5) && temp < (float)i)
		{
			idy = i / 5 - 1;
			break;
		}
	}

	if(temp < 0.0f)
	{
		calc_ph = temper_comp_table1[0][idx];
	}
	else if(temp >= 95.0f)
	{
		calc_ph = temper_comp_table1[19][idx];
	}
	else
	{
		calc_ph = temper_comp_table1[idy][idx] + (temper_comp_table1[idy + 1][idx] - temper_comp_table1[idy][idx]) * (temp - idy * 5.0f) / 5.0f;
	}

	return calc_ph;
}


/**
   @brief Calculate pH value

   @return float - pH value
**/
float Wq_CalculatePH(float temp)
{
	float ph;
	uint32_t ui32adcValue;
	float volt;


	cfgInfo_t cfg;
	cfgInfo_get(&cfg);


	if(temp == 0)
		temp = 25;

//	/* Read ADC output value */
/*32b result is sum of 15 measurements at 150Hz, 0.1s total to improve 50/60Hz rejection*/
	SnsMeasure(CHAN0, &ui32adcValue, 15);
#if DEBUG
	printf("ADC code: %X"EOL, ui32adcValue/15);
#endif /*DEBUG*/

//	/* Convert ADC output value to voltage */
	if (ATE_REV >= 0x14)
		volt = (V_ADC_REF_mV*((((float) ui32adcValue)/15.0) - 32768.0)/32768.0);
	else
		volt = (1800*(((float)(ui32adcValue)/15.0)-32768.0)/32768.0);
#if DEBUG
	printf("Probe: %.6f volts"EOL,volt);/*TESTING*/
#endif /*DEBUG*/

	mPHVolt = volt;

 	/* Calculate pH value */
	if(myPhProbe.cal_points < 2) { //use the Nernst equation
		ph = myPhProbe.pH_iso -((volt - TOLERANCE) /
					((PH_CONST * IDEAL_GAS_CONST_R * (temp + K_DEGREES)) /
					 FARADAY_CONST));
		if(myPhProbe.cal_points == 1) { //correct offset
			ph = ph - (myPhProbe.pH_iso -((myPhProbe.cal_V1 - TOLERANCE) /
						      ((PH_CONST * IDEAL_GAS_CONST_R * (temp + K_DEGREES)) /
						       FARADAY_CONST)) - myPhProbe.cal_pH1);
		}
	} else { //Use calibration
//		if(myPhProbe.cal_V1 != myPhProbe.cal_V2)
//		{
//			float k =  (myPhProbe.cal_pH2 - myPhProbe.cal_pH1) /
//				   (myPhProbe.cal_V2 - myPhProbe.cal_V1);
//			ph = k * (volt - myPhProbe.cal_V1 + TOLERANCE) +
//			     myPhProbe.cal_pH1;
//			if(myPhProbe.ph_ATC)
//			{
//				//Compensate for 0.003 pH/'C/pH away from ph 7 error
//				ph = ph + ((ph - 7)*(0.003*(temp - 25)));
//			}
//		} else {
//			printf("Error: pH calibration configuration caused divide by zero"EOL);
//			ph = 0;
//		}


		PH_Cal_t cal[3];
		float k1;
		float k2;

		cal[0].val = cfg.ph_val1 ;
		cal[0].volt= cfg.ph_volt1;
		cal[0].temp= cfg.ph_temp1;

		cal[1].val = cfg.ph_val2 ;
		cal[1].volt= cfg.ph_volt2;
		cal[1].temp= cfg.ph_temp2;

		cal[2].val = cfg.ph_val3 ;
		cal[2].volt= cfg.ph_volt3;
		cal[2].temp= cfg.ph_temp3;


		if(cfg.phNistMode == 0)
		{
			cal[0].val = select_real_ph_nist(cal[0].val , cal[0].temp);
			cal[1].val = select_real_ph_nist(cal[1].val , cal[1].temp);
			cal[2].val = select_real_ph_nist(cal[2].val , cal[2].temp);
		}
		else if(cfg.phNistMode == 1)
		{
			//国内常用
			cal[0].val = select_real_ph_tech(cal[0].val , cal[0].temp);
			cal[1].val = select_real_ph_tech(cal[1].val , cal[1].temp);
			cal[2].val = select_real_ph_tech(cal[2].val , cal[2].temp);
		}

		float temp_zero;
		if(cfg.phCalMode == 2)
		{
			bubble_sort(  cal,2);

			k1 = (cal[1].val - cal[0].val) / (cal[1].volt - cal[0].volt);
			ph = k1 * (volt - cal[0].volt + TOLERANCE) + cal[0].val  ;

			temp_zero = cal[0].temp;
		}
		else if(cfg.phCalMode == 3)
		{
			bubble_sort(  cal,3);

			k1 = (cal[2].val - cal[1].val) / (cal[2].volt - cal[1].volt);
			k2 = (cal[0].val - cal[1].val) / (cal[0].volt - cal[1].volt);

			if(volt > cal[1].volt )
			{
				ph = k1 * (volt - cal[1].volt + TOLERANCE) + cal[1].val  ;
			}
			else
			{
				ph = k2 * (volt - cal[1].volt + TOLERANCE) + cal[1].val;
			}

			temp_zero = cal[1].temp;
		}
        
        
        
        //Compensate for 0.003 pH/'C/pH away from ph 7 error
        ph = ph + ((ph - 7)*(0.003*( temp_zero - temp)));
        

	}

	ph += cfg.phOffset;
	mPH = ph;

	return ph;
}

/**
 * @brief change sensor type: PH , conductivity , ORP
 *
 */
void ChangeDevType(uint8_t dev_type)
{
	if (dev_type == DEV_TYPE_PH) {
		pSnsCfg0->Sensor_Type = pH;
		pSnsCfg0->Enable = SENSOR_CHANNEL_ENABLE;
		pSnsCfg0->Sensor_Status = Unknown;
		pSnsCfg0->StartingHpRtiaSeIndex = 8; //1Meg
		pSnsCfg0->StartingGnPgaIndex = 0; //1
		if(flagHiZMode) { /* Set default EIS freq range */
			pSnsCfg0->minFreq = MIN_PH_HZ_FREQ;
			pSnsCfg0->maxFreq = MAX_PH_HZ_FREQ;
		} else {
			pSnsCfg0->minFreq = MIN_PH_INT_FREQ;
			pSnsCfg0->maxFreq = MAX_PH_INT_FREQ;
		}

	} else if (dev_type == DEV_TYPE_COND) {
		pSnsCfg0->Sensor_Type = Conductivity;
		pSnsCfg0->Enable = SENSOR_CHANNEL_ENABLE;
		pSnsCfg0->Sensor_Status = Unknown;
		pSnsCfg0->StartingHpRtiaSeIndex = 6; //80k
		pSnsCfg0->StartingGnPgaIndex = 0; //1
		if(flagHiZMode) { /* Set default EIS freq range */
			pSnsCfg0->minFreq = MIN_COND_HZ_FREQ;
			pSnsCfg0->maxFreq = MAX_COND_HZ_FREQ;
		} else {
			pSnsCfg0->minFreq = MIN_COND_INT_FREQ;
			pSnsCfg0->maxFreq = MAX_COND_INT_FREQ;
		}

	} else if (dev_type == DEV_TYPE_ORP) {
		pSnsCfg0->Sensor_Type = ORP;
		pSnsCfg0->Enable = SENSOR_CHANNEL_ENABLE;
		pSnsCfg0->Sensor_Status = Unknown;
		pSnsCfg0->StartingHpRtiaSeIndex = 6; //80k
		pSnsCfg0->StartingGnPgaIndex = 0; //1
		pSnsCfg0->minFreq = MIN_FREQ_DEFAULT;
		pSnsCfg0->maxFreq = MAX_FREQ_DEFAULT;
	}
}

/**
 * @brief change sensor type: PH , conductivity , ORP
 *
 */
void ChangeSnsType(uint8_t *args)
{
	uint8_t	*p = args;
	char	arg[17];

	/* Check if this function gets an argument */
	while (*(p = Wq_FindArgv(p)) != '\0')
		/* Save channel parameter */
		Wq_GetArgv(arg, p);

	/*DEFAULT CONFIGURATION*/
	if (strncmp(arg, "ph", 3) == 0) {
		pSnsCfg0->Sensor_Type = pH;
		pSnsCfg0->Enable = SENSOR_CHANNEL_ENABLE;
		pSnsCfg0->Sensor_Status = Unknown;
		pSnsCfg0->StartingHpRtiaSeIndex = 8; //1Meg
		pSnsCfg0->StartingGnPgaIndex = 0; //1
		if(flagHiZMode) { /* Set default EIS freq range */
			pSnsCfg0->minFreq = MIN_PH_HZ_FREQ;
			pSnsCfg0->maxFreq = MAX_PH_HZ_FREQ;
		} else {
			pSnsCfg0->minFreq = MIN_PH_INT_FREQ;
			pSnsCfg0->maxFreq = MAX_PH_INT_FREQ;
		}
		printf("Sensor changed to pH."EOL);
	} else if (strncmp(arg, "conductivity", 13) == 0) {
		pSnsCfg0->Sensor_Type = Conductivity;
		pSnsCfg0->Enable = SENSOR_CHANNEL_ENABLE;
		pSnsCfg0->Sensor_Status = Unknown;
		pSnsCfg0->StartingHpRtiaSeIndex = 6; //80k
		pSnsCfg0->StartingGnPgaIndex = 0; //1
		if(flagHiZMode) { /* Set default EIS freq range */
			pSnsCfg0->minFreq = MIN_COND_HZ_FREQ;
			pSnsCfg0->maxFreq = MAX_COND_HZ_FREQ;
		} else {
			pSnsCfg0->minFreq = MIN_COND_INT_FREQ;
			pSnsCfg0->maxFreq = MAX_COND_INT_FREQ;
		}
		printf("Sensor changed to conductivity."EOL);
	} else if (strncmp(arg, "orp", 4) == 0) {
		pSnsCfg0->Sensor_Type = ORP;
		pSnsCfg0->Enable = SENSOR_CHANNEL_ENABLE;
		pSnsCfg0->Sensor_Status = Unknown;
		pSnsCfg0->StartingHpRtiaSeIndex = 6; //80k
		pSnsCfg0->StartingGnPgaIndex = 0; //1
		pSnsCfg0->minFreq = MIN_FREQ_DEFAULT;
		pSnsCfg0->maxFreq = MAX_FREQ_DEFAULT;
		printf("Sensor changed to ORP."EOL);
	} else {
		printf("Error: Sensor Type not recognized."EOL);
	}
}

void MeasureParameter(uint8_t *args) /*pH, conductivity, ORP*/
{
	float ph = 0;
	float millivolt;
	float conductivity;
	float var1, var2;
	uint8_t i,icond, imin, iminfound, imax;
	uint32_t ui32adcValue;

	cfgInfo_t cfgInfo;
	cfgInfo_get(&cfgInfo);

	myEcProbe.cond_meas_freq = cfgInfo.condExcitFreq;
	myEcProbe.cell_constant = cfgInfo.condCellConstant;

//	if (pSnsCfg1->Enable == SENSOR_CHANNEL_ENABLE) {
//		//Measure Temperature
//		temp = Wq_CalculateTemp();
//		printf("Temperature: %.3f"EOL, temp);
//	} else {
//		temp = 25;
//	}

	if (pSnsCfg0->Sensor_Type == pH) {
		//Measure pH
		ph = Wq_CalculatePH(temp);
		printf("pH: %.4f"EOL,ph);
	} else if (pSnsCfg0->Sensor_Type == Conductivity) {
		//Measure Conductivity
		if(CondResultArrSize == 1)
			CondResult[0].freq = myEcProbe.cond_meas_freq;

		SnsACInit(CHAN0);
		SnsACTest(CHAN0, CondResult, CondResultArrSize);
		SnsMagPhaseCal(CondResult, CondResultArrSize); //calculate impedance
		
		//Determine actual limits of conductivity measurement
		imin = 0;
		iminfound = 0;
		for(i=0; i<=CondResultArrSize-1; i++) {
			if(CondResult[i].freq > pSnsCfg0->minFreq && !iminfound) {
				iminfound = 1;
				imin = i;				
			}
			if(CondResult[i].freq < pSnsCfg0->maxFreq)
				imax = i;
		}
		
		//Determine value at minimum delta = solution resistance (conductivity)
		if((imax - imin) >= 3) {
			icond = imin; //index at minimum delta
			var2 = fabs(CondResult[imin+1].Mag - CondResult[imin].Mag); //minimum delta
			for(i=imin; i<imax; i++) {
				var1 = fabs(CondResult[i+1].Mag - CondResult[i].Mag);
				if(var1 < var2) {
					var2 = var1;
					icond = i;
				}
			}
			i = icond;
		} else {
			i = imin;
		}
		//Calculate value
		conductivity = fabs((myEcProbe.cell_constant / CondResult[i].Mag) -
				    (myEcProbe.cal_cond_measured - myEcProbe.cal_cond_actual));

		conductivity *= 1000;

		mConductivity = conductivity*1000;			//unit: uS/cm
        mResistivity = 1/conductivity/1000;	//unit : ohm.M   //CondResult[i].Mag;

        mResistivity += cfgInfo.condResOffset;
        mResistivity *=  (100 / (100 + cfgInfo.condTempCoef * (mTemperature - 25)));
        mConductivity = 1/mResistivity;

		//Print value
		printf("Conductivity(S/cm): %.4e"EOL, conductivity);
#if DEBUG
		printf("Measured at(Hz): %.2f"EOL,CondResult[i].freq);/*TESTING*/
		printf("Impedance Results for the conductivity measurement:"EOL);
		printf("Freq, Mag, measured Rcal, ideal Rcal, Rtia"EOL);
		for(i=0; i<CondResultArrSize; i++) {
			if(flagHiZMode)
				var1 = 10000000;
			else if(CondResult[i].iRtia == 8)
				var1 = 1000000;
			else
				var1 = hprtiase_ohm[CondResult[i].iRtia];
			printf("%.2f, %.3f, %.3f, %d, %d"EOL, CondResult[i].freq,CondResult[i].Mag,
			       CondResult[i].DFT_Mag[2],uiValRcal[CondResult[i].iRcal],(int)var1);
		}
#endif /*DEBUG*/
		/* Adjust defaults */
		pSnsCfg0->StartingHpRtiaSeIndex = CondResult[imax].iRtia;
		pSnsCfg0->StartingGnPgaIndex = CondResult[imax].iGpga;
	} else if (pSnsCfg0->Sensor_Type == ORP) {
		//Measure ORP
		/* Read ADC output value */
			/*32b result is sum of 15 measurements at 150Hz, 0.1s total to improve 50/60Hz rejection*/
		SnsMeasure(CHAN0, &ui32adcValue, 15);
#if DEBUG
		printf("ADC code: %X"EOL, ui32adcValue/15);
#endif /*DEBUG*/

		/* Convert ADC output value to voltage */
		if (ATE_REV >= 0x14)
			millivolt = (V_ADC_REF_mV*((((float) ui32adcValue)/15.0) - 32768.0)/32768.0);
		else
			millivolt = (1800*(((float)(ui32adcValue)/15.0)-32768.0)/32768.0);

		printf("ORP(mV): %.3f"EOL,millivolt);

		millivolt += cfgInfo.orpOffset;

		mORP = millivolt;
	}

}

void MeasureEIS(uint8_t *args)
{
	iSnsStatus tmpStat;
	uint16_t validResults = 0;
	uint8_t bode = 0;
	uint8_t highestValidInd;
	uint8_t	*p = args;
	char	arg[17];

	/* Check if this function gets an argument */
	while (*(p = Wq_FindArgv(p)) != '\0')
		/* Save channel parameter */
		Wq_GetArgv(arg, p);

	/*DEFAULT CONFIGURATION*/
	if (strncmp(arg, "bode", 5) == 0) 
		bode = 1;

	if (pSnsCfg1->Enable == SENSOR_CHANNEL_ENABLE) {
		//Measure Temperature
		temp = Wq_CalculateTemp();
		//Else allow user to enter a temp from an external sensor? Or take in as arg?
		printf("Temperature: %.3f"EOL, temp);
	} else {
		temp = 25;
	}

	printf("Starting EIS Measurement. This will take about 30 seconds."EOL);
	SnsACInit(CHAN0);
	SnsACTest(CHAN0, EISResult, EISResultArrSize);
	SnsMagPhaseCal(EISResult, EISResultArrSize);   //calculate impedance
	
	/*power off high power exitation loop if required*/
	AfeAdcIntCfg(NOINT); //disable all ADC interrupts
	NVIC_DisableIRQ(AFE_ADC_IRQn);
	AfeWaveGenGo(false);
	AfeHPDacPwrUp(false);
	AfeHpTiaPwrUp(false);

	
	/*print Impedance result*/
	printf("Impedance Result:\r\n");
	if(!bode)
		printf("Frequency,Real,-Imag,RCAL"EOL);
	else
		printf("Frequency,Mag,PhaseDeg,RCAL"EOL);
	for(uint32_t i=0; i<EISResultArrSize; i++) {
		if(EISResult[i].result_valid) {
			if(!bode) {
			//Real, -Imaginary for EIS nyquist plot
				printf("%.4f,%.4f,%.4f,%.4f"EOL, EISResult[i].freq,
				       EISResult[i].DFT_result[0], EISResult[i].DFT_result[1],
				       EISResult[i].DFT_Mag[2]);
			} else {
			//Magnitude, Phase for BODE plot
				printf("%.4f,%.4f,%.4f,%.4f"EOL, EISResult[i].freq,
					EISResult[i].Mag, -EISResult[i].Phase,
					EISResult[i].DFT_Mag[2]);
			}
			validResults++;
		  	highestValidInd = i;
		}
	}
	if(!validResults) {
		printf("Error in MeasureEIS: No valid results."EOL);
		printf("High leakage may be saturating TIA (especially in Hi-Z mode)."EOL);
		printf("Otherwise, check connections and switches and try again."EOL);
	} else {
		/* Adjust defaults for next run*/
		pSnsCfg0->StartingHpRtiaSeIndex = EISResult[highestValidInd].iRtia;
		pSnsCfg0->StartingGnPgaIndex = EISResult[highestValidInd].iGpga;
	}

	//Set sensor health
	/* NOTE: This is an example. Implement sensor health algorithm here. */
	tmpStat = Normal;
	if (pSnsCfg0->Sensor_Type == pH) {
		for(uint32_t i=0; i<EISResultArrSize; i++) {
			if(!EISResult[i].result_valid) {
			} else if(EISResult[i].DFT_result[1] > 100000000) {
				tmpStat = Dry;
			} else if(EISResult[i].freq < 10 && EISResult[i].Mag < 1000) {
				tmpStat = Broken;
			}
		}
	} else if (pSnsCfg0->Sensor_Type == Conductivity) {
		for(uint32_t i=0; i<EISResultArrSize; i++) {
			if(EISResult[i].DFT_result[1] > 10000000)
				tmpStat = Dry;
		}
	}
	pSnsCfg0->Sensor_Status = tmpStat;
}

void PrintSnsHealth(uint8_t *args)
{
	printf("Sensor status is %s"EOL,szSnsStatus[pSnsCfg0->Sensor_Status]);
	printf("NOTE: THIS IS JUST AN EXAMPLE. IMPLEMENT CUSTOM ALGORITHM."EOL);
}

void PrintTemp(uint8_t *args)
{
	if (pSnsCfg1->Enable == SENSOR_CHANNEL_ENABLE)
		//Print temperature value without measuring
		printf("Temperature: %.3f[˚C]"EOL, temp);
}

void PrintConfig(uint8_t *args)
{
	printf("Current Configuration"EOL);
	printf("  Name: %s"EOL, pSnsCfg0->SensorName);
	printf("  Sensor Type: %s"EOL, szSnsType[pSnsCfg0->Sensor_Type]);
	printf("  EIS Frequency Range: %.2f - %.1f"EOL, pSnsCfg0->minFreq, pSnsCfg0->maxFreq);
	if (flagHiZMode)
		printf("  Hi-Z Mode: Enabled"EOL);
	else
		printf("  Hi-Z Mode: Disabled"EOL);

	if (pSnsCfg1->Enable == SENSOR_CHANNEL_ENABLE) {
		printf("  Temperature: Enabled"EOL);
		printf("    Temp Sensor Type: %s"EOL, szTempSnsType[pSnsCfg1->Sensor_Type]);
	} else {
		printf("  Temperature: Disabled"EOL);
	}
}

void EnableTemp(uint8_t *args)
{
	uint8_t  *p = args;
	char     arg[17];

	/* Check if this function gets an argument */
	while (*(p = Wq_FindArgv(p)) != '\0') {
		/* Save channel parameter */
		Wq_GetArgv(arg, p);
	}

	/*DEFAULT CONFIGURATION*/
	if (strncmp(arg, "1", 2) == 0) {
		pSnsCfg1->Enable = SENSOR_CHANNEL_ENABLE;
		SnsInit(pSnsCfg1);
		printf("Temperature Sensor Enabled"EOL);
	} else if (strncmp(arg, "0", 2) == 0) {
		pSnsCfg1->Enable = 0;
		printf("Temperature Sensor Disabled"EOL);
	}
}
void HiZModeSet(uint8_t hiz_en)
{
	if (hiz_en == 1) {
		flagHiZMode = 1;
		pSnsCfg0->StartingGnPgaIndex = 0;
		if(pSnsCfg0->Sensor_Type == pH) { /* Set default EIS freq range */
			pSnsCfg0->minFreq = MIN_PH_HZ_FREQ;
			pSnsCfg0->maxFreq = MAX_PH_HZ_FREQ;
		} else if(pSnsCfg0->Sensor_Type == Conductivity) {
			pSnsCfg0->minFreq = MIN_COND_HZ_FREQ;
			pSnsCfg0->maxFreq = MAX_COND_HZ_FREQ;
		} else {
			pSnsCfg0->minFreq = MIN_FREQ_DEFAULT;
			pSnsCfg0->maxFreq = MAX_FREQ_DEFAULT;
		}

	} else if (hiz_en == 0) {
		flagHiZMode = 0;
		if(pSnsCfg0->Sensor_Type == pH) { /* Set default EIS freq range */
			pSnsCfg0->minFreq = MIN_PH_INT_FREQ;
			pSnsCfg0->maxFreq = MAX_PH_INT_FREQ;
		} else if(pSnsCfg0->Sensor_Type == Conductivity) {
			pSnsCfg0->minFreq = MIN_COND_INT_FREQ;
			pSnsCfg0->maxFreq = MAX_COND_INT_FREQ;
		} else {
			pSnsCfg0->minFreq = MIN_FREQ_DEFAULT;
			pSnsCfg0->maxFreq = MAX_FREQ_DEFAULT;
		}

	}
}
void EnableHiZMode(uint8_t *args)
{
	uint8_t  *p = args;
	char     arg[17];

	/* Check if this function gets an argument */
	while (*(p = Wq_FindArgv(p)) != '\0') {
		/* Save channel parameter */
		Wq_GetArgv(arg, p);
	}

	/*DEFAULT CONFIGURATION*/
	if (strncmp(arg, "1", 2) == 0) {
		flagHiZMode = 1;
		pSnsCfg0->StartingGnPgaIndex = 0;
		if(pSnsCfg0->Sensor_Type == pH) { /* Set default EIS freq range */
			pSnsCfg0->minFreq = MIN_PH_HZ_FREQ;
			pSnsCfg0->maxFreq = MAX_PH_HZ_FREQ;
		} else if(pSnsCfg0->Sensor_Type == Conductivity) {
			pSnsCfg0->minFreq = MIN_COND_HZ_FREQ;
			pSnsCfg0->maxFreq = MAX_COND_HZ_FREQ;
		} else {
			pSnsCfg0->minFreq = MIN_FREQ_DEFAULT;
			pSnsCfg0->maxFreq = MAX_FREQ_DEFAULT;
		}
		printf("Hi-Z Mode Enabled. Ensure S2 is set to Hi-Z!"EOL);
	} else if (strncmp(arg, "0", 2) == 0) {
		flagHiZMode = 0;
		if(pSnsCfg0->Sensor_Type == pH) { /* Set default EIS freq range */
			pSnsCfg0->minFreq = MIN_PH_INT_FREQ;
			pSnsCfg0->maxFreq = MAX_PH_INT_FREQ;
		} else if(pSnsCfg0->Sensor_Type == Conductivity) {
			pSnsCfg0->minFreq = MIN_COND_INT_FREQ;
			pSnsCfg0->maxFreq = MAX_COND_INT_FREQ;
		} else {
			pSnsCfg0->minFreq = MIN_FREQ_DEFAULT;
			pSnsCfg0->maxFreq = MAX_FREQ_DEFAULT;
		}
		printf("Hi-Z Mode Disabled. Ensure S2 is set to INT!"EOL);
	}
}

void SetMinEISFreq(uint8_t *args)
{
	uint8_t  *p = args;
	char     arg[17];
	float    freq;

	/* Check if this function gets an argument */
	while (*(p = Wq_FindArgv(p)) != '\0') {
		/* Save channel parameter */
		Wq_GetArgv(arg, p);
	}

	/*Check Arguments and Set Min Frequency*/
	if (strncmp(arg, "full", 5) == 0) {
		pSnsCfg0->minFreq = 0.1;
		printf("Min EIS Frequency set to 0.1 Hz"EOL);
	} else {
		freq = strtof(arg,NULL);
		if(freq > 0 && freq < pSnsCfg0->maxFreq){
			pSnsCfg0->minFreq = freq;
			printf("Min EIS Frequency set to %.2f Hz"EOL,freq);
		} else {
			printf("Argument not recognized. Min EIS Frequency not set."EOL);
		}
	}
}

void SetMaxEISFreq(uint8_t *args)
{
	uint8_t  *p = args;
	char     arg[17];
	float    freq;

	/* Check if this function gets an argument */
	while (*(p = Wq_FindArgv(p)) != '\0') {
		/* Save channel parameter */
		Wq_GetArgv(arg, p);
	}

	/*Check Arguments and Set Max Frequency*/
	if (strncmp(arg, "full", 5) == 0) {
		pSnsCfg0->maxFreq = 200000;
		printf("Max EIS Frequency set to 200000 Hz"EOL);
	} else {
		freq = strtof(arg,NULL);
		if(freq > pSnsCfg0->minFreq && freq < 200000){
			pSnsCfg0->maxFreq = freq;
			printf("Max EIS Frequency set to %.2f Hz"EOL,freq);
		} else {
			printf("Argument not recognized. Max EIS Frequency not set."EOL);
		}
	}
}

void RenameSns(uint8_t *args)
{
	uint8_t  *p = args;
	char     arg[16];

	/* Check if this function gets an argument */
	while (*(p = Wq_FindArgv(p)) != '\0') {
		/* Save channel parameter */
		Wq_GetArgv(arg, p);
	}

	/*DEFAULT CONFIGURATION*/
	if (strlen((char *)arg) > 3) {
		strcpy(pSnsCfg0->SensorName,arg);
		printf("New name is %s"EOL,pSnsCfg0->SensorName);
	} else {
		printf("Please try again with a name that is 4 to 15 characters long."EOL);
	}
}

void PrintSerialNum(uint8_t *args)
{
	printf("%X%X%X%X"EOL, *BOARD_ID_PTR, *(BOARD_ID_PTR + 4), *(BOARD_ID_PTR + 8),
	       *(BOARD_ID_PTR + 12));
}

void SetI2CAddr(uint8_t newaddr)
{
#ifdef I2Ccomms
	if((DioRd(pADI_GPIO0)&PIN3) == 0) {
	/* CS is low, this device is selected for address change */
		NVIC_DisableIRQ(I2C_SLV_EVT_IRQn);
		pADI_I2C0->SCTL &= ~(0x1); //Clear I2C_SCTL[0] to disable the slave
		pADI_I2C0->SHCTL |= 0x1; //resets start/stop detection circuits of I2C block
		I2CInit(newaddr); //re-enables the slave and the interrupt
	}
#endif /*I2Ccomms*/
}

//==============================================================================
//                          Communications Int Handlers
//==============================================================================
/*Derived from M355_UART.c*/
#if DEBUG
void UART_Int_Handler()
{
#ifdef UARTcomms
	int i = 0;

	ucCOMSTA0 = UrtLinSta(pADI_UART0);
	ucCOMIID0 = UrtIntSta(pADI_UART0);
	if ((ucCOMIID0 & 0xE) == 0x2)          // Transmit buffer empty
		ucTxBufferEmpty = 1;

	if ((ucCOMIID0 & 0xE) == 0x4) {	          // Receive byte
		ucNumRxIrqs++;
		iNumBytesInFifo = pADI_UART0->COMRFC;    // read the Num of bytes in FIFO
		for (i=0; i<iNumBytesInFifo; i++) {
			ucComRx = UrtRx(pADI_UART0);
			szInSring[ucRxCnt++]= ucComRx;
		}
		if (ucRxCnt >= 64) { //Prevent buffer overflow
			ucRxCnt = 0;
			ucPacketReceived = 1;
		} else if (szInSring[ucRxCnt - 1] == _CR) { //check for carriage return
			szInSring[ucRxCnt - 1] = '\0'; // end of string indicator
			ucRxCnt = 0;
			ucPacketReceived = 1;
		}
	}

	if ((ucCOMIID0 & 0xE) == 0xC) {	          // UART Time-out condition
		ucNumToIrqs++;
		iNumBytesInFifo = pADI_UART0->COMRFC;    // read the Num of bytes in FIFO
		for (i=0; i<iNumBytesInFifo; i++) {
			ucComRx = UrtRx(pADI_UART0);
			szInSring[ucRxCnt++]= ucComRx;
		}
		if (ucRxCnt >= 64) {
			ucRxCnt = 0;
			ucPacketReceived = 1;
		} else if (szInSring[ucRxCnt - 1] == _CR) {  //check for carriage return
			szInSring[ucRxCnt - 1] = '\0'; // end of string indicator
			ucRxCnt = 0;
			ucPacketReceived = 1;
		}
	}

#endif /*UARTcomms*/
}
#endif

/*Derived from M355_I2C_Slave.c*/
void I2C0_Slave_Int_Handler()
{
#ifdef I2Ccomms
	SLAVE_STATUS slave_status = READY;
	unsigned int I2CSSTATUS = 0;
	uint8_t newaddr = 0;

	I2CSSTATUS = I2cSta(pADI_I2C0,SLAVE);
	if ((I2CSSTATUS & 0x8) == 0x8) {	//If I2C Master Write Request IRQ
		if(ucRxCnt == 0) {
			*mastercmd = I2cRx(pADI_I2C0,SLAVE);	//first byte is the command
			ucRxCnt++;
		} else {	//Read byte data from master
			szInSring[ucRxCnt++] = I2cRx(pADI_I2C0,SLAVE);	// Read byte from master
			if (ucRxCnt >=64) {	//Check for an overflow of the buffer
				ucRxCnt = 0;	//reset and wait for new command
				ucPacketReceived = 1;
			} else if(*mastercmd == GET_STATUS || *mastercmd == BYTES_TO_READ
				  || *mastercmd == 0x62) { //No Arg. Take data byte from FIFO and wait for read.
				ucRxCnt = 0;     //reset for new command
			} else if(*mastercmd == SET_I2C_ADDRESS || *mastercmd == 0x60) {
				newaddr = szInSring[ucRxCnt - 1]; //Read the address
				SetI2CAddr(newaddr); //Function to set new address if SS is low
				tempbyte = newaddr; //load address back into FIFO to echo
				ucRxCnt = 0; //reset and wait for new command
			} else if (szInSring[ucRxCnt - 1] == _CR) { //check for carriage return
				szInSring[ucRxCnt - 1] = '\0';  // end of string indicator for string parsing
				ucRxCnt = 0; //reset for new command
				ucPacketReceived = 1;
			}
		}
	}

	if ((I2CSSTATUS & 0x4) == 0x4) {  // If I2C Master Read Request IRQ
		if (*mastercmd == GET_STATUS) {
			pADI_I2C0->STX = slave_status;
		} else if(*mastercmd == BYTES_TO_READ) {
		//account for bytes that were in the FIFO at the end of last read
			uiPrevBytes = tempbyte;
			nbytes = (pTxWrite - pTxSend) + uiPrevBytes;  //how many bytes we have to send
			if (nbytes < 0)
				nbytes = nbytes + BUF_SIZE;
			if (nbytes > 255)
				nbytes = 255; //>255 byte transaction would require 2 byte response
			pADI_I2C0->STX = (uint8_t) nbytes;
		} else if (*mastercmd == 0x62) { //Define debug byte to send to master
			pADI_I2C0->STX = pADI_I2C0->ID0; //Read address
		} else { //write next character to master
			if ((pADI_I2C0->STAT & BITM_I2C_STAT_STXF) != 0x2
			    && nbytes > 0) { //FIFO not full
				if(uiPrevBytes > 0) {
					I2cTx(pADI_I2C0,SLAVE,ucPrevBytesArr[2-uiPrevBytes]);// Load Tx FIFO
					ucPrevBytesArr[2-uiPrevBytes] = '\0';
					uiPrevBytes--;
				} else if(pTxSend != pTxWrite) { //characters to send
					I2cTx(pADI_I2C0,SLAVE,*pTxSend++);// Load Tx FIFO
					if((pTxSend - szTemp) < 3)
						*(pTxSend + BUF_SIZE - 3) = '\0';
					else
						*(pTxSend - 3) =
							'\0'; //Save previous two characters in case we need to flush fifo

					if ((pTxSend - szTemp) >= BUF_SIZE)  // Check for an overflow of the buffer
						pTxSend = szTemp;  //Roll pointer back
				} else {
					I2cTx(pADI_I2C0,SLAVE,'+');//No characters to send (+ is for debug purposes)
				}
				nbytes--;
			}//Otherwise, FIFO is full so don't write to it.
		}
	}

	if ((I2CSSTATUS & 0x2) == 0x2) {            // Slave Transmit underflow
		//handle the same as master read request
		if (*mastercmd == GET_STATUS) {
			pADI_I2C0->STX = slave_status;
		} else if (*mastercmd == BYTES_TO_READ) {
			uiPrevBytes =
				tempbyte;   //account for bytes that were in the FIFO at the end of last read
			nbytes = (pTxWrite - pTxSend) + uiPrevBytes;  //how many bytes we have to send
			if (nbytes < 0)
				nbytes = nbytes + BUF_SIZE;
			if (nbytes > 255)
				nbytes = 255;  //>255 byte transaction would require 2 byte response
			pADI_I2C0->STX = (uint8_t) nbytes;
		} else if (*mastercmd == 0x62) { //Command for debug purposes
			pADI_I2C0->STX = pADI_I2C0->ID0; //Read address
		} else { //write next character to master
			if ((pADI_I2C0->STAT & BITM_I2C_STAT_STXF) != 0x2
			    && nbytes > 0) { //FIFO not full
				if (uiPrevBytes > 0) {
					I2cTx(pADI_I2C0,SLAVE,ucPrevBytesArr[2-uiPrevBytes]);// Load Tx FIFO
					ucPrevBytesArr[2-uiPrevBytes] = '\0';
					uiPrevBytes--;
				} else if (pTxSend != pTxWrite) { //characters to send
					I2cTx(pADI_I2C0,SLAVE,*pTxSend++);// Load Tx FIFO
					if ((pTxSend - szTemp) < 3)
						*(pTxSend + BUF_SIZE - 3) = '\0';
					else
						*(pTxSend - 3) =
							'\0'; //Save previous two characters in case we need to flush fifo

					if ((pTxSend - szTemp) >= BUF_SIZE)  // Check for an overflow of the buffer
						pTxSend = szTemp;  //Roll pointer back
				} else {
					I2cTx(pADI_I2C0,SLAVE,'+');//No characters to send (+ is for debug purposes)
				}
				nbytes--;
			} //Otherwise, FIFO is full so don't write to it.
		}
	}
	// if ((I2CSSTATUS & 0x10) == 0x10){}		// Slave receive overflow
	// if ((I2CSSTATUS & 0x20) == 0x20){}		// If I2C NOACK
	// if ((I2CSSTATUS & 0x80) == 0x80){}		// I2C General Call Interrupt
	if ((I2CSSTATUS & 0x400) ==
	    0x400) { // If I2C Stop after Start condition detected IRQ
		//Decrement write pointer if we already filled the Tx FIFO
		if(*mastercmd == GET_STATUS) {}
		else if (*mastercmd == BYTES_TO_READ) {}
		else if (*mastercmd == 0x62) {}
		else {
			tempbyte = (uint8_t)(pADI_I2C0->STAT &
					     BITM_I2C_STAT_STXF); //number of bytes in Tx FIFO before flush
			ucPrevBytesArr[0] = *(pTxSend - 2);
			ucPrevBytesArr[1] = *(pTxSend - 1);
		}

		I2cFifoFlush(pADI_I2C0,SLAVE,ENABLE);    // Enable flush of Slave FIFOs
		I2cFifoFlush(pADI_I2C0,SLAVE,DISABLE);
		ucRxCnt = 0;
	}
//	if ((I2CSSTATUS & 0x2000) == 0x2000){}       // If I2C Repeated Start detected IRQ

#endif /*I2Ccomms*/
}

