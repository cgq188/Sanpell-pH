/***************************************************************************//**
 *   @file   Main.c
 *   @brief  Implementation of the program's main function.
 *   @author DNechita
********************************************************************************
 * Copyright 2012(c) Analog Devices, Inc.
 *
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *  - Neither the name of Analog Devices, Inc. nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *  - The use of this software may or may not infringe the patent rights
 *    of one or more patent holders.  This license does not release you
 *    from the requirement that you obtain separate licenses from these
 *    patent holders to use this software.
 *  - Use of the software either in source or binary form, must be run
 *    on or directly connected to an Analog Devices Inc. component.
 *
 * THIS SOFTWARE IS PROVIDED BY ANALOG DEVICES "AS IS" AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, NON-INFRINGEMENT,
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL ANALOG DEVICES BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, INTELLECTUAL PROPERTY RIGHTS, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
********************************************************************************
 *   SVN Revision: 499
*******************************************************************************/

/******************************************************************************/
/* Include Files                                                              */
/******************************************************************************/
#include "YRDKRL78G13.h"    // YRDKRX62N definitions.
#include "ST7579.h"		    // ST7579 definitions.
#include "AD7793.h"		    // AD7793 definitions.

/******************************************************************************/
/* Option Bytes                                                               */
/******************************************************************************/
#pragma location = "OPTBYTE"
__root const uint8_t opbyte0 = 0x00U;
#pragma location = "OPTBYTE"
__root const uint8_t opbyte1 = 0xFFU;
#pragma location = "OPTBYTE"
__root const uint8_t opbyte2 = 0xE8U;
#pragma location = "OPTBYTE"
__root const uint8_t opbyte3 = 0x04U;

/******************************************************************************/
/* Security ID                                                                */
/******************************************************************************/
#pragma location = "SECUID"
__root const uint8_t secuid[10] = 
    {0x00U, 0x00U, 0x00U, 0x00U, 0x00U, 0x00U, 0x00U, 0x00U, 0x00U, 0x00U};

/******************************************************************************/
/* Variables Declarations                                                     */
/******************************************************************************/
const unsigned char adiLogo [2 * 19] =
	{ 0xFF, 0xFF, 0xFF, 0x03, 0x03, 0x03, 0x07, 0x07,
	  0x0F, 0x0F, 0x1F, 0x1F, 0x3F, 0x3F, 0x7F, 0x7F,
	  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xC0, 0xC0,
	  0xC0, 0xE0, 0xE0, 0xF0, 0xF0, 0xF8, 0xF8, 0xFC,
	  0xFC, 0xFE, 0xFE, 0xFF, 0xFF, 0xFF };	// ADI Logo.

unsigned long 	value 		= 0;	// value read from the ADC

/***************************************************************************//**
 * @brief Creates a delay of seconds.
 *
 * @param mSeconds - time in miliseconds.
 *
 * @return None.
*******************************************************************************/
void DelayMs(unsigned long mSeconds)
{
    unsigned long time = 0;
    
    R_TAU0_Channel0_Start();
    while(time < mSeconds)
    {
        if(TMIF00 == 1)
        {
            time++;
            TMIF00 = 0;
        }
    }
    R_TAU0_Channel0_Stop();
}

/***************************************************************************//**
 * @brief Main function.
 *
 * @param None.
 *
 * @return None.
*******************************************************************************/
void  main(void)
{
    YRDKRL78G13_Init();
	ST7579_Init();
    ST7579_Image(2,0,adiLogo,19,16);
    ST7579_String(2,21,"ANALOG");
    ST7579_String(3,21,"DEVICES");
    ST7579_String(4,0,"wiki.analog.com");
    DelayMs(2000);
    ST7579_Clear();
    ST7579_Image(0,0,adiLogo,19,16);	
    ST7579_String(0,22,"ST7579 OK");
    /* Reset AD7793 to bring the SPI interface in a known state */
    AD7793_Reset();
	if(AD7793_Init())
	{
		ST7579_String(1,22,"AD7793 OK");
	}
	else
	{
		ST7579_String(1,22,"AD7793 Err");		
	}
	/* AD7793 setup */
    AD7793_SetGain(AD7793_GAIN_1);                // set gain to 1
    AD7793_SetChannel(AD7793_CH_AIN1P_AIN1M);     // use AIN1(+) - AIN1(-) 
    AD7793_SetIntReference(AD7793_REFSEL_INT);    // select internal 1.17V reference
    AD7793_Calibrate(AD7793_MODE_CAL_INT_ZERO,
                     AD7793_CH_AIN1P_AIN1M);      // Internal Zero-Scale Calibration
    /* A 20 samples average is displayed. */
    ST7579_String(3,0,"AVG:");
    value = AD7793_ContinuousReadAvg(20);
	ST7579_HexNumber(3,70,value,4);
    while(1)
	{
        value = AD7793_SingleConversion();
        ST7579_String(5,2,"AIN1(+)-AIN1(-)");
        ST7579_String(4,0,"Data:");
        ST7579_HexNumber(4,75,value,4);
        if(value > 0x800000)
            {
                value -= 0x800000;
                value = ((value * 1170) >> 15);
                ST7579_String(6,10,"+");
            }
            else
            {
                value = 0x800000 - value;
                value = ((value * 1170) >> 15);
                ST7579_String(6,10,"-");
            }
            ST7579_Number(6,55,value,5);
            ST7579_String(6,65,"mV");
        DelayMs(250);   
	}
}
