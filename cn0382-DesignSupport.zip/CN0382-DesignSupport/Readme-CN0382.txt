Analog Devices Inc.
Design Support Package
CN-0382
Rev. 0
7-28-2015


This file is designed to provide you with a brief overview of what is contained within the circuit note design support package.


**********************
*******Overview*******
**********************


CN-0382 Design Support Package contains: 
	
	Link to Circuit Note
	Link to Product Datasheets
	Schematics
	Bill of Materials	
	Gerber Layout Files
	PADS Layout Files
	Assembly Drawings
	Link to LabVIEW Software for Circuit Note	
	Link to Symbols and Footprints
	Link to Technical Support
	Link to Other Resources
	Source Code and Software Guide



**********************
***File Explanation**
**********************


Circuit Note - Copy of the circuit note this design support package was made for.  This file is provided as a HTML and PDF:

	CN0382: http://www.analog.com/CN0382


Product Datasheets - Copy of all ADI component datasheets used in the circuit.  These files are provided as a PDF:

	AD7124-4:	http://www.analog.com/AD7124-4
	AD5421:		http://www.analog.com/AD5421
	AD5700:		http://www.analog.com/AD5700
	ADUM1441:	http://www.analog.com/ADUM1441
	ADP162		http://www.analog.com/ADP162
	ADG5433:	http://www.analog.com/ADG5433
		

Circuit Note Schematic: Provided as a .pdf and .sch file. 

	DEMO-AD7124-DZ-PadsSchematic-RevB.pdf
	DEMO-AD7124-DZ-PadsSchematic-RevB.sch
	

Bill of Material -  A complete list of components used within the circuit.  Details the quantity, value, and manufacturer information.  This file is provided in an Excel format:

	DEMO-AD7124-DZ-BOM-RevB.xls


Assembly Drawing (Top and bottom):

	DEMO-AD7124-DZ-Assembly-RevB.pdf


PADs Layout Files:

	DEMO-AD7124-DZ-PadsLayout-RevB.pcb
	DEMO-AD7124-DZ-PadsLayout-RevB.pdf
 
	
Gerber layout files - Layout files provided in Gerber format within the .zip file:

	DEMO-AD7124-DZ-GRB-RevA.zip



CN0382 Source Code and User Guide (Folder)





Symbols and Footprints for ADI parts:


AD7124-4:
http://www.analog.com/en/design-center/packaging-quality-symbols-footprints/symbols-and-footprints/AD7124-4.html

AD5421:
http://www.analog.com/en/design-center/packaging-quality-symbols-footprints/symbols-and-footprints/AD5421.html
	
AD5700:	
http://www.analog.com/en/design-center/packaging-quality-symbols-footprints/symbols-and-footprints/AD5700.html
	
ADUM1441:	
http://www.analog.com/en/design-center/packaging-quality-symbols-footprints/symbols-and-footprints/ADuM1441.html
	
ADP162:
http://www.analog.com/en/design-center/packaging-quality-symbols-footprints/symbols-and-footprints/ADP162.html
	
ADG5433:	
http://www.analog.com/en/design-center/packaging-quality-symbols-footprints/symbols-and-footprints/ADG5433.html
	


Technical Support -  If you require further technical assistance please contact us by phone, email, or our EngineerZone community.  http://www.analog.com/en/content/technical_support_page/fca.html



**********************
***Other Resources****
**********************


Resources that are not provided by Analog Devices, but could be helpful.


Gerber Viewer:  http://www.graphicode.com, http://www.viewplot.com, http://www.pentalogix.com/


PADs Viewer: http://www.mentor.com/products/pcb-system-design/design-flows/pads/pads-pcb-viewer


Allegro Physical Viewer: http://www.cadence.com/products/pcb/Pages/downloads.aspx



