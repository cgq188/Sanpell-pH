﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PHPCTool
{
    public class ORPCalibValue
    {
        public float Buffer1 { get; set; }
        public float Buffer2 { get; set; }
        public float Buffer3 { get; set; }

        public float Measure1 { get; set; }
        public float Measure2 { get; set; }
        public float Measure3 { get; set; }

        public float[] measure_vals { get; set; }
        public int read_count { get; set; }

        public ORPCalibValue()
        {
            Buffer1 = -177.0f;
            Buffer2 = 0.0f;
            Buffer3 = 177.0f;
            measure_vals = new float[10];
        }

        public void clear_data()
        {
            read_count = 0;
            for (int i = 0; i < 10; i++)
            {
                measure_vals[i] = 0;
            }
        }

        public bool CheckValid()
        {
            for (int i = 1; i < 10; i++)
            {
                if (measure_vals[i] - measure_vals[0] > 0.4f || measure_vals[i] - measure_vals[0] > 0.4f)
                    return false;
            }
            return true;
        }
    }
}
