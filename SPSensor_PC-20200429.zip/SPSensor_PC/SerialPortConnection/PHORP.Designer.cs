﻿namespace SerialPortConnection
{
    partial class PHORP
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupLogWindow = new System.Windows.Forms.GroupBox();
            this.txtReceive = new System.Windows.Forms.RichTextBox();
            this.statusBar = new System.Windows.Forms.StatusStrip();
            this.tsSpNum = new System.Windows.Forms.ToolStripStatusLabel();
            this.tsBaudRate = new System.Windows.Forms.ToolStripStatusLabel();
            this.tsDataBits = new System.Windows.Forms.ToolStripStatusLabel();
            this.tsStopBits = new System.Windows.Forms.ToolStripStatusLabel();
            this.tsParity = new System.Windows.Forms.ToolStripStatusLabel();
            this.groupBoxPortSetting = new System.Windows.Forms.GroupBox();
            this.textDeviceID = new System.Windows.Forms.TextBox();
            this.labelDeviceID = new System.Windows.Forms.Label();
            this.labelLanguage = new System.Windows.Forms.Label();
            this.comboSelectLanguage = new System.Windows.Forms.ComboBox();
            this.cbBaudRate = new System.Windows.Forms.ComboBox();
            this.labelBaud = new System.Windows.Forms.Label();
            this.buttonRefresh = new System.Windows.Forms.Button();
            this.buttonOpen = new System.Windows.Forms.Button();
            this.comboPort = new System.Windows.Forms.ComboBox();
            this.labelSerialPort = new System.Windows.Forms.Label();
            this.groupBoxSettingWindow = new System.Windows.Forms.GroupBox();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.textBaudRate = new System.Windows.Forms.ComboBox();
            this.buttonSettingWriteAll = new System.Windows.Forms.Button();
            this.buttonSettingReadAll = new System.Windows.Forms.Button();
            this.buttonWrite2 = new System.Windows.Forms.Button();
            this.buttonWrite1 = new System.Windows.Forms.Button();
            this.buttonRead2 = new System.Windows.Forms.Button();
            this.buttonRead1 = new System.Windows.Forms.Button();
            this.textSlaveID = new System.Windows.Forms.TextBox();
            this.labelBaudRate = new System.Windows.Forms.Label();
            this.labelSlaveID = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.buttonDeviceWriteAll = new System.Windows.Forms.Button();
            this.buttonDeviceReadAll = new System.Windows.Forms.Button();
            this.buttonWrite7 = new System.Windows.Forms.Button();
            this.buttonRead7 = new System.Windows.Forms.Button();
            this.textProductNumber = new System.Windows.Forms.TextBox();
            this.labelProductNumber = new System.Windows.Forms.Label();
            this.buttonWrite6 = new System.Windows.Forms.Button();
            this.buttonRead6 = new System.Windows.Forms.Button();
            this.textManufactureNumber = new System.Windows.Forms.TextBox();
            this.labelManufactureNumber = new System.Windows.Forms.Label();
            this.buttonWrite5 = new System.Windows.Forms.Button();
            this.buttonWrite4 = new System.Windows.Forms.Button();
            this.buttonRead5 = new System.Windows.Forms.Button();
            this.buttonRead4 = new System.Windows.Forms.Button();
            this.textSerialNumber = new System.Windows.Forms.TextBox();
            this.textFWVersion = new System.Windows.Forms.TextBox();
            this.labelSerialNumber = new System.Windows.Forms.Label();
            this.labelFirmwareVersion = new System.Windows.Forms.Label();
            this.buttonWrite3 = new System.Windows.Forms.Button();
            this.buttonRead3 = new System.Windows.Forms.Button();
            this.textHWVersion = new System.Windows.Forms.TextBox();
            this.labelHardwareVersion = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.txtCalibManualResult = new System.Windows.Forms.TextBox();
            this.btnCalibManualReadResult = new System.Windows.Forms.Button();
            this.btnWriteCalibManualAction = new System.Windows.Forms.Button();
            this.txtBasicSlope = new System.Windows.Forms.TextBox();
            this.btnWriteBasicSlope = new System.Windows.Forms.Button();
            this.txtAcidSlope = new System.Windows.Forms.TextBox();
            this.btnWriteAcidSlope = new System.Windows.Forms.Button();
            this.txtZeroPoint = new System.Windows.Forms.TextBox();
            this.btnWriteZeroPoint = new System.Windows.Forms.Button();
            this.btnWriteCalibManualTime = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.cbxORPActionCode = new System.Windows.Forms.ComboBox();
            this.txtORPResult = new System.Windows.Forms.TextBox();
            this.btnORPCalibResultCode = new System.Windows.Forms.Button();
            this.btnWriteORPActionCode = new System.Windows.Forms.Button();
            this.txtORPPoint3 = new System.Windows.Forms.TextBox();
            this.btnWriteORPPoint3 = new System.Windows.Forms.Button();
            this.txtORPPoint2 = new System.Windows.Forms.TextBox();
            this.btnWriteORPPoint2 = new System.Windows.Forms.Button();
            this.txtORPPoint1 = new System.Windows.Forms.TextBox();
            this.btnWriteORPPoint1 = new System.Windows.Forms.Button();
            this.btnWriteORPCalibTime = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cbxPHActionCode = new System.Windows.Forms.ComboBox();
            this.txtPHResult = new System.Windows.Forms.TextBox();
            this.btnPHReadResult = new System.Windows.Forms.Button();
            this.btnRunPHCalib = new System.Windows.Forms.Button();
            this.txtpH3rdBuffer = new System.Windows.Forms.TextBox();
            this.btnWrite3rdPH = new System.Windows.Forms.Button();
            this.txtpH2ndBuffer = new System.Windows.Forms.TextBox();
            this.btnWrite2ndPH = new System.Windows.Forms.Button();
            this.txtpH1stBuffer = new System.Windows.Forms.TextBox();
            this.btnWrite1stPH = new System.Windows.Forms.Button();
            this.btnPHCalibTime = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblCalibTime = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblCalibType = new System.Windows.Forms.Label();
            this.lblSlope2 = new System.Windows.Forms.Label();
            this.lblSlope1 = new System.Windows.Forms.Label();
            this.lblZeroPoint = new System.Windows.Forms.Label();
            this.btnReadLatestORPCalib = new System.Windows.Forms.Button();
            this.btnReadLatestPHCalib = new System.Windows.Forms.Button();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.txtReadOrpBias = new System.Windows.Forms.Label();
            this.btnReadOrpBias = new System.Windows.Forms.Button();
            this.txtReadTempBias = new System.Windows.Forms.Label();
            this.btnReadTempBias = new System.Windows.Forms.Button();
            this.cbxTempMode = new System.Windows.Forms.ComboBox();
            this.btnWriteTempMode = new System.Windows.Forms.Button();
            this.txtMTCStatus = new System.Windows.Forms.Label();
            this.btnReadMTCStatus = new System.Windows.Forms.Button();
            this.txtReadMTC = new System.Windows.Forms.Label();
            this.btnReadManualTemp = new System.Windows.Forms.Button();
            this.txtWriteMTC = new System.Windows.Forms.TextBox();
            this.btnWriteManualTemp = new System.Windows.Forms.Button();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.txtOrpBias = new System.Windows.Forms.TextBox();
            this.btnFactoryResetCalib = new System.Windows.Forms.Button();
            this.txtTempBias = new System.Windows.Forms.TextBox();
            this.btnWriteTempBias = new System.Windows.Forms.Button();
            this.btnWriteOrpBias = new System.Windows.Forms.Button();
            this.btnFactoryResetSetting = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.txtTempCalibResult = new System.Windows.Forms.TextBox();
            this.btnReadTempCalibResult = new System.Windows.Forms.Button();
            this.btnRunTempCalib = new System.Windows.Forms.Button();
            this.txtResOfPoint2 = new System.Windows.Forms.TextBox();
            this.btnWriteResOfPoint2 = new System.Windows.Forms.Button();
            this.txtResOfPoint1 = new System.Windows.Forms.TextBox();
            this.btnWriteResOfPoint1 = new System.Windows.Forms.Button();
            this.btnWriteTempCalibTime = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtTempCalibTime = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txtTempOffset = new System.Windows.Forms.Label();
            this.txtTempSlope = new System.Windows.Forms.Label();
            this.btnLatestTempCalibration = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.textTemperature = new System.Windows.Forms.Label();
            this.textORP = new System.Windows.Forms.Label();
            this.textPH = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.buttonMoitorStop = new System.Windows.Forms.Button();
            this.buttonMoitorStart = new System.Windows.Forms.Button();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.groupORPCalib = new System.Windows.Forms.GroupBox();
            this.picORPCalibProgress = new System.Windows.Forms.PictureBox();
            this.txtORPMeasure3 = new System.Windows.Forms.Label();
            this.txtORPMeasure2 = new System.Windows.Forms.Label();
            this.txtORPMeasure1 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.btnORPCalibStart = new System.Windows.Forms.Button();
            this.btnORPCalibFinish = new System.Windows.Forms.Button();
            this.btnORPCalibContinue = new System.Windows.Forms.Button();
            this.btnORPCalibBack = new System.Windows.Forms.Button();
            this.txtORPBuffer3 = new System.Windows.Forms.Label();
            this.txtORPBuffer2 = new System.Windows.Forms.Label();
            this.txtORPBuffer1 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.groupPHCalib = new System.Windows.Forms.GroupBox();
            this.picPHCalibProcess = new System.Windows.Forms.PictureBox();
            this.btnPHCalibStart = new System.Windows.Forms.Button();
            this.btnPHCalibFinish = new System.Windows.Forms.Button();
            this.btnPHCalibContinue = new System.Windows.Forms.Button();
            this.btnPHCalibBack = new System.Windows.Forms.Button();
            this.txtPHOfBuffer = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.txtPHCalibTime = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.txtPHCalibTemp = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.txtPHVoltage = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.txtPHOfBuffer3 = new System.Windows.Forms.Label();
            this.txtPHOfBuffer2 = new System.Windows.Forms.Label();
            this.txtPHOfBuffer1 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.comboCalibType = new System.Windows.Forms.ComboBox();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.btnTempCalibRunCalib = new System.Windows.Forms.Button();
            this.btnTempCalibRunP2 = new System.Windows.Forms.Button();
            this.txtTempCalibResMea2 = new System.Windows.Forms.Label();
            this.txtTempCalibResMea1 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.btnTempCalibRunP1 = new System.Windows.Forms.Button();
            this.txtTempCalibRes2 = new System.Windows.Forms.Label();
            this.txtTempCalibRes1 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.timerMornitor = new System.Windows.Forms.Timer(this.components);
            this.timerReadSetting = new System.Windows.Forms.Timer(this.components);
            this.timerWriteSetting = new System.Windows.Forms.Timer(this.components);
            this.timerReadDeviceInfo = new System.Windows.Forms.Timer(this.components);
            this.timerWriteDeviceInfo = new System.Windows.Forms.Timer(this.components);
            this.timerCalib = new System.Windows.Forms.Timer(this.components);
            this.groupLogWindow.SuspendLayout();
            this.statusBar.SuspendLayout();
            this.groupBoxPortSetting.SuspendLayout();
            this.groupBoxSettingWindow.SuspendLayout();
            this.tabControl.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.groupORPCalib.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picORPCalibProgress)).BeginInit();
            this.groupPHCalib.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picPHCalibProcess)).BeginInit();
            this.tabPage7.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupLogWindow
            // 
            this.groupLogWindow.Controls.Add(this.txtReceive);
            this.groupLogWindow.Location = new System.Drawing.Point(16, 490);
            this.groupLogWindow.Margin = new System.Windows.Forms.Padding(4);
            this.groupLogWindow.Name = "groupLogWindow";
            this.groupLogWindow.Padding = new System.Windows.Forms.Padding(4);
            this.groupLogWindow.Size = new System.Drawing.Size(1361, 339);
            this.groupLogWindow.TabIndex = 9;
            this.groupLogWindow.TabStop = false;
            this.groupLogWindow.Text = "Log Window";
            // 
            // txtReceive
            // 
            this.txtReceive.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txtReceive.ForeColor = System.Drawing.Color.Blue;
            this.txtReceive.Location = new System.Drawing.Point(21, 32);
            this.txtReceive.Margin = new System.Windows.Forms.Padding(4);
            this.txtReceive.Name = "txtReceive";
            this.txtReceive.ReadOnly = true;
            this.txtReceive.Size = new System.Drawing.Size(1311, 296);
            this.txtReceive.TabIndex = 0;
            this.txtReceive.Text = "";
            // 
            // statusBar
            // 
            this.statusBar.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusBar.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsSpNum,
            this.tsBaudRate,
            this.tsDataBits,
            this.tsStopBits,
            this.tsParity});
            this.statusBar.Location = new System.Drawing.Point(0, 943);
            this.statusBar.Name = "statusBar";
            this.statusBar.Padding = new System.Windows.Forms.Padding(1, 0, 19, 0);
            this.statusBar.Size = new System.Drawing.Size(1731, 30);
            this.statusBar.TabIndex = 12;
            this.statusBar.Text = "statusStrip1";
            this.statusBar.Visible = false;
            // 
            // tsSpNum
            // 
            this.tsSpNum.Name = "tsSpNum";
            this.tsSpNum.Size = new System.Drawing.Size(118, 25);
            this.tsSpNum.Text = "串口号：未指定|";
            // 
            // tsBaudRate
            // 
            this.tsBaudRate.Name = "tsBaudRate";
            this.tsBaudRate.Size = new System.Drawing.Size(106, 25);
            this.tsBaudRate.Text = "波特率:未指定|";
            // 
            // tsDataBits
            // 
            this.tsDataBits.Name = "tsDataBits";
            this.tsDataBits.Size = new System.Drawing.Size(106, 25);
            this.tsDataBits.Text = "数据位:未指定|";
            // 
            // tsStopBits
            // 
            this.tsStopBits.Name = "tsStopBits";
            this.tsStopBits.Size = new System.Drawing.Size(106, 25);
            this.tsStopBits.Text = "停止位:未指定|";
            // 
            // tsParity
            // 
            this.tsParity.Name = "tsParity";
            this.tsParity.Size = new System.Drawing.Size(106, 25);
            this.tsParity.Text = "停止位:未指定|";
            // 
            // groupBoxPortSetting
            // 
            this.groupBoxPortSetting.Controls.Add(this.textDeviceID);
            this.groupBoxPortSetting.Controls.Add(this.labelDeviceID);
            this.groupBoxPortSetting.Controls.Add(this.labelLanguage);
            this.groupBoxPortSetting.Controls.Add(this.comboSelectLanguage);
            this.groupBoxPortSetting.Controls.Add(this.cbBaudRate);
            this.groupBoxPortSetting.Controls.Add(this.labelBaud);
            this.groupBoxPortSetting.Controls.Add(this.buttonRefresh);
            this.groupBoxPortSetting.Controls.Add(this.buttonOpen);
            this.groupBoxPortSetting.Controls.Add(this.comboPort);
            this.groupBoxPortSetting.Controls.Add(this.labelSerialPort);
            this.groupBoxPortSetting.Location = new System.Drawing.Point(16, 16);
            this.groupBoxPortSetting.Margin = new System.Windows.Forms.Padding(4);
            this.groupBoxPortSetting.Name = "groupBoxPortSetting";
            this.groupBoxPortSetting.Padding = new System.Windows.Forms.Padding(4);
            this.groupBoxPortSetting.Size = new System.Drawing.Size(1361, 90);
            this.groupBoxPortSetting.TabIndex = 13;
            this.groupBoxPortSetting.TabStop = false;
            this.groupBoxPortSetting.Text = "Port Setting";
            // 
            // textDeviceID
            // 
            this.textDeviceID.Location = new System.Drawing.Point(968, 41);
            this.textDeviceID.Margin = new System.Windows.Forms.Padding(4);
            this.textDeviceID.Name = "textDeviceID";
            this.textDeviceID.Size = new System.Drawing.Size(64, 22);
            this.textDeviceID.TabIndex = 29;
            this.textDeviceID.Text = "1";
            this.textDeviceID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textDeviceID.TextChanged += new System.EventHandler(this.textSlaveID_TextChanged);
            // 
            // labelDeviceID
            // 
            this.labelDeviceID.AutoSize = true;
            this.labelDeviceID.Location = new System.Drawing.Point(881, 46);
            this.labelDeviceID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelDeviceID.Name = "labelDeviceID";
            this.labelDeviceID.Size = new System.Drawing.Size(64, 17);
            this.labelDeviceID.TabIndex = 28;
            this.labelDeviceID.Text = "Slave ID:";
            // 
            // labelLanguage
            // 
            this.labelLanguage.AutoSize = true;
            this.labelLanguage.Font = new System.Drawing.Font("SimSun", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labelLanguage.Location = new System.Drawing.Point(1069, 43);
            this.labelLanguage.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelLanguage.Name = "labelLanguage";
            this.labelLanguage.Size = new System.Drawing.Size(98, 18);
            this.labelLanguage.TabIndex = 27;
            this.labelLanguage.Text = "Language :";
            // 
            // comboSelectLanguage
            // 
            this.comboSelectLanguage.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboSelectLanguage.FormattingEnabled = true;
            this.comboSelectLanguage.Items.AddRange(new object[] {
            "English",
            "中文"});
            this.comboSelectLanguage.Location = new System.Drawing.Point(1176, 38);
            this.comboSelectLanguage.Margin = new System.Windows.Forms.Padding(4);
            this.comboSelectLanguage.Name = "comboSelectLanguage";
            this.comboSelectLanguage.Size = new System.Drawing.Size(109, 24);
            this.comboSelectLanguage.TabIndex = 26;
            this.comboSelectLanguage.SelectedIndexChanged += new System.EventHandler(this.comboSelectLanguage_SelectedIndexChanged);
            // 
            // cbBaudRate
            // 
            this.cbBaudRate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbBaudRate.FormattingEnabled = true;
            this.cbBaudRate.Items.AddRange(new object[] {
            "300",
            "600",
            "1200",
            "2400",
            "4800",
            "7200",
            "9600",
            "14400",
            "19200",
            "38400",
            "43000",
            "57600",
            "115200",
            "128000",
            "230400"});
            this.cbBaudRate.Location = new System.Drawing.Point(564, 38);
            this.cbBaudRate.Margin = new System.Windows.Forms.Padding(4);
            this.cbBaudRate.Name = "cbBaudRate";
            this.cbBaudRate.Size = new System.Drawing.Size(123, 24);
            this.cbBaudRate.TabIndex = 25;
            // 
            // labelBaud
            // 
            this.labelBaud.AutoSize = true;
            this.labelBaud.Font = new System.Drawing.Font("SimSun", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labelBaud.Location = new System.Drawing.Point(444, 43);
            this.labelBaud.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelBaud.Name = "labelBaud";
            this.labelBaud.Size = new System.Drawing.Size(107, 18);
            this.labelBaud.TabIndex = 24;
            this.labelBaud.Text = "Baud Rate :";
            // 
            // buttonRefresh
            // 
            this.buttonRefresh.Location = new System.Drawing.Point(321, 36);
            this.buttonRefresh.Margin = new System.Windows.Forms.Padding(4);
            this.buttonRefresh.Name = "buttonRefresh";
            this.buttonRefresh.Size = new System.Drawing.Size(92, 31);
            this.buttonRefresh.TabIndex = 13;
            this.buttonRefresh.Text = "Refresh";
            this.buttonRefresh.UseVisualStyleBackColor = true;
            this.buttonRefresh.Click += new System.EventHandler(this.buttonRefresh_Click);
            // 
            // buttonOpen
            // 
            this.buttonOpen.Location = new System.Drawing.Point(705, 36);
            this.buttonOpen.Margin = new System.Windows.Forms.Padding(4);
            this.buttonOpen.Name = "buttonOpen";
            this.buttonOpen.Size = new System.Drawing.Size(100, 31);
            this.buttonOpen.TabIndex = 12;
            this.buttonOpen.Text = "Open";
            this.buttonOpen.UseVisualStyleBackColor = true;
            this.buttonOpen.Click += new System.EventHandler(this.btnSwitch_Click);
            // 
            // comboPort
            // 
            this.comboPort.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboPort.FormattingEnabled = true;
            this.comboPort.Location = new System.Drawing.Point(176, 38);
            this.comboPort.Margin = new System.Windows.Forms.Padding(4);
            this.comboPort.Name = "comboPort";
            this.comboPort.Size = new System.Drawing.Size(129, 24);
            this.comboPort.TabIndex = 11;
            // 
            // labelSerialPort
            // 
            this.labelSerialPort.AutoSize = true;
            this.labelSerialPort.Font = new System.Drawing.Font("SimSun", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labelSerialPort.Location = new System.Drawing.Point(37, 41);
            this.labelSerialPort.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelSerialPort.Name = "labelSerialPort";
            this.labelSerialPort.Size = new System.Drawing.Size(125, 18);
            this.labelSerialPort.TabIndex = 10;
            this.labelSerialPort.Text = "Serial Port :";
            // 
            // groupBoxSettingWindow
            // 
            this.groupBoxSettingWindow.Controls.Add(this.tabControl);
            this.groupBoxSettingWindow.Location = new System.Drawing.Point(17, 114);
            this.groupBoxSettingWindow.Margin = new System.Windows.Forms.Padding(4);
            this.groupBoxSettingWindow.Name = "groupBoxSettingWindow";
            this.groupBoxSettingWindow.Padding = new System.Windows.Forms.Padding(4);
            this.groupBoxSettingWindow.Size = new System.Drawing.Size(1360, 368);
            this.groupBoxSettingWindow.TabIndex = 14;
            this.groupBoxSettingWindow.TabStop = false;
            this.groupBoxSettingWindow.Text = "Setting Window";
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tabPage1);
            this.tabControl.Controls.Add(this.tabPage2);
            this.tabControl.Controls.Add(this.tabPage4);
            this.tabControl.Controls.Add(this.tabPage5);
            this.tabControl.Controls.Add(this.tabPage3);
            this.tabControl.Controls.Add(this.tabPage6);
            this.tabControl.Controls.Add(this.tabPage7);
            this.tabControl.Location = new System.Drawing.Point(20, 27);
            this.tabControl.Margin = new System.Windows.Forms.Padding(4);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(1317, 318);
            this.tabControl.TabIndex = 0;
            this.tabControl.SelectedIndexChanged += new System.EventHandler(this.tabControl_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.textBaudRate);
            this.tabPage1.Controls.Add(this.buttonSettingWriteAll);
            this.tabPage1.Controls.Add(this.buttonSettingReadAll);
            this.tabPage1.Controls.Add(this.buttonWrite2);
            this.tabPage1.Controls.Add(this.buttonWrite1);
            this.tabPage1.Controls.Add(this.buttonRead2);
            this.tabPage1.Controls.Add(this.buttonRead1);
            this.tabPage1.Controls.Add(this.textSlaveID);
            this.tabPage1.Controls.Add(this.labelBaudRate);
            this.tabPage1.Controls.Add(this.labelSlaveID);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage1.Size = new System.Drawing.Size(1309, 289);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Transmmition Setting";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // textBaudRate
            // 
            this.textBaudRate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.textBaudRate.FormattingEnabled = true;
            this.textBaudRate.Items.AddRange(new object[] {
            "300",
            "600",
            "1200",
            "2400",
            "4800",
            "7200",
            "9600",
            "14400",
            "19200",
            "38400",
            "43000",
            "57600",
            "115200",
            "128000",
            "230400"});
            this.textBaudRate.Location = new System.Drawing.Point(493, 110);
            this.textBaudRate.Margin = new System.Windows.Forms.Padding(4);
            this.textBaudRate.Name = "textBaudRate";
            this.textBaudRate.Size = new System.Drawing.Size(132, 24);
            this.textBaudRate.TabIndex = 26;
            // 
            // buttonSettingWriteAll
            // 
            this.buttonSettingWriteAll.Location = new System.Drawing.Point(661, 181);
            this.buttonSettingWriteAll.Margin = new System.Windows.Forms.Padding(4);
            this.buttonSettingWriteAll.Name = "buttonSettingWriteAll";
            this.buttonSettingWriteAll.Size = new System.Drawing.Size(137, 46);
            this.buttonSettingWriteAll.TabIndex = 9;
            this.buttonSettingWriteAll.Text = "Write All";
            this.buttonSettingWriteAll.UseVisualStyleBackColor = true;
            this.buttonSettingWriteAll.Click += new System.EventHandler(this.buttonSettingWriteAll_Click);
            // 
            // buttonSettingReadAll
            // 
            this.buttonSettingReadAll.Location = new System.Drawing.Point(489, 181);
            this.buttonSettingReadAll.Margin = new System.Windows.Forms.Padding(4);
            this.buttonSettingReadAll.Name = "buttonSettingReadAll";
            this.buttonSettingReadAll.Size = new System.Drawing.Size(137, 46);
            this.buttonSettingReadAll.TabIndex = 8;
            this.buttonSettingReadAll.Text = "Read All";
            this.buttonSettingReadAll.UseVisualStyleBackColor = true;
            this.buttonSettingReadAll.Click += new System.EventHandler(this.buttonSettingReadAll_Click);
            // 
            // buttonWrite2
            // 
            this.buttonWrite2.Location = new System.Drawing.Point(781, 107);
            this.buttonWrite2.Margin = new System.Windows.Forms.Padding(4);
            this.buttonWrite2.Name = "buttonWrite2";
            this.buttonWrite2.Size = new System.Drawing.Size(100, 31);
            this.buttonWrite2.TabIndex = 7;
            this.buttonWrite2.Text = "Write";
            this.buttonWrite2.UseVisualStyleBackColor = true;
            // 
            // buttonWrite1
            // 
            this.buttonWrite1.Location = new System.Drawing.Point(781, 50);
            this.buttonWrite1.Margin = new System.Windows.Forms.Padding(4);
            this.buttonWrite1.Name = "buttonWrite1";
            this.buttonWrite1.Size = new System.Drawing.Size(100, 31);
            this.buttonWrite1.TabIndex = 6;
            this.buttonWrite1.Text = "Write";
            this.buttonWrite1.UseVisualStyleBackColor = true;
            // 
            // buttonRead2
            // 
            this.buttonRead2.Location = new System.Drawing.Point(661, 107);
            this.buttonRead2.Margin = new System.Windows.Forms.Padding(4);
            this.buttonRead2.Name = "buttonRead2";
            this.buttonRead2.Size = new System.Drawing.Size(100, 31);
            this.buttonRead2.TabIndex = 5;
            this.buttonRead2.Text = "Read";
            this.buttonRead2.UseVisualStyleBackColor = true;
            // 
            // buttonRead1
            // 
            this.buttonRead1.Location = new System.Drawing.Point(661, 50);
            this.buttonRead1.Margin = new System.Windows.Forms.Padding(4);
            this.buttonRead1.Name = "buttonRead1";
            this.buttonRead1.Size = new System.Drawing.Size(100, 31);
            this.buttonRead1.TabIndex = 4;
            this.buttonRead1.Text = "Read";
            this.buttonRead1.UseVisualStyleBackColor = true;
            // 
            // textSlaveID
            // 
            this.textSlaveID.Location = new System.Drawing.Point(493, 53);
            this.textSlaveID.Margin = new System.Windows.Forms.Padding(4);
            this.textSlaveID.Name = "textSlaveID";
            this.textSlaveID.Size = new System.Drawing.Size(132, 22);
            this.textSlaveID.TabIndex = 2;
            this.textSlaveID.Text = "1";
            this.textSlaveID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // labelBaudRate
            // 
            this.labelBaudRate.AutoSize = true;
            this.labelBaudRate.Location = new System.Drawing.Point(375, 113);
            this.labelBaudRate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelBaudRate.Name = "labelBaudRate";
            this.labelBaudRate.Size = new System.Drawing.Size(75, 17);
            this.labelBaudRate.TabIndex = 1;
            this.labelBaudRate.Text = "BaudRate:";
            // 
            // labelSlaveID
            // 
            this.labelSlaveID.AutoSize = true;
            this.labelSlaveID.Location = new System.Drawing.Point(375, 58);
            this.labelSlaveID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelSlaveID.Name = "labelSlaveID";
            this.labelSlaveID.Size = new System.Drawing.Size(64, 17);
            this.labelSlaveID.TabIndex = 0;
            this.labelSlaveID.Text = "Slave ID:";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.buttonDeviceWriteAll);
            this.tabPage2.Controls.Add(this.buttonDeviceReadAll);
            this.tabPage2.Controls.Add(this.buttonWrite7);
            this.tabPage2.Controls.Add(this.buttonRead7);
            this.tabPage2.Controls.Add(this.textProductNumber);
            this.tabPage2.Controls.Add(this.labelProductNumber);
            this.tabPage2.Controls.Add(this.buttonWrite6);
            this.tabPage2.Controls.Add(this.buttonRead6);
            this.tabPage2.Controls.Add(this.textManufactureNumber);
            this.tabPage2.Controls.Add(this.labelManufactureNumber);
            this.tabPage2.Controls.Add(this.buttonWrite5);
            this.tabPage2.Controls.Add(this.buttonWrite4);
            this.tabPage2.Controls.Add(this.buttonRead5);
            this.tabPage2.Controls.Add(this.buttonRead4);
            this.tabPage2.Controls.Add(this.textSerialNumber);
            this.tabPage2.Controls.Add(this.textFWVersion);
            this.tabPage2.Controls.Add(this.labelSerialNumber);
            this.tabPage2.Controls.Add(this.labelFirmwareVersion);
            this.tabPage2.Controls.Add(this.buttonWrite3);
            this.tabPage2.Controls.Add(this.buttonRead3);
            this.tabPage2.Controls.Add(this.textHWVersion);
            this.tabPage2.Controls.Add(this.labelHardwareVersion);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage2.Size = new System.Drawing.Size(1309, 289);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Device Information";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // buttonDeviceWriteAll
            // 
            this.buttonDeviceWriteAll.Location = new System.Drawing.Point(637, 202);
            this.buttonDeviceWriteAll.Margin = new System.Windows.Forms.Padding(4);
            this.buttonDeviceWriteAll.Name = "buttonDeviceWriteAll";
            this.buttonDeviceWriteAll.Size = new System.Drawing.Size(137, 46);
            this.buttonDeviceWriteAll.TabIndex = 41;
            this.buttonDeviceWriteAll.Text = "Write All";
            this.buttonDeviceWriteAll.UseVisualStyleBackColor = true;
            this.buttonDeviceWriteAll.Click += new System.EventHandler(this.buttonDeviceWriteAll_Click);
            // 
            // buttonDeviceReadAll
            // 
            this.buttonDeviceReadAll.Location = new System.Drawing.Point(465, 202);
            this.buttonDeviceReadAll.Margin = new System.Windows.Forms.Padding(4);
            this.buttonDeviceReadAll.Name = "buttonDeviceReadAll";
            this.buttonDeviceReadAll.Size = new System.Drawing.Size(137, 46);
            this.buttonDeviceReadAll.TabIndex = 40;
            this.buttonDeviceReadAll.Text = "Read All";
            this.buttonDeviceReadAll.UseVisualStyleBackColor = true;
            this.buttonDeviceReadAll.Click += new System.EventHandler(this.buttonDeviceReadAll_Click);
            // 
            // buttonWrite7
            // 
            this.buttonWrite7.Location = new System.Drawing.Point(1116, 97);
            this.buttonWrite7.Margin = new System.Windows.Forms.Padding(4);
            this.buttonWrite7.Name = "buttonWrite7";
            this.buttonWrite7.Size = new System.Drawing.Size(80, 31);
            this.buttonWrite7.TabIndex = 38;
            this.buttonWrite7.Text = "Write";
            this.buttonWrite7.UseVisualStyleBackColor = true;
            // 
            // buttonRead7
            // 
            this.buttonRead7.Location = new System.Drawing.Point(1028, 97);
            this.buttonRead7.Margin = new System.Windows.Forms.Padding(4);
            this.buttonRead7.Name = "buttonRead7";
            this.buttonRead7.Size = new System.Drawing.Size(80, 31);
            this.buttonRead7.TabIndex = 36;
            this.buttonRead7.Text = "Read";
            this.buttonRead7.UseVisualStyleBackColor = true;
            // 
            // textProductNumber
            // 
            this.textProductNumber.Location = new System.Drawing.Point(811, 100);
            this.textProductNumber.Margin = new System.Windows.Forms.Padding(4);
            this.textProductNumber.Name = "textProductNumber";
            this.textProductNumber.Size = new System.Drawing.Size(208, 22);
            this.textProductNumber.TabIndex = 34;
            this.textProductNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // labelProductNumber
            // 
            this.labelProductNumber.AutoSize = true;
            this.labelProductNumber.Location = new System.Drawing.Point(647, 105);
            this.labelProductNumber.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelProductNumber.Name = "labelProductNumber";
            this.labelProductNumber.Size = new System.Drawing.Size(144, 17);
            this.labelProductNumber.TabIndex = 32;
            this.labelProductNumber.Text = "Measured value type:";
            // 
            // buttonWrite6
            // 
            this.buttonWrite6.Location = new System.Drawing.Point(1116, 47);
            this.buttonWrite6.Margin = new System.Windows.Forms.Padding(4);
            this.buttonWrite6.Name = "buttonWrite6";
            this.buttonWrite6.Size = new System.Drawing.Size(80, 31);
            this.buttonWrite6.TabIndex = 31;
            this.buttonWrite6.Text = "Write";
            this.buttonWrite6.UseVisualStyleBackColor = true;
            // 
            // buttonRead6
            // 
            this.buttonRead6.Location = new System.Drawing.Point(1028, 47);
            this.buttonRead6.Margin = new System.Windows.Forms.Padding(4);
            this.buttonRead6.Name = "buttonRead6";
            this.buttonRead6.Size = new System.Drawing.Size(80, 31);
            this.buttonRead6.TabIndex = 29;
            this.buttonRead6.Text = "Read";
            this.buttonRead6.UseVisualStyleBackColor = true;
            // 
            // textManufactureNumber
            // 
            this.textManufactureNumber.Location = new System.Drawing.Point(811, 49);
            this.textManufactureNumber.Margin = new System.Windows.Forms.Padding(4);
            this.textManufactureNumber.Name = "textManufactureNumber";
            this.textManufactureNumber.Size = new System.Drawing.Size(208, 22);
            this.textManufactureNumber.TabIndex = 27;
            this.textManufactureNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // labelManufactureNumber
            // 
            this.labelManufactureNumber.AutoSize = true;
            this.labelManufactureNumber.Location = new System.Drawing.Point(647, 53);
            this.labelManufactureNumber.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelManufactureNumber.Name = "labelManufactureNumber";
            this.labelManufactureNumber.Size = new System.Drawing.Size(164, 17);
            this.labelManufactureNumber.TabIndex = 25;
            this.labelManufactureNumber.Text = "Sensor software version:";
            // 
            // buttonWrite5
            // 
            this.buttonWrite5.Location = new System.Drawing.Point(519, 146);
            this.buttonWrite5.Margin = new System.Windows.Forms.Padding(4);
            this.buttonWrite5.Name = "buttonWrite5";
            this.buttonWrite5.Size = new System.Drawing.Size(80, 31);
            this.buttonWrite5.TabIndex = 23;
            this.buttonWrite5.Text = "Write";
            this.buttonWrite5.UseVisualStyleBackColor = true;
            // 
            // buttonWrite4
            // 
            this.buttonWrite4.Location = new System.Drawing.Point(519, 97);
            this.buttonWrite4.Margin = new System.Windows.Forms.Padding(4);
            this.buttonWrite4.Name = "buttonWrite4";
            this.buttonWrite4.Size = new System.Drawing.Size(80, 31);
            this.buttonWrite4.TabIndex = 22;
            this.buttonWrite4.Text = "Write";
            this.buttonWrite4.UseVisualStyleBackColor = true;
            // 
            // buttonRead5
            // 
            this.buttonRead5.Location = new System.Drawing.Point(431, 146);
            this.buttonRead5.Margin = new System.Windows.Forms.Padding(4);
            this.buttonRead5.Name = "buttonRead5";
            this.buttonRead5.Size = new System.Drawing.Size(80, 31);
            this.buttonRead5.TabIndex = 21;
            this.buttonRead5.Text = "Read";
            this.buttonRead5.UseVisualStyleBackColor = true;
            // 
            // buttonRead4
            // 
            this.buttonRead4.Location = new System.Drawing.Point(431, 97);
            this.buttonRead4.Margin = new System.Windows.Forms.Padding(4);
            this.buttonRead4.Name = "buttonRead4";
            this.buttonRead4.Size = new System.Drawing.Size(80, 31);
            this.buttonRead4.TabIndex = 20;
            this.buttonRead4.Text = "Read";
            this.buttonRead4.UseVisualStyleBackColor = true;
            // 
            // textSerialNumber
            // 
            this.textSerialNumber.Location = new System.Drawing.Point(219, 149);
            this.textSerialNumber.Margin = new System.Windows.Forms.Padding(4);
            this.textSerialNumber.Name = "textSerialNumber";
            this.textSerialNumber.Size = new System.Drawing.Size(203, 22);
            this.textSerialNumber.TabIndex = 19;
            this.textSerialNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textFWVersion
            // 
            this.textFWVersion.Location = new System.Drawing.Point(219, 100);
            this.textFWVersion.Margin = new System.Windows.Forms.Padding(4);
            this.textFWVersion.Name = "textFWVersion";
            this.textFWVersion.Size = new System.Drawing.Size(203, 22);
            this.textFWVersion.TabIndex = 18;
            this.textFWVersion.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // labelSerialNumber
            // 
            this.labelSerialNumber.AutoSize = true;
            this.labelSerialNumber.Location = new System.Drawing.Point(68, 154);
            this.labelSerialNumber.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelSerialNumber.Name = "labelSerialNumber";
            this.labelSerialNumber.Size = new System.Drawing.Size(147, 17);
            this.labelSerialNumber.TabIndex = 17;
            this.labelSerialNumber.Text = "Sensor serial number:";
            // 
            // labelFirmwareVersion
            // 
            this.labelFirmwareVersion.AutoSize = true;
            this.labelFirmwareVersion.Location = new System.Drawing.Point(68, 105);
            this.labelFirmwareVersion.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelFirmwareVersion.Name = "labelFirmwareVersion";
            this.labelFirmwareVersion.Size = new System.Drawing.Size(145, 17);
            this.labelFirmwareVersion.TabIndex = 16;
            this.labelFirmwareVersion.Text = "Sensor manufacturer:";
            // 
            // buttonWrite3
            // 
            this.buttonWrite3.Location = new System.Drawing.Point(519, 47);
            this.buttonWrite3.Margin = new System.Windows.Forms.Padding(4);
            this.buttonWrite3.Name = "buttonWrite3";
            this.buttonWrite3.Size = new System.Drawing.Size(80, 31);
            this.buttonWrite3.TabIndex = 15;
            this.buttonWrite3.Text = "Write";
            this.buttonWrite3.UseVisualStyleBackColor = true;
            // 
            // buttonRead3
            // 
            this.buttonRead3.Location = new System.Drawing.Point(431, 47);
            this.buttonRead3.Margin = new System.Windows.Forms.Padding(4);
            this.buttonRead3.Name = "buttonRead3";
            this.buttonRead3.Size = new System.Drawing.Size(80, 31);
            this.buttonRead3.TabIndex = 13;
            this.buttonRead3.Text = "Read";
            this.buttonRead3.UseVisualStyleBackColor = true;
            // 
            // textHWVersion
            // 
            this.textHWVersion.Location = new System.Drawing.Point(219, 49);
            this.textHWVersion.Margin = new System.Windows.Forms.Padding(4);
            this.textHWVersion.Name = "textHWVersion";
            this.textHWVersion.Size = new System.Drawing.Size(203, 22);
            this.textHWVersion.TabIndex = 11;
            this.textHWVersion.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // labelHardwareVersion
            // 
            this.labelHardwareVersion.AutoSize = true;
            this.labelHardwareVersion.Location = new System.Drawing.Point(68, 53);
            this.labelHardwareVersion.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelHardwareVersion.Name = "labelHardwareVersion";
            this.labelHardwareVersion.Size = new System.Drawing.Size(98, 17);
            this.labelHardwareVersion.TabIndex = 9;
            this.labelHardwareVersion.Text = "Sensor Name:";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.groupBox4);
            this.tabPage4.Controls.Add(this.groupBox3);
            this.tabPage4.Controls.Add(this.groupBox2);
            this.tabPage4.Controls.Add(this.groupBox1);
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(1309, 289);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "pH/ORP Calibration";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.txtCalibManualResult);
            this.groupBox4.Controls.Add(this.btnCalibManualReadResult);
            this.groupBox4.Controls.Add(this.btnWriteCalibManualAction);
            this.groupBox4.Controls.Add(this.txtBasicSlope);
            this.groupBox4.Controls.Add(this.btnWriteBasicSlope);
            this.groupBox4.Controls.Add(this.txtAcidSlope);
            this.groupBox4.Controls.Add(this.btnWriteAcidSlope);
            this.groupBox4.Controls.Add(this.txtZeroPoint);
            this.groupBox4.Controls.Add(this.btnWriteZeroPoint);
            this.groupBox4.Controls.Add(this.btnWriteCalibManualTime);
            this.groupBox4.Location = new System.Drawing.Point(932, 17);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox4.Size = new System.Drawing.Size(315, 254);
            this.groupBox4.TabIndex = 31;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Data Entry Calibration";
            // 
            // txtCalibManualResult
            // 
            this.txtCalibManualResult.Location = new System.Drawing.Point(193, 217);
            this.txtCalibManualResult.Margin = new System.Windows.Forms.Padding(4);
            this.txtCalibManualResult.Name = "txtCalibManualResult";
            this.txtCalibManualResult.Size = new System.Drawing.Size(108, 22);
            this.txtCalibManualResult.TabIndex = 28;
            this.txtCalibManualResult.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnCalibManualReadResult
            // 
            this.btnCalibManualReadResult.Location = new System.Drawing.Point(19, 214);
            this.btnCalibManualReadResult.Margin = new System.Windows.Forms.Padding(4);
            this.btnCalibManualReadResult.Name = "btnCalibManualReadResult";
            this.btnCalibManualReadResult.Size = new System.Drawing.Size(167, 28);
            this.btnCalibManualReadResult.TabIndex = 27;
            this.btnCalibManualReadResult.Text = "Read Result";
            this.btnCalibManualReadResult.UseVisualStyleBackColor = true;
            this.btnCalibManualReadResult.Click += new System.EventHandler(this.btnCalibManualReadResult_Click);
            // 
            // btnWriteCalibManualAction
            // 
            this.btnWriteCalibManualAction.Location = new System.Drawing.Point(19, 176);
            this.btnWriteCalibManualAction.Margin = new System.Windows.Forms.Padding(4);
            this.btnWriteCalibManualAction.Name = "btnWriteCalibManualAction";
            this.btnWriteCalibManualAction.Size = new System.Drawing.Size(167, 28);
            this.btnWriteCalibManualAction.TabIndex = 25;
            this.btnWriteCalibManualAction.Text = "Run Calibration";
            this.btnWriteCalibManualAction.UseVisualStyleBackColor = true;
            this.btnWriteCalibManualAction.Click += new System.EventHandler(this.btnWriteCalibManualAction_Click);
            // 
            // txtBasicSlope
            // 
            this.txtBasicSlope.Location = new System.Drawing.Point(193, 138);
            this.txtBasicSlope.Margin = new System.Windows.Forms.Padding(4);
            this.txtBasicSlope.Name = "txtBasicSlope";
            this.txtBasicSlope.Size = new System.Drawing.Size(108, 22);
            this.txtBasicSlope.TabIndex = 24;
            this.txtBasicSlope.Text = "59.16";
            this.txtBasicSlope.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnWriteBasicSlope
            // 
            this.btnWriteBasicSlope.Location = new System.Drawing.Point(19, 135);
            this.btnWriteBasicSlope.Margin = new System.Windows.Forms.Padding(4);
            this.btnWriteBasicSlope.Name = "btnWriteBasicSlope";
            this.btnWriteBasicSlope.Size = new System.Drawing.Size(167, 28);
            this.btnWriteBasicSlope.TabIndex = 23;
            this.btnWriteBasicSlope.Text = "Write Basic Slope";
            this.btnWriteBasicSlope.UseVisualStyleBackColor = true;
            this.btnWriteBasicSlope.Click += new System.EventHandler(this.btnWriteBasicSlope_Click);
            // 
            // txtAcidSlope
            // 
            this.txtAcidSlope.Location = new System.Drawing.Point(193, 98);
            this.txtAcidSlope.Margin = new System.Windows.Forms.Padding(4);
            this.txtAcidSlope.Name = "txtAcidSlope";
            this.txtAcidSlope.Size = new System.Drawing.Size(108, 22);
            this.txtAcidSlope.TabIndex = 22;
            this.txtAcidSlope.Text = "59.16";
            this.txtAcidSlope.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnWriteAcidSlope
            // 
            this.btnWriteAcidSlope.Location = new System.Drawing.Point(19, 96);
            this.btnWriteAcidSlope.Margin = new System.Windows.Forms.Padding(4);
            this.btnWriteAcidSlope.Name = "btnWriteAcidSlope";
            this.btnWriteAcidSlope.Size = new System.Drawing.Size(167, 28);
            this.btnWriteAcidSlope.TabIndex = 21;
            this.btnWriteAcidSlope.Text = "Write Acid Slope";
            this.btnWriteAcidSlope.UseVisualStyleBackColor = true;
            this.btnWriteAcidSlope.Click += new System.EventHandler(this.btnWriteAcidSlope_Click);
            // 
            // txtZeroPoint
            // 
            this.txtZeroPoint.Location = new System.Drawing.Point(193, 62);
            this.txtZeroPoint.Margin = new System.Windows.Forms.Padding(4);
            this.txtZeroPoint.Name = "txtZeroPoint";
            this.txtZeroPoint.Size = new System.Drawing.Size(108, 22);
            this.txtZeroPoint.TabIndex = 20;
            this.txtZeroPoint.Text = "7.0";
            this.txtZeroPoint.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnWriteZeroPoint
            // 
            this.btnWriteZeroPoint.Location = new System.Drawing.Point(19, 59);
            this.btnWriteZeroPoint.Margin = new System.Windows.Forms.Padding(4);
            this.btnWriteZeroPoint.Name = "btnWriteZeroPoint";
            this.btnWriteZeroPoint.Size = new System.Drawing.Size(167, 28);
            this.btnWriteZeroPoint.TabIndex = 11;
            this.btnWriteZeroPoint.Text = "Write Zero Point";
            this.btnWriteZeroPoint.UseVisualStyleBackColor = true;
            this.btnWriteZeroPoint.Click += new System.EventHandler(this.btnWriteZeroPoint_Click);
            // 
            // btnWriteCalibManualTime
            // 
            this.btnWriteCalibManualTime.Location = new System.Drawing.Point(19, 23);
            this.btnWriteCalibManualTime.Margin = new System.Windows.Forms.Padding(4);
            this.btnWriteCalibManualTime.Name = "btnWriteCalibManualTime";
            this.btnWriteCalibManualTime.Size = new System.Drawing.Size(167, 28);
            this.btnWriteCalibManualTime.TabIndex = 10;
            this.btnWriteCalibManualTime.Text = "Write Time Stamp";
            this.btnWriteCalibManualTime.UseVisualStyleBackColor = true;
            this.btnWriteCalibManualTime.Click += new System.EventHandler(this.btnWriteCalibManualTime_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.cbxORPActionCode);
            this.groupBox3.Controls.Add(this.txtORPResult);
            this.groupBox3.Controls.Add(this.btnORPCalibResultCode);
            this.groupBox3.Controls.Add(this.btnWriteORPActionCode);
            this.groupBox3.Controls.Add(this.txtORPPoint3);
            this.groupBox3.Controls.Add(this.btnWriteORPPoint3);
            this.groupBox3.Controls.Add(this.txtORPPoint2);
            this.groupBox3.Controls.Add(this.btnWriteORPPoint2);
            this.groupBox3.Controls.Add(this.txtORPPoint1);
            this.groupBox3.Controls.Add(this.btnWriteORPPoint1);
            this.groupBox3.Controls.Add(this.btnWriteORPCalibTime);
            this.groupBox3.Location = new System.Drawing.Point(609, 17);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox3.Size = new System.Drawing.Size(315, 254);
            this.groupBox3.TabIndex = 30;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "ORP Calibration";
            // 
            // cbxORPActionCode
            // 
            this.cbxORPActionCode.FormattingEnabled = true;
            this.cbxORPActionCode.Items.AddRange(new object[] {
            "1",
            "2",
            "3"});
            this.cbxORPActionCode.Location = new System.Drawing.Point(193, 176);
            this.cbxORPActionCode.Margin = new System.Windows.Forms.Padding(4);
            this.cbxORPActionCode.Name = "cbxORPActionCode";
            this.cbxORPActionCode.Size = new System.Drawing.Size(108, 24);
            this.cbxORPActionCode.TabIndex = 29;
            this.cbxORPActionCode.Text = "2";
            // 
            // txtORPResult
            // 
            this.txtORPResult.Location = new System.Drawing.Point(193, 217);
            this.txtORPResult.Margin = new System.Windows.Forms.Padding(4);
            this.txtORPResult.Name = "txtORPResult";
            this.txtORPResult.Size = new System.Drawing.Size(108, 22);
            this.txtORPResult.TabIndex = 28;
            this.txtORPResult.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnORPCalibResultCode
            // 
            this.btnORPCalibResultCode.Location = new System.Drawing.Point(19, 214);
            this.btnORPCalibResultCode.Margin = new System.Windows.Forms.Padding(4);
            this.btnORPCalibResultCode.Name = "btnORPCalibResultCode";
            this.btnORPCalibResultCode.Size = new System.Drawing.Size(167, 28);
            this.btnORPCalibResultCode.TabIndex = 27;
            this.btnORPCalibResultCode.Text = "Read Result";
            this.btnORPCalibResultCode.UseVisualStyleBackColor = true;
            this.btnORPCalibResultCode.Click += new System.EventHandler(this.btnORPCalibResultCode_Click);
            // 
            // btnWriteORPActionCode
            // 
            this.btnWriteORPActionCode.Location = new System.Drawing.Point(19, 176);
            this.btnWriteORPActionCode.Margin = new System.Windows.Forms.Padding(4);
            this.btnWriteORPActionCode.Name = "btnWriteORPActionCode";
            this.btnWriteORPActionCode.Size = new System.Drawing.Size(167, 28);
            this.btnWriteORPActionCode.TabIndex = 25;
            this.btnWriteORPActionCode.Text = "Run Calibration";
            this.btnWriteORPActionCode.UseVisualStyleBackColor = true;
            this.btnWriteORPActionCode.Click += new System.EventHandler(this.btnWriteORPActionCode_Click);
            // 
            // txtORPPoint3
            // 
            this.txtORPPoint3.Location = new System.Drawing.Point(193, 138);
            this.txtORPPoint3.Margin = new System.Windows.Forms.Padding(4);
            this.txtORPPoint3.Name = "txtORPPoint3";
            this.txtORPPoint3.Size = new System.Drawing.Size(108, 22);
            this.txtORPPoint3.TabIndex = 24;
            this.txtORPPoint3.Text = "177";
            this.txtORPPoint3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnWriteORPPoint3
            // 
            this.btnWriteORPPoint3.Location = new System.Drawing.Point(19, 135);
            this.btnWriteORPPoint3.Margin = new System.Windows.Forms.Padding(4);
            this.btnWriteORPPoint3.Name = "btnWriteORPPoint3";
            this.btnWriteORPPoint3.Size = new System.Drawing.Size(167, 28);
            this.btnWriteORPPoint3.TabIndex = 23;
            this.btnWriteORPPoint3.Text = "Write ORP 3rd Point";
            this.btnWriteORPPoint3.UseVisualStyleBackColor = true;
            this.btnWriteORPPoint3.Click += new System.EventHandler(this.btnWriteORPPoint3_Click);
            // 
            // txtORPPoint2
            // 
            this.txtORPPoint2.Location = new System.Drawing.Point(193, 98);
            this.txtORPPoint2.Margin = new System.Windows.Forms.Padding(4);
            this.txtORPPoint2.Name = "txtORPPoint2";
            this.txtORPPoint2.Size = new System.Drawing.Size(108, 22);
            this.txtORPPoint2.TabIndex = 22;
            this.txtORPPoint2.Text = "0";
            this.txtORPPoint2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnWriteORPPoint2
            // 
            this.btnWriteORPPoint2.Location = new System.Drawing.Point(19, 96);
            this.btnWriteORPPoint2.Margin = new System.Windows.Forms.Padding(4);
            this.btnWriteORPPoint2.Name = "btnWriteORPPoint2";
            this.btnWriteORPPoint2.Size = new System.Drawing.Size(167, 28);
            this.btnWriteORPPoint2.TabIndex = 21;
            this.btnWriteORPPoint2.Text = "Write ORP 2nd Point";
            this.btnWriteORPPoint2.UseVisualStyleBackColor = true;
            this.btnWriteORPPoint2.Click += new System.EventHandler(this.btnWriteORPPoint2_Click);
            // 
            // txtORPPoint1
            // 
            this.txtORPPoint1.Location = new System.Drawing.Point(193, 62);
            this.txtORPPoint1.Margin = new System.Windows.Forms.Padding(4);
            this.txtORPPoint1.Name = "txtORPPoint1";
            this.txtORPPoint1.Size = new System.Drawing.Size(108, 22);
            this.txtORPPoint1.TabIndex = 20;
            this.txtORPPoint1.Text = "-177";
            this.txtORPPoint1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnWriteORPPoint1
            // 
            this.btnWriteORPPoint1.Location = new System.Drawing.Point(19, 59);
            this.btnWriteORPPoint1.Margin = new System.Windows.Forms.Padding(4);
            this.btnWriteORPPoint1.Name = "btnWriteORPPoint1";
            this.btnWriteORPPoint1.Size = new System.Drawing.Size(167, 28);
            this.btnWriteORPPoint1.TabIndex = 11;
            this.btnWriteORPPoint1.Text = "Write ORP 1st Point";
            this.btnWriteORPPoint1.UseVisualStyleBackColor = true;
            this.btnWriteORPPoint1.Click += new System.EventHandler(this.btnWriteORPPoint1_Click);
            // 
            // btnWriteORPCalibTime
            // 
            this.btnWriteORPCalibTime.Location = new System.Drawing.Point(19, 23);
            this.btnWriteORPCalibTime.Margin = new System.Windows.Forms.Padding(4);
            this.btnWriteORPCalibTime.Name = "btnWriteORPCalibTime";
            this.btnWriteORPCalibTime.Size = new System.Drawing.Size(167, 28);
            this.btnWriteORPCalibTime.TabIndex = 10;
            this.btnWriteORPCalibTime.Text = "Write Time Stamp";
            this.btnWriteORPCalibTime.UseVisualStyleBackColor = true;
            this.btnWriteORPCalibTime.Click += new System.EventHandler(this.btnWriteORPCalibTime_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cbxPHActionCode);
            this.groupBox2.Controls.Add(this.txtPHResult);
            this.groupBox2.Controls.Add(this.btnPHReadResult);
            this.groupBox2.Controls.Add(this.btnRunPHCalib);
            this.groupBox2.Controls.Add(this.txtpH3rdBuffer);
            this.groupBox2.Controls.Add(this.btnWrite3rdPH);
            this.groupBox2.Controls.Add(this.txtpH2ndBuffer);
            this.groupBox2.Controls.Add(this.btnWrite2ndPH);
            this.groupBox2.Controls.Add(this.txtpH1stBuffer);
            this.groupBox2.Controls.Add(this.btnWrite1stPH);
            this.groupBox2.Controls.Add(this.btnPHCalibTime);
            this.groupBox2.Location = new System.Drawing.Point(284, 17);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(317, 254);
            this.groupBox2.TabIndex = 20;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "pH Calibration";
            // 
            // cbxPHActionCode
            // 
            this.cbxPHActionCode.FormattingEnabled = true;
            this.cbxPHActionCode.Items.AddRange(new object[] {
            "1",
            "2",
            "3"});
            this.cbxPHActionCode.Location = new System.Drawing.Point(193, 176);
            this.cbxPHActionCode.Margin = new System.Windows.Forms.Padding(4);
            this.cbxPHActionCode.Name = "cbxPHActionCode";
            this.cbxPHActionCode.Size = new System.Drawing.Size(108, 24);
            this.cbxPHActionCode.TabIndex = 29;
            this.cbxPHActionCode.Text = "2";
            // 
            // txtPHResult
            // 
            this.txtPHResult.Location = new System.Drawing.Point(193, 217);
            this.txtPHResult.Margin = new System.Windows.Forms.Padding(4);
            this.txtPHResult.Name = "txtPHResult";
            this.txtPHResult.Size = new System.Drawing.Size(108, 22);
            this.txtPHResult.TabIndex = 28;
            this.txtPHResult.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnPHReadResult
            // 
            this.btnPHReadResult.Location = new System.Drawing.Point(19, 214);
            this.btnPHReadResult.Margin = new System.Windows.Forms.Padding(4);
            this.btnPHReadResult.Name = "btnPHReadResult";
            this.btnPHReadResult.Size = new System.Drawing.Size(167, 28);
            this.btnPHReadResult.TabIndex = 27;
            this.btnPHReadResult.Text = "Read Result";
            this.btnPHReadResult.UseVisualStyleBackColor = true;
            this.btnPHReadResult.Click += new System.EventHandler(this.btnPHReadResult_Click);
            // 
            // btnRunPHCalib
            // 
            this.btnRunPHCalib.Location = new System.Drawing.Point(19, 176);
            this.btnRunPHCalib.Margin = new System.Windows.Forms.Padding(4);
            this.btnRunPHCalib.Name = "btnRunPHCalib";
            this.btnRunPHCalib.Size = new System.Drawing.Size(167, 28);
            this.btnRunPHCalib.TabIndex = 25;
            this.btnRunPHCalib.Text = "Run Calibration";
            this.btnRunPHCalib.UseVisualStyleBackColor = true;
            this.btnRunPHCalib.Click += new System.EventHandler(this.btnRunPHCalib_Click);
            // 
            // txtpH3rdBuffer
            // 
            this.txtpH3rdBuffer.Location = new System.Drawing.Point(193, 138);
            this.txtpH3rdBuffer.Margin = new System.Windows.Forms.Padding(4);
            this.txtpH3rdBuffer.Name = "txtpH3rdBuffer";
            this.txtpH3rdBuffer.Size = new System.Drawing.Size(108, 22);
            this.txtpH3rdBuffer.TabIndex = 24;
            this.txtpH3rdBuffer.Text = "10";
            this.txtpH3rdBuffer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnWrite3rdPH
            // 
            this.btnWrite3rdPH.Location = new System.Drawing.Point(19, 135);
            this.btnWrite3rdPH.Margin = new System.Windows.Forms.Padding(4);
            this.btnWrite3rdPH.Name = "btnWrite3rdPH";
            this.btnWrite3rdPH.Size = new System.Drawing.Size(167, 28);
            this.btnWrite3rdPH.TabIndex = 23;
            this.btnWrite3rdPH.Text = "Write pH of 3rd Buffer";
            this.btnWrite3rdPH.UseVisualStyleBackColor = true;
            this.btnWrite3rdPH.Click += new System.EventHandler(this.btnWrite3rdPH_Click);
            // 
            // txtpH2ndBuffer
            // 
            this.txtpH2ndBuffer.Location = new System.Drawing.Point(193, 98);
            this.txtpH2ndBuffer.Margin = new System.Windows.Forms.Padding(4);
            this.txtpH2ndBuffer.Name = "txtpH2ndBuffer";
            this.txtpH2ndBuffer.Size = new System.Drawing.Size(108, 22);
            this.txtpH2ndBuffer.TabIndex = 22;
            this.txtpH2ndBuffer.Text = "7";
            this.txtpH2ndBuffer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnWrite2ndPH
            // 
            this.btnWrite2ndPH.Location = new System.Drawing.Point(19, 96);
            this.btnWrite2ndPH.Margin = new System.Windows.Forms.Padding(4);
            this.btnWrite2ndPH.Name = "btnWrite2ndPH";
            this.btnWrite2ndPH.Size = new System.Drawing.Size(167, 28);
            this.btnWrite2ndPH.TabIndex = 21;
            this.btnWrite2ndPH.Text = "Write pH of 2nd Buffer";
            this.btnWrite2ndPH.UseVisualStyleBackColor = true;
            this.btnWrite2ndPH.Click += new System.EventHandler(this.btnWrite2ndPH_Click);
            // 
            // txtpH1stBuffer
            // 
            this.txtpH1stBuffer.Location = new System.Drawing.Point(193, 62);
            this.txtpH1stBuffer.Margin = new System.Windows.Forms.Padding(4);
            this.txtpH1stBuffer.Name = "txtpH1stBuffer";
            this.txtpH1stBuffer.Size = new System.Drawing.Size(108, 22);
            this.txtpH1stBuffer.TabIndex = 20;
            this.txtpH1stBuffer.Text = "4";
            this.txtpH1stBuffer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnWrite1stPH
            // 
            this.btnWrite1stPH.Location = new System.Drawing.Point(19, 59);
            this.btnWrite1stPH.Margin = new System.Windows.Forms.Padding(4);
            this.btnWrite1stPH.Name = "btnWrite1stPH";
            this.btnWrite1stPH.Size = new System.Drawing.Size(167, 28);
            this.btnWrite1stPH.TabIndex = 11;
            this.btnWrite1stPH.Text = "Write pH of 1st Buffer";
            this.btnWrite1stPH.UseVisualStyleBackColor = true;
            this.btnWrite1stPH.Click += new System.EventHandler(this.btnWrite1stPH_Click);
            // 
            // btnPHCalibTime
            // 
            this.btnPHCalibTime.Location = new System.Drawing.Point(19, 23);
            this.btnPHCalibTime.Margin = new System.Windows.Forms.Padding(4);
            this.btnPHCalibTime.Name = "btnPHCalibTime";
            this.btnPHCalibTime.Size = new System.Drawing.Size(167, 28);
            this.btnPHCalibTime.TabIndex = 10;
            this.btnPHCalibTime.Text = "Write Time Stamp";
            this.btnPHCalibTime.UseVisualStyleBackColor = true;
            this.btnPHCalibTime.Click += new System.EventHandler(this.btnPHCalibTime_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.lblCalibTime);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.lblCalibType);
            this.groupBox1.Controls.Add(this.lblSlope2);
            this.groupBox1.Controls.Add(this.lblSlope1);
            this.groupBox1.Controls.Add(this.lblZeroPoint);
            this.groupBox1.Controls.Add(this.btnReadLatestORPCalib);
            this.groupBox1.Controls.Add(this.btnReadLatestPHCalib);
            this.groupBox1.Location = new System.Drawing.Point(9, 17);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(267, 254);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Read Latest Calibration";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(33, 100);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 17);
            this.label1.TabIndex = 21;
            this.label1.Text = "Calib Time";
            // 
            // lblCalibTime
            // 
            this.lblCalibTime.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCalibTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCalibTime.Location = new System.Drawing.Point(111, 95);
            this.lblCalibTime.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCalibTime.Name = "lblCalibTime";
            this.lblCalibTime.Size = new System.Drawing.Size(135, 25);
            this.lblCalibTime.TabIndex = 20;
            this.lblCalibTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(33, 220);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(71, 17);
            this.label8.TabIndex = 19;
            this.label8.Text = "CalibType";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(33, 191);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(52, 17);
            this.label7.TabIndex = 18;
            this.label7.Text = "Slope2";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(33, 161);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 17);
            this.label6.TabIndex = 17;
            this.label6.Text = "Slope1";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(33, 130);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(74, 17);
            this.label5.TabIndex = 16;
            this.label5.Text = "Zero Point";
            // 
            // lblCalibType
            // 
            this.lblCalibType.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCalibType.Location = new System.Drawing.Point(112, 215);
            this.lblCalibType.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCalibType.Name = "lblCalibType";
            this.lblCalibType.Size = new System.Drawing.Size(135, 25);
            this.lblCalibType.TabIndex = 15;
            this.lblCalibType.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblSlope2
            // 
            this.lblSlope2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSlope2.Location = new System.Drawing.Point(112, 186);
            this.lblSlope2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSlope2.Name = "lblSlope2";
            this.lblSlope2.Size = new System.Drawing.Size(135, 25);
            this.lblSlope2.TabIndex = 14;
            this.lblSlope2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblSlope1
            // 
            this.lblSlope1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSlope1.Location = new System.Drawing.Point(112, 156);
            this.lblSlope1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSlope1.Name = "lblSlope1";
            this.lblSlope1.Size = new System.Drawing.Size(135, 25);
            this.lblSlope1.TabIndex = 13;
            this.lblSlope1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblZeroPoint
            // 
            this.lblZeroPoint.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblZeroPoint.Location = new System.Drawing.Point(111, 126);
            this.lblZeroPoint.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblZeroPoint.Name = "lblZeroPoint";
            this.lblZeroPoint.Size = new System.Drawing.Size(135, 25);
            this.lblZeroPoint.TabIndex = 12;
            this.lblZeroPoint.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnReadLatestORPCalib
            // 
            this.btnReadLatestORPCalib.Location = new System.Drawing.Point(19, 59);
            this.btnReadLatestORPCalib.Margin = new System.Windows.Forms.Padding(4);
            this.btnReadLatestORPCalib.Name = "btnReadLatestORPCalib";
            this.btnReadLatestORPCalib.Size = new System.Drawing.Size(229, 28);
            this.btnReadLatestORPCalib.TabIndex = 11;
            this.btnReadLatestORPCalib.Text = "Read Latest ORP Calibration";
            this.btnReadLatestORPCalib.UseVisualStyleBackColor = true;
            this.btnReadLatestORPCalib.Click += new System.EventHandler(this.btnReadLatestORPCalib_Click_1);
            // 
            // btnReadLatestPHCalib
            // 
            this.btnReadLatestPHCalib.Location = new System.Drawing.Point(19, 23);
            this.btnReadLatestPHCalib.Margin = new System.Windows.Forms.Padding(4);
            this.btnReadLatestPHCalib.Name = "btnReadLatestPHCalib";
            this.btnReadLatestPHCalib.Size = new System.Drawing.Size(229, 28);
            this.btnReadLatestPHCalib.TabIndex = 10;
            this.btnReadLatestPHCalib.Text = "Read Latest pH Calibration";
            this.btnReadLatestPHCalib.UseVisualStyleBackColor = true;
            this.btnReadLatestPHCalib.Click += new System.EventHandler(this.btnReadLatestPHCalib_Click_1);
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.groupBox8);
            this.tabPage5.Controls.Add(this.groupBox7);
            this.tabPage5.Controls.Add(this.groupBox6);
            this.tabPage5.Controls.Add(this.groupBox5);
            this.tabPage5.Location = new System.Drawing.Point(4, 25);
            this.tabPage5.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(1309, 289);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Other Calibration";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.txtReadOrpBias);
            this.groupBox8.Controls.Add(this.btnReadOrpBias);
            this.groupBox8.Controls.Add(this.txtReadTempBias);
            this.groupBox8.Controls.Add(this.btnReadTempBias);
            this.groupBox8.Controls.Add(this.cbxTempMode);
            this.groupBox8.Controls.Add(this.btnWriteTempMode);
            this.groupBox8.Controls.Add(this.txtMTCStatus);
            this.groupBox8.Controls.Add(this.btnReadMTCStatus);
            this.groupBox8.Controls.Add(this.txtReadMTC);
            this.groupBox8.Controls.Add(this.btnReadManualTemp);
            this.groupBox8.Controls.Add(this.txtWriteMTC);
            this.groupBox8.Controls.Add(this.btnWriteManualTemp);
            this.groupBox8.Location = new System.Drawing.Point(969, 15);
            this.groupBox8.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox8.Size = new System.Drawing.Size(317, 254);
            this.groupBox8.TabIndex = 29;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "MTC Setting";
            // 
            // txtReadOrpBias
            // 
            this.txtReadOrpBias.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtReadOrpBias.Location = new System.Drawing.Point(192, 174);
            this.txtReadOrpBias.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.txtReadOrpBias.Name = "txtReadOrpBias";
            this.txtReadOrpBias.Size = new System.Drawing.Size(109, 25);
            this.txtReadOrpBias.TabIndex = 32;
            this.txtReadOrpBias.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnReadOrpBias
            // 
            this.btnReadOrpBias.Location = new System.Drawing.Point(17, 171);
            this.btnReadOrpBias.Margin = new System.Windows.Forms.Padding(4);
            this.btnReadOrpBias.Name = "btnReadOrpBias";
            this.btnReadOrpBias.Size = new System.Drawing.Size(167, 28);
            this.btnReadOrpBias.TabIndex = 31;
            this.btnReadOrpBias.Text = "Read Orp Bias";
            this.btnReadOrpBias.UseVisualStyleBackColor = true;
            this.btnReadOrpBias.Click += new System.EventHandler(this.btnReadOrpBias_Click);
            // 
            // txtReadTempBias
            // 
            this.txtReadTempBias.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtReadTempBias.Location = new System.Drawing.Point(192, 209);
            this.txtReadTempBias.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.txtReadTempBias.Name = "txtReadTempBias";
            this.txtReadTempBias.Size = new System.Drawing.Size(109, 25);
            this.txtReadTempBias.TabIndex = 30;
            this.txtReadTempBias.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnReadTempBias
            // 
            this.btnReadTempBias.Location = new System.Drawing.Point(17, 207);
            this.btnReadTempBias.Margin = new System.Windows.Forms.Padding(4);
            this.btnReadTempBias.Name = "btnReadTempBias";
            this.btnReadTempBias.Size = new System.Drawing.Size(167, 28);
            this.btnReadTempBias.TabIndex = 29;
            this.btnReadTempBias.Text = "Read Temp Bias";
            this.btnReadTempBias.UseVisualStyleBackColor = true;
            this.btnReadTempBias.Click += new System.EventHandler(this.btnReadTempBias_Click);
            // 
            // cbxTempMode
            // 
            this.cbxTempMode.FormattingEnabled = true;
            this.cbxTempMode.Items.AddRange(new object[] {
            "ATC",
            "MTC"});
            this.cbxTempMode.Location = new System.Drawing.Point(192, 58);
            this.cbxTempMode.Margin = new System.Windows.Forms.Padding(4);
            this.cbxTempMode.Name = "cbxTempMode";
            this.cbxTempMode.Size = new System.Drawing.Size(108, 24);
            this.cbxTempMode.TabIndex = 26;
            this.cbxTempMode.Text = "ATC";
            // 
            // btnWriteTempMode
            // 
            this.btnWriteTempMode.Location = new System.Drawing.Point(17, 58);
            this.btnWriteTempMode.Margin = new System.Windows.Forms.Padding(4);
            this.btnWriteTempMode.Name = "btnWriteTempMode";
            this.btnWriteTempMode.Size = new System.Drawing.Size(167, 28);
            this.btnWriteTempMode.TabIndex = 25;
            this.btnWriteTempMode.Text = "Write Temp Mode";
            this.btnWriteTempMode.UseVisualStyleBackColor = true;
            this.btnWriteTempMode.Click += new System.EventHandler(this.btnWriteTempMode_Click);
            // 
            // txtMTCStatus
            // 
            this.txtMTCStatus.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtMTCStatus.Location = new System.Drawing.Point(192, 26);
            this.txtMTCStatus.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.txtMTCStatus.Name = "txtMTCStatus";
            this.txtMTCStatus.Size = new System.Drawing.Size(109, 25);
            this.txtMTCStatus.TabIndex = 24;
            this.txtMTCStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnReadMTCStatus
            // 
            this.btnReadMTCStatus.Location = new System.Drawing.Point(17, 23);
            this.btnReadMTCStatus.Margin = new System.Windows.Forms.Padding(4);
            this.btnReadMTCStatus.Name = "btnReadMTCStatus";
            this.btnReadMTCStatus.Size = new System.Drawing.Size(167, 28);
            this.btnReadMTCStatus.TabIndex = 23;
            this.btnReadMTCStatus.Text = "Read Temp Mode";
            this.btnReadMTCStatus.UseVisualStyleBackColor = true;
            this.btnReadMTCStatus.Click += new System.EventHandler(this.btnReadMTCStatus_Click);
            // 
            // txtReadMTC
            // 
            this.txtReadMTC.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtReadMTC.Location = new System.Drawing.Point(192, 100);
            this.txtReadMTC.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.txtReadMTC.Name = "txtReadMTC";
            this.txtReadMTC.Size = new System.Drawing.Size(109, 25);
            this.txtReadMTC.TabIndex = 22;
            this.txtReadMTC.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnReadManualTemp
            // 
            this.btnReadManualTemp.Location = new System.Drawing.Point(17, 97);
            this.btnReadManualTemp.Margin = new System.Windows.Forms.Padding(4);
            this.btnReadManualTemp.Name = "btnReadManualTemp";
            this.btnReadManualTemp.Size = new System.Drawing.Size(167, 28);
            this.btnReadManualTemp.TabIndex = 21;
            this.btnReadManualTemp.Text = "Read Manual Temp";
            this.btnReadManualTemp.UseVisualStyleBackColor = true;
            this.btnReadManualTemp.Click += new System.EventHandler(this.btnReadManualTemp_Click);
            // 
            // txtWriteMTC
            // 
            this.txtWriteMTC.Location = new System.Drawing.Point(192, 134);
            this.txtWriteMTC.Margin = new System.Windows.Forms.Padding(4);
            this.txtWriteMTC.Name = "txtWriteMTC";
            this.txtWriteMTC.Size = new System.Drawing.Size(108, 22);
            this.txtWriteMTC.TabIndex = 20;
            this.txtWriteMTC.Text = "25.1";
            this.txtWriteMTC.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnWriteManualTemp
            // 
            this.btnWriteManualTemp.Location = new System.Drawing.Point(17, 132);
            this.btnWriteManualTemp.Margin = new System.Windows.Forms.Padding(4);
            this.btnWriteManualTemp.Name = "btnWriteManualTemp";
            this.btnWriteManualTemp.Size = new System.Drawing.Size(167, 28);
            this.btnWriteManualTemp.TabIndex = 11;
            this.btnWriteManualTemp.Text = "Write Manual Temp";
            this.btnWriteManualTemp.UseVisualStyleBackColor = true;
            this.btnWriteManualTemp.Click += new System.EventHandler(this.btnWriteManualTemp_Click);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.txtOrpBias);
            this.groupBox7.Controls.Add(this.btnFactoryResetCalib);
            this.groupBox7.Controls.Add(this.txtTempBias);
            this.groupBox7.Controls.Add(this.btnWriteTempBias);
            this.groupBox7.Controls.Add(this.btnWriteOrpBias);
            this.groupBox7.Controls.Add(this.btnFactoryResetSetting);
            this.groupBox7.Location = new System.Drawing.Point(636, 15);
            this.groupBox7.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox7.Size = new System.Drawing.Size(317, 254);
            this.groupBox7.TabIndex = 22;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Factory Reset";
            // 
            // txtOrpBias
            // 
            this.txtOrpBias.Location = new System.Drawing.Point(192, 161);
            this.txtOrpBias.Margin = new System.Windows.Forms.Padding(4);
            this.txtOrpBias.Name = "txtOrpBias";
            this.txtOrpBias.Size = new System.Drawing.Size(108, 22);
            this.txtOrpBias.TabIndex = 32;
            this.txtOrpBias.Text = "0";
            this.txtOrpBias.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnFactoryResetCalib
            // 
            this.btnFactoryResetCalib.Location = new System.Drawing.Point(48, 100);
            this.btnFactoryResetCalib.Margin = new System.Windows.Forms.Padding(4);
            this.btnFactoryResetCalib.Name = "btnFactoryResetCalib";
            this.btnFactoryResetCalib.Size = new System.Drawing.Size(229, 28);
            this.btnFactoryResetCalib.TabIndex = 11;
            this.btnFactoryResetCalib.Text = "Factory Reset Calibration";
            this.btnFactoryResetCalib.UseVisualStyleBackColor = true;
            this.btnFactoryResetCalib.Click += new System.EventHandler(this.btnFactoryResetCalib_Click);
            // 
            // txtTempBias
            // 
            this.txtTempBias.Location = new System.Drawing.Point(192, 201);
            this.txtTempBias.Margin = new System.Windows.Forms.Padding(4);
            this.txtTempBias.Name = "txtTempBias";
            this.txtTempBias.Size = new System.Drawing.Size(108, 22);
            this.txtTempBias.TabIndex = 28;
            this.txtTempBias.Text = "0";
            this.txtTempBias.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnWriteTempBias
            // 
            this.btnWriteTempBias.Location = new System.Drawing.Point(17, 198);
            this.btnWriteTempBias.Margin = new System.Windows.Forms.Padding(4);
            this.btnWriteTempBias.Name = "btnWriteTempBias";
            this.btnWriteTempBias.Size = new System.Drawing.Size(167, 28);
            this.btnWriteTempBias.TabIndex = 27;
            this.btnWriteTempBias.Text = "Write Temp Bias";
            this.btnWriteTempBias.UseVisualStyleBackColor = true;
            this.btnWriteTempBias.Click += new System.EventHandler(this.btnWriteTempBias_Click);
            // 
            // btnWriteOrpBias
            // 
            this.btnWriteOrpBias.Location = new System.Drawing.Point(17, 159);
            this.btnWriteOrpBias.Margin = new System.Windows.Forms.Padding(4);
            this.btnWriteOrpBias.Name = "btnWriteOrpBias";
            this.btnWriteOrpBias.Size = new System.Drawing.Size(167, 28);
            this.btnWriteOrpBias.TabIndex = 31;
            this.btnWriteOrpBias.Text = "Write Orp Bias";
            this.btnWriteOrpBias.UseVisualStyleBackColor = true;
            this.btnWriteOrpBias.Click += new System.EventHandler(this.btnWriteOrpBias_Click);
            // 
            // btnFactoryResetSetting
            // 
            this.btnFactoryResetSetting.Location = new System.Drawing.Point(48, 50);
            this.btnFactoryResetSetting.Margin = new System.Windows.Forms.Padding(4);
            this.btnFactoryResetSetting.Name = "btnFactoryResetSetting";
            this.btnFactoryResetSetting.Size = new System.Drawing.Size(229, 28);
            this.btnFactoryResetSetting.TabIndex = 10;
            this.btnFactoryResetSetting.Text = "Factory Reset Setting";
            this.btnFactoryResetSetting.UseVisualStyleBackColor = true;
            this.btnFactoryResetSetting.Click += new System.EventHandler(this.btnFactoryResetSetting_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.txtTempCalibResult);
            this.groupBox6.Controls.Add(this.btnReadTempCalibResult);
            this.groupBox6.Controls.Add(this.btnRunTempCalib);
            this.groupBox6.Controls.Add(this.txtResOfPoint2);
            this.groupBox6.Controls.Add(this.btnWriteResOfPoint2);
            this.groupBox6.Controls.Add(this.txtResOfPoint1);
            this.groupBox6.Controls.Add(this.btnWriteResOfPoint1);
            this.groupBox6.Controls.Add(this.btnWriteTempCalibTime);
            this.groupBox6.Location = new System.Drawing.Point(301, 15);
            this.groupBox6.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox6.Size = new System.Drawing.Size(317, 254);
            this.groupBox6.TabIndex = 21;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Temperature Calibration";
            // 
            // txtTempCalibResult
            // 
            this.txtTempCalibResult.Location = new System.Drawing.Point(193, 202);
            this.txtTempCalibResult.Margin = new System.Windows.Forms.Padding(4);
            this.txtTempCalibResult.Name = "txtTempCalibResult";
            this.txtTempCalibResult.Size = new System.Drawing.Size(108, 22);
            this.txtTempCalibResult.TabIndex = 28;
            this.txtTempCalibResult.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnReadTempCalibResult
            // 
            this.btnReadTempCalibResult.Location = new System.Drawing.Point(19, 199);
            this.btnReadTempCalibResult.Margin = new System.Windows.Forms.Padding(4);
            this.btnReadTempCalibResult.Name = "btnReadTempCalibResult";
            this.btnReadTempCalibResult.Size = new System.Drawing.Size(167, 28);
            this.btnReadTempCalibResult.TabIndex = 27;
            this.btnReadTempCalibResult.Text = "Read Result";
            this.btnReadTempCalibResult.UseVisualStyleBackColor = true;
            this.btnReadTempCalibResult.Click += new System.EventHandler(this.btnReadTempCalibResult_Click);
            // 
            // btnRunTempCalib
            // 
            this.btnRunTempCalib.Location = new System.Drawing.Point(19, 161);
            this.btnRunTempCalib.Margin = new System.Windows.Forms.Padding(4);
            this.btnRunTempCalib.Name = "btnRunTempCalib";
            this.btnRunTempCalib.Size = new System.Drawing.Size(167, 28);
            this.btnRunTempCalib.TabIndex = 25;
            this.btnRunTempCalib.Text = "Run Calibration";
            this.btnRunTempCalib.UseVisualStyleBackColor = true;
            this.btnRunTempCalib.Click += new System.EventHandler(this.btnRunTempCalib_Click);
            // 
            // txtResOfPoint2
            // 
            this.txtResOfPoint2.Location = new System.Drawing.Point(193, 117);
            this.txtResOfPoint2.Margin = new System.Windows.Forms.Padding(4);
            this.txtResOfPoint2.Name = "txtResOfPoint2";
            this.txtResOfPoint2.Size = new System.Drawing.Size(108, 22);
            this.txtResOfPoint2.TabIndex = 22;
            this.txtResOfPoint2.Text = "1300";
            this.txtResOfPoint2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnWriteResOfPoint2
            // 
            this.btnWriteResOfPoint2.Location = new System.Drawing.Point(19, 114);
            this.btnWriteResOfPoint2.Margin = new System.Windows.Forms.Padding(4);
            this.btnWriteResOfPoint2.Name = "btnWriteResOfPoint2";
            this.btnWriteResOfPoint2.Size = new System.Drawing.Size(167, 28);
            this.btnWriteResOfPoint2.TabIndex = 21;
            this.btnWriteResOfPoint2.Text = "Write Res of 2nd Point";
            this.btnWriteResOfPoint2.UseVisualStyleBackColor = true;
            this.btnWriteResOfPoint2.Click += new System.EventHandler(this.btnWriteResOfPoint2_Click);
            // 
            // txtResOfPoint1
            // 
            this.txtResOfPoint1.Location = new System.Drawing.Point(193, 80);
            this.txtResOfPoint1.Margin = new System.Windows.Forms.Padding(4);
            this.txtResOfPoint1.Name = "txtResOfPoint1";
            this.txtResOfPoint1.Size = new System.Drawing.Size(108, 22);
            this.txtResOfPoint1.TabIndex = 20;
            this.txtResOfPoint1.Text = "1000";
            this.txtResOfPoint1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnWriteResOfPoint1
            // 
            this.btnWriteResOfPoint1.Location = new System.Drawing.Point(19, 78);
            this.btnWriteResOfPoint1.Margin = new System.Windows.Forms.Padding(4);
            this.btnWriteResOfPoint1.Name = "btnWriteResOfPoint1";
            this.btnWriteResOfPoint1.Size = new System.Drawing.Size(167, 28);
            this.btnWriteResOfPoint1.TabIndex = 11;
            this.btnWriteResOfPoint1.Text = "Write Res of 1st Point";
            this.btnWriteResOfPoint1.UseVisualStyleBackColor = true;
            this.btnWriteResOfPoint1.Click += new System.EventHandler(this.btnWriteResOfPoint1_Click);
            // 
            // btnWriteTempCalibTime
            // 
            this.btnWriteTempCalibTime.Location = new System.Drawing.Point(19, 42);
            this.btnWriteTempCalibTime.Margin = new System.Windows.Forms.Padding(4);
            this.btnWriteTempCalibTime.Name = "btnWriteTempCalibTime";
            this.btnWriteTempCalibTime.Size = new System.Drawing.Size(167, 28);
            this.btnWriteTempCalibTime.TabIndex = 10;
            this.btnWriteTempCalibTime.Text = "Write Time Stamp";
            this.btnWriteTempCalibTime.UseVisualStyleBackColor = true;
            this.btnWriteTempCalibTime.Click += new System.EventHandler(this.btnWriteTempCalibTime_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label2);
            this.groupBox5.Controls.Add(this.txtTempCalibTime);
            this.groupBox5.Controls.Add(this.label10);
            this.groupBox5.Controls.Add(this.label11);
            this.groupBox5.Controls.Add(this.txtTempOffset);
            this.groupBox5.Controls.Add(this.txtTempSlope);
            this.groupBox5.Controls.Add(this.btnLatestTempCalibration);
            this.groupBox5.Location = new System.Drawing.Point(19, 15);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox5.Size = new System.Drawing.Size(267, 254);
            this.groupBox5.TabIndex = 11;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Read Latest Calibration";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(33, 100);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 17);
            this.label2.TabIndex = 21;
            this.label2.Text = "Calib Time";
            // 
            // txtTempCalibTime
            // 
            this.txtTempCalibTime.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTempCalibTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTempCalibTime.Location = new System.Drawing.Point(111, 95);
            this.txtTempCalibTime.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.txtTempCalibTime.Name = "txtTempCalibTime";
            this.txtTempCalibTime.Size = new System.Drawing.Size(135, 25);
            this.txtTempCalibTime.TabIndex = 20;
            this.txtTempCalibTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(32, 186);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(46, 17);
            this.label10.TabIndex = 17;
            this.label10.Text = "Offset";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(32, 142);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(44, 17);
            this.label11.TabIndex = 16;
            this.label11.Text = "Slope";
            // 
            // txtTempOffset
            // 
            this.txtTempOffset.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTempOffset.Location = new System.Drawing.Point(111, 181);
            this.txtTempOffset.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.txtTempOffset.Name = "txtTempOffset";
            this.txtTempOffset.Size = new System.Drawing.Size(135, 25);
            this.txtTempOffset.TabIndex = 13;
            this.txtTempOffset.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtTempSlope
            // 
            this.txtTempSlope.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTempSlope.Location = new System.Drawing.Point(109, 137);
            this.txtTempSlope.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.txtTempSlope.Name = "txtTempSlope";
            this.txtTempSlope.Size = new System.Drawing.Size(135, 25);
            this.txtTempSlope.TabIndex = 12;
            this.txtTempSlope.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnLatestTempCalibration
            // 
            this.btnLatestTempCalibration.Location = new System.Drawing.Point(17, 42);
            this.btnLatestTempCalibration.Margin = new System.Windows.Forms.Padding(4);
            this.btnLatestTempCalibration.Name = "btnLatestTempCalibration";
            this.btnLatestTempCalibration.Size = new System.Drawing.Size(229, 28);
            this.btnLatestTempCalibration.TabIndex = 10;
            this.btnLatestTempCalibration.Text = "Read Latest Temp Calibration";
            this.btnLatestTempCalibration.UseVisualStyleBackColor = true;
            this.btnLatestTempCalibration.Click += new System.EventHandler(this.btnLatestTempCalibration_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.textTemperature);
            this.tabPage3.Controls.Add(this.textORP);
            this.tabPage3.Controls.Add(this.textPH);
            this.tabPage3.Controls.Add(this.label12);
            this.tabPage3.Controls.Add(this.label9);
            this.tabPage3.Controls.Add(this.label4);
            this.tabPage3.Controls.Add(this.label3);
            this.tabPage3.Controls.Add(this.label19);
            this.tabPage3.Controls.Add(this.label18);
            this.tabPage3.Controls.Add(this.buttonMoitorStop);
            this.tabPage3.Controls.Add(this.buttonMoitorStart);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1309, 289);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Monitoring";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // textTemperature
            // 
            this.textTemperature.BackColor = System.Drawing.Color.Black;
            this.textTemperature.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textTemperature.Font = new System.Drawing.Font("SimSun", 30F);
            this.textTemperature.ForeColor = System.Drawing.Color.White;
            this.textTemperature.Location = new System.Drawing.Point(368, 194);
            this.textTemperature.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textTemperature.Name = "textTemperature";
            this.textTemperature.Size = new System.Drawing.Size(266, 65);
            this.textTemperature.TabIndex = 23;
            this.textTemperature.Text = "25.3";
            this.textTemperature.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textORP
            // 
            this.textORP.BackColor = System.Drawing.Color.Black;
            this.textORP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textORP.Font = new System.Drawing.Font("SimSun", 30F);
            this.textORP.ForeColor = System.Drawing.Color.White;
            this.textORP.Location = new System.Drawing.Point(368, 111);
            this.textORP.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textORP.Name = "textORP";
            this.textORP.Size = new System.Drawing.Size(266, 65);
            this.textORP.TabIndex = 22;
            this.textORP.Text = "-1000.2";
            this.textORP.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textPH
            // 
            this.textPH.BackColor = System.Drawing.Color.Black;
            this.textPH.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textPH.Font = new System.Drawing.Font("SimSun", 30F);
            this.textPH.ForeColor = System.Drawing.Color.White;
            this.textPH.Location = new System.Drawing.Point(368, 22);
            this.textPH.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textPH.Name = "textPH";
            this.textPH.Size = new System.Drawing.Size(266, 65);
            this.textPH.TabIndex = 21;
            this.textPH.Text = "7.2";
            this.textPH.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("SimSun", 24.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label12.Location = new System.Drawing.Point(640, 219);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(60, 42);
            this.label12.TabIndex = 20;
            this.label12.Text = "℃";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("SimSun", 24.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label9.Location = new System.Drawing.Point(640, 135);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(60, 42);
            this.label9.TabIndex = 19;
            this.label9.Text = "mV";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("SimSun", 24.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(640, 50);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 42);
            this.label4.TabIndex = 18;
            this.label4.Text = "pH";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("SimSun", 24.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(249, 122);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(102, 42);
            this.label3.TabIndex = 16;
            this.label3.Text = "ORP:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("SimSun", 24.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label19.Location = new System.Drawing.Point(227, 209);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(123, 42);
            this.label19.TabIndex = 13;
            this.label19.Text = "TEMP:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("SimSun", 24.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label18.Location = new System.Drawing.Point(272, 37);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(81, 42);
            this.label18.TabIndex = 12;
            this.label18.Text = "pH:";
            // 
            // buttonMoitorStop
            // 
            this.buttonMoitorStop.Enabled = false;
            this.buttonMoitorStop.Location = new System.Drawing.Point(897, 142);
            this.buttonMoitorStop.Margin = new System.Windows.Forms.Padding(4);
            this.buttonMoitorStop.Name = "buttonMoitorStop";
            this.buttonMoitorStop.Size = new System.Drawing.Size(137, 46);
            this.buttonMoitorStop.TabIndex = 11;
            this.buttonMoitorStop.Text = "Stop";
            this.buttonMoitorStop.UseVisualStyleBackColor = true;
            this.buttonMoitorStop.Click += new System.EventHandler(this.buttonMoitorStop_Click);
            // 
            // buttonMoitorStart
            // 
            this.buttonMoitorStart.Location = new System.Drawing.Point(897, 68);
            this.buttonMoitorStart.Margin = new System.Windows.Forms.Padding(4);
            this.buttonMoitorStart.Name = "buttonMoitorStart";
            this.buttonMoitorStart.Size = new System.Drawing.Size(137, 46);
            this.buttonMoitorStart.TabIndex = 10;
            this.buttonMoitorStart.Text = "Start";
            this.buttonMoitorStart.UseVisualStyleBackColor = true;
            this.buttonMoitorStart.Click += new System.EventHandler(this.buttonMoitorStart_Click);
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.radioButton2);
            this.tabPage6.Controls.Add(this.radioButton1);
            this.tabPage6.Controls.Add(this.groupORPCalib);
            this.tabPage6.Controls.Add(this.groupPHCalib);
            this.tabPage6.Location = new System.Drawing.Point(4, 25);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(1309, 289);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "pH/ORP AutoCalibration";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(668, 28);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(17, 16);
            this.radioButton2.TabIndex = 30;
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Checked = true;
            this.radioButton1.Location = new System.Drawing.Point(22, 28);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(17, 16);
            this.radioButton1.TabIndex = 29;
            this.radioButton1.TabStop = true;
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // groupORPCalib
            // 
            this.groupORPCalib.Controls.Add(this.picORPCalibProgress);
            this.groupORPCalib.Controls.Add(this.txtORPMeasure3);
            this.groupORPCalib.Controls.Add(this.txtORPMeasure2);
            this.groupORPCalib.Controls.Add(this.txtORPMeasure1);
            this.groupORPCalib.Controls.Add(this.label33);
            this.groupORPCalib.Controls.Add(this.label34);
            this.groupORPCalib.Controls.Add(this.label35);
            this.groupORPCalib.Controls.Add(this.btnORPCalibStart);
            this.groupORPCalib.Controls.Add(this.btnORPCalibFinish);
            this.groupORPCalib.Controls.Add(this.btnORPCalibContinue);
            this.groupORPCalib.Controls.Add(this.btnORPCalibBack);
            this.groupORPCalib.Controls.Add(this.txtORPBuffer3);
            this.groupORPCalib.Controls.Add(this.txtORPBuffer2);
            this.groupORPCalib.Controls.Add(this.txtORPBuffer1);
            this.groupORPCalib.Controls.Add(this.label41);
            this.groupORPCalib.Controls.Add(this.label42);
            this.groupORPCalib.Controls.Add(this.label43);
            this.groupORPCalib.Enabled = false;
            this.groupORPCalib.Location = new System.Drawing.Point(691, 6);
            this.groupORPCalib.Name = "groupORPCalib";
            this.groupORPCalib.Size = new System.Drawing.Size(593, 277);
            this.groupORPCalib.TabIndex = 28;
            this.groupORPCalib.TabStop = false;
            this.groupORPCalib.Text = "ORP Calibration";
            // 
            // picORPCalibProgress
            // 
            this.picORPCalibProgress.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.picORPCalibProgress.Image = global::PHPCTool.Properties.Resources.start;
            this.picORPCalibProgress.Location = new System.Drawing.Point(38, 174);
            this.picORPCalibProgress.Name = "picORPCalibProgress";
            this.picORPCalibProgress.Size = new System.Drawing.Size(511, 55);
            this.picORPCalibProgress.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picORPCalibProgress.TabIndex = 34;
            this.picORPCalibProgress.TabStop = false;
            // 
            // txtORPMeasure3
            // 
            this.txtORPMeasure3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtORPMeasure3.Location = new System.Drawing.Point(414, 109);
            this.txtORPMeasure3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.txtORPMeasure3.Name = "txtORPMeasure3";
            this.txtORPMeasure3.Size = new System.Drawing.Size(135, 25);
            this.txtORPMeasure3.TabIndex = 33;
            this.txtORPMeasure3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtORPMeasure2
            // 
            this.txtORPMeasure2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtORPMeasure2.Location = new System.Drawing.Point(414, 74);
            this.txtORPMeasure2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.txtORPMeasure2.Name = "txtORPMeasure2";
            this.txtORPMeasure2.Size = new System.Drawing.Size(135, 25);
            this.txtORPMeasure2.TabIndex = 32;
            this.txtORPMeasure2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtORPMeasure1
            // 
            this.txtORPMeasure1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtORPMeasure1.Location = new System.Drawing.Point(414, 37);
            this.txtORPMeasure1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.txtORPMeasure1.Name = "txtORPMeasure1";
            this.txtORPMeasure1.Size = new System.Drawing.Size(135, 25);
            this.txtORPMeasure1.TabIndex = 31;
            this.txtORPMeasure1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(301, 113);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(109, 17);
            this.label33.TabIndex = 30;
            this.label33.Text = "Measured ORP:";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(301, 78);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(109, 17);
            this.label34.TabIndex = 29;
            this.label34.Text = "Measured ORP:";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(301, 41);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(109, 17);
            this.label35.TabIndex = 28;
            this.label35.Text = "Measured ORP:";
            // 
            // btnORPCalibStart
            // 
            this.btnORPCalibStart.Location = new System.Drawing.Point(115, 236);
            this.btnORPCalibStart.Name = "btnORPCalibStart";
            this.btnORPCalibStart.Size = new System.Drawing.Size(85, 30);
            this.btnORPCalibStart.TabIndex = 27;
            this.btnORPCalibStart.Text = "Start";
            this.btnORPCalibStart.UseVisualStyleBackColor = true;
            this.btnORPCalibStart.Click += new System.EventHandler(this.btnORPCalibStart_Click);
            // 
            // btnORPCalibFinish
            // 
            this.btnORPCalibFinish.Enabled = false;
            this.btnORPCalibFinish.Location = new System.Drawing.Point(417, 236);
            this.btnORPCalibFinish.Name = "btnORPCalibFinish";
            this.btnORPCalibFinish.Size = new System.Drawing.Size(85, 30);
            this.btnORPCalibFinish.TabIndex = 26;
            this.btnORPCalibFinish.Text = "Finish";
            this.btnORPCalibFinish.UseVisualStyleBackColor = true;
            this.btnORPCalibFinish.Click += new System.EventHandler(this.btnORPCalibFinish_Click);
            // 
            // btnORPCalibContinue
            // 
            this.btnORPCalibContinue.Enabled = false;
            this.btnORPCalibContinue.Location = new System.Drawing.Point(318, 236);
            this.btnORPCalibContinue.Name = "btnORPCalibContinue";
            this.btnORPCalibContinue.Size = new System.Drawing.Size(85, 30);
            this.btnORPCalibContinue.TabIndex = 25;
            this.btnORPCalibContinue.Text = "Continue";
            this.btnORPCalibContinue.UseVisualStyleBackColor = true;
            this.btnORPCalibContinue.Click += new System.EventHandler(this.btnORPCalibContinue_Click);
            // 
            // btnORPCalibBack
            // 
            this.btnORPCalibBack.Enabled = false;
            this.btnORPCalibBack.Location = new System.Drawing.Point(216, 236);
            this.btnORPCalibBack.Name = "btnORPCalibBack";
            this.btnORPCalibBack.Size = new System.Drawing.Size(85, 30);
            this.btnORPCalibBack.TabIndex = 24;
            this.btnORPCalibBack.Text = "Back";
            this.btnORPCalibBack.UseVisualStyleBackColor = true;
            this.btnORPCalibBack.Click += new System.EventHandler(this.btnORPCalibBack_Click);
            // 
            // txtORPBuffer3
            // 
            this.txtORPBuffer3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtORPBuffer3.Location = new System.Drawing.Point(131, 109);
            this.txtORPBuffer3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.txtORPBuffer3.Name = "txtORPBuffer3";
            this.txtORPBuffer3.Size = new System.Drawing.Size(135, 25);
            this.txtORPBuffer3.TabIndex = 15;
            this.txtORPBuffer3.Text = "177";
            this.txtORPBuffer3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.txtORPBuffer3.Click += new System.EventHandler(this.txtORPBuffer3_Click);
            // 
            // txtORPBuffer2
            // 
            this.txtORPBuffer2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtORPBuffer2.Location = new System.Drawing.Point(131, 74);
            this.txtORPBuffer2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.txtORPBuffer2.Name = "txtORPBuffer2";
            this.txtORPBuffer2.Size = new System.Drawing.Size(135, 25);
            this.txtORPBuffer2.TabIndex = 14;
            this.txtORPBuffer2.Text = "0";
            this.txtORPBuffer2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.txtORPBuffer2.Click += new System.EventHandler(this.txtORPBuffer2_Click);
            // 
            // txtORPBuffer1
            // 
            this.txtORPBuffer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtORPBuffer1.Location = new System.Drawing.Point(131, 37);
            this.txtORPBuffer1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.txtORPBuffer1.Name = "txtORPBuffer1";
            this.txtORPBuffer1.Size = new System.Drawing.Size(135, 25);
            this.txtORPBuffer1.TabIndex = 13;
            this.txtORPBuffer1.Text = "-177";
            this.txtORPBuffer1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.txtORPBuffer1.Click += new System.EventHandler(this.txtORPBuffer1_Click);
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(18, 113);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(106, 17);
            this.label41.TabIndex = 4;
            this.label41.Text = "ORP of  Point3:";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(18, 78);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(106, 17);
            this.label42.TabIndex = 3;
            this.label42.Text = "ORP of  Point2:";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(18, 41);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(106, 17);
            this.label43.TabIndex = 2;
            this.label43.Text = "ORP of  Point1:";
            // 
            // groupPHCalib
            // 
            this.groupPHCalib.Controls.Add(this.picPHCalibProcess);
            this.groupPHCalib.Controls.Add(this.btnPHCalibStart);
            this.groupPHCalib.Controls.Add(this.btnPHCalibFinish);
            this.groupPHCalib.Controls.Add(this.btnPHCalibContinue);
            this.groupPHCalib.Controls.Add(this.btnPHCalibBack);
            this.groupPHCalib.Controls.Add(this.txtPHOfBuffer);
            this.groupPHCalib.Controls.Add(this.label29);
            this.groupPHCalib.Controls.Add(this.txtPHCalibTime);
            this.groupPHCalib.Controls.Add(this.label27);
            this.groupPHCalib.Controls.Add(this.txtPHCalibTemp);
            this.groupPHCalib.Controls.Add(this.label25);
            this.groupPHCalib.Controls.Add(this.txtPHVoltage);
            this.groupPHCalib.Controls.Add(this.label23);
            this.groupPHCalib.Controls.Add(this.txtPHOfBuffer3);
            this.groupPHCalib.Controls.Add(this.txtPHOfBuffer2);
            this.groupPHCalib.Controls.Add(this.txtPHOfBuffer1);
            this.groupPHCalib.Controls.Add(this.label16);
            this.groupPHCalib.Controls.Add(this.label15);
            this.groupPHCalib.Controls.Add(this.label14);
            this.groupPHCalib.Controls.Add(this.label13);
            this.groupPHCalib.Controls.Add(this.comboCalibType);
            this.groupPHCalib.Location = new System.Drawing.Point(45, 6);
            this.groupPHCalib.Name = "groupPHCalib";
            this.groupPHCalib.Size = new System.Drawing.Size(593, 277);
            this.groupPHCalib.TabIndex = 0;
            this.groupPHCalib.TabStop = false;
            this.groupPHCalib.Text = "pH Calibration";
            // 
            // picPHCalibProcess
            // 
            this.picPHCalibProcess.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.picPHCalibProcess.Image = global::PHPCTool.Properties.Resources.start;
            this.picPHCalibProcess.Location = new System.Drawing.Point(32, 174);
            this.picPHCalibProcess.Name = "picPHCalibProcess";
            this.picPHCalibProcess.Size = new System.Drawing.Size(511, 55);
            this.picPHCalibProcess.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picPHCalibProcess.TabIndex = 28;
            this.picPHCalibProcess.TabStop = false;
            // 
            // btnPHCalibStart
            // 
            this.btnPHCalibStart.Location = new System.Drawing.Point(114, 236);
            this.btnPHCalibStart.Name = "btnPHCalibStart";
            this.btnPHCalibStart.Size = new System.Drawing.Size(85, 30);
            this.btnPHCalibStart.TabIndex = 27;
            this.btnPHCalibStart.Text = "Start";
            this.btnPHCalibStart.UseVisualStyleBackColor = true;
            this.btnPHCalibStart.Click += new System.EventHandler(this.btnPHCalibStart_Click);
            // 
            // btnPHCalibFinish
            // 
            this.btnPHCalibFinish.Location = new System.Drawing.Point(416, 236);
            this.btnPHCalibFinish.Name = "btnPHCalibFinish";
            this.btnPHCalibFinish.Size = new System.Drawing.Size(85, 30);
            this.btnPHCalibFinish.TabIndex = 26;
            this.btnPHCalibFinish.Text = "Finish";
            this.btnPHCalibFinish.UseVisualStyleBackColor = true;
            this.btnPHCalibFinish.Click += new System.EventHandler(this.btnPHCalibFinish_Click);
            // 
            // btnPHCalibContinue
            // 
            this.btnPHCalibContinue.Location = new System.Drawing.Point(317, 236);
            this.btnPHCalibContinue.Name = "btnPHCalibContinue";
            this.btnPHCalibContinue.Size = new System.Drawing.Size(85, 30);
            this.btnPHCalibContinue.TabIndex = 25;
            this.btnPHCalibContinue.Text = "Continue";
            this.btnPHCalibContinue.UseVisualStyleBackColor = true;
            this.btnPHCalibContinue.Click += new System.EventHandler(this.btnPHCalibContinue_Click);
            // 
            // btnPHCalibBack
            // 
            this.btnPHCalibBack.Location = new System.Drawing.Point(215, 236);
            this.btnPHCalibBack.Name = "btnPHCalibBack";
            this.btnPHCalibBack.Size = new System.Drawing.Size(85, 30);
            this.btnPHCalibBack.TabIndex = 24;
            this.btnPHCalibBack.Text = "Back";
            this.btnPHCalibBack.UseVisualStyleBackColor = true;
            this.btnPHCalibBack.Click += new System.EventHandler(this.btnPHCalibBack_Click);
            // 
            // txtPHOfBuffer
            // 
            this.txtPHOfBuffer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPHOfBuffer.Location = new System.Drawing.Point(408, 131);
            this.txtPHOfBuffer.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.txtPHOfBuffer.Name = "txtPHOfBuffer";
            this.txtPHOfBuffer.Size = new System.Drawing.Size(135, 25);
            this.txtPHOfBuffer.TabIndex = 23;
            this.txtPHOfBuffer.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(311, 135);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(88, 17);
            this.label29.TabIndex = 22;
            this.label29.Text = "pH of Buffer:";
            // 
            // txtPHCalibTime
            // 
            this.txtPHCalibTime.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPHCalibTime.Location = new System.Drawing.Point(408, 96);
            this.txtPHCalibTime.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.txtPHCalibTime.Name = "txtPHCalibTime";
            this.txtPHCalibTime.Size = new System.Drawing.Size(135, 25);
            this.txtPHCalibTime.TabIndex = 21;
            this.txtPHCalibTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(342, 100);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(60, 17);
            this.label27.TabIndex = 20;
            this.label27.Text = "Time(s):";
            // 
            // txtPHCalibTemp
            // 
            this.txtPHCalibTemp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPHCalibTemp.Location = new System.Drawing.Point(408, 59);
            this.txtPHCalibTemp.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.txtPHCalibTemp.Name = "txtPHCalibTemp";
            this.txtPHCalibTemp.Size = new System.Drawing.Size(135, 25);
            this.txtPHCalibTemp.TabIndex = 19;
            this.txtPHCalibTemp.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(305, 63);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(94, 17);
            this.label25.TabIndex = 18;
            this.label25.Text = "Temperature:";
            // 
            // txtPHVoltage
            // 
            this.txtPHVoltage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPHVoltage.Location = new System.Drawing.Point(408, 22);
            this.txtPHVoltage.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.txtPHVoltage.Name = "txtPHVoltage";
            this.txtPHVoltage.Size = new System.Drawing.Size(135, 25);
            this.txtPHVoltage.TabIndex = 17;
            this.txtPHVoltage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(290, 26);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(112, 17);
            this.label23.TabIndex = 16;
            this.label23.Text = "pH Voltage(mV):";
            // 
            // txtPHOfBuffer3
            // 
            this.txtPHOfBuffer3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPHOfBuffer3.Location = new System.Drawing.Point(131, 131);
            this.txtPHOfBuffer3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.txtPHOfBuffer3.Name = "txtPHOfBuffer3";
            this.txtPHOfBuffer3.Size = new System.Drawing.Size(135, 25);
            this.txtPHOfBuffer3.TabIndex = 15;
            this.txtPHOfBuffer3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.txtPHOfBuffer3.Click += new System.EventHandler(this.txtPHOfBuffer3_Click);
            // 
            // txtPHOfBuffer2
            // 
            this.txtPHOfBuffer2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPHOfBuffer2.Location = new System.Drawing.Point(131, 96);
            this.txtPHOfBuffer2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.txtPHOfBuffer2.Name = "txtPHOfBuffer2";
            this.txtPHOfBuffer2.Size = new System.Drawing.Size(135, 25);
            this.txtPHOfBuffer2.TabIndex = 14;
            this.txtPHOfBuffer2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.txtPHOfBuffer2.Click += new System.EventHandler(this.txtPHOfBuffer2_Click);
            // 
            // txtPHOfBuffer1
            // 
            this.txtPHOfBuffer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPHOfBuffer1.Location = new System.Drawing.Point(131, 59);
            this.txtPHOfBuffer1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.txtPHOfBuffer1.Name = "txtPHOfBuffer1";
            this.txtPHOfBuffer1.Size = new System.Drawing.Size(135, 25);
            this.txtPHOfBuffer1.TabIndex = 13;
            this.txtPHOfBuffer1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.txtPHOfBuffer1.Click += new System.EventHandler(this.txtPHOfBuffer1_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(28, 135);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(96, 17);
            this.label16.TabIndex = 4;
            this.label16.Text = "pH of Buffer3:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(28, 100);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(96, 17);
            this.label15.TabIndex = 3;
            this.label15.Text = "pH of Buffer2:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(28, 63);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(96, 17);
            this.label14.TabIndex = 2;
            this.label14.Text = "pH of Buffer1:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(49, 26);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(75, 17);
            this.label13.TabIndex = 1;
            this.label13.Text = "CalibType:";
            // 
            // comboCalibType
            // 
            this.comboCalibType.FormattingEnabled = true;
            this.comboCalibType.Items.AddRange(new object[] {
            "NIST Calibration",
            "TECH Calibration",
            "Manual Calibration"});
            this.comboCalibType.Location = new System.Drawing.Point(130, 23);
            this.comboCalibType.Name = "comboCalibType";
            this.comboCalibType.Size = new System.Drawing.Size(136, 24);
            this.comboCalibType.TabIndex = 0;
            this.comboCalibType.Text = "NIST Calibration";
            this.comboCalibType.SelectedIndexChanged += new System.EventHandler(this.comboCalibType_SelectedIndexChanged);
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.groupBox9);
            this.tabPage7.Location = new System.Drawing.Point(4, 25);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(1309, 289);
            this.tabPage7.TabIndex = 6;
            this.tabPage7.Text = "Temp AutoCalibration";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.btnTempCalibRunCalib);
            this.groupBox9.Controls.Add(this.btnTempCalibRunP2);
            this.groupBox9.Controls.Add(this.txtTempCalibResMea2);
            this.groupBox9.Controls.Add(this.txtTempCalibResMea1);
            this.groupBox9.Controls.Add(this.label24);
            this.groupBox9.Controls.Add(this.label26);
            this.groupBox9.Controls.Add(this.btnTempCalibRunP1);
            this.groupBox9.Controls.Add(this.txtTempCalibRes2);
            this.groupBox9.Controls.Add(this.txtTempCalibRes1);
            this.groupBox9.Controls.Add(this.label36);
            this.groupBox9.Controls.Add(this.label37);
            this.groupBox9.Location = new System.Drawing.Point(358, 19);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(593, 246);
            this.groupBox9.TabIndex = 29;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Temperature Calibration";
            // 
            // btnTempCalibRunCalib
            // 
            this.btnTempCalibRunCalib.Location = new System.Drawing.Point(411, 175);
            this.btnTempCalibRunCalib.Name = "btnTempCalibRunCalib";
            this.btnTempCalibRunCalib.Size = new System.Drawing.Size(125, 30);
            this.btnTempCalibRunCalib.TabIndex = 34;
            this.btnTempCalibRunCalib.Text = "Run Calibration";
            this.btnTempCalibRunCalib.UseVisualStyleBackColor = true;
            this.btnTempCalibRunCalib.Click += new System.EventHandler(this.btnTempCalibRunCalib_Click);
            // 
            // btnTempCalibRunP2
            // 
            this.btnTempCalibRunP2.Location = new System.Drawing.Point(251, 175);
            this.btnTempCalibRunP2.Name = "btnTempCalibRunP2";
            this.btnTempCalibRunP2.Size = new System.Drawing.Size(128, 30);
            this.btnTempCalibRunP2.TabIndex = 33;
            this.btnTempCalibRunP2.Text = "Run Point2";
            this.btnTempCalibRunP2.UseVisualStyleBackColor = true;
            this.btnTempCalibRunP2.Click += new System.EventHandler(this.btnTempCalibRunP2_Click);
            // 
            // txtTempCalibResMea2
            // 
            this.txtTempCalibResMea2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTempCalibResMea2.Location = new System.Drawing.Point(427, 101);
            this.txtTempCalibResMea2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.txtTempCalibResMea2.Name = "txtTempCalibResMea2";
            this.txtTempCalibResMea2.Size = new System.Drawing.Size(135, 25);
            this.txtTempCalibResMea2.TabIndex = 32;
            this.txtTempCalibResMea2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtTempCalibResMea1
            // 
            this.txtTempCalibResMea1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTempCalibResMea1.Location = new System.Drawing.Point(427, 55);
            this.txtTempCalibResMea1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.txtTempCalibResMea1.Name = "txtTempCalibResMea1";
            this.txtTempCalibResMea1.Size = new System.Drawing.Size(135, 25);
            this.txtTempCalibResMea1.TabIndex = 31;
            this.txtTempCalibResMea1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(314, 105);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(104, 17);
            this.label24.TabIndex = 29;
            this.label24.Text = "Measured Res:";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(314, 59);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(104, 17);
            this.label26.TabIndex = 28;
            this.label26.Text = "Measured Res:";
            // 
            // btnTempCalibRunP1
            // 
            this.btnTempCalibRunP1.Location = new System.Drawing.Point(85, 175);
            this.btnTempCalibRunP1.Name = "btnTempCalibRunP1";
            this.btnTempCalibRunP1.Size = new System.Drawing.Size(132, 30);
            this.btnTempCalibRunP1.TabIndex = 27;
            this.btnTempCalibRunP1.Text = "Run Point1";
            this.btnTempCalibRunP1.UseVisualStyleBackColor = true;
            this.btnTempCalibRunP1.Click += new System.EventHandler(this.btnTempCalibRunP1_Click);
            // 
            // txtTempCalibRes2
            // 
            this.txtTempCalibRes2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTempCalibRes2.Location = new System.Drawing.Point(144, 101);
            this.txtTempCalibRes2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.txtTempCalibRes2.Name = "txtTempCalibRes2";
            this.txtTempCalibRes2.Size = new System.Drawing.Size(135, 25);
            this.txtTempCalibRes2.TabIndex = 14;
            this.txtTempCalibRes2.Text = "1300";
            this.txtTempCalibRes2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.txtTempCalibRes2.Click += new System.EventHandler(this.txtTempCalibRes2_Click);
            // 
            // txtTempCalibRes1
            // 
            this.txtTempCalibRes1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTempCalibRes1.Location = new System.Drawing.Point(144, 55);
            this.txtTempCalibRes1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.txtTempCalibRes1.Name = "txtTempCalibRes1";
            this.txtTempCalibRes1.Size = new System.Drawing.Size(135, 25);
            this.txtTempCalibRes1.TabIndex = 13;
            this.txtTempCalibRes1.Text = "1000";
            this.txtTempCalibRes1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.txtTempCalibRes1.Click += new System.EventHandler(this.txtTempCalibRes1_Click);
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(31, 105);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(101, 17);
            this.label36.TabIndex = 3;
            this.label36.Text = "Res of  Point2:";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(31, 59);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(101, 17);
            this.label37.TabIndex = 2;
            this.label37.Text = "Res of  Point1:";
            // 
            // timerMornitor
            // 
            this.timerMornitor.Interval = 3000;
            this.timerMornitor.Tick += new System.EventHandler(this.timerMornitor_Tick);
            // 
            // timerReadSetting
            // 
            this.timerReadSetting.Interval = 3000;
            this.timerReadSetting.Tick += new System.EventHandler(this.timerReadSetting_Tick);
            // 
            // timerWriteSetting
            // 
            this.timerWriteSetting.Interval = 3000;
            this.timerWriteSetting.Tick += new System.EventHandler(this.timerWriteSetting_Tick);
            // 
            // timerReadDeviceInfo
            // 
            this.timerReadDeviceInfo.Interval = 3000;
            this.timerReadDeviceInfo.Tick += new System.EventHandler(this.timerReadDeviceInfo_Tick);
            // 
            // timerWriteDeviceInfo
            // 
            this.timerWriteDeviceInfo.Interval = 3000;
            this.timerWriteDeviceInfo.Tick += new System.EventHandler(this.timerWriteDeviceInfo_Tick);
            // 
            // timerCalib
            // 
            this.timerCalib.Interval = 1000;
            this.timerCalib.Tick += new System.EventHandler(this.timerCalib_Tick);
            // 
            // PHORP
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1399, 863);
            this.Controls.Add(this.groupBoxSettingWindow);
            this.Controls.Add(this.groupBoxPortSetting);
            this.Controls.Add(this.groupLogWindow);
            this.Controls.Add(this.statusBar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "PHORP";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "配置工具";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.groupLogWindow.ResumeLayout(false);
            this.statusBar.ResumeLayout(false);
            this.statusBar.PerformLayout();
            this.groupBoxPortSetting.ResumeLayout(false);
            this.groupBoxPortSetting.PerformLayout();
            this.groupBoxSettingWindow.ResumeLayout(false);
            this.tabControl.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            this.groupORPCalib.ResumeLayout(false);
            this.groupORPCalib.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picORPCalibProgress)).EndInit();
            this.groupPHCalib.ResumeLayout(false);
            this.groupPHCalib.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picPHCalibProcess)).EndInit();
            this.tabPage7.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupLogWindow;
        //private System.Windows.Forms.RadioButton rdse;
        private System.Windows.Forms.RichTextBox txtReceive;
        private System.Windows.Forms.StatusStrip statusBar;
        private System.Windows.Forms.ToolStripStatusLabel tsSpNum;
        private System.Windows.Forms.ToolStripStatusLabel tsBaudRate;
        private System.Windows.Forms.ToolStripStatusLabel tsDataBits;
        private System.Windows.Forms.ToolStripStatusLabel tsStopBits;
        private System.Windows.Forms.ToolStripStatusLabel tsParity;
        private System.Windows.Forms.GroupBox groupBoxPortSetting;
        private System.Windows.Forms.Label labelLanguage;
        private System.Windows.Forms.ComboBox comboSelectLanguage;
        private System.Windows.Forms.ComboBox cbBaudRate;
        private System.Windows.Forms.Label labelBaud;
        private System.Windows.Forms.Button buttonRefresh;
        private System.Windows.Forms.Button buttonOpen;
        private System.Windows.Forms.ComboBox comboPort;
        private System.Windows.Forms.Label labelSerialPort;
        private System.Windows.Forms.GroupBox groupBoxSettingWindow;
        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button buttonSettingWriteAll;
        private System.Windows.Forms.Button buttonSettingReadAll;
        private System.Windows.Forms.Button buttonWrite2;
        private System.Windows.Forms.Button buttonWrite1;
        private System.Windows.Forms.Button buttonRead2;
        private System.Windows.Forms.Button buttonRead1;
        private System.Windows.Forms.TextBox textSlaveID;
        private System.Windows.Forms.Label labelBaudRate;
        private System.Windows.Forms.Label labelSlaveID;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button buttonDeviceWriteAll;
        private System.Windows.Forms.Button buttonDeviceReadAll;
        private System.Windows.Forms.Button buttonWrite7;
        private System.Windows.Forms.Button buttonRead7;
        private System.Windows.Forms.TextBox textProductNumber;
        private System.Windows.Forms.Label labelProductNumber;
        private System.Windows.Forms.Button buttonWrite6;
        private System.Windows.Forms.Button buttonRead6;
        private System.Windows.Forms.TextBox textManufactureNumber;
        private System.Windows.Forms.Label labelManufactureNumber;
        private System.Windows.Forms.Button buttonWrite5;
        private System.Windows.Forms.Button buttonWrite4;
        private System.Windows.Forms.Button buttonRead5;
        private System.Windows.Forms.Button buttonRead4;
        private System.Windows.Forms.TextBox textSerialNumber;
        private System.Windows.Forms.TextBox textFWVersion;
        private System.Windows.Forms.Label labelSerialNumber;
        private System.Windows.Forms.Label labelFirmwareVersion;
        private System.Windows.Forms.Button buttonWrite3;
        private System.Windows.Forms.Button buttonRead3;
        private System.Windows.Forms.TextBox textHWVersion;
        private System.Windows.Forms.Label labelHardwareVersion;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button buttonMoitorStop;
        private System.Windows.Forms.Button buttonMoitorStart;
        private System.Windows.Forms.Timer timerMornitor;
        private System.Windows.Forms.TextBox textDeviceID;
        private System.Windows.Forms.Label labelDeviceID;
        private System.Windows.Forms.Timer timerReadSetting;
        private System.Windows.Forms.ComboBox textBaudRate;
        private System.Windows.Forms.Timer timerWriteSetting;
        private System.Windows.Forms.Timer timerReadDeviceInfo;
        private System.Windows.Forms.Timer timerWriteDeviceInfo;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblCalibType;
        private System.Windows.Forms.Label lblSlope2;
        private System.Windows.Forms.Label lblSlope1;
        private System.Windows.Forms.Label lblZeroPoint;
        private System.Windows.Forms.Button btnReadLatestORPCalib;
        private System.Windows.Forms.Button btnReadLatestPHCalib;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtPHResult;
        private System.Windows.Forms.Button btnPHReadResult;
        private System.Windows.Forms.Button btnRunPHCalib;
        private System.Windows.Forms.TextBox txtpH3rdBuffer;
        private System.Windows.Forms.Button btnWrite3rdPH;
        private System.Windows.Forms.TextBox txtpH2ndBuffer;
        private System.Windows.Forms.Button btnWrite2ndPH;
        private System.Windows.Forms.TextBox txtpH1stBuffer;
        private System.Windows.Forms.Button btnWrite1stPH;
        private System.Windows.Forms.Button btnPHCalibTime;
        private System.Windows.Forms.ComboBox cbxPHActionCode;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ComboBox cbxORPActionCode;
        private System.Windows.Forms.TextBox txtORPResult;
        private System.Windows.Forms.Button btnORPCalibResultCode;
        private System.Windows.Forms.Button btnWriteORPActionCode;
        private System.Windows.Forms.TextBox txtORPPoint3;
        private System.Windows.Forms.Button btnWriteORPPoint3;
        private System.Windows.Forms.TextBox txtORPPoint2;
        private System.Windows.Forms.Button btnWriteORPPoint2;
        private System.Windows.Forms.TextBox txtORPPoint1;
        private System.Windows.Forms.Button btnWriteORPPoint1;
        private System.Windows.Forms.Button btnWriteORPCalibTime;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox txtCalibManualResult;
        private System.Windows.Forms.Button btnCalibManualReadResult;
        private System.Windows.Forms.Button btnWriteCalibManualAction;
        private System.Windows.Forms.TextBox txtBasicSlope;
        private System.Windows.Forms.Button btnWriteBasicSlope;
        private System.Windows.Forms.TextBox txtAcidSlope;
        private System.Windows.Forms.Button btnWriteAcidSlope;
        private System.Windows.Forms.TextBox txtZeroPoint;
        private System.Windows.Forms.Button btnWriteZeroPoint;
        private System.Windows.Forms.Button btnWriteCalibManualTime;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblCalibTime;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Button btnFactoryResetCalib;
        private System.Windows.Forms.Button btnFactoryResetSetting;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox txtTempCalibResult;
        private System.Windows.Forms.Button btnReadTempCalibResult;
        private System.Windows.Forms.Button btnRunTempCalib;
        private System.Windows.Forms.TextBox txtResOfPoint2;
        private System.Windows.Forms.Button btnWriteResOfPoint2;
        private System.Windows.Forms.TextBox txtResOfPoint1;
        private System.Windows.Forms.Button btnWriteResOfPoint1;
        private System.Windows.Forms.Button btnWriteTempCalibTime;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label txtTempCalibTime;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label txtTempOffset;
        private System.Windows.Forms.Label txtTempSlope;
        private System.Windows.Forms.Button btnLatestTempCalibration;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label textTemperature;
        private System.Windows.Forms.Label textORP;
        private System.Windows.Forms.Label textPH;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Label txtMTCStatus;
        private System.Windows.Forms.Button btnReadMTCStatus;
        private System.Windows.Forms.Label txtReadMTC;
        private System.Windows.Forms.Button btnReadManualTemp;
        private System.Windows.Forms.TextBox txtWriteMTC;
        private System.Windows.Forms.Button btnWriteManualTemp;
        private System.Windows.Forms.TextBox txtTempBias;
        private System.Windows.Forms.Button btnWriteTempBias;
        private System.Windows.Forms.ComboBox cbxTempMode;
        private System.Windows.Forms.Button btnWriteTempMode;
        private System.Windows.Forms.Label txtReadTempBias;
        private System.Windows.Forms.Button btnReadTempBias;
        private System.Windows.Forms.TextBox txtOrpBias;
        private System.Windows.Forms.Button btnWriteOrpBias;
        private System.Windows.Forms.Label txtReadOrpBias;
        private System.Windows.Forms.Button btnReadOrpBias;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.GroupBox groupORPCalib;
        private System.Windows.Forms.Button btnORPCalibStart;
        private System.Windows.Forms.Button btnORPCalibFinish;
        private System.Windows.Forms.Button btnORPCalibContinue;
        private System.Windows.Forms.Button btnORPCalibBack;
        private System.Windows.Forms.Label txtORPBuffer3;
        private System.Windows.Forms.Label txtORPBuffer2;
        private System.Windows.Forms.Label txtORPBuffer1;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.GroupBox groupPHCalib;
        private System.Windows.Forms.Button btnPHCalibStart;
        private System.Windows.Forms.Button btnPHCalibFinish;
        private System.Windows.Forms.Button btnPHCalibContinue;
        private System.Windows.Forms.Button btnPHCalibBack;
        private System.Windows.Forms.Label txtPHOfBuffer;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label txtPHCalibTime;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label txtPHCalibTemp;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label txtPHVoltage;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label txtPHOfBuffer3;
        private System.Windows.Forms.Label txtPHOfBuffer2;
        private System.Windows.Forms.Label txtPHOfBuffer1;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox comboCalibType;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.Label txtORPMeasure3;
        private System.Windows.Forms.Label txtORPMeasure2;
        private System.Windows.Forms.Label txtORPMeasure1;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.PictureBox picPHCalibProcess;
        private System.Windows.Forms.Timer timerCalib;
        private System.Windows.Forms.PictureBox picORPCalibProgress;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Button btnTempCalibRunCalib;
        private System.Windows.Forms.Button btnTempCalibRunP2;
        private System.Windows.Forms.Label txtTempCalibResMea2;
        private System.Windows.Forms.Label txtTempCalibResMea1;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Button btnTempCalibRunP1;
        private System.Windows.Forms.Label txtTempCalibRes2;
        private System.Windows.Forms.Label txtTempCalibRes1;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
    }
}

