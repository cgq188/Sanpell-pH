﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SerialPortConnection
{
    public class ChineseString
    {

        /************ Title ***************/
        public static string SETTING_TOOLS_CN = "配置工具";
        public static string SETTING_TOOLS_EN = "SettingTools";


        /************ Port Setting Group ***************/
        public static string PORT_SETTING_CN = "串口设置";
        public static string PORT_SETTING_EN = "Port Setting";

        public static string SERIAL_PORT_CN = "  串 口 :";
        public static string SERIAL_PORT_EN = "Serial Port :";

        public static string BTN_REFREASH_CN = "刷 新";
        public static string BTN_REFREASH_EN = "Refresh";

        public static string BTN_OPEN_CN = "打 开";
        public static string BTN_OPEN_EN = "Open";

        public static string BTN_CLOSE_CN = "关 闭";
        public static string BTN_CLOSE_EN = "Close";

        public static string SLAVE_ID_CN = "从设备ID";
        public static string SLAVE_ID_EN = "Slave ID";

        public static string LABEL_LANGUAGE_CN = "语  言 :";
        public static string LABEL_LANGUAGE_EN = "Language :";


        /************ Log Window ***************/
        public static string LOG_WINDOW_CN = "日志窗口";
        public static string LOG_WINDOW_EN = "Log Window";

        public static string LOG_SEND_CN = "发  送";
        public static string LOG_SEND_EN = "Send";

        public static string LOG_RECEIVE_CN = "返  回";
        public static string LOG_RECEIVE_EN = "Receive";

        /************ Setting Window ***************/
        public static string SETTING_WINDOW_CN = "设置窗口";
        public static string SETTING_WINDOW_EN = "Setting Window";

        public static string TAB_TRANSMMITION_SETTING_CN = " 传 输 设 置 ";
        public static string TAB_TRANSMMITION_SETTING_EN = "Transmmition Setting";

        public static string TAB_DEVICE_INFOMATION_CN = " 设 备 信 息 ";
        public static string TAB_DEVICE_INFOMATION_EN = "Device Information:";

        public static string TAB_MONITORING_CN = " 监   控 ";
        public static string TAB_MONITORING_EN = "Monitoring";

        public static string HARDWARE_VERSION_CN = "    硬件版本:";
        public static string HARDWARE_VERSION_EN = "Hardware Version:";

        public static string FIRMWARE_VERSION_CN = "    固件版本:";
        public static string FIRMWARE_VERSION_EN = "Firmware Version:";

        public static string SERIAL_NUMBER_CN = "    序列号:";
        public static string SERIAL_NUMBER_EN = "Serial Number:";

        public static string MANUFACTURER_NUMBER_CN = "     厂家编号:";
        public static string MANUFACTURER_NUMBER_EN = "Manufacturer Number:";

        public static string PRODUCT_NUMBER_CN = "     产品编号:";
        public static string PRODUCT_NUMBER_EN = "Product Number:";

        public static string BAUD_RATE_CN = " 波特率:";
        public static string BAUD_RATE_EN = "Baud Rate:";

        public static string SLAVE_ID_CN1 = "从设备ID:";
        public static string SLAVE_ID_EN1 = "Slave ID:";

        public static string DATE_TIME_CN = "  日期 / 时间:";
        public static string DATE_TIME_EN = "Date / Time:";

        public static string BUTTON_READ_CN = "阅读";
        public static string BUTTON_READ_EN = "Read";

        public static string BUTTON_WRITE_CN = "编写";
        public static string BUTTON_WRITE_EN = "Write";

        public static string BUTTON_READ_ALL_CN = "全部阅读";
        public static string BUTTON_READ_ALL_EN = "Read All";

        public static string BUTTON_WRITE_ALL_CN = "全部写";
        public static string BUTTON_WRITE_ALL_EN = "Write All";

        public static string BUTTON_START_CN = "开始";
        public static string BUTTON_START_EN = "Start";

        public static string BUTTON_STOP_CN = "停止";
        public static string BUTTON_STOP_EN = "Stop";

    }
}
