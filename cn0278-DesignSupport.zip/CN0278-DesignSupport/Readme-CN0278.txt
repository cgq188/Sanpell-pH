Analog Devices Inc.
Design Support Package
CN-0278
06/06/2012
Rev. 0


This file is designed to provide you with a brief overview of what is contained within the circuit note design support package.


**********************
*******Overview*******
**********************


CN-0278 Design Support Package contains: 
	
	Link to Circuit Note
	Link to Product Datasheets
	Link to Product Evaluation Boards and User Guides
	PADs Schematics
	Bill of Materials
	Assembly Drawings
	PADs Layout Files
	Gerber Layout Files	
	Link to Symbols and Footprints
	Link to Technical Support
	Link to Other Resources



**********************
***File Explanation**
**********************


Circuit Note - Copy of the circuit note this design support package was made for. This file is provided as a PDF:

	CN0278: http://www.analog.com/CN0278


Product Datasheets - Links to all ADI component datasheets used in the circuit. These files are provided as a PDF:

	AD5700: http://www.analog.com/AD5700
	AD5700-1: http://www.analog.com/AD5700-1
	AD5422: http://www.analog.com/AD5422
	

AD5700 	Evaluation Board:
	 
	EVAL-AD5700-1EBZ: http://www.analog.com/EVAL-AD5700-1EBZ


AD5700 Evaluation Board User Guide, UG-382:

	http://www.analog.com/UG-382


EVAL-AD5700-1EBZ Schematic:

	EVAL-AD5700-1EBZ-SCH-Rev0.sch
	EVAL-AD5700-1EBZ-SCH-Rev0.pdf


EVAL-AD5700-1EBZ PADS Layout and Assembly:

	EVAL-AD5700-1EBZ-PADS-Rev0.pcb


EVAL-AD5700-1EBZ Gerber Files:

	EVAL-AD5700-1EBZ-GBR-Rev01.zip


EVAL-AD5700-1EBZ Bill of Material:

	EVAL-AD5700-1EBZ-BOM-Rev01.xls



AD5422 Evaluation Board User Guide:

	EVAL-AD5422LFEBZ: http://www.analog.com/EVAL-AD5422



EVAL-AD5422FLEBZ Schematic:

	EVAL-AD5422LFEBZ-SCH-Rev01.sch
	EVAL-AD5422LFEBZ-SCH-Rev01.pdf


EVAL-AD5422LFEBZ PADS Layout and Assembly:

	EVAL-AD5422LFEBZ-PADS-Rev01.pcb


EVAL-AD5422LFEBZ Gerber Files:

	EVAL-AD5422LFEBZ-GBR-Rev01.zip


EVAL-AD5422LFEBZ Bill of Material:

	EVAL-AD5422LFEBZ-BOM-Rev01.xls


		
Symbols and Footprints:

	
AD5700:
http://www.analog.com/en/interface/hart-modem/ad5700/products/symbols-footprints.html

AD5700-1:
http://www.analog.com/en/interface/hart-modem/ad5700-1/products/symbols-footprints.html

AD5422:
http://www.analog.com/en/digital-to-analog-converters/da-converters/ad5422/products/symbols-footprints.html




Technical Support -  If you require further technical assistance please contact us by phone, email, or our EngineerZone community.  http://www.analog.com/en/content/technical_support_page/fca.html



**********************
***Other Resources****
**********************


Resources that are not provided by Analog Devices, but could be helpful.


Gerber Viewer:  http://www.graphicode.com

PADs Viewer: http://www.mentor.com/products/pcb-system-design/design-flows/pads/pads-pcb-viewer

Allegro Physical Viewer: http://www.cadence.com/products/pcb/Pages/downloads.aspx


